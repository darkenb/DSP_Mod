# Related mods and code references — starfi5h-ErrorAnalyzer

All listed copies are inside this mod folder. They are one-level reference copies with their own Source, InstalledPackage, metadata and English change notes. Required installed dependencies of those copies are flattened into the same RelatedMods directory; copies never recursively contain another RelatedMods directory.

Dependency declarations (including optional compatibility plugins), compiled member calls and native integration/test context are distinguished below. A shared native API touchpoint is not presented as a direct foreign-method call. Original game/BepInEx SDK files and uninstalled optional mods are not fabricated or downloaded. 

## crecheng-CloseError

Copy: `RelatedMods/crecheng-CloseError/`.

- **fix_integration_context**: Both operate on the same native error-panel lifecycle; closing/resetting must release the tracked error and button state.

### Code in this mod

`Source/Reconstructed/plugins/ErrorAnalyzer/ErrorAnalyzer/Plugin.cs:42`

```csharp
		try
		{
			harmony.PatchAll(typeof(UIFatalErrorTip_Patch));
			Application.logMessageReceived += HandleLog;
			isRegistered = true;
```

`Source/Reconstructed/plugins/ErrorAnalyzer/ErrorAnalyzer/UIErrorEnhancer.cs:18`

```csharp

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIFatalErrorTip), "_OnClose")]
	public static void OnClose_Postfix()
	{
```

`Source/Reconstructed/plugins/ErrorAnalyzer/ErrorAnalyzer/UIFatalErrorTip_Patch.cs:11`

```csharp
namespace ErrorAnalyzer;

[HarmonyPatch(typeof(UIFatalErrorTip))]
internal class UIFatalErrorTip_Patch
{
```

`Source/EarlierWorkingSource/Plugin.cs:40`

```csharp
            try
            {
                harmony.PatchAll(typeof(UIFatalErrorTip_Patch));
                Application.logMessageReceived += HandleLog;
                isRegistered = true;
```

`Source/EarlierWorkingSource/UIErrorEnhancer.cs:19`

```csharp

        [HarmonyPostfix]
        [HarmonyPatch(typeof(UIFatalErrorTip), "_OnClose")]
        public static void OnClose_Postfix()
        {
```

### Code in the related copy

`RelatedMods/crecheng-CloseError/Source/Reconstructed/plugins/closeError/closeError/CloseError.cs:28`

```csharp
			if (GUI.Button(rect, "X"))
			{
				UIFatalErrorTip.instance?._Close();
				isError = false;
			}
```

`RelatedMods/crecheng-CloseError/Source/EarlierWorkingSource/CloseError.cs:27`

```csharp
            if (GUI.Button(rect, "X"))
            {
                UIFatalErrorTip.instance?._Close();
                isError = false;
            }
```

`RelatedMods/crecheng-CloseError/Evidence/InitialPhase/check.cs:9`

```csharp
    static int Main()
    {
        var type = typeof(CloseError);
        var flag = AccessTools.Field(type, "isError");
        AccessTools.Method(type, "errorFalse").Invoke(null, new object[] {null});
```
