using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("ErrorAnalyzer")]
[assembly: AssemblyVersion("1.3.3.0")]
[module: RefSafetyRules(11)]
