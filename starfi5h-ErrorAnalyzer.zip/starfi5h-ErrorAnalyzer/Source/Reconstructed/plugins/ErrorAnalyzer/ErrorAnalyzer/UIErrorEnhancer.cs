using System.Collections.Generic;
using System.Reflection;
using BepInEx;
using HarmonyLib;
using UnityEngine;

namespace ErrorAnalyzer;

internal class UIErrorEnhancer
{
	private static bool isChecked;

	private static BepInExPluginIdentifier bepInExPluginIdentifier;

	private static HarmonyPatcherMapper harmonyPatcherMapper;

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIFatalErrorTip), "_OnClose")]
	public static void OnClose_Postfix()
	{
		isChecked = false;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIFatalErrorTip), "_OnOpen")]
	public static void OnOpen_Postfix(UIFatalErrorTip __instance)
	{
		if (!isChecked)
		{
			string text = __instance.errorLogText.text;
			string text2 = ParseAndAnalysis(text, Plugin.ShowFullStack.Value);
			text = StackParser.CleanStacktrace(text);
			Plugin.Log.LogInfo(text2);
			__instance.errorLogText.text = text + text2;
			__instance.rectTrans.sizeDelta = new Vector2(__instance.rectTrans.sizeDelta.x, __instance.errorLogText.preferredHeight + 45f);
			__instance.errorLogText.rectTransform.sizeDelta = new Vector2(__instance.errorLogText.rectTransform.sizeDelta.x, __instance.errorLogText.preferredHeight + 2f);
			isChecked = true;
		}
	}

	public static string ParseAndAnalysis(string errorLog, bool showAllPatches = false)
	{
		if (harmonyPatcherMapper == null)
		{
			harmonyPatcherMapper = new HarmonyPatcherMapper();
		}
		if (bepInExPluginIdentifier == null)
		{
			bepInExPluginIdentifier = new BepInExPluginIdentifier();
		}
		string text = "";
		List<(string, string)> list = StackParser.ParseStackTraceLines(errorLog);
		if (list.Count == 0)
		{
			return text;
		}
		string text2 = "";
		HashSet<Assembly> hashSet = new HashSet<Assembly>();
		HashSet<Assembly> hashSet2 = new HashSet<Assembly>();
		string item = list[0].Item1;
		Assembly assembly = bepInExPluginIdentifier.GetAssembly(list[0].Item1);
		if (assembly != null)
		{
			hashSet.Add(assembly);
		}
		MethodBase modMethod = harmonyPatcherMapper.GetModMethod(list[0].Item1, list[0].Item2);
		if (modMethod != null)
		{
			hashSet.UnionWith(harmonyPatcherMapper.GetModAssembliesFromMethod(modMethod));
			text2 += harmonyPatcherMapper.GetPatchesDescription(modMethod);
		}
		if (hashSet.Count == 0)
		{
			hashSet2 = harmonyPatcherMapper.GetModAssembliesFromType(list[0].Item1);
		}
		bool flag = false;
		for (int i = 1; i < list.Count; i++)
		{
			string item2 = list[i].Item1;
			string item3 = list[i].Item2;
			Assembly assembly2 = bepInExPluginIdentifier.GetAssembly(item2);
			if (assembly2 != null)
			{
				hashSet.Add(assembly2);
			}
			if (!showAllPatches)
			{
				if (flag)
				{
					continue;
				}
				if (item2 == "VFPreload")
				{
					flag = true;
				}
				if (item2 == "GameMain")
				{
					flag = true;
				}
				if (item3 == "GameTick" && (item2 == "GameData" || item2 == "PlanetFactory"))
				{
					flag = true;
				}
				if (item3 == "ProcessFrame" && item2 == "ThreadManager")
				{
					flag = true;
				}
				if (item3 == "LogicFrame" && item2 == "GameLogic")
				{
					flag = true;
				}
				if (flag)
				{
					continue;
				}
			}
			MethodBase modMethod2 = harmonyPatcherMapper.GetModMethod(item2, item3);
			if (modMethod2 != null)
			{
				hashSet.UnionWith(harmonyPatcherMapper.GetModAssembliesFromMethod(modMethod2));
				text2 += harmonyPatcherMapper.GetPatchesDescription(modMethod2);
				flag = true;
			}
		}
		if (hashSet2.Count > 0)
		{
			text = text + "\n[== Mods to " + item + " ==]: ";
			foreach (Assembly item4 in hashSet2)
			{
				text = text + "[" + item4.GetName().Name + "]";
			}
		}
		if (hashSet.Count > 0)
		{
			text += "\n[== Mods on stack trace ==]: ";
			foreach (Assembly item5 in hashSet)
			{
				text = text + "[" + item5.GetName().Name + "]";
			}
			text = text + "\n" + text2;
		}
		UpdateExtraTitleString(hashSet);
		return text;
	}

	private static void UpdateExtraTitleString(HashSet<Assembly> relevantAssemblies)
	{
		UIFatalErrorTip_Patch.ExtraTitleString = ((relevantAssemblies.Count > 0) ? "possible candidates: " : "");
		foreach (Assembly relevantAssembly in relevantAssemblies)
		{
			foreach (PluginInfo pluginInfo in bepInExPluginIdentifier.GetPluginInfoList(relevantAssembly))
			{
				string name = pluginInfo.Metadata.Name;
				string text = pluginInfo.Metadata.Version.ToString();
				UIFatalErrorTip_Patch.ExtraTitleString = UIFatalErrorTip_Patch.ExtraTitleString + "[" + name + text + "]";
			}
		}
	}
}
