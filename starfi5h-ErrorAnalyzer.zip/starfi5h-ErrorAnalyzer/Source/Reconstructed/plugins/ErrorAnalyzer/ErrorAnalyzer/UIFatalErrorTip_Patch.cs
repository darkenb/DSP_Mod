using System;
using System.Text;
using BepInEx;
using BepInEx.Bootstrap;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace ErrorAnalyzer;

[HarmonyPatch(typeof(UIFatalErrorTip))]
internal class UIFatalErrorTip_Patch
{
	private static UIButton btnClose;

	private static UIButton btnCopy;

	private static UIButton btnInspect;

	private static bool waitingToRefresh;

	private static int astroId;

	private static int entityId;

	private static Vector3 localPos;

	public static string ExtraTitleString { get; set; } = "";

	[HarmonyPostfix]
	[HarmonyPatch("_OnRegEvent")]
	private static void OnRegEvent_Postfix()
	{
		if (!Plugin.isRegistered)
		{
			return;
		}
		Plugin.isRegistered = false;
		try
		{
			Application.logMessageReceived -= Plugin.HandleLog;
			if (string.IsNullOrEmpty(Plugin.errorString) || Chainloader.PluginInfos.ContainsKey("dsp.nebula-multiplayer"))
			{
				return;
			}
			string[] array = Plugin.errorStackTrace.Split('\n', '\r');
			Plugin.Log.LogDebug("Error captured during loading. Lines count: " + array.Length);
			if (array.Length > 15)
			{
				StringBuilder stringBuilder = new StringBuilder();
				for (int i = 0; i < 5; i++)
				{
					stringBuilder.AppendLine(array[i].TrimEnd('\n', '\r'));
				}
				stringBuilder.AppendLine($"...(skip the middle {array.Length - 15} lines)");
				for (int j = array.Length - 10; j < array.Length; j++)
				{
					stringBuilder.AppendLine(array[j].TrimEnd('\n', '\r'));
				}
				Plugin.errorStackTrace = stringBuilder.ToString();
			}
			UIFatalErrorTip.instance.ShowError(Plugin.errorString, Plugin.errorStackTrace);
		}
		catch (Exception data)
		{
			Plugin.Log.LogError(data);
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch("ShowError")]
	private static void ShowError_Prefix(UIFatalErrorTip __instance)
	{
		if (string.IsNullOrEmpty(__instance.errorLogText.text) || waitingToRefresh)
		{
			TrackEntity_Patch.Snapshot(out astroId, out entityId, out localPos);
		}
		if (waitingToRefresh)
		{
			waitingToRefresh = false;
			UIFatalErrorTip.ClearError();
			TryNavigate();
		}
	}

	[HarmonyPostfix]
	[HarmonyPriority(200)]
	[HarmonyPatch("_OnOpen")]
	private static void OnOpen_Postfix(UIFatalErrorTip __instance)
	{
		if (btnClose != null || btnCopy != null || btnInspect != null)
		{
			return;
		}
		bool num = Chainloader.PluginInfos.ContainsKey("dsp.nebula-multiplayer");
		if (!num)
		{
			TryCreateButton(delegate
			{
				CreateCloseBtn(__instance);
			}, "Close Button");
			TryCreateButton(delegate
			{
				CreateCopyBtn(__instance);
			}, "Copy Button");
		}
		TryCreateButton(delegate
		{
			CreateInspectBtn(__instance);
		}, "Inspect Button");
		if (!num)
		{
			__instance.transform.Find("tip-text-0").GetComponent<Text>().text = GetShortTitle();
			__instance.transform.Find("tip-text-1").GetComponent<Text>().text = GetShortTitle();
			UnityEngine.Object.Destroy(__instance.transform.Find("tip-text-0").GetComponent<Localizer>());
			UnityEngine.Object.Destroy(__instance.transform.Find("tip-text-1").GetComponent<Localizer>());
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch("_OnClose")]
	private static void OnClose_Postfix()
	{
		if (btnClose != null)
		{
			UnityEngine.Object.Destroy(btnClose.gameObject);
			btnClose = null;
		}
		if (btnCopy != null)
		{
			UnityEngine.Object.Destroy(btnCopy.gameObject);
			btnCopy = null;
		}
		if (btnInspect != null)
		{
			UnityEngine.Object.Destroy(btnInspect.gameObject);
			btnInspect = null;
		}
		TrackEntity_Patch.ResetId();
	}

	private static void TryCreateButton(Action createAction, string buttonName)
	{
		try
		{
			createAction();
		}
		catch (Exception arg)
		{
			Plugin.Log.LogWarning($"{buttonName} did not patch!\n{arg}");
		}
	}

	private static UIButton CreateButton(string path, Transform parent, Vector3 positionOffset, Action<int> onClickAction)
	{
		GameObject gameObject = GameObject.Find(path);
		if (gameObject == null)
		{
			Plugin.Log.LogWarning("Can't find " + path);
			return null;
		}
		return CreateButton(gameObject, parent, positionOffset, onClickAction);
	}

	private static UIButton CreateButton(GameObject originalGo, Transform parent, Vector3 positionOffset, Action<int> onClickAction)
	{
		if (originalGo != null)
		{
			GameObject gameObject = UnityEngine.Object.Instantiate(originalGo, parent);
			RectTransform obj = (RectTransform)gameObject.transform;
			obj.anchorMin = Vector2.up;
			obj.anchorMax = Vector2.up;
			obj.pivot = Vector2.up;
			obj.anchoredPosition = positionOffset;
			gameObject.SetActive(value: true);
			UIButton component = gameObject.GetComponent<UIButton>();
			component.onClick += onClickAction;
			component.tips.corner = 1;
			return component;
		}
		return null;
	}

	private static void CreateCloseBtn(UIFatalErrorTip __instance)
	{
		if (!(btnClose != null))
		{
			btnClose = CreateButton("UI Root/Overlay Canvas/In Game/Common Tools/Color Palette Panel/panel-bg/btn-box/close-wnd-btn", __instance.transform, new Vector3(-5f, 0f, 0f), OnCloseClick);
			if (!(btnClose != null))
			{
				btnClose = CreateButton("UI Root/Overlay Canvas/In Game/Windows/Window Template/panel-bg/btn-box/close-btn", __instance.transform, new Vector3(-5f, 0f, 0f), OnCloseClick);
			}
		}
	}

	private static void CreateCopyBtn(UIFatalErrorTip __instance)
	{
		if (!(btnCopy != null))
		{
			btnCopy = CreateButton("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy/layers/blueprint-group/blueprint-2/copy-button", __instance.transform, new Vector3(5f, -55f, 0f), OnCopyClick);
			btnCopy.tips.tipTitle = "Copy Error Message";
			btnCopy.tips.tipText = "Copy the message to clipboard\nShift-click to copy the mod list too";
		}
	}

	private static void CreateInspectBtn(UIFatalErrorTip __instance)
	{
		if (!(btnInspect != null) && GameMain.mainPlayer != null)
		{
			btnInspect = CreateButton(UIRoot.instance.uiGame.researchQueue.pauseButton.gameObject, __instance.transform, new Vector3(20f, -80f, 0f), OnInspectClick);
			btnInspect.transform.Find("icon").GetComponent<Image>().sprite = UIRoot.instance.uiGame.starmap.cursorFunctionButton2.transform.Find("icon").GetComponent<Image>().sprite;
			btnInspect.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
			btnInspect.onRightClick += ToggleTrackMode;
			btnInspect.tips.tipTitle = "Find The Error Entity";
			btnInspect.tips.tipText = "Left click to navigate\nRight click to toggle debug mode";
			if (astroId > 0 && astroId % 100 != 0)
			{
				string arg = GameMain.galaxy.PlanetById(astroId).displayName ?? "";
				btnInspect.tips.tipText += $"\nentity: {entityId} at [{astroId}] {arg}";
			}
			SetInsepctButton();
		}
	}

	private static string GetFullTitle()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("Error report: Game version ");
		stringBuilder.Append(GameConfig.gameVersion.ToString());
		stringBuilder.Append('.');
		stringBuilder.Append(GameConfig.gameVersion.Build);
		stringBuilder.Append(" with ");
		stringBuilder.Append(Chainloader.PluginInfos.Values.Count);
		stringBuilder.AppendLine(" mods used.");
		foreach (PluginInfo value in Chainloader.PluginInfos.Values)
		{
			stringBuilder.Append('[');
			stringBuilder.Append(value.Metadata.Name);
			stringBuilder.Append(value.Metadata.Version);
			stringBuilder.Append("] ");
		}
		return stringBuilder.ToString();
	}

	private static string GetShortTitle()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("Error report: Game version ");
		stringBuilder.Append(GameConfig.gameVersion.ToString());
		stringBuilder.Append('.');
		stringBuilder.Append(GameConfig.gameVersion.Build);
		stringBuilder.Append(" with ");
		stringBuilder.Append(Chainloader.PluginInfos.Values.Count);
		stringBuilder.Append(" mods used.");
		if (!string.IsNullOrWhiteSpace(ExtraTitleString))
		{
			stringBuilder.AppendLine();
			stringBuilder.Append(ExtraTitleString);
		}
		return stringBuilder.ToString();
	}

	private static void OnCopyClick(int id)
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("```ini");
		if (VFInput.shift)
		{
			stringBuilder.AppendLine(GetFullTitle());
		}
		else
		{
			stringBuilder.AppendLine(GetShortTitle());
		}
		string[] array = UIFatalErrorTip.instance.errorLogText.text.Split('\n', '\r');
		foreach (string text in array)
		{
			if (!string.IsNullOrEmpty(text))
			{
				int num = text.LastIndexOf(" <", StringComparison.Ordinal);
				int num2 = text.LastIndexOf(">:", StringComparison.Ordinal);
				if (num != -1 && num2 > num)
				{
					stringBuilder.AppendLine(text.Remove(num, num2 - num + 2));
				}
				else
				{
					stringBuilder.AppendLine(text);
				}
			}
		}
		stringBuilder.Replace(" (at", "; (");
		stringBuilder.Replace(" inIL_", " ;IL_");
		stringBuilder.AppendLine("```");
		GUIUtility.systemCopyBuffer = stringBuilder.ToString();
		UIRealtimeTip.Popup("Error message copied!", sound: false);
	}

	public static void OnCloseClick(int _)
	{
		waitingToRefresh = false;
		UIFatalErrorTip.ClearError();
		if (!(GameConfig.gameVersion < new Version(0, 10, 33)))
		{
			ClearErrorCount();
		}
	}

	public static void ClearErrorCount()
	{
		ThreadManager threadManager = GameMain.logic?.threadController?.threadManager;
		if (threadManager != null)
		{
			Plugin.Log.LogDebug($"Error closed. frameErrorCountMainThread={threadManager.frameErrorCountMainThread} erroredFrameCount={threadManager.erroredFrameCount}");
			threadManager.frameErrorCountAllThreads = 0;
			threadManager.frameErrorCountMainThread = 0;
			threadManager.erroredFrameCount = 0;
			threadManager.totalErrorCount = 0;
		}
	}

	private static void OnInspectClick(int _)
	{
		if (astroId <= 0)
		{
			if (!TrackEntity_Patch.Active)
			{
				waitingToRefresh = true;
				ToggleTrackMode(0);
			}
		}
		else
		{
			TryNavigate();
		}
	}

	internal static void TryNavigate()
	{
		if (astroId <= 0 || GameMain.mainPlayer == null)
		{
			return;
		}
		if (astroId % 100 != 0 && GameMain.data.localPlanet?.id == astroId)
		{
			PlanetFactory factory = GameMain.data.localPlanet.factory;
			if (entityId >= factory.entityPool.Length)
			{
				UIRealtimeTip.Popup($"EntityId {entityId} exceed Pool length {factory.entityPool.Length}!");
				return;
			}
			localPos = ((entityId > 0) ? factory.entityPool[entityId].pos : localPos);
			UIRoot.instance.uiGame.globemap.MoveToViewTargetTwoStep(localPos, localPos.magnitude - GameMain.data.localPlanet.realRadius);
			GameMain.data.mainPlayer.Order(OrderNode.MoveTo(localPos), multiple: false);
		}
		else
		{
			GameMain.mainPlayer.navigation.indicatorAstroId = astroId;
		}
	}

	private static void ToggleTrackMode(int _)
	{
		try
		{
			TrackEntity_Patch.Enable(!TrackEntity_Patch.Active);
			SetInsepctButton();
		}
		catch (Exception ex)
		{
			Plugin.Log.LogError("Can't enable tracking!\n" + ex);
		}
	}

	private static void SetInsepctButton()
	{
		if (!(btnInspect == null) && btnInspect.transitions.Length != 0)
		{
			btnInspect.CloseTip();
			if (TrackEntity_Patch.Active)
			{
				btnInspect.tips.tipTitle = "Find The Error Entity (ON)";
				btnInspect.transitions[0].normalColor = new Color(0.7f, 0.7f, 0.3f, 0.4f);
				btnInspect.transitions[0].mouseoverColor = new Color(0.7f, 0.7f, 0.3f, 0.5f);
			}
			else
			{
				btnInspect.tips.tipTitle = "Find The Error Entity (OFF)";
				btnInspect.transitions[0].normalColor = new Color(0.2392f, 0.6f, 0.9f, 0.078f);
				btnInspect.transitions[0].mouseoverColor = new Color(0.2392f, 0.6f, 0.9f, 0.178f);
			}
		}
	}
}
