using System;
using HarmonyLib;
using UnityEngine;

namespace ErrorAnalyzer;

internal class TrackEntity_Patch
{
	private static class Patch1033
	{
		[HarmonyFinalizer]
		[HarmonyPatch(typeof(FactorySystem), "GameTick")]
		[HarmonyPatch(typeof(FactorySystem), "GameTickLabProduceMode")]
		[HarmonyPatch(typeof(FactorySystem), "GameTickLabResearchMode")]
		[HarmonyPatch(typeof(FactorySystem), "GameTickInserters")]
		[HarmonyPatch(typeof(PowerSystem), "GameTick")]
		[HarmonyPatch(typeof(CargoTraffic), "SpraycoaterGameTick")]
		[HarmonyPatch(typeof(DefenseSystem), "GameTick")]
		[HarmonyPatch(typeof(ConstructionSystem), "GameTick")]
		private static Exception GetFactoryId(Exception __exception, PlanetFactory ___factory)
		{
			Capture(__exception, (___factory?.planet?.astroId).GetValueOrDefault(), 0, Vector3.zero);
			return __exception;
		}
	}

	private static class Patch1032
	{
		[HarmonyFinalizer]
		[HarmonyPatch(typeof(FactorySystem), "GameTick", new Type[]
		{
			typeof(long),
			typeof(bool),
			typeof(int),
			typeof(int),
			typeof(int)
		})]
		[HarmonyPatch(typeof(FactorySystem), "GameTickLabProduceMode", new Type[]
		{
			typeof(long),
			typeof(bool),
			typeof(int),
			typeof(int),
			typeof(int)
		})]
		[HarmonyPatch(typeof(FactorySystem), "GameTickLabResearchMode", new Type[]
		{
			typeof(long),
			typeof(bool)
		})]
		[HarmonyPatch(typeof(FactorySystem), "GameTickInserters", new Type[]
		{
			typeof(long),
			typeof(bool),
			typeof(int),
			typeof(int)
		})]
		[HarmonyPatch(typeof(PowerSystem), "GameTick")]
		[HarmonyPatch(typeof(CargoTraffic), "SpraycoaterGameTick")]
		[HarmonyPatch(typeof(CargoTraffic), "PresentCargoPathsAsync")]
		[HarmonyPatch(typeof(DefenseSystem), "GameTick")]
		[HarmonyPatch(typeof(ConstructionSystem), "GameTick")]
		private static Exception GetFactoryId(Exception __exception, PlanetFactory ___factory)
		{
			Capture(__exception, (___factory?.planet?.astroId).GetValueOrDefault(), 0, Vector3.zero);
			return __exception;
		}
	}

	private static Harmony _patch;

	private static readonly object contextLock = new object();

	private static Exception trackedException;

	public static bool Active => _patch != null;

	public static int AstroId { get; private set; }

	public static int EntityId { get; private set; }

	public static Vector3 LocalPos { get; private set; }

	private static void Capture(Exception exception, int astro, int entity, Vector3 position)
	{
		if (exception == null)
		{
			return;
		}
		lock (contextLock)
		{
			if (trackedException == null)
			{
				trackedException = exception;
			}
			if (trackedException == exception)
			{
				if (AstroId == 0)
				{
					AstroId = astro;
				}
				if (EntityId == 0)
				{
					EntityId = entity;
				}
				if (LocalPos == Vector3.zero)
				{
					LocalPos = position;
				}
			}
		}
	}

	internal static void Snapshot(out int astro, out int entity, out Vector3 position)
	{
		lock (contextLock)
		{
			astro = AstroId;
			entity = EntityId;
			position = LocalPos;
		}
	}

	public static void Enable(bool on)
	{
		ResetId();
		if (on)
		{
			if (_patch == null)
			{
				_patch = Harmony.CreateAndPatchAll(typeof(TrackEntity_Patch));
				if (GameConfig.gameVersion < new Version(0, 10, 33))
				{
					_patch.PatchAll(typeof(Patch1032));
					Plugin.Log.LogInfo("TrackEntity_Patch enable (0.10.32)");
				}
				else
				{
					_patch.PatchAll(typeof(Patch1033));
					Plugin.Log.LogInfo("TrackEntity_Patch enable");
				}
			}
		}
		else
		{
			_patch?.UnpatchSelf();
			_patch = null;
			Plugin.Log.LogInfo("TrackEntity_Patch disable");
		}
	}

	public static void ResetId()
	{
		lock (contextLock)
		{
			trackedException = null;
			AstroId = 0;
			EntityId = 0;
			LocalPos = Vector3.zero;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIEntityBriefInfo), "_OnOpen")]
	private static void UIEntityBriefInfo_OnOpen(UIEntityBriefInfo __instance)
	{
		__instance.entityIdText.text = __instance.entityId.ToString();
	}

	[HarmonyFinalizer]
	[HarmonyPatch(typeof(MinerComponent), "InternalUpdate")]
	[HarmonyPatch(typeof(AssemblerComponent), "InternalUpdate")]
	[HarmonyPatch(typeof(FractionatorComponent), "InternalUpdate")]
	[HarmonyPatch(typeof(FractionatorComponent), "InternalUpdate")]
	[HarmonyPatch(typeof(EjectorComponent), "InternalUpdate")]
	[HarmonyPatch(typeof(SiloComponent), "InternalUpdate")]
	[HarmonyPatch(typeof(LabComponent), "InternalUpdateAssemble")]
	[HarmonyPatch(typeof(LabComponent), "InternalUpdateResearch")]
	[HarmonyPatch(typeof(InserterComponent), "InternalOffsetCorrection")]
	[HarmonyPatch(typeof(SpraycoaterComponent), "InternalUpdate")]
	[HarmonyPatch(typeof(TurretComponent), "InternalUpdate")]
	private static Exception GetEntityId(Exception __exception, int ___entityId)
	{
		Capture(__exception, 0, ___entityId, Vector3.zero);
		return __exception;
	}

	[HarmonyFinalizer]
	[HarmonyPatch(typeof(InserterComponent), "InternalUpdate_Bidirectional")]
	[HarmonyPatch(typeof(InserterComponent), "InternalUpdate")]
	[HarmonyPatch(typeof(InserterComponent), "InternalUpdateNoAnim")]
	[HarmonyPatch(typeof(DispenserComponent), "InternalTick")]
	private static Exception GetInserterId(Exception __exception, int ___entityId, PlanetFactory factory)
	{
		if (__exception != null)
		{
			Capture(__exception, (factory?.planet?.astroId).GetValueOrDefault(), ___entityId, Vector3.zero);
		}
		return __exception;
	}

	[HarmonyFinalizer]
	[HarmonyPatch(typeof(StationComponent), "DetermineDispatch")]
	[HarmonyPatch(typeof(StationComponent), "InternalTickLocal")]
	[HarmonyPatch(typeof(StationComponent), "InternalTickRemote")]
	private static Exception GetStationId(Exception __exception, int ___entityId, int ___planetId)
	{
		if (__exception != null)
		{
			Capture(__exception, ___planetId, ___entityId, Vector3.zero);
		}
		return __exception;
	}

	[HarmonyFinalizer]
	[HarmonyPatch(typeof(CargoPath), "PresentCargos")]
	private static Exception GetCargoPathPos(Exception __exception, Vector3[] ___pointPos)
	{
		if (__exception != null && ___pointPos != null && ___pointPos.Length != 0)
		{
			Capture(__exception, 0, 0, ___pointPos[0]);
		}
		return __exception;
	}

	[HarmonyFinalizer]
	[HarmonyPatch(typeof(CargoTraffic), "SetBeltState")]
	private static Exception SetBeltState()
	{
		return null;
	}

	[HarmonyFinalizer]
	[HarmonyPatch(typeof(CargoContainer), "RemoveCargo")]
	private static Exception RemoveCargo()
	{
		return null;
	}

	[HarmonyFinalizer]
	[HarmonyPatch(typeof(CargoTraffic), "PickupBeltItems")]
	private static Exception PickupBeltItems()
	{
		return null;
	}
}
