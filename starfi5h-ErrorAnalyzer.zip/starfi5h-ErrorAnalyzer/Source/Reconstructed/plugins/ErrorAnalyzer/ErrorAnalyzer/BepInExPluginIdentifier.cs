using System.Collections.Generic;
using System.Reflection;
using System.Text;
using BepInEx;
using BepInEx.Bootstrap;

namespace ErrorAnalyzer;

public class BepInExPluginIdentifier
{
	private readonly Dictionary<Assembly, List<PluginInfo>> pluginsByAssembly = new Dictionary<Assembly, List<PluginInfo>>();

	private readonly Dictionary<string, Assembly> assemblyByRootNamespace = new Dictionary<string, Assembly>();

	private readonly HashSet<string> duplicatedRootNamespace = new HashSet<string>();

	private readonly Dictionary<string, Assembly> assemblyByFullNamespace = new Dictionary<string, Assembly>();

	public BepInExPluginIdentifier()
	{
		foreach (PluginInfo value4 in Chainloader.PluginInfos.Values)
		{
			if (value4.Instance == null)
			{
				continue;
			}
			Assembly assembly = value4.Instance.GetType().Assembly;
			if (pluginsByAssembly.TryGetValue(assembly, out var value))
			{
				value.Add(value4);
			}
			else
			{
				pluginsByAssembly.Add(assembly, new List<PluginInfo> { value4 });
			}
			string text = value4.Instance.GetType().Namespace;
			if (string.IsNullOrEmpty(text))
			{
				continue;
			}
			string text2 = text.Split(new char[1] { '.' })[0];
			if (assemblyByFullNamespace.TryGetValue(text, out var value2))
			{
				if (!(assembly != value2))
				{
				}
			}
			else
			{
				assemblyByFullNamespace.Add(text, assembly);
			}
			if (duplicatedRootNamespace.Contains(text2))
			{
				continue;
			}
			if (assemblyByRootNamespace.TryGetValue(text2, out var value3))
			{
				if (!(value3 == assembly))
				{
					duplicatedRootNamespace.Add(text2);
					assemblyByRootNamespace.Remove(text2);
				}
			}
			else
			{
				assemblyByRootNamespace.Add(text2, assembly);
			}
		}
	}

	public Assembly GetAssembly(string fullTypeName)
	{
		if (string.IsNullOrEmpty(fullTypeName))
		{
			return null;
		}
		int num = fullTypeName.LastIndexOf('.');
		if (num > 0)
		{
			string text = fullTypeName.Substring(0, num);
			if (assemblyByFullNamespace.TryGetValue(text, out var value))
			{
				return value;
			}
			string key = text;
			int num2 = text.IndexOf('.');
			if (num2 > 0)
			{
				key = text.Substring(0, num2);
			}
			if (assemblyByRootNamespace.TryGetValue(key, out var value2))
			{
				return value2;
			}
			return null;
		}
		return null;
	}

	public List<PluginInfo> GetPluginInfoList(Assembly assembly)
	{
		if (pluginsByAssembly.TryGetValue(assembly, out var value))
		{
			return value;
		}
		return new List<PluginInfo>();
	}

	public string DumpNamespaceMap()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("assembly by root namespace:");
		foreach (KeyValuePair<string, Assembly> item in assemblyByRootNamespace)
		{
			stringBuilder.AppendLine("[" + item.Key + "] " + item.Value.GetName().Name);
		}
		if (duplicatedRootNamespace.Count > 0)
		{
			stringBuilder.AppendLine("duplicate root namespace:");
			foreach (string item2 in duplicatedRootNamespace)
			{
				stringBuilder.AppendLine(item2);
			}
		}
		stringBuilder.AppendLine();
		stringBuilder.AppendLine("assembly by full namespace:");
		foreach (KeyValuePair<string, Assembly> item3 in assemblyByFullNamespace)
		{
			stringBuilder.AppendLine("[" + item3.Key + "]: " + item3.Value.GetName().Name);
		}
		return stringBuilder.ToString();
	}
}
