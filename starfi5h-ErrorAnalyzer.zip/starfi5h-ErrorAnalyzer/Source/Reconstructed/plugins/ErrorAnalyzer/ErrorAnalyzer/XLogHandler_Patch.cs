using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace ErrorAnalyzer;

[HarmonyPatch(typeof(XLogHandler))]
internal class XLogHandler_Patch
{
	[HarmonyTranspiler]
	[HarmonyPatch("HandleLogThreaded")]
	private static IEnumerable<CodeInstruction> HandleLogThreaded_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions);
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch(OpCodes.Ldarg_0), new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Callvirt && ((MethodInfo)i.operand).Name == "get_Length"), new CodeMatch((CodeInstruction i) => i.IsLdloc()), new CodeMatch(OpCodes.Sub), new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Callvirt && ((MethodInfo)i.operand).Name == "Substring"));
			if (codeMatcher.IsValid)
			{
				codeMatcher.Advance(2).RemoveInstructions(2).Advance(1)
					.RemoveInstruction();
			}
			return codeMatcher.InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("HandleLogThreaded_Transpiler error!");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}
}
