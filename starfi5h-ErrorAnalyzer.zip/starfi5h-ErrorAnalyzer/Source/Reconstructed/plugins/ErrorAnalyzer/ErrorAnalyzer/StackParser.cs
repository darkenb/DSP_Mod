using System;
using System.Collections.Generic;
using System.Text;

namespace ErrorAnalyzer;

public static class StackParser
{
	private static readonly List<(string, string)> replaceTable = new List<(string, string)>
	{
		("System.Void ", "void "),
		("System.Boolean ", "bool "),
		("System.Byte ", "byte "),
		("System.Char ", "char "),
		("System.Decimal ", "decimal "),
		("System.Double ", "double "),
		("System.Single ", "float "),
		("System.Int32 ", "int "),
		("System.Int64 ", "long "),
		("System.Object ", "object "),
		("System.SByte ", "sbyte "),
		("System.Int16 ", "short "),
		("System.String ", "string "),
		("System.UInt32 ", "uint "),
		("System.UInt64 ", "ulong "),
		("System.UInt16 ", "ushort "),
		("System.Collections.Generic.List`1[T]", "List<T>"),
		("System.Collections.Generic.Dictionary`2[TKey,TValue]", "Dictionary<TKey, TValue>")
	};

	public static List<(string, string)> ParseStackTraceLines(string source)
	{
		List<(string, string)> list = new List<(string, string)>();
		if (string.IsNullOrEmpty(source))
		{
			return list;
		}
		string[] array = source.Split('\n', '\r');
		foreach (string text in array)
		{
			int num = text.IndexOf('(');
			if (num == -1)
			{
				continue;
			}
			int num2 = text.IndexOf(".DMD<");
			if (num2 != -1)
			{
				int num3 = text.IndexOf(':', num2);
				if (num3 != -1)
				{
					num = text.IndexOf('>', num3);
					if (num != -1)
					{
						string item = text.Substring(num2 + 5, num3 - num2 - 5);
						string item2 = text.Substring(num3 + 2, num - num3 - 2);
						list.Add((item, item2));
					}
				}
			}
			else
			{
				int num4 = text.LastIndexOf('.', num);
				if (num4 != -1 && num - num4 - 2 > 0)
				{
					string item3 = (text.StartsWith("  at ") ? text.Substring(5, num4 - 5) : text.Substring(0, num4));
					string item4 = text.Substring(num4 + 1, num - num4 - 2);
					list.Add((item3, item4));
				}
			}
		}
		return list;
	}

	public static string CleanStacktrace(string source)
	{
		if (string.IsNullOrEmpty(source))
		{
			return source;
		}
		string[] array = source.Split('\n', '\r');
		StringBuilder stringBuilder = new StringBuilder();
		StringBuilder stringBuilder2 = new StringBuilder();
		bool flag = true;
		string[] array2 = array;
		foreach (string text in array2)
		{
			if (string.IsNullOrWhiteSpace(text))
			{
				continue;
			}
			if (text.IndexOf(')') == -1)
			{
				stringBuilder2.AppendLine(text);
				if (flag)
				{
					flag = false;
					stringBuilder2.AppendLine();
				}
				continue;
			}
			stringBuilder.Clear();
			stringBuilder.Append(text);
			int num = text.LastIndexOf(" <", StringComparison.Ordinal);
			int num2 = text.LastIndexOf(">:", StringComparison.Ordinal);
			if (num != -1 && num2 > num)
			{
				stringBuilder.Remove(num, num2 - num + 2);
			}
			stringBuilder.Replace(" (at", "; (");
			stringBuilder.Replace(" inIL_", " ;IL_");
			foreach (var item in replaceTable)
			{
				stringBuilder.Replace(item.Item1, item.Item2);
			}
			stringBuilder2.AppendLine(stringBuilder.ToString());
		}
		return stringBuilder2.ToString();
	}
}
