using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Reflection;
using System.Text;
using HarmonyLib;

namespace ErrorAnalyzer;

public class HarmonyPatcherMapper
{
	private readonly Dictionary<string, List<MethodBase>> patchesByTargetType = new Dictionary<string, List<MethodBase>>();

	public HarmonyPatcherMapper()
	{
		foreach (MethodBase allPatchedMethod in PatchProcessor.GetAllPatchedMethods())
		{
			string fullName = allPatchedMethod.DeclaringType.FullName;
			if (!patchesByTargetType.TryGetValue(fullName, out var value))
			{
				value = new List<MethodBase>();
				patchesByTargetType[fullName] = value;
			}
			value.Add(allPatchedMethod);
		}
	}

	public bool IsTargetType(string typeName)
	{
		return patchesByTargetType.ContainsKey(typeName);
	}

	public MethodBase GetModMethod(string typeName, string methodName)
	{
		if (patchesByTargetType.TryGetValue(typeName, out var value))
		{
			foreach (MethodBase item in value)
			{
				if (item.Name == methodName)
				{
					return item;
				}
			}
		}
		return null;
	}

	public HashSet<Assembly> GetModAssembliesFromMethod(MethodBase targetMethod)
	{
		Patches patchInfo = Harmony.GetPatchInfo(targetMethod);
		if (patchInfo == null)
		{
			return new HashSet<Assembly>();
		}
		HashSet<Assembly> hashSet = new HashSet<Assembly>();
		foreach (Patch prefix in patchInfo.Prefixes)
		{
			hashSet.Add(prefix.PatchMethod.DeclaringType.Assembly);
		}
		foreach (Patch postfix in patchInfo.Postfixes)
		{
			hashSet.Add(postfix.PatchMethod.DeclaringType.Assembly);
		}
		foreach (Patch transpiler in patchInfo.Transpilers)
		{
			hashSet.Add(transpiler.PatchMethod.DeclaringType.Assembly);
		}
		return hashSet;
	}

	public HashSet<Assembly> GetModAssembliesFromType(string targetTypeName)
	{
		HashSet<Assembly> hashSet = new HashSet<Assembly>();
		if (!patchesByTargetType.TryGetValue(targetTypeName, out var value))
		{
			return hashSet;
		}
		foreach (MethodBase item in value)
		{
			hashSet.UnionWith(GetModAssembliesFromMethod(item));
		}
		return hashSet;
	}

	public string GetPatchesDescription(MethodBase targetMethod)
	{
		Patches patchInfo = PatchProcessor.GetPatchInfo(targetMethod);
		if (patchInfo == null)
		{
			return "";
		}
		StringBuilder stringBuilder = new StringBuilder();
		PatchesToString(stringBuilder, patchInfo.Prefixes, "; " + targetMethod.DeclaringType.Name + "." + targetMethod.Name + "(Prefix)");
		PatchesToString(stringBuilder, patchInfo.Postfixes, "; " + targetMethod.DeclaringType.Name + "." + targetMethod.Name + "(Postfix)");
		PatchesToString(stringBuilder, patchInfo.Transpilers, "; " + targetMethod.DeclaringType.Name + "." + targetMethod.Name + "(Transpiler)");
		return stringBuilder.ToString();
	}

	public string DumpPatchMap()
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.Append("DumpPatchMap type count: ").Append(patchesByTargetType.Keys.Count).AppendLine();
		foreach (KeyValuePair<string, List<MethodBase>> item in patchesByTargetType)
		{
			stringBuilder.Append("\n[Type: ").Append(item.Key).AppendLine("]");
			foreach (MethodBase item2 in item.Value)
			{
				stringBuilder.Append("-- ").Append(item.Key).Append(".")
					.Append(item2.Name)
					.AppendLine(" --");
				Patches patchInfo = PatchProcessor.GetPatchInfo(item2);
				PatchesToString(stringBuilder, patchInfo.Prefixes, "; (Prefix)");
				PatchesToString(stringBuilder, patchInfo.Postfixes, "; (Postfix)");
				PatchesToString(stringBuilder, patchInfo.Transpilers, "; (Transpiler)");
			}
		}
		return stringBuilder.ToString();
	}

	private void PatchesToString(StringBuilder sb, ReadOnlyCollection<Patch> patches, string textPostfix)
	{
		foreach (Patch patch in patches)
		{
			sb.Append(patch.PatchMethod.FullDescription().Replace("System.Collections.Generic.IEnumerable<HarmonyLib.CodeInstruction>", "var").Replace("System.Reflection.Emit.ILGenerator", "var"));
			sb.Replace("static ", "");
			sb.AppendLine(textPostfix);
		}
	}
}
