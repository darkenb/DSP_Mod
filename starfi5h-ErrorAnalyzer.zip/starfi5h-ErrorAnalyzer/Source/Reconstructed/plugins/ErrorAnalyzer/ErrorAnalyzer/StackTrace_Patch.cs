using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace ErrorAnalyzer;

[HarmonyPatch(typeof(StackTrace))]
internal class StackTrace_Patch
{
	[HarmonyTranspiler]
	[HarmonyPatch("AddFrames")]
	private static IEnumerable<CodeInstruction> AddFrames_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions);
			codeMatcher.MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Callvirt && ((MethodInfo)i.operand).Name == "GetInternalMethodName"));
			if (codeMatcher.IsValid)
			{
				CodeInstruction codeInstruction = codeMatcher.InstructionAt(-1);
				codeMatcher.Advance(1).Insert(codeInstruction, new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(StackTrace_Patch), "AppendLineOrIL")));
			}
			codeMatcher.MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Callvirt && ((MethodInfo)i.operand).Name == "GetFileLineNumber"), new CodeMatch(OpCodes.Box));
			if (codeMatcher.IsValid)
			{
				CodeInstruction codeInstruction2 = codeMatcher.InstructionAt(-1);
				codeMatcher.Advance(2).Insert(new CodeInstruction(OpCodes.Pop), codeInstruction2, new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(StackTrace_Patch), "GetLineOrIL")));
			}
			return codeMatcher.InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("AddFrames_Transpiler error!");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	private static string AppendLineOrIL(string currentText, StackFrame stackFrame)
	{
		return currentText + " (at " + GetLineOrIL(stackFrame) + ")";
	}

	private static string GetLineOrIL(StackFrame stackFrame)
	{
		int fileLineNumber = stackFrame.GetFileLineNumber();
		if (fileLineNumber == -1 || fileLineNumber == 0)
		{
			return "IL_" + stackFrame.GetILOffset().ToString("X4");
		}
		return fileLineNumber.ToString();
	}
}
