using System;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;

namespace ErrorAnalyzer;

[BepInPlugin("aaa.dsp.plugin.ErrorAnalyzer", "ErrorAnalyzer", "1.3.4")]
public class Plugin : BaseUnityPlugin
{
	public const string GUID = "aaa.dsp.plugin.ErrorAnalyzer";

	public const string NAME = "ErrorAnalyzer";

	public const string VERSION = "1.3.4";

	public static ManualLogSource Log;

	public static bool isRegistered;

	public static string errorString;

	public static string errorStackTrace;

	private static Harmony harmony;

	private static bool init;

	public static ConfigEntry<bool> ShowFullStack { get; private set; }

	public void Awake()
	{
		Log = base.Logger;
		harmony = new Harmony("aaa.dsp.plugin.ErrorAnalyzer");
		bool value = base.Config.Bind("DEBUG Mode", "Enable", defaultValue: false, "Enable DEBUG mode to track the entity when starting up the game").Value;
		ShowFullStack = base.Config.Bind("Message", "Show All Patches", defaultValue: false, "Show all mod patches on the stack trace (By default it will not list GameData.Gametick() and below methods)");
		bool value2 = base.Config.Bind("Message", "Dump All Patches", defaultValue: false, "Dump Harmony patches of all mods when the game load in BepInEx\\LogOutput.log").Value;
		try
		{
			harmony.PatchAll(typeof(UIFatalErrorTip_Patch));
			Application.logMessageReceived += HandleLog;
			isRegistered = true;
		}
		catch (Exception data)
		{
			Log.LogError("Error when patching UIFatalErrorTip_Patch");
			Log.LogError(data);
		}
		try
		{
			harmony.PatchAll(typeof(UIErrorEnhancer));
		}
		catch (Exception data2)
		{
			Log.LogError("Error when patching StacktraceParser");
			Log.LogError(data2);
		}
		if (value)
		{
			try
			{
				TrackEntity_Patch.Enable(on: true);
			}
			catch (Exception data3)
			{
				Log.LogError("Error when patching TrackEntity_Patch");
				Log.LogError(data3);
			}
		}
		if (value2)
		{
			harmony.PatchAll(typeof(Plugin));
		}
		harmony.PatchAll(typeof(StackTrace_Patch));
		try
		{
			harmony.PatchAll(typeof(XLogHandler_Patch));
		}
		catch (Exception data4)
		{
			Log.LogWarning("Error when patching XLogHandler_Patch");
			Log.LogWarning(data4);
		}
	}

	[HarmonyPostfix]
	[HarmonyPriority(0)]
	[HarmonyPatch(typeof(GameMain), "Begin")]
	private static void OnBegin()
	{
		if (!init)
		{
			init = true;
			HarmonyPatcherMapper harmonyPatcherMapper = new HarmonyPatcherMapper();
			Log.LogInfo(harmonyPatcherMapper.DumpPatchMap());
		}
	}

	public static void HandleLog(string logString, string stackTrace, LogType type)
	{
		if (string.IsNullOrEmpty(errorString) && logString.IndexOf("Exception") > 0)
		{
			errorString = logString;
			errorStackTrace = stackTrace;
			Log.LogDebug("Exception Record");
		}
	}
}
