using System;
using System.Threading;
using HarmonyLib;
using UnityEngine;

static class Check
{
    static int Main()
    {
        var type = typeof(ErrorAnalyzer.Plugin).Assembly.GetType("ErrorAnalyzer.TrackEntity_Patch");
        var capture = AccessTools.Method(type, "Capture");
        var reset = AccessTools.Method(type, "ResetId");
        var first = new Exception("factory A");
        var second = new Exception("factory B");
        capture.Invoke(null, new object[] {first, 0, 73, Vector3.zero});
        Exception workerFailure = null;
        var worker = new Thread(() => {try { capture.Invoke(null, new object[] {second, 202, 98, Vector3.zero}); } catch (Exception e) {workerFailure = e;} });
        worker.Start(); worker.Join();
        if (workerFailure != null) throw workerFailure;
        capture.Invoke(null, new object[] {first, 101, 0, Vector3.zero});
        if ((int)AccessTools.Property(type, "AstroId").GetValue(null, null) != 101 || (int)AccessTools.Property(type, "EntityId").GetValue(null, null) != 73)
            throw new Exception("Worker contexts mixed");
        var result = AccessTools.Method(type, "GetStationId").Invoke(null, new object[] {first, 73, 101});
        if (!ReferenceEquals(result, first)) throw new Exception("Original exception replaced");
        reset.Invoke(null, null);
        capture.Invoke(null, new object[] {second, 202, 98, Vector3.zero});
        if ((int)AccessTools.Property(type, "AstroId").GetValue(null, null) != 202) throw new Exception("Reset retained old exception");
        Console.WriteLine("PASS two worker exceptions remain separate, outer finalizer completes same exception, original error and reset preserved");
        return 0;
    }
}
