param([string]$Built, [string]$Core, [string]$PhaseRoot)
$ErrorActionPreference = 'Stop'
$assembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Built)
try {
    $type = $assembly.MainModule.Types | Where-Object FullName -eq 'ErrorAnalyzer.TrackEntity_Patch'
    $enable = $type.Methods | Where-Object Name -eq 'Enable'
    $il = @($enable.Body.Instructions)
    $compare = @($il | Where-Object { $_.OpCode.Code -eq 'Call' -and $_.Operand.Name -eq 'op_LessThan' })
    if ($compare.Count -ne 1) { throw 'Version comparison changed' }
    $index = [Array]::IndexOf($il, $compare[0])
    if ($il[$index-4].OpCode.Code -ne 'Ldc_I4_0' -or $il[$index-3].Operand -ne 10 -or $il[$index-2].Operand -ne 33 -or $il[$index-1].Operand.DeclaringType.FullName -ne 'Version') { throw 'Legacy version threshold changed' }
    $branch = $il[$index+1]
    if ($branch.OpCode.Code -notin @('Brfalse','Brfalse_S')) { throw 'Legacy branch changed' }
    $oldToken = @($il | Where-Object { $_.OpCode.Code -eq 'Ldtoken' -and $_.Operand.FullName -eq 'ErrorAnalyzer.TrackEntity_Patch/Patch1032' })
    $newToken = @($il | Where-Object { $_.OpCode.Code -eq 'Ldtoken' -and $_.Operand.FullName -eq 'ErrorAnalyzer.TrackEntity_Patch/Patch1033' })
    if ($oldToken.Count -ne 1 -or $newToken.Count -ne 1 -or $oldToken[0].Offset -le $branch.Offset -or $oldToken[0].Offset -ge $branch.Operand.Offset -or $newToken[0].Offset -lt $branch.Operand.Offset) { throw 'Conditional PatchAll selection changed' }
    $oldIndex = [Array]::IndexOf($il,$oldToken[0])
    $newIndex = [Array]::IndexOf($il,$newToken[0])
    if ($il[$oldIndex+2].Operand.Name -ne 'PatchAll' -or $il[$newIndex+2].Operand.Name -ne 'PatchAll') { throw 'Patch registration changed' }
    foreach ($other in $type.Methods | Where-Object Name -ne 'Enable') {
        if ($other.HasBody -and @($other.Body.Instructions | Where-Object { $_.OpCode.Code -eq 'Ldtoken' -and $_.Operand.FullName -eq 'ErrorAnalyzer.TrackEntity_Patch/Patch1032' }).Count) { throw 'Additional legacy registration found' }
    }
    [ordered]@{
        reason = 'Patch1032 is registered only for GameConfig.gameVersion < 0.10.33; current game 0.10.35.29104 selects Patch1033.'
        caller = 'System.Exception ErrorAnalyzer.TrackEntity_Patch/Patch1032::GetFactoryId(System.Exception,PlanetFactory)'
        members = @('FactorySystem::GameTick(System.Int64,System.Boolean,System.Int32,System.Int32,System.Int32)', 'FactorySystem::GameTickLabProduceMode(System.Int64,System.Boolean,System.Int32,System.Int32,System.Int32)', 'FactorySystem::GameTickInserters(System.Int64,System.Boolean,System.Int32,System.Int32)', 'CargoTraffic::PresentCargoPathsAsync')
        registration_il = @($il | ForEach-Object ToString)
        passed = $true
    } | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $PhaseRoot 'inactive-patches.json') -Encoding UTF8
    Write-Output 'PASS legacy patch targets retained; IL verifies 0.10.33 conditional registration'
} finally { $assembly.Dispose() }
