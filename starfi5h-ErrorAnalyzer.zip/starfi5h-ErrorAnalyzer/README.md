# starfi5h-ErrorAnalyzer

Keep planet/entity/location tied to the same first exception and publish a consistent short-lock snapshot.

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.

[Review map](REVIEW_GUIDE.md) · [Related mods and code references](RELATED_MODS.md) · [Detailed changes](CHANGELOG.md) · [Build/review notes](BUILD.md) · [Assembly metadata](metadata.json)

Prepared for maintainer review on 15 October 2026. This is a local modified build, not an official upstream release, published package or pull request.

Installed plugin version(s): **1.3.4**. Existing package manifest version: **1.3.3**. Manifest, plugin and assembly versions are separate; the original manifest is retained.

## Package layout

- `InstalledPackage/`: actual installed mod files and companion preloader when present.
- `Source/Reconstructed/`: full projects reconstructed from the exact installed assemblies.
- `Source/EarlierWorkingSource/`, `PortedWorkingSource/`, `UpstreamSnapshot/`: source snapshots when available; provenance is recorded separately.
- `Evidence/`: development helpers, focused check sources and structured validation/installation records.
- `Diffs/`: source-port patches and normalized structural IL comparison.
- `Baselines/`: previous binary and its provenance for review, not an automatic rollback.

## Plugin identifiers and declared dependencies

- `aaa.dsp.plugin.ErrorAnalyzer` — ErrorAnalyzer 1.3.4; dependencies: none declared on this plugin.

## Installed assembly hashes

| Recorded path | SHA-256 |
|---|---|
| `plugins/starfi5h-ErrorAnalyzer/ErrorAnalyzer.dll` | `401b9af2ece9ea76d6fbf16f2c953c7fc4ecf39ab2b0486283c70dca0a29b8e7` |

## Scope and limitations

Not every source project has been rebuilt. Historical compile/test evidence is limited to its recorded hashes. Headless/embedded-Mono checks do not establish real Unity UI, the user's world, all-mod startup, multiplayer or sustained-memory acceptance.

## Independent review package

Send this entire directory, with all subdirectories, to this mod's maintainer. No sibling maintainer directory or parent-level report is required for code review. There are **1** related-mod reference copies under `RelatedMods/`. Read `RELATED_MODS.md` for direct dependencies, concrete compiled member calls, shared native integration points and source snippets. Required installed dependencies of a copy are flattened into this directory; no recursive RelatedMods trees are produced.

Uninstalled optional declarations are listed explicitly; no nonexistent mod is claimed to be included. The actual game/Unity/BepInEx SDK remains an external build prerequisite. Historical test/build scripts may need path adaptation; this is a complete review package, not a guaranteed one-command clean rebuild. See `STANDALONE_VERIFICATION.json` and `PACKAGE_SHA256SUMS.txt` for the local package check.
