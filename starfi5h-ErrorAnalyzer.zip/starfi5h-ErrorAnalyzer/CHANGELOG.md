# starfi5h-ErrorAnalyzer — detailed change report

Installed plugin version(s): **1.3.4**. Keep planet/entity/location tied to the same first exception and publish a consistent short-lock snapshot.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Consistent exception context — 1.3.4

Use source matching installed 1.3.3. Preserve existing GameLogic stack recognition, XLogHandler and version-based Patch1032/Patch1033 selection.

- Keep planet/entity/location attached to the same first tracked exception. Another worker's exception cannot mix its context into that record. An outer factory finalizer for the same exception may fill missing planet information.
- Hold a short lock only while capturing an error. Read all three UI fields from one snapshot; clear both the exception reference and context on reset/close.
- Avoid a second diagnostic exception on an empty cargo-point array.
- Continue returning the original exception from finalizers. Four legacy-version targets remain in their compatibility branch but are inactive on the current game.

Independent checks cover interleaved worker exceptions, inner/outer finalizers for one exception and reset. They do not establish that the actual error panel opens correctly or that all workers are accepted in game. No unrelated vegetation, blueprint or statistics feature was changed.

## Recorded source commits

- `3d77a1ebff3ed4d0b7c29aba4e1b9a6b61f7bea1`

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
