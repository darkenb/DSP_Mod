using System;
using HarmonyLib;
using closeError;

static class Check
{
    static int Main()
    {
        var type = typeof(CloseError);
        var flag = AccessTools.Field(type, "isError");
        AccessTools.Method(type, "errorFalse").Invoke(null, new object[] {null});
        if (!(bool)flag.GetValue(null)) throw new Exception("Open failed to enable X");
        AccessTools.Method(type, "Closed").Invoke(null, null);
        if ((bool)flag.GetValue(null)) throw new Exception("External close retained X");
        AccessTools.Method(type, "errorFalse").Invoke(null, new object[] {null});
        if (!(bool)flag.GetValue(null)) throw new Exception("New error cannot be closed");
        Console.WriteLine("PASS error opens, external close clears button and later error reopens; game exceptions are not suppressed");
        return 0;
    }
}
