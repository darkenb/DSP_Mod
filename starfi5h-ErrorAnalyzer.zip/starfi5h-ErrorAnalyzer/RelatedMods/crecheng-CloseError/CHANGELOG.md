# crecheng-CloseError — detailed change report

Installed plugin version(s): **1.0.1**. Reset the close-button state when the error panel closes and derive position from the current resolution.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Error-panel close-button lifecycle — 1.0.1

Use installed 1.0.0 behavior. Its manifest had no source URL; a historical API response in the evidence recorded upstream 1.0.0 dated 20 February 2021. This is a statement about that recorded response, not a new online version check. Retain plugin GUID, assembly identity and public Start/OnGUI contracts.

- Clear the corner-X state when ErrorAnalyzer or another path closes the panel; show it again on a later error.
- Derive X position from the current screen width on each draw so resolution changes do not leave an old position.
- Remove unused native GUIStyle creation and clean up owned Harmony patches on shutdown.
- Close only the current panel. Do not suppress new errors/exceptions or change Windows settings. The historical test executable uses the shared TestHost fix for console-window behavior.

Independent checks cover close/reopen and a later error. Actual in-game error UI, ErrorAnalyzer copy/inspect buttons and log preservation remain live acceptance work.

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
