using BepInEx;
using HarmonyLib;
using UnityEngine;

[assembly: System.Reflection.AssemblyVersion("1.0.0.0")]

namespace closeError
{
    [BepInPlugin("crecheng.CloseError", "CloseError", "1.0.1")]
    public class CloseError : BaseUnityPlugin
    {
        private static Rect rect = new Rect(0, 10, 20, 20);
        private static bool isError;
        private Harmony harmony;

        public void Start()
        {
            harmony = Harmony.CreateAndPatchAll(typeof(CloseError), "crecheng.CloseError");
        }

        public void OnGUI()
        {
            if (!isError) return;
            rect.x = Mathf.Max(0, Screen.width - 35);
            if (GUI.Button(rect, "X"))
            {
                UIFatalErrorTip.instance?._Close();
                isError = false;
            }
        }

        [HarmonyPostfix, HarmonyPatch(typeof(UIFatalErrorTip), "_OnOpen")]
        private static void errorFalse(UIFatalErrorTip __instance) {isError = true;}

        [HarmonyPostfix, HarmonyPatch(typeof(UIFatalErrorTip), "_OnClose")]
        private static void Closed() {isError = false;}

        private void OnDestroy()
        {
            harmony?.UnpatchSelf();
            isError = false;
        }
    }
}
