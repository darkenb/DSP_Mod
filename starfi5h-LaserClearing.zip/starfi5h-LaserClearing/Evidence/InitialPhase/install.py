"""Install the already-built, regression-checked DLL using ordinary file operations only."""
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import os
import subprocess
import tempfile
import zipfile

PHASE = Path(__file__).resolve().parent
PLUGINS = PHASE.parent.parent.parent.resolve()
GAME = Path('D:/Games/Dyson Sphere Program/DSPGAME_Data/Managed/Assembly-CSharp.dll')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))

def write(path, data):
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')

def game_closed():
    command = "if (@(Get-Process -Name DSPGAME -ErrorAction SilentlyContinue).Count -gt 0) { exit 1 }"
    result = subprocess.run(['powershell.exe', '-NoProfile', '-Command', command],
        capture_output=True, text=True, errors='replace', timeout=15, creationflags=subprocess.CREATE_NO_WINDOW)
    assert result.returncode == 0, 'Game is running or process check failed'

result = read(PHASE / 'build-result.json')
assert result['version'] == '1.0.10' and result['checks_passed'] and result['api_findings'] == 0
target = (PLUGINS / result['original_relative_path']).resolve(strict=True)
assert target.is_relative_to(PLUGINS) and target == PLUGINS / 'starfi5h-LaserClearing/LaserClearing.dll'
built = Path(result['loose_output']).resolve(strict=True)
assert built.is_relative_to(Path(tempfile.gettempdir()).resolve()), 'Build output must stay outside plugins'
assert digest(target) == result['original_sha256'] and digest(built) == result['output_sha256']
assert digest(GAME) == result['game_sha256']
for group in ('source_sha256', 'validation_source_sha256', 'embedded_resource_sha256'):
    for name, expected in result[group].items():
        assert digest(PHASE / name) == expected, 'Changed input: ' + name
mono = read(PHASE / 'audit-20261007/mono-check.json')
assert mono['passed'] and mono['dll_sha256'] == result['output_sha256']
assert read(PHASE / 'validation.json')['passed']
package = PHASE / (result['folder'] + '-' + result['version'] + '.zip')
assert digest(package) == package.with_suffix('.zip.sha256').read_text().split()[0]
with zipfile.ZipFile(package) as archive:
    assert archive.testzip() is None
    payload = archive.read('plugins/' + result['folder'] + '/' + built.name)
    assert hashlib.sha256(payload).hexdigest() == result['output_sha256']
baseline = read(PHASE / 'audit-20261007/baseline.json')
metadata = read(PHASE / 'audit-20261007/assembly-metadata.json')
assert metadata['built_sha256'] == result['output_sha256'] and metadata['original_sha256'] == result['original_sha256']
assert metadata['original_mvid'] != metadata['built_mvid']
def verify_protected_files():
    for name, expected in baseline['saves'].items():
        assert digest(Path(name)) == expected, 'Save changed: ' + name
    for name, expected in baseline['configs'].items():
        assert digest(PLUGINS.parent / 'config' / name) == expected, 'Config changed: ' + name
verify_protected_files()
game_closed()
before = {str(path.relative_to(PLUGINS)): digest(path) for path in PLUGINS.rglob('*.dll')}
assert before == baseline['plugin_dlls'], 'Plugin baseline changed before install'
assert not list((PLUGINS / '_calisma').rglob('*.dll')), 'Loose build DLL under plugin work directory'
folder = PHASE / ('backup-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
folder.mkdir()
backup = folder / 'previous-plugin-dll.zip'
entry = target.relative_to(PLUGINS).as_posix()
with zipfile.ZipFile(backup, 'w', zipfile.ZIP_DEFLATED) as archive:
    archive.write(target, entry)
with zipfile.ZipFile(backup) as archive:
    assert archive.testzip() is None
    original = archive.read(entry)
    assert hashlib.sha256(original).hexdigest() == result['original_sha256']
record = dict(status='backup_verified', date_utc=datetime.now(timezone.utc).isoformat(),
    version=result['version'], previous_version='1.0.9', target=str(target),
    original_relative_path=entry, previous_sha256=result['original_sha256'], output_sha256=result['output_sha256'],
    package=str(package), package_sha256=digest(package), backup=str(backup), backup_sha256=digest(backup),
    api_references=result['api_reference_count'], harmony_patches=result['harmony_patch_count'],
    embedded_mono_check_passed=True, kaspersky_detected=None, kaspersky_suspicions=None, antivirus_scan_performed=False,
    runtime_tested=False, game_sha256=result['game_sha256'], previous_mvid=metadata['original_mvid'], output_mvid=metadata['built_mvid'])
journal = folder / 'installation.json'
write(journal, record)
game_closed()
assert digest(target) == result['original_sha256'], 'Target changed before install'
temporary = target.with_suffix('.dll.installing')
assert not temporary.exists(), 'Unexpected pending install file'
try:
    temporary.write_bytes(payload)
    assert digest(temporary) == result['output_sha256']
    os.replace(temporary, target)
    assert digest(target) == result['output_sha256']
    after = {str(path.relative_to(PLUGINS)): digest(path) for path in PLUGINS.rglob('*.dll')}
    expected = dict(before)
    expected[str(target.relative_to(PLUGINS))] = result['output_sha256']
    assert after == expected, 'Unexpected plugin DLL changes'
    assert digest(GAME) == result['game_sha256'], 'Game assembly changed'
    verify_protected_files()
except BaseException:
    temporary.write_bytes(original)
    os.replace(temporary, target)
    record['status'] = 'rolled_back_after_error'
    write(journal, record)
    raise
record.update(status='installed_and_hash_verified', unrelated_plugin_dlls_unchanged=True,
    game_assembly_unchanged=True, saves_unchanged=True, configs_unchanged=True, saved_file_count=len(baseline['saves']), config_file_count=len(baseline['configs']), scanned_plugin_dll_count=len(after))
write(journal, record)
write(PHASE / 'installation.json', record)
print('PASS LaserClearing 1.0.10 installed; SHA-256 readback and unrelated DLL/game integrity passed')
print('BACKUP', backup)
print('PACKAGE', package)
