using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using HarmonyLib;
using LaserClearing;
using UnityEngine;

static class Check
{
    static T Empty<T>() => (T)FormatterServices.GetUninitializedObject(typeof(T));
    static void Assert(bool ok, string text) { if (!ok) throw new Exception(text); Console.WriteLine("PASS " + text); }
    static int failures;
    static void Run(string name, Action check)
    {
        try { check(); Console.WriteLine("PASS " + name); }
        catch (Exception error) { failures++; Console.WriteLine("FAIL " + name + ": " + (error.InnerException ?? error).Message); }
    }
    static int Main()
    {
        var type = typeof(LocalLaser_Patch);
        var factory = Empty<PlanetFactory>();
        AccessTools.Property(typeof(PlanetFactory), "planet").SetValue(factory, new PlanetData {id = 101}, null);
        var skills = Empty<SkillSystem>();
        skills.localLaserContinuous = Empty<DataPoolRenderer<LocalLaserContinuous>>();
        skills.localLaserContinuous.buffer = new LocalLaserContinuous[4];
        skills.localLaserContinuous.cursor = 3;
        for (int i = 1; i <= 2; i++)
        {
            ref var laser = ref skills.localLaserContinuous.buffer[i];
            laser.id = i; laser.astroId = 101; laser.fade = 1;
            laser.target.type = ETargetType.Vegetable; laser.target.id = i;
        }
        AccessTools.Field(type, "ownerFactory").SetValue(null, factory);
        AccessTools.Field(type, "ownerSkillSystem").SetValue(null, skills);
        var ids = (List<int>)AccessTools.Field(type, "laserIds").GetValue(null);
        var targets = (Dictionary<int,int>)AccessTools.Field(type, "laserTargets").GetValue(null);
        ids.Add(1); targets.Add(1, 1);
        LocalLaser_Patch.ClearAll();
        Assert(skills.localLaserContinuous.buffer[1].fade == -1 && skills.localLaserContinuous.buffer[2].fade == 1, "native Stop affects only the owned laser");
        Assert(ids.Count == 0 && targets.Count == 0 && AccessTools.Field(type, "ownerFactory").GetValue(null) == null, "world transition clears ownership");
        Assert(LocalLaser_Patch.KillVegeFinally_Prefix(factory, 1), "unowned vegetation uses native destruction");
        var collection = new VegetableCollection();
        collection.AddVegeToPlayer(150); collection.AddVegeToPlayer(150);
        Assert(collection.playerVegeDict[150] == 2, "native vegetation collection retains repeated specimens");

        // Tiny spatial bucket; native hash lookup and native prototype selection still execute.
        var center = new Vector3(-270, -270, -270);
        AccessTools.Property(typeof(HashSystem), "cellSize").SetValue(null, 1f, null);
        var cellType = typeof(HashSystem).GetNestedType("Cell");
        var map = Array.CreateInstance(cellType, 32);
        var cell = Activator.CreateInstance(cellType);
        AccessTools.Field(cellType, "dist").SetValue(cell, (short)1);
        map.SetValue(cell, 1);
        AccessTools.Field(typeof(HashSystem), "bucketMap").SetValue(null, map);
        factory.hashSystemStatic = Empty<HashSystem>();
        factory.hashSystemStatic.hashPool = new[] { (1 << 28) | 1 };
        factory.hashSystemStatic.bucketOffsets = new[] { 0, 1 };
        factory.hashSystemStatic.bucketCursors = new[] { 1 };
        factory.hashSystemStatic.activeBuckets = new int[32];
        factory.vegePool = new VegeData[2];
        factory.vegePool[1] = new VegeData { id = 1, protoId = 150, pos = center };
        var protos = Empty<VegeProtoSet>();
        AccessTools.Field(typeof(UnityEngine.Object), "m_CachedPtr").SetValue(protos, new IntPtr(1));
        protos.dataArray = new[] {
            new VegeProto { ID = 150, MiningItem = new[] { 1001 } },
            new VegeProto { ID = 151, MiningItem = new int[0] },
            new VegeProto { ID = 9999, MiningItem = new[] { 1001 } }
        };
        AccessTools.Field(typeof(ProtoSet<VegeProto>), "dataIndices").SetValue(protos, new Dictionary<int,int> { {150,0}, {151,1}, {9999,2} });
        AccessTools.Field(typeof(LDB), "_veges").SetValue(null, protos);
        var closest = AccessTools.Method(type, "GetClosestVegeId");
        Func<int> select = () => (int)closest.Invoke(null, new object[] {factory, center, 0.5f});
        LocalLaser_Patch.DropOnly = true; LocalLaser_Patch.SpaceCapsule = false;
        Assert(select() == 1, "eligible vegetation selected");
        Run("reused slot obeys DropOnly", () => {
            factory.vegePool[1].protoId = 151; Assert(select() == 0, "no-drop replacement excluded");
        });
        Run("reused slot obeys capsule exclusion", () => {
            factory.vegePool[1].protoId = 9999; Assert(select() == 0, "capsule replacement excluded");
        });
        Run("removed vegetation is never selected", () => {
            factory.vegePool[1].id = 0; Assert(select() == 0, "empty slot excluded");
        });
        LocalLaser_Patch.ClearAll();
        factory.vegePool[1].id = 1; factory.vegePool[1].protoId = 151;
        Assert(select() == 0, "initial no-drop vegetation excluded");
        Run("excluded slot can become eligible", () => {
            factory.vegePool[1].protoId = 150; Assert(select() == 1, "eligible replacement selected");
        });
        Run("stale hash address is ignored", () => {
            factory.hashSystemStatic.hashPool[0] = (1 << 28) | 99;
            Assert(select() == 0, "out-of-pool hash address excluded");
            Assert(factory.hashSystemStatic.activeBucketsCount == 0, "hash buckets cleared");
        });
        factory.hashSystemStatic.hashPool[0] = (1 << 28) | 1;
        targets[1] = 1;
        Run("existing target is not selected twice", () => Assert(select() == 0, "owned target excluded"));
        LocalLaser_Patch.ClearAll();
        Run("status update before UI creation is safe", () => {
            UI_Patch.UpdateButtonStatus(UI_Patch.ButtonStatus.Normal);
            Assert((UI_Patch.ButtonStatus)AccessTools.Field(typeof(UI_Patch), "buttonStatus").GetValue(null) == UI_Patch.ButtonStatus.None, "absent UI does not cache a rendered status");
        });

        var player = Empty<Player>();
        AccessTools.Property(typeof(Player), "planetData").SetValue(player, factory.planet, null);
        factory.planet.factory = factory; factory.planet.factoryLoaded = true;
        AccessTools.Property(typeof(Player), "mecha").SetValue(player, Empty<Mecha>(), null);
        player.mecha.energyChanges = new double[10];
        AccessTools.Property(typeof(Player), "package").SetValue(player, Empty<StorageComponent>(), null);
        player.package.size = 1;
        player.package.grids = new StorageComponent.GRID[1]; player.package.grids[0].count = 1;
        GameMain.data = Empty<GameData>();
        AccessTools.Property(typeof(GameData), "mainPlayer").SetValue(GameMain.data, player, null);
        var mine = Empty<PlayerAction_Mine>(); mine.player = player;
        SkillSystem.RoughHeightByModelIndex = new float[1];
        LocalLaser_Patch.Enable = true; LocalLaser_Patch.EnableLoot = true; LocalLaser_Patch.RequiredSpace = 1;
        AccessTools.Field(type, "maxLaserCount").SetValue(null, 1);
        AccessTools.Field(type, "ownerFactory").SetValue(null, factory);
        AccessTools.Field(type, "ownerSkillSystem").SetValue(null, skills);
        ids.Add(1); targets[1] = 1; skills.localLaserContinuous.buffer[1].fade = 1;
        Run("full inventory stops owned lasers immediately", () => {
            AccessTools.Method(type, "GameTick").Invoke(null, new object[] { mine });
            Assert(ids.Count == 0 && targets.Count == 0 && skills.localLaserContinuous.buffer[1].fade == -1, "full inventory clears owned laser");
            Assert(skills.localLaserContinuous.buffer[2].fade == 1, "full inventory preserves other lasers");
        });
        LocalLaser_Patch.ClearAll();
        AccessTools.Field(type, "ownerFactory").SetValue(null, factory);
        AccessTools.Field(type, "ownerSkillSystem").SetValue(null, skills);
        ids.Add(1); targets[1] = 1;
        LocalLaser_Patch.MiningPower = 100;
        var continuation = AccessTools.Method(type, "ContinueLaser");
        foreach (double available in new[] { 0.0, 50.0, 200.0 })
        {
            double energy = available;
            Run("laser power with energy " + energy, () => {
                player.mecha.coreEnergy = energy; player.mecha.energyChanges[5] = 0;
                Assert((bool)continuation.Invoke(null, new object[] { factory, 1, center, player.mecha, 0 }), "owned laser continues");
                double consumed = Math.Min(energy, 100);
                Assert(Math.Abs(skills.localLaserContinuous.buffer[1].damageScale - consumed / 100) < 0.00001, "native damage scale follows supplied energy");
                Assert(player.mecha.coreEnergy == energy - consumed && player.mecha.energyChanges[5] == -consumed, "native energy consumption and accounting preserved");
                Assert(skills.localLaserContinuous.buffer[2].damageScale == 0, "other laser power unchanged");
            });
        }
        LocalLaser_Patch.ClearAll();
        Console.WriteLine("FAILED CHECKS " + failures);
        return failures == 0 ? 0 : 1;
    }
}
