"""Re-run the single regression check against the installed DLL, without launching DSP."""
from pathlib import Path
import importlib.util
import shutil
import subprocess
import sys

PHASE = Path(__file__).resolve().parent.parent
ROOT = PHASE.parent
spec = importlib.util.spec_from_file_location('phase_build', ROOT / 'build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
output = build.OUTPUT / 'LaserClearingAudit20261007' / 'installed'
output.mkdir(parents=True, exist_ok=True)
target = output / 'LaserClearing.dll'
shutil.copyfile(build.PLUGINS / 'starfi5h-LaserClearing/LaserClearing.dll', target)
check = output / 'Check.exe'
build.compile_cs([PHASE / 'check.cs'], check, build.references() + [target], executable=True)
result = build.run_check(check, [build.GAME, build.CORE])
(PHASE / 'audit-20261007/installed-clr-check.log').write_text(result.stdout + result.stderr, encoding='utf-8')
print(result.stdout + result.stderr)
if result.returncode:
    sys.exit(result.returncode)
result = subprocess.run([sys.executable, str(ROOT / 'mono-host.py'), str(check),
    str(output), str(build.GAME), str(build.CORE)], capture_output=True,
    text=True, encoding='utf-8', errors='replace', timeout=60)
(PHASE / 'audit-20261007/installed-mono-check.log').write_text(result.stdout + result.stderr, encoding='utf-8')
print(result.stdout + result.stderr)
print('TESTED INSTALLED DLL SHA-256', build.digest(target))
sys.exit(result.returncode)
