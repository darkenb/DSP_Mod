using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyTitle("LaserClearing")]
[assembly: AssemblyProduct("starfi5h.plugin.LaserClearing")]
[assembly: AssemblyFileVersion("1.0.10")]
[assembly: AssemblyVersion("1.0.7.0")]
[module: RefSafetyRules(11)]
