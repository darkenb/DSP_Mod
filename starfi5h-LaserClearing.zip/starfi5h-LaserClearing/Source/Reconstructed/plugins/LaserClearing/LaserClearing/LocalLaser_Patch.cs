using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace LaserClearing;

public class LocalLaser_Patch
{
	public static bool Enable = true;

	public static bool EnableLoot = true;

	public static int RequiredSpace = 5;

	public static int MaxLaserCount = 3;

	public static float Range = 40f;

	public static int MiningTick = 60;

	public static double MiningPower = 6000.0;

	public static bool DropOnly = true;

	public static bool SpaceCapsule = false;

	public static bool EnableDestructionSFX = false;

	public static float ScaleWithDroneCount = 0f;

	public static float ScaleWithMiningSpeed = 0f;

	private static readonly List<int> laserIds = new List<int>();

	private static PlanetFactory ownerFactory;

	private static SkillSystem ownerSkillSystem;

	private static readonly Dictionary<int, int> laserTargets = new Dictionary<int, int>();

	private static int maxLaserCount = 3;

	private static int tickToClear = 60;

	private static int checkIntervalTick = 10;

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameMain), "Begin")]
	[HarmonyPatch(typeof(GameHistoryData), "NotifyTechUnlock")]
	private static void SetParameters()
	{
		maxLaserCount = MaxLaserCount;
		if (ScaleWithDroneCount > 0f)
		{
			maxLaserCount = (int)((float)(maxLaserCount * GameMain.mainPlayer.mecha.constructionModule.droneCount) * ScaleWithDroneCount);
		}
		maxLaserCount = ((maxLaserCount <= 0) ? 1 : maxLaserCount);
		tickToClear = MiningTick;
		if (ScaleWithMiningSpeed > 0f)
		{
			tickToClear = (int)((float)tickToClear / (1f + (GameMain.history.miningSpeedScale - 1f) * ScaleWithMiningSpeed));
		}
		tickToClear = ((tickToClear <= 0) ? 1 : tickToClear);
		checkIntervalTick = tickToClear / (maxLaserCount * 2);
		checkIntervalTick = ((checkIntervalTick <= 0) ? 1 : checkIntervalTick);
		Plugin.Log.LogDebug($"maxLaserCount={maxLaserCount} tickToClear={tickToClear}");
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlayerAction_Mine), "GameTick")]
	private static void GameTick(PlayerAction_Mine __instance)
	{
		if (!Enable)
		{
			return;
		}
		PlanetFactory factory = __instance.player.factory;
		if (factory == null)
		{
			ClearAll();
			return;
		}
		if (ownerFactory != factory)
		{
			ClearAll();
		}
		if (!CheckPlayerInventorySpace())
		{
			ClearAll();
			UI_Patch.UpdateButtonStatus(UI_Patch.ButtonStatus.NotEnoughSpace);
			return;
		}
		UI_Patch.UpdateButtonStatus(UI_Patch.ButtonStatus.Normal);
		ownerFactory = factory;
		Mecha mecha = __instance.player.mecha;
		Vector3 skillCastRightL = mecha.skillCastRightL;
		if (laserIds.Count < maxLaserCount && GameMain.gameTick % checkIntervalTick == 0L)
		{
			int closestVegeId = GetClosestVegeId(factory, skillCastRightL, Range);
			if (closestVegeId != 0)
			{
				laserIds.Add(StartLaser(factory, closestVegeId, skillCastRightL));
			}
		}
		for (int num = laserIds.Count - 1; num >= 0; num--)
		{
			if (!ContinueLaser(factory, laserIds[num], skillCastRightL, mecha, out var _))
			{
				laserTargets.Remove(laserIds[num]);
				laserIds.RemoveAt(num);
			}
		}
	}

	private static bool CheckPlayerInventorySpace()
	{
		if (!EnableLoot)
		{
			return true;
		}
		StorageComponent.GRID[] grids = GameMain.mainPlayer.package.grids;
		int num = 0;
		for (int num2 = GameMain.mainPlayer.package.size - 1; num2 >= 0; num2--)
		{
			if (grids[num2].count == 0 && grids[num2].filter == 0)
			{
				num++;
			}
			if (num >= RequiredSpace)
			{
				return true;
			}
		}
		return false;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameMain), "Begin")]
	[HarmonyPatch(typeof(GameMain), "End")]
	public static void ClearAll()
	{
		StopAll();
		laserIds.Clear();
		laserTargets.Clear();
		ownerFactory = null;
		ownerSkillSystem = null;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlanetFactory), "KillVegeFinally")]
	private static bool KillVegeFinally_CurrentPrefix(PlanetFactory __instance, int id, ref CombatStat combatStat)
	{
		if (combatStat.lastCaster.type == ETargetType.Enemy)
		{
			return true;
		}
		return KillVegeFinally_Prefix(__instance, id);
	}

	public static bool KillVegeFinally_Prefix(PlanetFactory __instance, int id)
	{
		if (!Enable || __instance != ownerFactory || !laserTargets.ContainsValue(id))
		{
			return true;
		}
		if (id <= 0 || id >= __instance.vegePool.Length || __instance.vegePool[id].id != id)
		{
			return true;
		}
		ref VegeData reference = ref __instance.vegePool[id];
		VegeProto vegeProto = LDB.veges.Select(reference.protoId);
		if (vegeProto != null)
		{
			VFEffectEmitter.Emit(vegeProto.MiningEffect, __instance.vegePool[id].pos, __instance.vegePool[id].rot);
			if (EnableDestructionSFX)
			{
				VFAudio.Create(vegeProto.MiningAudio, null, __instance.vegePool[id].pos, play: true, 1, -1, -1L);
			}
			if (EnableLoot)
			{
				GetVegLoot(__instance, in reference, vegeProto);
			}
		}
		__instance.gameData.mainPlayer.vegetableCollection.AddVegeToPlayer(reference.protoId);
		__instance.RemoveVegeWithComponents(id);
		return false;
	}

	private static void GetVegLoot(PlanetFactory factory, in VegeData vegeData, VegeProto vegeProto)
	{
		DotNet35Random dotNet35Random = new DotNet35Random(vegeData.id + ((factory.planet.seed & 0x3FFF) << 14));
		int num = 0;
		for (int i = 0; i < vegeProto.MiningItem.Length; i++)
		{
			if (!((float)dotNet35Random.NextDouble() < vegeProto.MiningChance[i]))
			{
				continue;
			}
			int num2 = vegeProto.MiningItem[i];
			int num3 = (int)((float)vegeProto.MiningCount[i] * (vegeData.scl.y * vegeData.scl.y) + 0.5f);
			if (num3 > 0 && LDB.items.Select(num2) != null)
			{
				int num4 = GameMain.mainPlayer.TryAddItemToPackage(num2, num3, 0, throwTrash: true);
				GameMain.statistics.production.factoryStatPool[factory.index].AddProductionToTotalArray(num2, num3);
				GameMain.data.history.AddFeatureValue(2150000 + num2, num3);
				if (num4 > 0)
				{
					UIItemup.Up(num2, num4);
					UIRealtimeTip.PopupItemGet(num2, num4, vegeData.pos + vegeData.pos.normalized, num++);
				}
			}
		}
	}

	private static int StartLaser(PlanetFactory factory, int vegeId, Vector3 beginPos)
	{
		ownerSkillSystem = GameMain.data.spaceSector.skillSystem;
		ref LocalLaserContinuous reference = ref ownerSkillSystem.localLaserContinuous.Add();
		ref VegeData reference2 = ref factory.vegePool[vegeId];
		reference.Start();
		reference.astroId = factory.planetId;
		reference.hitIndex = 4;
		reference.beginPos = reference2.pos + reference2.pos.normalized * SkillSystem.RoughHeightByModelIndex[reference2.modelIndex] * 0.5f;
		reference.endPos = beginPos;
		reference.target.type = ETargetType.Vegetable;
		reference.target.id = vegeId;
		int num = SkillSystem.HpMaxByModelIndex[reference2.modelIndex];
		int num2 = SkillSystem.HpRecoverByModelIndex[reference2.modelIndex];
		reference.damage = (int)((float)(num / tickToClear + num2) / 1f + 1f);
		reference.damageScale = 1f;
		reference.mask = ETargetTypeMask.NotPlayer;
		reference.sfxId = GameMain.data.spaceSector.skillSystem.audio.AddPlanetAudio(123, 0f, reference.astroId, reference.beginPos).id;
		laserTargets[reference.id] = vegeId;
		return reference.id;
	}

	private static bool ContinueLaser(PlanetFactory factory, int laserId, Vector3 beginPos, Mecha mecha, out int vegeId)
	{
		vegeId = 0;
		if (ownerSkillSystem == null || factory != ownerFactory)
		{
			return false;
		}
		ref DataPoolRenderer<LocalLaserContinuous> localLaserContinuous = ref ownerSkillSystem.localLaserContinuous;
		if (localLaserContinuous == null || localLaserContinuous.buffer == null)
		{
			return false;
		}
		if (laserId <= 0 || laserId >= localLaserContinuous.cursor || laserId >= localLaserContinuous.buffer.Length)
		{
			return false;
		}
		ref LocalLaserContinuous reference = ref localLaserContinuous.buffer[laserId];
		if (!laserTargets.TryGetValue(laserId, out vegeId) || reference.id != laserId || reference.target.type != ETargetType.Vegetable || reference.target.id != vegeId || reference.astroId != factory.planetId)
		{
			return false;
		}
		reference.endPos = beginPos;
		if (vegeId <= 0 || vegeId >= factory.vegePool.Length)
		{
			reference.Stop(ownerSkillSystem);
			return false;
		}
		ref VegeData reference2 = ref factory.vegePool[vegeId];
		if (reference2.id == 0)
		{
			reference.Stop(ownerSkillSystem);
			return false;
		}
		reference.beginPos = reference2.pos + reference2.pos.normalized * SkillSystem.RoughHeightByModelIndex[reference2.modelIndex] * 0.5f;
		if (Vector3.SqrMagnitude(reference2.pos - beginPos) > Range * Range)
		{
			reference.Stop(ownerSkillSystem);
			return false;
		}
		mecha.QueryEnergy(MiningPower, out var energyGet, out var ratio);
		mecha.coreEnergy -= energyGet;
		mecha.MarkEnergyChange(5, 0.0 - energyGet);
		reference.damageScale = ratio;
		return true;
	}

	private static void StopAll()
	{
		if (ownerSkillSystem == null || ownerFactory == null)
		{
			return;
		}
		ref DataPoolRenderer<LocalLaserContinuous> localLaserContinuous = ref ownerSkillSystem.localLaserContinuous;
		if (localLaserContinuous == null || localLaserContinuous.buffer == null)
		{
			return;
		}
		foreach (int laserId in laserIds)
		{
			if (laserId > 0 && laserId < localLaserContinuous.cursor && laserId < localLaserContinuous.buffer.Length)
			{
				ref LocalLaserContinuous reference = ref localLaserContinuous.buffer[laserId];
				if (reference.id == laserId && reference.astroId == ownerFactory.planetId && reference.target.type == ETargetType.Vegetable && laserTargets.TryGetValue(laserId, out var value) && reference.target.id == value)
				{
					reference.Stop(ownerSkillSystem);
				}
			}
		}
	}

	private static int GetClosestVegeId(PlanetFactory factory, Vector3 centerPos, float range)
	{
		int result = 0;
		VegeData[] vegePool = factory.vegePool;
		float num = range * range;
		HashSystem hashSystemStatic = factory.hashSystemStatic;
		hashSystemStatic.ClearActiveBuckets();
		int[] hashPool = hashSystemStatic.hashPool;
		int[] bucketOffsets = hashSystemStatic.bucketOffsets;
		int[] bucketCursors = hashSystemStatic.bucketCursors;
		hashSystemStatic.GetBucketIdxesInArea(centerPos, range);
		int[] activeBuckets = hashSystemStatic.activeBuckets;
		int activeBucketsCount = hashSystemStatic.activeBucketsCount;
		for (int i = 0; i < activeBucketsCount; i++)
		{
			int num2 = activeBuckets[i];
			int num3 = bucketOffsets[num2];
			int num4 = num3 + bucketCursors[num2];
			for (int j = num3; j < num4; j++)
			{
				int num5 = hashPool[j];
				if (num5 == 0 || num5 >> 28 != 1)
				{
					continue;
				}
				int num6 = num5 & 0xFFFFFFF;
				if (num6 <= 0 || num6 >= vegePool.Length || laserTargets.ContainsValue(num6))
				{
					continue;
				}
				ref VegeData reference = ref vegePool[num6];
				if (reference.id != num6 || (reference.protoId == 9999 && !SpaceCapsule))
				{
					continue;
				}
				VegeProto vegeProto = LDB.veges.Select(reference.protoId);
				if (vegeProto != null && (!DropOnly || (vegeProto.MiningItem != null && vegeProto.MiningItem.Length != 0)))
				{
					float num7 = Vector3.SqrMagnitude(reference.pos - centerPos);
					if (num7 < num)
					{
						result = num6;
						num = num7;
					}
				}
			}
		}
		hashSystemStatic.ClearActiveBuckets();
		return result;
	}
}
