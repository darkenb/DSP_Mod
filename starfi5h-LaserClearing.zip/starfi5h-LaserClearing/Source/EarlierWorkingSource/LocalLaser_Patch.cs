using HarmonyLib;
using System;
using System.Collections.Generic;
using UnityEngine;

namespace LaserClearing
{
    public class LocalLaser_Patch
    {
        public static bool Enable = true;
        public static bool EnableLoot = true;
        public static int RequiredSpace = 5;
        public static int MaxLaserCount = 3;
        public static float Range = 40f;
        public static int MiningTick = 60;        
        public static double MiningPower = 6000; // 1000 per tick = 60kw in game
        public static bool DropOnly = true;
        public static bool SpaceCapsule = false;
        public static bool EnableDestructionSFX = false;
        public static float ScaleWithDroneCount = 0f;
        public static float ScaleWithMiningSpeed = 0f;

        static readonly List<int> laserIds = new();
        static PlanetFactory ownerFactory;
        static SkillSystem ownerSkillSystem;
        static readonly Dictionary<int, int> laserTargets = new();
        static int maxLaserCount = 3;
        static int tickToClear = 60;
        static int checkIntervalTick = 10;

        [HarmonyPostfix]
        [HarmonyPatch(typeof(GameMain), nameof(GameMain.Begin))]
        [HarmonyPatch(typeof(GameHistoryData), nameof(GameHistoryData.NotifyTechUnlock))]
        static void SetParameters()
        {
            maxLaserCount = MaxLaserCount;
            if (ScaleWithDroneCount > 0f)
            {
                maxLaserCount = (int)(maxLaserCount * (GameMain.mainPlayer.mecha.constructionModule.droneCount) * ScaleWithDroneCount);
            }
            maxLaserCount = maxLaserCount > 0 ? maxLaserCount : 1;
            tickToClear = MiningTick;
            if (ScaleWithMiningSpeed > 0f)
            {
                tickToClear = (int)(tickToClear / (1 + (GameMain.history.miningSpeedScale - 1f) * ScaleWithMiningSpeed));
            }
            tickToClear = tickToClear > 0 ? tickToClear : 1;
            checkIntervalTick = tickToClear / (maxLaserCount * 2);
            checkIntervalTick  = checkIntervalTick > 0 ? checkIntervalTick : 1;
            Plugin.Log.LogDebug($"maxLaserCount={maxLaserCount} tickToClear={tickToClear}");
        }

        [HarmonyPostfix, HarmonyPatch(typeof(PlayerAction_Mine), nameof(PlayerAction_Mine.GameTick))]
        static void GameTick(PlayerAction_Mine __instance)
        {
            if (!Enable) return;
            PlanetFactory factory = __instance.player.factory;
            if (factory == null) { ClearAll(); return; }
            if (!ReferenceEquals(ownerFactory, factory)) ClearAll();
            if (!CheckPlayerInventorySpace())
            {
                ClearAll();
                UI_Patch.UpdateButtonStatus(UI_Patch.ButtonStatus.NotEnoughSpace);
                return;
            }
            UI_Patch.UpdateButtonStatus(UI_Patch.ButtonStatus.Normal);
            ownerFactory = factory;
            Mecha mecha = __instance.player.mecha;
            Vector3 beginPos = mecha.skillCastRightL;

            if (laserIds.Count < maxLaserCount && GameMain.gameTick % checkIntervalTick == 0)
            {
                int vegeId = GetClosestVegeId(factory, beginPos, Range);
                if (vegeId != 0)
                {
                    laserIds.Add(StartLaser(factory, vegeId, beginPos));
                }
            }
            for (int i = laserIds.Count - 1; i >= 0; i--)
            {
                if (!ContinueLaser(factory, laserIds[i], beginPos, mecha, out _))
                {
                    laserTargets.Remove(laserIds[i]);
                    laserIds.RemoveAt(i);
                }
            }
        }

        private static bool CheckPlayerInventorySpace()
        {
            if (!EnableLoot) return true;
            var grids = GameMain.mainPlayer.package.grids;
            var spaceCount = 0;
            for (int i = GameMain.mainPlayer.package.size - 1; i >= 0; i--)
            {
                if (grids[i].count == 0 && grids[i].filter == 0) ++spaceCount;
                if (spaceCount >= RequiredSpace) return true;
            }
            return false;
        }


        [HarmonyPostfix]
        [HarmonyPatch(typeof(GameMain), nameof(GameMain.Begin))]
        [HarmonyPatch(typeof(GameMain), nameof(GameMain.End))]
        public static void ClearAll()
        {
            StopAll();
            laserIds.Clear();
            laserTargets.Clear();
            ownerFactory = null;
            ownerSkillSystem = null;
        }


        [HarmonyPrefix]
        [HarmonyPatch(typeof(PlanetFactory), nameof(PlanetFactory.KillVegeFinally))]
        private static bool KillVegeFinally_CurrentPrefix(PlanetFactory __instance, int id, ref CombatStat combatStat)
        {
            if (combatStat.lastCaster.type == ETargetType.Enemy) return true;
            return KillVegeFinally_Prefix(__instance, id);
        }

        public static bool KillVegeFinally_Prefix(PlanetFactory __instance, int id)
        {
            if (!Enable || !ReferenceEquals(__instance, ownerFactory) || !laserTargets.ContainsValue(id)) return true;
            if (id <= 0 || id >= __instance.vegePool.Length || __instance.vegePool[id].id != id) return true;

            ref var vegeData = ref __instance.vegePool[id];
            VegeProto vegeProto = LDB.veges.Select(vegeData.protoId);
            if (vegeProto != null)
            {
                VFEffectEmitter.Emit(vegeProto.MiningEffect, __instance.vegePool[id].pos, __instance.vegePool[id].rot);
                if (EnableDestructionSFX)
                    VFAudio.Create(vegeProto.MiningAudio, null, __instance.vegePool[id].pos, true, 1, -1, -1L);

                if (EnableLoot)
                {
                    GetVegLoot(__instance, vegeData, vegeProto);
                }
            }
            // Preserve the current native combat destruction collection semantics.
            __instance.gameData.mainPlayer.vegetableCollection.AddVegeToPlayer(vegeData.protoId);
            __instance.RemoveVegeWithComponents(id);
            return false;
        }

        static void GetVegLoot(PlanetFactory factory, in VegeData vegeData, VegeProto vegeProto)
        {
            // From PlayerAction_Mine.GameTick()
            var dotNet35Random = new DotNet35Random(vegeData.id + ((factory.planet.seed & 16383) << 14));
            int queue = 0;
            for (int j = 0; j < vegeProto.MiningItem.Length; j++)
            {
                if ((float)dotNet35Random.NextDouble() < vegeProto.MiningChance[j])
                {
                    int itemId = vegeProto.MiningItem[j];
                    int itemCount = (int)(vegeProto.MiningCount[j] * (vegeData.scl.y * vegeData.scl.y) + 0.5f);
                    if (itemCount > 0 && LDB.items.Select(itemId) != null)
                    {
                        int addedCount = GameMain.mainPlayer.TryAddItemToPackage(itemId, itemCount, 0, true, 0, false);
                        GameMain.statistics.production.factoryStatPool[factory.index].AddProductionToTotalArray(itemId, itemCount);
                        GameMain.data.history.AddFeatureValue(2150000 + itemId, itemCount);
                        if (addedCount > 0)
                        {
                            UIItemup.Up(itemId, addedCount);
                            UIRealtimeTip.PopupItemGet(itemId, addedCount, vegeData.pos + vegeData.pos.normalized, queue++);
                        }
                    }
                }
            }
        }



        // Reference: TestSkillCasts

        static int StartLaser(PlanetFactory factory, int vegeId, Vector3 beginPos)
        {
            ownerSkillSystem = GameMain.data.spaceSector.skillSystem;
            ref LocalLaserContinuous ptr = ref ownerSkillSystem.localLaserContinuous.Add();
            ref VegeData vegeData = ref factory.vegePool[vegeId];
            ptr.Start();
            ptr.astroId = factory.planetId;
            ptr.hitIndex = 4;
            ptr.beginPos = vegeData.pos + vegeData.pos.normalized * SkillSystem.RoughHeightByModelIndex[vegeData.modelIndex] * 0.5f;
            ptr.endPos = beginPos;
            ptr.target.type = ETargetType.Vegetable;
            ptr.target.id = vegeId;

            int maxHp = SkillSystem.HpMaxByModelIndex[vegeData.modelIndex];
            int recoverHp = SkillSystem.HpRecoverByModelIndex[vegeData.modelIndex];
            ptr.damage = (int)((maxHp / tickToClear + recoverHp) / 1.0f + 1); // Kill the tree/stones after MiningTick 
            ptr.damageScale = 1.0f; // TickSkillLogic: vfaudio.volumeMultiplier = Mathf.Min(1.5f, this.damageScale * 0.6f);
            ptr.mask = ETargetTypeMask.NotPlayer;

            // Replace laser sound with mining sound (123)
            ref SkillSFXHolder ptr2 = ref GameMain.data.spaceSector.skillSystem.audio.AddPlanetAudio(123, 0f, ptr.astroId, ptr.beginPos);
            ptr.sfxId = ptr2.id;
            laserTargets[ptr.id] = vegeId;
            return ptr.id;
        }

        static bool ContinueLaser(PlanetFactory factory, int laserId, Vector3 beginPos, Mecha mecha, out int vegeId)
        {
            vegeId = 0;
            if (ownerSkillSystem == null || !ReferenceEquals(factory, ownerFactory)) return false;
            ref var pool = ref ownerSkillSystem.localLaserContinuous;
            if (pool == null || pool.buffer == null) return false;
            if (laserId <= 0 || laserId >= pool.cursor || laserId >= pool.buffer.Length) return false;
            ref LocalLaserContinuous ptr = ref pool.buffer[laserId];
            if (!laserTargets.TryGetValue(laserId, out vegeId) || ptr.id != laserId || ptr.target.type != ETargetType.Vegetable || ptr.target.id != vegeId || ptr.astroId != factory.planetId) return false;
            ptr.endPos = beginPos;
            if (vegeId <= 0 || vegeId >= factory.vegePool.Length) { ptr.Stop(ownerSkillSystem); return false; }
            ref VegeData vegeData = ref factory.vegePool[vegeId];
            if (vegeData.id == 0)
            {
                ptr.Stop(ownerSkillSystem);
                return false;
            }
            ptr.beginPos = vegeData.pos + vegeData.pos.normalized * SkillSystem.RoughHeightByModelIndex[vegeData.modelIndex] * 0.5f;
            if (Vector3.SqrMagnitude(vegeData.pos - beginPos) > Range * Range)
            {
                ptr.Stop(ownerSkillSystem);
                return false;
            }
            mecha.QueryEnergy(MiningPower, out double energyConsumed, out float energyRatio);
            mecha.coreEnergy -= energyConsumed;
            mecha.MarkEnergyChange(5, -energyConsumed);
            ptr.damageScale = energyRatio;
            return true;
        }

        static void StopAll()
        {
            if (ownerSkillSystem == null || ownerFactory == null) return;
            ref var pool = ref ownerSkillSystem.localLaserContinuous;
            if (pool == null || pool.buffer == null) return;
            foreach (var id in laserIds)
            {
                if (id <= 0 || id >= pool.cursor || id >= pool.buffer.Length) continue;
                ref var laser = ref pool.buffer[id];
                if (laser.id == id && laser.astroId == ownerFactory.planetId && laser.target.type == ETargetType.Vegetable &&
                    laserTargets.TryGetValue(id, out var vege) && laser.target.id == vege) laser.Stop(ownerSkillSystem);
            }
        }

        static int GetClosestVegeId(PlanetFactory factory, Vector3 centerPos, float range)
        {
            int result = 0;
            VegeData[] vegePool = factory.vegePool;
            float minDist = range * range;

            HashSystem hashSystemStatic = factory.hashSystemStatic; // The unmoveable objects
            hashSystemStatic.ClearActiveBuckets();
            int[] hashPool = hashSystemStatic.hashPool;
            int[] bucketOffsets = hashSystemStatic.bucketOffsets;
            int[] bucketCursors = hashSystemStatic.bucketCursors;
            hashSystemStatic.GetBucketIdxesInArea(centerPos, range);
            int[] activeBuckets = hashSystemStatic.activeBuckets;
            int activeBucketsCount = hashSystemStatic.activeBucketsCount;
            for (int k = 0; k < activeBucketsCount; k++)
            {
                int bucketId = activeBuckets[k];
                int offset = bucketOffsets[bucketId];
                int end = offset + bucketCursors[bucketId];
                for (int l = offset; l < end; l++)
                {
                    int hashAddress = hashPool[l];
                    if (hashAddress != 0 && hashAddress >> 28 == 1) // ETargetType.Vegetable = 1
                    {
                        int vegeId = hashAddress & 268435455;
                        if (vegeId <= 0 || vegeId >= vegePool.Length || laserTargets.ContainsValue(vegeId)) continue;
                        ref VegeData vege = ref vegePool[vegeId];
                        if (vege.id != vegeId || (vege.protoId == 9999 && !SpaceCapsule)) continue;
                        VegeProto vegeProto = LDB.veges.Select(vege.protoId);
                        if (vegeProto == null || (DropOnly && (vegeProto.MiningItem == null || vegeProto.MiningItem.Length == 0))) continue;
                        float dist = Vector3.SqrMagnitude(vege.pos - centerPos);
                        if (dist < minDist)
                        {
                            result = vegeId;
                            minDist = dist;
                        }
                    }
                }
            }
            hashSystemStatic.ClearActiveBuckets();
            return result;
        }
    }
}
