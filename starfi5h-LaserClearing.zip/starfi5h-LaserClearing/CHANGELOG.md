# starfi5h-LaserClearing — detailed change report

Installed plugin version(s): **1.0.10**. Track owned lasers, revalidate reused vegetation IDs and capsule rules, stop on full inventory and scale damage by actual energy.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Owned laser lifecycle — 1.0.8

Retain the installed 1.0.7 source baseline. Track the mod's lasers by factory and target identity so cleanup does not stop battle/other-mod lasers. Clear old ownership when worlds change and calculate range from the vegetation's actual position.

Use current native `VegetableCollection.AddVegeToPlayer` for custom clearing. Leave enemy-caused and unowned vegetation removal to native behavior. Version 1.0.9 adds `/unsafe+` access metadata verified in game Mono without replacing the native game DLL.

## Reused vegetation slots and energy — 1.0.10, 7 October

- Remove the vegetation-ID cache. Recheck the current prototype, drops and capsule settings on each target selection because pool slots can be reused. Skip removed/out-of-range IDs and do not create a second laser for an already targeted plant.
- Stop existing owned lasers when inventory no longer has the required free room; preserve other lasers' ownership.
- Safely skip state updates before the button exists, and reset state cache when recreating it.
- Scale laser damage by the energy ratio returned by `Mecha.QueryEnergy`; no energy means no damage. Preserve native energy expenditure records.

Actual game-DLL checks cover selection, pool-slot reuse, capsule protection, bounds, buttonless updates, full-inventory stopping, ownership, native Stop and native collection counts. Real Unity effects, plant/stone replanting, capsule loot and rendered UI remain live acceptance work.

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
