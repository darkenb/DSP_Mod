# Related mods and code references — starfi5h-LaserClearing

All listed copies are inside this mod folder. They are one-level reference copies with their own Source, InstalledPackage, metadata and English change notes. Required installed dependencies of those copies are flattened into the same RelatedMods directory; copies never recursively contain another RelatedMods directory.

Dependency declarations (including optional compatibility plugins), compiled member calls and native integration/test context are distinguished below. A shared native API touchpoint is not presented as a direct foreign-method call. Original game/BepInEx SDK files and uninstalled optional mods are not fabricated or downloaded. 

No installed cross-mod relationship specific to the recorded correction or its declared/compiled dependencies was identified. This package remains a review unit for its own native-game changes.
