# starfi5h-DeliverySlotsTweaks — detailed change report

Installed plugin version(s): **1.5.21**. Count only active, unlocked delivery grids using native geometry and guarded arithmetic.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Active delivery accounting — 1.5.20

- Check native `IsGridActive` on every grid instead of assuming all positions below the highest index are active. Closed regions and locked delivery packages are not available crafting material.
- Handle gaps in the native 100-slot geometry and repeated entries for an item; guard total-count overflow.
- Apply delivery-column and stack settings as minima. Do not shrink larger BigInventory/research values. Preserve native unlock behavior and inc transfers.
- Keep current forge/ref/out helpers and native auto-replenishment targets. New items/lenses use the generic item-ID path rather than a vanilla allowlist.

Version 1.5.21 on 4 October added `/unsafe+` metadata to the publicized-reference build and checked private access in actual game Mono; the native game DLL was not modified. Build evidence records native transfer and BigInventory interaction checks. Full game, multiplayer and UI acceptance remain outstanding.

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
