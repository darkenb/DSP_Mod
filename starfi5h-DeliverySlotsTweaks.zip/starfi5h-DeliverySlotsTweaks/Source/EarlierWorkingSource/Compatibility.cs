using BepInEx.Configuration;
using HarmonyLib;
using NebulaAPI;
using System;
using System.Reflection;

namespace DeliverySlotsTweaks
{
    public class Compatibility
    {
        public static bool IsArchitectModeModExist { get; private set; } = false;
        public static bool IsDeliveryPackageModExist { get; private set; } = false;

        public static void Init(Harmony harmony)
        {
            Multfunction_mod_Patch.Init(harmony); // ArchitectMode Mod
            UXAssist_Patch.Init(harmony);
            CheatEnabler_Patch.Init(harmony); // ArchitectMode Mod
            RebindBuildBar_Patch.Init(harmony);
            UnlimitedFoundations_Patch.Init(harmony);
            Nebula_Patch.Init(harmony);
            FractionateEverything_Patch.Init();
        }

        public static class Auxilaryfunction_Patch
        {
            public const string GUID = "cn.blacksnipe.dsp.Auxilaryfunction";

            public static void Init(Harmony harmony)
            {
                try
                {
                    if (!BepInEx.Bootstrap.Chainloader.PluginInfos.TryGetValue(GUID, out var pluginInfo)) return;
                    Assembly assembly = pluginInfo.Instance.GetType().Assembly;
                    Type classType = assembly.GetType("Auxilaryfunction.Auxilaryfunction");
                    harmony.Patch(AccessTools.Method(classType, "AutoMovetounbuilt"), null, null,
                        new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("UIBuildMenu_Transpiler")));

                }
                catch (Exception e)
                {
                    Plugin.Log.LogWarning("Auxilaryfunction compatibility failed! Last working version: 3.0.1");
                    Plugin.Log.LogWarning(e);
                }
            }
        }

        public static class UXAssist_Patch
        {
            public const string GUID = "org.soardev.uxassist";

            public static void Init(Harmony harmony)
            {
                if (!BepInEx.Bootstrap.Chainloader.PluginInfos.TryGetValue(GUID, out var pluginInfo)) return;

                try
                {
                    Assembly assembly = pluginInfo.Instance.GetType().Assembly;
                    Type classType = assembly.GetType("UXAssist.Patches.Logistics.LogisticsPatch");
                    harmony.Patch(AccessTools.Method(classType, "StationFillDrones"), null, null,
                        new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("TakeItem_Transpiler")));
                    harmony.Patch(AccessTools.Method(classType, "StationFillShips"), null, null,
                        new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("TakeItem_Transpiler")));
                    harmony.Patch(AccessTools.Method(classType, "DispenserFillCouriers"), null, null,
                        new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("TakeItem_Transpiler")));
                }
                catch (Exception e)
                {
                    Plugin.Log.LogWarning("UXAssist compatibility failed! Last working version: 1.6.0");
                    Plugin.Log.LogWarning(e);
                }
            }
        }

        public static class CheatEnabler_Patch
        {
            public const string GUID = "org.soardev.cheatenabler";
            static ConfigEntry<bool> ArchitectModeEnabled;

            public static void Init(Harmony _)
            {
                if (!BepInEx.Bootstrap.Chainloader.PluginInfos.TryGetValue(GUID, out var pluginInfo)) return;
                IsArchitectModeModExist = true;

                try
                {
                    Assembly assembly = pluginInfo.Instance.GetType().Assembly;
                    Type classType = assembly.GetType("CheatEnabler.Patches.Factory.FactoryPatch");
                    ArchitectModeEnabled = (ConfigEntry<bool>)AccessTools.Field(classType, "ArchitectModeEnabled").GetValue(null);
                    ArchitectModeEnabled.SettingChanged += OnArchitectModeEnabledChange;
                    DeliveryPackagePatch.architectMode |= ArchitectModeEnabled.Value;
                    Plugin.Log.LogDebug("CheatEnabler ArchitectModeEnabled: " + ArchitectModeEnabled.Value);
                }
                catch (Exception e)
                {
                    Plugin.Log.LogWarning("CheatEnabler compatibility failed! Last working version: 2.4.5");
                    Plugin.Log.LogWarning(e);
                }
            }

            internal static void OnArchitectModeEnabledChange(object sender, EventArgs e)
            {
                if (ArchitectModeEnabled == null) return;
                DeliveryPackagePatch.architectMode = ArchitectModeEnabled.Value;
                Plugin.Log.LogDebug("CheatEnabler ArchitectModeEnabled: " + DeliveryPackagePatch.architectMode);
            }
        }

        public static class Multfunction_mod_Patch
        {
            public const string GUID = "cn.blacksnipe.dsp.Multfuntion_mod";
            static ConfigEntry<bool> architectMode = null;

            public static void Init(Harmony harmony)
            {
                try
                {
                    if (!BepInEx.Bootstrap.Chainloader.PluginInfos.TryGetValue(GUID, out var pluginInfo)) return;
                    IsArchitectModeModExist = true;
                    Assembly assembly = pluginInfo.Instance.GetType().Assembly;
                    Type classType = assembly.GetType("Multifunction_mod.GUIDraw");
                    harmony.Patch(AccessTools.Method(classType, "BuildPannel"), null, new HarmonyMethod(typeof(Multfunction_mod_Patch).GetMethod(nameof(BuildPannel_Postfix))));

                    architectMode = (ConfigEntry<bool>)(AccessTools.Field(AccessTools.TypeByName("Multifunction_mod.Multifunction"), "ArchitectMode").GetValue(null));
                    DeliveryPackagePatch.architectMode |= architectMode.Value;
                    Plugin.Log.LogDebug("Multfunction_mod ArchitectModeEnabled: " + architectMode.Value);

                }
                catch (Exception e)
                {
                    Plugin.Log.LogWarning("Multfunction_mod compatibility failed! Last working version: 4.0.1");
                    Plugin.Log.LogWarning(e);
                }
            }

            public static void BuildPannel_Postfix()
            {
                DeliveryPackagePatch.architectMode = architectMode.Value;
            }
        }

        public static class Nebula_Patch
        {
            public const string GUID = "dsp.nebula-multiplayer";
            public static bool IsActive { get; private set; }
            static bool IsPatched;

            public static void Init(Harmony harmony)
            {
                try
                {
                    if (!BepInEx.Bootstrap.Chainloader.PluginInfos.TryGetValue(GUID, out var pluginInfo)) return;
                    Patch(harmony);
                }
                catch (Exception e)
                {
                    Plugin.Log.LogWarning("Nebula compatibility failed!");
                    Plugin.Log.LogWarning(e);
                }
            }

            public static bool IsOthers() // Action triggered by packets from other player
            {
                var factoryManager = NebulaModAPI.MultiplayerSession.Factories;
                return factoryManager.IsIncomingRequest.Value && factoryManager.PacketAuthor != NebulaModAPI.MultiplayerSession.LocalPlayer.Id;
            }


            private static void Patch(Harmony harmony)
            {
                // Separate for using NebulaModAPI
                if (!NebulaModAPI.NebulaIsInstalled || IsPatched)
                    return;
                NebulaModAPI.OnMultiplayerGameStarted += OnMultiplayerGameStarted;
                NebulaModAPI.OnMultiplayerGameEnded += OnMultiplayerGameEnded;

                Type classType = AccessTools.TypeByName("NebulaWorld.SimulatedWorld");
                harmony.Patch(AccessTools.Method(classType, "SetupInitialPlayerState"), null, new HarmonyMethod(AccessTools.Method(typeof(Plugin), "ApplyConfigs")));

#if DEBUG
                OnMultiplayerGameStarted();
#endif
                IsPatched = true;
            }

            private static void OnMultiplayerGameStarted()
            {
                IsActive = NebulaModAPI.IsMultiplayerActive;
            }

            private static void OnMultiplayerGameEnded()
            {
                IsActive = false;
            }
        }
    
        public static class RebindBuildBar_Patch
        {
            public const string GUID = "org.kremnev8.plugin.RebindBuildBar";

            public static void Init(Harmony harmony)
            {
                try
                {
                    if (!BepInEx.Bootstrap.Chainloader.PluginInfos.TryGetValue(GUID, out var pluginInfo)) return;
                    Assembly assembly = pluginInfo.Instance.GetType().Assembly;
                    Type classType = assembly.GetType("RebindBuildBar.Patches");
                    harmony.Patch(AccessTools.Method(classType, "EnableButton"), null, null, new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("UIBuildMenu_Transpiler")));
                }
                catch (Exception e)
                {
                    Plugin.Log.LogWarning("RebindBuildBar compatibility failed! Last working version: 1.0.4");
                    Plugin.Log.LogWarning(e);
                }
            }
        }

        public static class UnlimitedFoundations_Patch
        {
            public const string GUID1 = "com.aekoch.mods.dsp.UnlimitedFoundations";
            public const string GUID2 = "com.tinysquid.infinitefoundations";

            public static void Init(Harmony harmony)
            {
                try
                {
                    if (BepInEx.Bootstrap.Chainloader.PluginInfos.ContainsKey(GUID1)
                        || BepInEx.Bootstrap.Chainloader.PluginInfos.ContainsKey(GUID2))
                    harmony.Patch(AccessTools.Method(typeof(DeliveryPackagePatch), "GetItemCount"), 
                        null, 
                        new HarmonyMethod(typeof(UnlimitedFoundations_Patch).GetMethod("GetItemCount_Postfix")));
                }
                catch (Exception e)
                {
                    Plugin.Log.LogWarning("UnlimitedFoundations compatibility failed!");
                    Plugin.Log.LogWarning(e);
                }
            }

            public static void GetItemCount_Postfix(int itemId, ref int __result)
            {
                if (itemId == 1131) // FOUNDATION_ITEM_ID
                {
                    __result = 9999;
                }
            }
        }

        public static class FractionateEverything_Patch
        {
            public const string GUID = "com.menglei.dsp.fe";

            public static void Init()
            {
                if (BepInEx.Bootstrap.Chainloader.PluginInfos.ContainsKey(GUID))
                {
                    Plugin.Log.LogInfo("Disable UseLogisticSlots functions as FractionateEverything mod exist!");
                    IsDeliveryPackageModExist = true;
                }
            }
        }
    }
}