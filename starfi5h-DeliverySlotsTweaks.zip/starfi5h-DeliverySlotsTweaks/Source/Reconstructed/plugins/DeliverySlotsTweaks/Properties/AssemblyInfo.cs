using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyTitle("starfi5h.plugin.DeliverySlotsTweaks")]
[assembly: AssemblyProduct("DeliverySlotsTweaks")]
[assembly: AssemblyVersion("1.5.19.0")]
[module: RefSafetyRules(11)]
