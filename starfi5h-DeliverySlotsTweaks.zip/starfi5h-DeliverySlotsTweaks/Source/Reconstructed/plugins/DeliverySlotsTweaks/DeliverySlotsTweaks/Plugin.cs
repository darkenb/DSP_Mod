using System;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;

namespace DeliverySlotsTweaks;

[BepInPlugin("starfi5h.plugin.DeliverySlotsTweaks", "DeliverySlotsTweaks", "1.5.21")]
[BepInDependency("cn.blacksnipe.dsp.Multfuntion_mod", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class Plugin : BaseUnityPlugin
{
	public const string GUID = "starfi5h.plugin.DeliverySlotsTweaks";

	public const string NAME = "DeliverySlotsTweaks";

	public const string VERSION = "1.5.21";

	public static Plugin Instance;

	public static ManualLogSource Log;

	public static ConfigEntry<bool> UseLogisticSlots;

	public static ConfigEntry<bool> AutoRefillFuel;

	public static ConfigEntry<bool> AutoRefillWarper;

	public static ConfigEntry<int> ColCount;

	public static ConfigEntry<int> StackSizeMultiplier;

	public static ConfigEntry<bool> DeliveryFirst;

	public static ConfigEntry<int> PlayerPackageStackSize;

	public static ConfigEntry<int> PlayerPackageStackMultiplier;

	public static ConfigEntry<bool> SortToDelieverySlots;

	public static ConfigEntry<bool> EnableArchitectMode;

	public static ConfigEntry<bool> EnableFastReplicator;

	private Harmony harmony;

	private void InitConfig()
	{
		UseLogisticSlots = base.Config.Bind("DeliveryPackage", "UseLogisticSlots", defaultValue: true, "Let replicator and build tools use items in logistic slots. (require restart)\n使手动制造和建筑工具可以使用物流清单内的物品");
		AutoRefillFuel = base.Config.Bind("DeliveryPackage", "AutoRefillFuel", defaultValue: false, "Allow fuel chamber to also take from logistics slots. (require restart)\n自动补充燃料时也会使用物流清单内的物品");
		AutoRefillWarper = base.Config.Bind("DeliveryPackage", "AutoRefillWarper", defaultValue: false, "Auto refill space warper from inventory and logistics slots.\n从背包和物流清单自动补充翘曲器");
		ColCount = base.Config.Bind("DeliveryPackage", "ColCount", 0, new ConfigDescription("NoChange:0 TechMax:3 Limit:5\n物流清单容量-列(不改:0 原版科技:3 最高上限:5)", new AcceptableValueRange<int>(0, 5)));
		ColCount.SettingChanged += delegate
		{
			ApplyConfigs();
		};
		StackSizeMultiplier = base.Config.Bind("DeliveryPackage", "StackSizeMultiplier", 0, "NoChange:0 TechMax:10\n物流清单物品堆叠倍率(不改:0 原版科技:10)");
		StackSizeMultiplier.SettingChanged += delegate
		{
			ApplyConfigs();
		};
		DeliveryFirst = base.Config.Bind("DeliveryPackage", "DeliveryFirst", defaultValue: true, "When logistic bots send items to mecha, send them to delivery slots first.\n配送机会优先将物品送入物流清单的栏位");
		SortToDelieverySlots = base.Config.Bind("DeliveryPackage", "SortToDelieverySlots", defaultValue: false, "When sorting inventory, send them to delivery slots first.\n整理背包时会先将物品送入物流清单的栏位");
		PlayerPackageStackSize = base.Config.Bind("PlayerPackage", "StackSize", 0, "Overwrite stack size in inventory. NoChange:0\n统一设置玩家背包中的物品数量堆疊上限(上限=常数值,每件物品皆相同) (不改:0)");
		PlayerPackageStackSize.SettingChanged += delegate
		{
			ApplyConfigs();
		};
		PlayerPackageStackMultiplier = base.Config.Bind("PlayerPackage", "StackMultiplier", 0, "Apply multiplier for stack size in inventory. NoChange:0\n修改玩家背包中的物品堆疊倍率乘积(上限=原物品堆叠*倍率) (不改:0)");
		PlayerPackageStackMultiplier.SettingChanged += delegate
		{
			ApplyConfigs();
		};
		EnableArchitectMode = base.Config.Bind("BuildTool", "EnableArchitectMode", defaultValue: false, "Build without requirement of items (infinite buildings)\n建筑师模式:建造无需物品");
		EnableArchitectMode.SettingChanged += delegate
		{
			ApplyConfigs();
		};
		EnableFastReplicator = base.Config.Bind("BuildTool", "EnableFastReplicator", defaultValue: true, "Right click on hotbar to queue the building in replicator (require restart)\n右键单击快捷栏中的建筑可直接在合成器排程制造");
	}

	public void Start()
	{
		Instance = this;
		Log = base.Logger;
		harmony = new Harmony("starfi5h.plugin.DeliverySlotsTweaks");
		InitConfig();
		Compatibility.Init(harmony);
		harmony.PatchAll(typeof(Plugin));
		if (UseLogisticSlots.Value)
		{
			if (!Compatibility.IsDeliveryPackageModExist)
			{
				harmony.PatchAll(typeof(DeliveryPackagePatch));
			}
			if (AutoRefillFuel.Value)
			{
				harmony.Patch(AccessTools.Method(typeof(Mecha), "AutoReplenishFuel"), null, null, new HarmonyMethod(AccessTools.Method(typeof(DeliveryPackagePatch), "TakeItem_Transpiler")));
				harmony.Patch(AccessTools.Method(typeof(Mecha), "AutoReplenishFuelAll"), null, null, new HarmonyMethod(AccessTools.Method(typeof(DeliveryPackagePatch), "TakeItem_Transpiler")));
			}
		}
		StackSizeMultiplier.Value = Math.Min(StackSizeMultiplier.Value, 1000000);
		PlayerPackageStackSize.Value = Math.Min(PlayerPackageStackSize.Value, 1000000000);
		PlayerPackageStackMultiplier.Value = Math.Min(PlayerPackageStackMultiplier.Value, 1000000);
		if (PlayerPackageStackSize.Value > 0 || PlayerPackageStackMultiplier.Value > 0)
		{
			harmony.PatchAll(typeof(PlayerPackagePatch));
		}
		if (EnableFastReplicator.Value)
		{
			harmony.PatchAll(typeof(UIBuildMenuPatch));
		}
	}

	public void OnDestroy()
	{
		harmony?.UnpatchSelf();
		harmony = null;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIOptionWindow), "OnApplyClick")]
	internal static void OnApplyClick()
	{
		Instance.Config.Reload();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(Player), "Import")]
	[HarmonyPatch(typeof(Player), "SetForNewGame")]
	internal static void ApplyConfigs()
	{
		ParameterOverwrite();
		PlayerPackagePatch.OnConfigChange();
		SetMaxDeliveryGridIndex(GameMain.mainPlayer?.deliveryPackage);
		if (!Compatibility.IsArchitectModeModExist)
		{
			bool architectMode = DeliveryPackagePatch.architectMode;
			DeliveryPackagePatch.architectMode = EnableArchitectMode.Value;
			if (architectMode != DeliveryPackagePatch.architectMode)
			{
				Log.LogDebug("ArchitectModeEnabled: " + DeliveryPackagePatch.architectMode);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPriority(500)]
	[HarmonyPatch(typeof(GameHistoryData), "UnlockTechFunction")]
	private static void ParameterOverwrite()
	{
		DeliveryPackage deliveryPackage = GameMain.mainPlayer?.deliveryPackage;
		if (deliveryPackage != null)
		{
			if (ColCount.Value > 0 && ColCount.Value <= 5 && deliveryPackage.colCount < ColCount.Value)
			{
				deliveryPackage.colCount = ColCount.Value;
				deliveryPackage.NotifySizeChange();
			}
			if (StackSizeMultiplier.Value > 0)
			{
				deliveryPackage.stackSizeMultiplier = Math.Max(deliveryPackage.stackSizeMultiplier, Math.Min(StackSizeMultiplier.Value, 1000000));
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(DeliveryPackage), "NotifySizeChange")]
	private static void SetMaxDeliveryGridIndex(DeliveryPackage __instance)
	{
		if (!UseLogisticSlots.Value || __instance == null || __instance != GameMain.mainPlayer?.deliveryPackage)
		{
			return;
		}
		DeliveryPackagePatch.maxDeliveryGridIndex = 0;
		for (int num = __instance.gridLength - 1; num >= 0; num--)
		{
			if (__instance.IsGridActive(num))
			{
				DeliveryPackagePatch.maxDeliveryGridIndex = num;
				break;
			}
		}
		Log.LogDebug($"DeliveryPackage:{__instance.rowCount}x{__instance.colCount} stack:{__instance.stackSizeMultiplier} maxIndex:{DeliveryPackagePatch.maxDeliveryGridIndex}");
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlayerPackageUtility), "AddItemToAllPackages")]
	private static void AddItemToAllPackages(ref int priorityMode)
	{
		if (DeliveryFirst.Value)
		{
			priorityMode = -1;
		}
	}
}
