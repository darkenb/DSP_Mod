using HarmonyLib;

namespace DeliverySlotsTweaks;

public class UIBuildMenuPatch
{
	private static bool Initialized;

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIBuildMenu), "_OnRegEvent")]
	public static void AddEvents(UIBuildMenu __instance)
	{
		if (Initialized)
		{
			return;
		}
		Initialized = true;
		for (int i = 0; i < __instance.childButtons.Length; i++)
		{
			UIButton uIButton = __instance.childButtons[i];
			if (!(uIButton == null))
			{
				uIButton.data = i;
				uIButton.onRightClick += OnChildButtonRightClick;
			}
		}
	}

	private static void OnChildButtonRightClick(int index)
	{
		UIBuildMenu buildMenu = UIRoot.instance.uiGame.buildMenu;
		if (UIBuildMenu.protos[buildMenu.currentCategory, index] != null)
		{
			int iD = UIBuildMenu.protos[buildMenu.currentCategory, index].ID;
			ItemProto itemProto = LDB.items.Select(iD);
			if (itemProto != null && itemProto.maincraft != null)
			{
				TryReplicateItem(itemProto);
			}
		}
	}

	private static void TryReplicateItem(ItemProto itemProto)
	{
		RecipeProto maincraft = itemProto.maincraft;
		if (maincraft == null)
		{
			return;
		}
		int iD = maincraft.ID;
		int num = 1;
		if (!maincraft.Handcraft)
		{
			UIRealtimeTip.Popup("该配方".Translate() + maincraft.madeFromString + "生产".Translate());
			return;
		}
		if (!GameMain.history.RecipeUnlocked(iD))
		{
			UIRealtimeTip.Popup("配方未解锁".Translate());
			return;
		}
		MechaForge forge = GameMain.mainPlayer.mecha.forge;
		int num2 = forge.PredictTaskCount(iD);
		if (num > num2)
		{
			num = num2;
		}
		if (num == 0)
		{
			UIRealtimeTip.Popup("材料不足".Translate());
			return;
		}
		if (forge.AddTask(iD, num) == null)
		{
			UIRealtimeTip.Popup("材料不足".Translate());
			return;
		}
		GameMain.history.RegFeatureKey(1000104);
		int num3 = 0;
		if (maincraft.ResultCounts != null && maincraft.ResultCounts.Length != 0)
		{
			num3 = maincraft.ResultCounts[0];
		}
		UIRealtimeTip.Popup(string.Format("Crafting {0} [{1}]".Translate(), itemProto.name, num3), sound: false);
	}
}
