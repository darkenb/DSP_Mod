using System;
using BepInEx.Bootstrap;
using BepInEx.Configuration;
using HarmonyLib;
using NebulaAPI;
using NebulaAPI.GameState;

namespace DeliverySlotsTweaks;

public class Compatibility
{
	public static class Auxilaryfunction_Patch
	{
		public const string GUID = "cn.blacksnipe.dsp.Auxilaryfunction";

		public static void Init(Harmony harmony)
		{
			try
			{
				if (Chainloader.PluginInfos.TryGetValue("cn.blacksnipe.dsp.Auxilaryfunction", out var value))
				{
					Type type = value.Instance.GetType().Assembly.GetType("Auxilaryfunction.Auxilaryfunction");
					harmony.Patch(AccessTools.Method(type, "AutoMovetounbuilt"), null, null, new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("UIBuildMenu_Transpiler")));
				}
			}
			catch (Exception data)
			{
				Plugin.Log.LogWarning("Auxilaryfunction compatibility failed! Last working version: 3.0.1");
				Plugin.Log.LogWarning(data);
			}
		}
	}

	public static class UXAssist_Patch
	{
		public const string GUID = "org.soardev.uxassist";

		public static void Init(Harmony harmony)
		{
			if (!Chainloader.PluginInfos.TryGetValue("org.soardev.uxassist", out var value))
			{
				return;
			}
			try
			{
				Type type = value.Instance.GetType().Assembly.GetType("UXAssist.Patches.Logistics.LogisticsPatch");
				harmony.Patch(AccessTools.Method(type, "StationFillDrones"), null, null, new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("TakeItem_Transpiler")));
				harmony.Patch(AccessTools.Method(type, "StationFillShips"), null, null, new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("TakeItem_Transpiler")));
				harmony.Patch(AccessTools.Method(type, "DispenserFillCouriers"), null, null, new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("TakeItem_Transpiler")));
			}
			catch (Exception data)
			{
				Plugin.Log.LogWarning("UXAssist compatibility failed! Last working version: 1.6.0");
				Plugin.Log.LogWarning(data);
			}
		}
	}

	public static class CheatEnabler_Patch
	{
		public const string GUID = "org.soardev.cheatenabler";

		private static ConfigEntry<bool> ArchitectModeEnabled;

		public static void Init(Harmony _)
		{
			if (!Chainloader.PluginInfos.TryGetValue("org.soardev.cheatenabler", out var value))
			{
				return;
			}
			IsArchitectModeModExist = true;
			try
			{
				ArchitectModeEnabled = (ConfigEntry<bool>)AccessTools.Field(value.Instance.GetType().Assembly.GetType("CheatEnabler.Patches.Factory.FactoryPatch"), "ArchitectModeEnabled").GetValue(null);
				ArchitectModeEnabled.SettingChanged += OnArchitectModeEnabledChange;
				DeliveryPackagePatch.architectMode |= ArchitectModeEnabled.Value;
				Plugin.Log.LogDebug("CheatEnabler ArchitectModeEnabled: " + ArchitectModeEnabled.Value);
			}
			catch (Exception data)
			{
				Plugin.Log.LogWarning("CheatEnabler compatibility failed! Last working version: 2.4.5");
				Plugin.Log.LogWarning(data);
			}
		}

		internal static void OnArchitectModeEnabledChange(object sender, EventArgs e)
		{
			if (ArchitectModeEnabled != null)
			{
				DeliveryPackagePatch.architectMode = ArchitectModeEnabled.Value;
				Plugin.Log.LogDebug("CheatEnabler ArchitectModeEnabled: " + DeliveryPackagePatch.architectMode);
			}
		}
	}

	public static class Multfunction_mod_Patch
	{
		public const string GUID = "cn.blacksnipe.dsp.Multfuntion_mod";

		private static ConfigEntry<bool> architectMode;

		public static void Init(Harmony harmony)
		{
			try
			{
				if (Chainloader.PluginInfos.TryGetValue("cn.blacksnipe.dsp.Multfuntion_mod", out var value))
				{
					IsArchitectModeModExist = true;
					Type type = value.Instance.GetType().Assembly.GetType("Multifunction_mod.GUIDraw");
					harmony.Patch(AccessTools.Method(type, "BuildPannel"), null, new HarmonyMethod(typeof(Multfunction_mod_Patch).GetMethod("BuildPannel_Postfix")));
					architectMode = (ConfigEntry<bool>)AccessTools.Field(AccessTools.TypeByName("Multifunction_mod.Multifunction"), "ArchitectMode").GetValue(null);
					DeliveryPackagePatch.architectMode |= architectMode.Value;
					Plugin.Log.LogDebug("Multfunction_mod ArchitectModeEnabled: " + architectMode.Value);
				}
			}
			catch (Exception data)
			{
				Plugin.Log.LogWarning("Multfunction_mod compatibility failed! Last working version: 4.0.1");
				Plugin.Log.LogWarning(data);
			}
		}

		public static void BuildPannel_Postfix()
		{
			DeliveryPackagePatch.architectMode = architectMode.Value;
		}
	}

	public static class Nebula_Patch
	{
		public const string GUID = "dsp.nebula-multiplayer";

		private static bool IsPatched;

		public static bool IsActive { get; private set; }

		public static void Init(Harmony harmony)
		{
			try
			{
				if (Chainloader.PluginInfos.TryGetValue("dsp.nebula-multiplayer", out var _))
				{
					Patch(harmony);
				}
			}
			catch (Exception data)
			{
				Plugin.Log.LogWarning("Nebula compatibility failed!");
				Plugin.Log.LogWarning(data);
			}
		}

		public static bool IsOthers()
		{
			IFactoryManager factories = NebulaModAPI.MultiplayerSession.Factories;
			if (factories.IsIncomingRequest.Value)
			{
				return factories.PacketAuthor != NebulaModAPI.MultiplayerSession.LocalPlayer.Id;
			}
			return false;
		}

		private static void Patch(Harmony harmony)
		{
			if (NebulaModAPI.NebulaIsInstalled && !IsPatched)
			{
				NebulaModAPI.OnMultiplayerGameStarted = (Action)Delegate.Combine(NebulaModAPI.OnMultiplayerGameStarted, new Action(OnMultiplayerGameStarted));
				NebulaModAPI.OnMultiplayerGameEnded = (Action)Delegate.Combine(NebulaModAPI.OnMultiplayerGameEnded, new Action(OnMultiplayerGameEnded));
				Type type = AccessTools.TypeByName("NebulaWorld.SimulatedWorld");
				harmony.Patch(AccessTools.Method(type, "SetupInitialPlayerState"), null, new HarmonyMethod(AccessTools.Method(typeof(Plugin), "ApplyConfigs")));
				IsPatched = true;
			}
		}

		private static void OnMultiplayerGameStarted()
		{
			IsActive = NebulaModAPI.IsMultiplayerActive;
		}

		private static void OnMultiplayerGameEnded()
		{
			IsActive = false;
		}
	}

	public static class RebindBuildBar_Patch
	{
		public const string GUID = "org.kremnev8.plugin.RebindBuildBar";

		public static void Init(Harmony harmony)
		{
			try
			{
				if (Chainloader.PluginInfos.TryGetValue("org.kremnev8.plugin.RebindBuildBar", out var value))
				{
					Type type = value.Instance.GetType().Assembly.GetType("RebindBuildBar.Patches");
					harmony.Patch(AccessTools.Method(type, "EnableButton"), null, null, new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("UIBuildMenu_Transpiler")));
				}
			}
			catch (Exception data)
			{
				Plugin.Log.LogWarning("RebindBuildBar compatibility failed! Last working version: 1.0.4");
				Plugin.Log.LogWarning(data);
			}
		}
	}

	public static class UnlimitedFoundations_Patch
	{
		public const string GUID1 = "com.aekoch.mods.dsp.UnlimitedFoundations";

		public const string GUID2 = "com.tinysquid.infinitefoundations";

		public static void Init(Harmony harmony)
		{
			try
			{
				if (Chainloader.PluginInfos.ContainsKey("com.aekoch.mods.dsp.UnlimitedFoundations") || Chainloader.PluginInfos.ContainsKey("com.tinysquid.infinitefoundations"))
				{
					harmony.Patch(AccessTools.Method(typeof(DeliveryPackagePatch), "GetItemCount"), null, new HarmonyMethod(typeof(UnlimitedFoundations_Patch).GetMethod("GetItemCount_Postfix")));
				}
			}
			catch (Exception data)
			{
				Plugin.Log.LogWarning("UnlimitedFoundations compatibility failed!");
				Plugin.Log.LogWarning(data);
			}
		}

		public static void GetItemCount_Postfix(int itemId, ref int __result)
		{
			if (itemId == 1131)
			{
				__result = 9999;
			}
		}
	}

	public static class FractionateEverything_Patch
	{
		public const string GUID = "com.menglei.dsp.fe";

		public static void Init()
		{
			if (Chainloader.PluginInfos.ContainsKey("com.menglei.dsp.fe"))
			{
				Plugin.Log.LogInfo("Disable UseLogisticSlots functions as FractionateEverything mod exist!");
				IsDeliveryPackageModExist = true;
			}
		}
	}

	public static bool IsArchitectModeModExist { get; private set; }

	public static bool IsDeliveryPackageModExist { get; private set; }

	public static void Init(Harmony harmony)
	{
		Multfunction_mod_Patch.Init(harmony);
		UXAssist_Patch.Init(harmony);
		CheatEnabler_Patch.Init(harmony);
		RebindBuildBar_Patch.Init(harmony);
		UnlimitedFoundations_Patch.Init(harmony);
		Nebula_Patch.Init(harmony);
		FractionateEverything_Patch.Init();
	}
}
