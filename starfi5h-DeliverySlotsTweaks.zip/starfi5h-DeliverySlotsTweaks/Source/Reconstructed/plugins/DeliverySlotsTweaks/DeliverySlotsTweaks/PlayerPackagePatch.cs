using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;

namespace DeliverySlotsTweaks;

public class PlayerPackagePatch
{
	private static int packageStacksize = 1000;

	private static int packageStackMultiplier = 1;

	public static void OnConfigChange()
	{
		packageStackMultiplier = 1;
		if (Plugin.PlayerPackageStackSize.Value > 0)
		{
			packageStacksize = Plugin.PlayerPackageStackSize.Value;
			Plugin.Log.LogDebug("PlayerPackage stack count:" + packageStacksize);
			if (GameMain.mainPlayer == null)
			{
				return;
			}
			StorageComponent.GRID[] grids = GameMain.mainPlayer.package.grids;
			for (int i = 0; i < GameMain.mainPlayer.package.size; i++)
			{
				if (grids[i].filter > 0)
				{
					grids[i].stackSize = packageStacksize;
				}
			}
		}
		else
		{
			if (Plugin.PlayerPackageStackMultiplier.Value <= 0)
			{
				return;
			}
			packageStackMultiplier = Plugin.PlayerPackageStackMultiplier.Value;
			Plugin.Log.LogDebug("PlayerPackage stack multiplier:" + packageStackMultiplier);
			if (GameMain.mainPlayer == null)
			{
				return;
			}
			StorageComponent.GRID[] grids2 = GameMain.mainPlayer.package.grids;
			for (int j = 0; j < GameMain.mainPlayer.package.size; j++)
			{
				int filter = grids2[j].filter;
				if (filter > 0 && filter < StorageComponent.itemStackCount.Length)
				{
					grids2[j].stackSize = StorageComponent.itemStackCount[filter] * packageStackMultiplier;
				}
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(StorageComponent), "SetFilter")]
	public static void OverwritePlayerPackageStacksize2(StorageComponent __instance, int gridIndex, int filterId)
	{
		if (filterId > 0 && IsPlayerStorage(__instance))
		{
			if (Plugin.PlayerPackageStackSize.Value > 0)
			{
				__instance.grids[gridIndex].stackSize = packageStacksize;
			}
			else
			{
				__instance.grids[gridIndex].stackSize = StorageComponent.itemStackCount[filterId] * packageStackMultiplier;
			}
		}
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(StorageComponent), "AddItem", new Type[]
	{
		typeof(int),
		typeof(int),
		typeof(int),
		typeof(int),
		typeof(int),
		typeof(int)
	}, new ArgumentType[]
	{
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Out
	})]
	[HarmonyPatch(typeof(StorageComponent), "AddItemStacked")]
	[HarmonyPatch(typeof(StorageComponent), "Sort")]
	[HarmonyPatch(typeof(StorageComponent), "AddItemForSort")]
	private static IEnumerable<CodeInstruction> OverwritePlayerPackageStacksize(IEnumerable<CodeInstruction> instructions, ILGenerator il)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, il);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldsfld, AccessTools.Field(typeof(StorageComponent), "itemStackCount"))).Advance(1).CreateLabelAt(codeMatcher.Pos, out var label);
		int pos = codeMatcher.Pos;
		codeMatcher.MatchForward(false, new CodeMatch((CodeInstruction i) => i.IsStloc())).CreateLabelAt(codeMatcher.Pos, out var label2);
		if (Plugin.PlayerPackageStackSize.Value > 0)
		{
			codeMatcher.Advance(pos - codeMatcher.Pos);
			codeMatcher.Insert(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(PlayerPackagePatch), "IsPlayerStorage")), new CodeInstruction(OpCodes.Brfalse_S, label), new CodeInstruction(OpCodes.Pop), new CodeInstruction(OpCodes.Ldsfld, AccessTools.Field(typeof(PlayerPackagePatch), "packageStacksize")), new CodeInstruction(OpCodes.Br_S, label2));
		}
		else
		{
			codeMatcher.Insert(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(PlayerPackagePatch), "IsPlayerStorage")), new CodeInstruction(OpCodes.Brfalse_S, label2), new CodeInstruction(OpCodes.Ldsfld, AccessTools.Field(typeof(PlayerPackagePatch), "packageStackMultiplier")), new CodeInstruction(OpCodes.Mul));
		}
		return codeMatcher.Instructions();
	}

	public static bool IsPlayerStorage(StorageComponent storageComponent)
	{
		if (storageComponent != GameMain.mainPlayer.package)
		{
			return storageComponent == GameMain.mainPlayer.mecha.reactorStorage;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PackageStatistics), "Count")]
	private static bool CountOverwrite(PackageStatistics __instance, StorageComponent package)
	{
		if (!IsPlayerStorage(package))
		{
			return true;
		}
		__instance.itemBundle.Clear();
		ref StorageComponent.GRID[] grids = ref package.grids;
		int num = 0;
		if (packageStackMultiplier > 1)
		{
			int[] itemStackCount = StorageComponent.itemStackCount;
			for (int i = 0; i < package.size; i++)
			{
				int itemId = grids[i].itemId;
				if (itemId > 0)
				{
					__instance.itemBundle.Add(itemId, grids[i].count, itemStackCount[itemId] * packageStackMultiplier - grids[i].count);
				}
				else
				{
					num++;
				}
			}
			if (num > 0)
			{
				int[] itemIds = ItemProto.itemIds;
				int num2 = itemIds.Length;
				for (int j = 0; j < num2; j++)
				{
					__instance.itemBundle.Add(itemIds[j], 0, itemStackCount[itemIds[j]] * packageStackMultiplier * num);
				}
			}
		}
		else
		{
			for (int k = 0; k < package.size; k++)
			{
				int itemId2 = grids[k].itemId;
				if (itemId2 > 0)
				{
					__instance.itemBundle.Add(itemId2, grids[k].count, packageStacksize - grids[k].count);
				}
				else
				{
					num++;
				}
			}
			if (num > 0)
			{
				int[] itemIds2 = ItemProto.itemIds;
				for (int l = 0; l < itemIds2.Length; l++)
				{
					__instance.itemBundle.Add(itemIds2[l], 0, packageStacksize * num);
				}
			}
		}
		return false;
	}
}
