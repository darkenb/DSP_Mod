using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;

namespace DeliverySlotsTweaks;

public class DeliveryPackagePatch
{
	public static bool architectMode = false;

	public static int maxDeliveryGridIndex = 0;

	private static readonly Dictionary<int, int> packageItemCount = new Dictionary<int, int>();

	private static readonly Dictionary<int, int> deliveryItemCount = new Dictionary<int, int>();

	private static readonly Dictionary<int, int> deliveryGridindex = new Dictionary<int, int>();

	public static void Count(StorageComponent package)
	{
		packageItemCount.Clear();
		StorageComponent.GRID[] grids = package.grids;
		int num = ((package.size < grids.Length) ? package.size : grids.Length);
		for (int i = 0; i < num; i++)
		{
			int itemId = grids[i].itemId;
			if (itemId > 0)
			{
				if (packageItemCount.ContainsKey(itemId))
				{
					packageItemCount[itemId] += grids[i].count;
				}
				else
				{
					packageItemCount.Add(itemId, grids[i].count);
				}
			}
		}
	}

	public static void Count(DeliveryPackage package)
	{
		deliveryItemCount.Clear();
		deliveryGridindex.Clear();
		if (package?.grids == null)
		{
			return;
		}
		DeliveryPackage.GRID[] grids = package.grids;
		for (int i = 0; i < grids.Length; i++)
		{
			if (!package.IsGridActive(i))
			{
				continue;
			}
			int itemId = grids[i].itemId;
			if (itemId > 0)
			{
				deliveryItemCount.TryGetValue(itemId, out var value);
				deliveryItemCount[itemId] = (int)Math.Min(2147483647L, (long)value + (long)Math.Max(0, grids[i].count));
				if (!deliveryGridindex.ContainsKey(itemId))
				{
					deliveryGridindex.Add(itemId, i);
				}
			}
		}
	}

	public static int GetItemCount(StorageComponent _, int itemId)
	{
		if (architectMode)
		{
			return 999;
		}
		packageItemCount.TryGetValue(itemId, out var value);
		deliveryItemCount.TryGetValue(itemId, out var value2);
		return (int)Math.Min(2147483647L, (long)value + (long)value2);
	}

	public static int GetItemCountDummy(StorageComponent _, int itemId)
	{
		return 999;
	}

	public static int TakeItem(StorageComponent storage, int itemId, int count, out int inc)
	{
		if (architectMode)
		{
			inc = 0;
			return count;
		}
		if (deliveryGridindex.TryGetValue(itemId, out var value))
		{
			GameMain.mainPlayer.packageUtility.TakeItemFromAllPackages(value, ref itemId, ref count, out inc, deliveryFirst: false);
			return count;
		}
		return storage.TakeItem(itemId, count, out inc);
	}

	public static void TakeTailItems(StorageComponent storage, ref int itemId, ref int count, out int inc, bool _)
	{
		if (architectMode)
		{
			inc = 0;
			return;
		}
		if (Compatibility.Nebula_Patch.IsActive && Compatibility.Nebula_Patch.IsOthers())
		{
			inc = 0;
			return;
		}
		if (deliveryGridindex.TryGetValue(itemId, out var value))
		{
			int num = itemId;
			GameMain.mainPlayer.packageUtility.TakeItemFromAllPackages(value, ref itemId, ref count, out inc, deliveryFirst: false);
			itemId = num;
			if (packageItemCount.ContainsKey(itemId))
			{
				int num2 = packageItemCount[itemId] - count;
				packageItemCount[itemId] = num2;
				if (num2 <= 0)
				{
					packageItemCount.Remove(itemId);
				}
			}
			else if (deliveryItemCount.ContainsKey(itemId))
			{
				int num3 = deliveryItemCount[itemId] - count;
				deliveryItemCount[itemId] = num3;
				if (num3 <= 0)
				{
					deliveryItemCount.Remove(itemId);
				}
			}
			return;
		}
		storage.TakeTailItems(ref itemId, ref count, out inc);
		if (packageItemCount.ContainsKey(itemId))
		{
			int num4 = packageItemCount[itemId] - count;
			packageItemCount[itemId] = num4;
			if (num4 <= 0)
			{
				packageItemCount.Remove(itemId);
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(Mecha), "GameTick")]
	public static void Prepare(Mecha __instance, long time)
	{
		if (__instance?.player != null && __instance.player == GameMain.mainPlayer)
		{
			Count(__instance.player.package);
			Count(__instance.player.deliveryPackage);
			if (time % 30 == 0L && Plugin.AutoRefillWarper.Value)
			{
				TryReillWarper(__instance);
			}
		}
	}

	private static void TryReillWarper(Mecha mecha)
	{
		if (!mecha.HasWarper())
		{
			int itemId = 1210;
			int count = 1;
			if (GetItemCount(null, itemId) > 0)
			{
				TakeTailItems(mecha.player.package, ref itemId, ref count, out var inc, _: false);
				mecha.warpStorage.AddItem(itemId, count, inc, out var _);
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(StorageComponent), "Sort")]
	public static void Sort_Prefix(StorageComponent __instance)
	{
		if (!Plugin.SortToDelieverySlots.Value || __instance != GameMain.mainPlayer?.package)
		{
			return;
		}
		StorageComponent.GRID[] grids = __instance.grids;
		DeliveryPackage deliveryPackage = GameMain.mainPlayer.deliveryPackage;
		for (int num = ((__instance.size < __instance.grids.Length) ? __instance.size : __instance.grids.Length) - 1; num > 0; num--)
		{
			ref StorageComponent.GRID reference = ref grids[num];
			int itemId = reference.itemId;
			if (itemId > 0 && deliveryGridindex.ContainsKey(itemId))
			{
				int remainInc;
				int num2 = deliveryPackage.AddItem(deliveryGridindex[itemId], itemId, reference.count, reference.inc, out remainInc);
				reference.count -= num2;
				reference.inc = remainInc;
			}
		}
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(ConstructionModuleComponent), "PlaceItems")]
	public static IEnumerable<CodeInstruction> PlaceItems_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions);
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Br), new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(ConstructionModuleComponent), "entityId")), new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch(OpCodes.Ble)).Insert(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldarg_2), new CodeInstruction(OpCodes.Ldloca_S, (byte)0), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(DeliveryPackagePatch), "AddConstructableCountsInStorage")));
			codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldarg_2), new CodeMatch(OpCodes.Callvirt, AccessTools.DeclaredPropertyGetter(typeof(Player), "package")), new CodeMatch(OpCodes.Ldloca_S), new CodeMatch(OpCodes.Ldloca_S), new CodeMatch(OpCodes.Ldloca_S), new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Callvirt && ((MethodInfo)i.operand).Name == "TakeTailItems")).Repeat(delegate(CodeMatcher matcher)
			{
				matcher.SetAndAdvance(OpCodes.Call, AccessTools.Method(typeof(DeliveryPackagePatch), "TakeTailItems"));
			});
			return codeMatcher.InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler PlaceItems error");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	private static void AddConstructableCountsInStorage(ConstructionModuleComponent constructionModule, Player player, ref int num)
	{
		if (player?.deliveryPackage == null)
		{
			return;
		}
		ConstructionModuleComponent.ConstructableCount[] constructableCountsInStorage = constructionModule.constructableCountsInStorage;
		DeliveryPackage.GRID[] grids = player.deliveryPackage.grids;
		for (int i = 0; i < grids.Length; i++)
		{
			if (player.deliveryPackage.IsGridActive(i))
			{
				int itemId = grids[i].itemId;
				if (itemId > 0 && ItemProto.constructableIdHash.Contains(itemId))
				{
					int count = grids[i].count;
					int num2 = ItemProto.constructableIndiceById[itemId];
					constructableCountsInStorage[num2].haveCount += count;
					num += count;
				}
			}
		}
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(MechaForge), "TryAddTask")]
	[HarmonyPatch(typeof(MechaForge), "TryTaskWithTestPackage")]
	public static IEnumerable<CodeInstruction> TryAddTask_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			return new CodeMatcher(instructions).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Call && ((MethodInfo)i.operand).Name == "TryAddTaskIterate")).SetAndAdvance(OpCodes.Call, AccessTools.Method(typeof(DeliveryPackagePatch), "TryAddTaskIterate")).InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler TryAddTask error");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	public static bool TryAddTaskIterate(MechaForge mechaForge, RecipeProto recipe, int count, out bool useBottleneckItem, bool predictBottleneckItems)
	{
		Count(mechaForge.player.deliveryPackage);
		foreach (KeyValuePair<int, int> item in deliveryItemCount)
		{
			mechaForge._test_pack.Alter(item.Key, item.Value);
		}
		return mechaForge.TryAddTaskIterate(recipe, count, out useBottleneckItem, predictBottleneckItems);
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(MechaForge), "AddTaskIterate")]
	[HarmonyPatch(typeof(Mecha), "AutoReplenishAmmo")]
	[HarmonyPatch(typeof(Mecha), "AutoReplenishBomb")]
	public static IEnumerable<CodeInstruction> TakeItem_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			return new CodeMatcher(instructions).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Callvirt && ((MethodInfo)i.operand).Name == "TakeItem")).Repeat(delegate(CodeMatcher matcher)
			{
				matcher.SetAndAdvance(OpCodes.Call, AccessTools.Method(typeof(DeliveryPackagePatch), "TakeItem"));
			}).InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler StorageComponent.TakeItem error");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(BuildTool_Reform), "DoFlattenExecute")]
	[HarmonyPatch(typeof(BuildTool_Reform), "RemoveBasePit")]
	[HarmonyPatch(typeof(PlanetFactory), "EntityAutoReplenishIfNeeded")]
	[HarmonyPatch(typeof(PlanetFactory), "StationAutoReplenishIfNeeded")]
	[HarmonyPatch(typeof(PlayerAction_Inspect), "GameTick")]
	[HarmonyPatch(typeof(UIBlueprintInspector), "OnPlayerPackageChange")]
	[HarmonyPatch(typeof(UIBlueprintInspector), "SetComponentItem")]
	[HarmonyPatch(typeof(UIBuildMenu), "_OnUpdate")]
	[HarmonyPatch(typeof(UIBuildMenu), "OnChildButtonClick")]
	[HarmonyPatch(typeof(UIHandTip), "_OnUpdate")]
	[HarmonyPatch(typeof(UIRemoveBasePitButton), "_OnUpdate")]
	[HarmonyPatch(typeof(UITurretWindow), "OnHandFillAmmoButtonClick")]
	public static IEnumerable<CodeInstruction> UIBuildMenu_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			return new CodeMatcher(instructions).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Callvirt && ((MethodInfo)i.operand).Name == "GetItemCount")).Repeat(delegate(CodeMatcher matcher)
			{
				matcher.SetAndAdvance(OpCodes.Call, AccessTools.Method(typeof(DeliveryPackagePatch), "GetItemCount"));
			}).InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler UIBuildMenu._OnUpdate error");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	[HarmonyTranspiler]
	[HarmonyAfter(new string[] { "dsp.nebula-multiplayer" })]
	[HarmonyPatch(typeof(BuildTool_Click), "CreatePrebuilds")]
	[HarmonyPatch(typeof(BuildTool_Path), "CreatePrebuilds")]
	[HarmonyPatch(typeof(BuildTool_Addon), "CreatePrebuilds")]
	[HarmonyPatch(typeof(BuildTool_Inserter), "CreatePrebuilds")]
	[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "CreatePrebuilds")]
	[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "DetermineReforms")]
	[HarmonyPatch(typeof(BuildTool_Reform), "ConsumeItemsAndRegisterStats")]
	[HarmonyPatch(typeof(BuildTool_Reform), "RemoveBasePit")]
	[HarmonyPatch(typeof(PlanetFactory), "EntityAutoReplenishIfNeeded")]
	[HarmonyPatch(typeof(PlanetFactory), "StationAutoReplenishIfNeeded")]
	[HarmonyPatch(typeof(Player), "TakeItemFromPlayer")]
	[HarmonyPatch(typeof(PlayerAction_Build), "DoUpgradeObject")]
	[HarmonyPatch(typeof(PlayerAction_Inspect), "GameTick")]
	[HarmonyPatch(typeof(UITurretWindow), "OnHandFillAmmoButtonClick")]
	public static IEnumerable<CodeInstruction> CheckBuildConditions_Transpiler(IEnumerable<CodeInstruction> instructions, MethodBase __originalMethod)
	{
		try
		{
			int num = 1;
			if (__originalMethod.DeclaringType.Name == "BuildTool_BlueprintPaste" && __originalMethod.Name == "CreatePrebuilds")
			{
				num = 2;
			}
			else if (__originalMethod.Name == "StationAutoReplenishIfNeeded")
			{
				num = 2;
			}
			else if (__originalMethod.Name == "EntityAutoReplenishIfNeeded")
			{
				num = 3;
			}
			CodeMatcher codeMatcher = new CodeMatcher(instructions).End();
			for (int i = 0; i < num; i++)
			{
				codeMatcher.MatchBack(false, new CodeMatch((CodeInstruction codeInstruction) => codeInstruction.opcode == OpCodes.Callvirt && ((MethodInfo)codeInstruction.operand).Name == "TakeTailItems")).SetAndAdvance(OpCodes.Call, AccessTools.Method(typeof(DeliveryPackagePatch), "TakeTailItems"));
			}
			return codeMatcher.InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler CreatePrebuilds error");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "CalculateReformData")]
	[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "DetermineReforms")]
	public static IEnumerable<CodeInstruction> TmpPackage_Transpiler(IEnumerable<CodeInstruction> instructions, MethodBase __originalMethod)
	{
		try
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Call && ((MethodInfo)i.operand).Name == "Copy"));
			object operand = codeMatcher.InstructionAt(-1).operand;
			if (operand != null && ((FieldInfo)operand).Name == "size")
			{
				codeMatcher.Advance(-3).RemoveInstructions(3);
			}
			else
			{
				if (operand != null)
				{
					Plugin.Log.LogWarning("Transpiler TmpPackage_Transpiler unexpected operand!");
					return instructions;
				}
				codeMatcher.Advance(-5).RemoveInstructions(5);
			}
			codeMatcher.Insert(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Call, AccessTools.PropertyGetter(typeof(BuildTool), "player")), new CodeInstruction(OpCodes.Callvirt, AccessTools.PropertyGetter(typeof(Player), "package")), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(StorageComponent), "size")));
			return codeMatcher.InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler TmpPackage_Transpiler error: " + __originalMethod.Name);
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(PlayerAction_Build), "GameTick")]
	public static IEnumerable<CodeInstruction> PlayerAction_Build_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			return new CodeMatcher(instructions).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Callvirt && ((MethodInfo)i.operand).Name == "_GameTick")).SetAndAdvance(OpCodes.Call, AccessTools.Method(typeof(DeliveryPackagePatch), "BuildTool_GameTick")).InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler PlayerAction_Build.GameTick error");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	public static void BuildTool_GameTick(BuildTool @this, long time)
	{
		if (@this.active)
		{
			@this.mouseRay = @this.mainCamera.ScreenPointToRay(Input.mousePosition);
			@this.SetFactoryReferences();
			int num = @this.player.package.size + maxDeliveryGridIndex + 1;
			if (@this.tmpPackage == null)
			{
				@this.tmpPackage = new StorageComponent(num);
			}
			if (@this.tmpPackage.size != num)
			{
				@this.tmpPackage.SetSize(num);
			}
			Array.Copy(@this.player.package.grids, @this.tmpPackage.grids, @this.player.package.size);
			DeliveryPackage.GRID[] grids = @this.player.deliveryPackage.grids;
			for (int i = @this.player.package.size; i < num; i++)
			{
				ref DeliveryPackage.GRID reference = ref grids[i - @this.player.package.size];
				@this.tmpPackage.grids[i].itemId = reference.itemId;
				@this.tmpPackage.grids[i].count = reference.count;
			}
			@this.tmpInhandId = @this.player.inhandItemId;
			@this.tmpInhandCount = @this.player.inhandItemCount;
			try
			{
				@this._OnTick(time);
			}
			catch (Exception message)
			{
				Debug.LogError(message);
			}
			@this.frame++;
		}
	}
}
