using System;
using System.Reflection;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace DSPCompleteReplicatorQueue;

[HarmonyPatch]
internal static class WindowUI
{
	private static UIReplicatorWindow owner;

	private static Button button;

	private static Text label;

	private static bool createFailed;

	private static readonly FieldInfo ForgeField = typeof(UIReplicatorWindow).GetField("mechaForge", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

	private static MechaForge GetForge(UIReplicatorWindow window)
	{
		if (!(window != null) || !(ForgeField != null))
		{
			return null;
		}
		return ForgeField.GetValue(window) as MechaForge;
	}

	internal static void Remove()
	{
		if (button != null)
		{
			button.onClick.RemoveAllListeners();
			button.gameObject.SetActive(value: false);
			UnityEngine.Object.Destroy(button.gameObject);
		}
		button = null;
		label = null;
		owner = null;
		createFailed = false;
	}

	private static void Ensure(UIReplicatorWindow window)
	{
		if ((button != null && owner == window) || (createFailed && owner == window))
		{
			return;
		}
		Remove();
		owner = window;
		GameObject gameObject = null;
		try
		{
			Transform transform = window.transform.Find("panel-bg");
			if (!(transform == null) && !(window.minusButton == null))
			{
				Image component = window.minusButton.GetComponent<Image>();
				gameObject = new GameObject("DSPCompleteReplicatorQueueButton", typeof(RectTransform), typeof(Image), typeof(Button));
				gameObject.SetActive(value: false);
				gameObject.transform.SetParent(transform, worldPositionStays: false);
				RectTransform component2 = gameObject.GetComponent<RectTransform>();
				RectTransform rectTransform = transform.Find("btn-box") as RectTransform;
				component2.anchorMin = ((rectTransform != null) ? rectTransform.anchorMin : new Vector2(1f, 1f));
				component2.anchorMax = ((rectTransform != null) ? rectTransform.anchorMax : new Vector2(1f, 1f));
				component2.pivot = new Vector2(1f, 0.5f);
				component2.sizeDelta = new Vector2(235f, 30f);
				component2.anchoredPosition = new Vector2(-28f, -65f);
				Image component3 = gameObject.GetComponent<Image>();
				if (component != null)
				{
					component3.sprite = component.sprite;
					component3.type = component.type;
					component3.material = component.material;
				}
				component3.color = Color.white;
				button = gameObject.GetComponent<Button>();
				button.targetGraphic = component3;
				ColorBlock colors = button.colors;
				colors.normalColor = new Color(0.05f, 0.09f, 0.09f, 0.25f);
				colors.highlightedColor = new Color(0.16f, 0.18f, 0.18f, 0.7f);
				colors.pressedColor = new Color(0.18f, 0.27f, 0.27f, 0.7f);
				colors.disabledColor = new Color(0.05f, 0.09f, 0.09f, 0.05f);
				button.colors = colors;
				GameObject gameObject2 = new GameObject("text", typeof(RectTransform), typeof(Text));
				gameObject2.transform.SetParent(gameObject.transform, worldPositionStays: false);
				RectTransform component4 = gameObject2.GetComponent<RectTransform>();
				component4.anchorMin = Vector2.zero;
				component4.anchorMax = Vector2.one;
				component4.offsetMin = Vector2.zero;
				component4.offsetMax = Vector2.zero;
				label = gameObject2.GetComponent<Text>();
				label.font = window.multiValueText.font;
				label.fontSize = 16;
				label.alignment = TextAnchor.MiddleCenter;
				label.color = new Color(0.95f, 0.95f, 0.95f, 1f);
				label.raycastTarget = false;
				label.text = "Complete Replication Queue";
				button.onClick.AddListener(delegate
				{
					InstantCraft.CompleteAllTasks(GetForge(owner));
				});
				gameObject.SetActive(value: true);
			}
		}
		catch (Exception ex)
		{
			if (gameObject != null)
			{
				UnityEngine.Object.Destroy(gameObject);
			}
			button = null;
			label = null;
			createFailed = true;
			if (Main.Instance != null)
			{
				Main.Instance.Log(ex);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIReplicatorWindow), "_OnCreate")]
	private static void Created(UIReplicatorWindow __instance)
	{
		Ensure(__instance);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIReplicatorWindow), "_OnOpen")]
	private static void Opened(UIReplicatorWindow __instance)
	{
		createFailed = false;
		Ensure(__instance);
	}

	[HarmonyPostfix]
	[HarmonyPriority(0)]
	[HarmonyPatch(typeof(UIReplicatorWindow), "_OnUpdate")]
	private static void Updated(UIReplicatorWindow __instance)
	{
		Ensure(__instance);
		if (!(button == null))
		{
			bool flag = Main.Instance != null && Main.Instance.Busy;
			MechaForge forge = GetForge(__instance);
			button.interactable = !flag && forge != null && forge.tasks != null && forge.tasks.Count > 0;
			label.text = (flag ? "Completing Queue..." : "Complete Replication Queue");
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIReplicatorWindow), "_OnFree")]
	private static void Freed(UIReplicatorWindow __instance)
	{
		if (owner == __instance && Main.Instance != null)
		{
			Main.Instance.Cancel();
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIReplicatorWindow), "_OnDestroy")]
	private static void Destroyed(UIReplicatorWindow __instance)
	{
		if (!(owner != __instance))
		{
			if (Main.Instance != null)
			{
				Main.Instance.Cancel();
			}
			Remove();
		}
	}
}
