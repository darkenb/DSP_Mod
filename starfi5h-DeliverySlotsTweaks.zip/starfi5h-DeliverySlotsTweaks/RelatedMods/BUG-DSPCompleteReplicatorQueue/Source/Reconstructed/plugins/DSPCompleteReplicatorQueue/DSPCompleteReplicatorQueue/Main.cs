using System;
using BepInEx;
using HarmonyLib;

namespace DSPCompleteReplicatorQueue;

[BepInPlugin("Appun.DSP.plugin.DSPCompleteReplicatorQueue", "DSPCompleteReplicatorQueue", "1.0.3")]
[BepInDependency("Appun.DSP.plugin.DSPReplicatorPlus", BepInDependency.DependencyFlags.SoftDependency)]
public sealed class Main : BaseUnityPlugin
{
	public const string Guid = "Appun.DSP.plugin.DSPCompleteReplicatorQueue";

	internal static Main Instance;

	private Harmony harmony;

	private QueueCompletion completion;

	internal bool Busy
	{
		get
		{
			if (completion != null)
			{
				return completion.Active;
			}
			return false;
		}
	}

	private void Awake()
	{
		Instance = this;
		harmony = new Harmony("Appun.DSP.plugin.DSPCompleteReplicatorQueue");
		harmony.PatchAll(typeof(WindowUI));
	}

	internal void Request(MechaForge forge)
	{
		if (!Busy)
		{
			completion = new QueueCompletion(forge);
			if (!completion.Active && completion.StopReason != null)
			{
				base.Logger.LogWarning(completion.StopReason);
			}
		}
	}

	private void Update()
	{
		if (!Busy)
		{
			return;
		}
		if (!GameMain.isRunning || GameMain.isLoading || GameMain.mainPlayer == null || completion.Forge.player != GameMain.mainPlayer)
		{
			Cancel();
		}
		else
		{
			if (GameMain.isPaused)
			{
				return;
			}
			QueueCompletion queueCompletion = completion;
			try
			{
				queueCompletion.ProcessBatch(GameMain.gameTick);
			}
			catch (Exception data)
			{
				base.Logger.LogError(data);
			}
			if (queueCompletion == completion && !queueCompletion.Active)
			{
				base.Logger.LogInfo("Complete Queue: " + queueCompletion.CompletedCycles + " native production cycles completed.");
				if (queueCompletion.StopReason != null)
				{
					base.Logger.LogWarning(queueCompletion.StopReason);
				}
			}
		}
	}

	internal void Cancel()
	{
		if (completion != null)
		{
			completion.Stop("Completion cancelled; remaining queue preserved.");
		}
		completion = null;
	}

	private void OnDestroy()
	{
		Cancel();
		WindowUI.Remove();
		if (harmony != null)
		{
			harmony.UnpatchSelf();
		}
		if ((object)Instance == this)
		{
			Instance = null;
		}
	}

	internal void Log(Exception ex)
	{
		base.Logger.LogError(ex);
	}
}
