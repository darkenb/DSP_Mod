using System;
using System.Collections.Generic;
using System.Diagnostics;

namespace DSPCompleteReplicatorQueue;

public sealed class QueueCompletion
{
	private readonly Dictionary<ForgeTask, int> observed = new Dictionary<ForgeTask, int>();

	private bool processing;

	public MechaForge Forge { get; private set; }

	public bool Active { get; private set; }

	public int CompletedCycles { get; private set; }

	public string StopReason { get; private set; }

	public QueueCompletion(MechaForge forge)
	{
		Forge = forge;
		if (forge == null || forge.tasks == null || forge.tasks.Count == 0)
		{
			return;
		}
		for (int i = 0; i < forge.tasks.Count; i++)
		{
			ForgeTask forgeTask = forge.tasks[i];
			if (!Valid(forgeTask) || observed.ContainsKey(forgeTask) || (forgeTask.parentTaskIndex >= 0 && (forgeTask.parentTaskIndex <= i || forgeTask.parentTaskIndex >= forge.tasks.Count)))
			{
				Stop("Invalid task state; queue left unchanged.");
				return;
			}
			observed.Add(forgeTask, forgeTask.count);
		}
		Active = true;
	}

	private static bool Valid(ForgeTask task)
	{
		if (task == null || task.count <= 0 || task.tickSpend <= 0 || task.itemIds == null || task.itemCounts == null || task.served == null || task.productIds == null || task.productCounts == null || task.produced == null || task.itemIds.Length != task.itemCounts.Length || task.served.Length != task.itemCounts.Length || task.productIds.Length != task.productCounts.Length || task.produced.Length != task.productCounts.Length)
		{
			return false;
		}
		for (int i = 0; i < task.itemCounts.Length; i++)
		{
			if (task.itemIds[i] <= 0 || task.itemCounts[i] <= 0 || task.served[i] < 0)
			{
				return false;
			}
		}
		for (int j = 0; j < task.productCounts.Length; j++)
		{
			if (task.productIds[j] <= 0 || task.productCounts[j] <= 0 || task.produced[j] != 0)
			{
				return false;
			}
		}
		return true;
	}

	public void Stop(string reason)
	{
		Active = false;
		StopReason = reason;
	}

	public int ProcessBatch(long gameTick, int maxCycles = 128, double maxMilliseconds = 4.0)
	{
		if (!Active || processing || maxCycles <= 0 || maxMilliseconds <= 0.0)
		{
			return 0;
		}
		int num = 0;
		Stopwatch stopwatch = Stopwatch.StartNew();
		processing = true;
		try
		{
			while (Active && num < maxCycles && stopwatch.Elapsed.TotalMilliseconds < maxMilliseconds)
			{
				if (Forge.tasks == null || Forge.player == null || Forge.mecha == null || !Forge.player.isAlive)
				{
					Stop("Forge or player is no longer available.");
					break;
				}
				if (Forge.tasks.Count == 0)
				{
					Stop(null);
					break;
				}
				ForgeTask forgeTask = Forge.tasks[0];
				if (forgeTask == null || !observed.TryGetValue(forgeTask, out var value) || forgeTask.count > value)
				{
					Stop("Queue changed; press Complete Queue again to include new tasks.");
					break;
				}
				if (!Valid(forgeTask) || !forgeTask.itemEnough || (forgeTask.parentTaskIndex >= 0 && (forgeTask.parentTaskIndex == 0 || forgeTask.parentTaskIndex >= Forge.tasks.Count || !observed.ContainsKey(Forge.tasks[forgeTask.parentTaskIndex]))))
				{
					Stop("Missing inputs or invalid task state; remaining queue preserved.");
					break;
				}
				int count = forgeTask.count;
				int tick = forgeTask.tick;
				forgeTask.tick = Math.Max(forgeTask.tick, forgeTask.tickSpend);
				try
				{
					Forge.GameTick(gameTick, 0f);
				}
				catch
				{
					if (forgeTask.count == count)
					{
						forgeTask.tick = tick;
					}
					Stop("Native forge raised an error; accelerated completion stopped.");
					throw;
				}
				if (forgeTask.count != count - 1)
				{
					if (forgeTask.count == count)
					{
						forgeTask.tick = tick;
					}
					Stop("Native forge made no expected progress; remaining queue preserved.");
					break;
				}
				observed[forgeTask] = forgeTask.count;
				num++;
				CompletedCycles++;
				if (Forge.tasks == null || Forge.tasks.Count == 0)
				{
					Stop(null);
				}
			}
		}
		finally
		{
			processing = false;
		}
		return num;
	}
}
