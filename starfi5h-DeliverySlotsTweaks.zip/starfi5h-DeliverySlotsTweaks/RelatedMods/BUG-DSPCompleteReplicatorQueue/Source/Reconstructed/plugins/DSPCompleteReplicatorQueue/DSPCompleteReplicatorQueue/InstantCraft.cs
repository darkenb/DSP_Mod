namespace DSPCompleteReplicatorQueue;

public static class InstantCraft
{
	public static void CompleteAllTasks(MechaForge forge)
	{
		if (Main.Instance != null)
		{
			Main.Instance.Request(forge);
		}
	}
}
