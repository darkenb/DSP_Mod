using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization;
using DSPCompleteReplicatorQueue;
using HarmonyLib;

// Runs real native GameTick/Produce/TaskFeed/TaskDeliver and real package/delivery
// storage. Only Unity presentation, trash spawning and external stat/scenario
// endpoints are replaced by recording sinks; no native forge method is mocked.
class Check
{
    static string game, core, originalGame;
    static int trash, trashInc, deliveries, queueComplete, scenarios;
    static bool failScenario;
    static PlanetFactory factory;
    static readonly Dictionary<int, int> production = new Dictionary<int, int>();
    static readonly Dictionary<int, int> consumption = new Dictionary<int, int>();
    static void Assert(bool condition, string message) { if (!condition) throw new Exception(message); }
    static void Main(string[] args)
    {
        game = args[0]; core = args[1]; originalGame = args[2];
        AppDomain.CurrentDomain.AssemblyResolve += Resolve;
        try { Run(); }
        catch (Exception ex)
        {
            Console.Error.WriteLine("CHECK FAILED: " + ex);
            Environment.ExitCode = 1;
        }
    }
    static Assembly Resolve(object sender, ResolveEventArgs args)
    {
        string name = new AssemblyName(args.Name).Name + ".dll";
        foreach (string dir in new[] { game, core, originalGame })
            if (File.Exists(Path.Combine(dir, name))) return Assembly.LoadFrom(Path.Combine(dir, name));
        return null;
    }
    static T Bare<T>() { return (T)FormatterServices.GetUninitializedObject(typeof(T)); }
    static void Set(object instance, string property, object value)
    {
        typeof(Player).GetProperty(property).GetSetMethod(true).Invoke(instance, new[] { value });
    }
    static void Add(Dictionary<int, int> values, int id, int count)
    {
        int previous; values.TryGetValue(id, out previous); values[id] = previous + count;
    }
    static void Patch(Harmony harmony, Type type, string method, string prefix)
    {
        harmony.Patch(AccessTools.Method(type, method), prefix: new HarmonyMethod(typeof(Check), prefix));
    }
    static bool Nearest(ref PlanetFactory __result) { __result = factory; return false; }
    static bool Up() { return false; }
    static bool Trash(int itemId, int count, int inc) { trash += count; trashInc += inc; return false; }
    static bool Production(int itemId, int itemCount) { Add(production, itemId, itemCount); return false; }
    static bool Consumption(int itemId, int itemCount) { Add(consumption, itemId, itemCount); return false; }
    static bool Scenario()
    {
        scenarios++;
        if (failScenario) throw new InvalidOperationException("Injected scenario failure after Produce");
        return false;
    }
    static ForgeTask Task(int recipe, int count, int input, int inputCount, int served,
                          int product, int productCount, int parent = -1)
    {
        return new ForgeTask {
            recipeId = recipe, count = count, tick = 0, tickSpend = 10000,
            itemIds = new[] { input }, itemCounts = new[] { inputCount }, served = new[] { served },
            productIds = new[] { product }, productCounts = new[] { productCount }, produced = new int[1],
            parentTaskIndex = parent
        };
    }
    static MechaForge Forge(params ForgeTask[] tasks)
    {
        trash = trashInc = deliveries = queueComplete = scenarios = 0;
        production.Clear(); consumption.Clear(); failScenario = false;
        var data = Bare<GameData>();
        data.history = Bare<GameHistoryData>(); data.history.featureValues = new Dictionary<int, int>();
        var controller = Bare<PlayerController>(); controller.gameData = data;
        var player = new Player { isAlive = true };
        Set(player, "controller", controller);
        Set(player, "package", new StorageComponent(4));
        var delivery = new DeliveryPackage(); delivery.Init();
        Set(player, "deliveryPackage", delivery);
        var mecha = new Mecha { player = player, gameData = data, replicateSpeed = 1f };
        Set(player, "mecha", mecha);
        var forge = new MechaForge(); forge.Init(mecha);
        forge.tasks.AddRange(tasks);
        forge.onTaskDelivery += delegate { deliveries++; };
        forge.onTaskQueueComplete += delegate { queueComplete++; };
        return forge;
    }
    static int Stored(MechaForge forge, int id)
    {
        int count = 0;
        foreach (var grid in forge.player.package.grids) if (grid.itemId == id) count += grid.count;
        return count;
    }
    static void Finish(QueueCompletion session)
    {
        int batches = 0;
        while (session.Active && batches++ < 100) session.ProcessBatch(0, 128, 1000);
        Assert(!session.Active && session.StopReason == null, "Completion did not finish normally: " + session.StopReason);
    }
    static void Run()
    {
        var field = typeof(UIReplicatorWindow).GetField("mechaForge", BindingFlags.Instance | BindingFlags.NonPublic | BindingFlags.Public);
        Assert(field != null && field.FieldType == typeof(MechaForge), "Reflected UI forge field missing or wrong type");
        StorageComponent.staticLoaded = true; StorageComponent.itemStackCount = new int[12000];
        for (int i = 1001; i <= 1004; i++) StorageComponent.itemStackCount[i] = 100;
        var items = Bare<ItemProtoSet>(); items.dataArray = new ItemProto[0];
        AccessTools.Field(typeof(ItemProtoSet), "dataIndices").SetValue(items, new Dictionary<int, int>());
        typeof(LDB).GetField("_items", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic).SetValue(null, items);
        factory = Bare<PlanetFactory>();
        GameMain.gameScenario = Bare<GameScenarioLogic>();
        var harmony = new Harmony("BUG.CompleteQueue.HeadlessCheck");
        Patch(harmony, typeof(Player), "get_nearestFactory", "Nearest");
        Patch(harmony, typeof(Player), "ThrowTrash", "Trash");
        Patch(harmony, typeof(UIItemup), "Up", "Up");
        Patch(harmony, typeof(Mecha), "AddProductionStat", "Production");
        Patch(harmony, typeof(Mecha), "AddConsumptionStat", "Consumption");
        Patch(harmony, typeof(GameScenarioLogic), "NotifyOnMechaForgeTaskComplete", "Scenario");
        try
        {
            DirectAndPartial(); NestedAndNativeComparison(); Overflow(); Guards(); Failure();
            Console.WriteLine("PASS: real native forge, partial/nested production, native equivalence, storage/overflow/inc, callbacks/stat/scenario dispatch, batching, queue changes, failure/retry guards and reflected UI field.");
            Console.WriteLine("LIMIT: stat/scenario endpoints and Unity item popup/trash spawning are recording sinks; interactive UI/game runtime remains untested.");
        }
        finally { harmony.UnpatchSelf(); GameMain.gameScenario = null; }
    }
    static void DirectAndPartial()
    {
        var task = Task(1, 3, 1001, 1, 3, 1002, 2); task.tick = 6000;
        var forge = Forge(task); var session = new QueueCompletion(forge);
        Assert(session.ProcessBatch(0, 1, 1000) == 1 && session.Active, "Batch cap not respected");
        Assert(task.count == 2 && task.served[0] == 2 && task.produced[0] == 0 && Stored(forge, 1002) == 2, "Partial task accounting wrong");
        Finish(session);
        Assert(Stored(forge, 1002) == 6 && forge.tasks.Count == 0, "Wrong final product count");
        Assert(deliveries == 3 && queueComplete == 1 && scenarios == 3, "Native callbacks missing or repeated");
        Assert(production[1002] == 6 && consumption[1001] == 3, "Stat dispatch wrong");
        Assert(forge.player.controller.gameData.history.GetFeatureValue(2140001) == 3, "History not advanced");
        var empty = new QueueCompletion(forge); Assert(!empty.Active && empty.ProcessBatch(0) == 0, "Empty queue duplicated items");
        Console.WriteLine("PASS direct/partial, stat/scenario/history dispatch and repeat click");
    }
    static MechaForge Nested()
    {
        return Forge(Task(2, 2, 1001, 1, 2, 1002, 2, 1), Task(3, 1, 1002, 3, 0, 1003, 1));
    }
    static void NestedAndNativeComparison()
    {
        var native = Nested();
        while (native.tasks.Count > 0) { native.tasks[0].tick = native.tasks[0].tickSpend; native.GameTick(0, 0f); }
        int nativeIntermediate = Stored(native, 1002), nativeFinal = Stored(native, 1003);
        int nativeDeliveries = deliveries, nativeScenarios = scenarios;
        var fast = Nested(); Finish(new QueueCompletion(fast));
        Assert(Stored(fast, 1002) == nativeIntermediate && Stored(fast, 1003) == nativeFinal, "Accelerated results differ from native");
        Assert(nativeIntermediate == 1 && nativeFinal == 1, "Intermediate products incorrectly delivered");
        Assert(deliveries == nativeDeliveries && scenarios == nativeScenarios && queueComplete == 1, "Events differ from native");
        Assert(production[1002] == 4 && production[1003] == 1 && consumption[1001] == 2 && consumption[1002] == 3, "Nested stat dispatch wrong");
        Assert(fast.extraItems.items.Count == 0, "Extra item cache not cleared natively");
        Console.WriteLine("PASS nested feeding, surplus and native equivalence");
    }
    static void Fill(MechaForge forge)
    {
        for (int i = 0; i < forge.player.package.size; i++)
            forge.player.package.grids[i] = new StorageComponent.GRID { itemId = 1004, count = 100, inc = 300, stackSize = 100 };
    }
    static void Overflow()
    {
        for (int mode = 0; mode < 3; mode++)
        {
            var forge = Forge(Task(4, 2, 1001, 1, 2, 1002, 3)); Fill(forge);
            var delivery = forge.player.deliveryPackage;
            delivery.unlocked = mode != 0;
            delivery.grids[0] = new DeliveryPackage.GRID { itemId = 1002, count = mode == 2 ? 100 : 0, stackSize = 100, stackSizeMultiplier = 1 };
            int start = delivery.grids[0].count;
            Finish(new QueueCompletion(forge));
            Assert(delivery.grids[0].count - start + trash == 6, "Overflow delivered twice or lost");
            Assert(trash == (mode == 1 ? 0 : 6) && trashInc == 0, "Wrong native overflow sink");
            foreach (var grid in forge.player.package.grids) Assert(grid.count == 100 && grid.inc == 300, "Existing cargo/inc changed");
        }
        // Verify the same native delivery boundary preserves inc when splitting
        // between package, delivery storage and trash (forge products have inc=0).
        var split = Forge(); Fill(split);
        split.player.package.grids[0] = new StorageComponent.GRID { itemId = 1002, count = 99, inc = 297, stackSize = 100 };
        split.player.deliveryPackage.unlocked = true;
        split.player.deliveryPackage.grids[0] = new DeliveryPackage.GRID { itemId = 1002, count = 98, inc = 294, stackSize = 100, stackSizeMultiplier = 1 };
        int added = split.player.TryAddItemToPackage(1002, 5, 15, true);
        Assert(added == 1 && split.player.deliveryPackage.grids[0].count == 100 && trash == 2, "Native return is not normal-package count");
        Assert(split.player.package.grids[0].inc - 297 + split.player.deliveryPackage.grids[0].inc - 294 + trashInc == 15, "Inc lost across overflow");
        Console.WriteLine("PASS full package / delivery empty, full, locked / split count+inc");
    }
    static void Guards()
    {
        var missingTask = Task(5, 1, 1001, 1, 0, 1002, 1); missingTask.tick = 123;
        var missing = Forge(missingTask); var blocked = new QueueCompletion(missing); blocked.ProcessBatch(0, 128, 1000);
        Assert(!blocked.Active && missingTask.count == 1 && missingTask.tick == 123 && Stored(missing, 1002) == 0, "Missing inputs changed task");
        var invalid = Task(5, 1, 1001, 1, 1, 1002, 1, 8);
        Assert(!new QueueCompletion(Forge(invalid)).Active && invalid.count == 1, "Invalid parent accepted");
        var growingTask = Task(6, 2, 1001, 1, 2, 1002, 1);
        var growing = Forge(growingTask); var growSession = new QueueCompletion(growing);
        growingTask.count++; growSession.ProcessBatch(0, 128, 1000);
        Assert(!growSession.Active && growingTask.count == 3, "Merged new cycles accelerated");
        var reordered = Forge(Task(6, 2, 1001, 1, 2, 1002, 1)); var reorderSession = new QueueCompletion(reordered);
        var inserted = Task(7, 1, 1001, 1, 1, 1003, 1); reordered.tasks.Insert(0, inserted);
        reorderSession.ProcessBatch(0, 128, 1000);
        Assert(!reorderSession.Active && inserted.count == 1 && reordered.tasks.Count == 2, "New head task altered");
        var stopped = Forge(Task(8, 1, 1001, 1, 1, 1002, 1));
        typeof(MechaForge).GetField("working", BindingFlags.Instance | BindingFlags.NonPublic).SetValue(stopped, false);
        var stalled = new QueueCompletion(stopped); stalled.ProcessBatch(0, 128, 1000);
        Assert(!stalled.Active && stopped.tasks[0].tick == 0 && stopped.tasks[0].count == 1, "No-progress guard failed");
        var reentrant = Forge(Task(9, 2, 1001, 1, 2, 1002, 1)); var session = new QueueCompletion(reentrant);
        reentrant.onTaskDelivery += delegate { Assert(session.ProcessBatch(0, 128, 1000) == 0, "Reentrant completion accepted"); };
        Finish(session); Assert(Stored(reentrant, 1002) == 2, "Reentrant production duplication");
        var normal = Forge(Task(10, 3, 1001, 1, 3, 1002, 1)); var normalSession = new QueueCompletion(normal);
        normal.tasks[0].tick = normal.tasks[0].tickSpend; normal.GameTick(0, 0f);
        Finish(normalSession); Assert(Stored(normal, 1002) == 3, "Interleaved normal tick duplicated products");
        Console.WriteLine("PASS missing inputs, invalid parent, queue insertion/growth, no progress, reentry and interleaved native tick");
    }
    static void Failure()
    {
        var task = Task(11, 2, 1001, 1, 2, 1002, 1); var forge = Forge(task);
        var session = new QueueCompletion(forge); failScenario = true;
        try { session.ProcessBatch(0, 128, 1000); throw new Exception("Injected failure was not surfaced"); }
        catch (InvalidOperationException) { }
        Assert(!session.Active && task.count == 1 && task.produced[0] == 1 && Stored(forge, 1002) == 0, "Committed production rolled back or repeated");
        Assert(!new QueueCompletion(forge).Active && task.count == 1, "Retry accepted undelivered native products");
        Console.WriteLine("PASS failure after Produce and retry guard");
    }
}
