# BUG-DSPCompleteReplicatorQueue — detailed change report

Installed plugin version(s): **1.0.3**. Complete the queue through native forge production/delivery in bounded batches; retain intermediates and native events.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Native queue completion — 1.0.3, 3 October 2026

Production and UI sources were reconstructed around the installed 1.0.2 feature contract; this is not presented as an upstream build. The GUID, soft dependency and button contract were retained, as was assembly identity 0.0.0.0.

- Replace direct `count * productCounts` grants and `tasks.Clear()` with stepwise native `MechaForge.GameTick`. Native `Produce`, `TaskFeed`, `TaskFeedAfter`, `TaskDeliver`, statistics, scenario/history and events remain responsible for production.
- Remove the additional reflected `ThrowTrash` call. Package/delivery/overflow runs once, and intermediate products feed their parent tasks.
- Process at most 128 production operations and approximately 4 ms per frame; one native call can exceed that time budget. Continue large queues on later frames. The instant-completion feature intentionally bypasses waiting time and production energy.
- Track the tasks present at the click. Stop on a new/prepended task, increased quantity, missing inputs, invalid state or a native call that makes no progress. Preserve the queue and allow normal production between batches.
- Do not roll back products already delivered after an exception. Do not accelerate a corrupt task holding undelivered `produced` data.
- Bind the button to the window lifecycle without cloning native click listeners. Prevent duplicates and repeated activation during processing. Cancel on profile/game changes, window free and plugin shutdown.
- Check the original mod/game hashes before building; do not silently apply an old diagnosis to changed binaries.

## Validation

The phase used .NET Framework 4.7.2 and actual BepInEx/Harmony/game/Unity references; 23 game API references and 5 Harmony targets were checked. Native forge/storage/delivery/history tests covered direct and partial production, parent feeding and excess intermediates, equivalence with normal production, full inventory and unlocked/locked/full delivery packages, overflow count/inc, events, batch limits, interleaved normal ticks, missing inputs, invalid parents, prepending/increasing tasks, no progress, reentry and failures after `Produce` followed by another click.

Seven environment boundaries were replaced only in a disposable test game reference: nearest factory, trash, item popup, two statistics endpoints, scenario notification and the LDB item-asset getter. Recording substitutes verify calls; they do not run graphics, audio or physics. Native forge/task/inventory/delivery/history method bodies remain unchanged. The test game DLL is not distributed.

## Remaining acceptance

In game, compare final and intermediate totals with normal production; exercise all delivery/overflow cases, large queues, repeated clicks and opening, old/new saves, statistics/scenario progress and ReplicatorPlus prepending during completion. Headless success does not establish these UI/runtime outcomes. Do not load the original and modified DLL together under the same GUID.

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
