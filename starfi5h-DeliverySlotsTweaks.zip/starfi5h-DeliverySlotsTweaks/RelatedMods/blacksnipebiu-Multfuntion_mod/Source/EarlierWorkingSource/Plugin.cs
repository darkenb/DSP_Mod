using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Text.RegularExpressions;
using System.Threading;
using System.Threading.Tasks;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;
using Multifunction_mod.API;
using Multifunction_mod.Models;
using Multifunction_mod.Patchs;
using Multifunction_mod.Utils;
using UnityEngine;



[assembly: Debuggable(DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.DisableOptimizations | DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | DebuggableAttribute.DebuggingModes.EnableEditAndContinue)]
[assembly: AssemblyTitle("Multifunction_mod")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("Multifunction_mod")]
[assembly: AssemblyCopyright("Copyright ©  2022")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("d898890a-6afd-4680-84d6-0b5ebf5656c9")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: TargetFramework(".NETFramework,Version=v4.7.2", FrameworkDisplayName = ".NET Framework 4.7.2")]
[assembly: AssemblyVersion("1.0.0.0")]
namespace Multifunction_mod
{
	public class Constant
	{
		public static List<Vector3> nodepos = new List<Vector3>();

		public static double[,] posxz = new double[10, 2]
		{
			{ 0.0, 1.0 },
			{ 0.1563, -0.9877 },
			{ 0.3089, -0.9511 },
			{ 0.4539, -0.8911 },
			{ 0.5877, -0.8091 },
			{ 0.7071, -0.7071 },
			{ 0.8091, -0.5877 },
			{ 0.891, -0.454 },
			{ 0.9511, -0.3089 },
			{ 0.9877, -0.1564 }
		};

		public static double[,] dysonposxyz1 = new double[7, 2]
		{
			{ 7431.4, 6691.3 },
			{ 8090.2, 5877.9 },
			{ 8660.3, 5000.0 },
			{ 9135.5, 4067.4 },
			{ 9510.6, 3090.2 },
			{ 9781.5, 2079.1 },
			{ 9945.2, 1045.3 }
		};

		public static double[,] dysonposxyz2 = new double[14, 3]
		{
			{ -1045.3, 0.0, 9945.2 },
			{ -2079.1, 0.0, 9781.5 },
			{ -3090.2, 0.0, 9510.6 },
			{ -4067.4, 0.0, 9135.4 },
			{ -5000.0, 0.0, 8660.2 },
			{ -5877.9, 0.0, 8090.2 },
			{ -6691.3, 0.0, 7431.4 },
			{ -7431.5, 0.0, 6691.3 },
			{ -8090.2, 0.0, 5877.9 },
			{ -8660.3, 0.0, 5000.0 },
			{ -9135.5, 0.0, 4067.4 },
			{ -9510.6, 0.0, 3090.2 },
			{ -9781.5, 0.0, 2079.1 },
			{ -9945.2, 0.0, 1045.3 }
		};

		public static double[,] dysonposxyz3 = new double[98, 3]
		{
			{ 1143.5, 1149.8, 10879.8 },
			{ 1124.7, 2287.0, 10700.7 },
			{ 1093.5, 3399.2, 10404.3 },
			{ 1050.4, 4474.1, 9994.0 },
			{ 995.8, 5500.0, 9474.1 },
			{ 930.2, 6465.6, 8850.4 },
			{ 854.5, 7360.4, 8129.8 },
			{ 1699.6, 7360.4, 7996.0 },
			{ 1850.2, 6465.6, 8704.7 },
			{ 1980.6, 5500.0, 9318.1 },
			{ 2089.3, 4474.1, 9829.4 },
			{ 2175.1, 3399.2, 10233.0 },
			{ 2237.0, 2287.0, 10524.5 },
			{ 2274.5, 1149.8, 10700.7 },
			{ 3380.6, 1149.8, 10404.3 },
			{ 3324.9, 2287.0, 10233.0 },
			{ 3232.8, 3399.2, 9949.6 },
			{ 3105.3, 4474.1, 9557.2 },
			{ 2943.8, 5500.0, 9060.0 },
			{ 2750.0, 6465.6, 8463.6 },
			{ 2526.1, 7360.4, 7774.5 },
			{ 3324.9, 7360.4, 7467.9 },
			{ 3619.6, 6465.6, 8129.8 },
			{ 3874.7, 5500.0, 8702.7 },
			{ 4087.3, 4474.1, 9180.2 },
			{ 4255.1, 3399.2, 9557.2 },
			{ 4376.3, 2287.0, 9829.4 },
			{ 4449.6, 1149.8, 9993.9 },
			{ 5469.9, 1149.8, 9474.1 },
			{ 5379.8, 2287.0, 9318.1 },
			{ 5230.8, 3399.2, 9060.0 },
			{ 5024.5, 4474.1, 8702.7 },
			{ 4763.1, 5500.0, 8250.0 },
			{ 4449.6, 6465.6, 7706.9 },
			{ 4087.3, 7360.4, 7079.4 },
			{ 4804.9, 7360.4, 6613.4 },
			{ 5230.8, 6465.6, 7199.6 },
			{ 5599.4, 5500.0, 7706.9 },
			{ 5906.7, 4474.1, 8129.8 },
			{ 6149.2, 3399.2, 8463.6 },
			{ 6324.4, 2287.0, 8704.7 },
			{ 6430.2, 1149.8, 8850.4 },
			{ 7320.1, 1149.8, 8129.8 },
			{ 7199.6, 2287.0, 7995.9 },
			{ 7000.2, 3399.2, 7774.5 },
			{ 6724.1, 4474.1, 7467.9 },
			{ 6374.3, 5500.0, 7079.4 },
			{ 5954.7, 6465.6, 6613.4 },
			{ 5469.9, 7360.4, 6074.9 },
			{ 6074.9, 7360.4, 5469.9 },
			{ 6613.4, 6465.6, 5954.7 },
			{ 7079.4, 5500.0, 6374.3 },
			{ 7467.9, 4474.1, 6724.1 },
			{ 7774.5, 3399.2, 7000.2 },
			{ 7996.0, 2287.0, 7199.6 },
			{ 8129.8, 1149.8, 7320.1 },
			{ 8850.4, 1149.8, 6430.2 },
			{ 8704.7, 2287.0, 6324.3 },
			{ 8463.6, 3399.2, 6149.2 },
			{ 8129.8, 4474.1, 5906.6 },
			{ 7706.9, 5500.0, 5599.4 },
			{ 7199.6, 6465.6, 5230.8 },
			{ 6613.4, 7360.4, 4804.9 },
			{ 7079.4, 7360.4, 4087.3 },
			{ 7706.9, 6465.6, 4449.6 },
			{ 8250.0, 5500.0, 4763.1 },
			{ 8702.7, 4474.1, 5024.5 },
			{ 9060.0, 3399.2, 5230.8 },
			{ 9318.1, 2287.0, 5379.8 },
			{ 9474.1, 1149.8, 5469.9 },
			{ 9994.0, 1149.8, 4449.6 },
			{ 9829.4, 2287.0, 4376.3 },
			{ 9557.2, 3399.2, 4255.1 },
			{ 9180.2, 4474.1, 4087.3 },
			{ 8702.7, 5500.0, 3874.7 },
			{ 8129.8, 6465.6, 3619.6 },
			{ 7467.9, 7360.4, 3324.9 },
			{ 7774.5, 7360.4, 2526.1 },
			{ 8463.6, 6465.6, 2750.0 },
			{ 9060.0, 5500.0, 2943.8 },
			{ 9557.2, 4474.1, 3105.3 },
			{ 9949.6, 3399.2, 3232.8 },
			{ 10233.0, 2287.0, 3324.9 },
			{ 10404.3, 1149.8, 3380.6 },
			{ 10700.7, 1149.8, 2274.5 },
			{ 10524.5, 2287.0, 2237.0 },
			{ 10233.0, 3399.2, 2175.1 },
			{ 9829.4, 4474.1, 2089.3 },
			{ 9318.1, 5500.0, 1980.6 },
			{ 8704.7, 6465.6, 1850.2 },
			{ 7996.0, 7360.4, 1699.6 },
			{ 8129.8, 7360.4, 854.5 },
			{ 8850.4, 6465.6, 930.2 },
			{ 9474.1, 5500.0, 995.8 },
			{ 9994.0, 4474.1, 1050.4 },
			{ 10404.3, 3399.2, 1093.5 },
			{ 10700.7, 2287.0, 1124.7 },
			{ 10879.8, 1149.8, 1143.5 }
		};

		public static double[,] dysonposxyz4 = new double[244, 3]
		{
			{ 0.0, 9659.3, 2588.2 },
			{ -943.9, 8910.1, -4440.7 },
			{ -1846.5, 8910.1, -4147.4 },
			{ -2668.5, 8910.1, -3672.9 },
			{ -3373.8, 8910.1, -3037.8 },
			{ -3931.7, 8910.1, -2270.0 },
			{ -4317.7, 8910.1, -1402.9 },
			{ -4515.0, 8910.1, -474.6 },
			{ -4515.0, 8910.1, 474.5 },
			{ -4317.7, 8910.1, 1402.9 },
			{ -3931.7, 8910.1, 2269.9 },
			{ -3373.8, 8910.1, 3037.8 },
			{ -2668.5, 8910.1, 3672.9 },
			{ -1846.6, 8910.1, 4147.4 },
			{ -943.9, 8910.1, 4440.7 },
			{ 2588.2, 9659.3, 0.0 },
			{ 0.0, 10000.0, 0.0 },
			{ 2461.5, 9659.3, 799.8 },
			{ -745.1, 9335.8, 3505.4 },
			{ -1457.6, 9335.8, 3273.9 },
			{ -2106.4, 9335.8, 2899.3 },
			{ -2663.2, 9335.8, 2397.9 },
			{ -3103.6, 9335.8, 1791.8 },
			{ -3408.3, 9335.8, 1107.4 },
			{ -3564.1, 9335.8, 374.6 },
			{ -3564.0, 9335.8, -374.6 },
			{ -3408.3, 9335.8, -1107.4 },
			{ -3103.5, 9335.8, -1791.9 },
			{ -2663.2, 9335.8, -2398.0 },
			{ -2106.4, 9335.8, -2899.3 },
			{ -1457.6, 9335.8, -3273.9 },
			{ -745.1, 9335.8, -3505.4 },
			{ 799.8, 9659.3, 2461.5 },
			{ 1521.3, 9659.3, 2093.9 },
			{ -799.8, 9659.3, -2461.5 },
			{ -1521.3, 9659.3, -2093.9 },
			{ -2093.9, 9659.3, -1521.3 },
			{ -2461.5, 9659.3, -799.8 },
			{ -2588.2, 9659.3, 0.0 },
			{ -2461.5, 9659.3, 799.8 },
			{ -2093.9, 9659.3, 1521.3 },
			{ -1521.3, 9659.3, 2093.9 },
			{ -799.8, 9659.3, 2461.5 },
			{ 2093.9, 9659.3, 1521.3 },
			{ 163.5, 9876.9, -1555.8 },
			{ -636.3, 9876.9, 1429.1 },
			{ -1215.7, 9876.9, 984.5 },
			{ -1530.2, 9876.9, 325.2 },
			{ -1511.0, 9876.9, -404.9 },
			{ -1162.5, 9876.9, -1046.8 },
			{ -560.6, 9876.9, -1460.4 },
			{ 852.0, 9876.9, -1312.0 },
			{ 1354.8, 9876.9, -782.2 },
			{ 1562.2, 9876.9, -81.9 },
			{ 1429.1, 9876.9, 636.3 },
			{ 984.5, 9876.9, 1215.7 },
			{ 325.2, 9876.9, 1530.2 },
			{ 2461.5, 9659.3, -799.8 },
			{ 2093.9, 9659.3, -1521.3 },
			{ 1521.3, 9659.3, -2093.9 },
			{ 799.8, 9659.3, -2461.5 },
			{ 0.0, 9659.3, -2588.2 },
			{ 0.0, 9335.8, -3583.7 },
			{ 0.0, 8910.1, -4539.9 },
			{ 943.9, 8910.1, -4440.7 },
			{ 745.1, 9335.8, -3505.4 },
			{ 1457.6, 9335.8, -3273.9 },
			{ 1846.5, 8910.1, -4147.4 },
			{ 2668.5, 8910.1, -3672.9 },
			{ 2106.4, 9335.8, -2899.3 },
			{ 2663.2, 9335.8, -2397.9 },
			{ 3373.8, 8910.1, -3037.8 },
			{ 3103.6, 9335.8, -1791.8 },
			{ 3931.7, 8910.1, -2270.0 },
			{ 3408.3, 9335.8, -1107.4 },
			{ 4317.7, 8910.1, -1402.9 },
			{ 3564.0, 9335.8, -374.6 },
			{ 4515.0, 8910.1, -474.6 },
			{ 3564.0, 9335.8, 374.6 },
			{ 4515.0, 8910.1, 474.5 },
			{ 3408.3, 9335.8, 1107.4 },
			{ 4317.7, 8910.1, 1402.9 },
			{ 3103.6, 9335.8, 1791.8 },
			{ 3931.7, 8910.1, 2269.9 },
			{ 2663.2, 9335.8, 2397.9 },
			{ 3373.8, 8910.1, 3037.8 },
			{ 2106.4, 9335.8, 2899.3 },
			{ 2668.5, 8910.1, 3672.9 },
			{ 1457.6, 9335.8, 3273.9 },
			{ 1846.5, 8910.1, 4147.4 },
			{ 745.1, 9335.8, 3505.4 },
			{ 943.9, 8910.1, 4440.7 },
			{ 0.0, 9335.8, 3583.7 },
			{ 0.0, 8910.1, 4539.9 },
			{ -522.6, 8660.3, 4972.6 },
			{ 522.6, 8660.3, 4972.6 },
			{ 0.0, 8386.7, 5446.4 },
			{ 614.4, 8090.2, 5845.7 },
			{ -1545.1, 8660.3, 4755.3 },
			{ -2500.0, 8660.3, 4330.1 },
			{ -3345.7, 8660.3, 3715.7 },
			{ -4045.1, 8660.3, 2938.9 },
			{ -4567.7, 8660.3, 2033.7 },
			{ -4890.7, 8660.3, 1039.5 },
			{ -5000.0, 8660.3, 0.0 },
			{ -4890.7, 8660.3, -1039.6 },
			{ -4567.7, 8660.3, -2033.7 },
			{ -4045.1, 8660.3, -2939.0 },
			{ -3345.6, 8660.3, -3715.8 },
			{ -2500.0, 8660.3, -4330.2 },
			{ -1545.0, 8660.3, -4755.3 },
			{ -522.6, 8660.3, -4972.6 },
			{ 522.6, 8660.3, -4972.6 },
			{ 1545.1, 8660.3, -4755.3 },
			{ 2500.0, 8660.3, -4330.1 },
			{ 3345.7, 8660.3, -3715.7 },
			{ 4045.1, 8660.3, -2938.9 },
			{ 4567.7, 8660.3, -2033.7 },
			{ 4890.7, 8660.3, -1039.6 },
			{ 5000.0, 8660.3, 0.0 },
			{ 4890.7, 8660.3, 1039.6 },
			{ 4567.7, 8660.3, 2033.7 },
			{ 4045.1, 8660.3, 2938.9 },
			{ 3345.7, 8660.3, 3715.7 },
			{ 2500.0, 8660.3, 4330.1 },
			{ 1545.1, 8660.3, 4755.3 },
			{ 1132.4, 8386.7, 5327.4 },
			{ 1816.4, 8090.2, 5590.2 },
			{ 2215.2, 8386.7, 4975.5 },
			{ 3201.3, 8386.7, 4406.2 },
			{ 2938.9, 8090.2, 5090.4 },
			{ 2559.7, 7771.5, 5749.1 },
			{ 1308.4, 7771.5, 6155.7 },
			{ 0.0, 7771.5, 6293.2 },
			{ -614.4, 8090.2, 5845.7 },
			{ -1132.4, 8386.7, 5327.4 },
			{ -1816.4, 8090.2, 5590.2 },
			{ -1308.4, 7771.5, 6155.7 },
			{ -699.4, 7431.4, 6654.7 },
			{ -2067.7, 7431.4, 6363.8 },
			{ -2559.7, 7771.5, 5749.1 },
			{ -2215.3, 8386.7, 4975.5 },
			{ -3345.7, 7431.4, 5794.8 },
			{ -2938.9, 8090.2, 5090.4 },
			{ -3201.3, 8386.7, 4406.2 },
			{ -3699.1, 7771.5, 5091.3 },
			{ -4477.4, 7431.4, 4972.6 },
			{ -3933.1, 8090.2, 4368.1 },
			{ -4047.5, 8386.7, 3644.3 },
			{ -4676.8, 7771.5, 4211.0 },
			{ -5413.4, 7431.4, 3933.0 },
			{ -4755.3, 8090.2, 3454.9 },
			{ -4716.7, 8386.7, 2723.2 },
			{ -5450.1, 7771.5, 3146.6 },
			{ -6112.8, 7431.4, 2721.6 },
			{ -5369.7, 8090.2, 2390.7 },
			{ -5179.8, 8386.7, 1683.0 },
			{ -5985.2, 7771.5, 1944.7 },
			{ -6545.1, 7431.4, 1391.2 },
			{ -5749.4, 8090.2, 1222.0 },
			{ -5416.6, 8386.7, 569.3 },
			{ -6258.7, 7771.5, 657.8 },
			{ -6691.3, 7431.4, 0.0 },
			{ -5877.9, 8090.2, 0.0 },
			{ -5416.6, 8386.7, -569.3 },
			{ -6258.7, 7771.5, -657.9 },
			{ -6545.1, 7431.4, -1391.2 },
			{ -5749.4, 8090.2, -1222.1 },
			{ -5179.8, 8386.7, -1683.1 },
			{ -5985.2, 7771.5, -1944.8 },
			{ -6112.8, 7431.4, -2721.6 },
			{ -5369.7, 8090.2, -2390.8 },
			{ -4716.7, 8386.7, -2723.2 },
			{ -5450.0, 7771.5, -3146.6 },
			{ -5413.3, 7431.4, -3933.1 },
			{ -4755.3, 8090.2, -3455.0 },
			{ -4047.4, 8386.7, -3644.4 },
			{ -4676.7, 7771.5, -4211.0 },
			{ -4477.3, 7431.4, -4972.7 },
			{ -3933.0, 8090.2, -4368.1 },
			{ -3201.3, 8386.7, -4406.3 },
			{ -3699.0, 7771.5, -5091.3 },
			{ -3345.6, 7431.4, -5794.9 },
			{ -2938.9, 8090.2, -5090.4 },
			{ -2215.2, 8386.7, -4975.5 },
			{ -2559.6, 7771.5, -5749.2 },
			{ -2067.7, 7431.4, -6363.8 },
			{ -1816.3, 8090.2, -5590.2 },
			{ -1132.3, 8386.7, -5327.4 },
			{ -1308.4, 7771.5, -6155.7 },
			{ -699.4, 7431.4, -6654.7 },
			{ -614.3, 8090.2, -5845.7 },
			{ 0.0, 8386.7, -5446.4 },
			{ 0.0, 7771.5, -6293.2 },
			{ 699.4, 7431.4, -6654.7 },
			{ 614.4, 8090.2, -5845.7 },
			{ 1132.4, 8386.7, -5327.4 },
			{ 1308.4, 7771.5, -6155.7 },
			{ 2067.7, 7431.4, -6363.8 },
			{ 1816.4, 8090.2, -5590.2 },
			{ 2215.2, 8386.7, -4975.5 },
			{ 2559.7, 7771.5, -5749.1 },
			{ 3345.7, 7431.4, -5794.8 },
			{ 2938.9, 8090.2, -5090.4 },
			{ 3201.3, 8386.7, -4406.2 },
			{ 3699.1, 7771.5, -5091.3 },
			{ 4477.4, 7431.4, -4972.6 },
			{ 3933.1, 8090.2, -4368.1 },
			{ 4047.5, 8386.7, -3644.3 },
			{ 4676.8, 7771.5, -4211.0 },
			{ 5413.4, 7431.4, -3933.1 },
			{ 4755.3, 8090.2, -3454.9 },
			{ 4716.7, 8386.7, -2723.2 },
			{ 5450.1, 7771.5, -3146.6 },
			{ 6112.8, 7431.4, -2721.6 },
			{ 5369.7, 8090.2, -2390.7 },
			{ 5179.8, 8386.7, -1683.0 },
			{ 5985.2, 7771.5, -1944.7 },
			{ 6545.1, 7431.4, -1391.2 },
			{ 5749.4, 8090.2, -1222.1 },
			{ 5416.6, 8386.7, -569.3 },
			{ 6258.7, 7771.5, -657.8 },
			{ 6691.3, 7431.4, 0.0 },
			{ 5877.9, 8090.2, 0.0 },
			{ 5416.6, 8386.7, 569.3 },
			{ 6258.7, 7771.5, 657.8 },
			{ 6545.1, 7431.4, 1391.2 },
			{ 5749.4, 8090.2, 1222.1 },
			{ 5179.8, 8386.7, 1683.0 },
			{ 5985.2, 7771.5, 1944.7 },
			{ 6112.8, 7431.4, 2721.6 },
			{ 5369.7, 8090.2, 2390.7 },
			{ 4716.7, 8386.7, 2723.2 },
			{ 5450.1, 7771.5, 3146.6 },
			{ 5413.4, 7431.4, 3933.0 },
			{ 4755.3, 8090.2, 3454.9 },
			{ 4047.5, 8386.7, 3644.3 },
			{ 4676.8, 7771.5, 4211.0 },
			{ 4477.4, 7431.4, 4972.6 },
			{ 3933.1, 8090.2, 4368.1 },
			{ 3699.1, 7771.5, 5091.3 },
			{ 3345.7, 7431.4, 5794.8 },
			{ 2067.7, 7431.4, 6363.8 },
			{ 699.4, 7431.4, 6654.7 }
		};

		public static void preparedraw()
		{
			nodepos.Add(new Vector3(0f, 0f, 1f));
			nodepos.Add(new Vector3(0f, 0f, -1f));
			nodepos.Add(new Vector3(1f, 0f, 0f));
			nodepos.Add(new Vector3(-1f, 0f, 0f));
			for (int i = 0; i < 7; i++)
			{
				Vector3 item = new Vector3((float)dysonposxyz1[i, 0], (float)dysonposxyz1[i, 1], 0f) / 10000f;
				Vector3 item2 = new Vector3((float)dysonposxyz1[i, 0], 0f - (float)dysonposxyz1[i, 1], 0f) / 10000f;
				Vector3 item3 = new Vector3(0f - (float)dysonposxyz1[i, 0], (float)dysonposxyz1[i, 1], 0f) / 10000f;
				Vector3 item4 = new Vector3(0f - (float)dysonposxyz1[i, 0], 0f - (float)dysonposxyz1[i, 1], 0f) / 10000f;
				nodepos.Add(item);
				nodepos.Add(item3);
				nodepos.Add(item2);
				nodepos.Add(item4);
			}
			for (int j = 0; j < 7; j++)
			{
				Vector3 item5 = new Vector3(0f, (float)dysonposxyz1[j, 1], (float)dysonposxyz1[j, 0]) / 10000f;
				Vector3 item6 = new Vector3(0f, (float)dysonposxyz1[j, 1], 0f - (float)dysonposxyz1[j, 0]) / 10000f;
				Vector3 item7 = new Vector3(0f, 0f - (float)dysonposxyz1[j, 1], (float)dysonposxyz1[j, 0]) / 10000f;
				Vector3 item8 = new Vector3(0f, 0f - (float)dysonposxyz1[j, 1], 0f - (float)dysonposxyz1[j, 0]) / 10000f;
				nodepos.Add(item5);
				nodepos.Add(item6);
				nodepos.Add(item7);
				nodepos.Add(item8);
			}
			for (int k = 0; k < 14; k++)
			{
				Vector3 item9 = new Vector3((float)dysonposxyz2[k, 0], (float)dysonposxyz2[k, 1], (float)dysonposxyz2[k, 2]) / 10000f;
				Vector3 item10 = new Vector3(0f - (float)dysonposxyz2[k, 0], (float)dysonposxyz2[k, 1], (float)dysonposxyz2[k, 2]) / 10000f;
				nodepos.Add(item9);
				nodepos.Add(item10);
			}
			for (int l = 0; l < 14; l++)
			{
				Vector3 item11 = new Vector3(0f - (float)dysonposxyz2[l, 0], (float)dysonposxyz2[l, 1], 0f - (float)dysonposxyz2[l, 2]) / 10000f;
				Vector3 item12 = new Vector3((float)dysonposxyz2[l, 0], (float)dysonposxyz2[l, 1], 0f - (float)dysonposxyz2[l, 2]) / 10000f;
				nodepos.Add(item11);
				nodepos.Add(item12);
			}
			int[,] array = new int[8, 3]
			{
				{ 1, 1, 1 },
				{ 1, 1, -1 },
				{ 1, -1, 1 },
				{ 1, -1, -1 },
				{ -1, 1, 1 },
				{ -1, 1, -1 },
				{ -1, -1, 1 },
				{ -1, -1, -1 }
			};
			for (int m = 0; m < 8; m++)
			{
				for (int n = 0; n < 98; n++)
				{
					Vector3 item13 = new Vector3((float)dysonposxyz3[n, 0] * (float)array[m, 0], (float)dysonposxyz3[n, 1] * (float)array[m, 1], (float)dysonposxyz3[n, 2] * (float)array[m, 2]) / 11000f;
					nodepos.Add(item13);
				}
			}
			for (int num = 0; num < 244; num++)
			{
				Vector3 item14 = new Vector3((float)dysonposxyz4[num, 0], (float)dysonposxyz4[num, 1], (float)dysonposxyz4[num, 2]) / 10000f;
				Vector3 item15 = new Vector3((float)dysonposxyz4[num, 0], 0f - (float)dysonposxyz4[num, 1], (float)dysonposxyz4[num, 2]) / 10000f;
				nodepos.Add(item14);
				nodepos.Add(item15);
			}
		}
	}
	public class GUIDraw
	{
		private bool isDragging;

		public float DragStartWindowX = 200f;

		public float DragStartWindowY = 200f;

		public float DragStartMouseX = 10f;

		public float DragStartMouseY = 200f;

		private const float TitleBarHeight = 20f;

		private const float BorderMargin = 10f;

		private const float EdgeTolerance = 10f;

		private GUIStyle style;

		private GUIStyle normalStyle;

		private GUIStyle selectedIconStyle;

		private Texture2D selectedTexture;

		private GUIStyle labelmarginStyle;

		private GUIStyle selectedButtonStyle;

		private GUILayoutOption[] slideroptions;

		private GUILayoutOption[] MoreWidthslideroptions;

		private GUILayoutOption[] textfieldoptions;

		private GUILayoutOption[] menusbuttonoptions;

		private GUILayoutOption[] iconbuttonoptions;

		private bool leftscaling;

		private bool rightscaling;

		private bool bottomscaling;

		private bool firstDraw;

		private string stackmultipleStr;

		private Multifunction MainFunction;

		private int whichpannel;

		private Vector2 scrollPosition;

		private Vector2 TabscrollPosition;

		private GameObject ui_MultiFunctionPanel;

		private bool RefreshBaseSize;

		private bool ChangePlayerbool;

		private int baseSize;

		private int heightdis;

		private float mainWindow_x;

		private float mainWindow_y;

		private float mainWindowWidth;

		private float mainWindowHeight;

		private Color textColor;

		private Color mainWindowTextureColor;

		private Texture2D mainWindowTexture;

		public bool ColorChanged;

		public bool MouseInWindow;

		public int BaseSize
		{
			get
			{
				return baseSize;
			}
			set
			{
				baseSize = value;
				Multifunction.scale.Value = value;
				RefreshBaseSize = true;
				heightdis = value * 2;
			}
		}

		public float MainWindow_x
		{
			get
			{
				return mainWindow_x;
			}
			set
			{
				mainWindow_x = value;
				Multifunction.MainWindow_x_config.Value = value;
			}
		}

		public float MainWindow_y
		{
			get
			{
				return mainWindow_y;
			}
			set
			{
				mainWindow_y = value;
				Multifunction.MainWindow_y_config.Value = value;
			}
		}

		public float MainWindowWidth
		{
			get
			{
				return mainWindowWidth;
			}
			set
			{
				mainWindowWidth = value;
				Multifunction.MainWindow_width.Value = value;
			}
		}

		public float MainWindowHeight
		{
			get
			{
				return mainWindowHeight;
			}
			set
			{
				mainWindowHeight = value;
				Multifunction.MainWindow_height.Value = value;
			}
		}

		public bool DisplayingWindow { get; private set; }

		public Color TextColor
		{
			get
			{
				return textColor;
			}
			set
			{
				ColorChanged = true;
				textColor = value;
				Multifunction.Textcolor.Value = value;
			}
		}

		public Color MainWindowTextureColor
		{
			get
			{
				return mainWindowTextureColor;
			}
			set
			{
				mainWindowTextureColor = value;
				Multifunction.mainWindowTextureColor_config.Value = value;
			}
		}

		public Texture2D MainWindowTexture
		{
			get
			{
				return mainWindowTexture;
			}
			set
			{
				mainWindowTexture = value;
			}
		}

		public GUIDraw(int baseSize, GameObject panel, Multifunction multifunction)
		{
			BaseSize = baseSize;
			ui_MultiFunctionPanel = panel;
			MainFunction = multifunction;
			Init();
		}

		private void Init()
		{
			whichpannel = 0;
			scrollPosition[0] = 0f;
			TabscrollPosition[0] = 0f;
			RefreshBaseSize = true;
			ColorChanged = true;
			stackmultipleStr = Multifunction.StackMultiple.Value.ToString();
			MultifunctionAPI.ClearMenus();
			MultifunctionAPI.RegisterMenu("人物", PlayerPannel);
			MultifunctionAPI.RegisterMenu("战斗", BattlePannel);
			MultifunctionAPI.RegisterMenu("建筑", BuildPannel);
			MultifunctionAPI.RegisterMenu("星球", PlanetPannel);
			MultifunctionAPI.RegisterMenu("戴森球", DysonPannel);
			MultifunctionAPI.RegisterMenu("其它功能", OtherPannel);
			MultifunctionAPI.RegisterMenu("机甲物流", LogisticsPannel);
			TextColor = Multifunction.Textcolor.Value;
			MainWindowTextureColor = Multifunction.mainWindowTextureColor_config.Value;
			MainWindowTexture = new Texture2D(10, 10);
			selectedTexture = new Texture2D(1, 1);
			selectedTexture.SetPixel(0, 0, new Color(10f / 51f, 10f / 51f, 10f / 51f));
			selectedTexture.Apply();
			mainWindowTexture.SetPixels(Enumerable.Repeat(MainWindowTextureColor, 100).ToArray());
			mainWindowTexture.Apply();
			mainWindowWidth = Multifunction.MainWindow_width.Value;
			mainWindowHeight = Multifunction.MainWindow_height.Value;
			textColor = Multifunction.Textcolor.Value;
			MainWindow_x = Multifunction.MainWindow_x_config.Value;
			MainWindow_y = Multifunction.MainWindow_y_config.Value;
		}

		public void MainWindowKeyInvoke()
		{
			DisplayingWindow = !DisplayingWindow;
			if (DisplayingWindow)
			{
				firstDraw = true;
			}
			ui_MultiFunctionPanel.SetActive(DisplayingWindow);
		}

		public void OpenMainWindow()
		{
			DisplayingWindow = true;
			ui_MultiFunctionPanel.SetActive(value: true);
		}

		public void CloseMainWindow()
		{
			DisplayingWindow = false;
			ui_MultiFunctionPanel.SetActive(value: false);
		}

		public void Draw()
		{
			if (firstDraw)
			{
				firstDraw = false;
				BaseSize = GUI.skin.label.fontSize;
			}
			if (DisplayingWindow && Input.GetKey(KeyCode.LeftControl))
			{
				int num = (int)(Input.GetAxis("Mouse Wheel") * 10f);
				int num2 = BaseSize + num;
				if (Input.GetKeyDown(KeyCode.UpArrow))
				{
					num2++;
				}
				if (Input.GetKeyDown(KeyCode.DownArrow))
				{
					num2--;
				}
				num2 = Math.Max(5, Math.Min(num2, 35));
				BaseSize = num2;
			}
			if (style == null)
			{
				style = new GUIStyle
				{
					wordWrap = true,
					fontSize = baseSize - 2
				};
				selectedButtonStyle = new GUIStyle(GUI.skin.button);
				selectedButtonStyle.normal.textColor = new Color32(215, 186, 245, byte.MaxValue);
				normalStyle = new GUIStyle();
				selectedIconStyle = new GUIStyle();
				selectedIconStyle.normal.background = selectedTexture;
				labelmarginStyle = new GUIStyle(style)
				{
					margin = new RectOffset(0, 0, 3, 0)
				};
			}
			if (RefreshBaseSize)
			{
				RefreshBaseSize = false;
				GUI.skin.label.fontSize = BaseSize;
				GUI.skin.button.fontSize = BaseSize;
				GUI.skin.toggle.fontSize = BaseSize;
				GUI.skin.textField.fontSize = BaseSize;
				GUI.skin.textArea.fontSize = BaseSize;
				style.fontSize = BaseSize;
				labelmarginStyle.fontSize = BaseSize;
				slideroptions = new GUILayoutOption[1] { GUILayout.Width(heightdis * 6) };
				MoreWidthslideroptions = new GUILayoutOption[1] { GUILayout.Width(heightdis * 8) };
				textfieldoptions = new GUILayoutOption[1] { GUILayout.Width(heightdis * 3) };
				menusbuttonoptions = new GUILayoutOption[2]
				{
					GUILayout.Height(heightdis),
					GUILayout.Width(heightdis * 4)
				};
				iconbuttonoptions = new GUILayoutOption[2]
				{
					GUILayout.Height(heightdis),
					GUILayout.Width(heightdis)
				};
			}
			if (ColorChanged)
			{
				ColorChanged = false;
				GUI.skin.button.normal.textColor = TextColor;
				GUI.skin.textArea.normal.textColor = TextColor;
				GUI.skin.textField.normal.textColor = TextColor;
				GUI.skin.toggle.normal.textColor = TextColor;
				GUI.skin.toggle.onNormal.textColor = TextColor;
				style.normal.textColor = TextColor;
				labelmarginStyle.normal.textColor = TextColor;
			}
			if (DisplayingWindow)
			{
				bool flag = MoveWindow();
				bool flag2 = Scaling_window();
				Rect rect = new Rect(MainWindow_x, MainWindow_y, MainWindowWidth, MainWindowHeight);
				GUI.DrawTexture(rect, mainWindowTexture);
				GUI.Window(20210218, rect, MainWindow, "OP面板".getTranslate() + "(4.0.4)ps:ctrl+↑↓");
				if (flag || flag2)
				{
					UIPanelSet();
				}
				if (MainWindow_x < 0f || MainWindow_x > (float)Screen.width)
				{
					MainWindow_x = 100f;
				}
				if (MainWindow_y < 0f || MainWindow_y > (float)Screen.height)
				{
					MainWindow_y = 100f;
				}
			}
		}

		private void UIPanelSet()
		{
			RectTransform component = ui_MultiFunctionPanel.GetComponent<RectTransform>();
			RectTransform component2 = UIRoot.instance.overlayCanvas.GetComponent<RectTransform>();
			float num = component2.sizeDelta.x * 1f / (float)Screen.width;
			float num2 = component2.sizeDelta.y * 1f / (float)Screen.height;
			component.sizeDelta = new Vector2(num * MainWindowWidth, num2 * MainWindowHeight);
			component.localPosition = new Vector2((0f - component2.sizeDelta.x) / 2f + MainWindow_x * num, component2.sizeDelta.y / 2f - MainWindow_y * num2 - component.sizeDelta.y);
		}

		private void MainWindow(int winId)
		{
			GUILayout.BeginArea(new Rect(10f, 20f, MainWindowWidth, MainWindowHeight));
			GUILayout.BeginVertical();
			GUILayout.BeginHorizontal();
			List<ExternalMenu> externalMenus = MultifunctionAPI.ExternalMenus;
			for (int i = 0; i < externalMenus.Count; i++)
			{
				if (whichpannel == i)
				{
					GUILayout.Button(externalMenus[i].Name.getTranslate(), selectedButtonStyle, menusbuttonoptions);
				}
				else if (GUILayout.Button(externalMenus[i].Name.getTranslate(), menusbuttonoptions))
				{
					whichpannel = i;
				}
			}
			GUILayout.EndHorizontal();
			scrollPosition = GUILayout.BeginScrollView(scrollPosition, GUILayout.Width(MainWindowWidth - 20f), GUILayout.Height(MainWindowHeight - (float)(heightdis * 2)));
			if (whichpannel >= 0 && whichpannel < externalMenus.Count)
			{
				externalMenus[whichpannel].OnDraw?.Invoke();
			}
			GUILayout.EndScrollView();
			GUILayout.EndVertical();
			GUILayout.EndArea();
		}

		public float PropertyDataUIDraw(float num, float left, float right, string propertyName, int resulttype = 0, bool morewidth = false)
		{
			GUILayout.BeginHorizontal();
			float result = GUILayout.HorizontalSlider(num, left, right, morewidth ? MoreWidthslideroptions : slideroptions);
			string text;
			switch (resulttype)
			{
			case 0:
				text = ((int)result).ToString() ?? "";
				break;
			case 1:
				text = NumberUtils.TGMKinttostring(GameMain.mainPlayer.mecha.reactorPowerGen, "W");
				break;
			case 2:
				text = $"{result:N2}";
				break;
			case 3:
				text = NumberUtils.TGMKinttostring(result, "J");
				break;
			case 4:
				text = $"{result:N6}";
				break;
			default:
				return 0f;
			}
			string text2 = GUILayout.TextField(text, textfieldoptions);
			if (text2 != text)
			{
				if (resulttype != 0)
				{
					result = NumberUtils.ConvertToNumber(text2);
				}
				else
				{
					float.TryParse(Regex.Replace(text2, "^[^0-9]", ""), out result);
				}
			}
			GUILayout.Label(propertyName.getTranslate(), labelmarginStyle);
			GUILayout.EndHorizontal();
			return Math.Max(left, Math.Min(right, result));
		}

		private void PlayerPannel()
		{
			GUILayout.BeginHorizontal();
			GUILayout.BeginVertical(GUILayout.Width(Multifunction.IsEnglish ? (18 * heightdis) : (14 * heightdis)));
			if (GameMain.mainPlayer != null && Multifunction.propertyData != null)
			{
				PropertyData propertyData = Multifunction.propertyData;
				if (ChangePlayerbool != GUILayout.Toggle(ChangePlayerbool, "启动属性修改".getTranslate()))
				{
					ChangePlayerbool = !ChangePlayerbool;
					if (ChangePlayerbool)
					{
						Multifunction.propertyData.SetContent(Multifunction.player.mecha, GameMain.history, Multifunction.player.deliveryPackage.stackSizeMultiplier);
					}
				}
				if (ChangePlayerbool)
				{
					propertyData.WalkSpeed = PropertyDataUIDraw(propertyData.WalkSpeed, 1f, 100f, "走路速度", 2);
					propertyData.TechSpeed = PropertyDataUIDraw(propertyData.TechSpeed, 1f, 10000f, "研发速度");
					propertyData.DroneSpeed = PropertyDataUIDraw(propertyData.DroneSpeed, 1f, 100f, "小飞机速度");
					propertyData.DroneCount = PropertyDataUIDraw(propertyData.DroneCount, 1f, 256f, "小飞机数量");
					propertyData.MaxSailSpeed = PropertyDataUIDraw(propertyData.MaxSailSpeed, 1f, 10f, "最大航行速度");
					propertyData.MaxWarpSpeed = PropertyDataUIDraw(propertyData.MaxWarpSpeed, 1f, 100f, "最大曲速");
					propertyData.BuildArea = PropertyDataUIDraw(propertyData.BuildArea, 80f, 400f, "建造范围");
					propertyData.ReactorPowerGen = PropertyDataUIDraw(propertyData.ReactorPowerGen, 800000f, 1E+10f, "核心功率", 1);
					propertyData.LogisticCourierSpeed = PropertyDataUIDraw(propertyData.LogisticCourierSpeed, 1f, 100f, "配送机速度");
					propertyData.LogisticDroneSpeedScale = PropertyDataUIDraw(propertyData.LogisticDroneSpeedScale, 1f, 10000f, "运输机速度", 2);
					propertyData.LogisticShipSpeedScale = PropertyDataUIDraw(propertyData.LogisticShipSpeedScale, 1f, 10000f, "运输船速度", 2);
					propertyData.LogisticCourierCarries = PropertyDataUIDraw(propertyData.LogisticCourierCarries, 1f, 10000f, "配送机载量");
					propertyData.LogisticDroneCarries = PropertyDataUIDraw(propertyData.LogisticDroneCarries, 20f, 10000f, "运输机载量");
					propertyData.LogisticShipCarries = PropertyDataUIDraw(propertyData.LogisticShipCarries, 100f, 100000f, "运输船载量");
					propertyData.MiningCostRate = PropertyDataUIDraw(propertyData.MiningCostRate, 0f, 1f, "采矿消耗矿物比例", 4);
					propertyData.MiningSpeedScale = PropertyDataUIDraw(propertyData.MiningSpeedScale, 1f, 10000f, "采矿机速度倍率", 2);
					propertyData.LabLevel = PropertyDataUIDraw(propertyData.LabLevel, 2f, 100f, "建筑堆叠高度");
					propertyData.StorageLevel = PropertyDataUIDraw(propertyData.StorageLevel, 1f, 20f, "货物集装数量");
					propertyData.StackSizeMultiplier = PropertyDataUIDraw(propertyData.StackSizeMultiplier, 1f, 20f, "物流背包堆叠倍率");
				}
				else
				{
					PropertyDataUIDraw(propertyData.WalkSpeed, 1f, 100f, "走路速度", 2);
					PropertyDataUIDraw(propertyData.TechSpeed, 1f, 10000f, "研发速度");
					PropertyDataUIDraw(propertyData.DroneSpeed, 1f, 100f, "小飞机速度");
					PropertyDataUIDraw(propertyData.DroneCount, 1f, 400f, "小飞机数量");
					PropertyDataUIDraw(propertyData.MaxSailSpeed, 1f, 10f, "最大航行速度");
					PropertyDataUIDraw(propertyData.MaxWarpSpeed, 1f, 100f, "最大曲速");
					PropertyDataUIDraw(propertyData.BuildArea, 80f, 400f, "建造范围");
					PropertyDataUIDraw(propertyData.ReactorPowerGen, 1000000f, 1E+10f, "核心功率", 1);
					PropertyDataUIDraw(propertyData.LogisticCourierSpeed, 1f, 100f, "配送机速度");
					PropertyDataUIDraw(propertyData.LogisticDroneSpeedScale, 1f, 10000f, "运输机速度", 2);
					PropertyDataUIDraw(propertyData.LogisticShipSpeedScale, 1f, 10000f, "运输船速度", 2);
					PropertyDataUIDraw(propertyData.LogisticCourierCarries, 1f, 10000f, "配送机载量");
					PropertyDataUIDraw(propertyData.LogisticDroneCarries, 20f, 10000f, "运输机载量");
					PropertyDataUIDraw(propertyData.LogisticShipCarries, 100f, 100000f, "运输船载量");
					PropertyDataUIDraw(propertyData.MiningCostRate, 0f, 1f, "采矿消耗矿物比例", 4);
					PropertyDataUIDraw(propertyData.MiningSpeedScale, 1f, 10000f, "采矿机速度倍率", 2);
					PropertyDataUIDraw(propertyData.LabLevel, 2f, 100f, "建筑堆叠高度");
					PropertyDataUIDraw(propertyData.StorageLevel, 1f, 20f, "货物集装数量");
					PropertyDataUIDraw(propertyData.StackSizeMultiplier, 1f, 20f, "物流背包堆叠倍率");
				}
			}
			GUILayout.EndVertical();
			GUILayout.BeginVertical();
			Multifunction.Infinitething.Value = GUILayout.Toggle(Multifunction.Infinitething.Value, "无限物品".getTranslate());
			Multifunction.InfiniteSand.Value = GUILayout.Toggle(Multifunction.InfiniteSand.Value, "无限沙土".getTranslate());
			Multifunction.Property9999999 = GUILayout.Toggle(Multifunction.Property9999999, "无限元数据".getTranslate());
			Multifunction.DroneNoenergy_bool.Value = GUILayout.Toggle(Multifunction.DroneNoenergy_bool.Value, "小飞机不耗能".getTranslate());
			Multifunction.Infiniteplayerpower.Value = GUILayout.Toggle(Multifunction.Infiniteplayerpower.Value, "无限机甲能量".getTranslate());
			Multifunction.EnableTp.Value = GUILayout.Toggle(Multifunction.EnableTp.Value, "启用传送".getTranslate());
			Multifunction.unlockpointtech = GUILayout.Toggle(Multifunction.unlockpointtech, "科技点击解锁".getTranslate());
			Multifunction.dismantle_but_nobuild.Value = GUILayout.Toggle(Multifunction.dismantle_but_nobuild.Value, "不往背包放东西".getTranslate());
			Multifunction.MiddleMouseLockGrid.Value = GUILayout.Toggle(Multifunction.MiddleMouseLockGrid.Value, "鼠标中键锁定玩家背包格子Max".getTranslate());
			if (Multifunction.QuickHandcraft.Value != GUILayout.Toggle(Multifunction.QuickHandcraft.Value, "机甲制造MAX".getTranslate()))
			{
				Multifunction.QuickHandcraft.Value = !Multifunction.QuickHandcraft.Value;
				if (Multifunction.QuickHandcraft.Value)
				{
					GameMain.mainPlayer.mecha.replicateSpeed = 100f;
				}
				else
				{
					GameMain.mainPlayer.mecha.replicateSpeed = Configs.freeMode.mechaMiningSpeed;
				}
			}
			if (Multifunction.QuickPlayerMine.Value != GUILayout.Toggle(Multifunction.QuickPlayerMine.Value, "机甲采矿MAX".getTranslate()))
			{
				Multifunction.QuickPlayerMine.Value = !Multifunction.QuickPlayerMine.Value;
				if (Multifunction.QuickPlayerMine.Value)
				{
					GameMain.mainPlayer.mecha.miningSpeed = 100f;
				}
				else
				{
					GameMain.mainPlayer.mecha.miningSpeed = Configs.freeMode.mechaReplicateSpeed;
				}
			}
			Multifunction.QuickResearch.Value = GUILayout.Toggle(Multifunction.QuickResearch.Value, "研究秒完成".Translate());
			Multifunction.isInstantItem.Value = GUILayout.Toggle(Multifunction.isInstantItem.Value, "直接获取物品".getTranslate());
			Multifunction.noneedwarp.Value = GUILayout.Toggle(Multifunction.noneedwarp.Value, "无需翘曲器曲速飞行".getTranslate());
			if (GUILayout.Button("清空背包".getTranslate()))
			{
				MainFunction.Clearpackage();
			}
			if (GUILayout.Button("初始化玩家".getTranslate()))
			{
				MainFunction.InitPlayer();
			}
			GUILayout.BeginHorizontal();
			GUILayout.Button("背包".getTranslate(), GUILayout.Height(heightdis * 2));
			GUILayout.BeginVertical();
			if (GUILayout.Button("加一行".getTranslate(), GUILayout.Height(heightdis)))
			{
				MainFunction.Operatepackagesize(1, 0);
			}
			if (GUILayout.Button("加一列".getTranslate(), GUILayout.Height(heightdis)))
			{
				MainFunction.Operatepackagesize(0, 1);
			}
			GUILayout.EndVertical();
			GUILayout.BeginVertical();
			if (GUILayout.Button("减一行".getTranslate(), GUILayout.Height(heightdis)))
			{
				MainFunction.Operatepackagesize(1, 0, add: false);
			}
			if (GUILayout.Button("减一列".getTranslate(), GUILayout.Height(heightdis)))
			{
				MainFunction.Operatepackagesize(0, 1, add: false);
			}
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
			if (GUILayout.Button("解锁全部科技".getTranslate() + "(" + "补充原料".getTranslate() + ")"))
			{
				MainFunction.UnlockallTech(addstat: true);
			}
			if (GUILayout.Button("解锁全部科技".getTranslate()))
			{
				MainFunction.UnlockallTech();
			}
			if (GUILayout.Button("回退无穷科技".getTranslate()))
			{
				MainFunction.lockTech();
			}
			GUILayout.EndVertical();
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
		}

		private void BattlePannel()
		{
			GUILayout.BeginHorizontal();
			GUILayout.BeginVertical();
			Multifunction.LockPlayerHp.Value = GUILayout.Toggle(Multifunction.LockPlayerHp.Value, "玩家锁血".getTranslate());
			Multifunction.LockBuildHp.Value = GUILayout.Toggle(Multifunction.LockBuildHp.Value, "建筑锁血".getTranslate());
			Multifunction.LockEnemyHp.Value = GUILayout.Toggle(Multifunction.LockEnemyHp.Value, "怪物锁血".getTranslate());
			Multifunction.PlayerQuickAttack.Value = GUILayout.Toggle(Multifunction.PlayerQuickAttack.Value, "玩家攻速Max".getTranslate());
			Multifunction.PlayerFakeDeath.Value = GUILayout.Toggle(Multifunction.PlayerFakeDeath.Value, "玩家隐身".getTranslate());
			Multifunction.TurrentKeepSuperNoval.Value = GUILayout.Toggle(Multifunction.TurrentKeepSuperNoval.Value, "炮塔永久超新星".getTranslate());
			GUILayout.BeginHorizontal();
			GUILayout.Space(20f);
			Multifunction.TurrentKeepSuperNovalQuickKey.Value = GUILayout.Toggle(Multifunction.TurrentKeepSuperNovalQuickKey.Value, "启用快捷键(ctrl+s)".getTranslate());
			GUILayout.EndHorizontal();
			Multifunction.ClickGenerateDFRelay = GUILayout.Toggle(Multifunction.ClickGenerateDFRelay, "点击生成中继站".getTranslate());
			Multifunction.ClickKillEnemy.Value = GUILayout.Toggle(Multifunction.ClickKillEnemy.Value, "点击杀死敌人".getTranslate());
			if (Multifunction.ClickKillEnemy.Value)
			{
				GUILayout.BeginHorizontal();
				GUILayout.Label("点击模式".getTranslate());
				bool flag = GUILayout.Toggle(Multifunction.ClickKillEnemyMode.Value == 0, "点按".getTranslate());
				bool flag2 = GUILayout.Toggle(Multifunction.ClickKillEnemyMode.Value == 1, "按压".getTranslate());
				if (flag && Multifunction.ClickKillEnemyMode.Value == 1)
				{
					Multifunction.ClickKillEnemyMode.Value = 0;
				}
				else if (flag2 && Multifunction.ClickKillEnemyMode.Value == 0)
				{
					Multifunction.ClickKillEnemyMode.Value = 1;
				}
				GUILayout.EndHorizontal();
				Multifunction.ClickKillEnemyBaseChain = GUILayout.Toggle(Multifunction.ClickKillEnemyBaseChain, "基地核心连锁拆除".getTranslate());
			}
			Multifunction.LocalAlwaysClearThreat.Value = GUILayout.Toggle(Multifunction.LocalAlwaysClearThreat.Value, "星球永远0威胁".getTranslate());
			Multifunction.LocalAlwaysMaxThreat.Value = GUILayout.Toggle(Multifunction.LocalAlwaysMaxThreat.Value, "玩家所在星球永远满威胁".getTranslate());
			Multifunction.SpaceAlwaysClearThreat.Value = GUILayout.Toggle(Multifunction.SpaceAlwaysClearThreat.Value, "太空永远0威胁".getTranslate());
			Multifunction.SpaceAlwaysMaxThreat.Value = GUILayout.Toggle(Multifunction.SpaceAlwaysMaxThreat.Value, "玩家所在星系永远满威胁".getTranslate());
			Multifunction.ModifyDarkFogLevel.Value = GUILayout.Toggle(Multifunction.ModifyDarkFogLevel.Value, "调整黑雾怪物等级".getTranslate());
			GUILayout.Label("黑雾怪物等级".getTranslate() + ":" + Multifunction.ModifyDarkFogLevelValue.Value, style);
			Multifunction.ModifyDarkFogLevelValue.Value = (int)GUILayout.HorizontalSlider(Multifunction.ModifyDarkFogLevelValue.Value, 0f, 30f);
			if (GUILayout.Button("设置当前星球黑雾等级"))
			{
				ObjectPool<DFGBaseComponent> objectPool = GameMain.localPlanet?.factory?.enemySystem?.bases;
				if (objectPool != null)
				{
					for (int i = 1; i < objectPool.cursor; i++)
					{
						DFGBaseComponent dFGBaseComponent = objectPool[i];
						if (dFGBaseComponent != null && dFGBaseComponent.id == i)
						{
							UnityEngine.Debug.Log(i);
							dFGBaseComponent.evolve.level = Multifunction.ModifyDarkFogLevelValue.Value;
						}
					}
				}
			}
			if (GUILayout.Button("设置当前星系太空黑雾等级") && GameMain.localStar != null)
			{
				EnemyDFHiveSystem[] array = GameMain.data?.spaceSector?.dfHives;
				if (array != null)
				{
					EnemyDFHiveSystem[] array2 = array;
					foreach (EnemyDFHiveSystem enemyDFHiveSystem in array2)
					{
						if (enemyDFHiveSystem != null && enemyDFHiveSystem.starData != null && enemyDFHiveSystem.starData.id == GameMain.localStar.id)
						{
							enemyDFHiveSystem.evolve.level = Multifunction.ModifyDarkFogLevelValue.Value;
						}
					}
				}
			}
			GUILayout.EndVertical();
			GUILayout.Space(10f);
			GUILayout.BeginVertical();
			PropertyData propertyData = Multifunction.propertyData;
			if (GameMain.mainPlayer != null && Multifunction.propertyData != null)
			{
				if (ChangePlayerbool != GUILayout.Toggle(ChangePlayerbool, "启动属性修改".getTranslate()))
				{
					ChangePlayerbool = !ChangePlayerbool;
					if (ChangePlayerbool)
					{
						Multifunction.propertyData.SetContent(Multifunction.player.mecha, GameMain.history, Multifunction.player.deliveryPackage.stackSizeMultiplier);
					}
				}
				ModeConfig freeMode = Configs.freeMode;
				if (ChangePlayerbool)
				{
					propertyData.KineticDamageScale = PropertyDataUIDraw(propertyData.KineticDamageScale, 1f, 100f, "动能武器伤害系数", 2, morewidth: true);
					propertyData.EnergyDamageScale = PropertyDataUIDraw(propertyData.EnergyDamageScale, 1f, 100f, "能量武器伤害系数", 2, morewidth: true);
					propertyData.BlastDamageScale = PropertyDataUIDraw(propertyData.BlastDamageScale, 1f, 100f, "爆破武器伤害系数", 2, morewidth: true);
					propertyData.MagneticDamageScale = PropertyDataUIDraw(propertyData.MagneticDamageScale, 1f, 100f, "电磁武器伤害系数", 2, morewidth: true);
					propertyData.GlobalHpEnhancement = PropertyDataUIDraw(propertyData.GlobalHpEnhancement, 0f, 100f, "全局耐久度倍率", 2, morewidth: true);
					propertyData.EnemyDropScale = PropertyDataUIDraw(propertyData.EnemyDropScale, 0f, 1000f, "残骸产出倍率", 2, morewidth: true);
					propertyData.EnergyShieldRadius = PropertyDataUIDraw(propertyData.EnergyShieldRadius, freeMode.energyShieldRadius, 450f, "玩家护盾半径", 2, morewidth: true);
					propertyData.EnergyShieldCapacity = (long)PropertyDataUIDraw(propertyData.EnergyShieldCapacity, freeMode.energyShieldCapacity, 1E+11f, "玩家护盾能量上限", 3, morewidth: true);
					propertyData.HpMaxUpgrade = (int)PropertyDataUIDraw(propertyData.HpMaxUpgrade, 0f, 100000f, "玩家额外血量", 0, morewidth: true);
					propertyData.LaserAttackLocalRange = PropertyDataUIDraw(propertyData.LaserAttackLocalRange, freeMode.mechaLocalLaserAttackRange, 150f, "机甲激光本地攻击范围", 2, morewidth: true);
					propertyData.LaserAttackSpaceRange = PropertyDataUIDraw(propertyData.LaserAttackSpaceRange, freeMode.mechaSpaceLaserAttackRange, 15000f, "机甲激光太空攻击范围", 2, morewidth: true);
					propertyData.LaserAttackDamage = PropertyDataUIDraw(propertyData.LaserAttackDamage, 0f, 10000f, "机甲激光伤害", 2, morewidth: true);
					propertyData.LaserEnergyCost = PropertyDataUIDraw(propertyData.LaserEnergyCost, 0f, freeMode.mechaLocalLaserEnergyCost, "机甲激光消耗能量", 3, morewidth: true);
					propertyData.CombatDroneDamageRatio = PropertyDataUIDraw(propertyData.CombatDroneDamageRatio, 1f, 100f, "战斗飞机伤害倍率", 2, morewidth: true);
					propertyData.CombatDroneROFRatio = PropertyDataUIDraw(propertyData.CombatDroneROFRatio, 1f, 100f, "战斗飞机攻击速度倍率", 2, morewidth: true);
					propertyData.CombatDroneDurabilityRatio = PropertyDataUIDraw(propertyData.CombatDroneDurabilityRatio, 1f, 100f, "战斗飞机耐久度倍率", 2, morewidth: true);
					propertyData.CombatDroneSpeedRatio = PropertyDataUIDraw(propertyData.CombatDroneSpeedRatio, 1f, 100f, "战斗飞机速度倍率", 2, morewidth: true);
					propertyData.CombatShipDamageRatio = PropertyDataUIDraw(propertyData.CombatShipDamageRatio, 1f, 100f, "战斗飞船伤害倍率", 2, morewidth: true);
					propertyData.CombatShipROFRatio = PropertyDataUIDraw(propertyData.CombatShipROFRatio, 1f, 100f, "战斗飞船攻击速度倍率", 2, morewidth: true);
					propertyData.CombatShipDurabilityRatio = PropertyDataUIDraw(propertyData.CombatShipDurabilityRatio, 1f, 100f, "战斗飞船耐久度倍率", 2, morewidth: true);
					propertyData.CombatShipSpeedRatio = PropertyDataUIDraw(propertyData.CombatShipSpeedRatio, 1f, 100f, "战斗飞船速度倍率", 2, morewidth: true);
					propertyData.PlanetaryATFieldEnergyRate = (int)PropertyDataUIDraw(propertyData.PlanetaryATFieldEnergyRate, 1f, 100f, "星球防御盾能量倍率", 2, morewidth: true);
				}
				else
				{
					PropertyDataUIDraw(propertyData.KineticDamageScale, 1f, 100f, "动能武器伤害系数", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.EnergyDamageScale, 1f, 100f, "能量武器伤害系数", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.BlastDamageScale, 1f, 100f, "爆破武器伤害系数", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.MagneticDamageScale, 1f, 100f, "电磁武器伤害系数", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.GlobalHpEnhancement, 0f, 100f, "全局耐久度倍率", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.EnemyDropScale, 0f, 1000f, "残骸产出倍率", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.EnergyShieldRadius, freeMode.energyShieldRadius, 450f, "玩家护盾半径", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.EnergyShieldCapacity, freeMode.energyShieldCapacity, 1E+11f, "玩家护盾能量上限", 3, morewidth: true);
					PropertyDataUIDraw(propertyData.HpMaxUpgrade, 0f, 100000f, "玩家额外血量", 1, morewidth: true);
					PropertyDataUIDraw(propertyData.LaserAttackLocalRange, freeMode.mechaLocalLaserAttackRange, 150f, "机甲激光本地攻击范围", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.LaserAttackSpaceRange, freeMode.mechaSpaceLaserAttackRange, 15000f, "机甲激光太空攻击范围", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.LaserAttackDamage, 0f, 10000f, "机甲激光伤害", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.LaserEnergyCost, 0f, freeMode.mechaLocalLaserEnergyCost, "机甲激光消耗能量", 3, morewidth: true);
					PropertyDataUIDraw(propertyData.CombatDroneDamageRatio, 1f, 100f, "战斗飞机伤害倍率", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.CombatDroneROFRatio, 1f, 100f, "战斗飞机攻击速度倍率", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.CombatDroneDurabilityRatio, 1f, 100f, "战斗飞机耐久度倍率", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.CombatDroneSpeedRatio, 1f, 100f, "战斗飞机速度倍率", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.CombatShipDamageRatio, 1f, 100f, "战斗飞船伤害倍率", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.CombatShipROFRatio, 1f, 100f, "战斗飞船攻击速度倍率", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.CombatShipDurabilityRatio, 1f, 100f, "战斗飞船耐久度倍率", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.CombatShipSpeedRatio, 1f, 100f, "战斗飞船速度倍率", 2, morewidth: true);
					PropertyDataUIDraw(propertyData.PlanetaryATFieldEnergyRate, 1f, 100f, "星球防御盾能量倍率", 2, morewidth: true);
				}
			}
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
		}

		private void BuildPannel()
		{
			GUILayout.BeginHorizontal();
			GUILayout.BeginVertical();
			GUILayout.Label("物流站功能".getTranslate() + ":", style);
			GUILayout.BeginHorizontal();
			GUILayout.Space(BaseSize);
			GUILayout.BeginVertical();
			GUILayout.Label("额外存储倍率".getTranslate() + ":" + Multifunction.StationStoExtra.Value, style);
			Multifunction.StationStoExtra.Value = (int)GUILayout.HorizontalSlider(Multifunction.StationStoExtra.Value, 0f, 100f, GUILayout.Width(heightdis * 4));
			Multifunction.Stationfullenergy.Value = GUILayout.Toggle(Multifunction.Stationfullenergy.Value, "永久满电".getTranslate());
			Multifunction.StationfullCount = GUILayout.Toggle(Multifunction.StationfullCount, "要啥有啥".getTranslate());
			Multifunction.StationMaxproliferator.Value = GUILayout.Toggle(Multifunction.StationMaxproliferator.Value, "无限增产".getTranslate());
			Multifunction.StationSpray.Value = GUILayout.Toggle(Multifunction.StationSpray.Value, "内置喷涂".getTranslate());
			Multifunction.StationPowerGen.Value = GUILayout.Toggle(Multifunction.StationPowerGen.Value, "内置发电".getTranslate());
			Multifunction.Station_infiniteWarp_bool.Value = GUILayout.Toggle(Multifunction.Station_infiniteWarp_bool.Value, "无限翘曲".getTranslate());
			Multifunction.build_station_nocondition.Value = GUILayout.Toggle(Multifunction.build_station_nocondition.Value, "建造无需条件".getTranslate());
			GUILayout.Label("以下功能需改名".getTranslate() + ":", style);
			Multifunction.StationfullCount_bool.Value = GUILayout.Toggle(Multifunction.StationfullCount_bool.Value, "星球无限供货机".getTranslate());
			Multifunction.StationTrash.Value = GUILayout.Toggle(Multifunction.StationTrash.Value, "垃圾站".getTranslate());
			if (Multifunction.StationTrash.Value)
			{
				GUILayout.BeginHorizontal();
				GUILayout.Space(BaseSize);
				Multifunction.needtrashsand.Value = GUILayout.Toggle(Multifunction.needtrashsand.Value, "需要沙土".getTranslate());
				GUILayout.EndHorizontal();
			}
			Multifunction.StationMiner.Value = GUILayout.Toggle(Multifunction.StationMiner.Value, "星球矿机".getTranslate());
			if (Multifunction.StationMiner.Value)
			{
				GUILayout.BeginHorizontal();
				GUILayout.Space(BaseSize);
				GUILayout.BeginVertical();
				GUILayout.Label("采矿速率".getTranslate() + ":" + Multifunction.Stationminenumber.Value, style);
				Multifunction.Stationminenumber.Value = (int)GUILayout.HorizontalSlider(Multifunction.Stationminenumber.Value, 1f, 100f, GUILayout.Width(heightdis * 4));
				GUILayout.EndVertical();
				GUILayout.EndHorizontal();
			}
			Multifunction.StationSprayer.Value = GUILayout.Toggle(Multifunction.StationSprayer.Value, "喷涂加工厂".getTranslate());
			Multifunction.StationMinerSmelter.Value = GUILayout.Toggle(Multifunction.StationMinerSmelter.Value, "星球熔炉矿机".getTranslate());
			if (Multifunction.StationMinerSmelter.Value)
			{
				GUILayout.BeginHorizontal();
				GUILayout.Space(BaseSize);
				GUILayout.BeginVertical();
				GUILayout.Label("等价高级熔炉数量".getTranslate() + ":" + Multifunction.StationMinerSmelterNum.Value, style);
				int num = (int)GUILayout.HorizontalSlider(Multifunction.StationMinerSmelterNum.Value, 30f, 1000f, GUILayout.Width(heightdis * 4));
				if (num % 100 <= num % 30)
				{
					Multifunction.StationMinerSmelterNum.Value = num / 100 * 100;
				}
				else
				{
					Multifunction.StationMinerSmelterNum.Value = num / 30 * 30;
				}
				GUILayout.EndVertical();
				GUILayout.EndHorizontal();
			}
			GUILayout.Label("自动改名".getTranslate() + ":", style);
			string[] array = new string[7] { "星球无限供货机", "垃圾站", "星球矿机", "喷涂加工厂", "星球熔炉矿机", "星球量子传输站", "星系量子传输站" };
			for (int i = 0; i < array.Length; i++)
			{
				bool flag = GUILayout.Toggle(Multifunction.AutoChangeStationName.Value == array[i], array[i].getTranslate());
				if (flag && Multifunction.AutoChangeStationName.Value != array[i])
				{
					Multifunction.AutoChangeStationName.Value = array[i];
				}
				else if (!flag && Multifunction.AutoChangeStationName.Value == array[i])
				{
					Multifunction.AutoChangeStationName.Value = "";
				}
			}
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
			GUILayout.EndVertical();
			GUILayout.BeginVertical();
			GUILayout.Label("其它建筑功能".getTranslate() + ":", style);
			GUILayout.BeginHorizontal();
			GUILayout.Space(BaseSize);
			GUILayout.BeginVertical();
			GUILayout.Label("建造数量最大值".getTranslate() + ":" + Multifunction.Buildmaxlen.Value, style);
			int num2 = (int)GUILayout.HorizontalSlider(Multifunction.Buildmaxlen.Value, 15f, 100f, GUILayout.Width(heightdis * 4));
			if (num2 != Multifunction.Buildmaxlen.Value)
			{
				Multifunction.Buildmaxlen.Value = num2;
				GameMain.mainPlayer.controller.actionBuild.clickTool.dotsSnapped = new Vector3[num2];
			}
			Multifunction.InspectDisNoLimit.Value = GUILayout.Toggle(Multifunction.InspectDisNoLimit.Value, "操作范围不受限制".getTranslate());
			Multifunction.BuildNotime_bool.Value = GUILayout.Toggle(Multifunction.BuildNotime_bool.Value, "建筑秒完成".getTranslate());
			Multifunction.blueprintpastenoneed_bool.Value = GUILayout.Toggle(Multifunction.blueprintpastenoneed_bool.Value, "蓝图建造无需材料".getTranslate());
			Multifunction.ArchitectMode.Value = GUILayout.Toggle(Multifunction.ArchitectMode.Value, "建筑师模式".getTranslate());
			if (Multifunction.DriftBuildings != GUILayout.Toggle(Multifunction.DriftBuildings, "建筑抬升".getTranslate()))
			{
				Multifunction.DriftBuildings = !Multifunction.DriftBuildings;
				if (Multifunction.DriftBuildings && !DriftBuildingsPatch.IsPatched)
				{
					DriftBuildingsPatch.IsPatched = true;
					Multifunctionpatch.harmony.PatchAll(typeof(DriftBuildingsPatch));
				}
			}
			if (Multifunction.DriftBuildings)
			{
				GUILayout.Label("抬升层数:" + Multifunction.DriftBuildingLevel, style);
			}
			if (Multifunction.BeltSignalFunction.Value != GUILayout.Toggle(Multifunction.BeltSignalFunction.Value, "传送带信号功能".getTranslate()))
			{
				Multifunction.BeltSignalFunction.Value = !Multifunction.BeltSignalFunction.Value;
				if (Multifunction.BeltSignalFunction.Value)
				{
					MainFunction.InitBeltSignalDiction();
				}
			}
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
			GUILayout.Label("电力设备".getTranslate() + ":", style);
			GUILayout.BeginHorizontal();
			GUILayout.Space(BaseSize);
			GUILayout.BeginVertical();
			Multifunction.Buildingnoconsume.Value = GUILayout.Toggle(Multifunction.Buildingnoconsume.Value, "新建设备不耗电".getTranslate());
			Multifunction.InfineteStarPower.Value = GUILayout.Toggle(Multifunction.InfineteStarPower.Value, "人造恒星无限能源".getTranslate());
			Multifunction.PlanetPower_bool.Value = GUILayout.Toggle(Multifunction.PlanetPower_bool.Value, "星球电网(人造恒星)".getTranslate());
			if (Multifunction.PlanetPower_bool.Value)
			{
				GUILayout.BeginHorizontal();
				GUILayout.Space(BaseSize);
				GUILayout.BeginVertical();
				Multifunction.PlanetPower_bool.Value = GUILayout.Toggle(Multifunction.PlanetPower_bool.Value, "覆盖全球".getTranslate());
				Multifunction.farconnectdistance = GUILayout.Toggle(Multifunction.farconnectdistance, "超长连接".getTranslate());
				GUILayout.EndVertical();
				GUILayout.EndHorizontal();
			}
			Multifunction.WindturbinesUnlimitedEnergy.Value = GUILayout.Toggle(Multifunction.WindturbinesUnlimitedEnergy.Value, "风力涡轮机无限能源".getTranslate());
			Multifunction.Windturbinescovertheglobe.Value = GUILayout.Toggle(Multifunction.Windturbinescovertheglobe.Value, "风力涡轮机覆盖全球".getTranslate());
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
			GUILayout.Label("储液站功能".getTranslate() + ":", style);
			GUILayout.BeginHorizontal();
			GUILayout.Space(BaseSize);
			GUILayout.BeginVertical();
			Multifunction.Tankcontentall.Value = GUILayout.Toggle(Multifunction.Tankcontentall.Value, "储液站任意存".getTranslate());
			Multifunction.Infinitestoragetank.Value = GUILayout.Toggle(Multifunction.Infinitestoragetank.Value, "无限储液站".getTranslate());
			Multifunction.TankMaxproliferator.Value = GUILayout.Toggle(Multifunction.TankMaxproliferator.Value, "储液站无限增产".getTranslate());
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
			GUILayout.EndVertical();
			GUILayout.BeginVertical();
			Multifunction.Quantumtransport_bool.Value = GUILayout.Toggle(Multifunction.Quantumtransport_bool.Value, "量子传输站".getTranslate());
			if (Multifunction.Quantumtransport_bool.Value)
			{
				Multifunction.Quantumtransportpdwarp_bool.Value = GUILayout.Toggle(Multifunction.Quantumtransportpdwarp_bool.Value, "星球级翘曲全面供应".getTranslate());
				Multifunction.Quantumtransportstarwarp_bool.Value = GUILayout.Toggle(Multifunction.Quantumtransportstarwarp_bool.Value, "星系级翘曲全面供应".getTranslate());
				Multifunction.Quantumtransportbuild_bool.Value = GUILayout.Toggle(Multifunction.Quantumtransportbuild_bool.Value, "星球级材料供应".getTranslate());
				if (Multifunction.Quantumtransportbuild_bool.Value)
				{
					GUILayout.BeginVertical();
					GUILayout.BeginHorizontal();
					Multifunction.QuantumtransportCollectorSupply.Value = GUILayout.Toggle(Multifunction.QuantumtransportCollectorSupply.Value, "采集器拿取");
					GUILayout.EndHorizontal();
					GUILayout.BeginHorizontal();
					Multifunction.QuantumtransportstationSupply.Value = GUILayout.Toggle(Multifunction.QuantumtransportstationSupply.Value, "物流站供应");
					Multifunction.QuantumtransportstationDemand.Value = GUILayout.Toggle(Multifunction.QuantumtransportstationDemand.Value, "物流站拿取");
					GUILayout.EndHorizontal();
					GUILayout.BeginHorizontal();
					Multifunction.QuantumtransportminerDemand.Value = GUILayout.Toggle(Multifunction.QuantumtransportminerDemand.Value, "矿机拿取");
					GUILayout.EndHorizontal();
					GUILayout.BeginHorizontal();
					Multifunction.QuantumtransportsiloDemand.Value = GUILayout.Toggle(Multifunction.QuantumtransportsiloDemand.Value, "发射井弹射器供应");
					GUILayout.EndHorizontal();
					GUILayout.BeginHorizontal();
					Multifunction.QuantumtransportlabSupply.Value = GUILayout.Toggle(Multifunction.QuantumtransportlabSupply.Value, "研究站供应");
					Multifunction.QuantumtransportlabDemand.Value = GUILayout.Toggle(Multifunction.QuantumtransportlabDemand.Value, "研究站拿取");
					GUILayout.EndHorizontal();
					GUILayout.BeginHorizontal();
					Multifunction.QuantumtransportpowerSupply.Value = GUILayout.Toggle(Multifunction.QuantumtransportpowerSupply.Value, "电力设备供应");
					Multifunction.QuantumtransportpowerDemand.Value = GUILayout.Toggle(Multifunction.QuantumtransportpowerDemand.Value, "电力设备拿取");
					GUILayout.EndHorizontal();
					GUILayout.BeginHorizontal();
					Multifunction.QuantumtransportassembleSupply.Value = GUILayout.Toggle(Multifunction.QuantumtransportassembleSupply.Value, "组装机供应");
					Multifunction.QuantumtransportassembleDemand.Value = GUILayout.Toggle(Multifunction.QuantumtransportassembleDemand.Value, "组装机拿取");
					GUILayout.EndHorizontal();
					GUILayout.EndVertical();
				}
				GUILayoutOption[] options = new GUILayoutOption[2]
				{
					GUILayout.Height(heightdis),
					GUILayout.Width(heightdis * 5)
				};
				GUILayout.BeginHorizontal();
				int num3 = (int)GUILayout.HorizontalSlider(Multifunction.planetquamaxpowerpertick.Value, 60f, 10000f, options);
				GUILayout.Label((num3 > 1000) ? (num3 / 1000 + "G") : (num3 + "MW " + "星球量子充电功率".getTranslate()), style);
				GUILayout.EndHorizontal();
				GUILayout.BeginHorizontal();
				int num4 = (int)GUILayout.HorizontalSlider(Multifunction.starquamaxpowerpertick.Value, 60f, 10000f, options);
				GUILayout.Label((num4 > 1000) ? (num4 / 1000 + "G") : (num4 + "MW " + "星系量子充电功率".getTranslate()), style);
				GUILayout.EndHorizontal();
				GUILayout.BeginHorizontal();
				Multifunction.Quantumenergy.Value = (int)GUILayout.HorizontalSlider(Multifunction.Quantumenergy.Value, 0f, 1000000f, options);
				GUILayout.Label(NumberUtils.TGMKinttostring(Multifunction.Quantumenergy.Value, "J") + " " + "量子耗能/个".getTranslate(), style);
				GUILayout.EndHorizontal();
				if ((float)num3 != Multifunction.planetquamaxpowerpertick.Value || (float)num4 != Multifunction.starquamaxpowerpertick.Value)
				{
					Multifunction.changequapowerpertick = true;
					Multifunction.planetquamaxpowerpertick.Value = num3;
					Multifunction.starquamaxpowerpertick.Value = num4;
				}
			}
			GUILayout.EndVertical();
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
		}

		private void PlanetPannel()
		{
			GUILayout.Label("\"生成矿物\":鼠标左键生成矿物，鼠标右键取消。\"删除矿物\"：按x键进入拆除模式可拆除矿物。".getTranslate(), style);
			GUILayout.BeginHorizontal();
			GUILayout.BeginVertical();
			VeinControlProperty veinproperty = Multifunction.veinproperty;
			veinproperty.DeleteVein = GUILayout.Toggle(veinproperty.DeleteVein, "删除矿物".getTranslate());
			veinproperty.Changeveinpos = GUILayout.Toggle(veinproperty.Changeveinpos, "移动单矿".getTranslate());
			veinproperty.Changeveingrouppos = GUILayout.Toggle(veinproperty.Changeveingrouppos, "移动矿堆".getTranslate());
			veinproperty.NotTidyVein = GUILayout.Toggle(veinproperty.NotTidyVein, "不排列".getTranslate());
			veinproperty.GetallVein = GUILayout.Toggle(veinproperty.GetallVein, "整理所有矿".getTranslate());
			GUILayout.Label("整理为".getTranslate() + veinproperty.VeinLines + "行".getTranslate());
			veinproperty.VeinLines = (int)GUILayout.HorizontalSlider(veinproperty.VeinLines, 1f, 20f);
			veinproperty.Changexveinspos = GUILayout.Toggle(veinproperty.Changexveinspos, "切割矿脉".getTranslate());
			GUILayout.Label("切割出".getTranslate() + veinproperty.CuttingVeinNumbers + "个".getTranslate());
			veinproperty.CuttingVeinNumbers = (int)GUILayout.HorizontalSlider(veinproperty.CuttingVeinNumbers, 2f, 72f);
			GUILayout.EndVertical();
			GUILayout.Space(heightdis);
			GUILayout.BeginVertical();
			GUILayoutOption[] options = new GUILayoutOption[2]
			{
				GUILayout.Height(heightdis),
				GUILayout.Width(heightdis)
			};
			int num = 8;
			int num2 = LDB.veins.dataArray.Length;
			int num3 = num2 / num + ((num2 % num > 0) ? 1 : 0);
			for (int i = 0; i < num3; i++)
			{
				GUILayout.BeginHorizontal();
				for (int j = 0; j < num; j++)
				{
					int num4 = i * num + j + 1;
					if (num4 == num2 + 1)
					{
						break;
					}
					if (GUILayout.Button(LDB.items?.Select(LDB.veins.Select(num4).MiningItem)?.iconSprite?.texture, (veinproperty.VeinType == num4) ? selectedIconStyle : normalStyle, options))
					{
						veinproperty.VeinType = ((veinproperty.VeinType != num4) ? num4 : 0);
					}
				}
				GUILayout.EndHorizontal();
			}
			GUILayout.BeginHorizontal();
			GUILayout.Label("生成矿物模式".getTranslate());
			bool flag = GUILayout.Toggle(veinproperty.AddVeinMode == 0, "点按".getTranslate());
			bool flag2 = GUILayout.Toggle(veinproperty.AddVeinMode == 1, "按压".getTranslate());
			GUILayout.EndHorizontal();
			if (flag && veinproperty.AddVeinMode == 1)
			{
				veinproperty.AddVeinMode = 0;
			}
			else if (flag2 && veinproperty.AddVeinMode == 0)
			{
				veinproperty.AddVeinMode = 1;
			}
			if (veinproperty.VeinType == 7)
			{
				GUILayout.BeginHorizontal();
				GUILayout.Label("添加油井速率".getTranslate());
				for (int k = 0; k < 3; k++)
				{
					bool flag3 = GUILayout.Toggle(veinproperty.OilAddIntervalBool[k], (float)veinproperty.OilAddIntervalValue[k] / 10f + "/s");
					if (flag3 != veinproperty.OilAddIntervalBool[k] && flag3)
					{
						veinproperty.SetOilAddInterval(k);
					}
				}
				GUILayout.EndHorizontal();
			}
			else
			{
				GUILayout.BeginHorizontal();
				GUILayout.Label("添加矿脉数量".getTranslate());
				bool flag4 = GUILayout.Toggle(veinproperty.AddVeinNumber == 500, "500");
				bool flag5 = GUILayout.Toggle(veinproperty.AddVeinNumber != 500, "无穷".getTranslate());
				if (flag4 && veinproperty.AddVeinNumber != 500)
				{
					veinproperty.AddVeinNumber = 500;
				}
				else if (flag5 && veinproperty.AddVeinNumber == 500)
				{
					veinproperty.AddVeinNumber = 1000000000;
				}
				GUILayout.EndHorizontal();
			}
			GUILayout.EndVertical();
			GUILayout.Space(heightdis);
			GUILayout.BeginVertical();
			Multifunction.restorewater = GUILayout.Toggle(Multifunction.restorewater, "还原海洋".getTranslate());
			string[] array = new string[6]
			{
				(!Multifunction.restorewater) ? "铺平整个星球" : "还原全部海洋",
				"掩埋全部矿",
				"删除全部矿",
				"超密铺采集器",
				"删除当前星球所有建筑",
				"删除当前星球所有建筑(不掉落)"
			};
			for (int l = 0; l < array.Length; l++)
			{
				if (GUILayout.Button(array[l].getTranslate(), GUILayout.Height(heightdis)))
				{
					switch (l)
					{
					case 0:
						MainFunction.OnSetBase();
						break;
					case 1:
						veinproperty.BuryAllvein();
						break;
					case 2:
						veinproperty.RemoveAllvein();
						break;
					case 3:
						MainFunction.SetMaxGasStation();
						break;
					case 4:
						MainFunction.RemoveAllBuild(0);
						break;
					case 5:
						MainFunction.RemoveAllBuild(1);
						break;
					}
				}
			}
			MainFunction.currentPlanetWaterType = GUILayout.TextField(MainFunction.currentPlanetWaterType, GUILayout.MinWidth(heightdis * 3));
			if (GUILayout.Button("设置当前星球海洋类型".getTranslate(), GUILayout.Height(heightdis)))
			{
				MainFunction.SetWaterType();
			}
			if (GUILayout.Button("恢复所有星球海洋类型".getTranslate(), GUILayout.Height(heightdis)))
			{
				MainFunction.RestoreWaterType();
			}
			GUILayout.EndVertical();
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
		}

		private void DysonPannel()
		{
			GUILayout.Label("注意事项:戴森云和戴森壳不要出现一层轨道都没有的情况(用前存档)".getTranslate(), style);
			GUILayout.BeginHorizontal();
			GUILayout.BeginVertical();
			if (GameMain.localStar != null && GameMain.data.dysonSpheres != null && GameMain.data.dysonSpheres[GameMain.localStar.index] != null)
			{
				DysonSphere dysonSphere = GameMain.data.dysonSpheres[GameMain.localStar.index];
				List<int> list = new List<int>();
				DysonSphereLayer[] layersIdBased = GameMain.data.dysonSpheres[GameMain.localStar.index].layersIdBased;
				foreach (DysonSphereLayer dysonSphereLayer in layersIdBased)
				{
					if (dysonSphereLayer != null)
					{
						list.Add(dysonSphereLayer.id);
					}
				}
				GUILayout.Label("点击删除下列戴森壳层级".getTranslate(), style);
				GUILayout.BeginHorizontal();
				for (int j = 1; j <= 5; j++)
				{
					bool flag = list.Contains(j);
					bool flag2 = GUILayout.Button(flag ? j.ToString() : "", iconbuttonoptions);
					if (!(flag2 && flag))
					{
						continue;
					}
					for (int k = 1; k < dysonSphere.rocketCursor; k++)
					{
						if (dysonSphere.rocketPool[k].id == k)
						{
							dysonSphere.RemoveDysonRocket(k);
						}
					}
					dysonSphere.RemoveLayer(j);
				}
				GUILayout.EndHorizontal();
				GUILayout.BeginHorizontal();
				for (int l = 6; l <= 10; l++)
				{
					bool flag3 = list.Contains(l);
					bool flag4 = GUILayout.Button(flag3 ? l.ToString() : "", iconbuttonoptions);
					if (!(flag4 && flag3))
					{
						continue;
					}
					for (int m = 1; m < dysonSphere.rocketCursor; m++)
					{
						if (dysonSphere.rocketPool[m].id == m)
						{
							dysonSphere.RemoveDysonRocket(m);
						}
					}
					dysonSphere.RemoveLayer(l);
				}
				GUILayout.EndHorizontal();
				if (GUILayout.Button("初始化当前戴森球".getTranslate(), GUILayout.Height(heightdis)) && GameMain.localStar != null && GameMain.data.dysonSpheres[GameMain.localStar.index] != null)
				{
					int index = GameMain.localStar.index;
					GameMain.data.dysonSpheres[index] = new DysonSphere();
					GameMain.data.dysonSpheres[index].Init(GameMain.data, GameMain.localStar);
					GameMain.data.dysonSpheres[index].ResetNew();
				}
				if (GUILayout.Button("瞬间完成戴森球(用前存档)".getTranslate(), GUILayout.Height(heightdis)))
				{
					MainFunction.FinishDysonShell();
				}
			}
			Multifunction.quickEjector = GUILayout.Toggle(Multifunction.quickEjector, "极速轨道弹射器(慎用)".getTranslate());
			Multifunction.quicksilo = GUILayout.Toggle(Multifunction.quicksilo, "极速垂直发射井(慎用)".getTranslate());
			if (Multifunction.cancelsolarbullet.Value != GUILayout.Toggle(Multifunction.cancelsolarbullet.Value, "跳过太阳帆子弹阶段".getTranslate()))
			{
				Multifunction.cancelsolarbullet.Value = !Multifunction.cancelsolarbullet.Value;
			}
			Multifunction.quickabsorbsolar.Value = GUILayout.Toggle(Multifunction.quickabsorbsolar.Value, "跳过太阳帆吸收阶段".getTranslate());
			Multifunction.QuickabortSwarm.Value = GUILayout.Toggle(Multifunction.QuickabortSwarm.Value, "太阳帆帧吸收".getTranslate() + ":" + Multifunction.Solarsailsabsorbeveryframe.Value);
			if (Multifunction.QuickabortSwarm.Value)
			{
				GUILayout.BeginHorizontal();
				GUILayout.Space(10f);
				Multifunction.Solarsailsabsorbeveryframe.Value = (int)GUILayout.HorizontalSlider(Multifunction.Solarsailsabsorbeveryframe.Value, 1f, 100f);
				GUILayout.EndHorizontal();
			}
			if (Multifunction.alwaysemission.Value != GUILayout.Toggle(Multifunction.alwaysemission.Value, "全球打帆".getTranslate()))
			{
				Multifunction.alwaysemission.Value = !Multifunction.alwaysemission.Value;
				Multifunction.alwaysemissiontemp = Multifunction.alwaysemission.Value;
			}
			bool flag5 = GUILayout.Toggle(Multifunction.ChangeDysonradius.Value, "开放戴森壳半径上下限(用前存档)".getTranslate());
			GUILayout.Label("最小半径".getTranslate() + ":100", style);
			GUILayout.Label("最大半径".getTranslate() + ":" + NumberUtils.TGMKinttostring(Multifunction.MaxOrbitRadiusConfig.Value, ""), style);
			string valueStr = Regex.Replace(GUILayout.TextField(Multifunction.MaxOrbitRadiusConfig.Value.ToString() ?? "", 10), "[^0-9]", "");
			Multifunction.MaxOrbitRadiusConfig.Value = NumberUtils.IntParseLimit(valueStr, 100000, 10000000);
			if (flag5 != Multifunction.ChangeDysonradius.Value)
			{
				Multifunction.ChangeDysonradius.Value = flag5;
				DysonSphere dysonSphere2 = UIRoot.instance?.uiGame?.dysonEditor?.selection?.viewDysonSphere;
				DysonSphere[] array = GameMain.data?.dysonSpheres;
				foreach (DysonSphere dysonSphere3 in array)
				{
					if (dysonSphere3 == null)
					{
						continue;
					}
					if (flag5)
					{
						dysonSphere3.maxOrbitRadius = Multifunction.MaxOrbitRadiusConfig.Value;
						dysonSphere3.minOrbitRadius = 100f;
					}
					else
					{
						dysonSphere3.minOrbitRadius = dysonSphere3.starData.physicsRadius * 1.5f;
						if (dysonSphere3.minOrbitRadius < 4000f)
						{
							dysonSphere3.minOrbitRadius = 4000f;
						}
						dysonSphere3.maxOrbitRadius = dysonSphere3.defOrbitRadius * 2f;
						if (dysonSphere3.starData.type == EStarType.GiantStar)
						{
							dysonSphere3.minOrbitRadius *= 0.6f;
						}
						dysonSphere3.minOrbitRadius = Mathf.Ceil(dysonSphere3.minOrbitRadius / 100f) * 100f;
						dysonSphere3.maxOrbitRadius = Mathf.Round(dysonSphere3.maxOrbitRadius / 100f) * 100f;
					}
					if (dysonSphere2 == dysonSphere3)
					{
						UIRoot.instance.uiGame.dysonEditor.controlPanel.OnViewStarChange(dysonSphere3);
					}
				}
			}
			GUILayout.EndVertical();
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
		}

		private void OtherPannel()
		{
			GUILayout.BeginHorizontal();
			GUILayout.BeginVertical();
			GUILayout.Label("以下设置需要进入存档".getTranslate(), style);
			if (GameMain.mainPlayer != null)
			{
				Multifunction.CloseUIAbnormalityTip.Value = GUILayout.Toggle(Multifunction.CloseUIAbnormalityTip.Value, "关闭异常提示".getTranslate());
				Multifunction.IgnoreControlPanelLocalLimit.Value = GUILayout.Toggle(Multifunction.IgnoreControlPanelLocalLimit.Value, "取消总控面板本地限制".getTranslate());
				Multifunction.Maxproliferator.Value = GUILayout.Toggle(Multifunction.Maxproliferator.Value, "增产点数上限10".getTranslate());
				Multifunction.incAbility = (Multifunction.Maxproliferator.Value ? 10 : 4);
				Multifunction.pasteanyway = GUILayout.Toggle(Multifunction.pasteanyway, "蓝图强制粘贴".getTranslate());
				if (Multifunction.PasteBuildAnyWay != GUILayout.Toggle(Multifunction.PasteBuildAnyWay, "建筑铺设无需条件".getTranslate()))
				{
					Multifunction.PasteBuildAnyWay = !Multifunction.PasteBuildAnyWay;
					if (Multifunction.PasteBuildAnyWay && !PasteAnywayPatch.IsPatched)
					{
						PasteAnywayPatch.IsPatched = true;
						Multifunctionpatch.harmony.PatchAll(typeof(PasteAnywayPatch));
					}
				}
				if (Multifunction.closeallcollider != GUILayout.Toggle(Multifunction.closeallcollider, "关闭所有碰撞体".getTranslate()))
				{
					Multifunction.closeallcollider = !Multifunction.closeallcollider;
					ColliderPool.instance.gameObject.SetActive(!Multifunction.closeallcollider);
				}
				if (Multifunction.allhandcraft.Value != GUILayout.Toggle(Multifunction.allhandcraft.Value, "全部手搓".getTranslate()))
				{
					Multifunction.allhandcraft.Value = !Multifunction.allhandcraft.Value;
					Multifunction.refreshLDB = true;
				}
				if (Multifunction.quickproduce.Value != GUILayout.Toggle(Multifunction.quickproduce.Value, "快速生产".getTranslate()))
				{
					Multifunction.quickproduce.Value = !Multifunction.quickproduce.Value;
					Multifunction.refreshLDB = true;
				}
				GUILayout.Label("堆叠倍率".getTranslate() + ":", style);
				GUILayout.BeginHorizontal();
				stackmultipleStr = Regex.Replace(GUILayout.TextField(stackmultipleStr, 10, GUILayout.MinWidth(heightdis * 3)), "[^0-9]", "");
				int multiple = NumberUtils.IntParseLimit(stackmultipleStr, 1, 5000000);
				stackmultipleStr = multiple.ToString();
				if (GUILayout.Button("设置".getTranslate()))
				{
					MainFunction.SetmultipleItemStatck(multiple);
				}
				GUILayout.EndHorizontal();
				if (GUILayout.Button("取消所有勾选".getTranslate()))
				{
					MainFunction.CancelAllToggle();
				}
			}
			GUILayout.EndVertical();
			GUILayout.Space(heightdis);
			GUILayout.BeginVertical();
			GUILayout.Label("窗口颜色及透明度".getTranslate() + " RGBA", style);
			GUILayout.BeginHorizontal();
			float num = GUILayout.HorizontalSlider(mainWindowTextureColor.r, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
			GUILayout.Label("R:" + $"{num:N2}", style);
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal();
			float num2 = GUILayout.HorizontalSlider(mainWindowTextureColor.g, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
			GUILayout.Label("G:" + $"{num2:N2}", style);
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal();
			float num3 = GUILayout.HorizontalSlider(mainWindowTextureColor.b, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
			GUILayout.Label("B:" + $"{num3:N2}", style);
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal();
			float num4 = GUILayout.HorizontalSlider(mainWindowTextureColor.a, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
			GUILayout.Label("A:" + $"{num4:N2}", style);
			GUILayout.EndHorizontal();
			if (num != mainWindowTextureColor.r || num2 != mainWindowTextureColor.g || num3 != mainWindowTextureColor.b || num4 != mainWindowTextureColor.a)
			{
				mainWindowTextureColor = new Color(num, num2, num3, num4);
				for (int i = 0; i < MainWindowTexture.width; i++)
				{
					for (int j = 0; j < MainWindowTexture.height; j++)
					{
						MainWindowTexture.SetPixel(i, j, mainWindowTextureColor);
					}
				}
				MainWindowTexture.Apply();
			}
			GUILayout.Label("窗口字体颜色".getTranslate() + " RGB", style);
			GUILayout.BeginHorizontal();
			float num5 = GUILayout.HorizontalSlider(TextColor.r, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
			GUILayout.Label("R:" + $"{num5:N2}", style);
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal();
			float num6 = GUILayout.HorizontalSlider(TextColor.g, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
			GUILayout.Label("G:" + $"{num6:N2}", style);
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal();
			float num7 = GUILayout.HorizontalSlider(TextColor.b, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
			GUILayout.Label("B:" + $"{num7:N2}", style);
			GUILayout.EndHorizontal();
			if (num5 != TextColor.r || num6 != TextColor.g || num7 != TextColor.b)
			{
				TextColor = new Color(num5, num6, num7);
			}
			Multifunction.ChangeQuickKey = GUILayout.Toggle(Multifunction.ChangeQuickKey, (!Multifunction.ChangeQuickKey) ? "改变窗口快捷键".getTranslate() : "点击确认".getTranslate());
			GUILayout.Label("快捷键".getTranslate() + ":" + Multifunction.tempShowWindow.ToString());
			GUILayout.EndVertical();
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
		}

		private void LogisticsPannel()
		{
			GUILayout.BeginHorizontal();
			GUILayout.BeginVertical();
			GUILayout.Label("如果启动机甲物流，物流背包没有解锁会自动解锁一列。", style);
			GUILayout.Label("物流背包里的设置可以直接从全星系的存储设备中获取或回收", style);
			GUILayout.Label("设置机甲物流专用星后，只有名字是\"机甲物流\"的星球才会进行物流操作", style);
			GUILayoutOption[] options = new GUILayoutOption[1] { GUILayout.Height(heightdis) };
			if (Multifunction.Mechalogistics_bool.Value != GUILayout.Toggle(Multifunction.Mechalogistics_bool.Value, "强化机甲物流".getTranslate(), options))
			{
				Multifunction.Mechalogistics_bool.Value = !Multifunction.Mechalogistics_bool.Value;
				if (Multifunction.Mechalogistics_bool.Value && !Multifunction.player.deliveryPackage.unlocked)
				{
					Multifunction.player.deliveryPackage.unlocked = true;
					Multifunction.player.deliveryPackage.colCount = 1;
					Multifunction.player.deliveryPackage.NotifySizeChange();
				}
			}
			GUILayout.BeginHorizontal();
			GUILayout.Label("所有物品(优先度）");
			Multifunction.MechalogPlayerStorageFirst_bool.Value = GUILayout.Toggle(Multifunction.MechalogPlayerStorageFirst_bool.Value, "玩家背包".getTranslate(), options);
			if (GUILayout.Toggle(!Multifunction.MechalogPlayerStorageFirst_bool.Value, "物流背包".getTranslate(), options) == Multifunction.MechalogPlayerStorageFirst_bool.Value)
			{
				Multifunction.MechalogPlayerStorageFirst_bool.Value = false;
			}
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal();
			GUILayout.Label("建筑物品(优先度）");
			Multifunction.MechalogBuildGotoPlayerStorageFirst_bool.Value = GUILayout.Toggle(Multifunction.MechalogBuildGotoPlayerStorageFirst_bool.Value, "玩家背包".getTranslate(), options);
			if (GUILayout.Toggle(!Multifunction.MechalogBuildGotoPlayerStorageFirst_bool.Value, "物流背包".getTranslate(), options) == Multifunction.MechalogBuildGotoPlayerStorageFirst_bool.Value)
			{
				Multifunction.MechalogBuildGotoPlayerStorageFirst_bool.Value = false;
			}
			if (Multifunction.MechalogPlayerStorageFirst_bool.Value)
			{
				Multifunction.MechalogBuildGotoPlayerStorageFirst_bool.Value = true;
			}
			GUILayout.EndHorizontal();
			Multifunction.MechalogisticsPlanet_bool.Value = GUILayout.Toggle(Multifunction.MechalogisticsPlanet_bool.Value, "机甲物流专用星".getTranslate(), options);
			Multifunction.MechalogStoragerecycle_bool.Value = GUILayout.Toggle(Multifunction.MechalogStoragerecycle_bool.Value, "回收使用储物仓".getTranslate(), options);
			Multifunction.MechalogStorageprovide_bool.Value = GUILayout.Toggle(Multifunction.MechalogStorageprovide_bool.Value, "需求使用储物仓".getTranslate(), options);
			Multifunction.MechalogStationrecycle_bool.Value = GUILayout.Toggle(Multifunction.MechalogStationrecycle_bool.Value, "回收使用物流站".getTranslate(), options);
			Multifunction.MechalogStationprovide_bool.Value = GUILayout.Toggle(Multifunction.MechalogStationprovide_bool.Value, "需求使用物流站".getTranslate(), options);
			GUILayout.EndVertical();
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
		}

		private bool MoveWindow()
		{
			float num = MainWindow_x;
			float num2 = MainWindow_y;
			if (leftscaling || rightscaling || bottomscaling)
			{
				return false;
			}
			Vector2 vector = Input.mousePosition;
			float x = vector.x;
			float num3 = (float)Screen.height - vector.y;
			bool flag = x > MainWindow_x && x < MainWindow_x + MainWindowWidth && num3 > MainWindow_y && num3 < MainWindow_y + 20f;
			if (Input.GetMouseButtonDown(0) && flag)
			{
				DragStartWindowX = MainWindow_x;
				DragStartWindowY = MainWindow_y;
				DragStartMouseX = x;
				DragStartMouseY = num3;
				isDragging = true;
			}
			if (isDragging && Input.GetMouseButton(0))
			{
				MainWindow_x = DragStartWindowX + x - DragStartMouseX;
				MainWindow_y = DragStartWindowY + num3 - DragStartMouseY;
			}
			if (Input.GetMouseButtonUp(0))
			{
				isDragging = false;
			}
			MainWindow_y = Math.Max(10f, Math.Min((float)Screen.height - 10f, MainWindow_y));
			MainWindow_x = Math.Max(10f, Math.Min((float)Screen.width - 10f, MainWindow_x));
			return MainWindow_x != num || MainWindow_y != num2;
		}

		private bool Scaling_window()
		{
			float num = MainWindowWidth;
			float num2 = MainWindowHeight;
			Vector2 vector = Input.mousePosition;
			float num3 = MainWindowWidth;
			float num4 = MainWindowHeight;
			if (Input.GetMouseButton(0))
			{
				if ((vector.x + 10f > MainWindow_x && vector.x - 10f < MainWindow_x && (float)Screen.height - vector.y >= MainWindow_y && (float)Screen.height - vector.y <= MainWindow_y + num4) || leftscaling)
				{
					num3 -= vector.x - MainWindow_x;
					MainWindow_x = vector.x;
					leftscaling = true;
					rightscaling = false;
				}
				if ((vector.x + 10f > MainWindow_x + num3 && vector.x - 10f < MainWindow_x + num3 && (float)Screen.height - vector.y >= MainWindow_y && (float)Screen.height - vector.y <= MainWindow_y + num4) || rightscaling)
				{
					num3 += vector.x - MainWindow_x - num3;
					rightscaling = true;
					leftscaling = false;
				}
				if (((float)Screen.height - vector.y + 10f > num4 + MainWindow_y && (float)Screen.height - vector.y - 10f < num4 + MainWindow_y && vector.x >= MainWindow_x && vector.x <= MainWindow_x + num3) || bottomscaling)
				{
					num4 += (float)Screen.height - vector.y - (MainWindow_y + num4);
					bottomscaling = true;
				}
			}
			if (Input.GetMouseButtonUp(0))
			{
				rightscaling = false;
				leftscaling = false;
				bottomscaling = false;
			}
			MainWindowWidth = Math.Max(100f, num3);
			MainWindowHeight = Math.Max(100f, num4);
			return MainWindowWidth != num || MainWindowHeight != num2;
		}
	}
	[BepInPlugin("cn.blacksnipe.dsp.Multfuntion_mod", "Multfuntion_mod", "4.0.6")]
	public class Multifunction : BaseUnityPlugin
	{
		private static bool ResizePackage(Player target, int rowDelta, int columnDelta, bool add)
		{
			if (target?.package == null || rowDelta < 0 || columnDelta < 0 || target.packageColCount <= 0) return false;
			var package = target.package;
			int oldColumns = target.packageColCount;
			long oldRows = ((long)package.size + oldColumns - 1) / oldColumns;
			long columns = Math.Max(10L, Math.Min(30L, oldColumns + (add ? (long)columnDelta : -(long)columnDelta)));
			long rows = Math.Max(1L, oldRows + (add ? (long)rowDelta : -(long)rowDelta));
			long size = rows * columns;
			if (size > int.MaxValue) return false;
			for (int i = 0; i < package.size; i++)
				if ((i / oldColumns >= rows || i % oldColumns >= columns) && (package.grids[i].count != 0 || package.grids[i].filter != 0)) return false;
			var grids = new StorageComponent.GRID[(int)size];
			for (int i = 0; i < package.size; i++)
				if (i / oldColumns < rows && i % oldColumns < columns) grids[(i / oldColumns) * (int)columns + i % oldColumns] = package.grids[i];
			target.packageColCount = (int)columns;
			package.grids = grids; package.size = (int)size;
			package.ResetOptimizationFlags(); package.NotifyStorageChange(); package.NotifyStorageSizeChange();
			return true;
		}
		public const string GUID = "cn.blacksnipe.dsp.Multfuntion_mod";

		public const string NAME = "Multfuntion_mod";

		public const string VERSION = "4.0.6";

		public static bool IsEnglish;

		public int ReformType;

		public int ReformColor;

		public float OnesecondTime;

		public float HalfsecondTime;

		public string currentPlanetWaterType = "";

		private SeedPlanetWater originWaterTypes;

		private SeedPlanetWater currentWaterTypes;

		public Dictionary<long, SeedPlanetWater> seedPlanetWaterTypes;

		public static GUIDraw guidraw;

		public static PropertyData propertyData;

		public static VeinControlProperty veinproperty;

		public static bool OneSecondTimeElapse;

		public static bool HalfSecondTimeElapse;

		public RecipeProto[] originRecipeProtos;

		public static Player player;

		public static Queue<EnemyData> killEnemys = new Queue<EnemyData>();

		public static KeyboardShortcut tempShowWindow;

		private static int driftBuildingLevel;

		public static float DriftBuildingHeight = 1f;

		public static int incAbility = 4;

		private static bool LDBInitSave;

		public static bool refreshLDB;

		public static bool GameRunning;

		public static bool refreshPlayerData;

		public static bool changequapowerpertick;

		public static bool StationfullCount;

		public static bool ChangeQuickKey;

		public static bool ChangingQuickKey;

		public static bool blueprintPasteToolActive;

		public static bool DriftBuildings;

		public static bool Property9999999;

		public static bool alwaysemissiontemp;

		public static bool FinallyInit;

		public static bool restorewater;

		public static bool entityitemnoneed;

		public static bool quickEjector;

		public static bool quicksilo;

		public static bool ClickKillEnemyBaseChain;

		public static int temp;

		public static bool farconnectdistance;

		public static bool pasteanyway;

		public static bool PasteBuildAnyWay;

		public static bool closeallcollider;

		public static bool unlockpointtech;

		public static bool ClickGenerateDFRelay;

		public static bool ClickGenerateDFRelayLockClick;

		public string watertype = "";

		public static Dictionary<int, List<RecipeProto>> smeltRecipes = new Dictionary<int, List<RecipeProto>>();

		public static Dictionary<int, Dictionary<int, int>> Beltsignal = new Dictionary<int, Dictionary<int, int>>();

		public static Dictionary<int, Dictionary<int, int>> Beltsignalnumberoutput = new Dictionary<int, Dictionary<int, int>>();

		public static ConfigEntry<KeyboardShortcut> QuickKey;

		public static ConfigEntry<int> veinlines;

		public static ConfigEntry<int> scale;

		public static ConfigEntry<int> StackMultiple;

		public static ConfigEntry<int> StationStoExtra;

		public static ConfigEntry<int> Stationminenumber;

		public static ConfigEntry<int> Buildmaxlen;

		public static ConfigEntry<int> Quantumenergy;

		public static ConfigEntry<int> CuttingVeinNumbers;

		public static ConfigEntry<int> MaxOrbitRadiusConfig;

		public static ConfigEntry<int> Solarsailsabsorbeveryframe;

		public static ConfigEntry<int> StationMinerSmelterNum;

		public static ConfigEntry<int> ClickKillEnemyMode;

		public static ConfigEntry<Color> Textcolor;

		public static ConfigEntry<Color> mainWindowTextureColor_config;

		public static ConfigEntry<float> MainWindow_width;

		public static ConfigEntry<float> MainWindow_height;

		public static ConfigEntry<float> MainWindow_x_config;

		public static ConfigEntry<float> MainWindow_y_config;

		public static ConfigEntry<float> starquamaxpowerpertick;

		public static ConfigEntry<float> planetquamaxpowerpertick;

		public static ConfigEntry<bool> InfiniteSand;

		public static ConfigEntry<bool> isInstantItem;

		public static ConfigEntry<bool> WindturbinesUnlimitedEnergy;

		public static ConfigEntry<bool> Windturbinescovertheglobe;

		public static ConfigEntry<bool> NotTidyVein;

		public static ConfigEntry<bool> InspectDisNoLimit;

		public static ConfigEntry<bool> StationMaxproliferator;

		public static ConfigEntry<bool> Mechalogistics_bool;

		public static ConfigEntry<bool> MechalogBuildGotoPlayerStorageFirst_bool;

		public static ConfigEntry<bool> MechalogPlayerStorageFirst_bool;

		public static ConfigEntry<bool> MechalogStoragerecycle_bool;

		public static ConfigEntry<bool> MechalogStorageprovide_bool;

		public static ConfigEntry<bool> MechalogStationrecycle_bool;

		public static ConfigEntry<bool> MechalogStationprovide_bool;

		public static ConfigEntry<bool> Infinitestoragetank;

		public static ConfigEntry<bool> QuickHandcraft;

		public static ConfigEntry<bool> QuickPlayerMine;

		public static ConfigEntry<bool> QuickResearch;

		public static ConfigEntry<bool> TankMaxproliferator;

		public static ConfigEntry<bool> Quantumtransport_bool;

		public static ConfigEntry<bool> Quantumtransportbuild_bool;

		public static ConfigEntry<bool> Quantumtransportpdwarp_bool;

		public static ConfigEntry<bool> Quantumtransportstarwarp_bool;

		public static ConfigEntry<bool> needtrashsand;

		public static ConfigEntry<bool> InfineteStarPower;

		public static ConfigEntry<bool> PlanetPower_bool;

		public static ConfigEntry<bool> allhandcraft;

		public static ConfigEntry<bool> quickproduce;

		public static ConfigEntry<bool> blueprintpastenoneed_bool;

		public static ConfigEntry<bool> noneedwarp;

		public static ConfigEntry<bool> Infinitething;

		public static ConfigEntry<bool> Infiniteplayerpower;

		public static ConfigEntry<bool> EnableTp;

		public static ConfigEntry<bool> deleteveinbool;

		public static ConfigEntry<bool> MechalogisticsPlanet_bool;

		public static ConfigEntry<bool> StationMiner;

		public static ConfigEntry<bool> StationSprayer;

		public static ConfigEntry<bool> StationMinerSmelter;

		public static ConfigEntry<bool> dismantle_but_nobuild;

		public static ConfigEntry<bool> MiddleMouseLockGrid;

		public static ConfigEntry<bool> build_station_nocondition;

		public static ConfigEntry<bool> StationTrash;

		public static ConfigEntry<bool> DroneNoenergy_bool;

		public static ConfigEntry<bool> BuildNotime_bool;

		public static ConfigEntry<bool> Station_infiniteWarp_bool;

		public static ConfigEntry<bool> StationfullCount_bool;

		public static ConfigEntry<bool> Buildingnoconsume;

		public static ConfigEntry<bool> Stationfullenergy;

		public static ConfigEntry<bool> BeltSignalFunction;

		public static ConfigEntry<bool> Tankcontentall;

		public static ConfigEntry<bool> ArchitectMode;

		public static ConfigEntry<bool> quickabsorbsolar;

		public static ConfigEntry<bool> cancelsolarbullet;

		public static ConfigEntry<bool> QuickabortSwarm;

		public static ConfigEntry<bool> alwaysemission;

		public static ConfigEntry<bool> StationSpray;

		public static ConfigEntry<bool> Maxproliferator;

		public static ConfigEntry<bool> StationPowerGen;

		public static ConfigEntry<bool> ChangeDysonradius;

		public static ConfigEntry<bool> CloseUIAbnormalityTip;

		public static ConfigEntry<bool> IgnoreControlPanelLocalLimit;

		public static ConfigEntry<bool> QuantumtransportstationSupply;

		public static ConfigEntry<bool> QuantumtransportCollectorSupply;

		public static ConfigEntry<bool> QuantumtransportlabSupply;

		public static ConfigEntry<bool> QuantumtransportpowerSupply;

		public static ConfigEntry<bool> QuantumtransportassembleSupply;

		public static ConfigEntry<bool> QuantumtransportstationDemand;

		public static ConfigEntry<bool> LockPlayerHp;

		public static ConfigEntry<bool> LockBuildHp;

		public static ConfigEntry<bool> LockEnemyHp;

		public static ConfigEntry<bool> PlayerQuickAttack;

		public static ConfigEntry<bool> PlayerFakeDeath;

		public static ConfigEntry<bool> TurrentKeepSuperNoval;

		public static ConfigEntry<bool> TurrentKeepSuperNovalQuickKey;

		public static ConfigEntry<bool> ClickKillEnemy;

		public static ConfigEntry<bool> LocalAlwaysClearThreat;

		public static ConfigEntry<bool> SpaceAlwaysClearThreat;

		public static ConfigEntry<bool> LocalAlwaysMaxThreat;

		public static ConfigEntry<bool> SpaceAlwaysMaxThreat;

		public static ConfigEntry<bool> DarkFogBuilderQuickBuild;

		public static ConfigEntry<string> seedPlanetWater;

		public static ConfigEntry<string> AutoChangeStationName;

		public static ConfigEntry<bool> QuantumtransportminerDemand;

		public static ConfigEntry<bool> QuantumtransportsiloDemand;

		public static ConfigEntry<bool> QuantumtransportlabDemand;

		public static ConfigEntry<bool> QuantumtransportpowerDemand;

		public static ConfigEntry<bool> QuantumtransportassembleDemand;

		public static ConfigEntry<bool> ModifyDarkFogLevel;

		public static ConfigEntry<int> ModifyDarkFogLevelValue;

		private int dockindex = -1;

		public static List<int> CollectorStation = new List<int>();

		public static List<int> SuperStation = new List<int>();

		public static List<int> StarSuperStation = new List<int>();

		public static Dictionary<int, int[]> StarSuperStationItemidstore = new Dictionary<int, int[]>();

		public static Dictionary<int, Dictionary<int, List<int[]>>> PlanetSuperStationItemidstore = new Dictionary<int, Dictionary<int, List<int[]>>>();

		public static int DriftBuildingLevel
		{
			get
			{
				return driftBuildingLevel;
			}
			set
			{
				driftBuildingLevel = value;
				DriftBuildingHeight = 1f + (float)DriftBuildingLevel * 0.0066f;
			}
		}

		private void Start()
		{
			//IL_0c64: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c7a: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c7f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c91: Unknown result type (might be due to invalid IL or missing references)
			//IL_0c96: Unknown result type (might be due to invalid IL or missing references)
			//IL_0cac: Unknown result type (might be due to invalid IL or missing references)
			//IL_0cb1: Unknown result type (might be due to invalid IL or missing references)
			//IL_0ce4: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dcd: Unknown result type (might be due to invalid IL or missing references)
			//IL_0dd2: Unknown result type (might be due to invalid IL or missing references)
			Constant.preparedraw();
			originWaterTypes = new SeedPlanetWater();
			seedPlanetWaterTypes = new Dictionary<long, SeedPlanetWater>();
			MultifunctionTranslate.regallTranslate();
			Quantumtransport_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("量子传输站", "Quantumtransport_bool", false, (ConfigDescription)null);
			Quantumtransportstarwarp_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("星系级翘曲全面供应", "Quantumtransportstarwarp_bool", false, (ConfigDescription)null);
			Quantumtransportpdwarp_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("星球级翘曲全面供应", "Quantumtransportpdwarp_bool", false, (ConfigDescription)null);
			Quantumtransportbuild_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("星球级材料供应", "Quantumtransportbuild_bool", true, (ConfigDescription)null);
			QuantumtransportCollectorSupply = ((BaseUnityPlugin)this).Config.Bind<bool>("采集器拿取", "QuantumtransportCollectorSupply", true, (ConfigDescription)null);
			QuantumtransportstationSupply = ((BaseUnityPlugin)this).Config.Bind<bool>("星球级物流站材料供应", "QuantumtransportstationSupply", true, (ConfigDescription)null);
			QuantumtransportlabSupply = ((BaseUnityPlugin)this).Config.Bind<bool>("星球级研究站材料供应", "QuantumtransportlabSupply", true, (ConfigDescription)null);
			QuantumtransportpowerSupply = ((BaseUnityPlugin)this).Config.Bind<bool>("星球级电力设备材料供应", "QuantumtransportpowerSupply", true, (ConfigDescription)null);
			QuantumtransportassembleSupply = ((BaseUnityPlugin)this).Config.Bind<bool>("星球级组装机材料供应", "QuantumtransportassembleSupply", true, (ConfigDescription)null);
			QuantumtransportstationDemand = ((BaseUnityPlugin)this).Config.Bind<bool>("星球级物流站材料拿取", "QuantumtransportstationDemand", true, (ConfigDescription)null);
			QuantumtransportminerDemand = ((BaseUnityPlugin)this).Config.Bind<bool>("星球级矿机材料拿取", "QuantumtransportminerDemand", true, (ConfigDescription)null);
			QuantumtransportsiloDemand = ((BaseUnityPlugin)this).Config.Bind<bool>("星球级发射井弹射器材料拿取", "QuantumtransportsiloDemand", true, (ConfigDescription)null);
			QuantumtransportlabDemand = ((BaseUnityPlugin)this).Config.Bind<bool>("星球级研究站材料拿取", "QuantumtransportlabDemand", true, (ConfigDescription)null);
			QuantumtransportpowerDemand = ((BaseUnityPlugin)this).Config.Bind<bool>("星球级电力设备材料拿取", "QuantumtransportpowerDemand", true, (ConfigDescription)null);
			QuantumtransportassembleDemand = ((BaseUnityPlugin)this).Config.Bind<bool>("星球级组装机材料拿取", "QuantumtransportassembleDemand", true, (ConfigDescription)null);
			scale = ((BaseUnityPlugin)this).Config.Bind<int>("大小适配", "scale", 16, (ConfigDescription)null);
			LockPlayerHp = ((BaseUnityPlugin)this).Config.Bind<bool>("玩家锁血", "LockPlayerHp", false, (ConfigDescription)null);
			LockBuildHp = ((BaseUnityPlugin)this).Config.Bind<bool>("建筑锁血", "LockBuildHp", false, (ConfigDescription)null);
			LockEnemyHp = ((BaseUnityPlugin)this).Config.Bind<bool>("怪物锁血", "LockEnemyHp", false, (ConfigDescription)null);
			PlayerQuickAttack = ((BaseUnityPlugin)this).Config.Bind<bool>("玩家攻速Max", "PlayerQuickAttack", false, (ConfigDescription)null);
			PlayerFakeDeath = ((BaseUnityPlugin)this).Config.Bind<bool>("玩家假死", "PlayerFakeDeath", false, (ConfigDescription)null);
			TurrentKeepSuperNoval = ((BaseUnityPlugin)this).Config.Bind<bool>("炮塔永久超新星", "TurrentKeepSuperNoval", false, (ConfigDescription)null);
			TurrentKeepSuperNovalQuickKey = ((BaseUnityPlugin)this).Config.Bind<bool>("启用快捷键(ctrl+s)", "TurrentKeepSuperNovalQuickKey", false, (ConfigDescription)null);
			LocalAlwaysClearThreat = ((BaseUnityPlugin)this).Config.Bind<bool>("星球永远0威胁", "LocalAlwaysClearThreat", false, (ConfigDescription)null);
			SpaceAlwaysClearThreat = ((BaseUnityPlugin)this).Config.Bind<bool>("太空永远0威胁", "SpaceAlwaysClearThreat", false, (ConfigDescription)null);
			LocalAlwaysMaxThreat = ((BaseUnityPlugin)this).Config.Bind<bool>("玩家所在星球永远满威胁", "LocalAlwaysMaxThreat", false, (ConfigDescription)null);
			SpaceAlwaysMaxThreat = ((BaseUnityPlugin)this).Config.Bind<bool>("玩家所在星系永远满威胁", "SpaceAlwaysMaxThreat", false, (ConfigDescription)null);
			DarkFogBuilderQuickBuild = ((BaseUnityPlugin)this).Config.Bind<bool>("黑雾巢穴快速产怪", "DarkFogBuilderQuickBuild", false, (ConfigDescription)null);
			ClickKillEnemy = ((BaseUnityPlugin)this).Config.Bind<bool>("点击杀死敌人", "ClickKillEnemy", false, (ConfigDescription)null);
			ClickKillEnemyMode = ((BaseUnityPlugin)this).Config.Bind<int>("点击杀死敌人模式", "ClickKillEnemyMode", 0, (ConfigDescription)null);
			ModifyDarkFogLevel = ((BaseUnityPlugin)this).Config.Bind<bool>("调整黑雾怪物等级", "ModifyDarkFogLevel", false, (ConfigDescription)null);
			ModifyDarkFogLevelValue = ((BaseUnityPlugin)this).Config.Bind<int>("调整黑雾怪物等级数值", "ModifyDarkFogLevelValue", 15, (ConfigDescription)null);
			ArchitectMode = ((BaseUnityPlugin)this).Config.Bind<bool>("建筑师模式", "ArchitectMode", false, (ConfigDescription)null);
			EnableTp = ((BaseUnityPlugin)this).Config.Bind<bool>("启用传送", "EnableTp", false, (ConfigDescription)null);
			Quantumenergy = ((BaseUnityPlugin)this).Config.Bind<int>("量子耗能", "Quantumenergy", 1000000, (ConfigDescription)null);
			StationMinerSmelterNum = ((BaseUnityPlugin)this).Config.Bind<int>("星球熔炉矿机等价高级熔炉数量", "StationMinerSmelterNum", 120, (ConfigDescription)null);
			StationfullCount_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("星球无限供货机", "StationfullCount_bool", false, (ConfigDescription)null);
			StationMinerSmelter = ((BaseUnityPlugin)this).Config.Bind<bool>("星球熔炉矿机", "StationMinerSmelter", false, (ConfigDescription)null);
			StationSprayer = ((BaseUnityPlugin)this).Config.Bind<bool>("喷涂加工厂", "StationSprayer", false, (ConfigDescription)null);
			InfineteStarPower = ((BaseUnityPlugin)this).Config.Bind<bool>("人造卫星无限能源", "InfineteStarPower", false, (ConfigDescription)null);
			WindturbinesUnlimitedEnergy = ((BaseUnityPlugin)this).Config.Bind<bool>("风力涡轮机无限能源", "WindturbinesUnlimitedEnergy", false, (ConfigDescription)null);
			Windturbinescovertheglobe = ((BaseUnityPlugin)this).Config.Bind<bool>("风力涡轮机覆盖全球", "Windturbinescovertheglobe", false, (ConfigDescription)null);
			Infinitestoragetank = ((BaseUnityPlugin)this).Config.Bind<bool>("无限储液站", "Infinitestoragetank", false, (ConfigDescription)null);
			TankMaxproliferator = ((BaseUnityPlugin)this).Config.Bind<bool>("储液站无限增产", "TankMaxproliferator", false, (ConfigDescription)null);
			Tankcontentall = ((BaseUnityPlugin)this).Config.Bind<bool>("储液站任意存", "Tankcontentall", false, (ConfigDescription)null);
			allhandcraft = ((BaseUnityPlugin)this).Config.Bind<bool>("全部手搓", "allhandcraft", false, (ConfigDescription)null);
			quickproduce = ((BaseUnityPlugin)this).Config.Bind<bool>("快速生产", "quickproduce", false, (ConfigDescription)null);
			noneedwarp = ((BaseUnityPlugin)this).Config.Bind<bool>("无翘曲器曲速", "noneedwarp", false, (ConfigDescription)null);
			isInstantItem = ((BaseUnityPlugin)this).Config.Bind<bool>("直接获取物品", "isInstantItem", false, (ConfigDescription)null);
			QuickResearch = ((BaseUnityPlugin)this).Config.Bind<bool>("鼠标中键锁定格子", "QuickResearch", false, (ConfigDescription)null);
			MiddleMouseLockGrid = ((BaseUnityPlugin)this).Config.Bind<bool>("鼠标中键锁定格子", "MiddleMouseLockGrid", false, (ConfigDescription)null);
			CuttingVeinNumbers = ((BaseUnityPlugin)this).Config.Bind<int>("切割矿脉数量", "CuttingVeinNumbers", 3, (ConfigDescription)null);
			veinlines = ((BaseUnityPlugin)this).Config.Bind<int>("矿物行数", "veinlines", 3, (ConfigDescription)null);
			NotTidyVein = ((BaseUnityPlugin)this).Config.Bind<bool>("矿堆不整理", "NotTidyVein", false, (ConfigDescription)null);
			deleteveinbool = ((BaseUnityPlugin)this).Config.Bind<bool>("删除矿物", "deleteveinbool", false, (ConfigDescription)null);
			StationMaxproliferator = ((BaseUnityPlugin)this).Config.Bind<bool>("物流站无限增产点数", "StationMaxproliferator", false, (ConfigDescription)null);
			BeltSignalFunction = ((BaseUnityPlugin)this).Config.Bind<bool>("传送带信号功能", "BeltSignalFunction", false, (ConfigDescription)null);
			Mechalogistics_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("机甲物流", "Mechalogistics_bool", false, (ConfigDescription)null);
			MechalogisticsPlanet_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("机甲物流专用星", "MechalogisticsPlanet_bool", false, (ConfigDescription)null);
			MechalogBuildGotoPlayerStorageFirst_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("建筑优先进入玩家背包", "MechalogBuildGotoPlayerStorageFirst_bool", false, (ConfigDescription)null);
			MechalogPlayerStorageFirst_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("所有物品优先进入玩家背包", "MechalogPlayerStorageFirst_bool", false, (ConfigDescription)null);
			MechalogStationprovide_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("需求使用物流站", "MechalogStationprovide_bool", false, (ConfigDescription)null);
			MechalogStationrecycle_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("回收使用物流站", "MechalogStationrecycle_bool", false, (ConfigDescription)null);
			MechalogStorageprovide_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("需求使用储物仓", "MechalogStorageprovide_bool", false, (ConfigDescription)null);
			MechalogStoragerecycle_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("回收使用储物仓", "MechalogStoragerecycle_bool", false, (ConfigDescription)null);
			Infinitething = ((BaseUnityPlugin)this).Config.Bind<bool>("无限物品", "Infinitething", false, (ConfigDescription)null);
			InfiniteSand = ((BaseUnityPlugin)this).Config.Bind<bool>("无限沙土", "InfiniteSand", false, (ConfigDescription)null);
			Infiniteplayerpower = ((BaseUnityPlugin)this).Config.Bind<bool>("无限机甲能量", "Infiniteplayerpower", false, (ConfigDescription)null);
			StationMiner = ((BaseUnityPlugin)this).Config.Bind<bool>("星球矿机", "stationmineropen", false, (ConfigDescription)null);
			StationTrash = ((BaseUnityPlugin)this).Config.Bind<bool>("星球垃圾箱", "stationtrashopen", false, (ConfigDescription)null);
			Buildingnoconsume = ((BaseUnityPlugin)this).Config.Bind<bool>("全设备不耗电", "Buildingnoconsume", false, (ConfigDescription)null);
			Stationfullenergy = ((BaseUnityPlugin)this).Config.Bind<bool>("物流站永久满电", "Stationfullenergy", false, (ConfigDescription)null);
			StationSpray = ((BaseUnityPlugin)this).Config.Bind<bool>("物流站喷涂", "StationSpray", false, (ConfigDescription)null);
			StationPowerGen = ((BaseUnityPlugin)this).Config.Bind<bool>("物流站内置发电", "StationPowerGen", false, (ConfigDescription)null);
			build_station_nocondition = ((BaseUnityPlugin)this).Config.Bind<bool>("建造无需条件", "build_station_nocondition", false, (ConfigDescription)null);
			QuickHandcraft = ((BaseUnityPlugin)this).Config.Bind<bool>("机甲制造MAX", "QuickHandcraft", false, (ConfigDescription)null);
			QuickPlayerMine = ((BaseUnityPlugin)this).Config.Bind<bool>("机甲采矿Max", "QuickPlayerMine", false, (ConfigDescription)null);
			InspectDisNoLimit = ((BaseUnityPlugin)this).Config.Bind<bool>("操作范围不受限制", "InspectDisNoLimit", false, (ConfigDescription)null);
			needtrashsand = ((BaseUnityPlugin)this).Config.Bind<bool>("需要垃圾沙土", "needtrashsand", false, (ConfigDescription)null);
			dismantle_but_nobuild = ((BaseUnityPlugin)this).Config.Bind<bool>("拆除不添加至背包", "dismantle_but_nobuild", false, (ConfigDescription)null);
			DroneNoenergy_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("小飞机不耗能", "DroneNoenergy_bool", false, (ConfigDescription)null);
			Station_infiniteWarp_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("星际运输站无限曲速", "Station_infiniteWarp_bool", false, (ConfigDescription)null);
			BuildNotime_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("建筑秒完成", "BuildNotime_bool", false, (ConfigDescription)null);
			PlanetPower_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("星球电网", "PlanetPower_bool", false, (ConfigDescription)null);
			blueprintpastenoneed_bool = ((BaseUnityPlugin)this).Config.Bind<bool>("蓝图建造无需材料", "blueprintpastenoneed_bool", false, (ConfigDescription)null);
			quickabsorbsolar = ((BaseUnityPlugin)this).Config.Bind<bool>("跳过太阳帆吸收阶段", "quickabsorbsolar", false, (ConfigDescription)null);
			cancelsolarbullet = ((BaseUnityPlugin)this).Config.Bind<bool>("跳过太阳帆子弹阶段", "cancelsolarbullet", false, (ConfigDescription)null);
			alwaysemission = ((BaseUnityPlugin)this).Config.Bind<bool>("全球打帆", "alwaysemission", false, (ConfigDescription)null);
			QuickabortSwarm = ((BaseUnityPlugin)this).Config.Bind<bool>("太阳帆秒吸收", "QuickabortSwarm", false, (ConfigDescription)null);
			ChangeDysonradius = ((BaseUnityPlugin)this).Config.Bind<bool>("改变戴森球半径上下限", "ChangeDysonradius", false, (ConfigDescription)null);
			MaxOrbitRadiusConfig = ((BaseUnityPlugin)this).Config.Bind<int>("戴森球最大半径", "MaxOrbitRadiusConfig", 1000000, (ConfigDescription)null);
			StationStoExtra = ((BaseUnityPlugin)this).Config.Bind<int>("运输站额外储量", "StationStoExtra", 0, (ConfigDescription)null);
			StackMultiple = ((BaseUnityPlugin)this).Config.Bind<int>("堆叠倍数", "StackMultiple", 1, (ConfigDescription)null);
			Stationminenumber = ((BaseUnityPlugin)this).Config.Bind<int>("星球矿机速率", "Stationminenumber", 1, (ConfigDescription)null);
			Buildmaxlen = ((BaseUnityPlugin)this).Config.Bind<int>("建筑数量最大值", "Buildmaxlen", 15, (ConfigDescription)null);
			Maxproliferator = ((BaseUnityPlugin)this).Config.Bind<bool>("增产点数上限10", "Maxproliferator", false, (ConfigDescription)null);
			starquamaxpowerpertick = ((BaseUnityPlugin)this).Config.Bind<float>("实时修改星球量子充电功率", "starquamaxpowerpertick", 60f, (ConfigDescription)null);
			planetquamaxpowerpertick = ((BaseUnityPlugin)this).Config.Bind<float>("实时修改星系量子充电功率", "planetquamaxpowerpertick", 60f, (ConfigDescription)null);
			CloseUIAbnormalityTip = ((BaseUnityPlugin)this).Config.Bind<bool>("关闭异常提示", "CloseUIAbnormalityTip", false, (ConfigDescription)null);
			Textcolor = ((BaseUnityPlugin)this).Config.Bind<Color>("字体颜色", "Textcolor", Color.white, (ConfigDescription)null);
			mainWindowTextureColor_config = ((BaseUnityPlugin)this).Config.Bind<Color>("窗口材质颜色", "mainWindowTextureColor", Color.black, (ConfigDescription)null);
			seedPlanetWater = ((BaseUnityPlugin)this).Config.Bind<string>("海洋类型修改", "seedPlanetWater", "", (ConfigDescription)null);
			AutoChangeStationName = ((BaseUnityPlugin)this).Config.Bind<string>("物流站自动改名", "AutoChangeStationName", "", (ConfigDescription)null);
			Solarsailsabsorbeveryframe = ((BaseUnityPlugin)this).Config.Bind<int>("每帧吸收个数", "Solarsailsabsorbeveryframe", 1, (ConfigDescription)null);
			IgnoreControlPanelLocalLimit = ((BaseUnityPlugin)this).Config.Bind<bool>("取消总控面板本地限制", "IgnoreControlPanelLocalLimit", false, (ConfigDescription)null);
			MainWindow_x_config = ((BaseUnityPlugin)this).Config.Bind<float>("第一窗口x", "xl_SimpleUI_1_x_config", 448f, (ConfigDescription)null);
			MainWindow_y_config = ((BaseUnityPlugin)this).Config.Bind<float>("第一窗口y", "xl_SimpleUI_1_y_config", 199f, (ConfigDescription)null);
			MainWindow_width = ((BaseUnityPlugin)this).Config.Bind<float>("第一窗口宽度", "xl_SimpleUI_1_x_config", 1400f, (ConfigDescription)null);
			MainWindow_height = ((BaseUnityPlugin)this).Config.Bind<float>("第一窗口高度", "xl_SimpleUI_1_y_config", 1000f, (ConfigDescription)null);
			QuickKey = ((BaseUnityPlugin)this).Config.Bind<KeyboardShortcut>("打开窗口快捷键", "Key", new KeyboardShortcut(KeyCode.LeftAlt, new KeyCode[1] { KeyCode.Alpha1 }), (ConfigDescription)null);
			KeyboardShortcut value = QuickKey.Value;
			if (value.MainKey == KeyCode.Alpha1)
			{
				value = QuickKey.Value;
				if (value.Modifiers.Count() == 1)
				{
					value = QuickKey.Value;
					if (value.Modifiers.ElementAt(0) == KeyCode.LeftAlt)
					{
						QuickKey.Value = new KeyboardShortcut(KeyCode.LeftAlt, new KeyCode[1] { KeyCode.Alpha1 });
					}
				}
			}
			AssetBundle assetBundle = AssetBundle.LoadFromStream(Assembly.GetExecutingAssembly().GetManifestResourceStream("Multifunction_mod.multifunctionpanel"));
			GameObject original = assetBundle.LoadAsset<GameObject>("MultiFunctionPanel");
			GameObject gameObject = UnityEngine.Object.Instantiate(original, UIRoot.instance.overlayCanvas.transform);
			gameObject.SetActive(value: false);
			guidraw = new GUIDraw(Math.Max(5, Math.Min(scale.Value, 35)), gameObject, this);
			veinproperty = new VeinControlProperty
			{
				VeinLines = veinlines.Value,
				CuttingVeinNumbers = CuttingVeinNumbers.Value,
				oillowerlimit = (int)(0.1f / VeinData.oilSpeedMultiplier),
				DeleteVein = deleteveinbool.Value,
				NotTidyVein = NotTidyVein.Value
			};
			incAbility = (Maxproliferator.Value ? 10 : 4);
			tempShowWindow = QuickKey.Value;
			CollectorStation = new List<int>();
			InitWaterTypes();
			IgnoreControlPanelLocalLimit.SettingChanged += delegate
			{
				UIControlPanelPatch.Enable = IgnoreControlPanelLocalLimit.Value;
			};
			alwaysemission.SettingChanged += delegate
			{
				EjectAnywayPatch.Enable = alwaysemission.Value;
			};
			cancelsolarbullet.SettingChanged += delegate
			{
				SkipBulletPatch.Enable = cancelsolarbullet.Value;
			};
			SkipBulletPatch.Enable = cancelsolarbullet.Value;
			EjectAnywayPatch.Enable = alwaysemission.Value;
			UIControlPanelPatch.Enable = IgnoreControlPanelLocalLimit.Value;
			Multifunctionpatch.Patchallmethod();
		}

		private void Update()
		{
			if (FinallyInit)
			{
				if (Time.time > OnesecondTime + 1f)
				{
					OnesecondTime = Time.time;
					OneSecondTimeElapse = true;
				}
				if (Time.time > HalfsecondTime + 0.5f)
				{
					HalfsecondTime = Time.time;
					HalfSecondTimeElapse = true;
				}
			}
			ChangeQuickKeyMethod();
			QuickKeyOpenWindow();
			FirstStartGame();
			AfterGameStart();
			if (!Input.GetKeyDown(KeyCode.F9))
			{
			}
		}

		private void OnGUI()
		{
			IsEnglish = Localization.CurrentLanguage.glyph == Localization.EGlyph.Latin;
			guidraw.Draw();
		}

		public void RefreshSuperStation()
		{
			if (GameMain.data?.galacticTransport?.stationPool == null)
			{
				return;
			}
			StarSuperStation.Clear();
			SuperStation.Clear();
			StarSuperStationItemidstore.Clear();
			PlanetSuperStationItemidstore.Clear();
			for (int i = 0; i < GameMain.data.galacticTransport.stationPool.Length; i++)
			{
				StationComponent stationComponent = GameMain.data.galacticTransport.stationPool[i];
				if (stationComponent == null)
				{
					continue;
				}
				PlanetFactory planetFactory = GameMain.galaxy.PlanetById(stationComponent.planetId)?.factory;
				string text = planetFactory.ReadExtraInfoOnEntity(stationComponent.entityId);
				if (string.IsNullOrEmpty(text) || stationComponent.storage == null || !stationComponent.isStellar)
				{
					continue;
				}
				if (text == "星系量子传输站")
				{
					StarSuperStation.Add(i);
					for (int j = 0; j < stationComponent.storage.Length; j++)
					{
						ref StationStore reference = ref stationComponent.storage[j];
						if (reference.itemId > 0)
						{
							if (!StarSuperStationItemidstore.ContainsKey(reference.itemId))
							{
								StarSuperStationItemidstore.Add(reference.itemId, new int[2]
								{
									StarSuperStation.Count - 1,
									j
								});
							}
							if (reference.count < 0)
							{
								reference.count = 0;
							}
							if (reference.inc < 0)
							{
								reference.inc = 0;
							}
							else if (reference.inc > reference.count * 4)
							{
								reference.inc = reference.count * 4;
							}
						}
					}
					if (changequapowerpertick)
					{
						try
						{
							GameMain.galaxy.PlanetById(stationComponent.planetId).factory.powerSystem.consumerPool[stationComponent.pcId].workEnergyPerTick = (long)starquamaxpowerpertick.Value * 16667;
						}
						catch
						{
						}
					}
				}
				if (!(text == "星球量子传输站"))
				{
					continue;
				}
				SuperStation.Add(i);
				if (changequapowerpertick)
				{
					try
					{
						GameMain.galaxy.PlanetById(stationComponent.planetId).factory.powerSystem.consumerPool[stationComponent.pcId].workEnergyPerTick = (long)planetquamaxpowerpertick.Value * 16667;
					}
					catch
					{
					}
				}
			}
		}

		public void takeitemfromstarsuperstation()
		{
			if (GameMain.data?.galacticTransport?.stationPool == null)
			{
				return;
			}
			RefreshSuperStation();
			int count = SuperStation.Count;
			int count2 = StarSuperStation.Count;
			if (count == 0 && count2 == 0)
			{
				return;
			}
			changequapowerpertick = false;
			for (int i = 0; i < count; i++)
			{
				StationComponent stationComponent = GameMain.data.galacticTransport.stationPool[SuperStation[i]];
				int planetId = stationComponent.planetId;
				for (int num = stationComponent.storage.Length - 1; num >= 0; num--)
				{
					ref StationStore reference = ref stationComponent.storage[num];
					int itemId = reference.itemId;
					if (itemId > 0)
					{
						if (!PlanetSuperStationItemidstore.ContainsKey(planetId))
						{
							PlanetSuperStationItemidstore.Add(planetId, new Dictionary<int, List<int[]>>());
						}
						Dictionary<int, List<int[]>> dictionary = PlanetSuperStationItemidstore[planetId];
						if (!dictionary.ContainsKey(itemId))
						{
							dictionary.Add(itemId, new List<int[]> { new int[2] { i, num } });
						}
						else
						{
							dictionary[itemId].Add(new int[2] { i, num });
						}
						if (reference.remoteLogic == ELogisticStorage.Demand && reference.count < reference.max)
						{
							if (reference.max > reference.count)
							{
								int[] array = doitemfromStarsuper(itemId, reference.max - reference.count);
								reference.count += array[0];
								reference.inc += array[1];
							}
							else if (reference.max < reference.count)
							{
								int[] array2 = doitemfromStarsuper(itemId, reference.count - reference.max, reference.inc, take: false);
								reference.count -= array2[0];
								reference.inc -= array2[1];
							}
						}
						else if (reference.remoteLogic == ELogisticStorage.Supply && reference.count > 0)
						{
							int[] array3 = doitemfromStarsuper(itemId, reference.count, reference.inc, take: false);
							reference.count -= array3[0];
							reference.inc -= array3[1];
						}
						if (reference.count < 0)
						{
							reference.count = 0;
						}
						if (reference.inc < 0)
						{
							reference.inc = 0;
						}
					}
				}
				if (Quantumtransportpdwarp_bool.Value && stationComponent.warperCount <= 5)
				{
					stationComponent.warperCount += doitemfromStarsuper(1210, 50)[0];
				}
			}
			for (int j = 0; j < count2; j++)
			{
				StationComponent stationComponent2 = GameMain.data.galacticTransport.stationPool[StarSuperStation[j]];
				if (Quantumtransportstarwarp_bool.Value && stationComponent2.warperCount <= 5)
				{
					stationComponent2.warperCount += doitemfromStarsuper(1210, 50)[0];
				}
			}
			if (QuantumtransportCollectorSupply.Value)
			{
				CollectorStationDemand();
			}
			if (Quantumtransportbuild_bool.Value)
			{
				SuperStationProvide();
			}
		}

		public void StationSupplyDemand(FactorySystem fs, int pdid)
		{
			StationComponent[] stationPool = fs.factory.transport.stationPool;
			foreach (StationComponent stationComponent in stationPool)
			{
				if (stationComponent?.storage == null)
				{
					continue;
				}
				string text = fs.factory.ReadExtraInfoOnEntity(stationComponent.entityId);
				if (text == "星球量子传输站")
				{
					continue;
				}
				for (int j = 0; j < stationComponent.storage.Length; j++)
				{
					ref StationStore reference = ref stationComponent.storage[j];
					if (reference.itemId > 0)
					{
						if (QuantumtransportstationDemand.Value && reference.localLogic == ELogisticStorage.Supply && reference.count > 0 && text != "星系量子传输站")
						{
							int[] array = doitemfromPlanetSuper(reference.itemId, reference.count, pdid, reference.inc, take: false);
							reference.count -= array[0];
							reference.inc -= array[1];
						}
						if (QuantumtransportstationSupply.Value && reference.localLogic == ELogisticStorage.Demand && reference.count <= reference.max)
						{
							int[] array2 = doitemfromPlanetSuper(reference.itemId, reference.max - reference.count, pdid);
							reference.count += array2[0];
							reference.inc += array2[1];
						}
					}
				}
			}
		}

		public void MinerSupplyDemand(FactorySystem fs, int pdid)
		{
			MinerComponent[] minerPool = fs.minerPool;
			for (int i = 0; i < minerPool.Length; i++)
			{
				MinerComponent minerComponent = minerPool[i];
				if (minerComponent.id > 0 && minerComponent.entityId > 0 && minerComponent.productCount > 20 && minerComponent.productId > 0)
				{
					fs.minerPool[minerComponent.id].productCount -= doitemfromPlanetSuper(minerComponent.productId, minerComponent.productCount, pdid, 0, take: false)[0];
				}
			}
		}

		public void SiloComponentSupplyDemand(FactorySystem fs, int pdid)
		{
			SiloComponent[] siloPool = fs.siloPool;
			for (int i = 0; i < siloPool.Length; i++)
			{
				SiloComponent siloComponent = siloPool[i];
				if (siloComponent.id > 0 && siloComponent.entityId > 0 && siloComponent.bulletCount <= 1)
				{
					int[] array = doitemfromPlanetSuper(1503, 20, pdid);
					fs.siloPool[siloComponent.id].bulletCount += array[0];
					fs.siloPool[siloComponent.id].bulletInc += array[1];
				}
			}
			EjectorComponent[] ejectorPool = fs.ejectorPool;
			for (int j = 0; j < ejectorPool.Length; j++)
			{
				EjectorComponent ejectorComponent = ejectorPool[j];
				if (ejectorComponent.id > 0 && ejectorComponent.entityId > 0 && ejectorComponent.bulletCount <= 1)
				{
					int[] array2 = doitemfromPlanetSuper(1501, 20, pdid);
					fs.ejectorPool[ejectorComponent.id].bulletCount += array2[0];
					fs.ejectorPool[ejectorComponent.id].bulletInc += array2[1];
				}
			}
		}

		public void AssemblerSupplyDemand(FactorySystem fs, int pdid)
		{
			AssemblerComponent[] assemblerPool = fs.assemblerPool;
			for (int i = 0; i < assemblerPool.Length; i++)
			{
				AssemblerComponent assemblerComponent = assemblerPool[i];
				if (assemblerComponent.id <= 0 || assemblerComponent.entityId <= 0 || assemblerComponent.recipeId <= 0)
				{
					continue;
				}
				if (QuantumtransportassembleDemand.Value)
				{
					int[] productCounts = assemblerComponent.recipeExecuteData.productCounts;
					int[] products = assemblerComponent.recipeExecuteData.products;
					for (int j = 0; j < productCounts.Length; j++)
					{
						int num = assemblerComponent.produced[j];
						if (num > 500)
						{
							num = 200;
						}
						if (num > 0)
						{
							num -= doitemfromPlanetSuper(products[j], num, pdid, 0, take: false)[0];
						}
						assemblerComponent.produced[j] = num;
					}
				}
				if (!QuantumtransportassembleSupply.Value)
				{
					continue;
				}
				int[] requireCounts = assemblerComponent.recipeExecuteData.requireCounts;
				int[] requires = assemblerComponent.recipeExecuteData.requires;
				for (int k = 0; k < assemblerComponent.served.Length; k++)
				{
					if (assemblerComponent.served[k] <= requireCounts[k] * 2)
					{
						int[] array = doitemfromPlanetSuper(requires[k], 20, pdid);
						assemblerComponent.served[k] += array[0];
						assemblerComponent.incServed[k] += array[1];
					}
					if (assemblerComponent.served[k] < 0)
					{
						assemblerComponent.served[k] = 0;
					}
				}
			}
		}

		public void LabSupplyDemand(FactorySystem fs, int pdid)
		{
			LabComponent[] labPool = fs.labPool;
			for (int i = 0; i < labPool.Length; i++)
			{
				LabComponent labComponent = labPool[i];
				if (labComponent.id <= 0 || labComponent.entityId <= 0)
				{
					continue;
				}
				if (QuantumtransportlabSupply.Value && labComponent.researchMode)
				{
					for (int j = 0; j < labComponent.matrixServed.Length; j++)
					{
						if (labComponent.matrixServed[j] <= 288000)
						{
							int[] array = doitemfromPlanetSuper(6001 + j, 20, pdid);
							labComponent.matrixServed[j] += array[0] * 3600;
							labComponent.matrixIncServed[j] += array[1] * 3600;
						}
					}
				}
				if (!labComponent.matrixMode)
				{
					continue;
				}
				if (QuantumtransportlabDemand.Value)
				{
					for (int k = 0; k < labComponent.recipeExecuteData.productCounts.Length; k++)
					{
						if (labComponent.produced[k] > 5)
						{
							labComponent.produced[k] -= doitemfromPlanetSuper(labComponent.recipeExecuteData.products[k], labComponent.produced[k], pdid, 0, take: false)[0];
						}
					}
				}
				if (!QuantumtransportlabSupply.Value)
				{
					continue;
				}
				for (int l = 0; l < labComponent.served.Length; l++)
				{
					if (labComponent.served[l] <= 20)
					{
						int[] array2 = doitemfromPlanetSuper(labComponent.recipeExecuteData.requires[l], 20, pdid);
						labComponent.served[l] += array2[0];
						labComponent.incServed[l] += array2[1];
					}
				}
			}
		}

		public void PowerSupplyDemand(FactorySystem fs, int pdid)
		{
			PowerGeneratorComponent[] genPool = fs.factory.powerSystem.genPool;
			for (int i = 0; i < genPool.Length; i++)
			{
				PowerGeneratorComponent powerGeneratorComponent = genPool[i];
				if (powerGeneratorComponent.id <= 0)
				{
					continue;
				}
				if (powerGeneratorComponent.gamma)
				{
					if (QuantumtransportpowerDemand.Value && powerGeneratorComponent.productCount >= 1f)
					{
						fs.factory.powerSystem.genPool[powerGeneratorComponent.id].productCount -= doitemfromPlanetSuper(1208, (int)powerGeneratorComponent.productCount, pdid, 0, take: false)[0];
					}
					if (QuantumtransportpowerSupply.Value && powerGeneratorComponent.catalystPoint == 0)
					{
						int[] array = doitemfromPlanetSuper(1209, 5, pdid);
						fs.factory.powerSystem.genPool[powerGeneratorComponent.id].catalystPoint += array[0] * 3600;
						fs.factory.powerSystem.genPool[powerGeneratorComponent.id].catalystIncPoint += array[1] * 3600;
					}
				}
				else
				{
					if (!QuantumtransportpowerSupply.Value)
					{
						continue;
					}
					int num = 0;
					switch (powerGeneratorComponent.fuelMask)
					{
					case 1:
						num = 1006;
						break;
					case 2:
						num = 1802;
						break;
					case 4:
						num = 1803;
						break;
					}
					if (num > 0 && powerGeneratorComponent.fuelCount <= 2)
					{
						int[] array2 = doitemfromPlanetSuper(num, 20, pdid);
						short num2 = (short)array2[0];
						if (num2 == 0)
						{
							break;
						}
						short num3 = (short)array2[1];
						if (powerGeneratorComponent.fuelCount == 0)
						{
							fs.factory.powerSystem.genPool[powerGeneratorComponent.id].SetNewFuel(num, num2, num3);
							continue;
						}
						fs.factory.powerSystem.genPool[powerGeneratorComponent.id].fuelCount += num2;
						fs.factory.powerSystem.genPool[powerGeneratorComponent.id].fuelInc += num3;
					}
				}
			}
		}

		public void CollectorStationDemand()
		{
			foreach (int item in CollectorStation)
			{
				StationComponent stationComponent = GameMain.data.galacticTransport.stationPool[item];
				ref StationStore reference = ref stationComponent.storage[0];
				ref StationStore reference2 = ref stationComponent.storage[1];
				reference.count -= doitemfromStarsuper(reference.itemId, reference.count, 0, take: false)[0];
				reference2.count -= doitemfromStarsuper(reference2.itemId, reference2.count, 0, take: false)[0];
			}
		}

		public void SuperStationProvide()
		{
			foreach (int key in PlanetSuperStationItemidstore.Keys)
			{
				PlanetData planetData = GameMain.galaxy.PlanetById(key);
				FactorySystem factorySystem = planetData.factory.factorySystem;
				if (QuantumtransportstationSupply.Value || QuantumtransportstationDemand.Value)
				{
					StationSupplyDemand(factorySystem, key);
				}
				if (QuantumtransportminerDemand.Value)
				{
					MinerSupplyDemand(factorySystem, key);
				}
				if (QuantumtransportsiloDemand.Value)
				{
					SiloComponentSupplyDemand(factorySystem, key);
				}
				if (QuantumtransportlabSupply.Value || QuantumtransportlabDemand.Value)
				{
					LabSupplyDemand(factorySystem, key);
				}
				if (QuantumtransportpowerSupply.Value || QuantumtransportpowerDemand.Value)
				{
					PowerSupplyDemand(factorySystem, key);
				}
				if (QuantumtransportassembleSupply.Value || QuantumtransportassembleDemand.Value)
				{
					AssemblerSupplyDemand(factorySystem, key);
				}
			}
		}

		public static int[] doitemfromStarsuper(int itemid, int itemcount, int inc = 0, bool take = true)
		{
			if (!StarSuperStationItemidstore.ContainsKey(itemid) || itemcount <= 0)
			{
				return new int[2];
			}
			StationComponent stationComponent = GameMain.data.galacticTransport.stationPool[StarSuperStation[StarSuperStationItemidstore[itemid][0]]];
			int num = StarSuperStationItemidstore[itemid][0];
			int num2 = StarSuperStationItemidstore[itemid][1];
			long num3 = ((!Stationfullenergy.Value) ? Quantumenergy.Value : 0);
			int num4 = itemcount;
			ref StationStore reference = ref stationComponent.storage[num2];
			if (take)
			{
				num4 = Math.Min(num4, reference.count);
				if (stationComponent.energy <= num4 * num3 && stationComponent.energy > 0)
				{
					num4 = Math.Min(num4, (int)(stationComponent.energy / num3));
					if (num4 == 0)
					{
						return new int[2];
					}
				}
				inc = Math.Min(num4 * 4, reference.inc);
				stationComponent.energy -= num4 * num3;
				reference.count -= num4;
				reference.inc -= inc;
			}
			else
			{
				if (stationComponent.energy >= 0 && stationComponent.energy < num4 * num3)
				{
					num4 = Math.Min(num4, (int)(stationComponent.energy / num3));
					if (num4 == 0)
					{
						return new int[2];
					}
				}
				if (reference.count + num4 <= reference.max)
				{
					inc = Math.Min(num4 * incAbility, inc);
					reference.count += num4;
					reference.inc += inc;
				}
				else if (reference.localLogic == ELogisticStorage.None && reference.remoteLogic == ELogisticStorage.None && reference.max < 2147483547)
				{
					if (reference.count + num4 <= 2147483547)
					{
						inc = Math.Min(num4 * incAbility, inc);
						reference.max = reference.count + num4;
						reference.count = reference.max;
						reference.inc += inc;
					}
					else
					{
						num4 = 2147483547 - reference.count;
						reference.max = reference.count + num4;
						reference.count = reference.max;
						reference.inc += inc;
					}
				}
				else
				{
					num4 = reference.max - reference.count;
					inc = Math.Min(num4 * incAbility, inc);
					reference.count = reference.max;
					reference.inc += inc;
				}
				stationComponent.energy -= num4 * num3;
			}
			return new int[2]
			{
				num4,
				StationMaxproliferator.Value ? (incAbility * num4) : inc
			};
		}

		public static int[] doitemfromPlanetSuper(int itemid, int itemcount, int planetid, int inc = 0, bool take = true)
		{
			if (!PlanetSuperStationItemidstore.ContainsKey(planetid) || !PlanetSuperStationItemidstore[planetid].ContainsKey(itemid) || itemcount == 0)
			{
				return new int[2];
			}
			int count = PlanetSuperStationItemidstore[planetid][itemid].Count;
			for (int i = 0; i < count; i++)
			{
				int index = PlanetSuperStationItemidstore[planetid][itemid][i][0];
				int num = PlanetSuperStationItemidstore[planetid][itemid][i][1];
				StationComponent stationComponent = GameMain.data.galacticTransport.stationPool[SuperStation[index]];
				ref StationStore reference = ref stationComponent.storage[num];
				if (stationComponent.storage[num].localLogic != ELogisticStorage.None && ((take && stationComponent.storage[num].localLogic != ELogisticStorage.Supply) || (!take && stationComponent.storage[num].localLogic != ELogisticStorage.Demand)))
				{
					continue;
				}
				long num2 = ((!Stationfullenergy.Value) ? Quantumenergy.Value : 0);
				int num3 = itemcount;
				if (take)
				{
					if (stationComponent.energy < num3 * num2)
					{
						num3 = Math.Min(num3, (int)(stationComponent.energy / num2));
					}
					if (num3 == 0)
					{
						return new int[2];
					}
					if (num3 > reference.count)
					{
						int itemcount2 = num3 - reference.count;
						int[] array = doitemfromStarsuper(itemid, itemcount2);
						num3 = reference.count + array[0];
						inc = reference.inc + array[1];
						reference.count = 0;
						reference.inc = 0;
					}
					else
					{
						inc = Math.Min(num3 * incAbility, reference.inc);
						reference.count -= num3;
						reference.inc -= inc;
					}
				}
				else
				{
					if (stationComponent.energy < num3 * num2)
					{
						num3 = Math.Min(num3, (int)(stationComponent.energy / num2));
						if (num3 == 0)
						{
							return new int[2];
						}
					}
					inc = Math.Min(num3 * incAbility, inc);
					if (reference.count + num3 >= reference.max)
					{
						int num4 = reference.count + num3 - reference.max;
						int[] array2 = doitemfromStarsuper(itemid, num4, inc, take: false);
						num3 -= num4 - array2[0];
						inc = Math.Min(num3 * incAbility, inc);
						reference.count = reference.max;
						reference.inc += inc - array2[1];
					}
					else
					{
						reference.count += num3;
						reference.inc += inc;
					}
				}
				return new int[2]
				{
					num3,
					StationMaxproliferator.Value ? (incAbility * num3) : inc
				};
			}
			return new int[2];
		}

		public void FirstStartGame()
		{
			if (GameMain.instance == null)
			{
				return;
			}
			if (!GameMain.instance.running && FinallyInit)
			{
				GameRunning = false;
				FinallyInit = false;
				closeallcollider = false;
				Beltsignal = new Dictionary<int, Dictionary<int, int>>();
				Beltsignalnumberoutput = new Dictionary<int, Dictionary<int, int>>();
				StarSuperStation = new List<int>();
				SuperStation = new List<int>();
				StarSuperStationItemidstore = new Dictionary<int, int[]>();
				PlanetSuperStationItemidstore = new Dictionary<int, Dictionary<int, List<int[]>>>();
				CollectorStation.Clear();
				SuperStation = new List<int>();
				StarSuperStation = new List<int>();
				alwaysemissiontemp = false;
				originWaterTypes = new SeedPlanetWater();
				GC.Collect();
			}
			if (!GameMain.instance.running || FinallyInit)
			{
				return;
			}
			FinallyInit = true;
			InitPlanetWaterType();
			if (BeltSignalFunction.Value)
			{
				InitBeltSignalDiction();
			}
			if (Quantumtransport_bool.Value)
			{
				InitQuantumTransport();
			}
			if (LDB.recipes != null && !LDBInitSave)
			{
				LDBInitSave = true;
				originRecipeProtos = new RecipeProto[LDB.recipes.dataArray.Length];
				for (int i = 0; i < originRecipeProtos.Length; i++)
				{
					RecipeProto recipeProto = LDB.recipes.dataArray[i];
					originRecipeProtos[i] = new RecipeProto
					{
						TimeSpend = recipeProto.TimeSpend,
						Handcraft = recipeProto.Handcraft
					};
					if (recipeProto.Type != ERecipeType.Smelt)
					{
						continue;
					}
					int[] items = recipeProto.Items;
					foreach (int key in items)
					{
						if (smeltRecipes.ContainsKey(key))
						{
							smeltRecipes[key].Add(recipeProto);
							continue;
						}
						smeltRecipes.Add(key, new List<RecipeProto> { recipeProto });
					}
				}
				ChangeRecipe();
			}
			alwaysemissiontemp = alwaysemission.Value;
			SetmultipleItemStatck(StackMultiple.Value);
			ChangeItemstack();
		}

		public void AfterGameStart()
		{
			if (GameMain.history == null || !FinallyInit)
			{
				return;
			}
			GameRunning = true;
			PlayerDataInit();
			if (GameMain.localPlanet == null)
			{
				currentPlanetWaterType = "";
			}
			else
			{
				BluePrintpasteNoneed();
				if (string.IsNullOrEmpty(currentPlanetWaterType))
				{
					currentPlanetWaterType = LDB.items.Select(GameMain.localPlanet.waterItemId)?.name ?? "无海洋".getTranslate();
				}
			}
			if (!guidraw.DisplayingWindow || !guidraw.MouseInWindow)
			{
				veinproperty.ControlVein();
				CombatFunction();
			}
			if (refreshLDB)
			{
				refreshLDB = false;
				ChangeRecipe();
			}
			OnsecondMethod();
			if (Infinitething.Value)
			{
				InfiniteAllThingInPackage();
			}
			if (QuickResearch.Value)
			{
				GameMain.history.AddTechHash(600000000000000L);
			}
			SetDronenocomsume();
			DriftBuild();
		}

		private void CombatFunction()
		{
			if (Input.GetMouseButtonUp(0) || (ClickGenerateDFRelayLockClick && Input.GetMouseButtonDown(0)))
			{
				ClickGenerateDFRelayLockClick = false;
			}
			if (ClickGenerateDFRelay && Input.GetMouseButtonDown(0) && Physics.Raycast(GameCamera.main.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
			{
				ClickGenerateDFRelay = false;
				ClickGenerateDFRelayLockClick = true;
				VectorLF3 vectorLF = hitInfo.point.normalized * (GameMain.localPlanet.realRadius + 70f);
				EnemyDFHiveSystem enemyDFHiveSystem = GameMain.data.spaceSector.dfHives[GameMain.localStar.index];
				if (enemyDFHiveSystem == null)
				{
					return;
				}
				int relayCount = enemyDFHiveSystem.relayCount;
				for (EnemyDFHiveSystem enemyDFHiveSystem2 = GameMain.data.spaceSector.dfHives[GameMain.localStar.index]; enemyDFHiveSystem2 != null; enemyDFHiveSystem2 = enemyDFHiveSystem2.nextSibling)
				{
					if (enemyDFHiveSystem2.isAlive && relayCount > enemyDFHiveSystem2.relayCount)
					{
						enemyDFHiveSystem = enemyDFHiveSystem2;
					}
				}
				System.Random random = new System.Random(enemyDFHiveSystem.seed);
				double x = random.NextDouble();
				double num = random.NextDouble();
				int num2 = GameMain.data.spaceSector.CreateEnemyFinal(enemyDFHiveSystem, 8116, GameMain.localPlanet.astroId, vectorLF, Maths.SphericalRotation(vectorLF, (float)num * 360f));
				int dfRelayId = enemyDFHiveSystem.sector.enemyPool[num2].dfRelayId;
				DFRelayComponent dFRelayComponent = enemyDFHiveSystem.relays.buffer[dfRelayId];
				Vector3 vector = -(GameMain.localPlanet.veinBiasVector * 0.97f).normalized;
				if (dFRelayComponent != null)
				{
					dFRelayComponent.SetDockIndex(enemyDFHiveSystem.relayCount);
					dFRelayComponent.hiveAstroId = enemyDFHiveSystem.hiveAstroId;
					dFRelayComponent.targetAstroId = GameMain.localPlanet.astroId;
					dFRelayComponent.targetLPos = vectorLF;
					dFRelayComponent.targetYaw = (float)num * 360f;
					dFRelayComponent.baseState = 1;
					dFRelayComponent.baseId = 0;
					double num3 = VectorLF3.Dot(vectorLF.normalized, vector);
					num3 = Maths.Clamp01((num3 + 1.0) * 0.5);
					num3 = Math.Pow(num3, 0.5);
					dFRelayComponent.baseTicks = (int)(6400f * (float)(Math.Pow(x, 2.0) * num3) + 200.5f);
					dFRelayComponent.baseEvolve = enemyDFHiveSystem.evolve;
					dFRelayComponent.baseEvolve.threat = 0;
					dFRelayComponent.baseEvolve.waves = 1;
					dFRelayComponent.direction = 0;
					dFRelayComponent.stage = 2;
					int num4 = random.Next(180001) * 100;
					int builderId = dFRelayComponent.builderId;
					enemyDFHiveSystem.builders.buffer[builderId].energy = enemyDFHiveSystem.builders.buffer[builderId].maxEnergy + num4;
					enemyDFHiveSystem.sector.enemyAnimPool[num2].time = 1f;
					enemyDFHiveSystem.sector.enemyAnimPool[num2].state = 1u;
					enemyDFHiveSystem.sector.enemyAnimPool[num2].power = -1f;
				}
				enemyDFHiveSystem.idleRelayCount = 0;
				for (int i = 0; i < enemyDFHiveSystem.relayDocks.Length; i++)
				{
					ref DFDock reference = ref enemyDFHiveSystem.relayDocks[i % enemyDFHiveSystem.relayDocks.Length];
					int num5 = enemyDFHiveSystem.sector.CreateEnemyFinal(enemyDFHiveSystem, 8116, enemyDFHiveSystem.hiveAstroId, reference.pos, reference.rot);
					int dfRelayId2 = enemyDFHiveSystem.sector.enemyPool[num5].dfRelayId;
					DFRelayComponent dFRelayComponent2 = enemyDFHiveSystem.relays.buffer[dfRelayId2];
					Assert.True(dFRelayComponent2 != null && dfRelayId2 > 0 && dfRelayId2 == dFRelayComponent2.id);
					if (dFRelayComponent2 != null)
					{
						dFRelayComponent2.SetDockIndex(i);
						enemyDFHiveSystem.idleRelayIds[enemyDFHiveSystem.idleRelayCount++] = dfRelayId2;
					}
				}
			}
			else
			{
				if (ClickGenerateDFRelayLockClick || !ClickKillEnemy.Value || ((!Input.GetMouseButton(0) || ClickKillEnemyMode.Value != 1) && (!Input.GetMouseButtonDown(0) || ClickKillEnemyMode.Value != 0)))
				{
					return;
				}
				GameData data = GameMain.data;
				PlanetData localPlanet = data.localPlanet;
				PlanetFactory planetFactory = ((localPlanet != null && localPlanet.factoryLoaded) ? localPlanet.factory : null);
				PlanetPhysics planetPhysics = planetFactory?.planet.physics;
				SpaceSector spaceSector = data.spaceSector;
				SectorPhysics physics = spaceSector.physics;
				EnemyData item = default(EnemyData);
				EnemyDFGroundSystem enemyDFGroundSystem = null;
				EnemyDFHiveSystem enemyDFHiveSystem3 = null;
				if (planetPhysics != null)
				{
					item = planetPhysics.raycastLogic.castEnemy;
					if (item.id > 0)
					{
						enemyDFGroundSystem = planetFactory.enemySystem;
					}
				}
				if (enemyDFGroundSystem == null && physics != null && physics.spaceColliderLogic.cursorCastAllCount > 0)
				{
					RaycastData raycastData = physics.spaceColliderLogic.cursorCastAll[0];
					if (raycastData.objType == EObjectType.Enemy && raycastData.objId > 0)
					{
						item = spaceSector.enemyPool[raycastData.objId];
						enemyDFGroundSystem = null;
						enemyDFHiveSystem3 = spaceSector.GetHiveByAstroId(item.originAstroId);
					}
				}
				if (item.id <= 0 || item.modelIndex <= 0)
				{
					return;
				}
				if (enemyDFHiveSystem3 != null)
				{
					int dfSCoreId = item.dfSCoreId;
					if (dfSCoreId > 0 && ClickKillEnemyBaseChain)
					{
						EnemyData[] enemyPool = GameMain.data.spaceSector.enemyPool;
						EnemyData[] array = enemyPool;
						for (int j = 0; j < array.Length; j++)
						{
							EnemyData item2 = array[j];
							if (item2.originAstroId == enemyDFHiveSystem3.hiveAstroId)
							{
								killEnemys.Enqueue(item2);
							}
						}
					}
					killEnemys.Enqueue(item);
				}
				else
				{
					if (enemyDFGroundSystem == null)
					{
						return;
					}
					EnemyData[] enemyPool2 = planetFactory.enemyPool;
					int dfGBaseId = item.dfGBaseId;
					if (dfGBaseId > 0 && ClickKillEnemyBaseChain)
					{
						EnemyData[] array2 = enemyPool2;
						for (int k = 0; k < array2.Length; k++)
						{
							EnemyData item3 = array2[k];
							if (item3.owner == dfGBaseId)
							{
								killEnemys.Enqueue(item3);
							}
						}
					}
					killEnemys.Enqueue(item);
				}
			}
		}

		private void InitPlanetWaterType()
		{
			if (GameMain.galaxy?.stars == null || GameMain.data?.gameDesc == null)
			{
				return;
			}
			long seedKey = GameMain.data.gameDesc.seedKey64;
			originWaterTypes.seedKey64 = seedKey;
			StarData[] stars = GameMain.galaxy.stars;
			foreach (StarData starData in stars)
			{
				if (starData == null)
				{
					continue;
				}
				PlanetData[] planets = starData.planets;
				foreach (PlanetData planetData in planets)
				{
					if (planetData != null && !(planetData.gasTotalHeat > 0.0))
					{
						originWaterTypes.waterTypes.Add(planetData.id, planetData.waterItemId);
					}
				}
			}
			if (seedPlanetWaterTypes.ContainsKey(seedKey))
			{
				currentWaterTypes = seedPlanetWaterTypes[seedKey];
				{
					foreach (KeyValuePair<int, int> waterType in currentWaterTypes.waterTypes)
					{
						PlanetData planetData2 = GameMain.galaxy.PlanetById(waterType.Key);
						if (planetData2 != null)
						{
							planetData2.waterItemId = waterType.Value;
						}
					}
					return;
				}
			}
			currentWaterTypes = new SeedPlanetWater(seedKey);
			seedPlanetWaterTypes.Add(seedKey, currentWaterTypes);
		}

		private void OnsecondMethod()
		{
			if (!OneSecondTimeElapse)
			{
				return;
			}
			if (Quantumtransport_bool.Value)
			{
				try
				{
					takeitemfromstarsuperstation();
				}
				catch (Exception ex)
				{
					UnityEngine.Debug.Log("量子传输失败1" + ex.Message);
				}
			}
			if (Mechalogistics_bool.Value)
			{
				MechaLogisticsMethod();
			}
			if (Infinitething.Value)
			{
				InfiniteAllThingInPackage();
			}
			if (MiddleMouseLockGrid.Value)
			{
				InfiniteFilterThingInPackage();
			}
		}

		public void CancelAllToggle()
		{
			InfiniteSand.Value = false;
			QuickHandcraft.Value = false;
			QuickPlayerMine.Value = false;
			QuickabortSwarm.Value = false;
			ChangeDysonradius.Value = false;
			NotTidyVein.Value = false;
			isInstantItem.Value = false;
			InspectDisNoLimit.Value = false;
			StationMaxproliferator.Value = false;
			Mechalogistics_bool.Value = false;
			MechalogStoragerecycle_bool.Value = false;
			MechalogStorageprovide_bool.Value = false;
			MechalogStationrecycle_bool.Value = false;
			MechalogStationprovide_bool.Value = false;
			Infinitestoragetank.Value = false;
			TankMaxproliferator.Value = false;
			Quantumtransport_bool.Value = false;
			Quantumtransportbuild_bool.Value = false;
			Quantumtransportpdwarp_bool.Value = false;
			Quantumtransportstarwarp_bool.Value = false;
			needtrashsand.Value = false;
			InfineteStarPower.Value = false;
			PlanetPower_bool.Value = false;
			allhandcraft.Value = false;
			quickproduce.Value = false;
			blueprintpastenoneed_bool.Value = false;
			noneedwarp.Value = false;
			Infinitething.Value = false;
			Infiniteplayerpower.Value = false;
			deleteveinbool.Value = false;
			MechalogisticsPlanet_bool.Value = false;
			StationMiner.Value = false;
			dismantle_but_nobuild.Value = false;
			build_station_nocondition.Value = false;
			StationTrash.Value = false;
			DroneNoenergy_bool.Value = false;
			BuildNotime_bool.Value = false;
			Station_infiniteWarp_bool.Value = false;
			StationfullCount_bool.Value = false;
			Buildingnoconsume.Value = false;
			Stationfullenergy.Value = false;
			BeltSignalFunction.Value = false;
			Tankcontentall.Value = false;
			ArchitectMode.Value = false;
			quickabsorbsolar.Value = false;
			cancelsolarbullet.Value = false;
			alwaysemission.Value = false;
			StationSpray.Value = false;
			Maxproliferator.Value = false;
			StationPowerGen.Value = false;
			CloseUIAbnormalityTip.Value = false;
			QuantumtransportstationSupply.Value = false;
			QuantumtransportlabSupply.Value = false;
			QuantumtransportpowerSupply.Value = false;
			QuantumtransportassembleSupply.Value = false;
			QuantumtransportstationDemand.Value = false;
			QuantumtransportminerDemand.Value = false;
			QuantumtransportsiloDemand.Value = false;
			QuantumtransportlabDemand.Value = false;
			QuantumtransportpowerDemand.Value = false;
			QuantumtransportassembleDemand.Value = false;
			Windturbinescovertheglobe.Value = false;
			WindturbinesUnlimitedEnergy.Value = false;
			AutoChangeStationName.Value = "";
			StationMinerSmelter.Value = false;
			StationSprayer.Value = false;
		}

		public void QuickKeyOpenWindow()
		{
			//IL_0030: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Unknown result type (might be due to invalid IL or missing references)
			//IL_0076: Unknown result type (might be due to invalid IL or missing references)
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0050: Unknown result type (might be due to invalid IL or missing references)
			//IL_0055: Unknown result type (might be due to invalid IL or missing references)
			//IL_0098: Unknown result type (might be due to invalid IL or missing references)
			//IL_009d: Unknown result type (might be due to invalid IL or missing references)
			if (Input.GetKeyDown(KeyCode.Escape))
			{
				guidraw.CloseMainWindow();
			}
			if (!ChangingQuickKey)
			{
				bool flag = false;
				KeyboardShortcut value = QuickKey.Value;
				if (value.Modifiers.Count() == 0)
				{
					value = QuickKey.Value;
					if (Input.GetKeyDown(value.MainKey))
					{
						flag = true;
					}
				}
				else
				{
					value = QuickKey.Value;
					if (Input.GetKey(value.MainKey))
					{
						flag = true;
						value = QuickKey.Value;
						foreach (KeyCode modifier in value.Modifiers)
						{
							if (!Input.GetKeyDown(modifier))
							{
								flag = false;
							}
						}
					}
				}
				if (flag)
				{
					guidraw.MainWindowKeyInvoke();
				}
			}
			if (TurrentKeepSuperNovalQuickKey.Value && Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.S))
			{
				TurrentKeepSuperNoval.Value = !TurrentKeepSuperNoval.Value;
				UIRealtimeTip.Popup("炮塔永久超新星" + (TurrentKeepSuperNoval.Value ? "开启" : "关闭"));
			}
		}

		public void ChangeQuickKeyMethod()
		{
			//IL_0034: Unknown result type (might be due to invalid IL or missing references)
			if (ChangeQuickKey)
			{
				setQuickKey();
				ChangingQuickKey = true;
			}
			else if (!ChangeQuickKey && ChangingQuickKey)
			{
				QuickKey.Value = tempShowWindow;
				ChangingQuickKey = false;
			}
		}

		public void DriftBuild()
		{
			if (!DriftBuildings)
			{
				return;
			}
			PlayerAction_Build playerAction_Build = player?.controller?.actionBuild;
			if (playerAction_Build != null && player.controller.cmd.type == ECommand.Build)
			{
				if (blueprintPasteToolActive != playerAction_Build.blueprintPasteTool.active)
				{
					blueprintPasteToolActive = !blueprintPasteToolActive;
					DriftBuildingLevel = 0;
				}
				if (Input.GetKeyDown(KeyCode.UpArrow))
				{
					DriftBuildingLevel++;
					if (blueprintPasteToolActive)
					{
						playerAction_Build.blueprintPasteTool.cursorValid = true;
						playerAction_Build.blueprintPasteTool.DeterminePreviewsPrestage();
					}
				}
				if (Input.GetKeyDown(KeyCode.DownArrow))
				{
					DriftBuildingLevel--;
					if (blueprintPasteToolActive)
					{
						playerAction_Build.blueprintPasteTool.cursorValid = true;
						playerAction_Build.blueprintPasteTool.DeterminePreviewsPrestage();
					}
				}
			}
			else if (DriftBuildingLevel != 0)
			{
				DriftBuildingLevel = 0;
			}
		}

		public void SetMaxGasStation()
		{
			if (GameMain.localPlanet != null && GameMain.localPlanet.type == EPlanetType.Gas)
			{
				for (int i = 0; i < Constant.nodepos.Count; i++)
				{
					Vector3 vector = Constant.nodepos[i] * GameMain.localPlanet.realRadius;
					Vector3 vector2 = 0.025f * vector.normalized * player.planetData.realRadius;
					Quaternion quaternion = Maths.SphericalRotation(vector, player.controller.actionBuild.clickTool.yaw);
					vector += vector2;
					PrebuildData prebuild = default(PrebuildData);
					prebuild.protoId = 2105;
					prebuild.modelIndex = 117;
					prebuild.pos = vector + quaternion * Vector3.zero;
					prebuild.pos2 = vector + quaternion * Vector3.zero;
					prebuild.rot = quaternion * Quaternion.identity;
					prebuild.rot2 = quaternion * Quaternion.identity;
					prebuild.pickOffset = 0;
					prebuild.insertOffset = 0;
					prebuild.recipeId = 0;
					prebuild.filterId = 0;
					prebuild.paramCount = 0;
					prebuild.InitParametersArray(0);
					player.controller.actionBuild.clickTool.factory.AddPrebuildDataWithComponents(prebuild);
				}
			}
		}

		public void InitPlayer()
		{
			if (player == null || player.mecha == null || player.mecha.constructionModule.droneIdleCount < player.mecha.constructionModule.droneAliveCount)
			{
				return;
			}
			refreshPlayerData = true;
			ModeConfig freeMode = Configs.freeMode;
			GameHistoryData history = GameMain.history;
			Mecha mecha = player.mecha;
			mecha.coreEnergyCap = freeMode.mechaCoreEnergyCap;
			mecha.coreLevel = freeMode.mechaCoreLevel;
			mecha.corePowerGen = freeMode.mechaCorePowerGen;
			mecha.miningSpeed = freeMode.mechaMiningSpeed;
			mecha.walkSpeed = freeMode.mechaWalkSpeed;
			mecha.jumpSpeed = freeMode.mechaJumpSpeed;
			mecha.walkPower = freeMode.mechaWalkPower;
			mecha.thrusterLevel = freeMode.mechaThrusterLevel;
			mecha.jumpEnergy = freeMode.mechaJumpEnergy;
			mecha.constructionModule.Setup(freeMode);
			mecha.maxSailSpeed = freeMode.mechaSailSpeedMax;
			mecha.maxWarpSpeed = freeMode.mechaWarpSpeedMax;
			mecha.buildArea = freeMode.mechaBuildArea;
			mecha.replicateSpeed = freeMode.mechaReplicateSpeed;
			mecha.reactorPowerGen = freeMode.mechaReactorPowerGen;
			mecha.thrustPowerPerAcc = freeMode.mechaThrustPowerPerAcc;
			mecha.warpKeepingPowerPerSpeed = freeMode.mechaWarpKeepingPowerPerSpeed;
			mecha.warpStartPowerPerSpeed = freeMode.mechaWarpStartPowerPerSpeed;
			mecha.miningPower = freeMode.mechaMiningPower;
			mecha.hpMaxUpgrade = 0;
			mecha.laserLocalAttackRange = freeMode.mechaLocalLaserAttackRange;
			mecha.laserSpaceAttackRange = freeMode.mechaSpaceLaserAttackRange;
			mecha.laserLocalDamage = freeMode.mechaLocalLaserDamage;
			mecha.laserEnergyCapacity = freeMode.mechaLaserEnergyCapacity;
			mecha.laserLocalEnergyCost = freeMode.mechaLocalLaserEnergyCost;
			mecha.laserSpaceEnergyCost = freeMode.mechaSpaceLaserEnergyCost;
			mecha.energyShieldRadius = freeMode.energyShieldRadius;
			mecha.energyShieldCapacity = freeMode.energyShieldCapacity;
			mecha.groundCombatModule.fleetCount = 0;
			mecha.spaceCombatModule.fleetCount = 0;
			player.deliveryPackage.colCount = 0;
			player.packageColCount = 10;
			player.deliveryPackage.stackSizeMultiplier = Configs.freeMode.deliveryPackageStackSizeMultiplier;
			int playerPackageSize = freeMode.playerPackageSize;
			player.deliveryPackage.rowCount = (playerPackageSize - 1) / 10 + 1;
			history.constructionDroneSpeed = freeMode.droneSpeed;
			history.globalHpEnhancement = 0f;
			history.constructionDroneMovement = freeMode.droneMovement;
			history.stationPilerLevel = 1;
			history.logisticDroneCarries = freeMode.logisticDroneCarries;
			history.logisticDroneSpeed = freeMode.logisticDroneSpeed;
			history.logisticShipCarries = freeMode.logisticShipCarries;
			history.logisticShipSailSpeed = freeMode.logisticShipSailSpeed;
			history.logisticShipWarpSpeed = freeMode.logisticShipWarpSpeed;
			history.logisticCourierSpeed = freeMode.logisticCourierSpeed;
			history.logisticCourierCarries = freeMode.logisticCourierCarries;
			history.dispenserDeliveryMaxAngle = freeMode.dispenserDeliveryMaxAngle;
			history.logisticShipSpeedScale = 1f;
			history.logisticDroneSpeedScale = 1f;
			history.logisticCourierSpeedScale = 1f;
			history.inserterStackInput = 2;
			history.logisticShipWarpDrive = freeMode.logisticShipWarpDrive;
			history.miningCostRate = freeMode.miningCostRate;
			history.miningSpeedScale = freeMode.miningSpeedScale;
			history.storageLevel = 2;
			history.labLevel = 3;
			history.enemyDropScale = 1f;
			history.techSpeed = freeMode.techSpeed;
			history.dysonNodeLatitude = 0f;
			history.solarEnergyLossRate = 0.7f;
			history.solarSailLife = freeMode.solarSailLife;
			history.localStationExtraStorage = 0;
			history.remoteStationExtraStorage = 0;
			history.autoReconstructSpeed = 0;
			history.kineticDamageScale = 1f;
			history.energyDamageScale = 1f;
			history.blastDamageScale = 1f;
			history.magneticDamageScale = 1f;
			history.combatDroneDamageRatio = 1f;
			history.combatDroneROFRatio = 1f;
			history.combatDroneDurabilityRatio = 1f;
			history.combatDroneSpeedRatio = 1f;
			history.combatShipSpeedRatio = 1f;
			history.combatShipDamageRatio = 1f;
			history.combatShipROFRatio = 1f;
			history.combatShipDurabilityRatio = 1f;
			history.planetaryATFieldEnergyRate = freeMode.planetaryATFieldEnergyRate;
			history.groundFleetPortCount = 0;
			history.spaceFleetPortCount = 0;
			StorageComponent.GRID[] array = new StorageComponent.GRID[player.package.size];
			Array.Copy(player.package.grids, array, player.package.size);
			player.package.SetSize(playerPackageSize);
			foreach (TechProto item in new List<TechProto>(LDB.techs.dataArray))
			{
				if (item.Level < item.MaxLevel)
				{
					for (int i = item.Level; i < GameMain.history.techStates[item.ID].curLevel + ((GameMain.history.techStates[item.ID].curLevel >= item.MaxLevel) ? 1 : 0); i++)
					{
						for (int j = 0; j < item.UnlockFunctions.Length; j++)
						{
							if (item.UnlockFunctions[j] == 30)
							{
								history.localStationExtraStorage += (int)item.UnlockValues[j];
							}
							else if (item.UnlockFunctions[j] == 31)
							{
								history.remoteStationExtraStorage += (int)item.UnlockValues[j];
							}
							else
							{
								GameMain.history.UnlockTechFunction(item.UnlockFunctions[j], item.UnlockValues[j], i);
							}
						}
					}
				}
				else if (GameMain.history.techStates[item.ID].unlocked)
				{
					for (int k = 0; k < item.UnlockFunctions.Length; k++)
					{
						GameMain.history.UnlockTechFunction(item.UnlockFunctions[k], item.UnlockValues[k], GameMain.history.techStates[item.ID].maxLevel);
					}
				}
			}
			int num = 0;
			for (int l = 0; l < array.Length; l++)
			{
				if (num == player.package.size)
				{
					break;
				}
				if (array[l].count != 0 || array[l].filter != 0 || array[l].itemId != 0)
				{
					player.package.grids[num++] = array[l];
				}
			}
		}

		public void MechaLogisticsMethod()
		{
			StorageComponent package = player.package;
			if (player.inhandItemId != 0)
			{
				return;
			}
			int num = (MechalogPlayerStorageFirst_bool.Value ? 1 : 0);
			for (int i = 0; i < player.deliveryPackage.grids.Length; i++)
			{
				DeliveryPackage.GRID gRID = player.deliveryPackage.grids[i];
				int itemId = gRID.itemId;
				if (itemId == 0)
				{
					continue;
				}
				if (num == 0 && MechalogBuildGotoPlayerStorageFirst_bool.Value && LDB.items.Select(itemId).CanBuild)
				{
					num = 1;
				}
				int count = gRID.count;
				int packageItemCount = player.packageUtility.GetPackageItemCount(itemId);
				int num2 = packageItemCount + count;
				int remainInc;
				if (gRID.requireCount > num2)
				{
					int packageItemCapacity = player.packageUtility.GetPackageItemCapacity(itemId);
					int num3 = Math.Min(gRID.requireCount - num2, packageItemCapacity);
					int num4 = 0;
					int num5 = 0;
					for (int j = 0; j < GameMain.data.factoryCount; j++)
					{
						PlanetFactory planetFactory = GameMain.data.factories[j];
						if (MechalogisticsPlanet_bool.Value && !planetFactory.planet.displayName.Equals("机甲物流"))
						{
							continue;
						}
						if (MechalogStationprovide_bool.Value && planetFactory.transport?.stationPool != null)
						{
							StationComponent[] stationPool = planetFactory.transport.stationPool;
							foreach (StationComponent stationComponent in stationPool)
							{
								if (stationComponent != null && stationComponent.storage != null)
								{
									int count2 = num3;
									int itemId2 = itemId;
									stationComponent.TakeItem(ref itemId2, ref count2, out var inc);
									num4 += count2;
									num3 -= count2;
									num5 += inc;
									if (num4 >= num3)
									{
										break;
									}
								}
							}
						}
						if (!MechalogStorageprovide_bool.Value || planetFactory.factoryStorage == null)
						{
							continue;
						}
						if (num4 < num3 && planetFactory.factoryStorage.tankPool != null)
						{
							TankComponent[] tankPool = planetFactory.factoryStorage.tankPool;
							for (int l = 0; l < tankPool.Length; l++)
							{
								TankComponent tankComponent = tankPool[l];
								if (tankComponent.id > 0 && tankComponent.fluidId > 0 && tankComponent.fluidCount > 0 && itemId == tankComponent.fluidId)
								{
									int num6 = ((tankComponent.fluidCount > num3) ? num3 : tankComponent.fluidCount);
									int num7 = (int)((double)(tankComponent.fluidInc / tankComponent.fluidCount) + 0.5) * num6;
									planetFactory.factoryStorage.tankPool[tankComponent.id].fluidCount -= num6;
									planetFactory.factoryStorage.tankPool[tankComponent.id].fluidInc -= num7;
									num5 += num7;
									num4 += num6;
									num3 -= num6;
									if (num4 >= num3)
									{
										break;
									}
								}
							}
						}
						if (num4 >= num3 || planetFactory.factoryStorage.storagePool == null)
						{
							continue;
						}
						StorageComponent[] storagePool = planetFactory.factoryStorage.storagePool;
						foreach (StorageComponent storageComponent in storagePool)
						{
							if (storageComponent != null)
							{
								int inc2;
								int num8 = storageComponent.TakeItem(itemId, num3, out inc2);
								num4 += num8;
								num5 += inc2;
								num3 -= num8;
								if (num4 >= num3)
								{
									break;
								}
							}
						}
						if (num4 >= num3)
						{
							break;
						}
					}
					player.packageUtility.AddItemToAllPackages(itemId, num4, i, num5, out remainInc, num);
				}
				if (gRID.recycleCount >= num2)
				{
					continue;
				}
				int count3 = num2 - gRID.recycleCount;
				player.packageUtility.TakeItemFromAllPackages(i, ref itemId, ref count3, out var inc3, deliveryFirst: true);
				if (itemId == 0 || count3 == 0)
				{
					continue;
				}
				for (int n = 0; n < GameMain.data.factoryCount; n++)
				{
					PlanetFactory planetFactory2 = GameMain.data.factories[n];
					if (MechalogisticsPlanet_bool.Value && !planetFactory2.planet.displayName.Equals("机甲物流"))
					{
						continue;
					}
					if (MechalogStationrecycle_bool.Value && planetFactory2.transport?.stationPool != null)
					{
						StationComponent[] stationPool2 = planetFactory2.transport.stationPool;
						foreach (StationComponent stationComponent2 in stationPool2)
						{
							if (stationComponent2 == null || stationComponent2.storage == null)
							{
								continue;
							}
							for (int num10 = 0; num10 < stationComponent2.storage.Length; num10++)
							{
								if (stationComponent2.storage[num10].itemId == itemId)
								{
									int num11 = stationComponent2.storage[num10].max - stationComponent2.storage[num10].count;
									int num12 = SplitIncUtil.split_inc(ref count3, ref inc3, num11);
									stationComponent2.storage[num10].count = stationComponent2.storage[num10].count + num11;
									stationComponent2.storage[num10].inc = stationComponent2.storage[num10].inc + num12;
								}
							}
							if (count3 == 0)
							{
								break;
							}
						}
					}
					if (planetFactory2.transport != null && planetFactory2.transport.stationPool != null && MechalogStationrecycle_bool.Value && count3 == 0)
					{
						break;
					}
					if (!MechalogStoragerecycle_bool.Value || planetFactory2.factoryStorage == null)
					{
						continue;
					}
					if (count3 > 0 && planetFactory2.factoryStorage.tankPool != null)
					{
						TankComponent[] tankPool2 = planetFactory2.factoryStorage.tankPool;
						for (int num13 = 0; num13 < tankPool2.Length; num13++)
						{
							TankComponent tankComponent2 = tankPool2[num13];
							if (tankComponent2.id > 0 && tankComponent2.fluidId > 0 && tankComponent2.fluidCount > 0 && itemId == tankComponent2.fluidId)
							{
								if (tankComponent2.fluidCount > 10000)
								{
									planetFactory2.factoryStorage.tankPool[tankComponent2.id].fluidCount += count3;
									planetFactory2.factoryStorage.tankPool[tankComponent2.id].fluidInc += inc3;
									count3 = 0;
								}
								else
								{
									int num14 = ((tankComponent2.fluidCapacity - tankComponent2.fluidCount > count3) ? count3 : (tankComponent2.fluidCapacity - tankComponent2.fluidCount));
									int num15 = SplitIncUtil.split_inc(ref count3, ref inc3, num14);
									planetFactory2.factoryStorage.tankPool[tankComponent2.id].fluidCount += num14;
									planetFactory2.factoryStorage.tankPool[tankComponent2.id].fluidInc += num15;
								}
								if (count3 == 0)
								{
									break;
								}
							}
						}
					}
					if (count3 <= 0 || planetFactory2.factoryStorage.storagePool == null)
					{
						continue;
					}
					StorageComponent[] storagePool2 = planetFactory2.factoryStorage.storagePool;
					foreach (StorageComponent storageComponent2 in storagePool2)
					{
						if (storageComponent2 != null)
						{
							count3 -= storageComponent2.AddItem(itemId, count3, inc3, out var remainInc2);
							inc3 -= remainInc2;
							if (count3 == 0)
							{
								break;
							}
						}
					}
				}
				player.packageUtility.AddItemToAllPackages(itemId, count3, i, inc3, out remainInc);
			}
		}

		public void InitBeltSignalDiction()
		{
			if (GameMain.galaxy == null || GameMain.galaxy.stars == null)
			{
				return;
			}
			StarData[] stars = GameMain.galaxy.stars;
			foreach (StarData starData in stars)
			{
				PlanetData[] planets = starData.planets;
				foreach (PlanetData planetData in planets)
				{
					if (planetData == null || planetData.factory == null || planetData.factory.entitySignPool == null)
					{
						continue;
					}
					EntityData[] entityPool = planetData.factory.entityPool;
					for (int k = 0; k < entityPool.Length; k++)
					{
						EntityData entityData = entityPool[k];
						if (entityData.id > 0 && entityData.beltId != 0 && planetData.factory.entitySignPool[entityData.id].iconId0 != 0)
						{
							int iconId = (int)planetData.factory.entitySignPool[entityData.id].iconId0;
							int beltId = entityData.beltId;
							if (!Beltsignal.ContainsKey(planetData.factoryIndex))
							{
								Beltsignal.Add(planetData.factoryIndex, new Dictionary<int, int>());
							}
							if (!Beltsignal[planetData.factoryIndex].ContainsKey(beltId))
							{
								Beltsignal[planetData.factoryIndex].Add(beltId, iconId);
							}
							else
							{
								Beltsignal[planetData.factoryIndex][beltId] = iconId;
							}
							if (!Beltsignalnumberoutput.ContainsKey(planetData.factoryIndex))
							{
								Beltsignalnumberoutput.Add(planetData.factoryIndex, new Dictionary<int, int>());
							}
							if (!Beltsignalnumberoutput[planetData.factoryIndex].ContainsKey(beltId) && planetData.factory.entitySignPool[entityData.id].iconId0 == 601 && planetData.factory.entitySignPool[entityData.id].count0 > 0f)
							{
								Beltsignalnumberoutput[planetData.factoryIndex].Add(beltId, (int)planetData.factory.entitySignPool[entityData.id].count0);
							}
						}
					}
				}
			}
		}

		private void InitQuantumTransport()
		{
			StationComponent[] stationPool = GameMain.data.galacticTransport.stationPool;
			foreach (StationComponent stationComponent in stationPool)
			{
				if (stationComponent != null && stationComponent.isCollector)
				{
					CollectorStation.Add(stationComponent.gid);
				}
			}
		}

		public static void AddComsumeItemtoTotal(int itemid, int count)
		{
			List<int> list = new List<int>();
			List<long> list2 = new List<long>();
			list.Add(itemid);
			list2.Add(count);
			int num = 0;
			while (num < list.Count)
			{
				ItemProto itemProto = LDB.items.Select(list[num]);
				if (itemProto.recipes == null || itemProto.recipes.Count == 0 || list[num] == 1003)
				{
					num++;
					continue;
				}
				for (int i = 0; i < itemProto.recipes[0].Items.Length; i++)
				{
					list.Add(itemProto.recipes[0].Items[i]);
					list2.Add(itemProto.recipes[0].ItemCounts[i] * list2[num]);
				}
				num++;
			}
			for (int num2 = list.Count - 1; num2 >= 0; num2--)
			{
				try
				{
					if (itemid == 1503 && list[num2] == 1501)
					{
						list2[num2] *= 12L;
					}
					if (itemid == 1503 && list[num2] == 1404)
					{
						list2[num2] *= 12L;
					}
					while (list2[num2] > 0)
					{
						int num3 = (int)((list2[num2] > int.MaxValue) ? int.MaxValue : list2[num2]);
						GameMain.data.statistics.production.factoryStatPool[GameMain.localPlanet.factory.index].AddProductionToTotalArray(list[num2], num3);
						GameMain.data.statistics.production.factoryStatPool[GameMain.localPlanet.factory.index].AddConsumptionToTotalArray(list[num2], num3);
						list2[num2] -= num3;
					}
				}
				catch
				{
				}
			}
		}

		public void PlayerDataInit()
		{
			if (refreshPlayerData || player == null || GameMain.mainPlayer != player)
			{
				refreshPlayerData = false;
				player = GameMain.mainPlayer;
				propertyData = new PropertyData();
				propertyData.SetContent(player.mecha, GameMain.history, player.deliveryPackage.stackSizeMultiplier);
				if (Mechalogistics_bool.Value && !player.deliveryPackage.unlocked)
				{
					player.deliveryPackage.unlocked = true;
					player.deliveryPackage.colCount = 1;
					player.deliveryPackage.NotifySizeChange();
				}
			}
		}

		public void BluePrintpasteNoneed()
		{
			if (!blueprintpastenoneed_bool.Value)
			{
				return;
			}
			PlanetFactory planetFactory = GameMain.localPlanet?.factory;
			if (planetFactory == null)
			{
				return;
			}
			for (int i = 1; i < planetFactory.prebuildCursor; i++)
			{
				if (planetFactory.prebuildPool[i].protoId > 0)
				{
					planetFactory.prebuildPool[i].itemRequired = 0;
				}
			}
		}

		public void FinishDysonShell()
		{
			DysonSphere[] dysonSpheres = GameMain.data.dysonSpheres;
			foreach (DysonSphere dysonSphere in dysonSpheres)
			{
				if (dysonSphere == null || dysonSphere.starData != GameMain.localStar)
				{
					continue;
				}
				int num = 0;
				int num2 = 0;
				DysonSphereLayer[] layersIdBased = dysonSphere.layersIdBased;
				foreach (DysonSphereLayer dysonSphereLayer in layersIdBased)
				{
					if (dysonSphereLayer == null)
					{
						continue;
					}
					DysonNode[] nodePool = dysonSphereLayer.nodePool;
					foreach (DysonNode dysonNode in nodePool)
					{
						if (dysonNode == null)
						{
							continue;
						}
						if (dysonNode.totalSp < dysonNode.totalSpMax)
						{
							num += dysonNode.totalSpMax - dysonNode.totalSp;
							dysonNode.sp = 30;
							for (int l = 0; l < dysonNode.frames.Count; l++)
							{
								if (dysonNode.frames[l].nodeA == dysonNode)
								{
									dysonNode.frames[l].spA = dysonNode.frames[l].spMax / 2;
								}
								else if (dysonNode.frames[l].nodeB == dysonNode)
								{
									dysonNode.frames[l].spB = dysonNode.frames[l].spMax / 2;
								}
							}
						}
						if (dysonNode.totalCp < dysonNode.totalCpMax)
						{
							num2 = dysonNode.totalCpMax - dysonNode.totalCp;
							for (int m = 0; m < dysonNode.shells.Count; m++)
							{
								DysonShell dysonShell = dysonNode.shells[m];
								int num3 = dysonShell.nodeIndexMap[dysonNode.id];
								dysonShell.nodecps[num3] += (dysonShell.vertsqOffset[num3 + 1] - dysonShell.vertsqOffset[num3]) * dysonShell.cpPerVertex;
								dysonShell.nodecps[dysonShell.nodecps.Length - 1] += (dysonShell.vertsqOffset[num3 + 1] - dysonShell.vertsqOffset[num3]) * dysonShell.cpPerVertex;
							}
						}
					}
				}
				dysonSphere.modelRenderer.RebuildModels();
			}
		}

		public void RemoveAllBuild(int type)
		{
			if (GameMain.localPlanet == null || GameMain.localPlanet.factory == null)
			{
				return;
			}
			if (type == 1)
			{
				entityitemnoneed = true;
			}
			EntityData[] entityPool = GameMain.localPlanet.factory.entityPool;
			for (int i = 0; i < entityPool.Length; i++)
			{
				EntityData entityData = entityPool[i];
				int stationId = entityData.stationId;
				if (stationId > 0)
				{
					StationComponent stationComponent = GameMain.localPlanet.factory.transport.stationPool[stationId];
					for (int j = 0; j < stationComponent.storage.Length; j++)
					{
						if (type != 0)
						{
							break;
						}
						int upCount = player.TryAddItemToPackage(stationComponent.storage[j].itemId, stationComponent.storage[j].count, 0, throwTrash: true, entityData.id);
						UIItemup.Up(stationComponent.storage[j].itemId, upCount);
					}
					stationComponent.storage = new StationStore[stationComponent.storage.Length];
					stationComponent.needs = new int[stationComponent.needs.Length];
				}
				if (type == 1)
				{
					GameMain.localPlanet.factory.RemoveEntityWithComponents(entityData.id, returnItems: false);
				}
				else
				{
					player.controller.actionBuild.DoDismantleObject(entityData.id);
				}
			}
			entityitemnoneed = false;
		}

		public void OnSetBase()
		{
			PlanetData localPlanet = GameMain.localPlanet;
			if (localPlanet != null && localPlanet.type != EPlanetType.Gas)
			{
				PlanetFactory factory = localPlanet.factory;
				if (restorewater)
				{
					factory.PlanetReformRevert();
					return;
				}
				BuildTool_Reform reformTool = player.controller.actionBuild.reformTool;
				if (reformTool.reformMode == 1) { factory.PlanetReformRevert(); return; }
				if (reformTool.reformMode != 0) return;
				factory.PlanetReformAll(reformTool.brushType, reformTool.brushColor, reformTool.buryVeins);
			}
		}

		public void Clearpackage()
		{
			if (player == null)
			{
				return;
			}
			for (int i = 0; i < player.package.grids.Length; i++)
			{
				player.package.grids[i].count = 0;
				player.package.grids[i].inc = 0;
				if (player.package.grids[i].filter == 0)
				{
					player.package.grids[i].itemId = 0;
					player.package.grids[i].stackSize = 0;
				}
			}
			player.package.NotifyStorageChange();
		}

		public void Operatepackagesize(int rownum, int colnum, bool add = true)
        {
            ResizePackage(player, rownum, colnum, add);
        }

		public void UnlockallTech(bool addstat = false)
		{
			if (player == null)
			{
				return;
			}
			bool flag = true;
			while (flag)
			{
				flag = false;
				foreach (TechProto item in new List<TechProto>(LDB.techs.dataArray))
				{
					if (GameMain.data.history.TechUnlocked(item.ID) || item.IsObsolete || !GameMain.data.history.CanEnqueueTech(item.ID) || item.MaxLevel > 15)
					{
						continue;
					}
					flag = true;
					if (item.Level < item.MaxLevel)
					{
						for (int i = item.Level; i < item.MaxLevel; i++)
						{
							if (addstat)
							{
								for (int j = 0; j < item.itemArray.Length; j++)
								{
									AddComsumeItemtoTotal(item.Items[j], (int)(item.ItemPoints[j] * item.GetHashNeeded(item.Level) / 3600));
								}
							}
							for (int k = 0; k < item.UnlockFunctions.Length; k++)
							{
								if (item.UnlockFunctions[k] == 7)
								{
								}
								GameMain.history.UnlockTechFunction(item.UnlockFunctions[k], item.UnlockValues[k], i);
							}
						}
					}
					if (GameMain.history.techStates[item.ID].unlocked)
					{
						continue;
					}
					if (addstat)
					{
						for (int l = 0; l < item.itemArray.Length; l++)
						{
							AddComsumeItemtoTotal(item.Items[l], (int)(item.ItemPoints[l] * item.GetHashNeeded(item.Level) / 3600));
						}
					}
					for (int m = 0; m < item.UnlockFunctions.Length; m++)
					{
						if (item.UnlockFunctions[m] == 7)
						{
						}
					}
					GameMain.history.UnlockTech(item.ID);
				}
			}
		}

		public void lockTech()
		{
			TechProto[] dataArray = LDB.techs.dataArray;
			foreach (TechProto techProto in dataArray)
			{
				if (techProto.MaxLevel > 30 && techProto.Level != techProto.MaxLevel)
				{
					TechState value = GameMain.history.techStates[techProto.ID];
					value.unlocked = false;
					value.curLevel = techProto.Level;
					value.hashUploaded = 0L;
					value.hashNeeded = techProto.GetHashNeeded(value.curLevel);
					GameMain.history.techStates[techProto.ID] = value;
				}
			}
		}

		public void InfiniteFilterThingInPackage()
		{
			if (GameMain.mainPlayer == null)
			{
				return;
			}
			StorageComponent.GRID[] grids = GameMain.mainPlayer.package.grids;
			bool flag = false;
			for (int i = 0; i < grids.Length; i++)
			{
				if (grids[i].itemId > 0 && grids[i].filter > 0 && grids[i].count != grids[i].stackSize)
				{
					flag = true;
					grids[i].count = grids[i].stackSize;
				}
			}
			if (flag)
			{
				GameMain.mainPlayer.package.NotifyStorageChange();
			}
		}

		public void InfiniteAllThingInPackage()
		{
			if (GameMain.mainPlayer == null)
			{
				return;
			}
			StorageComponent.GRID[] grids = GameMain.mainPlayer.package.grids;
			if (grids.Length < LDB.items.dataArray.Length)
			{
				GameMain.mainPlayer.package.SetSize((LDB.items.dataArray.Length / player.packageColCount + 1) * player.packageColCount);
			}
			int num = 0;
			bool flag = false;
			ItemProto[] dataArray = LDB.items.dataArray;
			foreach (ItemProto itemProto in dataArray)
			{
				if (itemProto.ID != 1099)
				{
					if (grids[num].itemId != itemProto.ID || grids[num].count != StorageComponent.itemStackCount[itemProto.ID] || grids[num].stackSize != StorageComponent.itemStackCount[itemProto.ID])
					{
						flag = true;
						grids[num].itemId = itemProto.ID;
						grids[num].stackSize = StorageComponent.itemStackCount[itemProto.ID];
						grids[num].count = StorageComponent.itemStackCount[itemProto.ID];
					}
					num++;
					if (num == grids.Length)
					{
						break;
					}
				}
			}
			if (flag)
			{
				GameMain.mainPlayer.package.NotifyStorageChange();
			}
		}

		public void SetDronenocomsume()
		{
			if (player.mecha != null)
			{
				if (DroneNoenergy_bool.Value && player.mecha.droneEjectEnergy != 0.0)
				{
					player.mecha.droneEjectEnergy = 0.0;
					player.mecha.droneEnergyPerMeter = 0.0;
				}
				if (!DroneNoenergy_bool.Value && player.mecha.droneEjectEnergy == 0.0)
				{
					player.mecha.droneEjectEnergy = 300000.0;
					player.mecha.droneEnergyPerMeter = 60000.0;
				}
			}
		}

		public void ChangeRecipe()
		{
			for (int i = 0; i < LDB.recipes.dataArray.Length && i < originRecipeProtos.Length; i++)
			{
				RecipeProto recipeProto = LDB.recipes.dataArray[i];
				recipeProto.Handcraft = allhandcraft.Value || originRecipeProtos[i].Handcraft;
				recipeProto.TimeSpend = (quickproduce.Value ? 10 : originRecipeProtos[i].TimeSpend);
			}
			RecipeProto[] dataArray = LDB.recipes.dataArray;
			foreach (RecipeProto recipeProto2 in dataArray)
			{
			}
		}

		public void SetmultipleItemStatck(int multiple)
		{
			int num = LDB.items.dataArray.Length;
			for (int i = 0; i < num; i++)
			{
				ItemProto itemProto = LDB.items.dataArray[i];
				StorageComponent.itemStackCount[itemProto.ID] = itemProto.StackSize * multiple;
			}
			StackMultiple.Value = multiple;
		}

		public void ChangeItemstack()
		{
		}

		private void InitWaterTypes()
		{
			string[] array = Multifunction.seedPlanetWater.Value.Split(new char[1] { '|' });
			string[] array2 = array;
			foreach (string text in array2)
			{
				if (string.IsNullOrEmpty(text))
				{
					continue;
				}
				SeedPlanetWater seedPlanetWater = new SeedPlanetWater();
				string[] array3 = text.Split(new char[1] { ',' });
				if (array3[0] == "0")
				{
					continue;
				}
				if (array3[1].Length > 0)
				{
					seedPlanetWater.seedKey64 = Convert.ToInt64(array3[0]);
					string[] array4 = array3[1].Split(new char[1] { '-' });
					string[] array5 = array4;
					foreach (string text2 in array5)
					{
						if (!string.IsNullOrEmpty(text2))
						{
							string[] array6 = text2.Split(new char[1] { ':' });
							seedPlanetWater.waterTypes.Add(Convert.ToInt32(array6[0]), Convert.ToInt32(array6[1]));
						}
					}
				}
				if (seedPlanetWater.seedKey64 != 0)
				{
					seedPlanetWaterTypes.Add(seedPlanetWater.seedKey64, seedPlanetWater);
				}
			}
		}

		public void SetWaterType()
		{
			if (GameMain.localPlanet == null)
			{
				return;
			}
			ItemProto itemProto = LDB.items.dataArray.ToList().Find((ItemProto x) => x.name == currentPlanetWaterType);
			if (itemProto == null)
			{
				UIMessageBox.Show("", "设置海洋类型失败".getTranslate(), "确定".Translate(), 3);
			}
			else
			{
				if (GameMain.localPlanet.waterItemId == itemProto.ID)
				{
					return;
				}
				GameMain.localPlanet.waterItemId = itemProto.ID;
				int id = GameMain.localPlanet.id;
				int num = originWaterTypes.waterTypes[id];
				if (num == itemProto.ID && currentWaterTypes.waterTypes.ContainsKey(id))
				{
					currentWaterTypes.waterTypes.Remove(id);
				}
				else if (num != itemProto.ID)
				{
					if (!currentWaterTypes.waterTypes.ContainsKey(id))
					{
						currentWaterTypes.waterTypes.Add(id, itemProto.ID);
					}
					else
					{
						currentWaterTypes.waterTypes[id] = itemProto.ID;
					}
				}
				string text = "";
				foreach (KeyValuePair<long, SeedPlanetWater> seedPlanetWaterType in seedPlanetWaterTypes)
				{
					if (seedPlanetWaterType.Value.seedKey64 != 0L && seedPlanetWaterType.Value.waterTypes.Count != 0)
					{
						text = text + seedPlanetWaterType.Value.ToStr() + "|";
					}
				}
				seedPlanetWater.Value = text;
			}
		}

		public void RestoreWaterType()
		{
			string text = "";
			foreach (KeyValuePair<int, int> waterType in currentWaterTypes.waterTypes)
			{
				if (originWaterTypes.waterTypes.ContainsKey(waterType.Key))
				{
					GameMain.galaxy.PlanetById(waterType.Key).waterItemId = originWaterTypes.waterTypes[waterType.Key];
					if (GameMain.localPlanet.id == waterType.Key)
					{
						currentPlanetWaterType = LDB.items.Select(originWaterTypes.waterTypes[waterType.Key])?.name ?? "无海洋".getTranslate();
					}
				}
			}
			currentWaterTypes.waterTypes.Clear();
			foreach (KeyValuePair<long, SeedPlanetWater> seedPlanetWaterType in seedPlanetWaterTypes)
			{
				if (seedPlanetWaterType.Value.seedKey64 != 0L && seedPlanetWaterType.Value.waterTypes.Count != 0)
				{
					text = text + seedPlanetWaterType.Value.ToStr() + "|";
				}
			}
			seedPlanetWater.Value = text;
		}

		public void setQuickKey()
		{
			//IL_014b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0150: Unknown result type (might be due to invalid IL or missing references)
			//IL_0177: Unknown result type (might be due to invalid IL or missing references)
			//IL_017c: Unknown result type (might be due to invalid IL or missing references)
			bool flag = true;
			int[] array = new int[2];
			if (Input.GetKey(KeyCode.LeftShift) && flag)
			{
				flag = false;
				array[0] = 304;
			}
			if (Input.GetKey(KeyCode.LeftControl) && flag)
			{
				flag = false;
				array[0] = 306;
			}
			if (Input.GetKey(KeyCode.LeftAlt) && flag)
			{
				flag = false;
				array[0] = 308;
			}
			bool flag2 = true;
			for (int i = 48; i <= 57 && flag2; i++)
			{
				if (Input.GetKey((KeyCode)i))
				{
					array[1] = i;
					flag2 = false;
					break;
				}
			}
			for (int j = 97; j <= 122 && flag2; j++)
			{
				if (Input.GetKey((KeyCode)j))
				{
					array[1] = j;
					flag2 = false;
					break;
				}
			}
			for (int k = 282; k <= 291 && flag2; k++)
			{
				if (Input.GetKey((KeyCode)k))
				{
					array[1] = k;
					flag2 = false;
					break;
				}
			}
			switch ((!(flag && flag2)) ? ((flag || flag2) ? 1 : 2) : 0)
			{
			case 2:
				tempShowWindow = new KeyboardShortcut((KeyCode)array[1], new KeyCode[1] { (KeyCode)array[0] });
				break;
			case 1:
			{
				int num = Math.Max(array[0], array[1]);
				tempShowWindow = new KeyboardShortcut((KeyCode)num, Array.Empty<KeyCode>());
				break;
			}
			}
		}
	}
	public class Multifunctionpatch
	{
		public static Harmony harmony;

		public static int ability = 4;

		public static void Patchallmethod()
		{
			//IL_0006: Unknown result type (might be due to invalid IL or missing references)
			//IL_0010: Expected O, but got Unknown
			//IL_007b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0089: Expected O, but got Unknown
			harmony = new Harmony("cn.blacksnipe.dsp.Multfuntion_mod");
			MethodInfo[] methods = typeof(StorageComponent).GetMethods();
			MethodInfo[] array = methods;
			foreach (MethodInfo methodInfo in array)
			{
				if (methodInfo.Name == "TakeTailItems" && methodInfo.ReturnType == typeof(void))
				{
					MethodInfo method = typeof(Multifunctionpatch).GetMethod("TakeTailItemsPatch");
					harmony.Patch((MethodBase)methodInfo, new HarmonyMethod(method), (HarmonyMethod)null, (HarmonyMethod)null, (HarmonyMethod)null, (HarmonyMethod)null);
					break;
				}
			}
			harmony.PatchAll(typeof(Multifunction_modGameLogic));
			harmony.PatchAll(typeof(DysonPatch));
			harmony.PatchAll(typeof(PlayerPatch));
			harmony.PatchAll(typeof(PowerSystemPatch));
			harmony.PatchAll(typeof(PlanetFactoryPatch));
			harmony.PatchAll(typeof(StorageComponentPatch));
			harmony.PatchAll(typeof(StationComponentPatch));
			harmony.PatchAll(typeof(FactorySystemPatch));
			harmony.PatchAll(typeof(CargoTrafficPatch));
			harmony.PatchAll(typeof(SomePatch));
			harmony.PatchAll(typeof(UIPatch));
			harmony.PatchAll(typeof(PlanetTransportPatch));
			harmony.PatchAll(typeof(TankComponentPatch));
			harmony.PatchAll(typeof(SpraycoaterComponentPatch));
			harmony.PatchAll(typeof(CombatPatch));
			harmony.PatchAll(typeof(BuildTool_ClickPatch));
		}

		public static bool TakeTailItemsPatch(StorageComponent __instance, ref int itemId)
		{
			if (Multifunction.ArchitectMode.Value)
			{
				if (itemId <= 0 || itemId >= 6007 || __instance == null || __instance.id != GameMain.mainPlayer.package.id)
				{
					return true;
				}
				if (LDB.items.Select(itemId).CanBuild)
				{
					return false;
				}
			}
			return true;
		}
	}
	public static class MultifunctionTranslate
	{
		private static Dictionary<string, string> TranslateDict = new Dictionary<string, string>();

		public static string getTranslate(this string s)
		{
			return (Multifunction.IsEnglish && TranslateDict.ContainsKey(s) && TranslateDict[s].Length > 0) ? TranslateDict[s] : s;
		}

		public static void regallTranslate()
		{
			TranslateDict.Clear();
			TranslateDict.Add("OP面板", "OP Pannel");
			TranslateDict.Add("人物", "Player");
			TranslateDict.Add("建筑", "Building");
			TranslateDict.Add("星球", "Planet");
			TranslateDict.Add("戴森球", "DysonSphere");
			TranslateDict.Add("其它功能", "Other");
			TranslateDict.Add("机甲物流", "Mechalogistics");
			TranslateDict.Add("防止面板穿透", "ClosePanel");
			TranslateDict.Add("走路速度", "Move speed");
			TranslateDict.Add("研发速度", "Research speed");
			TranslateDict.Add("配送机速度", "Dispenser speed");
			TranslateDict.Add("配送机载量", "Delivery airload");
			TranslateDict.Add("机甲制造MAX", "Mecha makes MAX");
			TranslateDict.Add("机甲采矿MAX", "Mecha mining MAX");
			TranslateDict.Add("背包", "Player Package");
			TranslateDict.Add("加一行", "Add a line");
			TranslateDict.Add("减一行", "Reduce a line");
			TranslateDict.Add("加一列", "Add a column");
			TranslateDict.Add("减一列", "Reduce a column");
			TranslateDict.Add("小飞机速度", "Construction drones flight speed");
			TranslateDict.Add("小飞机任务点数", "Construction drone task count");
			TranslateDict.Add("小飞机数量", "Construction drones");
			TranslateDict.Add("采矿速度", "Mecha mining speed");
			TranslateDict.Add("制造速度", "Mecha produce speed");
			TranslateDict.Add("最大航行速度", "Max sail speed");
			TranslateDict.Add("最大曲速", "Max warp speed");
			TranslateDict.Add("跳跃速度", "Jump speed");
			TranslateDict.Add("建造范围", "Building range");
			TranslateDict.Add("核心功率", "Core Generation");
			TranslateDict.Add("运输机速度", "Logistics drone flight speed");
			TranslateDict.Add("运输船速度", "Logistics vessel navigate speed");
			TranslateDict.Add("运输机载量", "Logistics drone carrying capacity");
			TranslateDict.Add("运输船载量", "Logistics vessel carrying capacity");
			TranslateDict.Add("采矿机速度倍率", "Mining speed");
			TranslateDict.Add("极速分拣器数量", "Sorter cargo stacking");
			TranslateDict.Add("建筑堆叠高度", "Vertical construction");
			TranslateDict.Add("货物集装数量", "Output Cargo Stack Count");
			TranslateDict.Add("小飞机不耗能", "Construction drones no consumption");
			TranslateDict.Add("无需翘曲器曲速飞行", "Mecha don't need space warper");
			TranslateDict.Add("无限物品", "Infinite item");
			TranslateDict.Add("锁定背包", "Lock the package");
			TranslateDict.Add("建筑师模式", "ArchitectMode");
			TranslateDict.Add("无限机甲能量", "Infinite mecha energy");
			TranslateDict.Add("不往背包放东西", "Don't put things in the player's package");
			TranslateDict.Add("建筑秒完成", "Construction completed in seconds");
			TranslateDict.Add("蓝图建造无需材料", "No materials required for blueprint construction");
			TranslateDict.Add("科技点击解锁", "Technology click to unlock");
			TranslateDict.Add("物品列表(Tab)", "ItemList(Tab)");
			TranslateDict.Add("物流背包堆叠倍率", "Delivery Package Stack Size");
			TranslateDict.Add("以下功能需改名", "The following features need to be renamed");
			TranslateDict.Add("无限元数据", "Infinite Property");
			TranslateDict.Add("无限沙土", "Infinite Sand");
			TranslateDict.Add("停止修改", "Stop change value");
			TranslateDict.Add("启动修改", "Start change value");
			TranslateDict.Add("清空背包", "Clear the package");
			TranslateDict.Add("初始化玩家", "Initialize player");
			TranslateDict.Add("增加背包大小", "Add package size");
			TranslateDict.Add("直接获取物品", "InstantItem Mode");
			TranslateDict.Add("减少背包大小", "Reduce package size");
			TranslateDict.Add("解锁全部科技", "Unlock all tech.");
			TranslateDict.Add("回退无穷科技", "Lock all Infinite tech.");
			TranslateDict.Add("初始化太阳帆轨道", "Initialize the solar sail orbit");
			TranslateDict.Add("点击删除下列戴森壳层级", "Click to delete the following Dyson shell layers");
			TranslateDict.Add("注意事项:戴森云和戴森壳不要出现一层轨道都没有的情况(用前存档)", "Note: The Dyson cloud and Dyson shell do not have a layer of orbits (save before use)");
			TranslateDict.Add("建造数量最大值", "Max buildings num");
			TranslateDict.Add("额外存储倍率", "Station storage extra multiply");
			TranslateDict.Add("物流站功能", "Station storage functions");
			TranslateDict.Add("储液站功能", "Storage tank functions");
			TranslateDict.Add("其它建筑功能", "Other building functions");
			TranslateDict.Add("储液站无限增产", "The station increases production indefinitely");
			TranslateDict.Add("建筑抬升", "Building uplift");
			TranslateDict.Add("风力涡轮机覆盖全球", "Wind turbines cover the globe");
			TranslateDict.Add("内置喷涂", "Station Built-in spraying");
			TranslateDict.Add("内置发电", "Built-in power generation");
			TranslateDict.Add("实时更改全部物流站存储倍率", "Real-time changes Station storage max");
			TranslateDict.Add("无限储液站", "Infinite storage tank");
			TranslateDict.Add("星球无限供货机", "Planet infinite item station");
			TranslateDict.Add("要啥有啥", "All stations infinite item");
			TranslateDict.Add("建造无需条件", "Build no conditions");
			TranslateDict.Add("无需赤道造采集器", "Collector no equatorial condition");
			TranslateDict.Add("强行近距离建造物流站", "Station no too close condition");
			TranslateDict.Add("无限翘曲", "Station infinite space warpers");
			TranslateDict.Add("人造恒星无限能源", "Artificial star infinite power");
			TranslateDict.Add("风力涡轮机无限能源", "Wind Turbines Unlimited Energy");
			TranslateDict.Add("极速轨道弹射器(慎用)", "Extremely quick Ejector(Danger)");
			TranslateDict.Add("极速垂直发射井(慎用)", "Extremely quick Silo(Danger");
			TranslateDict.Add("星球电网(人造恒星)", "Plnaet Power(Artificial star)");
			TranslateDict.Add("电力设备", "Electrical equipment");
			TranslateDict.Add("覆盖全球", "Global coverage");
			TranslateDict.Add("超长连接", "Long connection");
			TranslateDict.Add("新建设备不耗电", "New buildings dont't require power");
			TranslateDict.Add("永久满电", "Stations full energy");
			TranslateDict.Add("无限增产", "Station Max proliferator");
			TranslateDict.Add("传送带信号功能", "BeltSignal Function");
			TranslateDict.Add("储液站任意存", "Anything can store in water tank");
			TranslateDict.Add("量子耗能/个", "Quantum comsume energy each");
			TranslateDict.Add("量子传输站", "Quantum Transmission Station");
			TranslateDict.Add("星球级材料供应", "Planet Material supply");
			TranslateDict.Add("星球级物流站材料供应", "Planet Station Material supply");
			TranslateDict.Add("星球级矿机材料供应", "Planet Mining facility Material supply");
			TranslateDict.Add("星球级发射井弹射器材料供应", "Planet Silo and Ejector Material supply");
			TranslateDict.Add("星球级研究站材料供应", "Planet Lab Material supply");
			TranslateDict.Add("星球级电力设备材料供应", "Planet Power facility Material supply");
			TranslateDict.Add("星球级组装机材料供应", "Planet Assmeblers Material supply");
			TranslateDict.Add("星球级翘曲全面供应", "Planet Quantum Transmission Station warper supply");
			TranslateDict.Add("星系级翘曲全面供应", "Star Quantum Transmission Station warper supply");
			TranslateDict.Add("自动改名\"星球量子传输站\"", "auto. change name\"星球量子传输站\"");
			TranslateDict.Add("自动改名\"星系量子传输站\"", "auto. change name\"星系量子传输站\"");
			TranslateDict.Add("星系量子不突破上限", "Star Quantum Transmission Station don't exceed the upper limit");
			TranslateDict.Add("星球量子充电功率", "Planet Quantum Transmission Station max charging power");
			TranslateDict.Add("星系量子充电功率", "Star Quantum Transmission Station max charging power");
			TranslateDict.Add("\"生成矿物\":鼠标左键生成矿物，鼠标右键取消。\"删除矿物\"：按x键进入拆除模式可拆除矿物。", "\"Generate Vein\":left mouse button generate vein，right mouse button cancel.\"delete vein\"：Press the x key to enter the removal mode to delete the vein");
			TranslateDict.Add("生成矿物", "Generate Vein");
			TranslateDict.Add("移动单矿", "Change position of the vein");
			TranslateDict.Add("移动矿堆", "Change position of the veingroup");
			TranslateDict.Add("获取所有矿", "Get all veins and change");
			TranslateDict.Add("删除矿物", "delete vein");
			TranslateDict.Add("还原海洋", "Restore the ocean");
			TranslateDict.Add("整理所有矿", "Organize all mines");
			TranslateDict.Add("切割出", "Cut out");
			TranslateDict.Add("整理为", "Organized as");
			TranslateDict.Add("个", "veins");
			TranslateDict.Add("行", "lines");
			TranslateDict.Add("铺平整个星球", "Pave the whole planet");
			TranslateDict.Add("还原全部海洋", "Restore the whole ocean");
			TranslateDict.Add("铺平整个星球(地基)", "Pave the whole planet(Foundation)");
			TranslateDict.Add("铺平整个星球(自定义颜色)", "Pave the whole planet(Custom color)");
			TranslateDict.Add("掩埋全部矿", "bury all veins");
			TranslateDict.Add("删除全部矿", "delete all veins");
			TranslateDict.Add("添加油井速率", "Add oil interval");
			TranslateDict.Add("添加矿脉数量", "Add vein interval");
			TranslateDict.Add("无穷", "Infinite");
			TranslateDict.Add("生成矿物模式", "Add vein Mode");
			TranslateDict.Add("点按", "Click");
			TranslateDict.Add("按压", "Press");
			TranslateDict.Add("删除当前星球所有建筑", "Dismantle all buildings");
			TranslateDict.Add("删除当前星球所有建筑(不掉落)", "Dismantle all buildings(no drop)");
			TranslateDict.Add("初始化当前星球", "Initialize the current planet");
			TranslateDict.Add("初始化当前星球(不要海洋)", "Initialize the current planet(no ocean)");
			TranslateDict.Add("星球矿机", "Station_miner");
			TranslateDict.Add("自动改名", "auto. change name\"Station_miner\"");
			TranslateDict.Add("星球矿机无消耗", "Station_miner no comsumption veins");
			TranslateDict.Add("采矿速率", "mining speed");
			TranslateDict.Add("垃圾站", "Station_trash");
			TranslateDict.Add("不需要沙土", "no need for soil pile");
			TranslateDict.Add("改变海洋类型", "Change water type");
			TranslateDict.Add("还原所有海洋类型", "Restore all water types");
			TranslateDict.Add("不排列", "Do not arrange");
			TranslateDict.Add("切割矿脉", "Cutting veins");
			TranslateDict.Add("超密铺采集器", "Ultra-dense shop collector");
			TranslateDict.Add("设置当前星球海洋类型", "Sets the current planetary ocean type");
			TranslateDict.Add("恢复所有星球海洋类型", "Restore all planetary ocean types");
			TranslateDict.Add("初始化当前戴森球", "Clear current DysonSphere");
			TranslateDict.Add("瞬间完成戴森球(用前存档)", "Finish DysonSphere(Remember to save)");
			TranslateDict.Add("保存戴森球", "save DysonSphere");
			TranslateDict.Add("打开戴森球蓝图文件夹", "Open DysonSphere Blueprint folder");
			TranslateDict.Add("导入戴森球", "Load DysonSphere");
			TranslateDict.Add("跳过太阳帆吸收阶段", "Skip the solar sail absorption phase");
			TranslateDict.Add("跳过太阳帆子弹阶段", "Skip the solar sail bullet stage");
			TranslateDict.Add("太阳帆帧吸收", "abort solarsail every frame");
			TranslateDict.Add("全球打帆", "Sail anywhere in the planet");
			TranslateDict.Add("间隔发射", "Eject average");
			TranslateDict.Add("开放戴森壳半径上下限(用前存档)", "Open the upper and lower limits of the Dyson shell radius (save before use)");
			TranslateDict.Add("最大半径", "maxOrbitRadius");
			TranslateDict.Add("最小半径", "minOrbitRadius");
			TranslateDict.Add("戴森云和戴森壳至少要有一层，否则会出bug", "Dyson swarm must have at least one orbit.Dyson shell must have al least one layer");
			TranslateDict.Add("丢垃圾速率", "throw trash speed");
			TranslateDict.Add("以下设置需要进入存档", "The follow config need to load game");
			TranslateDict.Add("丢垃圾(整活用)", "throw trash");
			TranslateDict.Add("夜灯", "Sunlight");
			TranslateDict.Add("蓝图强制粘贴", "Enforce to paste blueprint");
			TranslateDict.Add("成就重新检测", "Recheck Achievements");
			TranslateDict.Add("以下设置需要重启游戏", "The follow config need restart the game");
			TranslateDict.Add("设置", "Set");
			TranslateDict.Add("冶炼倍数", "Multiple smelt");
			TranslateDict.Add("堆叠倍率", "Multiple stack");
			TranslateDict.Add("操作范围不受限制", "Inspect no limit");
			TranslateDict.Add("全部手搓", "All item can handcraft");
			TranslateDict.Add("无材料生产", "No material produce");
			TranslateDict.Add("快速生产", "Quick produce");
			TranslateDict.Add("关闭异常提示", "Turn off exception prompts");
			TranslateDict.Add("增产点数上限10", "The maximum number of production increase points is 10");
			TranslateDict.Add("建筑铺设无需条件", "No conditions are required for the laying of the building");
			TranslateDict.Add("关闭所有碰撞体", "Close all colliders");
			TranslateDict.Add("取消所有勾选", "Uncheck all ticks");
			TranslateDict.Add("窗口颜色及透明度", "Window color and alpha");
			TranslateDict.Add("应用", "Confirm");
			TranslateDict.Add("窗口字体颜色", "Window font color");
			TranslateDict.Add("快捷键", "QuickKey");
			TranslateDict.Add("改变窗口快捷键", "Change QuickKey");
			TranslateDict.Add("点击确认", "Click to confirm");
			TranslateDict.Add("储存", "Store");
			TranslateDict.Add("需求", "Need");
			TranslateDict.Add("回收", "Recycle");
			TranslateDict.Add("强化机甲物流", "Strengthen mecha logistics");
			TranslateDict.Add("机甲物流专用星", "Mecha logistics Planet");
			TranslateDict.Add("回收使用储物仓", "Recycle use storage");
			TranslateDict.Add("需求使用储物仓", "Provide use storage");
			TranslateDict.Add("回收使用物流站", "Recycle use station");
			TranslateDict.Add("需求使用物流站", "Provide use station");
		}
	}
}
namespace Multifunction_mod.Utils
{
	public static class NumberUtils
	{
		public static float ConvertToNumber(string input)
		{
			string text = "";
			string text2 = "";
			bool flag = false;
			for (int i = 0; i < input.Length; i++)
			{
				char c = input[i];
				if (char.IsDigit(c))
				{
					text += c;
				}
				else if (c == '.')
				{
					if (!flag)
					{
						flag = true;
						text += c;
					}
				}
				else
				{
					text2 += c;
				}
			}
			input = text2;
			string text3 = input.Replace(text, "").Replace(".", "").Replace("W", "")
				.Replace("J", "");
			if (float.TryParse(text, out var result))
			{
				string text4 = text3;
				string text5 = text4;
				if (text5 == null || text5.Length != 0)
				{
					switch (text5)
					{
					case "K":
						result *= 1000f;
						break;
					case "M":
						result *= 1000000f;
						break;
					case "G":
						result *= 1E+09f;
						break;
					case "T":
						result *= 1E+12f;
						break;
					}
				}
				return result;
			}
			return 0f;
		}

		public static int IntParseLimit(string valueStr, int lowlimit, int highlimit)
		{
			int.TryParse(valueStr, out var result);
			return Math.Max(lowlimit, Math.Min(result, highlimit));
		}

		public static string TGMKinttostring(double num, string unit)
		{
			double num2 = num;
			int num3 = 0;
			if (num < 1000.0)
			{
				return num + unit;
			}
			while (num2 >= 999.9)
			{
				num3++;
				num2 /= 1000.0;
			}
			string text = $"{num2:N2}";
			return num3 switch
			{
				0 => text + unit, 
				1 => text + "K" + unit, 
				2 => text + "M" + unit, 
				3 => text + "G" + unit, 
				4 => text + "T" + unit, 
				_ => "", 
			};
		}
	}
	internal class SplitIncUtil
	{
		public static int split_inc(ref int itemcount, ref int iteminc, int splitcount)
		{
			if (itemcount == 0)
			{
				iteminc = 0;
				return 0;
			}
			int num = iteminc / itemcount;
			int num2 = iteminc - num * itemcount;
			itemcount -= splitcount;
			num2 -= itemcount;
			num = ((num2 > 0) ? (num * splitcount + num2) : (num * splitcount));
			iteminc -= num;
			return num;
		}
	}
}
namespace Multifunction_mod.Patchs
{
	public class BuildTool_ClickPatch
	{
		[HarmonyPrefix]
		[HarmonyPatch(typeof(BuildTool_Click), "CheckBuildConditions")]
		public static bool CheckBuildConditionsPatchPrefix(BuildTool_Click __instance, ref bool __result)
		{
			if (!Multifunction.PasteBuildAnyWay && !Multifunction.build_station_nocondition.Value)
			{
				return true;
			}
			for (int i = 0; i < __instance.buildPreviews.Count; i++)
			{
				PrefabDesc prefabDesc = __instance.buildPreviews[i]?.item?.prefabDesc;
				if (prefabDesc != null && prefabDesc.veinMiner)
				{
					return true;
				}
				if (Multifunction.build_station_nocondition.Value && !Multifunction.PasteBuildAnyWay && !prefabDesc.isStation && !prefabDesc.isStation && !prefabDesc.isCollectStation)
				{
					return true;
				}
			}
			__result = true;
			return false;
		}
	}
	public class CargoTrafficPatch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(CargoTraffic), "SetBeltSignalIcon")]
		public static void SetBeltSignalIconPatch(int signalId, int entityId, CargoTraffic __instance)
		{
			if (Multifunction.BeltSignalFunction.Value)
			{
				int index = __instance.factory.index;
				int beltId = __instance.factory.entityPool[entityId].beltId;
				if (!Multifunction.Beltsignal.ContainsKey(index))
				{
					Multifunction.Beltsignal.Add(index, new Dictionary<int, int>());
				}
				if (!Multifunction.Beltsignal[index].ContainsKey(beltId))
				{
					Multifunction.Beltsignal[index].Add(beltId, signalId);
				}
				else
				{
					Multifunction.Beltsignal[index][beltId] = signalId;
				}
				if (Multifunction.Beltsignalnumberoutput.ContainsKey(index) && Multifunction.Beltsignalnumberoutput[index].ContainsKey(beltId) && signalId != 601)
				{
					Multifunction.Beltsignalnumberoutput[index].Remove(beltId);
				}
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(CargoTraffic), "SetBeltSignalNumber")]
		public static void SetBeltSignalNumberPatch(float number, int entityId, CargoTraffic __instance)
		{
			if (!Multifunction.BeltSignalFunction.Value || __instance.factory.entitySignPool[entityId].iconType == 0 || __instance.factory.entitySignPool[entityId].iconId0 == 0)
			{
				return;
			}
			int index = __instance.factory.index;
			int beltId = __instance.factory.entityPool[entityId].beltId;
			if (__instance.factory.entitySignPool[entityId].iconId0 == 600)
			{
				return;
			}
			if (__instance.factory.entitySignPool[entityId].iconId0 == 601)
			{
				if (!Multifunction.Beltsignalnumberoutput.ContainsKey(index))
				{
					Multifunction.Beltsignalnumberoutput.Add(index, new Dictionary<int, int>());
				}
				if (!Multifunction.Beltsignalnumberoutput[index].ContainsKey(beltId))
				{
					Multifunction.Beltsignalnumberoutput[index].Add(beltId, (int)number);
				}
				else
				{
					Multifunction.Beltsignalnumberoutput[index][beltId] = (int)number;
				}
			}
			else if (Multifunction.Beltsignalnumberoutput.ContainsKey(index) && Multifunction.Beltsignalnumberoutput[index].ContainsKey(beltId))
			{
				Multifunction.Beltsignalnumberoutput[index][beltId] = (int)number;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(CargoTraffic), "TryPickItemAtRear")]
		public static void Prefix(ref int[] needs)
		{
			if (Multifunction.Tankcontentall.Value && needs != null && ItemProto.fluids == needs)
			{
				needs = null;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(CargoTraffic), "RemoveBeltComponent")]
		public static void Prefix(CargoTraffic __instance, int id)
		{
			if (Multifunction.BeltSignalFunction.Value)
			{
				int index = __instance.factory.index;
				if (Multifunction.Beltsignal.ContainsKey(index) && Multifunction.Beltsignal[index].ContainsKey(id))
				{
					Multifunction.Beltsignal[index].Remove(id);
				}
				if (Multifunction.Beltsignalnumberoutput.ContainsKey(index) && Multifunction.Beltsignalnumberoutput[index].ContainsKey(id))
				{
					Multifunction.Beltsignalnumberoutput[index].Remove(id);
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(CargoTraffic), "SplitterGameTick")]
		public static void CargoTrafficSplitterGameTickPatch(CargoTraffic __instance)
		{
			CargoSignalFunction(__instance);
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(GameMain), "FixedUpdate")]
		public static void CargoTrafficGameTickPatch()
		{
			if (!GameMain.isPaused)
			{
				for (int i = 0; i < GameMain.data.factoryCount; i++)
				{
					CargoSignalFunction(GameMain.data.factories[i].cargoTraffic);
				}
			}
		}

		public static void CargoSignalFunction(CargoTraffic __instance)
		{
			if (!Multifunction.BeltSignalFunction.Value || !Multifunction.FinallyInit)
			{
				return;
			}
			int index = __instance.factory.index;
			if (!Multifunction.Beltsignal.ContainsKey(index))
			{
				return;
			}
			FactorySystem factorySystem = __instance.factory.factorySystem;
			foreach (KeyValuePair<int, int> item2 in Multifunction.Beltsignal[index])
			{
				int value = item2.Value;
				if (value == 404)
				{
					__instance.TryPickItem(item2.Key, 0, 0, out var _, out var _);
					continue;
				}
				int cargoId;
				int offset;
				if (1000 <= value && value < 20000)
				{
					int key = item2.Key;
					BeltComponent beltComponent = factorySystem.traffic.beltPool[key];
					int index2 = beltComponent.segIndex + beltComponent.segPivotOffset;
					int num = (int)factorySystem.factory.entitySignPool[factorySystem.traffic.beltPool[key].entityId].count0;
					if (num == 999999)
					{
						__instance.TryInsertItem(key, 0, value, 1, 0);
					}
					else if (num > 999900 && num % 10 != 0)
					{
						int num2 = num % 100;
						int num3 = num2 % 10;
						int num4 = ((num2 / 10 >= 3) ? 4 : (num2 / 10)) * num3;
						__instance.TryInsertItem(key, 0, value, (byte)num3, (byte)num4);
					}
					else if (num >= 11 && num <= 14)
					{
						bool flag = false;
						int num5 = num % 10;
						CargoPath cargoPath = __instance.GetCargoPath(beltComponent.segPathId);
						cargoPath.GetCargoAtIndex(index2, out var cargo, out cargoId, out offset);
						if (cargo.item > 0)
						{
							continue;
						}
						if (factorySystem.factory.transport?.stationPool != null)
						{
							StationComponent[] stationPool = factorySystem.factory.transport.stationPool;
							foreach (StationComponent stationComponent in stationPool)
							{
								if (flag)
								{
									break;
								}
								if (stationComponent == null || stationComponent.storage == null)
								{
									continue;
								}
								for (int j = 0; j < stationComponent.storage.Length; j++)
								{
									if (stationComponent.storage[j].itemId == value)
									{
										if (stationComponent.storage[j].count < num5)
										{
											break;
										}
										int num6 = Math.Min(stationComponent.storage[j].inc, 4 * num5);
										if (cargoPath.TryInsertItem(index2, value, (byte)num5, (byte)num6))
										{
											stationComponent.storage[j].count -= num5;
											stationComponent.storage[j].inc -= num6;
										}
										flag = true;
									}
								}
							}
						}
						if (flag || factorySystem.factory.factoryStorage == null)
						{
							continue;
						}
						StorageComponent[] storagePool = factorySystem.factory.factoryStorage.storagePool;
						if (storagePool != null)
						{
							StorageComponent[] array = storagePool;
							foreach (StorageComponent storageComponent in array)
							{
								if (flag)
								{
									break;
								}
								if (storageComponent != null && !storageComponent.isEmpty && storageComponent.GetItemCount(value) >= num5)
								{
									storageComponent.TakeItem(value, num5, out var inc2);
									if (!cargoPath.TryInsertItem(index2, value, (byte)num5, (byte)inc2))
									{
										storageComponent.AddItem(value, num5, inc2, out offset);
									}
									flag = true;
									break;
								}
							}
						}
						if (flag)
						{
							continue;
						}
						TankComponent[] tankPool = factorySystem.factory.factoryStorage.tankPool;
						if (tankPool == null)
						{
							continue;
						}
						TankComponent[] array2 = tankPool;
						for (int l = 0; l < array2.Length; l++)
						{
							TankComponent tankComponent = array2[l];
							if (flag)
							{
								break;
							}
							if (tankComponent.fluidId == value && tankComponent.id > 0 && tankComponent.fluidCount >= num5)
							{
								int num7 = Math.Min(tankComponent.fluidInc, num5 * 4);
								if (cargoPath.TryInsertItem(index2, value, (byte)num5, (byte)num7))
								{
									factorySystem.factory.factoryStorage.tankPool[tankComponent.id].fluidInc -= num7;
									factorySystem.factory.factoryStorage.tankPool[tankComponent.id].fluidCount -= num5;
								}
								flag = true;
								break;
							}
						}
					}
					else
					{
						if (num < 21 || num > 24 || factorySystem.minerPool == null)
						{
							continue;
						}
						int num8 = num % 20;
						CargoPath cargoPath2 = __instance.GetCargoPath(beltComponent.segPathId);
						cargoPath2.GetCargoAtIndex(index2, out var cargo2, out offset, out cargoId);
						if (cargo2.item > 0)
						{
							continue;
						}
						MinerComponent[] minerPool = factorySystem.minerPool;
						for (int m = 0; m < minerPool.Length; m++)
						{
							MinerComponent minerComponent = minerPool[m];
							if (minerComponent.id > 0 && minerComponent.entityId > 0 && minerComponent.productId == value && minerComponent.productCount >= num8)
							{
								factorySystem.minerPool[minerComponent.id].productCount -= (cargoPath2.TryInsertItem(index2, value, (byte)num8, 0) ? num8 : 0);
								break;
							}
						}
					}
					continue;
				}
				switch (value)
				{
				case 405:
				{
					BeltComponent beltComponent2 = factorySystem.traffic.beltPool[item2.Key];
					CargoPath cargoPath3 = __instance.GetCargoPath(beltComponent2.segPathId);
					int num10 = beltComponent2.segIndex + beltComponent2.segPivotOffset;
					cargoPath3.GetCargoAtIndex(num10, out var cargo3, out cargoId, out offset);
					int item = cargo3.item;
					if (item < 1000)
					{
						break;
					}
					float count = factorySystem.factory.entitySignPool[beltComponent2.entityId].count0;
					float num11 = count;
					byte stack3;
					byte inc4;
					if (num11 != 1f)
					{
						if (num11 != 5f)
						{
							if (num11 != 6f)
							{
								if (num11 != 8f)
								{
									if (num11 == 9f)
									{
									}
								}
								else
								{
									if (factorySystem.labPool == null)
									{
										break;
									}
									bool flag2 = false;
									LabComponent[] labPool = factorySystem.labPool;
									for (int num12 = 0; num12 < labPool.Length; num12++)
									{
										LabComponent labComponent = labPool[num12];
										if (flag2)
										{
											break;
										}
										if (labComponent.id <= 0 || labComponent.entityId <= 0)
										{
											continue;
										}
										if (labComponent.researchMode)
										{
											if (item < 6001 || item > 6006)
											{
												continue;
											}
											for (int num13 = 0; num13 < labComponent.matrixServed.Length; num13++)
											{
												if (item == 6001 + num13 && labComponent.matrixServed[num13] <= 36000)
												{
													if (cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4) == 0)
													{
														return;
													}
													labComponent.matrixServed[num13] += 3600 * stack3;
													labComponent.matrixIncServed[num13] += inc4;
													break;
												}
											}
										}
										else
										{
											if (!labComponent.matrixMode)
											{
												continue;
											}
											for (int num14 = 0; num14 < labComponent.served.Length; num14++)
											{
												if (item == labComponent.recipeExecuteData.requires[num14] && labComponent.served[num14] <= labComponent.recipeExecuteData.requireCounts[num14] * 2)
												{
													if (cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4) == 0)
													{
														return;
													}
													labComponent.served[num14] += stack3;
													labComponent.incServed[num14] += inc4;
													break;
												}
											}
										}
									}
									if (item != 1503 && item != 1501 && item != 1209 && item != 1803 && item != 1804)
									{
										break;
									}
									if (item == 1209 || item == 1803 || item == 1804)
									{
										if (factorySystem.factory.powerSystem == null || factorySystem.factory.powerSystem.genPool == null)
										{
											break;
										}
										PowerGeneratorComponent[] genPool = factorySystem.factory.powerSystem.genPool;
										for (int num15 = 0; num15 < genPool.Length; num15++)
										{
											PowerGeneratorComponent powerGeneratorComponent = genPool[num15];
											if (powerGeneratorComponent.id <= 0)
											{
												continue;
											}
											if (powerGeneratorComponent.gamma)
											{
												if (item == 1209 && powerGeneratorComponent.catalystPoint == 0)
												{
													if (cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4) == 0)
													{
														return;
													}
													factorySystem.factory.powerSystem.genPool[powerGeneratorComponent.id].catalystPoint += 3600 * stack3;
													factorySystem.factory.powerSystem.genPool[powerGeneratorComponent.id].catalystIncPoint += 3600 * inc4;
													flag2 = true;
													break;
												}
											}
											else if (powerGeneratorComponent.fuelMask == 4 && (item == 1803 || item == 1804) && powerGeneratorComponent.fuelCount <= 2 && (item == 1803 || item == 1804))
											{
												if (cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4) == 0)
												{
													return;
												}
												factorySystem.factory.powerSystem.genPool[powerGeneratorComponent.id].SetNewFuel(item, (short)(factorySystem.factory.powerSystem.genPool[powerGeneratorComponent.id].fuelCount + stack3), inc4);
												flag2 = true;
												break;
											}
										}
										break;
									}
									switch (item)
									{
									case 1503:
									{
										if (factorySystem.siloPool == null)
										{
											break;
										}
										SiloComponent[] siloPool = factorySystem.siloPool;
										for (int num17 = 0; num17 < siloPool.Length; num17++)
										{
											SiloComponent siloComponent = siloPool[num17];
											if (siloComponent.id > 0 && siloComponent.entityId > 0 && siloComponent.bulletCount <= 1)
											{
												cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4);
												factorySystem.siloPool[siloComponent.id].bulletCount += stack3;
												factorySystem.siloPool[siloComponent.id].bulletInc += inc4;
												break;
											}
										}
										break;
									}
									case 1501:
									{
										if (factorySystem.ejectorPool == null)
										{
											break;
										}
										EjectorComponent[] ejectorPool = factorySystem.ejectorPool;
										for (int num16 = 0; num16 < ejectorPool.Length; num16++)
										{
											EjectorComponent ejectorComponent = ejectorPool[num16];
											if (ejectorComponent.id > 0 && ejectorComponent.entityId > 0 && ejectorComponent.bulletCount <= 1)
											{
												cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4);
												factorySystem.ejectorPool[ejectorComponent.id].bulletCount += stack3;
												factorySystem.ejectorPool[ejectorComponent.id].bulletInc += inc4;
												break;
											}
										}
										break;
									}
									}
								}
							}
							else
							{
								if (factorySystem.factory.transport == null || factorySystem.factory.transport.stationPool == null)
								{
									break;
								}
								bool flag2 = false;
								StationComponent[] stationPool2 = factorySystem.factory.transport.stationPool;
								foreach (StationComponent stationComponent2 in stationPool2)
								{
									if (stationComponent2 == null || stationComponent2.storage == null)
									{
										continue;
									}
									for (int num19 = 0; num19 < stationComponent2.storage.Length; num19++)
									{
										if (stationComponent2.storage[num19].itemId == item && stationComponent2.storage[num19].count < stationComponent2.storage[num19].max)
										{
											cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4);
											stationComponent2.AddItem(item, stack3, inc4);
											flag2 = true;
											break;
										}
									}
									if (flag2)
									{
										break;
									}
								}
							}
						}
						else
						{
							if (factorySystem.assemblerPool == null)
							{
								break;
							}
							bool flag2 = false;
							AssemblerComponent[] assemblerPool = factorySystem.assemblerPool;
							for (int num20 = 0; num20 < assemblerPool.Length; num20++)
							{
								AssemblerComponent assemblerComponent = assemblerPool[num20];
								if (flag2)
								{
									break;
								}
								if (assemblerComponent.id <= 0 || assemblerComponent.entityId <= 0 || assemblerComponent.recipeId <= 0)
								{
									continue;
								}
								for (int num21 = 0; num21 < assemblerComponent.served.Length; num21++)
								{
									if (item != assemblerComponent.recipeExecuteData.requires[num21])
									{
										continue;
									}
									if (assemblerComponent.served[num21] < 0)
									{
										assemblerComponent.served[num21] = 0;
									}
									else if (assemblerComponent.served[num21] <= assemblerComponent.recipeExecuteData.requireCounts[num21] * 2)
									{
										if (cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4) == 0)
										{
											return;
										}
										assemblerComponent.served[num21] += stack3;
										assemblerComponent.incServed[num21] += inc4;
										flag2 = true;
										break;
									}
								}
							}
						}
					}
					else
					{
						if (item != 1006 && item != 1007 && item != 1011 && item != 1109 && item != 1114 && item != 1120 && item != 1801 && item != 1802)
						{
							break;
						}
						PowerGeneratorComponent[] array3 = factorySystem.factory.powerSystem?.genPool;
						if (array3 == null)
						{
							break;
						}
						PowerGeneratorComponent[] array4 = array3;
						for (int num22 = 0; num22 < array4.Length; num22++)
						{
							PowerGeneratorComponent powerGeneratorComponent2 = array4[num22];
							if (powerGeneratorComponent2.id <= 0 || powerGeneratorComponent2.fuelCount > 2)
							{
								continue;
							}
							if (powerGeneratorComponent2.fuelMask == 1 && item != 1802)
							{
								if (item == array3[powerGeneratorComponent2.id].fuelId)
								{
									cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4);
									array3[powerGeneratorComponent2.id].SetNewFuel(item, (short)(array3[powerGeneratorComponent2.id].fuelCount + stack3), inc4);
									break;
								}
								if (powerGeneratorComponent2.fuelCount == 0)
								{
									cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4);
									array3[powerGeneratorComponent2.id].SetNewFuel(item, (short)(array3[powerGeneratorComponent2.id].fuelCount + stack3), inc4);
									break;
								}
							}
							if (powerGeneratorComponent2.fuelMask == 2 && item == 1802)
							{
								cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4);
								array3[powerGeneratorComponent2.id].SetNewFuel(1802, (short)(array3[powerGeneratorComponent2.id].fuelCount + stack3), inc4);
								break;
							}
						}
					}
					break;
				}
				case 600:
				{
					if (!Multifunction.Beltsignalnumberoutput.ContainsKey(index))
					{
						break;
					}
					int index3 = (int)factorySystem.factory.entitySignPool[factorySystem.traffic.beltPool[item2.Key].entityId].count0;
					int key2 = Multifunction.Beltsignalnumberoutput[index].FirstOrDefault((KeyValuePair<int, int> x) => x.Value == index3).Key;
					if (index3 > 0 && key2 > 0)
					{
						byte stack2;
						byte inc3;
						int num9 = __instance.TryPickItem(item2.Key, 0, 0, out stack2, out inc3);
						if (num9 >= 1000 && !__instance.TryInsertItem(key2, 0, num9, stack2, inc3))
						{
							__instance.TryInsertItem(item2.Key, 0, num9, stack2, inc3);
						}
					}
					break;
				}
				}
			}
		}
	}
	public class CombatPatch
	{
		[HarmonyPrefix]
		[HarmonyPatch(typeof(Mecha), "TakeDamage")]
		public static bool MechaTakeDamage(Mecha __instance)
		{
			if (Multifunction.LockPlayerHp.Value)
			{
				return false;
			}
			return true;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(Mecha), "UpdateCombatStats")]
		public static void MechaTakeUpdateCombatStats(Mecha __instance)
		{
			if (Multifunction.LockPlayerHp.Value)
			{
				__instance.energyShieldEnergy = __instance.energyShieldCapacity;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(ConstructionSystem), "GameTick")]
		public static void PlanetFactoryGameTick(ConstructionSystem __instance)
		{
			if (!Multifunction.LockBuildHp.Value && !Multifunction.LockEnemyHp.Value)
			{
				return;
			}
			CombatStat[] buffer = __instance.factory.skillSystem.combatStats.buffer;
			CombatStat[] array = buffer;
			for (int i = 0; i < array.Length; i++)
			{
				CombatStat combatStat = array[i];
				if (Multifunction.LockBuildHp.Value && combatStat.objectType == 0)
				{
					buffer[combatStat.id].hp = combatStat.hpMax;
				}
				if (Multifunction.LockEnemyHp.Value && combatStat.objectType == 4)
				{
					buffer[combatStat.id].hp = combatStat.hpMax;
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(Mecha), "TickLaserFireCondition")]
		public static void MechaTickLaserFireCondition(Mecha __instance)
		{
			if (Multifunction.PlayerQuickAttack.Value)
			{
				__instance.laserFire = 0;
				__instance.laserEnergy = __instance.laserEnergyCapacity;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(Mecha), "TestLaserTurretEnergy")]
		public static bool MechaTestLaserTurretEnergy(ref bool __result)
		{
			if (Multifunction.PlayerQuickAttack.Value)
			{
				__result = true;
				return false;
			}
			return true;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(SkillSystem), "GameTick")]
		public static void SkillSystemGameTick(SkillSystem __instance)
		{
			if (Multifunction.killEnemys.Count <= 0)
			{
				return;
			}
			EnemyData enemyData = Multifunction.killEnemys.Dequeue();
			if (enemyData.id > 0)
			{
				if (enemyData.combatStatId > 0 && __instance.combatStats.buffer[enemyData.combatStatId].id == enemyData.combatStatId)
				{
					__instance.combatStats.buffer[enemyData.combatStatId].hp = 0;
				}
				else if (enemyData.originAstroId > 1000000)
				{
					ref EnemyData reference = ref __instance.sector.enemyPool[enemyData.id];
					__instance.sector.KillEnemyFinal(reference.id, ref CombatStat.empty);
				}
				else if (enemyData.originAstroId > 100 && enemyData.originAstroId <= 204899 && enemyData.originAstroId % 100 > 0)
				{
					PlanetFactory planetFactory = __instance.astroFactories[enemyData.originAstroId];
					planetFactory.KillEnemyFinally(planetFactory.enemyPool[enemyData.id].id, ref CombatStat.empty);
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(EnemyDFHiveSystem), "GameTickLogic")]
		public static void EnemyDFHiveSystemPreGameTickLogic(EnemyDFHiveSystem __instance)
		{
			if (Multifunction.SpaceAlwaysClearThreat.Value)
			{
				__instance.evolve.threat = 0;
				__instance.evolve.threatshr = 0;
			}
			if (Multifunction.SpaceAlwaysMaxThreat.Value && __instance.evolve.threat < __instance.evolve.maxThreat && __instance.evolve.waveTicks == 0 && GameMain.localStar != null && __instance.starData.index == GameMain.localStar.index)
			{
				__instance.evolve.threat = __instance.evolve.maxThreat * 2 + 1;
				__instance.evolve.threatshr = __instance.evolve.maxThreat * 2 + 1;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(EnemyDFHiveSystem), "GameTickLogic")]
		public static void EnemyDFHiveSystemGameTickLogic(EnemyDFHiveSystem __instance)
		{
			if (Multifunction.SpaceAlwaysClearThreat.Value)
			{
				__instance.evolve.threat = 0;
				__instance.evolve.threatshr = 0;
			}
			if (Multifunction.SpaceAlwaysMaxThreat.Value && __instance.evolve.threat < __instance.evolve.maxThreat && __instance.evolve.waveTicks == 0 && GameMain.localStar != null && __instance.starData.index == GameMain.localStar.index)
			{
				__instance.evolve.threat = __instance.evolve.maxThreat * 2 + 1;
				__instance.evolve.threatshr = __instance.evolve.maxThreat * 2 + 1;
			}
			if (Multifunction.PlayerFakeDeath.Value && __instance.isLocal)
			{
				__instance.local_player_exist_alive = false;
				__instance.local_player_in_range = false;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(DFGBaseComponent), "UpdateFactoryThreat")]
		public static void DFGBaseComponentPreLogicTick(DFGBaseComponent __instance, ref float power_threat_factor, ref float player_threat)
		{
			if (Multifunction.LocalAlwaysClearThreat.Value)
			{
				power_threat_factor = 0f;
				player_threat = 0f;
				__instance.evolve.threat = 0;
				__instance.evolve.threatshr = 0;
			}
			if (Multifunction.LocalAlwaysMaxThreat.Value && __instance.evolve.threat < __instance.evolve.maxThreat && __instance.evolve.waveTicks == 0 && GameMain.localPlanet != null && __instance.groundSystem.factory.planet.index == GameMain.localPlanet.index)
			{
				__instance.evolve.threat = __instance.evolve.maxThreat * 2 + 1;
				__instance.evolve.threatshr = __instance.evolve.maxThreat * 2 + 1;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DFGBaseComponent), "UpdateFactoryThreat")]
		public static void DFGBaseComponentLogicTick(DFGBaseComponent __instance, ref float power_threat_factor, ref float player_threat)
		{
			if (Multifunction.LocalAlwaysClearThreat.Value)
			{
				power_threat_factor = 0f;
				player_threat = 0f;
				__instance.evolve.threat = 0;
				__instance.evolve.threatshr = 0;
			}
			if (Multifunction.LocalAlwaysMaxThreat.Value && __instance.evolve.threat < __instance.evolve.maxThreat && __instance.evolve.waveTicks == 0 && GameMain.localPlanet != null && __instance.groundSystem.factory.planet.index == GameMain.localPlanet.index)
			{
				__instance.evolve.threat = __instance.evolve.maxThreat * 2 + 1;
				__instance.evolve.threatshr = __instance.evolve.maxThreat * 2 + 1;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(EnemyBuilderComponent), "LogicTick")]
		public static void EnemyBuilderComponentBuildLogic_Ground(EnemyBuilderComponent __instance)
		{
			if (Multifunction.DarkFogBuilderQuickBuild.Value)
			{
				__instance.energy = __instance.maxEnergy;
				__instance.matter = __instance.maxMatter;
				__instance.sp = __instance.spMax;
				__instance.buildCDTime = 0;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(TurretComponent), "InternalUpdate")]
		public static void TurretComponentInternalUpdate(ref TurretComponent __instance)
		{
			if (Multifunction.TurrentKeepSuperNoval.Value)
			{
				__instance.supernovaTick = 901;
				__instance.supernovaStrength = 30f;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(HatredList), "HateTarget", new Type[]
		{
			typeof(ETargetType),
			typeof(int),
			typeof(int),
			typeof(int),
			typeof(EHatredOperation)
		})]
		public static bool HatredListHateTarget(ETargetType type)
		{
			if (Multifunction.PlayerFakeDeath.Value && type == ETargetType.Player)
			{
				return false;
			}
			return true;
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(EnemyDFGroundSystem), "GameTickLogic_Prepare")]
		public static void EnemyDFGroundSystemGameTickLogic(EnemyDFGroundSystem __instance)
		{
			if (Multifunction.PlayerFakeDeath.Value && __instance.isLocalLoaded)
			{
				__instance.local_player_exist_alive = false;
			}
		}
	}
	public class DriftBuildingsPatch
	{
		public static bool IsPatched;

		[HarmonyPrefix]
		[HarmonyPatch(typeof(BuildTool_Click), "UpdatePreviewModels")]
		public static void Prefix(ref BuildTool_Click __instance)
		{
			if (Multifunction.DriftBuildings)
			{
				for (int i = 0; i < __instance.buildPreviews.Count; i++)
				{
					BuildPreview buildPreview = __instance.buildPreviews[i];
					buildPreview.lpos *= Multifunction.DriftBuildingHeight;
					buildPreview.lpos2 *= Multifunction.DriftBuildingHeight;
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "CreatePrebuilds")]
		public static void BuildTool_BlueprintPasteCreatePrebuildsPatch(ref BuildTool_BlueprintPaste __instance)
		{
			if (!Multifunction.DriftBuildings)
			{
				return;
			}
			for (int i = 0; i < __instance.bpCursor; i++)
			{
				BuildPreview buildPreview = __instance.bpPool[i];
				if (buildPreview.desc.isBelt)
				{
					buildPreview.lpos *= Multifunction.DriftBuildingHeight;
					buildPreview.lpos2 *= Multifunction.DriftBuildingHeight;
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "UpdatePreviewModels")]
		public static void BuildTool_BlueprintPastePrefix(ref BuildTool_BlueprintPaste __instance)
		{
			if (!Multifunction.DriftBuildings)
			{
				return;
			}
			for (int i = 0; i < __instance.bpCursor; i++)
			{
				BuildPreview buildPreview = __instance.bpPool[i];
				if (buildPreview.desc.isBelt)
				{
					buildPreview.lpos *= Multifunction.DriftBuildingHeight;
					buildPreview.lpos2 *= Multifunction.DriftBuildingHeight;
				}
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "UpdatePreviewModels")]
		public static void BuildTool_BlueprintPastePostfix(ref BuildTool_BlueprintPaste __instance)
		{
			if (!Multifunction.DriftBuildings)
			{
				return;
			}
			for (int i = 0; i < __instance.bpCursor; i++)
			{
				BuildPreview buildPreview = __instance.bpPool[i];
				if (buildPreview.desc.isBelt)
				{
					buildPreview.lpos /= Multifunction.DriftBuildingHeight;
					buildPreview.lpos2 /= Multifunction.DriftBuildingHeight;
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "AlterBPGPUIModel")]
		public static void BuildTool_BlueprintPasteAlterBPGPUIModelPatch(ref BuildPreview _bp)
		{
			if (Multifunction.DriftBuildings)
			{
				_bp.lpos *= Multifunction.DriftBuildingHeight;
				_bp.lpos2 *= Multifunction.DriftBuildingHeight;
			}
		}
	}
	public class DysonPatch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonSphere), "Init")]
		public static void DysonSphereInit(ref DysonSphere __instance)
		{
			if (Multifunction.ChangeDysonradius.Value)
			{
				__instance.minOrbitRadius = 100f;
				__instance.maxOrbitRadius = Multifunction.MaxOrbitRadiusConfig.Value;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(DysonSphereLayer), "GameTick")]
		public static void DysonSphereLayerGameTick(ref DysonSphereLayer __instance, long gameTick)
		{
			if (!Multifunction.QuickabortSwarm.Value)
			{
				return;
			}
			int num = (int)(gameTick % 120);
			for (int i = 1; i < __instance.nodeCursor; i++)
			{
				DysonNode dysonNode = __instance.nodePool[i];
				if (dysonNode != null && dysonNode.id == i && dysonNode.id % 120 == num && dysonNode.sp == dysonNode.spMax)
				{
					for (int j = 1; j <= Multifunction.Solarsailsabsorbeveryframe.Value; j++)
					{
						dysonNode.OrderConstructCp(gameTick, __instance.dysonSphere.swarm);
					}
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(DysonSwarm), "AbsorbSail")]
		public static bool DysonSwarmPatch1(ref DysonSwarm __instance, ref bool __result, DysonNode node)
		{
			if (!Multifunction.quickabsorbsolar.Value)
			{
				return true;
			}
			if (__instance.expiryCursor == __instance.expiryEnding)
			{
				__result = false;
				return false;
			}
			__instance.expiryEnding--;
			if (__instance.expiryEnding < 0)
			{
				__instance.expiryEnding += __instance.sailCapacity;
			}
			int expiryEnding = __instance.expiryEnding;
			int index = __instance.expiryOrder[expiryEnding].index;
			if (__instance.expiryOrder[expiryEnding].time == 0)
			{
				Assert.CannotBeReached();
				__result = false;
				return false;
			}
			__instance.expiryOrder[expiryEnding].time = 0L;
			__instance.expiryOrder[expiryEnding].index = 0;
			if (node != null && node.ConstructCp() != null)
			{
				__instance.dysonSphere.productRegister[11903]++;
			}
			__instance.RemoveSolarSail(index);
			return false;
		}
	}
	public class EjectAnywayPatch
	{
		private static Harmony _patch;

		private static bool enable;

		public static string Patchid => "cn.blacksnipe.dsp.Multfuntion_mod.EjectAnywayPatch";

		public static bool Enable
		{
			get
			{
				return enable;
			}
			set
			{
				if (enable != value)
				{
					enable = value;
					if (enable)
					{
						_patch = Harmony.CreateAndPatchAll(typeof(EjectAnywayPatch), Patchid);
					}
					else
					{
						_patch.UnpatchSelf();
					}
				}
			}
		}

		[HarmonyTranspiler]
		[HarmonyPriority(0)]
		[HarmonyPatch(typeof(EjectorComponent), "InternalUpdate")]
		private static IEnumerable<CodeInstruction> EjectorComponent_InternalUpdate_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0009: Expected O, but got Unknown
			//IL_0024: Unknown result type (might be due to invalid IL or missing references)
			//IL_002a: Expected O, but got Unknown
			//IL_004b: Unknown result type (might be due to invalid IL or missing references)
			//IL_0051: Expected O, but got Unknown
			//IL_0064: Unknown result type (might be due to invalid IL or missing references)
			//IL_006a: Expected O, but got Unknown
			//IL_0072: Unknown result type (might be due to invalid IL or missing references)
			//IL_0078: Expected O, but got Unknown
			//IL_0093: Unknown result type (might be due to invalid IL or missing references)
			//IL_0099: Expected O, but got Unknown
			//IL_00a1: Unknown result type (might be due to invalid IL or missing references)
			//IL_00a7: Expected O, but got Unknown
			//IL_00af: Unknown result type (might be due to invalid IL or missing references)
			//IL_00b5: Expected O, but got Unknown
			CodeMatcher val = new CodeMatcher(instructions, generator);
			val.End().MatchBack(true, (CodeMatch[])(object)new CodeMatch[2]
			{
				new CodeMatch((OpCode?)OpCodes.Ldarg_0, (object)null, (string)null),
				new CodeMatch((OpCode?)OpCodes.Ldfld, (object)AccessTools.Field(typeof(EjectorComponent), "autoOrbit"), (string)null)
			}).Insert((CodeInstruction[])(object)new CodeInstruction[5]
			{
				new CodeInstruction(OpCodes.Ldarg_0, (object)null),
				new CodeInstruction(OpCodes.Ldc_I4_1, (object)null),
				new CodeInstruction(OpCodes.Stfld, (object)AccessTools.Field(typeof(EjectorComponent), "targetState")),
				new CodeInstruction(OpCodes.Ldc_I4_1, (object)null),
				new CodeInstruction(OpCodes.Stloc_3, (object)null)
			});
			return val.InstructionEnumeration();
		}
	}
	public struct Tempsail
	{
		public DysonSail ss;

		public int orbitid;

		public long time;

		public void FromData(in VectorLF3 delta1, in VectorLF3 delta2, int orbitId)
		{
			ss.px = (float)delta1.x;
			ss.py = (float)delta1.y;
			ss.pz = (float)delta1.z;
			ss.vx = (float)delta2.x;
			ss.vy = (float)delta2.y;
			ss.vz = (float)delta2.z;
			ss.gs = 1f;
			orbitid = orbitId;
			time = (long)(GameMain.history.solarSailLife * 60f + 0.1f);
		}
	}
	public class SkipBulletPatch
	{
		private static long _sailLifeTime;

		private static Tempsail[][] _sailsCache;

		private static int[] _sailsCacheLen;

		private static int[] _sailsCacheCapacity;

		private static Harmony _patch;

		private static bool enable;

		public static string Patchid => "cn.blacksnipe.dsp.Multfuntion_mod.SkipBulletPatch";

		public static bool Enable
		{
			get
			{
				return enable;
			}
			set
			{
				if (enable == value)
				{
					return;
				}
				enable = value;
				Init();
				if (enable)
				{
					_patch = Harmony.CreateAndPatchAll(typeof(SkipBulletPatch), Patchid);
					Multifunction_modGameLogic.OnGameBegin = (Action)Delegate.Combine(Multifunction_modGameLogic.OnGameBegin, new Action(GameMain_Begin_Postfix));
					UpdateSailLifeTime();
					return;
				}
				Harmony patch = _patch;
				if (patch != null)
				{
					patch.UnpatchSelf();
				}
				Multifunction_modGameLogic.OnGameBegin = (Action)Delegate.Remove(Multifunction_modGameLogic.OnGameBegin, new Action(GameMain_Begin_Postfix));
			}
		}

		public static bool CheckPatched()
		{
			Patches patchInfo = Harmony.GetPatchInfo((MethodBase)typeof(EjectorComponent).GetMethod("InternalUpdate"));
			return patchInfo.Transpilers.Count > 0;
		}

		private static void GameMain_Begin_Postfix()
		{
			Init();
		}

		private static void UpdateSailLifeTime()
		{
			if (GameMain.history != null)
			{
				_sailLifeTime = (long)(GameMain.history.solarSailLife * 60f + 0.1f);
			}
		}

		public static void Init()
		{
			GalaxyData galaxyData = GameMain.data?.galaxy;
			if (galaxyData != null)
			{
				int starCount = GameMain.data.galaxy.starCount;
				_sailsCache = new Tempsail[starCount][];
				_sailsCacheLen = new int[starCount];
				_sailsCacheCapacity = new int[starCount];
				Array.Clear(_sailsCacheLen, 0, starCount);
				Array.Clear(_sailsCacheCapacity, 0, starCount);
				UpdateSailLifeTime();
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(GameHistoryData), "UnlockTechFunction")]
		private static void GameHistoryData_SetForNewGame_Postfix(int func)
		{
			if (func == 12)
			{
				UpdateSailLifeTime();
			}
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(EjectorComponent), "InternalUpdate")]
		private static IEnumerable<CodeInstruction> EjectorComponent_InternalUpdate_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0009: Expected O, but got Unknown
			//IL_002f: Unknown result type (might be due to invalid IL or missing references)
			//IL_0035: Expected O, but got Unknown
			//IL_0043: Unknown result type (might be due to invalid IL or missing references)
			//IL_0049: Expected O, but got Unknown
			//IL_0062: Unknown result type (might be due to invalid IL or missing references)
			//IL_0068: Expected O, but got Unknown
			//IL_0083: Unknown result type (might be due to invalid IL or missing references)
			//IL_0089: Expected O, but got Unknown
			//IL_0096: Unknown result type (might be due to invalid IL or missing references)
			//IL_009c: Expected O, but got Unknown
			//IL_00b6: Unknown result type (might be due to invalid IL or missing references)
			//IL_00bc: Expected O, but got Unknown
			//IL_00cf: Unknown result type (might be due to invalid IL or missing references)
			//IL_00e7: Expected O, but got Unknown
			//IL_00f0: Unknown result type (might be due to invalid IL or missing references)
			//IL_00f6: Expected O, but got Unknown
			//IL_00fe: Unknown result type (might be due to invalid IL or missing references)
			//IL_0104: Expected O, but got Unknown
			//IL_010c: Unknown result type (might be due to invalid IL or missing references)
			//IL_0112: Expected O, but got Unknown
			//IL_012d: Unknown result type (might be due to invalid IL or missing references)
			//IL_0133: Expected O, but got Unknown
			//IL_0141: Unknown result type (might be due to invalid IL or missing references)
			//IL_0147: Expected O, but got Unknown
			//IL_0155: Unknown result type (might be due to invalid IL or missing references)
			//IL_015b: Expected O, but got Unknown
			//IL_0178: Unknown result type (might be due to invalid IL or missing references)
			//IL_017e: Expected O, but got Unknown
			CodeMatcher val = new CodeMatcher(instructions, generator);
			Label label = generator.DefineLabel();
			val.MatchForward(true, (CodeMatch[])(object)new CodeMatch[2]
			{
				new CodeMatch((OpCode?)OpCodes.Ldc_R4, (object)10f, (string)null),
				new CodeMatch((OpCode?)OpCodes.Stfld, (object)null, (string)null)
			}).Advance(1).Insert((CodeInstruction[])(object)new CodeInstruction[3]
			{
				new CodeInstruction(OpCodes.Ldarg_0, (object)null),
				new CodeInstruction(OpCodes.Ldfld, (object)AccessTools.Field(typeof(EjectorComponent), "fired")),
				new CodeInstruction(OpCodes.Brtrue, (object)label)
			})
				.MatchForward(true, (CodeMatch[])(object)new CodeMatch[1]
				{
					new CodeMatch((OpCode?)OpCodes.Pop, (object)null, (string)null)
				})
				.Insert((CodeInstruction[])(object)new CodeInstruction[8]
				{
					CodeInstructionExtensions.WithLabels(new CodeInstruction(OpCodes.Nop, (object)null), new Label[1] { label }),
					new CodeInstruction(OpCodes.Ldarg_3, (object)null),
					new CodeInstruction(OpCodes.Ldarg_3, (object)null),
					new CodeInstruction(OpCodes.Ldarg_0, (object)null),
					new CodeInstruction(OpCodes.Ldfld, (object)AccessTools.Field(typeof(EjectorComponent), "orbitId")),
					new CodeInstruction(OpCodes.Ldloc_S, (object)9),
					new CodeInstruction(OpCodes.Ldloc_S, (object)11),
					new CodeInstruction(OpCodes.Call, (object)AccessTools.Method(typeof(SkipBulletPatch), "AddDysonSail", (Type[])null, (Type[])null))
				});
			return val.InstructionEnumeration();
		}

		private static void AddDysonSail(DysonSwarm swarm, int orbitId, VectorLF3 uPos, VectorLF3 endVec)
		{
			int index = swarm.starData.index;
			VectorLF3 delta = endVec - swarm.starData.uPosition;
			VectorLF3 delta2 = VectorLF3.Cross(endVec - uPos, swarm.orbits[orbitId].up).normalized * Math.Sqrt(swarm.dysonSphere.gravity / swarm.orbits[orbitId].radius);
			lock (swarm)
			{
				Tempsail[] array = _sailsCache[index];
				int num = _sailsCacheLen[index];
				if (array == null)
				{
					SetSailsCacheCapacity(index, 256);
					array = _sailsCache[index];
				}
				else
				{
					int num2 = _sailsCacheCapacity[index];
					if (num >= num2)
					{
						SetSailsCacheCapacity(index, num2 * 2);
						array = _sailsCache[index];
					}
				}
				_sailsCacheLen[index] = num + 1;
				array[num].time = _sailLifeTime;
				array[num].FromData(in delta, in delta2, orbitId);
			}
		}

		private static void SetSailsCacheCapacity(int index, int capacity)
		{
			Tempsail[] array = new Tempsail[capacity];
			int num = _sailsCacheLen[index];
			if (num > 0)
			{
				Array.Copy(_sailsCache[index], array, num);
			}
			_sailsCache[index] = array;
			_sailsCacheCapacity[index] = capacity;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(DysonSwarm), "GameTick")]
		public static void DysonSwarmPatch(ref DysonSwarm __instance, long time)
		{
			if (__instance.starData == null || _sailsCacheLen == null)
			{
				return;
			}
			int index = __instance.starData.index;
			if (_sailsCacheLen[index] != 0)
			{
				for (int num = _sailsCacheLen[index] - 1; num >= 0; num--)
				{
					Tempsail tempsail = _sailsCache[index][num];
					__instance.AddSolarSail(tempsail.ss, tempsail.orbitid, tempsail.time + time);
				}
				_sailsCacheLen[index] = 0;
			}
		}
	}
	public class FactorySystemPatch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(FactorySystem), "NewEjectorComponent")]
		public static void NewEjectorComponentPatch(ref int __result, FactorySystem __instance)
		{
			if (Multifunction.quickEjector)
			{
				__instance.ejectorPool[__result].bulletCount = int.MaxValue;
				__instance.ejectorPool[__result].bulletId = 1501;
				__instance.ejectorPool[__result].coldSpend = 5;
				__instance.ejectorPool[__result].chargeSpend = 4;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(FactorySystem), "NewSiloComponent")]
		public static void NewSiloComponentPatch(ref int __result, FactorySystem __instance)
		{
			if (Multifunction.quicksilo)
			{
				__instance.siloPool[__result].bulletCount = int.MaxValue;
				__instance.siloPool[__result].bulletId = 1503;
				__instance.siloPool[__result].coldSpend = 40;
				__instance.siloPool[__result].chargeSpend = 80;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(FactoryStorage), "NewTankComponent")]
		public static void NewTankComponentPatch(ref int fCount)
		{
			if (Multifunction.Infinitestoragetank.Value)
			{
				fCount = 2147483447;
			}
		}
	}
	internal class Multifunction_modGameLogic
	{
		public static Action OnDataLoaded;

		public static Action OnGameBegin;

		public static Action OnGameEnd;

		[HarmonyPostfix]
		[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
		public static void VFPreload_InvokeOnLoadWorkEnded_Postfix()
		{
			OnDataLoaded?.Invoke();
		}

		[HarmonyPostfix]
		[HarmonyPriority(800)]
		[HarmonyPatch(typeof(GameMain), "Begin")]
		public static void GameMain_Begin_Postfix()
		{
			OnGameBegin?.Invoke();
		}

		[HarmonyPostfix]
		[HarmonyPriority(0)]
		[HarmonyPatch(typeof(GameMain), "End")]
		public static void GameMain_End_Postfix()
		{
			OnGameEnd?.Invoke();
		}
	}
	public class PasteAnywayPatch
	{
		public static bool IsPatched { get; internal set; }

		[HarmonyPrefix]
		[HarmonyPatch(typeof(BuildTool_Inserter), "CheckBuildConditions")]
		public static bool BuildTool_InserterCheckBuildConditionsPatch(ref bool __result)
		{
			if (Multifunction.PasteBuildAnyWay)
			{
				__result = true;
				return false;
			}
			return true;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(BuildTool_Addon), "CheckBuildConditions")]
		public static bool BuildTool_AddonCheckBuildConditionsPatch(ref bool __result)
		{
			if (Multifunction.PasteBuildAnyWay)
			{
				__result = true;
				return false;
			}
			return true;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(BuildTool_Path), "CheckBuildConditions")]
		public static bool BuildTool_PathCheckBuildConditionsPatch(ref bool __result, BuildTool_Path __instance)
		{
			if (Multifunction.PasteBuildAnyWay)
			{
				int count = __instance.buildPreviews.Count;
				float num = __instance.altitude;
				float num2 = __instance.altitude;
				float tilt = __instance.tilt;
				float tilt2 = __instance.tilt;
				if (count > 0)
				{
					num = (__instance.buildPreviews[0].lpos.magnitude - __instance.planet.realRadius - 0.2f) / 1.3333333f;
					num2 = (__instance.buildPreviews[count - 1].lpos.magnitude - __instance.planet.realRadius - 0.2f) / 1.3333333f;
					num = Mathf.Round(num * 100f) / 100f;
					num2 = Mathf.Round(num2 * 100f) / 100f;
					if ((double)num < 0.041)
					{
						num = 0f;
					}
					if ((double)num2 < 0.041)
					{
						num2 = 0f;
					}
					tilt = __instance.buildPreviews[0].tilt;
					tilt2 = __instance.buildPreviews[count - 1].tilt;
				}
				if (num > 0f || num2 > 0f || tilt != 0f || tilt2 != 0f)
				{
					BuildModel model = __instance.actionBuild.model;
					model.cursorText += "<size=12>";
					if (num > 0f || num2 > 0f)
					{
						string arg = ((num != num2) ? $"{num:0.##}\u2006～\u2006{num2:0.##}" : $"{num:0.##}");
						BuildModel model2 = __instance.actionBuild.model;
						model2.cursorText += string.Format("传送带高度提示".Translate(), arg);
					}
					if (tilt != 0f || tilt2 != 0f)
					{
						string arg2 = ((tilt != tilt2) ? $"{0f - tilt:+0.#;-0.#;0}\u2006～\u2006{0f - tilt2:+0.#;-0.#;0}" : $"{0f - tilt:+0.#;-0.#;0}°");
						BuildModel model3 = __instance.actionBuild.model;
						model3.cursorText += string.Format("传送带倾斜提示".Translate(), arg2);
					}
					BuildModel model4 = __instance.actionBuild.model;
					model4.cursorText += "</size>";
				}
				__result = true;
				return false;
			}
			return true;
		}
	}
	public class PlanetFactoryPatch
	{
		private static void RemoveVegeAndCollect(PlanetFactory factory, int id)
		{
			int proto = id > 0 && id < factory.vegePool.Length && factory.vegePool[id].id == id ? factory.vegePool[id].protoId : 0;
			var collection = factory.gameData.mainPlayer?.vegetableCollection;
			int before = 0;
			if (collection != null) collection.playerVegeDict.TryGetValue(proto, out before);
			factory.RemoveVegeWithComponents(id);
			int after = 0;
			if (collection != null) collection.playerVegeDict.TryGetValue(proto, out after);
			if (proto > 0 && collection != null && factory.vegePool[id].id == 0 && before == after) collection.AddVegeToPlayer(proto);
		}

		[HarmonyTranspiler, HarmonyPatch(typeof(PlanetFactory), "PlanetReformAll")]
		private static IEnumerable<CodeInstruction> BulkReformCollection(IEnumerable<CodeInstruction> instructions)
		{
			var codes = new List<CodeInstruction>(instructions);
			var original = AccessTools.Method(typeof(PlanetFactory), "RemoveVegeWithComponents");
			int count = 0;
			foreach (var code in codes)
				if (code.Calls(original)) { code.opcode = OpCodes.Call; code.operand = AccessTools.Method(typeof(PlanetFactoryPatch), "RemoveVegeAndCollect"); count++; }
			if (count != 1) throw new InvalidOperationException("Native bulk vegetation removal changed: " + count);
			return codes;
		}
		[HarmonyPostfix]
		[HarmonyPatch(typeof(PlanetFactory), "ComputeFlattenTerrainReform")]
		public static void PlanetFactoryNoComsumeSand(ref int costSandCount)
		{
			if (Multifunction.InfiniteSand.Value)
			{
				if (GameMain.mainPlayer != null && GameMain.mainPlayer.sandCount < int.MaxValue)
				{
					GameMain.mainPlayer.SetSandCount(2147483647L, ESandSource.Other);
				}
				costSandCount = 0;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(PlanetFactory), "UpgradeEntityWithComponents")]
		public static void UpgradeEntityWithComponentsPatch(int entityId, PlanetFactory __instance)
		{
			if (Multifunction.Buildingnoconsume.Value && entityId != 0 && __instance.entityPool[entityId].id != 0 && GameMain.localPlanet.factory.entityPool[entityId].stationId <= 0)
			{
				int powerConId = __instance.entityPool[entityId].powerConId;
				if (powerConId > 0)
				{
					__instance.powerSystem.consumerPool[powerConId].idleEnergyPerTick = 0L;
					__instance.powerSystem.consumerPool[powerConId].workEnergyPerTick = 0L;
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(PlanetFactory), "TakeBackItemsInEntity")]
		public static bool TakeBackItemsInEntityPatch()
		{
			return !Multifunction.entityitemnoneed;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(PlanetFactory), "CreateEntityLogicComponents")]
		public static void CreateEntityLogicComponentsPatch(PlanetFactory __instance, int entityId, PrefabDesc desc, int prebuildId)
		{
			if (desc.isStation && !string.IsNullOrEmpty(Multifunction.AutoChangeStationName.Value))
			{
				__instance.WriteExtraInfoOnPrebuild(prebuildId, Multifunction.AutoChangeStationName.Value.getTranslate());
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(ConstructionSystem), "GameTick")]
		public static void ConstructionSystemGameTick(ConstructionSystem __instance)
		{
			if (!Multifunction.BuildNotime_bool.Value)
			{
				return;
			}
			PlanetFactory planetFactory = Multifunction.player?.factory;
			if (GameMain.localPlanet == null || planetFactory == null)
			{
				return;
			}
			PrebuildData[] prebuildPool = planetFactory.prebuildPool;
			if (planetFactory.prebuildCount <= 0)
			{
				return;
			}
			int num = 0;
			PlanetFactory.batchBuild = true;
			HighStopwatch highStopwatch = new HighStopwatch();
			highStopwatch.Begin();
			planetFactory.BeginFlattenTerrain();
			for (int num2 = planetFactory.prebuildCursor - 1; num2 > 0; num2--)
			{
				if ((prebuildPool[num2].itemRequired <= 0 || Multifunction.Infinitething.Value || Multifunction.ArchitectMode.Value) && prebuildPool[num2].id == num2 && !prebuildPool[num2].isDestroyed)
				{
					planetFactory.BuildFinally(GameMain.mainPlayer, prebuildPool[num2].id, autoRefresh: false);
					num++;
				}
			}
			planetFactory.EndFlattenTerrain();
			PlanetFactory.batchBuild = false;
			if (num > 0)
			{
				GameMain.localPlanet.physics?.raycastLogic?.NotifyBatchObjectRemove();
				GameMain.localPlanet.audio?.SetPlanetAudioDirty();
			}
		}
	}
	public class PlanetTransportPatch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(PlanetTransport), "NewStationComponent")]
		public static void PlanetTransportNewStationComponent(ref StationComponent __result, PlanetTransport __instance, int _entityId)
		{
			if (__result.isCollector)
			{
				Multifunction.CollectorStation.Add(__result.gid);
			}
			else if (!__result.isVeinCollector)
			{
				if (!string.IsNullOrEmpty(Multifunction.AutoChangeStationName.Value))
				{
					__instance.factory.WriteExtraInfoOnEntity(_entityId, Multifunction.AutoChangeStationName.Value.getTranslate());
				}
				if (Multifunction.Buildingnoconsume.Value)
				{
					GameMain.localPlanet.factory.powerSystem.consumerPool[__result.pcId].idleEnergyPerTick = 1000L;
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(PlanetTransport), "RemoveStationComponent")]
		public static void PlanetTransportRemoveStationComponent(PlanetTransport __instance, int id)
		{
			if (__instance.stationPool[id] != null && __instance.stationPool[id].id != 0 && __instance.stationPool[id].isCollector)
			{
				int gid = __instance.stationPool[id].gid;
				if (Multifunction.CollectorStation.Contains(gid))
				{
					Multifunction.CollectorStation.Remove(gid);
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(PlanetTransport), "SetStationStorage")]
		public static bool UIStationWindow_SetStationStorage(PlanetTransport __instance, int stationId, int storageIdx, int itemId, int itemCountMax, ELogisticStorage localLogic, ELogisticStorage remoteLogic, Player player)
		{
			if (Multifunction.StationStoExtra.Value <= 0)
			{
				return true;
			}
			if (itemId != 0 && LDB.items.Select(itemId) == null)
			{
				itemId = 0;
			}
			StationComponent stationComponent = __instance.GetStationComponent(stationId);
			bool flag = false;
			bool flag2 = false;
			if (stationComponent != null)
			{
				if (!stationComponent.isStellar)
				{
					remoteLogic = ELogisticStorage.None;
				}
				if (itemId <= 0)
				{
					itemId = 0;
					itemCountMax = 0;
					localLogic = ELogisticStorage.None;
					remoteLogic = ELogisticStorage.None;
				}
				int modelIndex = __instance.factory.entityPool[stationComponent.entityId].modelIndex;
				ModelProto modelProto = LDB.models.Select(modelIndex);
				int num = 0;
				if (modelProto != null)
				{
					num = modelProto.prefabDesc.stationMaxItemCount;
				}
				int num2 = (stationComponent.isStellar ? 10000 : 5000);
				int num3 = num + (Multifunction.StationStoExtra.Value + 1) * num2;
				if (itemCountMax > num3)
				{
					itemCountMax = num3;
				}
				if (storageIdx >= 0 && storageIdx < stationComponent.storage.Length)
				{
					StationStore stationStore = stationComponent.storage[storageIdx];
					if (stationStore.localLogic != localLogic)
					{
						flag = true;
					}
					if (stationStore.remoteLogic != remoteLogic)
					{
						flag2 = true;
					}
					if (stationStore.itemId == itemId)
					{
						stationComponent.storage[storageIdx].max = itemCountMax;
						stationComponent.storage[storageIdx].localLogic = localLogic;
						stationComponent.storage[storageIdx].remoteLogic = remoteLogic;
					}
					else
					{
						if (stationStore.localLogic != ELogisticStorage.None || localLogic != ELogisticStorage.None)
						{
							flag = true;
						}
						if (stationStore.remoteLogic != ELogisticStorage.None || remoteLogic != ELogisticStorage.None)
						{
							flag2 = true;
						}
						if (stationStore.count > 0 && stationStore.itemId > 0 && player != null)
						{
							int num4 = player.TryAddItemToPackage(stationStore.itemId, stationStore.count, stationStore.inc, throwTrash: true);
							UIItemup.Up(stationStore.itemId, num4);
							if (num4 < stationStore.count)
							{
								UIRealtimeTip.Popup("无法收回仓储物品".Translate());
							}
						}
						stationComponent.storage[storageIdx].itemId = itemId;
						stationComponent.storage[storageIdx].count = 0;
						stationComponent.storage[storageIdx].inc = 0;
						stationComponent.storage[storageIdx].localOrder = 0;
						stationComponent.storage[storageIdx].remoteOrder = 0;
						stationComponent.storage[storageIdx].max = itemCountMax;
						stationComponent.storage[storageIdx].localLogic = localLogic;
						stationComponent.storage[storageIdx].remoteLogic = remoteLogic;
					}
					if (itemId == 0)
					{
						stationComponent.storage[storageIdx] = default(StationStore);
						for (int i = 0; i < stationComponent.slots.Length; i++)
						{
							if (stationComponent.slots[i].dir == IODir.Output && stationComponent.slots[i].storageIdx - 1 == storageIdx)
							{
								stationComponent.slots[i].counter = 0;
								stationComponent.slots[i].storageIdx = 0;
								stationComponent.slots[i].dir = IODir.Output;
							}
						}
					}
				}
				if (!stationComponent.isStellar)
				{
					flag2 = false;
				}
			}
			if (flag)
			{
				__instance.RefreshStationTraffic(stationId);
			}
			if (flag2)
			{
				__instance.gameData.galacticTransport.RefreshTraffic(stationComponent.gid);
			}
			return false;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(PlanetTransport), "GameTick")]
		public static void PlanetTransportGameTick(long time, PlanetTransport __instance)
		{
			int num = (int)(time % 20);
			if (num < 0)
			{
				num += 20;
			}
			int num2 = (int)(time % 60);
			if (num2 < 0)
			{
				num2 += 60;
			}
			bool flag = num == 0;
			bool flag2 = num2 == 0;
			FactoryProductionStat factoryProductionStat = GameMain.statistics.production.factoryStatPool[__instance.factory.index];
			int[] productRegister = factoryProductionStat.productRegister;
			int[] consumeRegister = factoryProductionStat.consumeRegister;
			for (int num3 = __instance.stationPool.Length - 1; num3 > 0; num3--)
			{
				StationComponent stationComponent = __instance.stationPool[num3];
				if (stationComponent != null && stationComponent.id == num3)
				{
					if (flag)
					{
						if (Multifunction.Stationfullenergy.Value)
						{
							stationComponent.energy = stationComponent.energyMax;
						}
						if (Multifunction.StationMaxproliferator.Value)
						{
							for (int i = 0; i < stationComponent.storage.Length; i++)
							{
								if (stationComponent.storage[i].itemId > 0)
								{
									stationComponent.storage[i].inc = stationComponent.storage[i].count * Multifunction.incAbility;
								}
							}
						}
						if (Multifunction.StationfullCount)
						{
							StationComponentPatch.StationFullItemCount(stationComponent);
						}
					}
					if (!stationComponent.isCollector && !stationComponent.isVeinCollector)
					{
						if (Multifunction.StationSpray.Value)
						{
							StationComponentPatch.StationSprayInc(stationComponent, consumeRegister);
						}
						if (Multifunction.StationPowerGen.Value)
						{
							StationComponentPatch.StationPowerGeneration(stationComponent, consumeRegister);
						}
						if (flag && Multifunction.Station_infiniteWarp_bool.Value && stationComponent.isStellar)
						{
							stationComponent.warperCount = 50;
						}
						string text = __instance.factory.ReadExtraInfoOnEntity(stationComponent.entityId);
						if (!string.IsNullOrEmpty(text))
						{
							switch (text)
							{
							case "星球无限供货机":
								if (!(!Multifunction.StationfullCount_bool.Value && flag2) && !Multifunction.StationfullCount)
								{
									StationComponentPatch.StationFullItemCount(stationComponent);
								}
								break;
							case "垃圾站":
							case "Station_trash":
								if (!(!Multifunction.StationTrash.Value && flag2))
								{
									StationComponentPatch.StationTrashMethod(stationComponent, consumeRegister);
								}
								break;
							case "喷涂加工厂":
								if (Multifunction.StationSprayer.Value && !Multifunction.StationSpray.Value)
								{
									StationComponentPatch.StationSprayInc(stationComponent, consumeRegister);
								}
								break;
							case "星球熔炉矿机":
								if (Multifunction.StationMinerSmelter.Value)
								{
									if (flag2)
									{
										StationComponentPatch.StationMine(stationComponent, __instance.planet, productRegister);
									}
									StationComponentPatch.StationFurnaceMiner(stationComponent, time, consumeRegister, productRegister);
								}
								break;
							case "星球矿机":
							case "Station_miner":
								if (Multifunction.StationMiner.Value && flag2)
								{
									StationComponentPatch.StationMine(stationComponent, __instance.planet, productRegister);
								}
								break;
							}
						}
					}
				}
			}
		}
	}
	public class PlayerPatch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(Mecha), "UseWarper")]
		public static void EnoughWarperPatch(ref bool __result)
		{
			if (Multifunction.noneedwarp.Value)
			{
				__result = true;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(Mecha), "UseEnergy")]
		public static bool InfiniteplayerpowerPatch(Mecha __instance, ref float __result)
		{
			if (Multifunction.Infiniteplayerpower.Value)
			{
				__result = 1f;
				__instance.coreEnergy = __instance.coreEnergyCap;
				return false;
			}
			return true;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(MechaForge), "GameTick")]
		public static void Prefix(ref MechaForge __instance)
		{
			if (Multifunction.QuickHandcraft.Value && __instance.tasks.Count > 0)
			{
				__instance.tasks[0].tick = __instance.tasks[0].tickSpend;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(PlayerAction_Mine), "GameTick")]
		public static void PlayerAction_MineGameTickPatch(ref PlayerAction_Mine __instance)
		{
			if (!Multifunction.QuickPlayerMine.Value || __instance.miningId <= 0 || GameMain.localPlanet == null)
			{
				return;
			}
			PlanetFactory factory = __instance.player.factory;
			if (__instance.miningType == EObjectType.Vegetable)
			{
				VegeData vegeData = factory.GetVegeData(__instance.miningId);
				VegeProto vegeProto = LDB.veges.Select(vegeData.protoId);
				if (vegeProto != null)
				{
					__instance.miningTick = LDB.veges.Select(factory.GetVegeData(__instance.miningId).protoId).MiningTime * 10000;
				}
			}
			else if (__instance.miningType == EObjectType.Vein)
			{
				VeinData veinData = factory.GetVeinData(__instance.miningId);
				VeinProto veinProto = LDB.veins.Select((int)veinData.type);
				if (veinProto != null)
				{
					__instance.miningTick = veinProto.MiningTime * 10000;
				}
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(PlayerAction_Inspect), "GetObjectSelectDistance")]
		public static void PlayerAction_InspectPatch(ref float __result)
		{
			if (Multifunction.InspectDisNoLimit.Value)
			{
				__result = 400f;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(BuildTool_Click), "_OnInit")]
		public static void DeterminePreviewsPatch(BuildTool_Click __instance)
		{
			__instance.dotsSnapped = new Vector3[Multifunction.Buildmaxlen.Value];
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "CheckBuildConditions")]
		public static bool Prefix(BuildTool_BlueprintPaste __instance, ref bool __result)
		{
			if (Multifunction.pasteanyway && __instance.bpPool != null)
			{
				for (int i = 0; i < __instance.bpPool.Length; i++)
				{
					PrefabDesc prefabDesc = __instance.bpPool[i]?.item?.prefabDesc;
					if (prefabDesc != null && prefabDesc.veinMiner)
					{
						return true;
					}
				}
				__result = true;
				return false;
			}
			return true;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(Player), "TryAddItemToPackage")]
		public static bool PlayerTryAddItemToPackage(int itemId)
		{
			if (!Multifunction.dismantle_but_nobuild.Value || itemId == 1099)
			{
				return true;
			}
			return false;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(Player), "SendItemToPlayer")]
		public static bool PlayerSendItemToPlayer(ref int itemId, ref int itemCount, ref int itemInc, bool toPackage, ItemBundle sentList)
		{
			if (!Multifunction.dismantle_but_nobuild.Value || itemId == 1099)
			{
				return true;
			}
			if (itemId > 0 && itemCount > 0 && toPackage)
			{
				sentList?.Alter(itemId, itemCount);
				itemId = 0;
				itemCount = 0;
				itemInc = 0;
				return false;
			}
			return true;
		}
	}
	public class PowerSystemPatch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(PowerSystem), "NewGeneratorComponent")]
		public static void PowerSystemNewGeneratorComponent(ref int __result, PowerSystem __instance)
		{
			if (Multifunction.InfineteStarPower.Value && __instance.genPool[__result].fuelMask == 4)
			{
				__instance.genPool[__result].fuelId = 1803;
				__instance.genPool[__result].fuelCount = 100;
				__instance.genPool[__result].fuelEnergy = long.MaxValue;
				__instance.genPool[__result].genEnergyPerTick = 1000000000000L;
			}
			if (Multifunction.WindturbinesUnlimitedEnergy.Value && __instance.genPool[__result].wind)
			{
				__instance.genPool[__result].genEnergyPerTick = 1000000000000L;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(PowerSystem), "NewConsumerComponent")]
		public static void PowerSystemNewConsumerComponent(ref int __result, PowerSystem __instance)
		{
			if (!Multifunction.Buildingnoconsume.Value)
			{
				return;
			}
			int entityId = __instance.consumerPool[__result].entityId;
			int modelIndex = __instance.factory.entityPool[entityId].modelIndex;
			if (modelIndex > 0)
			{
				ModelProto modelProto = LDB.models.modelArray[modelIndex];
				if (modelProto?.prefabDesc != null && modelProto.prefabDesc.isFieldGenerator)
				{
					return;
				}
			}
			__instance.consumerPool[__result].requiredEnergy = 0L;
			__instance.consumerPool[__result].idleEnergyPerTick = 0L;
			__instance.consumerPool[__result].workEnergyPerTick = 0L;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(PowerSystem), "NewNodeComponent")]
		public static void NewNodeComponentPatchPrefix(PowerSystem __instance, ref int entityId, ref float conn, ref float cover)
		{
			short protoId = __instance.factory.entityPool[entityId].protoId;
			if (Multifunction.PlanetPower_bool.Value && protoId == 2210)
			{
				cover = GameMain.localPlanet.realRadius * 4f;
				if (Multifunction.farconnectdistance)
				{
					conn = GameMain.localPlanet.realRadius * 1.5f;
					Multifunction.farconnectdistance = false;
				}
			}
			else if (Multifunction.Windturbinescovertheglobe.Value && protoId == 2203)
			{
				cover = GameMain.localPlanet.realRadius * 4f;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(PowerSystem), "NewNodeComponent")]
		public static void NewNodeComponentPatchPostfix(ref int __result, PowerSystem __instance)
		{
			if (Multifunction.Buildingnoconsume.Value && GameMain.localPlanet.factory.entityPool[__instance.nodePool[__result].entityId].stationId <= 0)
			{
				__instance.nodePool[__result].requiredEnergy = 0;
				__instance.nodePool[__result].idleEnergyPerTick = 0;
			}
		}
	}
	public class SomePatch
	{
		[HarmonyPrefix]
		[HarmonyPatch(typeof(DispenserComponent), "InternalTick")]
		public static void DispenserComponentInternalTickPrefix(ref DispenserComponent __instance)
		{
			if (Multifunction.Stationfullenergy.Value)
			{
				__instance.energy = __instance.energyMax;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(PropertySystem), "GetItemTotalProperty")]
		public static void GetItemTotalPropertyPatch(ref long __result)
		{
			if (Multifunction.Property9999999)
			{
				__result = 2147483647L;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(ItemProto), "isFluid")]
		public static void ItemProtoisFluidPatch(ref bool __result)
		{
			if (Multifunction.Tankcontentall.Value)
			{
				__result = true;
			}
		}
	}
	public class SpraycoaterComponentPatch
	{
		[HarmonyPrefix]
		[HarmonyPatch(typeof(SpraycoaterComponent), "InternalUpdate")]
		public static void SpraycoaterComponentInternalUpdatePrefix(ref SpraycoaterComponent __instance)
		{
			if (Multifunction.Maxproliferator.Value)
			{
				Multifunctionpatch.ability = __instance.incAbility;
				__instance.incAbility = 10;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(SpraycoaterComponent), "InternalUpdate")]
		public static void SpraycoaterComponentInternalUpdatePostfix(ref SpraycoaterComponent __instance)
		{
			if (!Multifunction.Maxproliferator.Value && __instance.incAbility > 4)
			{
				__instance.incAbility = Multifunctionpatch.ability;
			}
		}
	}
	public class StationComponentPatch
	{
		private static HashSet<int> tempids = new HashSet<int>();

		[HarmonyPrefix]
		[HarmonyPatch(typeof(StationComponent), "Init")]
		public static void StationComponentInit(ref int _extraStorage, StationComponent __instance)
		{
			if (Multifunction.StationStoExtra.Value > 0)
			{
				int num = (__instance.isStellar ? 10000 : 5000);
				_extraStorage = (Multifunction.StationStoExtra.Value + 1) * num;
			}
		}

		public static int GetNumberOfVein(int itemid, PlanetData pd)
		{
			EVeinType evt = LDB.veins.GetVeinTypeByItemId(itemid);
			if (evt == EVeinType.None)
			{
				return 0;
			}
			if (evt == EVeinType.Oil)
			{
				long[] veinAmounts = new long[64];
				pd.SummarizeVeinAmountsByFilter(ref veinAmounts, tempids, UIRoot.instance.uiGame.veinAmountDisplayFilter);
				int num = (int)((double)((float)veinAmounts[7] * VeinData.oilSpeedMultiplier) + 0.5);
				if (num > 1)
				{
					return num;
				}
			}
			return pd.factory.veinPool.Count((VeinData x) => x.type == evt);
		}

		public static int MineVein(int itemid, int minenumber, PlanetData pd)
		{
			if (pd.waterItemId == itemid)
			{
				return (int)(30f * GameMain.history.miningSpeedScale * (float)Multifunction.Stationminenumber.Value);
			}
			if (minenumber <= 0)
			{
				return 0;
			}
			int num = 0;
			int num2 = ((itemid != 1007) ? ((int)((float)minenumber * GameMain.history.miningSpeedScale / 2f)) : ((int)((float)minenumber * GameMain.history.miningSpeedScale)));
			int num3 = ((itemid != 1007) ? ((int)((float)num2 * GameMain.history.miningCostRate / 2f)) : ((int)((float)num2 * GameMain.history.miningCostRate)));
			if (GameMain.data.gameDesc.isInfiniteResource)
			{
				return num2;
			}
			if (LDB.veins.GetVeinTypeByItemId(itemid) == EVeinType.None || pd == null)
			{
				return 0;
			}
			if (num3 == 0)
			{
				return num2;
			}
			VeinData[] veinPool = pd.factory.veinPool;
			for (int i = 0; i < veinPool.Length; i++)
			{
				VeinData veinData = veinPool[i];
				if (veinData.type != LDB.veins.GetVeinTypeByItemId(itemid) || veinData.amount == 1)
				{
					continue;
				}
				if (veinData.amount > num3 - num)
				{
					if (itemid == 1007 && (double)((float)veinData.amount * VeinData.oilSpeedMultiplier) <= 0.1)
					{
						int num4 = Multifunction.veinproperty.oillowerlimit - veinData.amount;
						pd.factory.veinPool[veinData.id].amount += num4;
						pd.factory.veinGroups[veinData.groupIndex].amount += num4;
						num += (int)(0.1 * (double)GameMain.history.miningSpeedScale * (double)Multifunction.Stationminenumber.Value);
					}
					else
					{
						pd.factory.veinPool[veinData.id].amount -= num3;
						pd.factory.veinGroups[veinData.groupIndex].amount -= num3;
						num = num2;
					}
				}
				else
				{
					num += veinData.amount - 1;
					pd.factory.veinPool[veinData.id].amount = 1;
					pd.factory.veinGroups[veinData.groupIndex].amount -= veinData.amount - 1;
				}
				if (num >= num2)
				{
					break;
				}
			}
			return num;
		}

		public static void StationMine(StationComponent sc, PlanetData pd, int[] productRegister)
		{
			for (int i = 0; i < sc.storage.Length && sc.energy > 0; i++)
			{
				ref StationStore reference = ref sc.storage[i];
				int itemId = reference.itemId;
				if (itemId <= 0 || reference.count >= reference.max)
				{
					continue;
				}
				int numberOfVein = GetNumberOfVein(itemId, pd);
				int num = numberOfVein * Multifunction.Stationminenumber.Value;
				if (numberOfVein > 0 && num == 0)
				{
					num = 1;
				}
				else if (numberOfVein == 0 && itemId != pd.waterItemId)
				{
					continue;
				}
				if (!Multifunction.Stationfullenergy.Value && (float)sc.energy <= (float)num * GameMain.history.miningSpeedScale * 5000f)
				{
					num = (int)((float)sc.energy * 0.9f / (GameMain.history.miningSpeedScale * 5000f));
				}
				int num2 = MineVein(itemId, num, pd);
				if (num2 <= 0)
				{
					continue;
				}
				lock (productRegister)
				{
					productRegister[itemId] += num2;
					sc.storage[i].count += num2;
					if (!Multifunction.Stationfullenergy.Value)
					{
						sc.energy -= num2 * 5000;
					}
				}
			}
		}

		public static void StationPowerGeneration(StationComponent sc, int[] consumeRegister)
		{
			if (sc == null || sc.storage == null || sc.energy >= sc.energyMax - 1000000)
			{
				return;
			}
			ref StationStore reference = ref sc.storage[sc.storage.Length - 1];
			if (reference.itemId <= 0 || reference.count <= 0)
			{
				return;
			}
			ItemProto itemProto = LDB.items.Select(reference.itemId);
			if (itemProto.HeatValue <= 0 || sc.energy + itemProto.HeatValue >= sc.energyMax)
			{
				return;
			}
			int num = Math.Min(reference.count, (int)((sc.energyMax - sc.energy) / itemProto.HeatValue));
			sc.energy += num * itemProto.HeatValue;
			reference.count -= num;
			if (num <= 0)
			{
				return;
			}
			lock (consumeRegister)
			{
				consumeRegister[itemProto.ID] = num;
			}
		}

		public static void StationSprayInc(StationComponent sc, int[] consumeRegister)
		{
			int num = -1;
			for (int i = 0; i < sc.storage.Length; i++)
			{
				if (sc.storage[i].itemId == 1143)
				{
					num = i;
					if (sc.storage[i].count == 0)
					{
						return;
					}
					break;
				}
			}
			if (num == -1)
			{
				return;
			}
			for (int j = 0; j < sc.storage.Length; j++)
			{
				ref StationStore reference = ref sc.storage[j];
				ref StationStore reference2 = ref sc.storage[num];
				if (reference.itemId == 1143 || reference.itemId <= 0 || reference.count <= 0)
				{
					continue;
				}
				int num2 = reference.count * Multifunction.incAbility - reference.inc;
				int num3 = Math.Min((int)Math.Ceiling((double)num2 / 296.0), reference2.count);
				if (num3 != 0)
				{
					lock (consumeRegister)
					{
						consumeRegister[1143] = num3;
						reference.inc += ((reference2.count >= num3) ? num3 : reference2.count) * 296;
						reference2.count -= num3;
					}
					if (reference.count == 0)
					{
						reference.inc = 0;
					}
				}
			}
		}

		public static void StationFullItemCount(StationComponent sc)
		{
			for (int i = 0; i < sc.storage.Length; i++)
			{
				if (sc.storage[i].itemId > 0)
				{
					sc.storage[i].count = sc.storage[i].max;
				}
			}
		}

		public static void StationTrashMethod(StationComponent sc, int[] consumeRegister)
		{
			long num = 0L;
			for (int i = 0; i < sc.storage.Length; i++)
			{
				if (sc.energy <= 0)
				{
					break;
				}
				ref StationStore reference = ref sc.storage[i];
				int itemId = reference.itemId;
				if (itemId <= 0)
				{
					continue;
				}
				int count = reference.count;
				if (sc.energy <= count * 10000)
				{
					continue;
				}
				lock (consumeRegister)
				{
					consumeRegister[itemId] = count;
					sc.storage[i].count -= count;
					if (!Multifunction.Stationfullenergy.Value)
					{
						sc.energy -= count * 10000;
					}
				}
				if (Multifunction.needtrashsand.Value)
				{
					num += count * 100;
				}
			}
			if (num > 0)
			{
				Multifunction.player.sandCountChanged -= UIRoot.instance.uiGame.OnSandCountChanged;
				Multifunction.player.SetSandCount(Multifunction.player.sandCount + num, ESandSource.Other);
				Multifunction.player.sandCountChanged += UIRoot.instance.uiGame.OnSandCountChanged;
			}
		}

		public static void StationFurnaceMiner(StationComponent sc, long time, int[] consumeRegister, int[] productRegister)
		{
			List<int> storageItems = sc.storage.Select((StationStore x) => x.itemId).ToList();
			storageItems.ForEach(delegate(int itemId)
			{
				if (itemId > 0 && Multifunction.smeltRecipes.ContainsKey(itemId))
				{
					Multifunction.smeltRecipes[itemId].ForEach(delegate(RecipeProto rp)
					{
						int num = rp.TimeSpend / 2;
						if ((num < 2 || time % num == 0) && rp.Results.All(storageItems.Contains) && rp.Items.All(storageItems.Contains))
						{
							for (int i = 0; i < rp.ResultCounts.Length; i++)
							{
								int num2 = storageItems.IndexOf(rp.Results[i]);
								if (sc.storage[num2].count > sc.storage[num2].max)
								{
									return;
								}
							}
							int value = Multifunction.StationMinerSmelterNum.Value;
							int num3 = 1440000;
							int num4 = 2880000;
							int num5 = value;
							int num6 = num5;
							int num7 = rp.Items.Length;
							for (int j = 0; j < num7; j++)
							{
								if (rp.ItemCounts[j] != 0)
								{
									int num8 = storageItems.IndexOf(rp.Items[j]);
									int val = sc.storage[num8].count / rp.ItemCounts[j];
									num5 = Math.Min(num5, val);
									num6 = Math.Min(Math.Min(num6, val), sc.storage[num8].inc / Multifunction.incAbility);
								}
							}
							if (Multifunction.Stationfullenergy.Value)
							{
								num5 -= num6;
							}
							else
							{
								num6 = (int)Math.Min(num6, sc.energy / num4);
								sc.energy -= num6 * num4;
								num5 = (int)Math.Min(num5 - num6, sc.energy / num3);
							}
							if (num5 + num6 != 0)
							{
								if (!Multifunction.Stationfullenergy.Value)
								{
									sc.energy -= num5 * num3;
								}
								for (int k = 0; k < num7; k++)
								{
									int num9 = rp.ItemCounts[k] * (num5 + num6);
									lock (consumeRegister)
									{
										int num10 = storageItems.IndexOf(rp.Items[k]);
										sc.storage[num10].count -= num9;
										sc.storage[num10].inc -= num6 * rp.ItemCounts[k] * Multifunction.incAbility;
										sc.storage[num10].inc = Math.Max(0, Math.Min(sc.storage[num10].count * Multifunction.incAbility, sc.storage[num10].inc));
										consumeRegister[rp.Items[k]] = num9;
									}
								}
								for (int l = 0; l < rp.ResultCounts.Length; l++)
								{
									lock (productRegister)
									{
										int num11 = (int)((double)rp.ResultCounts[l] * ((double)num5 + (double)num6 * (1.0 + Cargo.incTableMilli[Multifunction.incAbility])));
										int num12 = storageItems.IndexOf(rp.Results[l]);
										sc.storage[num12].count += num11;
										productRegister[rp.Results[l]] = num11;
									}
								}
							}
						}
					});
				}
			});
		}
	}
	public class StorageComponentPatch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(StorageComponent), "Import")]
		public static void StorageComponentImportPatch(StorageComponent __instance)
		{
			if (Multifunction.StackMultiple.Value <= 1)
			{
				return;
			}
			for (int i = 0; i < __instance.size; i++)
			{
				if (__instance.entityId > 0 && __instance.grids[i].itemId > 0)
				{
					ItemProto itemProto = LDB.items.Select(__instance.grids[i].itemId);
					if (itemProto != null)
					{
						__instance.grids[i].stackSize = itemProto.StackSize * Multifunction.StackMultiple.Value;
					}
				}
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(StorageComponent), "LoadStatic")]
		public static void Postfix()
		{
			if (Multifunction.StackMultiple.Value > 1)
			{
				ItemProto[] dataArray = LDB.items.dataArray;
				for (int i = 0; i < dataArray.Length; i++)
				{
					StorageComponent.itemStackCount[dataArray[i].ID] = dataArray[i].StackSize * Multifunction.StackMultiple.Value;
				}
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(StorageComponent), "GetItemCount", new Type[] { typeof(int) })]
		public static void GetItemCountPatch(StorageComponent __instance, int itemId, ref int __result)
		{
			if (Multifunction.ArchitectMode.Value && itemId > 0 && itemId < 6007 && __instance != null && __instance.id == GameMain.mainPlayer.package.id && LDB.items.Select(itemId).CanBuild && __result == 0)
			{
				__result = 100;
			}
		}
	}
	public class TankComponentPatch
	{
		[HarmonyPrefix]
		[HarmonyPatch(typeof(TankComponent), "GameTick")]
		public static void TankComponentGameTickPatchPrefix(ref TankComponent __instance)
		{
			if (Multifunction.TankMaxproliferator.Value)
			{
				__instance.fluidInc = __instance.fluidCount * Multifunction.incAbility;
			}
		}
	}
	internal class UIControlPanelPatch
	{
		private static Harmony _patch;

		private static bool enable;

		public static bool Enable
		{
			get
			{
				return enable;
			}
			set
			{
				if (enable != value)
				{
					enable = value;
					if (enable)
					{
						_patch = Harmony.CreateAndPatchAll(typeof(UIControlPanelPatch), (string)null);
					}
					else
					{
						_patch.UnpatchSelf();
					}
				}
			}
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(UIControlPanelStationInspector), "OnDroneIconClick")]
		public static IEnumerable<CodeInstruction> OnDroneIconClickPatch(IEnumerable<CodeInstruction> instructions)
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0038: Expected O, but got Unknown
			CodeMatcher val = new CodeMatcher(instructions, (ILGenerator)null).MatchForward(false, (CodeMatch[])(object)new CodeMatch[1]
			{
				new CodeMatch((OpCode?)OpCodes.Call, (object)AccessTools.Method(typeof(UIControlPanelStationInspector), "get_isLocal", (Type[])null, (Type[])null), (string)null)
			}).Set(OpCodes.Nop, (object)null);
			return val.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(UIControlPanelStationInspector), "OnShipIconClick")]
		public static IEnumerable<CodeInstruction> OnShipIconClickPatch(IEnumerable<CodeInstruction> instructions)
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0038: Expected O, but got Unknown
			CodeMatcher val = new CodeMatcher(instructions, (ILGenerator)null).MatchForward(false, (CodeMatch[])(object)new CodeMatch[1]
			{
				new CodeMatch((OpCode?)OpCodes.Call, (object)AccessTools.Method(typeof(UIControlPanelStationInspector), "get_isLocal", (Type[])null, (Type[])null), (string)null)
			}).Set(OpCodes.Nop, (object)null);
			return val.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(UIControlPanelStationInspector), "OnWarperIconClick")]
		public static IEnumerable<CodeInstruction> OnWarperIconClickPatch(IEnumerable<CodeInstruction> instructions)
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0038: Expected O, but got Unknown
			CodeMatcher val = new CodeMatcher(instructions, (ILGenerator)null).MatchForward(false, (CodeMatch[])(object)new CodeMatch[1]
			{
				new CodeMatch((OpCode?)OpCodes.Call, (object)AccessTools.Method(typeof(UIControlPanelStationInspector), "get_isLocal", (Type[])null, (Type[])null), (string)null)
			}).Set(OpCodes.Nop, (object)null);
			return val.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(UIControlPanelStationStorage), "OnItemIconMouseDown")]
		public static IEnumerable<CodeInstruction> OnItemIconMouseDownPatch(IEnumerable<CodeInstruction> instructions)
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0038: Expected O, but got Unknown
			//IL_0072: Unknown result type (might be due to invalid IL or missing references)
			//IL_0078: Expected O, but got Unknown
			CodeMatcher val = new CodeMatcher(instructions, (ILGenerator)null).MatchForward(false, (CodeMatch[])(object)new CodeMatch[1]
			{
				new CodeMatch((OpCode?)OpCodes.Call, (object)AccessTools.Method(typeof(UIControlPanelStationStorage), "get_isLocal", (Type[])null, (Type[])null), (string)null)
			}).Set(OpCodes.Nop, (object)null).MatchForward(false, (CodeMatch[])(object)new CodeMatch[1]
			{
				new CodeMatch((OpCode?)OpCodes.Call, (object)AccessTools.Method(typeof(UIControlPanelStationStorage), "get_isLocal", (Type[])null, (Type[])null), (string)null)
			})
				.Set(OpCodes.Nop, (object)null);
			return val.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(UIControlPanelDispenserInspector), "OnItemIconMouseDown")]
		public static IEnumerable<CodeInstruction> OnDispenserItemIconMouseDownPatch(IEnumerable<CodeInstruction> instructions)
		{
			//IL_0003: Unknown result type (might be due to invalid IL or missing references)
			//IL_0032: Unknown result type (might be due to invalid IL or missing references)
			//IL_0038: Expected O, but got Unknown
			//IL_0072: Unknown result type (might be due to invalid IL or missing references)
			//IL_0078: Expected O, but got Unknown
			CodeMatcher val = new CodeMatcher(instructions, (ILGenerator)null).MatchForward(false, (CodeMatch[])(object)new CodeMatch[1]
			{
				new CodeMatch((OpCode?)OpCodes.Call, (object)AccessTools.Method(typeof(UIControlPanelDispenserInspector), "get_isLocal", (Type[])null, (Type[])null), (string)null)
			}).Set(OpCodes.Nop, (object)null).MatchForward(false, (CodeMatch[])(object)new CodeMatch[1]
			{
				new CodeMatch((OpCode?)OpCodes.Call, (object)AccessTools.Method(typeof(UIControlPanelDispenserInspector), "get_isLocal", (Type[])null, (Type[])null), (string)null)
			})
				.Set(OpCodes.Nop, (object)null);
			return val.InstructionEnumeration();
		}
	}
	public class UIPatch
	{
		public static bool tempisInstantItem;

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UIGame), "On_E_Switch")]
		public static bool CloseWindowPatch()
		{
			if (Multifunction.guidraw.DisplayingWindow)
			{
				Multifunction.guidraw.CloseMainWindow();
				return false;
			}
			return true;
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(UIReplicatorWindow), "SetSelectedRecipeIndex")]
		public static void UIReplicatorWindowSetSelectedRecipe(ref UIReplicatorWindow __instance)
		{
			if (!Multifunction.isInstantItem.Value || !tempisInstantItem || !(Traverse.Create((object)__instance).Field("selectedRecipe").GetValue() is RecipeProto recipeProto))
			{
				return;
			}
			Player mainPlayer = GameMain.mainPlayer;
			RecipeProto recipeProto2 = recipeProto;
			if (recipeProto == null)
			{
				return;
			}
			int num = 1;
			if (__instance.multipliers.ContainsKey(recipeProto.ID))
			{
				num = __instance.multipliers[recipeProto.ID];
			}
			if (num < 1)
			{
				num = 1;
			}
			else if (num > 10)
			{
				num = 10;
			}
			for (int i = 0; i < recipeProto2.Results.Length; i++)
			{
				int num2 = recipeProto2.Results[i];
				int stackSize = LDB.items.Select(num2).StackSize;
				int num3 = (__instance.isBatch ? (num * stackSize) : num);
				int num4 = mainPlayer.TryAddItemToPackage(num2, num3, 0, throwTrash: true);
				int num5 = num3 - num4;
				if (num5 > 0)
				{
					ItemProto itemProto = LDB.items.Select(num2);
					if (itemProto != null)
					{
						UIRealtimeTip.Popup(string.Format("背包已满未添加".Translate(), num5, itemProto.name));
					}
				}
				if (num4 > 0)
				{
					UIItemup.Up(num2, num4);
				}
				mainPlayer.mecha.AddProductionStat(num2, num3, mainPlayer.nearestFactory);
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(UIReplicatorWindow), "_OnOpen")]
		public static void UIReplicatorWindow_OnOpen(ref UIReplicatorWindow __instance)
		{
			if (Multifunction.isInstantItem.Value)
			{
				__instance.isInstantItem = tempisInstantItem;
				__instance.instantItemSwitch.gameObject.SetActive(value: true);
				__instance.instantItemSwitch.SetToggleNoEvent(tempisInstantItem);
				if (tempisInstantItem)
				{
					Traverse.Create((object)__instance).Method("RefreshRecipeIcons", Array.Empty<object>()).GetValue();
				}
				__instance.instantItemSwitch.SetToggleNoEvent(tempisInstantItem);
				__instance.batchSwitch.gameObject.SetActive(tempisInstantItem);
				__instance.batchSwitch.SetToggleNoEvent(_isOn: true);
				__instance.sandboxAddUsefulItemButton.gameObject.SetActive(tempisInstantItem);
				__instance.sandboxClearPackageButton.gameObject.SetActive(tempisInstantItem);
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(UIReplicatorWindow), "OnInstantSwitchClick")]
		public static void UIReplicatorWindowOnInstantSwitchClick(ref UIReplicatorWindow __instance)
		{
			if (Multifunction.isInstantItem.Value)
			{
				tempisInstantItem = __instance.isInstantItem;
				__instance.sandboxAddUsefulItemButton.gameObject.SetActive(tempisInstantItem);
				__instance.sandboxClearPackageButton.gameObject.SetActive(tempisInstantItem);
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UIReplicatorWindow), "OnOkButtonClick")]
		public static bool UIReplicatorWindowOnOkButtonClick(ref UIReplicatorWindow __instance)
		{
			if (!Multifunction.isInstantItem.Value || !tempisInstantItem)
			{
				return true;
			}
			if (!(Traverse.Create((object)__instance).Field("selectedRecipe").GetValue() is RecipeProto { ID: var iD }))
			{
				return false;
			}
			int num = 1;
			if (__instance.multipliers.ContainsKey(iD))
			{
				num = __instance.multipliers[iD];
			}
			if (num < 1)
			{
				num = 1;
			}
			else if (num > 10)
			{
				num = 10;
			}
			Player mainPlayer = GameMain.mainPlayer;
			RecipeProto recipeProto2 = LDB.recipes.Select(iD);
			for (int i = 0; i < recipeProto2.Results.Length; i++)
			{
				int num2 = recipeProto2.Results[i];
				int stackSize = LDB.items.Select(num2).StackSize;
				int num3 = (__instance.isBatch ? (num * stackSize) : num);
				int num4 = mainPlayer.TryAddItemToPackage(num2, num3, 0, throwTrash: true);
				int num5 = num3 - num4;
				if (num5 > 0)
				{
					ItemProto itemProto = LDB.items.Select(num2);
					if (itemProto != null)
					{
						UIRealtimeTip.Popup(string.Format("背包已满未添加".Translate(), num5, itemProto.name));
					}
				}
				if (num4 > 0)
				{
					UIItemup.Up(num2, num4);
				}
				mainPlayer.mecha.AddProductionStat(num2, num3, mainPlayer.nearestFactory);
			}
			return false;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UITechTree), "_OnUpdate")]
		public static void UITechTreeSelectTechPatch(UITechTree __instance)
		{
			if (!Multifunction.unlockpointtech || __instance.selected == null)
			{
				return;
			}
			TechProto techProto = __instance.selected.techProto;
			if (GameMain.history.techStates[techProto.ID].unlocked || techProto.MaxLevel > 10)
			{
				return;
			}
			if (techProto.Level < techProto.MaxLevel)
			{
				for (int i = 1; i < techProto.MaxLevel; i++)
				{
					for (int j = 0; j < techProto.itemArray.Length; j++)
					{
						Multifunction.AddComsumeItemtoTotal(techProto.Items[j], (int)(techProto.ItemPoints[j] * techProto.GetHashNeeded(techProto.Level) / 3600));
					}
					GameMain.history.UnlockTechFunction(techProto.UnlockFunctions[0], techProto.UnlockValues[0], i);
				}
				GameMain.history.UnlockTech(techProto.ID);
			}
			if (!GameMain.history.techStates[techProto.ID].unlocked)
			{
				for (int k = 0; k < techProto.itemArray.Length; k++)
				{
					Multifunction.AddComsumeItemtoTotal(techProto.Items[k], (int)(techProto.ItemPoints[k] * techProto.GetHashNeeded(techProto.Level) / 3600));
				}
				GameMain.history.UnlockTech(techProto.ID);
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UITechTree), "UpdateScale")]
		public static bool UITechTreeUpdateScalePatch(UITechTree __instance)
		{
			if (Multifunction.unlockpointtech && (__instance.selected != null || __instance.centerViewNode != null))
			{
				return false;
			}
			return true;
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(UIStationStorage), "GetAdditionStorage")]
		public static void UIStationWindow_OnOpen(UIStationStorage __instance, ref int __result)
		{
			if (Multifunction.StationStoExtra.Value != 0 && !__instance.station.isCollector)
			{
				int num = (__instance.station.isStellar ? 10000 : 5000);
				__result += Multifunction.StationStoExtra.Value * num;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(UIAbnormalityTip), "_OnOpen")]
		public static void UIAbnormalityTipDeterminePatch(UIAbnormalityTip __instance)
		{
			if (Multifunction.CloseUIAbnormalityTip.Value)
			{
				__instance._Close();
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(UIStarmap), "UpdateCursorView")]
		public static void UIStarmapUpdateCursorView(UIStarmap __instance)
		{
			if (Multifunction.EnableTp.Value && __instance.focusPlanet != null)
			{
				Player mainPlayer = GameMain.mainPlayer;
				__instance.fastTravelButton.gameObject.SetActive(mainPlayer.planetId != __instance.focusPlanet.planet.id && !mainPlayer.warping);
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(UIStarmap), "OnFastTravelButtonClick")]
		public static void UIStarmapOnFastTravelButtonClick(UIStarmap __instance)
		{
			if (Multifunction.EnableTp.Value && __instance.focusPlanet != null)
			{
				GameMain.mainPlayer.controller.actionSail.StartFastTravelToPlanet(__instance.focusPlanet.planet);
			}
		}
	}
}
namespace Multifunction_mod.Models
{
	public class PropertyData
	{
		private float walkSpeed;

		private float techSpeed;

		private float droneSpeed;

		private float droneMovement;

		private float droneCount;

		private float maxSailSpeed;

		private float maxWarpSpeed;

		private float buildArea;

		private float reactorPowerGen;

		private float logisticCourierSpeed;

		private float logisticDroneSpeedScale;

		private float logisticShipSpeedScale;

		private float logisticCourierCarries;

		private float logisticDroneCarries;

		private float logisticShipCarries;

		private float miningCostRate;

		private float miningSpeedScale;

		private float labLevel;

		private float storageLevel;

		private float stackSizeMultiplier;

		private float kineticDamageScale;

		private float energyDamageScale;

		private float blastDamageScale;

		private float magneticDamageScale;

		private float globalHpEnhancement;

		private float energyShieldRadius;

		private long energyShieldCapacity;

		private float combatDroneDamageRatio;

		private float combatDroneROFRatio;

		private float combatDroneDurabilityRatio;

		private float enemyDropScale;

		private float combatDroneSpeedRatio;

		private float combatShipSpeedRatio;

		private float combatShipDamageRatio;

		private float combatShipROFRatio;

		private float combatShipDurabilityRatio;

		private float planetaryATFieldEnergyRate;

		private int hpMaxUpgrade;

		private float laserAttackLocalRange;

		private float laserAttackSpaceRange;

		private float laserAttackDamage;

		private float laserEnergyCapacity;

		private float laserEnergyCost;

		public float WalkSpeed
		{
			get
			{
				return walkSpeed;
			}
			set
			{
				if (value != 0f && value != walkSpeed)
				{
					walkSpeed = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.walkSpeed = value;
					}
				}
			}
		}

		public float TechSpeed
		{
			get
			{
				return techSpeed;
			}
			set
			{
				if (value != 0f && value != techSpeed)
				{
					techSpeed = value;
					if (CheckCondition())
					{
						GameMain.history.techSpeed = (int)value;
					}
				}
			}
		}

		public float DroneSpeed
		{
			get
			{
				return droneSpeed;
			}
			set
			{
				if (value != 0f && value != droneSpeed)
				{
					droneSpeed = value;
					if (CheckCondition())
					{
						GameMain.history.constructionDroneSpeed = value;
					}
				}
			}
		}

		public float DroneCount
		{
			get
			{
				return droneCount;
			}
			set
			{
				if (value != 0f && value != droneCount)
				{
					droneCount = value;
					if (CheckCondition())
					{
						int num = (int)(value - (float)GameMain.mainPlayer.mecha.constructionModule.droneCount);
						GameMain.mainPlayer.mecha.constructionModule.droneCount += num;
						GameMain.mainPlayer.mecha.constructionModule.droneAliveCount += num;
						GameMain.mainPlayer.mecha.constructionModule.droneIdleCount += num;
					}
				}
			}
		}

		public float MaxSailSpeed
		{
			get
			{
				return maxSailSpeed;
			}
			set
			{
				if (value != 0f && value != maxSailSpeed)
				{
					maxSailSpeed = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.maxSailSpeed = (int)value * 1000;
					}
				}
			}
		}

		public float MaxWarpSpeed
		{
			get
			{
				return maxWarpSpeed;
			}
			set
			{
				if (value != 0f && value != maxWarpSpeed)
				{
					maxWarpSpeed = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.maxWarpSpeed = (int)value * 1000 * 480;
					}
				}
			}
		}

		public float BuildArea
		{
			get
			{
				return buildArea;
			}
			set
			{
				if (value != 0f && value != buildArea)
				{
					buildArea = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.buildArea = value;
					}
				}
			}
		}

		public float ReactorPowerGen
		{
			get
			{
				return reactorPowerGen;
			}
			set
			{
				if (value != 0f && value != reactorPowerGen)
				{
					reactorPowerGen = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.reactorPowerGen = value;
					}
				}
			}
		}

		public float LogisticCourierSpeed
		{
			get
			{
				return logisticCourierSpeed;
			}
			set
			{
				if (value != 0f && value != logisticCourierSpeed)
				{
					logisticCourierSpeed = value;
					if (CheckCondition())
					{
						GameMain.history.logisticCourierSpeed = (int)value;
					}
				}
			}
		}

		public float LogisticDroneSpeedScale
		{
			get
			{
				return logisticDroneSpeedScale;
			}
			set
			{
				if (value != 0f && value != logisticDroneSpeedScale)
				{
					logisticDroneSpeedScale = value;
					if (CheckCondition())
					{
						GameMain.history.logisticDroneSpeedScale = value;
					}
				}
			}
		}

		public float LogisticShipSpeedScale
		{
			get
			{
				return logisticShipSpeedScale;
			}
			set
			{
				if (value != 0f && value != logisticShipSpeedScale)
				{
					logisticShipSpeedScale = value;
					if (CheckCondition())
					{
						GameMain.history.logisticShipSpeedScale = value;
					}
				}
			}
		}

		public float LogisticCourierCarries
		{
			get
			{
				return logisticCourierCarries;
			}
			set
			{
				if (value != 0f && value != logisticCourierCarries)
				{
					logisticCourierCarries = value;
					if (CheckCondition())
					{
						GameMain.history.logisticCourierCarries = (int)value;
					}
				}
			}
		}

		public float LogisticDroneCarries
		{
			get
			{
				return logisticDroneCarries;
			}
			set
			{
				if (value != 0f && value != logisticDroneCarries)
				{
					logisticDroneCarries = (int)(value / 50f) * 50;
					if (CheckCondition())
					{
						GameMain.history.logisticDroneCarries = (int)value;
					}
				}
			}
		}

		public float LogisticShipCarries
		{
			get
			{
				return logisticShipCarries;
			}
			set
			{
				if (value != 0f && value != logisticShipCarries)
				{
					logisticShipCarries = (int)(value / 500f) * 500;
					if (CheckCondition())
					{
						GameMain.history.logisticShipCarries = (int)value;
					}
				}
			}
		}

		public float MiningCostRate
		{
			get
			{
				return miningCostRate;
			}
			set
			{
				if (value != 0f && value != miningCostRate)
				{
					miningCostRate = value;
					if (CheckCondition())
					{
						GameMain.history.miningCostRate = value;
					}
				}
			}
		}

		public float MiningSpeedScale
		{
			get
			{
				return miningSpeedScale;
			}
			set
			{
				if (value != 0f && value != miningSpeedScale)
				{
					miningSpeedScale = value;
					if (CheckCondition())
					{
						GameMain.history.miningSpeedScale = value;
					}
				}
			}
		}

		public float LabLevel
		{
			get
			{
				return labLevel;
			}
			set
			{
				if (value != 0f && value != labLevel)
				{
					labLevel = value;
					if (CheckCondition())
					{
						GameMain.history.storageLevel = (int)value;
						GameMain.history.labLevel = (int)value;
					}
				}
			}
		}

		public float StorageLevel
		{
			get
			{
				return storageLevel;
			}
			set
			{
				if (value != 0f && value != storageLevel)
				{
					storageLevel = value;
					if (CheckCondition())
					{
						GameMain.history.stationPilerLevel = (int)value;
					}
				}
			}
		}

		public float StackSizeMultiplier
		{
			get
			{
				return stackSizeMultiplier;
			}
			set
			{
				if (value != 0f && value != stackSizeMultiplier)
				{
					stackSizeMultiplier = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.deliveryPackage.stackSizeMultiplier = (int)value;
					}
				}
			}
		}

		public float KineticDamageScale
		{
			get
			{
				return kineticDamageScale;
			}
			set
			{
				if (value != 0f && value != kineticDamageScale)
				{
					kineticDamageScale = value;
					if (CheckCondition())
					{
						GameMain.history.kineticDamageScale = value;
					}
				}
			}
		}

		public float EnergyDamageScale
		{
			get
			{
				return energyDamageScale;
			}
			set
			{
				if (value != 0f && value != energyDamageScale)
				{
					energyDamageScale = value;
					if (CheckCondition())
					{
						GameMain.history.energyDamageScale = value;
					}
				}
			}
		}

		public float BlastDamageScale
		{
			get
			{
				return blastDamageScale;
			}
			set
			{
				if (value != 0f && value != blastDamageScale)
				{
					blastDamageScale = value;
					if (CheckCondition())
					{
						GameMain.history.blastDamageScale = value;
					}
				}
			}
		}

		public float MagneticDamageScale
		{
			get
			{
				return magneticDamageScale;
			}
			set
			{
				if (value != 0f && value != magneticDamageScale)
				{
					magneticDamageScale = value;
					if (CheckCondition())
					{
						GameMain.history.magneticDamageScale = value;
					}
				}
			}
		}

		public float GlobalHpEnhancement
		{
			get
			{
				return globalHpEnhancement;
			}
			set
			{
				if (value != 0f && value != globalHpEnhancement)
				{
					globalHpEnhancement = value;
					if (CheckCondition())
					{
						GameMain.history.globalHpEnhancement = value;
					}
				}
			}
		}

		public float EnergyShieldRadius
		{
			get
			{
				return energyShieldRadius;
			}
			set
			{
				if (value != 0f && value != energyShieldRadius)
				{
					energyShieldRadius = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.energyShieldRadius = value;
					}
				}
			}
		}

		public long EnergyShieldCapacity
		{
			get
			{
				return energyShieldCapacity;
			}
			set
			{
				if (value != 0L && value != energyShieldCapacity)
				{
					if (value > 990000000000L)
					{
						value = 1000000000000L;
					}
					if (value < 1000)
					{
						value = 0L;
					}
					energyShieldCapacity = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.energyShieldCapacity = value;
					}
				}
			}
		}

		public float CombatDroneDamageRatio
		{
			get
			{
				return combatDroneDamageRatio;
			}
			set
			{
				if (value != 0f && value != combatDroneDamageRatio)
				{
					combatDroneDamageRatio = value;
					if (CheckCondition())
					{
						GameMain.history.combatDroneDamageRatio = value;
					}
				}
			}
		}

		public float CombatDroneROFRatio
		{
			get
			{
				return combatDroneROFRatio;
			}
			set
			{
				if (value != 0f && value != combatDroneROFRatio)
				{
					combatDroneROFRatio = value;
					if (CheckCondition())
					{
						GameMain.history.combatDroneROFRatio = value;
					}
				}
			}
		}

		public float CombatDroneDurabilityRatio
		{
			get
			{
				return combatDroneDurabilityRatio;
			}
			set
			{
				if (value != 0f && value != combatDroneDurabilityRatio)
				{
					combatDroneDurabilityRatio = value;
					if (CheckCondition())
					{
						GameMain.history.combatDroneDurabilityRatio = value;
					}
				}
			}
		}

		public float EnemyDropScale
		{
			get
			{
				return enemyDropScale;
			}
			set
			{
				if (value != 0f && value != enemyDropScale)
				{
					enemyDropScale = value;
					if (CheckCondition())
					{
						GameMain.history.enemyDropScale = value;
					}
				}
			}
		}

		public float CombatDroneSpeedRatio
		{
			get
			{
				return combatDroneSpeedRatio;
			}
			set
			{
				if (value != 0f && value != combatDroneSpeedRatio)
				{
					combatDroneSpeedRatio = value;
					if (CheckCondition())
					{
						GameMain.history.combatDroneSpeedRatio = value;
					}
				}
			}
		}

		public float CombatShipSpeedRatio
		{
			get
			{
				return combatShipSpeedRatio;
			}
			set
			{
				if (value != 0f && value != combatShipSpeedRatio)
				{
					combatShipSpeedRatio = value;
					if (CheckCondition())
					{
						GameMain.history.combatShipSpeedRatio = value;
					}
				}
			}
		}

		public float CombatShipDamageRatio
		{
			get
			{
				return combatShipDamageRatio;
			}
			set
			{
				if (value != 0f && value != combatShipDamageRatio)
				{
					combatShipDamageRatio = value;
					if (CheckCondition())
					{
						GameMain.history.combatShipDamageRatio = value;
					}
				}
			}
		}

		public float CombatShipROFRatio
		{
			get
			{
				return combatShipROFRatio;
			}
			set
			{
				if (value != 0f && value != combatShipROFRatio)
				{
					combatShipROFRatio = value;
					if (CheckCondition())
					{
						GameMain.history.combatShipROFRatio = value;
					}
				}
			}
		}

		public float CombatShipDurabilityRatio
		{
			get
			{
				return combatShipDurabilityRatio;
			}
			set
			{
				if (value != 0f && value != combatShipDurabilityRatio)
				{
					combatShipDurabilityRatio = value;
					if (CheckCondition())
					{
						GameMain.history.combatShipDurabilityRatio = value;
					}
				}
			}
		}

		public float PlanetaryATFieldEnergyRate
		{
			get
			{
				return planetaryATFieldEnergyRate;
			}
			set
			{
				if (value != 0f && value != planetaryATFieldEnergyRate)
				{
					planetaryATFieldEnergyRate = value;
					if (CheckCondition())
					{
						GameMain.history.planetaryATFieldEnergyRate = (long)value * Configs.freeMode.planetaryATFieldEnergyRate;
					}
				}
			}
		}

		public int HpMaxUpgrade
		{
			get
			{
				return hpMaxUpgrade;
			}
			set
			{
				if (value != 0 && value != hpMaxUpgrade)
				{
					if (value < 100)
					{
						value = 0;
					}
					hpMaxUpgrade = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.hpMaxUpgrade = value * 100;
					}
				}
			}
		}

		public float LaserAttackLocalRange
		{
			get
			{
				return laserAttackLocalRange;
			}
			set
			{
				if (value != 0f && value != laserAttackLocalRange)
				{
					laserAttackLocalRange = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.laserLocalAttackRange = (int)value;
					}
				}
			}
		}

		public float LaserAttackSpaceRange
		{
			get
			{
				return laserAttackSpaceRange;
			}
			set
			{
				if (value != 0f && value != laserAttackSpaceRange)
				{
					laserAttackSpaceRange = value / 10f * 10f;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.laserSpaceAttackRange = (int)value;
					}
				}
			}
		}

		public float LaserAttackDamage
		{
			get
			{
				return laserAttackDamage;
			}
			set
			{
				if (value != 0f && value != laserAttackDamage)
				{
					if (value < 5f)
					{
						value = 0f;
					}
					laserAttackDamage = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.laserLocalDamage = (int)value * 100;
						GameMain.mainPlayer.mecha.laserSpaceDamage = (int)value * 100;
					}
				}
			}
		}

		public float LaserEnergyCapacity
		{
			get
			{
				return laserEnergyCapacity;
			}
			set
			{
				if (value != 0f && value != laserEnergyCapacity)
				{
					if (value < 1000f)
					{
						value = 0f;
					}
					laserEnergyCapacity = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.laserEnergyCapacity = (int)value;
					}
				}
			}
		}

		public float LaserEnergyCost
		{
			get
			{
				return laserEnergyCost;
			}
			set
			{
				if (value != 0f && value != laserEnergyCost)
				{
					if (value < 10f)
					{
						value = 0f;
					}
					laserEnergyCost = value;
					if (CheckCondition())
					{
						GameMain.mainPlayer.mecha.laserLocalEnergyCost = (int)value;
						GameMain.mainPlayer.mecha.laserSpaceEnergyCost = (int)value;
					}
				}
			}
		}

		public void SetContent(Mecha mecha, GameHistoryData historyData, int stackSizeMultiplier)
		{
			walkSpeed = mecha.walkSpeed;
			techSpeed = historyData.techSpeed;
			droneSpeed = historyData.constructionDroneSpeed;
			droneMovement = historyData.constructionDroneMovement;
			droneCount = mecha.constructionModule.droneCount;
			maxSailSpeed = mecha.maxSailSpeed / 1000f;
			maxWarpSpeed = mecha.maxWarpSpeed / 480000f;
			buildArea = mecha.buildArea;
			reactorPowerGen = (float)mecha.reactorPowerGen;
			logisticCourierSpeed = ((historyData.logisticCourierSpeed > 0f) ? historyData.logisticCourierSpeed : 6f);
			logisticDroneSpeedScale = ((historyData.logisticDroneSpeedScale > 0f) ? historyData.logisticDroneSpeedScale : 3f);
			logisticShipSpeedScale = ((historyData.logisticShipSpeedScale > 0f) ? historyData.logisticShipSpeedScale : 5f);
			logisticCourierCarries = ((historyData.logisticCourierCarries > 0) ? historyData.logisticDroneCarries : 3);
			logisticDroneCarries = ((historyData.logisticDroneCarries > 0) ? historyData.logisticDroneCarries : 100);
			logisticShipCarries = ((historyData.logisticShipCarries > 0) ? historyData.logisticShipCarries : 100);
			miningCostRate = historyData.miningCostRate;
			miningSpeedScale = historyData.miningSpeedScale;
			labLevel = historyData.labLevel;
			storageLevel = historyData.storageLevel;
			globalHpEnhancement = historyData.globalHpEnhancement;
			this.stackSizeMultiplier = stackSizeMultiplier;
			kineticDamageScale = historyData.kineticDamageScale;
			energyDamageScale = historyData.energyDamageScale;
			blastDamageScale = historyData.blastDamageScale;
			magneticDamageScale = historyData.magneticDamageScale;
			energyShieldRadius = mecha.energyShieldRadius;
			energyShieldCapacity = mecha.energyShieldCapacity;
			hpMaxUpgrade = mecha.hpMaxUpgrade / 100;
			laserAttackLocalRange = mecha.laserLocalAttackRange;
			laserAttackSpaceRange = mecha.laserSpaceAttackRange;
			laserAttackDamage = mecha.laserLocalDamage / 100;
			laserEnergyCapacity = mecha.laserEnergyCapacity;
			laserEnergyCost = mecha.laserLocalEnergyCost;
			combatDroneDamageRatio = historyData.combatDroneDamageRatio;
			combatDroneROFRatio = historyData.combatDroneROFRatio;
			combatDroneDurabilityRatio = historyData.combatDroneDurabilityRatio;
			combatDroneSpeedRatio = historyData.combatDroneSpeedRatio;
			enemyDropScale = historyData.enemyDropScale;
			combatShipDamageRatio = historyData.combatShipDamageRatio;
			combatShipROFRatio = historyData.combatShipROFRatio;
			combatShipDurabilityRatio = historyData.combatShipDurabilityRatio;
			combatShipSpeedRatio = historyData.combatShipSpeedRatio;
			planetaryATFieldEnergyRate = historyData.planetaryATFieldEnergyRate / Configs.freeMode.planetaryATFieldEnergyRate;
		}

		private bool CheckCondition()
		{
			return GameMain.mainPlayer != null && GameMain.mainPlayer.mecha != null && GameMain.history != null;
		}
	}
	public class SeedPlanetWater
	{
		public long seedKey64 { get; set; }

		public Dictionary<int, int> waterTypes { get; set; }

		public SeedPlanetWater()
		{
			waterTypes = new Dictionary<int, int>();
		}

		public SeedPlanetWater(long seed)
		{
			seedKey64 = seed;
			waterTypes = new Dictionary<int, int>();
		}

		public string ToStr()
		{
			string text = seedKey64 + ",";
			return text + string.Join("", waterTypes.Select((KeyValuePair<int, int> x) => x.Key + ":" + x.Value + "-"));
		}
	}
	public class VeinControlProperty
	{
		private int veinLines;

		private int cuttingveinNumbers;

		private bool AddVein;

		private bool deleteVein;

		private bool nottidyvein;

		private bool changeveinpos;

		private bool getallVein;

		private bool changeveingrouppos;

		private bool changexveinspos;

		private bool coolDown;

		private VeinData pointVeinData;

		public int AddVeinMode;

		public int VeinType;

		public bool[] OilAddIntervalBool;

		public int[] OilAddIntervalValue;

		public float OilAddInterval;

		public int Selectedveintype;

		public int AddVeinNumber;

		public int oillowerlimit;

		public int VeinLines
		{
			get
			{
				return veinLines;
			}
			set
			{
				veinLines = value;
				Multifunction.veinlines.Value = value;
			}
		}

		public bool CoolDown
		{
			get
			{
				return coolDown;
			}
			set
			{
				coolDown = value;
				if (value)
				{
					Task.Run(delegate
					{
						Thread.Sleep(1000);
						coolDown = false;
					});
				}
			}
		}

		public int CuttingVeinNumbers
		{
			get
			{
				return cuttingveinNumbers;
			}
			set
			{
				cuttingveinNumbers = value;
				Multifunction.CuttingVeinNumbers.Value = value;
			}
		}

		public bool DeleteVein
		{
			get
			{
				return deleteVein;
			}
			set
			{
				deleteVein = value;
				Multifunction.deleteveinbool.Value = value;
			}
		}

		public bool Changeveinpos
		{
			get
			{
				return changeveinpos;
			}
			set
			{
				if (value)
				{
					SetFalse();
				}
				changeveinpos = value;
			}
		}

		public bool Changeveingrouppos
		{
			get
			{
				return changeveingrouppos;
			}
			set
			{
				if (value)
				{
					SetFalse();
				}
				changeveingrouppos = value;
			}
		}

		public bool NotTidyVein
		{
			get
			{
				return nottidyvein;
			}
			set
			{
				nottidyvein = value;
			}
		}

		public bool GetallVein
		{
			get
			{
				return getallVein;
			}
			set
			{
				if (value)
				{
					SetFalse();
				}
				getallVein = value;
			}
		}

		public bool Changexveinspos
		{
			get
			{
				return changexveinspos;
			}
			set
			{
				if (value)
				{
					SetFalse();
				}
				changexveinspos = value;
			}
		}

		public VeinData PointVeinData
		{
			get
			{
				return pointVeinData;
			}
			set
			{
				pointVeinData = value;
			}
		}

		public void SetFalse()
		{
			VeinType = 0;
			Changeveinpos = false;
			Changeveingrouppos = false;
			GetallVein = false;
			Changexveinspos = false;
		}

		public VeinControlProperty()
		{
			OilAddIntervalBool = new bool[3];
			OilAddIntervalValue = new int[3] { 1, 10, 100 };
			SetOilAddInterval(1);
			AddVeinNumber = 1000000000;
		}

		internal void SetOilAddInterval(int selectedIndex)
		{
			OilAddInterval = OilAddIntervalValue[selectedIndex];
			for (int i = 0; i < 3; i++)
			{
				OilAddIntervalBool[i] = i == selectedIndex;
			}
		}

		public void ControlVein()
		{
			if (VeinType != 0 && !GameMain.mainPlayer.controller.actionBuild.dismantleTool.active)
			{
				if (AddVeinMode == 0 && Input.GetMouseButtonDown(0))
				{
					addvein(VeinType);
				}
				else if (AddVeinMode == 1 && Input.GetMouseButton(0))
				{
					addvein(VeinType);
				}
			}
			if (Input.GetMouseButton(0) && DeleteVein && GameMain.mainPlayer.controller.actionBuild.dismantleTool.active)
			{
				removevein();
			}
			if (Input.GetMouseButton(1))
			{
				SetFalse();
			}
			if (!Input.GetMouseButton(0) || GameMain.mainPlayer.controller.actionBuild.dismantleTool.active)
			{
				return;
			}
			if (Input.GetMouseButtonDown(0))
			{
				PointVeinData = getveinbymouse();
			}
			if (PointVeinData.amount != 0)
			{
				RaycastHit hitInfo;
				if (GetallVein)
				{
					GetAllVeinMethod(PointVeinData);
				}
				else if (Changeveingrouppos)
				{
					ChangeveingroupposMethod(PointVeinData);
				}
				else if (Changexveinspos)
				{
					changexveins(PointVeinData);
				}
				else if (Changeveinpos && Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
				{
					Vector3 point = hitInfo.point;
					ChangeveinposMethod(PointVeinData, point);
				}
			}
		}

		public void addvein(int veintype)
		{
			PlanetData localPlanet = GameMain.localPlanet;
			if (localPlanet == null || localPlanet.type == EPlanetType.Gas || !Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
			{
				return;
			}
			Vector3 point = hitInfo.point;
			int num = ((veintype == 7) ? ((int)(OilAddInterval * (float)oillowerlimit)) : AddVeinNumber);
			VeinData[] veinPool = localPlanet.factory.veinPool;
			for (int i = 0; i < veinPool.Length; i++)
			{
				VeinData veinData = veinPool[i];
				if (veinData.type == EVeinType.None || !((point - veinData.pos).magnitude < 1f))
				{
					continue;
				}
				if (veinData.type != EVeinType.Oil)
				{
					if (localPlanet.factory.veinPool[veinData.id].amount + num < 1000000000)
					{
						localPlanet.factory.veinPool[veinData.id].amount += num;
						localPlanet.factory.veinGroups[veinData.groupIndex].amount += num;
					}
					else
					{
						localPlanet.factory.veinGroups[veinData.groupIndex].amount += 1000000000 - localPlanet.factory.veinPool[veinData.id].amount;
						localPlanet.factory.veinPool[veinData.id].amount = 1000000000;
					}
				}
				else
				{
					localPlanet.factory.veinPool[veinData.id].amount += num;
					localPlanet.factory.veinGroups[veinData.groupIndex].amount += num;
				}
				return;
			}
			VeinData veinData2 = new VeinData
			{
				amount = num,
				type = (EVeinType)veintype,
				pos = point,
				productId = LDB.veins.Select(veintype).MiningItem,
				modelIndex = (short)LDB.veins.Select(veintype).ModelIndex
			};
			veinData2.id = localPlanet.factory.AddVeinData(veinData2);
			veinData2.colliderId = localPlanet.physics.AddColliderData(LDB.veins.Select(veintype).prefabDesc.colliders[0].BindToObject(veinData2.id, 0, EObjectType.Vein, veinData2.pos, Quaternion.FromToRotation(Vector3.up, veinData2.pos.normalized)));
			veinData2.modelId = localPlanet.factoryModel.gpuiManager.AddModel(veinData2.modelIndex, veinData2.id, veinData2.pos, Maths.SphericalRotation(veinData2.pos, UnityEngine.Random.value * 360f));
			veinData2.minerCount = 0;
			localPlanet.factory.AssignGroupIndexForNewVein(ref veinData2);
			localPlanet.factory.veinPool[veinData2.id] = veinData2;
			localPlanet.factory.RefreshVeinMiningDisplay(veinData2.id, 0, 0);
			localPlanet.factory.RecalculateVeinGroup(localPlanet.factory.veinPool[veinData2.id].groupIndex);
		}

		public void changexveins(VeinData vd)
		{
			PlanetData localPlanet = GameMain.localPlanet;
			if (localPlanet == null || localPlanet.type == EPlanetType.Gas || localPlanet == null || !Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
			{
				return;
			}
			if (localPlanet.factory.veinGroups[localPlanet.factory.veinPool[vd.id].groupIndex].count <= CuttingVeinNumbers)
			{
				ChangeveingroupposMethod(vd);
				return;
			}
			Vector3 point = hitInfo.point;
			VeinData[] veinPool = localPlanet.factory.veinPool;
			Vector3 pos = veinPool[vd.id].pos;
			bool flag = false;
			List<int> list = new List<int>();
			VeinData[] array = veinPool;
			for (int i = 0; i < array.Length; i++)
			{
				VeinData veinData = array[i];
				if (veinData.id <= 0 || veinData.groupIndex != vd.groupIndex)
				{
					continue;
				}
				int id = veinData.id;
				if (vd.id == id)
				{
					flag = true;
				}
				if (flag || list.Count != CuttingVeinNumbers - 1)
				{
					list.Add(veinData.id);
					if (list.Count == CuttingVeinNumbers)
					{
						break;
					}
				}
			}
			if (list.Count != CuttingVeinNumbers)
			{
				return;
			}
			int num = 0;
			foreach (int item in list)
			{
				veinPool[item].pos = (NotTidyVein ? point : PostionCompute(pos, point, veinPool[item].pos, num++));
				if (!float.IsNaN(veinPool[item].pos.x) && !float.IsNaN(veinPool[item].pos.y) && !float.IsNaN(veinPool[item].pos.z))
				{
					int colliderId = veinPool[item].colliderId;
					localPlanet.physics.RemoveColliderData(colliderId);
					veinPool[item].colliderId = localPlanet.physics.AddColliderData(LDB.veins.Select((int)veinPool[item].type).prefabDesc.colliders[0].BindToObject(item, 0, EObjectType.Vein, veinPool[item].pos, Quaternion.FromToRotation(Vector3.up, veinPool[item].pos.normalized)));
					localPlanet.factoryModel.gpuiManager.AlterModel(veinPool[item].modelIndex, veinPool[item].modelId, item, veinPool[item].pos, Maths.SphericalRotation(veinPool[item].pos, 90f));
				}
			}
			bool flag2 = true;
			VeinData[] array2 = veinPool;
			for (int j = 0; j < array2.Length; j++)
			{
				VeinData veinData2 = array2[j];
				if (!list.Contains(veinData2.id) && veinData2.type == vd.type && (localPlanet.factory.veinPool[vd.id].pos - veinData2.pos).magnitude < 5f)
				{
					flag2 = false;
					break;
				}
			}
			if (!flag2)
			{
				return;
			}
			int groupIndex = localPlanet.factory.veinPool[vd.id].groupIndex;
			localPlanet.factory.veinPool[vd.id].groupIndex = (short)localPlanet.factory.AddVeinGroup(vd.type, vd.pos.normalized);
			foreach (int item2 in list)
			{
				if (item2 != vd.id)
				{
					localPlanet.factory.veinPool[item2].groupIndex = localPlanet.factory.veinPool[vd.id].groupIndex;
				}
			}
			localPlanet.factory.RecalculateVeinGroup(localPlanet.factory.veinPool[vd.id].groupIndex);
			localPlanet.factory.RecalculateVeinGroup(groupIndex);
			localPlanet.factory.ArrangeVeinGroups();
		}

		public void ChangeveingroupposMethod(VeinData vd)
		{
			if (CoolDown)
			{
				return;
			}
			PlanetData localPlanet = GameMain.localPlanet;
			if (localPlanet == null || localPlanet.type == EPlanetType.Gas || !Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
			{
				return;
			}
			Vector3 point = hitInfo.point;
			VeinData[] veinPool = localPlanet.factory.veinPool;
			Vector3 pos = veinPool[vd.id].pos;
			int num = 0;
			VeinData[] array = veinPool;
			for (int i = 0; i < array.Length; i++)
			{
				VeinData veinData = array[i];
				if (veinData.id <= 0)
				{
					continue;
				}
				int id = veinData.id;
				if (veinData.groupIndex != veinPool[vd.id].groupIndex)
				{
					continue;
				}
				if (NotTidyVein)
				{
					veinPool[id].pos = point;
				}
				else
				{
					Vector3 vector = PostionCompute(pos, point, veinData.pos, num++, vd.type == EVeinType.Oil);
					if (CoolDown)
					{
						return;
					}
					if ((double)Vector3.Distance(vector, veinData.pos) < 0.01)
					{
						continue;
					}
					veinPool[id].pos = vector;
					if (float.IsNaN(veinPool[id].pos.x) || float.IsNaN(veinPool[id].pos.y) || float.IsNaN(veinPool[id].pos.z))
					{
						continue;
					}
				}
				int colliderId = veinPool[id].colliderId;
				localPlanet.physics.RemoveColliderData(colliderId);
				veinPool[id].colliderId = localPlanet.physics.AddColliderData(LDB.veins.Select((int)veinPool[id].type).prefabDesc.colliders[0].BindToObject(id, 0, EObjectType.Vein, veinPool[id].pos, Quaternion.FromToRotation(Vector3.up, veinPool[id].pos.normalized)));
				localPlanet.factoryModel.gpuiManager.AlterModel(veinPool[id].modelIndex, veinPool[id].modelId, id, veinPool[id].pos, Maths.SphericalRotation(veinPool[id].pos, 90f));
			}
			localPlanet.factory.veinGroups[veinPool[vd.id].groupIndex].pos = veinPool[vd.id].pos / (localPlanet.realRadius + 2.5f);
		}

		public void ChangeveinposMethod(VeinData vd, Vector3 pos)
		{
			PlanetData localPlanet = GameMain.localPlanet;
			int id = vd.id;
			if (localPlanet == null || localPlanet.type == EPlanetType.Gas)
			{
				return;
			}
			VeinData[] veinPool = localPlanet.factory.veinPool;
			veinPool[id].pos = pos;
			int colliderId = veinPool[id].colliderId;
			localPlanet.physics.RemoveColliderData(colliderId);
			veinPool[id].colliderId = localPlanet.physics.AddColliderData(LDB.veins.Select((int)veinPool[id].type).prefabDesc.colliders[0].BindToObject(id, 0, EObjectType.Vein, veinPool[id].pos, Quaternion.FromToRotation(Vector3.up, veinPool[id].pos.normalized)));
			localPlanet.factoryModel.gpuiManager.AlterModel(veinPool[id].modelIndex, veinPool[id].modelId, id, veinPool[id].pos, Maths.SphericalRotation(veinPool[id].pos, 90f));
			bool flag = false;
			int num = -1;
			if (localPlanet.factory.veinGroups[veinPool[id].groupIndex].count > 1)
			{
				if ((double)(pos - localPlanet.factory.veinGroups[veinPool[id].groupIndex].pos * (localPlanet.realRadius + 2.5f)).magnitude > 10.0)
				{
					flag = true;
					num = veinPool[id].groupIndex;
					veinPool[id].groupIndex = -1;
				}
			}
			else
			{
				localPlanet.factory.veinGroups[veinPool[id].groupIndex].pos = veinPool[id].pos / (localPlanet.realRadius + 2.5f);
				VeinData[] veinPool2 = localPlanet.factory.veinPool;
				for (int i = 0; i < veinPool2.Length; i++)
				{
					VeinData veinData = veinPool2[i];
					if (veinData.type == veinPool[id].type && veinData.groupIndex != num && (veinData.pos - veinPool[id].pos).magnitude < 10f)
					{
						num = veinPool[id].groupIndex;
						veinPool[id].groupIndex = veinData.groupIndex;
						localPlanet.factory.RecalculateVeinGroup(num);
					}
				}
			}
			if (flag)
			{
				localPlanet.factory.RecalculateVeinGroup(num);
				VeinData[] veinPool3 = localPlanet.factory.veinPool;
				for (int j = 0; j < veinPool3.Length; j++)
				{
					VeinData veinData2 = veinPool3[j];
					if (veinData2.type == veinPool[id].type && veinData2.groupIndex != num && (veinData2.pos - veinPool[id].pos).magnitude < 10f)
					{
						veinPool[id].groupIndex = veinData2.groupIndex;
					}
				}
				if (veinPool[id].groupIndex == -1)
				{
					veinPool[id].groupIndex = (short)localPlanet.factory.AddVeinGroup(veinPool[id].type, veinPool[id].pos.normalized);
				}
			}
			localPlanet.factory.RecalculateVeinGroup(veinPool[id].groupIndex);
			localPlanet.factory.ArrangeVeinGroups();
		}

		public void GetAllVeinMethod(VeinData vd)
		{
			PlanetData localPlanet = GameMain.localPlanet;
			if (localPlanet == null || localPlanet.type == EPlanetType.Gas || !Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
			{
				return;
			}
			Vector3 point = hitInfo.point;
			VeinData[] veinPool = localPlanet.factory.veinPool;
			Vector3 pos = veinPool[vd.id].pos;
			int num = 0;
			VeinData[] array = veinPool;
			for (int i = 0; i < array.Length; i++)
			{
				VeinData veinData = array[i];
				if (veinData.id <= 0 || veinData.type != vd.type)
				{
					continue;
				}
				int id = veinData.id;
				veinPool[id].pos = (NotTidyVein ? point : PostionCompute(pos, point, veinData.pos, num++, vd.type == EVeinType.Oil));
				if (CoolDown)
				{
					return;
				}
				if (!float.IsNaN(veinPool[id].pos.x) && !float.IsNaN(veinPool[id].pos.y) && !float.IsNaN(veinPool[id].pos.z))
				{
					if (veinData.groupIndex != vd.groupIndex)
					{
						int groupIndex = veinPool[veinData.id].groupIndex;
						veinPool[veinData.id].groupIndex = vd.groupIndex;
						localPlanet.factory.RecalculateVeinGroup(groupIndex);
						localPlanet.factory.RecalculateVeinGroup(vd.groupIndex);
						localPlanet.factory.ArrangeVeinGroups();
					}
					int colliderId = veinPool[id].colliderId;
					localPlanet.physics.RemoveColliderData(colliderId);
					veinPool[id].colliderId = localPlanet.physics.AddColliderData(LDB.veins.Select((int)veinPool[id].type).prefabDesc.colliders[0].BindToObject(id, 0, EObjectType.Vein, veinPool[id].pos, Quaternion.FromToRotation(Vector3.up, veinPool[id].pos.normalized)));
					localPlanet.factoryModel.gpuiManager.AlterModel(veinPool[id].modelIndex, veinPool[id].modelId, id, veinPool[id].pos, Maths.SphericalRotation(veinPool[id].pos, 90f));
				}
			}
			localPlanet.factory.RecalculateVeinGroup(vd.groupIndex);
			localPlanet.factory.ArrangeVeinGroups();
		}

		public void removevein()
		{
			PlanetData localPlanet = GameMain.localPlanet;
			if (localPlanet == null || localPlanet.type == EPlanetType.Gas || !Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
			{
				return;
			}
			Vector3 point = hitInfo.point;
			VeinData[] veinPool = localPlanet.factory.veinPool;
			for (int i = 0; i < veinPool.Length; i++)
			{
				VeinData veinData = veinPool[i];
				if ((point - veinData.pos).magnitude < 1f && veinData.type != EVeinType.None)
				{
					localPlanet.factory.veinGroups[veinData.groupIndex].count--;
					localPlanet.factory.veinGroups[veinData.groupIndex].amount -= veinData.amount;
					localPlanet.factory.RemoveVeinWithComponents(veinData.id);
					if (localPlanet.factory.veinGroups[veinData.groupIndex].count == 0)
					{
						localPlanet.factory.veinGroups[veinData.groupIndex].type = EVeinType.None;
						localPlanet.factory.veinGroups[veinData.groupIndex].amount = 0L;
						localPlanet.factory.veinGroups[veinData.groupIndex].pos = Vector3.zero;
					}
					break;
				}
			}
		}

		public VeinData getveinbymouse()
		{
			PlanetData localPlanet = GameMain.localPlanet;
			if (localPlanet != null && localPlanet.type != EPlanetType.Gas && Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
			{
				Vector3 point = hitInfo.point;
				float num = 100f;
				VeinData result = default(VeinData);
				VeinData[] veinPool = localPlanet.factory.veinPool;
				for (int i = 0; i < veinPool.Length; i++)
				{
					VeinData veinData = veinPool[i];
					if (veinData.id != 0 && (point - veinData.pos).magnitude < num && veinData.type != EVeinType.None)
					{
						num = (point - veinData.pos).magnitude;
						result = veinData;
					}
				}
				if (num > 4f)
				{
					return default(VeinData);
				}
				return result;
			}
			return default(VeinData);
		}

		public Vector3 PostionCompute(Vector3 begin, Vector3 end, Vector3 pointpos, int index, bool oil = false)
		{
			if (end.y > 193f || end.y < -193f)
			{
				UIMessageBox.Show("移动矿堆失败".Translate(), "当前纬度过高，为避免出错，无法移动矿堆".Translate(), "确定".Translate(), 3);
				CoolDown = true;
				return pointpos;
			}
			Vector3 vector = begin;
			Vector3 vector2 = end;
			float realRadius = GameMain.localPlanet.realRadius;
			Quaternion quaternion = Maths.SphericalRotation(vector, 0f);
			float num = (oil ? 15f : 1.5f);
			Vector3 result;
			if (!oil)
			{
				vector2.x = (int)vector2.x;
				vector2.z = (int)vector2.z;
				vector2.y = (int)vector2.y;
				result = vector + quaternion * (new Vector3(index / VeinLines, 0f, index % VeinLines) * num);
			}
			else
			{
				result = vector - quaternion * new Vector3(index / VeinLines * 8, 0f, (float)(index % VeinLines) * num);
			}
			double num2 = Math.Atan(vector.z / vector.x) - Math.Atan(vector2.z / vector2.x);
			double num3 = Math.Acos(vector.y / realRadius) - Math.Acos(vector2.y / realRadius);
			double num4 = 0.0 - Math.Atan(result.z / result.x) + num2;
			double num5 = Math.Acos(result.y / realRadius) - num3;
			if (num2 == double.NaN || num3 == double.NaN || num4 == double.NaN || num5 == double.NaN)
			{
				return pointpos;
			}
			result.x = (float)((end.x < 0f) ? (0.0 - Math.Abs(Math.Sin(num5) * Math.Cos(num4))) : Math.Abs(Math.Sin(num5) * Math.Cos(num4)));
			result.y = (float)((end.y < 0f) ? (0.0 - Math.Abs(Math.Cos(num5))) : Math.Abs(Math.Cos(num5)));
			result.z = (float)((end.z < 0f) ? (0.0 - Math.Abs(Math.Sin(num5) * Math.Sin(num4))) : Math.Abs(Math.Sin(num5) * Math.Sin(num4)));
			result.x *= realRadius;
			result.y *= realRadius;
			result.z *= realRadius;
			if (result.x == float.NaN || result.y == float.NaN || result.z == float.NaN || result.y > 190f || result.y < -190f)
			{
				return pointpos;
			}
			return result;
		}

		public void BuryAllvein()
		{
			PlanetData localPlanet = GameMain.localPlanet;
			if (localPlanet != null && localPlanet.type != EPlanetType.Gas)
			{
				float num = localPlanet.realRadius - 50f;
				VeinData[] veinPool = localPlanet.factory.veinPool;
				for (int i = 0; i < veinPool.Length; i++)
				{
					VeinData veinData = veinPool[i];
					PlanetPhysics physics = localPlanet.physics;
					int id = veinData.id;
					int colliderId = veinData.colliderId;
					Vector3 pos = physics.GetColliderData(colliderId).pos.normalized * (num + 0.4f);
					physics.colChunks[colliderId >> 20].colliderPool[colliderId & 0xFFFFF].pos = pos;
					ref VeinData reference = ref localPlanet.factory.veinPool[id];
					Vector3 pos2 = veinData.pos;
					reference.pos = pos2.normalized * num;
				}
				VeinData[] veinPool2 = localPlanet.factory.veinPool;
				for (int j = 0; j < veinPool2.Length; j++)
				{
					VeinData veinData2 = veinPool2[j];
					GameMain.gpuiManager.AlterModel(veinData2.modelIndex, veinData2.modelId, veinData2.id, veinData2.pos, setBuffer: false);
				}
				GameMain.gpuiManager.SyncAllGPUBuffer();
			}
		}

		public void RemoveAllvein()
		{
			PlanetData localPlanet = GameMain.localPlanet;
			if (localPlanet == null || localPlanet.type == EPlanetType.Gas)
			{
				return;
			}
			VeinData[] veinPool = localPlanet.factory.veinPool;
			for (int i = 0; i < veinPool.Length; i++)
			{
				VeinData veinData = veinPool[i];
				if (veinData.type != EVeinType.None)
				{
					localPlanet.factory.veinGroups[veinData.groupIndex].count--;
					localPlanet.factory.veinGroups[veinData.groupIndex].amount -= veinData.amount;
					localPlanet.factory.RemoveVeinWithComponents(veinData.id);
					if (localPlanet.factory.veinGroups[veinData.groupIndex].count == 0)
					{
						localPlanet.factory.veinGroups[veinData.groupIndex].type = EVeinType.None;
						localPlanet.factory.veinGroups[veinData.groupIndex].amount = 0L;
						localPlanet.factory.veinGroups[veinData.groupIndex].pos = Vector3.zero;
					}
				}
			}
			localPlanet.factory.ArrangeVeinGroups();
		}
	}
}
namespace Multifunction_mod.API
{
	public class ExternalMenu
	{
		public string Name { get; set; }

		public Action OnDraw { get; set; }
	}
	public static class MultifunctionAPI
	{
		private static List<ExternalMenu> _externalMenus = new List<ExternalMenu>();

		public static List<ExternalMenu> ExternalMenus => _externalMenus;

		public static void ClearMenus()
		{
			_externalMenus.Clear();
		}

		public static void RegisterMenu(string name, Action onDraw)
		{
			if (string.IsNullOrEmpty(name) || onDraw == null)
			{
				UnityEngine.Debug.LogWarning("[MultifunctionAPI] RegisterMenu failed: name or onDraw is null.");
				return;
			}
			if (_externalMenus.Exists((ExternalMenu m) => m.Name == name))
			{
				UnityEngine.Debug.LogWarning("[MultifunctionAPI] Menu '" + name + "' is already registered.");
				return;
			}
			_externalMenus.Add(new ExternalMenu
			{
				Name = name,
				OnDraw = onDraw
			});
			UnityEngine.Debug.Log("[MultifunctionAPI] Registered menu: " + name);
		}

		public static void UnregisterMenu(string name)
		{
			_externalMenus.RemoveAll((ExternalMenu m) => m.Name == name);
		}
	}
}
