using System;

namespace Multifunction_mod.API;

public class ExternalMenu
{
	public string Name { get; set; }

	public Action OnDraw { get; set; }
}
