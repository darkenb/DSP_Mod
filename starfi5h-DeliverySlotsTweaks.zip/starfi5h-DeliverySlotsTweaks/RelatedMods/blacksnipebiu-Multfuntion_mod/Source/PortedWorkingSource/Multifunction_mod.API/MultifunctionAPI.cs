using System;
using System.Collections.Generic;
using UnityEngine;

namespace Multifunction_mod.API;

public static class MultifunctionAPI
{
	private static List<ExternalMenu> _externalMenus = new List<ExternalMenu>();

	public static List<ExternalMenu> ExternalMenus => _externalMenus;

	public static void ClearMenus()
	{
		_externalMenus.Clear();
	}

	public static void RegisterMenu(string name, Action onDraw)
	{
		if (string.IsNullOrEmpty(name) || onDraw == null)
		{
			Debug.LogWarning("[MultifunctionAPI] RegisterMenu failed: name or onDraw is null.");
			return;
		}
		if (_externalMenus.Exists((ExternalMenu m) => m.Name == name))
		{
			Debug.LogWarning("[MultifunctionAPI] Menu '" + name + "' is already registered.");
			return;
		}
		_externalMenus.Add(new ExternalMenu
		{
			Name = name,
			OnDraw = onDraw
		});
		Debug.Log("[MultifunctionAPI] Registered menu: " + name);
	}

	public static void UnregisterMenu(string name)
	{
		_externalMenus.RemoveAll((ExternalMenu m) => m.Name == name);
	}
}
