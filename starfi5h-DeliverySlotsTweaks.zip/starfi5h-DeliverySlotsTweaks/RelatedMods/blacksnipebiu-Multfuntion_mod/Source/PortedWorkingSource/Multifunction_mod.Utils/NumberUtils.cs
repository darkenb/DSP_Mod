using System;

namespace Multifunction_mod.Utils;

public static class NumberUtils
{
	public static float ConvertToNumber(string input)
	{
		string text = "";
		string text2 = "";
		bool flag = false;
		for (int i = 0; i < input.Length; i++)
		{
			char c = input[i];
			if (char.IsDigit(c))
			{
				text += c;
			}
			else if (c == '.')
			{
				if (!flag)
				{
					flag = true;
					text += c;
				}
			}
			else
			{
				text2 += c;
			}
		}
		input = text2;
		string text3 = input.Replace(text, "").Replace(".", "").Replace("W", "")
			.Replace("J", "");
		if (float.TryParse(text, out var result))
		{
			string text4 = text3;
			string text5 = text4;
			if (text5 == null || text5.Length != 0)
			{
				switch (text5)
				{
				case "K":
					result *= 1000f;
					break;
				case "M":
					result *= 1000000f;
					break;
				case "G":
					result *= 1E+09f;
					break;
				case "T":
					result *= 1E+12f;
					break;
				}
			}
			return result;
		}
		return 0f;
	}

	public static int IntParseLimit(string valueStr, int lowlimit, int highlimit)
	{
		int.TryParse(valueStr, out var result);
		return Math.Max(lowlimit, Math.Min(result, highlimit));
	}

	public static string TGMKinttostring(double num, string unit)
	{
		double num2 = num;
		int num3 = 0;
		if (num < 1000.0)
		{
			return num + unit;
		}
		while (num2 >= 999.9)
		{
			num3++;
			num2 /= 1000.0;
		}
		string text = $"{num2:N2}";
		return num3 switch
		{
			0 => text + unit, 
			1 => text + "K" + unit, 
			2 => text + "M" + unit, 
			3 => text + "G" + unit, 
			4 => text + "T" + unit, 
			_ => "", 
		};
	}
}
