namespace Multifunction_mod.Models;

public class PropertyData
{
	private float walkSpeed;

	private float techSpeed;

	private float droneSpeed;

	private float droneMovement;

	private float droneCount;

	private float maxSailSpeed;

	private float maxWarpSpeed;

	private float buildArea;

	private float reactorPowerGen;

	private float logisticCourierSpeed;

	private float logisticDroneSpeedScale;

	private float logisticShipSpeedScale;

	private float logisticCourierCarries;

	private float logisticDroneCarries;

	private float logisticShipCarries;

	private float miningCostRate;

	private float miningSpeedScale;

	private float labLevel;

	private float storageLevel;

	private float stackSizeMultiplier;

	private float kineticDamageScale;

	private float energyDamageScale;

	private float blastDamageScale;

	private float magneticDamageScale;

	private float globalHpEnhancement;

	private float energyShieldRadius;

	private long energyShieldCapacity;

	private float combatDroneDamageRatio;

	private float combatDroneROFRatio;

	private float combatDroneDurabilityRatio;

	private float enemyDropScale;

	private float combatDroneSpeedRatio;

	private float combatShipSpeedRatio;

	private float combatShipDamageRatio;

	private float combatShipROFRatio;

	private float combatShipDurabilityRatio;

	private float planetaryATFieldEnergyRate;

	private int hpMaxUpgrade;

	private float laserAttackLocalRange;

	private float laserAttackSpaceRange;

	private float laserAttackDamage;

	private float laserEnergyCapacity;

	private float laserEnergyCost;

	public float WalkSpeed
	{
		get
		{
			return walkSpeed;
		}
		set
		{
			if (value != 0f && value != walkSpeed)
			{
				walkSpeed = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.walkSpeed = value;
				}
			}
		}
	}

	public float TechSpeed
	{
		get
		{
			return techSpeed;
		}
		set
		{
			if (value != 0f && value != techSpeed)
			{
				techSpeed = value;
				if (CheckCondition())
				{
					GameMain.history.techSpeed = (int)value;
				}
			}
		}
	}

	public float DroneSpeed
	{
		get
		{
			return droneSpeed;
		}
		set
		{
			if (value != 0f && value != droneSpeed)
			{
				droneSpeed = value;
				if (CheckCondition())
				{
					GameMain.history.constructionDroneSpeed = value;
				}
			}
		}
	}

	public float DroneCount
	{
		get
		{
			return droneCount;
		}
		set
		{
			if (value != 0f && value != droneCount)
			{
				droneCount = value;
				if (CheckCondition())
				{
					int num = (int)(value - (float)GameMain.mainPlayer.mecha.constructionModule.droneCount);
					GameMain.mainPlayer.mecha.constructionModule.droneCount += num;
					GameMain.mainPlayer.mecha.constructionModule.droneAliveCount += num;
					GameMain.mainPlayer.mecha.constructionModule.droneIdleCount += num;
				}
			}
		}
	}

	public float MaxSailSpeed
	{
		get
		{
			return maxSailSpeed;
		}
		set
		{
			if (value != 0f && value != maxSailSpeed)
			{
				maxSailSpeed = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.maxSailSpeed = (int)value * 1000;
				}
			}
		}
	}

	public float MaxWarpSpeed
	{
		get
		{
			return maxWarpSpeed;
		}
		set
		{
			if (value != 0f && value != maxWarpSpeed)
			{
				maxWarpSpeed = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.maxWarpSpeed = (int)value * 1000 * 480;
				}
			}
		}
	}

	public float BuildArea
	{
		get
		{
			return buildArea;
		}
		set
		{
			if (value != 0f && value != buildArea)
			{
				buildArea = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.buildArea = value;
				}
			}
		}
	}

	public float ReactorPowerGen
	{
		get
		{
			return reactorPowerGen;
		}
		set
		{
			if (value != 0f && value != reactorPowerGen)
			{
				reactorPowerGen = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.reactorPowerGen = value;
				}
			}
		}
	}

	public float LogisticCourierSpeed
	{
		get
		{
			return logisticCourierSpeed;
		}
		set
		{
			if (value != 0f && value != logisticCourierSpeed)
			{
				logisticCourierSpeed = value;
				if (CheckCondition())
				{
					GameMain.history.logisticCourierSpeed = (int)value;
				}
			}
		}
	}

	public float LogisticDroneSpeedScale
	{
		get
		{
			return logisticDroneSpeedScale;
		}
		set
		{
			if (value != 0f && value != logisticDroneSpeedScale)
			{
				logisticDroneSpeedScale = value;
				if (CheckCondition())
				{
					GameMain.history.logisticDroneSpeedScale = value;
				}
			}
		}
	}

	public float LogisticShipSpeedScale
	{
		get
		{
			return logisticShipSpeedScale;
		}
		set
		{
			if (value != 0f && value != logisticShipSpeedScale)
			{
				logisticShipSpeedScale = value;
				if (CheckCondition())
				{
					GameMain.history.logisticShipSpeedScale = value;
				}
			}
		}
	}

	public float LogisticCourierCarries
	{
		get
		{
			return logisticCourierCarries;
		}
		set
		{
			if (value != 0f && value != logisticCourierCarries)
			{
				logisticCourierCarries = value;
				if (CheckCondition())
				{
					GameMain.history.logisticCourierCarries = (int)value;
				}
			}
		}
	}

	public float LogisticDroneCarries
	{
		get
		{
			return logisticDroneCarries;
		}
		set
		{
			if (value != 0f && value != logisticDroneCarries)
			{
				logisticDroneCarries = (int)(value / 50f) * 50;
				if (CheckCondition())
				{
					GameMain.history.logisticDroneCarries = (int)value;
				}
			}
		}
	}

	public float LogisticShipCarries
	{
		get
		{
			return logisticShipCarries;
		}
		set
		{
			if (value != 0f && value != logisticShipCarries)
			{
				logisticShipCarries = (int)(value / 500f) * 500;
				if (CheckCondition())
				{
					GameMain.history.logisticShipCarries = (int)value;
				}
			}
		}
	}

	public float MiningCostRate
	{
		get
		{
			return miningCostRate;
		}
		set
		{
			if (value != 0f && value != miningCostRate)
			{
				miningCostRate = value;
				if (CheckCondition())
				{
					GameMain.history.miningCostRate = value;
				}
			}
		}
	}

	public float MiningSpeedScale
	{
		get
		{
			return miningSpeedScale;
		}
		set
		{
			if (value != 0f && value != miningSpeedScale)
			{
				miningSpeedScale = value;
				if (CheckCondition())
				{
					GameMain.history.miningSpeedScale = value;
				}
			}
		}
	}

	public float LabLevel
	{
		get
		{
			return labLevel;
		}
		set
		{
			if (value != 0f && value != labLevel)
			{
				labLevel = value;
				if (CheckCondition())
				{
					GameMain.history.storageLevel = (int)value;
					GameMain.history.labLevel = (int)value;
				}
			}
		}
	}

	public float StorageLevel
	{
		get
		{
			return storageLevel;
		}
		set
		{
			if (value != 0f && value != storageLevel)
			{
				storageLevel = value;
				if (CheckCondition())
				{
					GameMain.history.stationPilerLevel = (int)value;
				}
			}
		}
	}

	public float StackSizeMultiplier
	{
		get
		{
			return stackSizeMultiplier;
		}
		set
		{
			if (value != 0f && value != stackSizeMultiplier)
			{
				stackSizeMultiplier = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.deliveryPackage.stackSizeMultiplier = (int)value;
				}
			}
		}
	}

	public float KineticDamageScale
	{
		get
		{
			return kineticDamageScale;
		}
		set
		{
			if (value != 0f && value != kineticDamageScale)
			{
				kineticDamageScale = value;
				if (CheckCondition())
				{
					GameMain.history.kineticDamageScale = value;
				}
			}
		}
	}

	public float EnergyDamageScale
	{
		get
		{
			return energyDamageScale;
		}
		set
		{
			if (value != 0f && value != energyDamageScale)
			{
				energyDamageScale = value;
				if (CheckCondition())
				{
					GameMain.history.energyDamageScale = value;
				}
			}
		}
	}

	public float BlastDamageScale
	{
		get
		{
			return blastDamageScale;
		}
		set
		{
			if (value != 0f && value != blastDamageScale)
			{
				blastDamageScale = value;
				if (CheckCondition())
				{
					GameMain.history.blastDamageScale = value;
				}
			}
		}
	}

	public float MagneticDamageScale
	{
		get
		{
			return magneticDamageScale;
		}
		set
		{
			if (value != 0f && value != magneticDamageScale)
			{
				magneticDamageScale = value;
				if (CheckCondition())
				{
					GameMain.history.magneticDamageScale = value;
				}
			}
		}
	}

	public float GlobalHpEnhancement
	{
		get
		{
			return globalHpEnhancement;
		}
		set
		{
			if (value != 0f && value != globalHpEnhancement)
			{
				globalHpEnhancement = value;
				if (CheckCondition())
				{
					GameMain.history.globalHpEnhancement = value;
				}
			}
		}
	}

	public float EnergyShieldRadius
	{
		get
		{
			return energyShieldRadius;
		}
		set
		{
			if (value != 0f && value != energyShieldRadius)
			{
				energyShieldRadius = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.energyShieldRadius = value;
				}
			}
		}
	}

	public long EnergyShieldCapacity
	{
		get
		{
			return energyShieldCapacity;
		}
		set
		{
			if (value != 0L && value != energyShieldCapacity)
			{
				if (value > 990000000000L)
				{
					value = 1000000000000L;
				}
				if (value < 1000)
				{
					value = 0L;
				}
				energyShieldCapacity = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.energyShieldCapacity = value;
				}
			}
		}
	}

	public float CombatDroneDamageRatio
	{
		get
		{
			return combatDroneDamageRatio;
		}
		set
		{
			if (value != 0f && value != combatDroneDamageRatio)
			{
				combatDroneDamageRatio = value;
				if (CheckCondition())
				{
					GameMain.history.combatDroneDamageRatio = value;
				}
			}
		}
	}

	public float CombatDroneROFRatio
	{
		get
		{
			return combatDroneROFRatio;
		}
		set
		{
			if (value != 0f && value != combatDroneROFRatio)
			{
				combatDroneROFRatio = value;
				if (CheckCondition())
				{
					GameMain.history.combatDroneROFRatio = value;
				}
			}
		}
	}

	public float CombatDroneDurabilityRatio
	{
		get
		{
			return combatDroneDurabilityRatio;
		}
		set
		{
			if (value != 0f && value != combatDroneDurabilityRatio)
			{
				combatDroneDurabilityRatio = value;
				if (CheckCondition())
				{
					GameMain.history.combatDroneDurabilityRatio = value;
				}
			}
		}
	}

	public float EnemyDropScale
	{
		get
		{
			return enemyDropScale;
		}
		set
		{
			if (value != 0f && value != enemyDropScale)
			{
				enemyDropScale = value;
				if (CheckCondition())
				{
					GameMain.history.enemyDropScale = value;
				}
			}
		}
	}

	public float CombatDroneSpeedRatio
	{
		get
		{
			return combatDroneSpeedRatio;
		}
		set
		{
			if (value != 0f && value != combatDroneSpeedRatio)
			{
				combatDroneSpeedRatio = value;
				if (CheckCondition())
				{
					GameMain.history.combatDroneSpeedRatio = value;
				}
			}
		}
	}

	public float CombatShipSpeedRatio
	{
		get
		{
			return combatShipSpeedRatio;
		}
		set
		{
			if (value != 0f && value != combatShipSpeedRatio)
			{
				combatShipSpeedRatio = value;
				if (CheckCondition())
				{
					GameMain.history.combatShipSpeedRatio = value;
				}
			}
		}
	}

	public float CombatShipDamageRatio
	{
		get
		{
			return combatShipDamageRatio;
		}
		set
		{
			if (value != 0f && value != combatShipDamageRatio)
			{
				combatShipDamageRatio = value;
				if (CheckCondition())
				{
					GameMain.history.combatShipDamageRatio = value;
				}
			}
		}
	}

	public float CombatShipROFRatio
	{
		get
		{
			return combatShipROFRatio;
		}
		set
		{
			if (value != 0f && value != combatShipROFRatio)
			{
				combatShipROFRatio = value;
				if (CheckCondition())
				{
					GameMain.history.combatShipROFRatio = value;
				}
			}
		}
	}

	public float CombatShipDurabilityRatio
	{
		get
		{
			return combatShipDurabilityRatio;
		}
		set
		{
			if (value != 0f && value != combatShipDurabilityRatio)
			{
				combatShipDurabilityRatio = value;
				if (CheckCondition())
				{
					GameMain.history.combatShipDurabilityRatio = value;
				}
			}
		}
	}

	public float PlanetaryATFieldEnergyRate
	{
		get
		{
			return planetaryATFieldEnergyRate;
		}
		set
		{
			if (value != 0f && value != planetaryATFieldEnergyRate)
			{
				planetaryATFieldEnergyRate = value;
				if (CheckCondition())
				{
					GameMain.history.planetaryATFieldEnergyRate = (long)value * Configs.freeMode.planetaryATFieldEnergyRate;
				}
			}
		}
	}

	public int HpMaxUpgrade
	{
		get
		{
			return hpMaxUpgrade;
		}
		set
		{
			if (value != 0 && value != hpMaxUpgrade)
			{
				if (value < 100)
				{
					value = 0;
				}
				hpMaxUpgrade = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.hpMaxUpgrade = value * 100;
				}
			}
		}
	}

	public float LaserAttackLocalRange
	{
		get
		{
			return laserAttackLocalRange;
		}
		set
		{
			if (value != 0f && value != laserAttackLocalRange)
			{
				laserAttackLocalRange = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.laserLocalAttackRange = (int)value;
				}
			}
		}
	}

	public float LaserAttackSpaceRange
	{
		get
		{
			return laserAttackSpaceRange;
		}
		set
		{
			if (value != 0f && value != laserAttackSpaceRange)
			{
				laserAttackSpaceRange = value / 10f * 10f;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.laserSpaceAttackRange = (int)value;
				}
			}
		}
	}

	public float LaserAttackDamage
	{
		get
		{
			return laserAttackDamage;
		}
		set
		{
			if (value != 0f && value != laserAttackDamage)
			{
				if (value < 5f)
				{
					value = 0f;
				}
				laserAttackDamage = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.laserLocalDamage = (int)value * 100;
					GameMain.mainPlayer.mecha.laserSpaceDamage = (int)value * 100;
				}
			}
		}
	}

	public float LaserEnergyCapacity
	{
		get
		{
			return laserEnergyCapacity;
		}
		set
		{
			if (value != 0f && value != laserEnergyCapacity)
			{
				if (value < 1000f)
				{
					value = 0f;
				}
				laserEnergyCapacity = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.laserEnergyCapacity = (int)value;
				}
			}
		}
	}

	public float LaserEnergyCost
	{
		get
		{
			return laserEnergyCost;
		}
		set
		{
			if (value != 0f && value != laserEnergyCost)
			{
				if (value < 10f)
				{
					value = 0f;
				}
				laserEnergyCost = value;
				if (CheckCondition())
				{
					GameMain.mainPlayer.mecha.laserLocalEnergyCost = (int)value;
					GameMain.mainPlayer.mecha.laserSpaceEnergyCost = (int)value;
				}
			}
		}
	}

	public void SetContent(Mecha mecha, GameHistoryData historyData, int stackSizeMultiplier)
	{
		walkSpeed = mecha.walkSpeed;
		techSpeed = historyData.techSpeed;
		droneSpeed = historyData.constructionDroneSpeed;
		droneMovement = historyData.constructionDroneMovement;
		droneCount = mecha.constructionModule.droneCount;
		maxSailSpeed = mecha.maxSailSpeed / 1000f;
		maxWarpSpeed = mecha.maxWarpSpeed / 480000f;
		buildArea = mecha.buildArea;
		reactorPowerGen = (float)mecha.reactorPowerGen;
		logisticCourierSpeed = ((historyData.logisticCourierSpeed > 0f) ? historyData.logisticCourierSpeed : 6f);
		logisticDroneSpeedScale = ((historyData.logisticDroneSpeedScale > 0f) ? historyData.logisticDroneSpeedScale : 3f);
		logisticShipSpeedScale = ((historyData.logisticShipSpeedScale > 0f) ? historyData.logisticShipSpeedScale : 5f);
		logisticCourierCarries = ((historyData.logisticCourierCarries > 0) ? historyData.logisticDroneCarries : 3);
		logisticDroneCarries = ((historyData.logisticDroneCarries > 0) ? historyData.logisticDroneCarries : 100);
		logisticShipCarries = ((historyData.logisticShipCarries > 0) ? historyData.logisticShipCarries : 100);
		miningCostRate = historyData.miningCostRate;
		miningSpeedScale = historyData.miningSpeedScale;
		labLevel = historyData.labLevel;
		storageLevel = historyData.storageLevel;
		globalHpEnhancement = historyData.globalHpEnhancement;
		this.stackSizeMultiplier = stackSizeMultiplier;
		kineticDamageScale = historyData.kineticDamageScale;
		energyDamageScale = historyData.energyDamageScale;
		blastDamageScale = historyData.blastDamageScale;
		magneticDamageScale = historyData.magneticDamageScale;
		energyShieldRadius = mecha.energyShieldRadius;
		energyShieldCapacity = mecha.energyShieldCapacity;
		hpMaxUpgrade = mecha.hpMaxUpgrade / 100;
		laserAttackLocalRange = mecha.laserLocalAttackRange;
		laserAttackSpaceRange = mecha.laserSpaceAttackRange;
		laserAttackDamage = mecha.laserLocalDamage / 100;
		laserEnergyCapacity = mecha.laserEnergyCapacity;
		laserEnergyCost = mecha.laserLocalEnergyCost;
		combatDroneDamageRatio = historyData.combatDroneDamageRatio;
		combatDroneROFRatio = historyData.combatDroneROFRatio;
		combatDroneDurabilityRatio = historyData.combatDroneDurabilityRatio;
		combatDroneSpeedRatio = historyData.combatDroneSpeedRatio;
		enemyDropScale = historyData.enemyDropScale;
		combatShipDamageRatio = historyData.combatShipDamageRatio;
		combatShipROFRatio = historyData.combatShipROFRatio;
		combatShipDurabilityRatio = historyData.combatShipDurabilityRatio;
		combatShipSpeedRatio = historyData.combatShipSpeedRatio;
		planetaryATFieldEnergyRate = historyData.planetaryATFieldEnergyRate / Configs.freeMode.planetaryATFieldEnergyRate;
	}

	private bool CheckCondition()
	{
		return GameMain.mainPlayer != null && GameMain.mainPlayer.mecha != null && GameMain.history != null;
	}
}
