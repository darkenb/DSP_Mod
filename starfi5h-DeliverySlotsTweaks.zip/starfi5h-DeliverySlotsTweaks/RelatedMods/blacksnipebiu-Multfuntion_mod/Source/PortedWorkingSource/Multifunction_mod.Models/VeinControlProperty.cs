using System;
using System.Collections.Generic;
using System.Threading;
using System.Threading.Tasks;
using UnityEngine;

namespace Multifunction_mod.Models;

public class VeinControlProperty
{
	private int veinLines;

	private int cuttingveinNumbers;

	private bool AddVein;

	private bool deleteVein;

	private bool nottidyvein;

	private bool changeveinpos;

	private bool getallVein;

	private bool changeveingrouppos;

	private bool changexveinspos;

	private bool coolDown;

	private VeinData pointVeinData;

	public int AddVeinMode;

	public int VeinType;

	public bool[] OilAddIntervalBool;

	public int[] OilAddIntervalValue;

	public float OilAddInterval;

	public int Selectedveintype;

	public int AddVeinNumber;

	public int oillowerlimit;

	public int VeinLines
	{
		get
		{
			return veinLines;
		}
		set
		{
			veinLines = value;
			Multifunction.veinlines.Value = value;
		}
	}

	public bool CoolDown
	{
		get
		{
			return coolDown;
		}
		set
		{
			coolDown = value;
			if (value)
			{
				Task.Run(delegate
				{
					Thread.Sleep(1000);
					coolDown = false;
				});
			}
		}
	}

	public int CuttingVeinNumbers
	{
		get
		{
			return cuttingveinNumbers;
		}
		set
		{
			cuttingveinNumbers = value;
			Multifunction.CuttingVeinNumbers.Value = value;
		}
	}

	public bool DeleteVein
	{
		get
		{
			return deleteVein;
		}
		set
		{
			deleteVein = value;
			Multifunction.deleteveinbool.Value = value;
		}
	}

	public bool Changeveinpos
	{
		get
		{
			return changeveinpos;
		}
		set
		{
			if (value)
			{
				SetFalse();
			}
			changeveinpos = value;
		}
	}

	public bool Changeveingrouppos
	{
		get
		{
			return changeveingrouppos;
		}
		set
		{
			if (value)
			{
				SetFalse();
			}
			changeveingrouppos = value;
		}
	}

	public bool NotTidyVein
	{
		get
		{
			return nottidyvein;
		}
		set
		{
			nottidyvein = value;
		}
	}

	public bool GetallVein
	{
		get
		{
			return getallVein;
		}
		set
		{
			if (value)
			{
				SetFalse();
			}
			getallVein = value;
		}
	}

	public bool Changexveinspos
	{
		get
		{
			return changexveinspos;
		}
		set
		{
			if (value)
			{
				SetFalse();
			}
			changexveinspos = value;
		}
	}

	public VeinData PointVeinData
	{
		get
		{
			return pointVeinData;
		}
		set
		{
			pointVeinData = value;
		}
	}

	public void SetFalse()
	{
		VeinType = 0;
		Changeveinpos = false;
		Changeveingrouppos = false;
		GetallVein = false;
		Changexveinspos = false;
	}

	public VeinControlProperty()
	{
		OilAddIntervalBool = new bool[3];
		OilAddIntervalValue = new int[3] { 1, 10, 100 };
		SetOilAddInterval(1);
		AddVeinNumber = 1000000000;
	}

	internal void SetOilAddInterval(int selectedIndex)
	{
		OilAddInterval = OilAddIntervalValue[selectedIndex];
		for (int i = 0; i < 3; i++)
		{
			OilAddIntervalBool[i] = i == selectedIndex;
		}
	}

	public void ControlVein()
	{
		if (VeinType != 0 && !GameMain.mainPlayer.controller.actionBuild.dismantleTool.active)
		{
			if (AddVeinMode == 0 && Input.GetMouseButtonDown(0))
			{
				addvein(VeinType);
			}
			else if (AddVeinMode == 1 && Input.GetMouseButton(0))
			{
				addvein(VeinType);
			}
		}
		if (Input.GetMouseButton(0) && DeleteVein && GameMain.mainPlayer.controller.actionBuild.dismantleTool.active)
		{
			removevein();
		}
		if (Input.GetMouseButton(1))
		{
			SetFalse();
		}
		if (!Input.GetMouseButton(0) || GameMain.mainPlayer.controller.actionBuild.dismantleTool.active)
		{
			return;
		}
		if (Input.GetMouseButtonDown(0))
		{
			PointVeinData = getveinbymouse();
		}
		if (PointVeinData.amount != 0)
		{
			RaycastHit hitInfo;
			if (GetallVein)
			{
				GetAllVeinMethod(PointVeinData);
			}
			else if (Changeveingrouppos)
			{
				ChangeveingroupposMethod(PointVeinData);
			}
			else if (Changexveinspos)
			{
				changexveins(PointVeinData);
			}
			else if (Changeveinpos && Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
			{
				Vector3 point = hitInfo.point;
				ChangeveinposMethod(PointVeinData, point);
			}
		}
	}

	public void addvein(int veintype)
	{
		PlanetData localPlanet = GameMain.localPlanet;
		if (localPlanet == null || localPlanet.type == EPlanetType.Gas || !Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
		{
			return;
		}
		Vector3 point = hitInfo.point;
		int num = ((veintype == 7) ? ((int)(OilAddInterval * (float)oillowerlimit)) : AddVeinNumber);
		VeinData[] veinPool = localPlanet.factory.veinPool;
		for (int i = 0; i < veinPool.Length; i++)
		{
			VeinData veinData = veinPool[i];
			if (veinData.type == EVeinType.None || !((point - veinData.pos).magnitude < 1f))
			{
				continue;
			}
			if (veinData.type != EVeinType.Oil)
			{
				if (localPlanet.factory.veinPool[veinData.id].amount + num < 1000000000)
				{
					localPlanet.factory.veinPool[veinData.id].amount += num;
					localPlanet.factory.veinGroups[veinData.groupIndex].amount += num;
				}
				else
				{
					localPlanet.factory.veinGroups[veinData.groupIndex].amount += 1000000000 - localPlanet.factory.veinPool[veinData.id].amount;
					localPlanet.factory.veinPool[veinData.id].amount = 1000000000;
				}
			}
			else
			{
				localPlanet.factory.veinPool[veinData.id].amount += num;
				localPlanet.factory.veinGroups[veinData.groupIndex].amount += num;
			}
			return;
		}
		VeinData veinData2 = new VeinData
		{
			amount = num,
			type = (EVeinType)veintype,
			pos = point,
			productId = LDB.veins.Select(veintype).MiningItem,
			modelIndex = (short)LDB.veins.Select(veintype).ModelIndex
		};
		veinData2.id = localPlanet.factory.AddVeinData(veinData2);
		veinData2.colliderId = localPlanet.physics.AddColliderData(LDB.veins.Select(veintype).prefabDesc.colliders[0].BindToObject(veinData2.id, 0, EObjectType.Vein, veinData2.pos, Quaternion.FromToRotation(Vector3.up, veinData2.pos.normalized)));
		veinData2.modelId = localPlanet.factoryModel.gpuiManager.AddModel(veinData2.modelIndex, veinData2.id, veinData2.pos, Maths.SphericalRotation(veinData2.pos, UnityEngine.Random.value * 360f));
		veinData2.minerCount = 0;
		localPlanet.factory.AssignGroupIndexForNewVein(ref veinData2);
		localPlanet.factory.veinPool[veinData2.id] = veinData2;
		localPlanet.factory.RefreshVeinMiningDisplay(veinData2.id, 0, 0);
		localPlanet.factory.RecalculateVeinGroup(localPlanet.factory.veinPool[veinData2.id].groupIndex);
	}

	public void changexveins(VeinData vd)
	{
		PlanetData localPlanet = GameMain.localPlanet;
		if (localPlanet == null || localPlanet.type == EPlanetType.Gas || localPlanet == null || !Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
		{
			return;
		}
		if (localPlanet.factory.veinGroups[localPlanet.factory.veinPool[vd.id].groupIndex].count <= CuttingVeinNumbers)
		{
			ChangeveingroupposMethod(vd);
			return;
		}
		Vector3 point = hitInfo.point;
		VeinData[] veinPool = localPlanet.factory.veinPool;
		Vector3 pos = veinPool[vd.id].pos;
		bool flag = false;
		List<int> list = new List<int>();
		VeinData[] array = veinPool;
		for (int i = 0; i < array.Length; i++)
		{
			VeinData veinData = array[i];
			if (veinData.id <= 0 || veinData.groupIndex != vd.groupIndex)
			{
				continue;
			}
			int id = veinData.id;
			if (vd.id == id)
			{
				flag = true;
			}
			if (flag || list.Count != CuttingVeinNumbers - 1)
			{
				list.Add(veinData.id);
				if (list.Count == CuttingVeinNumbers)
				{
					break;
				}
			}
		}
		if (list.Count != CuttingVeinNumbers)
		{
			return;
		}
		int num = 0;
		foreach (int item in list)
		{
			veinPool[item].pos = (NotTidyVein ? point : PostionCompute(pos, point, veinPool[item].pos, num++));
			if (!float.IsNaN(veinPool[item].pos.x) && !float.IsNaN(veinPool[item].pos.y) && !float.IsNaN(veinPool[item].pos.z))
			{
				int colliderId = veinPool[item].colliderId;
				localPlanet.physics.RemoveColliderData(colliderId);
				veinPool[item].colliderId = localPlanet.physics.AddColliderData(LDB.veins.Select((int)veinPool[item].type).prefabDesc.colliders[0].BindToObject(item, 0, EObjectType.Vein, veinPool[item].pos, Quaternion.FromToRotation(Vector3.up, veinPool[item].pos.normalized)));
				localPlanet.factoryModel.gpuiManager.AlterModel(veinPool[item].modelIndex, veinPool[item].modelId, item, veinPool[item].pos, Maths.SphericalRotation(veinPool[item].pos, 90f));
			}
		}
		bool flag2 = true;
		VeinData[] array2 = veinPool;
		for (int j = 0; j < array2.Length; j++)
		{
			VeinData veinData2 = array2[j];
			if (!list.Contains(veinData2.id) && veinData2.type == vd.type && (localPlanet.factory.veinPool[vd.id].pos - veinData2.pos).magnitude < 5f)
			{
				flag2 = false;
				break;
			}
		}
		if (!flag2)
		{
			return;
		}
		int groupIndex = localPlanet.factory.veinPool[vd.id].groupIndex;
		localPlanet.factory.veinPool[vd.id].groupIndex = (short)localPlanet.factory.AddVeinGroup(vd.type, vd.pos.normalized);
		foreach (int item2 in list)
		{
			if (item2 != vd.id)
			{
				localPlanet.factory.veinPool[item2].groupIndex = localPlanet.factory.veinPool[vd.id].groupIndex;
			}
		}
		localPlanet.factory.RecalculateVeinGroup(localPlanet.factory.veinPool[vd.id].groupIndex);
		localPlanet.factory.RecalculateVeinGroup(groupIndex);
		localPlanet.factory.ArrangeVeinGroups();
	}

	public void ChangeveingroupposMethod(VeinData vd)
	{
		if (CoolDown)
		{
			return;
		}
		PlanetData localPlanet = GameMain.localPlanet;
		if (localPlanet == null || localPlanet.type == EPlanetType.Gas || !Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
		{
			return;
		}
		Vector3 point = hitInfo.point;
		VeinData[] veinPool = localPlanet.factory.veinPool;
		Vector3 pos = veinPool[vd.id].pos;
		int num = 0;
		VeinData[] array = veinPool;
		for (int i = 0; i < array.Length; i++)
		{
			VeinData veinData = array[i];
			if (veinData.id <= 0)
			{
				continue;
			}
			int id = veinData.id;
			if (veinData.groupIndex != veinPool[vd.id].groupIndex)
			{
				continue;
			}
			if (NotTidyVein)
			{
				veinPool[id].pos = point;
			}
			else
			{
				Vector3 vector = PostionCompute(pos, point, veinData.pos, num++, vd.type == EVeinType.Oil);
				if (CoolDown)
				{
					return;
				}
				if ((double)Vector3.Distance(vector, veinData.pos) < 0.01)
				{
					continue;
				}
				veinPool[id].pos = vector;
				if (float.IsNaN(veinPool[id].pos.x) || float.IsNaN(veinPool[id].pos.y) || float.IsNaN(veinPool[id].pos.z))
				{
					continue;
				}
			}
			int colliderId = veinPool[id].colliderId;
			localPlanet.physics.RemoveColliderData(colliderId);
			veinPool[id].colliderId = localPlanet.physics.AddColliderData(LDB.veins.Select((int)veinPool[id].type).prefabDesc.colliders[0].BindToObject(id, 0, EObjectType.Vein, veinPool[id].pos, Quaternion.FromToRotation(Vector3.up, veinPool[id].pos.normalized)));
			localPlanet.factoryModel.gpuiManager.AlterModel(veinPool[id].modelIndex, veinPool[id].modelId, id, veinPool[id].pos, Maths.SphericalRotation(veinPool[id].pos, 90f));
		}
		localPlanet.factory.veinGroups[veinPool[vd.id].groupIndex].pos = veinPool[vd.id].pos / (localPlanet.realRadius + 2.5f);
	}

	public void ChangeveinposMethod(VeinData vd, Vector3 pos)
	{
		PlanetData localPlanet = GameMain.localPlanet;
		int id = vd.id;
		if (localPlanet == null || localPlanet.type == EPlanetType.Gas)
		{
			return;
		}
		VeinData[] veinPool = localPlanet.factory.veinPool;
		veinPool[id].pos = pos;
		int colliderId = veinPool[id].colliderId;
		localPlanet.physics.RemoveColliderData(colliderId);
		veinPool[id].colliderId = localPlanet.physics.AddColliderData(LDB.veins.Select((int)veinPool[id].type).prefabDesc.colliders[0].BindToObject(id, 0, EObjectType.Vein, veinPool[id].pos, Quaternion.FromToRotation(Vector3.up, veinPool[id].pos.normalized)));
		localPlanet.factoryModel.gpuiManager.AlterModel(veinPool[id].modelIndex, veinPool[id].modelId, id, veinPool[id].pos, Maths.SphericalRotation(veinPool[id].pos, 90f));
		bool flag = false;
		int num = -1;
		if (localPlanet.factory.veinGroups[veinPool[id].groupIndex].count > 1)
		{
			if ((double)(pos - localPlanet.factory.veinGroups[veinPool[id].groupIndex].pos * (localPlanet.realRadius + 2.5f)).magnitude > 10.0)
			{
				flag = true;
				num = veinPool[id].groupIndex;
				veinPool[id].groupIndex = -1;
			}
		}
		else
		{
			localPlanet.factory.veinGroups[veinPool[id].groupIndex].pos = veinPool[id].pos / (localPlanet.realRadius + 2.5f);
			VeinData[] veinPool2 = localPlanet.factory.veinPool;
			for (int i = 0; i < veinPool2.Length; i++)
			{
				VeinData veinData = veinPool2[i];
				if (veinData.type == veinPool[id].type && veinData.groupIndex != num && (veinData.pos - veinPool[id].pos).magnitude < 10f)
				{
					num = veinPool[id].groupIndex;
					veinPool[id].groupIndex = veinData.groupIndex;
					localPlanet.factory.RecalculateVeinGroup(num);
				}
			}
		}
		if (flag)
		{
			localPlanet.factory.RecalculateVeinGroup(num);
			VeinData[] veinPool3 = localPlanet.factory.veinPool;
			for (int j = 0; j < veinPool3.Length; j++)
			{
				VeinData veinData2 = veinPool3[j];
				if (veinData2.type == veinPool[id].type && veinData2.groupIndex != num && (veinData2.pos - veinPool[id].pos).magnitude < 10f)
				{
					veinPool[id].groupIndex = veinData2.groupIndex;
				}
			}
			if (veinPool[id].groupIndex == -1)
			{
				veinPool[id].groupIndex = (short)localPlanet.factory.AddVeinGroup(veinPool[id].type, veinPool[id].pos.normalized);
			}
		}
		localPlanet.factory.RecalculateVeinGroup(veinPool[id].groupIndex);
		localPlanet.factory.ArrangeVeinGroups();
	}

	public void GetAllVeinMethod(VeinData vd)
	{
		PlanetData localPlanet = GameMain.localPlanet;
		if (localPlanet == null || localPlanet.type == EPlanetType.Gas || !Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
		{
			return;
		}
		Vector3 point = hitInfo.point;
		VeinData[] veinPool = localPlanet.factory.veinPool;
		Vector3 pos = veinPool[vd.id].pos;
		int num = 0;
		VeinData[] array = veinPool;
		for (int i = 0; i < array.Length; i++)
		{
			VeinData veinData = array[i];
			if (veinData.id <= 0 || veinData.type != vd.type)
			{
				continue;
			}
			int id = veinData.id;
			veinPool[id].pos = (NotTidyVein ? point : PostionCompute(pos, point, veinData.pos, num++, vd.type == EVeinType.Oil));
			if (CoolDown)
			{
				return;
			}
			if (!float.IsNaN(veinPool[id].pos.x) && !float.IsNaN(veinPool[id].pos.y) && !float.IsNaN(veinPool[id].pos.z))
			{
				if (veinData.groupIndex != vd.groupIndex)
				{
					int groupIndex = veinPool[veinData.id].groupIndex;
					veinPool[veinData.id].groupIndex = vd.groupIndex;
					localPlanet.factory.RecalculateVeinGroup(groupIndex);
					localPlanet.factory.RecalculateVeinGroup(vd.groupIndex);
					localPlanet.factory.ArrangeVeinGroups();
				}
				int colliderId = veinPool[id].colliderId;
				localPlanet.physics.RemoveColliderData(colliderId);
				veinPool[id].colliderId = localPlanet.physics.AddColliderData(LDB.veins.Select((int)veinPool[id].type).prefabDesc.colliders[0].BindToObject(id, 0, EObjectType.Vein, veinPool[id].pos, Quaternion.FromToRotation(Vector3.up, veinPool[id].pos.normalized)));
				localPlanet.factoryModel.gpuiManager.AlterModel(veinPool[id].modelIndex, veinPool[id].modelId, id, veinPool[id].pos, Maths.SphericalRotation(veinPool[id].pos, 90f));
			}
		}
		localPlanet.factory.RecalculateVeinGroup(vd.groupIndex);
		localPlanet.factory.ArrangeVeinGroups();
	}

	public void removevein()
	{
		PlanetData localPlanet = GameMain.localPlanet;
		if (localPlanet == null || localPlanet.type == EPlanetType.Gas || !Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
		{
			return;
		}
		Vector3 point = hitInfo.point;
		VeinData[] veinPool = localPlanet.factory.veinPool;
		for (int i = 0; i < veinPool.Length; i++)
		{
			VeinData veinData = veinPool[i];
			if ((point - veinData.pos).magnitude < 1f && veinData.type != EVeinType.None)
			{
				localPlanet.factory.veinGroups[veinData.groupIndex].count--;
				localPlanet.factory.veinGroups[veinData.groupIndex].amount -= veinData.amount;
				localPlanet.factory.RemoveVeinWithComponents(veinData.id);
				if (localPlanet.factory.veinGroups[veinData.groupIndex].count == 0)
				{
					localPlanet.factory.veinGroups[veinData.groupIndex].type = EVeinType.None;
					localPlanet.factory.veinGroups[veinData.groupIndex].amount = 0L;
					localPlanet.factory.veinGroups[veinData.groupIndex].pos = Vector3.zero;
				}
				break;
			}
		}
	}

	public VeinData getveinbymouse()
	{
		PlanetData localPlanet = GameMain.localPlanet;
		if (localPlanet != null && localPlanet.type != EPlanetType.Gas && Physics.Raycast(GameMain.mainPlayer.controller.mainCamera.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
		{
			Vector3 point = hitInfo.point;
			float num = 100f;
			VeinData result = default(VeinData);
			VeinData[] veinPool = localPlanet.factory.veinPool;
			for (int i = 0; i < veinPool.Length; i++)
			{
				VeinData veinData = veinPool[i];
				if (veinData.id != 0 && (point - veinData.pos).magnitude < num && veinData.type != EVeinType.None)
				{
					num = (point - veinData.pos).magnitude;
					result = veinData;
				}
			}
			if (num > 4f)
			{
				return default(VeinData);
			}
			return result;
		}
		return default(VeinData);
	}

	public Vector3 PostionCompute(Vector3 begin, Vector3 end, Vector3 pointpos, int index, bool oil = false)
	{
		if (end.y > 193f || end.y < -193f)
		{
			UIMessageBox.Show("移动矿堆失败".Translate(), "当前纬度过高，为避免出错，无法移动矿堆".Translate(), "确定".Translate(), 3);
			CoolDown = true;
			return pointpos;
		}
		Vector3 vector = begin;
		Vector3 vector2 = end;
		float realRadius = GameMain.localPlanet.realRadius;
		Quaternion quaternion = Maths.SphericalRotation(vector, 0f);
		float num = (oil ? 15f : 1.5f);
		Vector3 result;
		if (!oil)
		{
			vector2.x = (int)vector2.x;
			vector2.z = (int)vector2.z;
			vector2.y = (int)vector2.y;
			result = vector + quaternion * (new Vector3(index / VeinLines, 0f, index % VeinLines) * num);
		}
		else
		{
			result = vector - quaternion * new Vector3(index / VeinLines * 8, 0f, (float)(index % VeinLines) * num);
		}
		double num2 = Math.Atan(vector.z / vector.x) - Math.Atan(vector2.z / vector2.x);
		double num3 = Math.Acos(vector.y / realRadius) - Math.Acos(vector2.y / realRadius);
		double num4 = 0.0 - Math.Atan(result.z / result.x) + num2;
		double num5 = Math.Acos(result.y / realRadius) - num3;
		if (num2 == double.NaN || num3 == double.NaN || num4 == double.NaN || num5 == double.NaN)
		{
			return pointpos;
		}
		result.x = (float)((end.x < 0f) ? (0.0 - Math.Abs(Math.Sin(num5) * Math.Cos(num4))) : Math.Abs(Math.Sin(num5) * Math.Cos(num4)));
		result.y = (float)((end.y < 0f) ? (0.0 - Math.Abs(Math.Cos(num5))) : Math.Abs(Math.Cos(num5)));
		result.z = (float)((end.z < 0f) ? (0.0 - Math.Abs(Math.Sin(num5) * Math.Sin(num4))) : Math.Abs(Math.Sin(num5) * Math.Sin(num4)));
		result.x *= realRadius;
		result.y *= realRadius;
		result.z *= realRadius;
		if (result.x == float.NaN || result.y == float.NaN || result.z == float.NaN || result.y > 190f || result.y < -190f)
		{
			return pointpos;
		}
		return result;
	}

	public void BuryAllvein()
	{
		PlanetData localPlanet = GameMain.localPlanet;
		if (localPlanet != null && localPlanet.type != EPlanetType.Gas)
		{
			float num = localPlanet.realRadius - 50f;
			VeinData[] veinPool = localPlanet.factory.veinPool;
			for (int i = 0; i < veinPool.Length; i++)
			{
				VeinData veinData = veinPool[i];
				PlanetPhysics physics = localPlanet.physics;
				int id = veinData.id;
				int colliderId = veinData.colliderId;
				Vector3 pos = physics.GetColliderData(colliderId).pos.normalized * (num + 0.4f);
				physics.colChunks[colliderId >> 20].colliderPool[colliderId & 0xFFFFF].pos = pos;
				ref VeinData reference = ref localPlanet.factory.veinPool[id];
				Vector3 pos2 = veinData.pos;
				reference.pos = pos2.normalized * num;
			}
			VeinData[] veinPool2 = localPlanet.factory.veinPool;
			for (int j = 0; j < veinPool2.Length; j++)
			{
				VeinData veinData2 = veinPool2[j];
				GameMain.gpuiManager.AlterModel(veinData2.modelIndex, veinData2.modelId, veinData2.id, veinData2.pos, setBuffer: false);
			}
			GameMain.gpuiManager.SyncAllGPUBuffer();
		}
	}

	public void RemoveAllvein()
	{
		PlanetData localPlanet = GameMain.localPlanet;
		if (localPlanet == null || localPlanet.type == EPlanetType.Gas)
		{
			return;
		}
		VeinData[] veinPool = localPlanet.factory.veinPool;
		for (int i = 0; i < veinPool.Length; i++)
		{
			VeinData veinData = veinPool[i];
			if (veinData.type != EVeinType.None)
			{
				localPlanet.factory.veinGroups[veinData.groupIndex].count--;
				localPlanet.factory.veinGroups[veinData.groupIndex].amount -= veinData.amount;
				localPlanet.factory.RemoveVeinWithComponents(veinData.id);
				if (localPlanet.factory.veinGroups[veinData.groupIndex].count == 0)
				{
					localPlanet.factory.veinGroups[veinData.groupIndex].type = EVeinType.None;
					localPlanet.factory.veinGroups[veinData.groupIndex].amount = 0L;
					localPlanet.factory.veinGroups[veinData.groupIndex].pos = Vector3.zero;
				}
			}
		}
		localPlanet.factory.ArrangeVeinGroups();
	}
}
