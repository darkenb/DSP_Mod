using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class TankComponentPatch
{
	[HarmonyPrefix]
	[HarmonyPatch(typeof(TankComponent), "GameTick")]
	public static void TankComponentGameTickPatchPrefix(ref TankComponent __instance)
	{
		if (Multifunction.TankMaxproliferator.Value)
		{
			__instance.fluidInc = __instance.fluidCount * Multifunction.incAbility;
		}
	}
}
