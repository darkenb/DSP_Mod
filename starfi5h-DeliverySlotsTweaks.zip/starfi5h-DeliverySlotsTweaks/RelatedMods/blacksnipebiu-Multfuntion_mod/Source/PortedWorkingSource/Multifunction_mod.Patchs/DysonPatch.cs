using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class DysonPatch
{
	[HarmonyPostfix]
	[HarmonyPatch(typeof(DysonSphere), "Init")]
	public static void DysonSphereInit(ref DysonSphere __instance)
	{
		if (Multifunction.ChangeDysonradius.Value)
		{
			__instance.minOrbitRadius = 100f;
			__instance.maxOrbitRadius = Multifunction.MaxOrbitRadiusConfig.Value;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSphereLayer), "GameTick")]
	public static void DysonSphereLayerGameTick(ref DysonSphereLayer __instance, long gameTick)
	{
		if (!Multifunction.QuickabortSwarm.Value)
		{
			return;
		}
		int num = (int)(gameTick % 120);
		for (int i = 1; i < __instance.nodeCursor; i++)
		{
			DysonNode dysonNode = __instance.nodePool[i];
			if (dysonNode != null && dysonNode.id == i && dysonNode.id % 120 == num && dysonNode.sp == dysonNode.spMax)
			{
				for (int j = 1; j <= Multifunction.Solarsailsabsorbeveryframe.Value; j++)
				{
					dysonNode.OrderConstructCp(gameTick, __instance.dysonSphere.swarm);
				}
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSwarm), "AbsorbSail")]
	public static bool DysonSwarmPatch1(ref DysonSwarm __instance, ref bool __result, DysonNode node)
	{
		if (!Multifunction.quickabsorbsolar.Value)
		{
			return true;
		}
		if (__instance.expiryCursor == __instance.expiryEnding)
		{
			__result = false;
			return false;
		}
		__instance.expiryEnding--;
		if (__instance.expiryEnding < 0)
		{
			__instance.expiryEnding += __instance.sailCapacity;
		}
		int expiryEnding = __instance.expiryEnding;
		int index = __instance.expiryOrder[expiryEnding].index;
		if (__instance.expiryOrder[expiryEnding].time == 0)
		{
			Assert.CannotBeReached();
			__result = false;
			return false;
		}
		__instance.expiryOrder[expiryEnding].time = 0L;
		__instance.expiryOrder[expiryEnding].index = 0;
		if (node != null && node.ConstructCp() != null)
		{
			__instance.dysonSphere.productRegister[11903]++;
		}
		__instance.RemoveSolarSail(index);
		return false;
	}
}
