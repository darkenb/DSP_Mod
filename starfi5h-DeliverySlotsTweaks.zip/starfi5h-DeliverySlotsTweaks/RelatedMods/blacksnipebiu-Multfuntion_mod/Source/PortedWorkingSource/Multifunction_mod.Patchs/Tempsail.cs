namespace Multifunction_mod.Patchs;

public struct Tempsail
{
	public DysonSail ss;

	public int orbitid;

	public long time;

	public void FromData(in VectorLF3 delta1, in VectorLF3 delta2, int orbitId)
	{
		ss.px = (float)delta1.x;
		ss.py = (float)delta1.y;
		ss.pz = (float)delta1.z;
		ss.vx = (float)delta2.x;
		ss.vy = (float)delta2.y;
		ss.vz = (float)delta2.z;
		ss.gs = 1f;
		orbitid = orbitId;
		time = (long)(GameMain.history.solarSailLife * 60f + 0.1f);
	}
}
