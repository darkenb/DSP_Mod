using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class SomePatch
{
	[HarmonyPrefix]
	[HarmonyPatch(typeof(DispenserComponent), "InternalTick")]
	public static void DispenserComponentInternalTickPrefix(ref DispenserComponent __instance)
	{
		if (Multifunction.Stationfullenergy.Value)
		{
			__instance.energy = __instance.energyMax;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PropertySystem), "GetItemTotalProperty")]
	public static void GetItemTotalPropertyPatch(ref long __result)
	{
		if (Multifunction.Property9999999)
		{
			__result = 2147483647L;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(ItemProto), "isFluid")]
	public static void ItemProtoisFluidPatch(ref bool __result)
	{
		if (Multifunction.Tankcontentall.Value)
		{
			__result = true;
		}
	}
}
