using System;
using HarmonyLib;

namespace Multifunction_mod.Patchs;

internal class Multifunction_modGameLogic
{
	public static Action OnDataLoaded;

	public static Action OnGameBegin;

	public static Action OnGameEnd;

	[HarmonyPostfix]
	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	public static void VFPreload_InvokeOnLoadWorkEnded_Postfix()
	{
		OnDataLoaded?.Invoke();
	}

	[HarmonyPostfix]
	[HarmonyPriority(800)]
	[HarmonyPatch(typeof(GameMain), "Begin")]
	public static void GameMain_Begin_Postfix()
	{
		OnGameBegin?.Invoke();
	}

	[HarmonyPostfix]
	[HarmonyPriority(0)]
	[HarmonyPatch(typeof(GameMain), "End")]
	public static void GameMain_End_Postfix()
	{
		OnGameEnd?.Invoke();
	}
}
