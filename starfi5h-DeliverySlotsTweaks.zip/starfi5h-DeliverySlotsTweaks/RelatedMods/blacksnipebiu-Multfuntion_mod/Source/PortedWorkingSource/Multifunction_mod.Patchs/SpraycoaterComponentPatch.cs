using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class SpraycoaterComponentPatch
{
	[HarmonyPrefix]
	[HarmonyPatch(typeof(SpraycoaterComponent), "InternalUpdate")]
	public static void SpraycoaterComponentInternalUpdatePrefix(ref SpraycoaterComponent __instance)
	{
		if (Multifunction.Maxproliferator.Value)
		{
			Multifunctionpatch.ability = __instance.incAbility;
			__instance.incAbility = 10;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(SpraycoaterComponent), "InternalUpdate")]
	public static void SpraycoaterComponentInternalUpdatePostfix(ref SpraycoaterComponent __instance)
	{
		if (!Multifunction.Maxproliferator.Value && __instance.incAbility > 4)
		{
			__instance.incAbility = Multifunctionpatch.ability;
		}
	}
}
