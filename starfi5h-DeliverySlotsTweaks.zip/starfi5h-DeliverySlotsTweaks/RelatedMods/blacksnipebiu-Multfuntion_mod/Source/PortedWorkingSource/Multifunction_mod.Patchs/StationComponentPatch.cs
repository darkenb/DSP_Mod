using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class StationComponentPatch
{
	private static HashSet<int> tempids = new HashSet<int>();

	[HarmonyPrefix]
	[HarmonyPatch(typeof(StationComponent), "Init")]
	public static void StationComponentInit(ref int _extraStorage, StationComponent __instance)
	{
		if (Multifunction.StationStoExtra.Value > 0)
		{
			int num = (__instance.isStellar ? 10000 : 5000);
			_extraStorage = (Multifunction.StationStoExtra.Value + 1) * num;
		}
	}

	public static int GetNumberOfVein(int itemid, PlanetData pd)
	{
		EVeinType evt = LDB.veins.GetVeinTypeByItemId(itemid);
		if (evt == EVeinType.None)
		{
			return 0;
		}
		if (evt == EVeinType.Oil)
		{
			long[] veinAmounts = new long[64];
			pd.SummarizeVeinAmountsByFilter(ref veinAmounts, tempids, UIRoot.instance.uiGame.veinAmountDisplayFilter);
			int num = (int)((double)((float)veinAmounts[7] * VeinData.oilSpeedMultiplier) + 0.5);
			if (num > 1)
			{
				return num;
			}
		}
		return pd.factory.veinPool.Count((VeinData x) => x.type == evt);
	}

	public static int MineVein(int itemid, int minenumber, PlanetData pd)
	{
		if (pd.waterItemId == itemid)
		{
			return (int)(30f * GameMain.history.miningSpeedScale * (float)Multifunction.Stationminenumber.Value);
		}
		if (minenumber <= 0)
		{
			return 0;
		}
		int num = 0;
		int num2 = ((itemid != 1007) ? ((int)((float)minenumber * GameMain.history.miningSpeedScale / 2f)) : ((int)((float)minenumber * GameMain.history.miningSpeedScale)));
		int num3 = ((itemid != 1007) ? ((int)((float)num2 * GameMain.history.miningCostRate / 2f)) : ((int)((float)num2 * GameMain.history.miningCostRate)));
		if (GameMain.data.gameDesc.isInfiniteResource)
		{
			return num2;
		}
		if (LDB.veins.GetVeinTypeByItemId(itemid) == EVeinType.None || pd == null)
		{
			return 0;
		}
		if (num3 == 0)
		{
			return num2;
		}
		VeinData[] veinPool = pd.factory.veinPool;
		for (int i = 0; i < veinPool.Length; i++)
		{
			VeinData veinData = veinPool[i];
			if (veinData.type != LDB.veins.GetVeinTypeByItemId(itemid) || veinData.amount == 1)
			{
				continue;
			}
			if (veinData.amount > num3 - num)
			{
				if (itemid == 1007 && (double)((float)veinData.amount * VeinData.oilSpeedMultiplier) <= 0.1)
				{
					int num4 = Multifunction.veinproperty.oillowerlimit - veinData.amount;
					pd.factory.veinPool[veinData.id].amount += num4;
					pd.factory.veinGroups[veinData.groupIndex].amount += num4;
					num += (int)(0.1 * (double)GameMain.history.miningSpeedScale * (double)Multifunction.Stationminenumber.Value);
				}
				else
				{
					pd.factory.veinPool[veinData.id].amount -= num3;
					pd.factory.veinGroups[veinData.groupIndex].amount -= num3;
					num = num2;
				}
			}
			else
			{
				num += veinData.amount - 1;
				pd.factory.veinPool[veinData.id].amount = 1;
				pd.factory.veinGroups[veinData.groupIndex].amount -= veinData.amount - 1;
			}
			if (num >= num2)
			{
				break;
			}
		}
		return num;
	}

	public static void StationMine(StationComponent sc, PlanetData pd, int[] productRegister)
	{
		for (int i = 0; i < sc.storage.Length && sc.energy > 0; i++)
		{
			ref StationStore reference = ref sc.storage[i];
			int itemId = reference.itemId;
			if (itemId <= 0 || reference.count >= reference.max)
			{
				continue;
			}
			int numberOfVein = GetNumberOfVein(itemId, pd);
			int num = numberOfVein * Multifunction.Stationminenumber.Value;
			if (numberOfVein > 0 && num == 0)
			{
				num = 1;
			}
			else if (numberOfVein == 0 && itemId != pd.waterItemId)
			{
				continue;
			}
			if (!Multifunction.Stationfullenergy.Value && (float)sc.energy <= (float)num * GameMain.history.miningSpeedScale * 5000f)
			{
				num = (int)((float)sc.energy * 0.9f / (GameMain.history.miningSpeedScale * 5000f));
			}
			int num2 = MineVein(itemId, num, pd);
			if (num2 <= 0)
			{
				continue;
			}
			lock (productRegister)
			{
				productRegister[itemId] += num2;
				sc.storage[i].count += num2;
				if (!Multifunction.Stationfullenergy.Value)
				{
					sc.energy -= num2 * 5000;
				}
			}
		}
	}

	public static void StationPowerGeneration(StationComponent sc, int[] consumeRegister)
	{
		if (sc == null || sc.storage == null || sc.energy >= sc.energyMax - 1000000)
		{
			return;
		}
		ref StationStore reference = ref sc.storage[sc.storage.Length - 1];
		if (reference.itemId <= 0 || reference.count <= 0)
		{
			return;
		}
		ItemProto itemProto = LDB.items.Select(reference.itemId);
		if (itemProto.HeatValue <= 0 || sc.energy + itemProto.HeatValue >= sc.energyMax)
		{
			return;
		}
		int num = Math.Min(reference.count, (int)((sc.energyMax - sc.energy) / itemProto.HeatValue));
		sc.energy += num * itemProto.HeatValue;
		reference.count -= num;
		if (num <= 0)
		{
			return;
		}
		lock (consumeRegister)
		{
			consumeRegister[itemProto.ID] = num;
		}
	}

	public static void StationSprayInc(StationComponent sc, int[] consumeRegister)
	{
		int num = -1;
		for (int i = 0; i < sc.storage.Length; i++)
		{
			if (sc.storage[i].itemId == 1143)
			{
				num = i;
				if (sc.storage[i].count == 0)
				{
					return;
				}
				break;
			}
		}
		if (num == -1)
		{
			return;
		}
		for (int j = 0; j < sc.storage.Length; j++)
		{
			ref StationStore reference = ref sc.storage[j];
			ref StationStore reference2 = ref sc.storage[num];
			if (reference.itemId == 1143 || reference.itemId <= 0 || reference.count <= 0)
			{
				continue;
			}
			int num2 = reference.count * Multifunction.incAbility - reference.inc;
			int num3 = Math.Min((int)Math.Ceiling((double)num2 / 296.0), reference2.count);
			if (num3 != 0)
			{
				lock (consumeRegister)
				{
					consumeRegister[1143] = num3;
					reference.inc += ((reference2.count >= num3) ? num3 : reference2.count) * 296;
					reference2.count -= num3;
				}
				if (reference.count == 0)
				{
					reference.inc = 0;
				}
			}
		}
	}

	public static void StationFullItemCount(StationComponent sc)
	{
		for (int i = 0; i < sc.storage.Length; i++)
		{
			if (sc.storage[i].itemId > 0)
			{
				sc.storage[i].count = sc.storage[i].max;
			}
		}
	}

	public static void StationTrashMethod(StationComponent sc, int[] consumeRegister)
	{
		long num = 0L;
		for (int i = 0; i < sc.storage.Length; i++)
		{
			if (sc.energy <= 0)
			{
				break;
			}
			ref StationStore reference = ref sc.storage[i];
			int itemId = reference.itemId;
			if (itemId <= 0)
			{
				continue;
			}
			int count = reference.count;
			if (sc.energy <= count * 10000)
			{
				continue;
			}
			lock (consumeRegister)
			{
				consumeRegister[itemId] = count;
				sc.storage[i].count -= count;
				if (!Multifunction.Stationfullenergy.Value)
				{
					sc.energy -= count * 10000;
				}
			}
			if (Multifunction.needtrashsand.Value)
			{
				num += count * 100;
			}
		}
		if (num > 0)
		{
			Multifunction.player.sandCountChanged -= UIRoot.instance.uiGame.OnSandCountChanged;
			Multifunction.player.SetSandCount(Multifunction.player.sandCount + num, ESandSource.Other);
			Multifunction.player.sandCountChanged += UIRoot.instance.uiGame.OnSandCountChanged;
		}
	}

	public static void StationFurnaceMiner(StationComponent sc, long time, int[] consumeRegister, int[] productRegister)
	{
		List<int> storageItems = sc.storage.Select((StationStore x) => x.itemId).ToList();
		storageItems.ForEach(delegate(int itemId)
		{
			if (itemId > 0 && Multifunction.smeltRecipes.ContainsKey(itemId))
			{
				Multifunction.smeltRecipes[itemId].ForEach(delegate(RecipeProto rp)
				{
					int num = rp.TimeSpend / 2;
					if ((num < 2 || time % num == 0) && rp.Results.All(storageItems.Contains) && rp.Items.All(storageItems.Contains))
					{
						for (int i = 0; i < rp.ResultCounts.Length; i++)
						{
							int num2 = storageItems.IndexOf(rp.Results[i]);
							if (sc.storage[num2].count > sc.storage[num2].max)
							{
								return;
							}
						}
						int value = Multifunction.StationMinerSmelterNum.Value;
						int num3 = 1440000;
						int num4 = 2880000;
						int num5 = value;
						int num6 = num5;
						int num7 = rp.Items.Length;
						for (int j = 0; j < num7; j++)
						{
							if (rp.ItemCounts[j] != 0)
							{
								int num8 = storageItems.IndexOf(rp.Items[j]);
								int val = sc.storage[num8].count / rp.ItemCounts[j];
								num5 = Math.Min(num5, val);
								num6 = Math.Min(Math.Min(num6, val), sc.storage[num8].inc / Multifunction.incAbility);
							}
						}
						if (Multifunction.Stationfullenergy.Value)
						{
							num5 -= num6;
						}
						else
						{
							num6 = (int)Math.Min(num6, sc.energy / num4);
							sc.energy -= num6 * num4;
							num5 = (int)Math.Min(num5 - num6, sc.energy / num3);
						}
						if (num5 + num6 != 0)
						{
							if (!Multifunction.Stationfullenergy.Value)
							{
								sc.energy -= num5 * num3;
							}
							for (int k = 0; k < num7; k++)
							{
								int num9 = rp.ItemCounts[k] * (num5 + num6);
								lock (consumeRegister)
								{
									int num10 = storageItems.IndexOf(rp.Items[k]);
									sc.storage[num10].count -= num9;
									sc.storage[num10].inc -= num6 * rp.ItemCounts[k] * Multifunction.incAbility;
									sc.storage[num10].inc = Math.Max(0, Math.Min(sc.storage[num10].count * Multifunction.incAbility, sc.storage[num10].inc));
									consumeRegister[rp.Items[k]] = num9;
								}
							}
							for (int l = 0; l < rp.ResultCounts.Length; l++)
							{
								lock (productRegister)
								{
									int num11 = (int)((double)rp.ResultCounts[l] * ((double)num5 + (double)num6 * (1.0 + Cargo.incTableMilli[Multifunction.incAbility])));
									int num12 = storageItems.IndexOf(rp.Results[l]);
									sc.storage[num12].count += num11;
									productRegister[rp.Results[l]] = num11;
								}
							}
						}
					}
				});
			}
		});
	}
}
