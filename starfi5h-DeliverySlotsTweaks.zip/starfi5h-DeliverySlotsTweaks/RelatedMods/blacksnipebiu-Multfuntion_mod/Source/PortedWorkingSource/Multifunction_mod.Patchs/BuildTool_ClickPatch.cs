using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class BuildTool_ClickPatch
{
	[HarmonyPrefix]
	[HarmonyPatch(typeof(BuildTool_Click), "CheckBuildConditions")]
	public static bool CheckBuildConditionsPatchPrefix(BuildTool_Click __instance, ref bool __result)
	{
		if (!Multifunction.PasteBuildAnyWay && !Multifunction.build_station_nocondition.Value)
		{
			return true;
		}
		for (int i = 0; i < __instance.buildPreviews.Count; i++)
		{
			PrefabDesc prefabDesc = __instance.buildPreviews[i]?.item?.prefabDesc;
			if (prefabDesc != null && prefabDesc.veinMiner)
			{
				return true;
			}
			if (Multifunction.build_station_nocondition.Value && !Multifunction.PasteBuildAnyWay && !prefabDesc.isStation && !prefabDesc.isStation && !prefabDesc.isCollectStation)
			{
				return true;
			}
		}
		__result = true;
		return false;
	}
}
