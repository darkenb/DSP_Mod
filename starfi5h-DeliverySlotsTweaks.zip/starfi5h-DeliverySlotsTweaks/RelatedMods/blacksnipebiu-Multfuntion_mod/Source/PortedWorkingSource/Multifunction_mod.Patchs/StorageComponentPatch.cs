using System;
using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class StorageComponentPatch
{
	[HarmonyPostfix]
	[HarmonyPatch(typeof(StorageComponent), "Import")]
	public static void StorageComponentImportPatch(StorageComponent __instance)
	{
		if (Multifunction.StackMultiple.Value <= 1)
		{
			return;
		}
		for (int i = 0; i < __instance.size; i++)
		{
			if (__instance.entityId > 0 && __instance.grids[i].itemId > 0)
			{
				ItemProto itemProto = LDB.items.Select(__instance.grids[i].itemId);
				if (itemProto != null)
				{
					__instance.grids[i].stackSize = itemProto.StackSize * Multifunction.StackMultiple.Value;
				}
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(StorageComponent), "LoadStatic")]
	public static void Postfix()
	{
		if (Multifunction.StackMultiple.Value > 1)
		{
			ItemProto[] dataArray = LDB.items.dataArray;
			for (int i = 0; i < dataArray.Length; i++)
			{
				StorageComponent.itemStackCount[dataArray[i].ID] = dataArray[i].StackSize * Multifunction.StackMultiple.Value;
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(StorageComponent), "GetItemCount", new Type[] { typeof(int) })]
	public static void GetItemCountPatch(StorageComponent __instance, int itemId, ref int __result)
	{
		if (Multifunction.ArchitectMode.Value && itemId > 0 && itemId < 6007 && __instance != null && __instance.id == GameMain.mainPlayer.package.id && LDB.items.Select(itemId).CanBuild && __result == 0)
		{
			__result = 100;
		}
	}
}
