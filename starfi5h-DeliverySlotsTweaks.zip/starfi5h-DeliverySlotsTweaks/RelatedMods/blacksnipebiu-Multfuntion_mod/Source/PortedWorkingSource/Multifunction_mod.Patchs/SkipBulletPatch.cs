using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class SkipBulletPatch
{
	private static long _sailLifeTime;

	private static Tempsail[][] _sailsCache;

	private static int[] _sailsCacheLen;

	private static int[] _sailsCacheCapacity;

	private static Harmony _patch;

	private static bool enable;

	public static string Patchid => "cn.blacksnipe.dsp.Multfuntion_mod.SkipBulletPatch";

	public static bool Enable
	{
		get
		{
			return enable;
		}
		set
		{
			if (enable != value)
			{
				enable = value;
				Init();
				if (enable)
				{
					_patch = Harmony.CreateAndPatchAll(typeof(SkipBulletPatch), Patchid);
					Multifunction_modGameLogic.OnGameBegin = (Action)Delegate.Combine(Multifunction_modGameLogic.OnGameBegin, new Action(GameMain_Begin_Postfix));
					UpdateSailLifeTime();
				}
				else
				{
					_patch?.UnpatchSelf();
					Multifunction_modGameLogic.OnGameBegin = (Action)Delegate.Remove(Multifunction_modGameLogic.OnGameBegin, new Action(GameMain_Begin_Postfix));
				}
			}
		}
	}

	public static bool CheckPatched()
	{
		Patches patchInfo = Harmony.GetPatchInfo(typeof(EjectorComponent).GetMethod("InternalUpdate"));
		return patchInfo.Transpilers.Count > 0;
	}

	private static void GameMain_Begin_Postfix()
	{
		Init();
	}

	private static void UpdateSailLifeTime()
	{
		if (GameMain.history != null)
		{
			_sailLifeTime = (long)(GameMain.history.solarSailLife * 60f + 0.1f);
		}
	}

	public static void Init()
	{
		GalaxyData galaxyData = GameMain.data?.galaxy;
		if (galaxyData != null)
		{
			int starCount = GameMain.data.galaxy.starCount;
			_sailsCache = new Tempsail[starCount][];
			_sailsCacheLen = new int[starCount];
			_sailsCacheCapacity = new int[starCount];
			Array.Clear(_sailsCacheLen, 0, starCount);
			Array.Clear(_sailsCacheCapacity, 0, starCount);
			UpdateSailLifeTime();
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameHistoryData), "UnlockTechFunction")]
	private static void GameHistoryData_SetForNewGame_Postfix(int func)
	{
		if (func == 12)
		{
			UpdateSailLifeTime();
		}
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(EjectorComponent), "InternalUpdate")]
	private static IEnumerable<CodeInstruction> EjectorComponent_InternalUpdate_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		Label label = generator.DefineLabel();
		codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldc_R4, 10f), new CodeMatch(OpCodes.Stfld)).Advance(1).Insert(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(EjectorComponent), "fired")), new CodeInstruction(OpCodes.Brtrue, label))
			.MatchForward(true, new CodeMatch(OpCodes.Pop))
			.Insert(new CodeInstruction(OpCodes.Nop).WithLabels(label), new CodeInstruction(OpCodes.Ldarg_3), new CodeInstruction(OpCodes.Ldarg_3), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(EjectorComponent), "orbitId")), new CodeInstruction(OpCodes.Ldloc_S, 9), new CodeInstruction(OpCodes.Ldloc_S, 11), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(SkipBulletPatch), "AddDysonSail")));
		return codeMatcher.InstructionEnumeration();
	}

	private static void AddDysonSail(DysonSwarm swarm, int orbitId, VectorLF3 uPos, VectorLF3 endVec)
	{
		int index = swarm.starData.index;
		VectorLF3 delta = endVec - swarm.starData.uPosition;
		VectorLF3 delta2 = VectorLF3.Cross(endVec - uPos, swarm.orbits[orbitId].up).normalized * Math.Sqrt(swarm.dysonSphere.gravity / swarm.orbits[orbitId].radius);
		lock (swarm)
		{
			Tempsail[] array = _sailsCache[index];
			int num = _sailsCacheLen[index];
			if (array == null)
			{
				SetSailsCacheCapacity(index, 256);
				array = _sailsCache[index];
			}
			else
			{
				int num2 = _sailsCacheCapacity[index];
				if (num >= num2)
				{
					SetSailsCacheCapacity(index, num2 * 2);
					array = _sailsCache[index];
				}
			}
			_sailsCacheLen[index] = num + 1;
			array[num].time = _sailLifeTime;
			array[num].FromData(in delta, in delta2, orbitId);
		}
	}

	private static void SetSailsCacheCapacity(int index, int capacity)
	{
		Tempsail[] array = new Tempsail[capacity];
		int num = _sailsCacheLen[index];
		if (num > 0)
		{
			Array.Copy(_sailsCache[index], array, num);
		}
		_sailsCache[index] = array;
		_sailsCacheCapacity[index] = capacity;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSwarm), "GameTick")]
	public static void DysonSwarmPatch(ref DysonSwarm __instance, long time)
	{
		if (__instance.starData == null || _sailsCacheLen == null)
		{
			return;
		}
		int index = __instance.starData.index;
		if (_sailsCacheLen[index] != 0)
		{
			for (int num = _sailsCacheLen[index] - 1; num >= 0; num--)
			{
				Tempsail tempsail = _sailsCache[index][num];
				__instance.AddSolarSail(tempsail.ss, tempsail.orbitid, tempsail.time + time);
			}
			_sailsCacheLen[index] = 0;
		}
	}
}
