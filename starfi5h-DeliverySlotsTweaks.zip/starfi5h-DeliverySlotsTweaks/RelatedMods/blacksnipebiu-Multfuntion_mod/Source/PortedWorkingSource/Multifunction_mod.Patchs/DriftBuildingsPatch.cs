using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class DriftBuildingsPatch
{
	public static bool IsPatched;

	[HarmonyPrefix]
	[HarmonyPatch(typeof(BuildTool_Click), "UpdatePreviewModels")]
	public static void Prefix(ref BuildTool_Click __instance)
	{
		if (Multifunction.DriftBuildings)
		{
			for (int i = 0; i < __instance.buildPreviews.Count; i++)
			{
				BuildPreview buildPreview = __instance.buildPreviews[i];
				buildPreview.lpos *= Multifunction.DriftBuildingHeight;
				buildPreview.lpos2 *= Multifunction.DriftBuildingHeight;
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "CreatePrebuilds")]
	public static void BuildTool_BlueprintPasteCreatePrebuildsPatch(ref BuildTool_BlueprintPaste __instance)
	{
		if (!Multifunction.DriftBuildings)
		{
			return;
		}
		for (int i = 0; i < __instance.bpCursor; i++)
		{
			BuildPreview buildPreview = __instance.bpPool[i];
			if (buildPreview.desc.isBelt)
			{
				buildPreview.lpos *= Multifunction.DriftBuildingHeight;
				buildPreview.lpos2 *= Multifunction.DriftBuildingHeight;
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "UpdatePreviewModels")]
	public static void BuildTool_BlueprintPastePrefix(ref BuildTool_BlueprintPaste __instance)
	{
		if (!Multifunction.DriftBuildings)
		{
			return;
		}
		for (int i = 0; i < __instance.bpCursor; i++)
		{
			BuildPreview buildPreview = __instance.bpPool[i];
			if (buildPreview.desc.isBelt)
			{
				buildPreview.lpos *= Multifunction.DriftBuildingHeight;
				buildPreview.lpos2 *= Multifunction.DriftBuildingHeight;
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "UpdatePreviewModels")]
	public static void BuildTool_BlueprintPastePostfix(ref BuildTool_BlueprintPaste __instance)
	{
		if (!Multifunction.DriftBuildings)
		{
			return;
		}
		for (int i = 0; i < __instance.bpCursor; i++)
		{
			BuildPreview buildPreview = __instance.bpPool[i];
			if (buildPreview.desc.isBelt)
			{
				buildPreview.lpos /= Multifunction.DriftBuildingHeight;
				buildPreview.lpos2 /= Multifunction.DriftBuildingHeight;
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "AlterBPGPUIModel")]
	public static void BuildTool_BlueprintPasteAlterBPGPUIModelPatch(ref BuildPreview _bp)
	{
		if (Multifunction.DriftBuildings)
		{
			_bp.lpos *= Multifunction.DriftBuildingHeight;
			_bp.lpos2 *= Multifunction.DriftBuildingHeight;
		}
	}
}
