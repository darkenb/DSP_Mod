using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class CargoTrafficPatch
{
	[HarmonyPostfix]
	[HarmonyPatch(typeof(CargoTraffic), "SetBeltSignalIcon")]
	public static void SetBeltSignalIconPatch(int signalId, int entityId, CargoTraffic __instance)
	{
		if (Multifunction.BeltSignalFunction.Value)
		{
			int index = __instance.factory.index;
			int beltId = __instance.factory.entityPool[entityId].beltId;
			if (!Multifunction.Beltsignal.ContainsKey(index))
			{
				Multifunction.Beltsignal.Add(index, new Dictionary<int, int>());
			}
			if (!Multifunction.Beltsignal[index].ContainsKey(beltId))
			{
				Multifunction.Beltsignal[index].Add(beltId, signalId);
			}
			else
			{
				Multifunction.Beltsignal[index][beltId] = signalId;
			}
			if (Multifunction.Beltsignalnumberoutput.ContainsKey(index) && Multifunction.Beltsignalnumberoutput[index].ContainsKey(beltId) && signalId != 601)
			{
				Multifunction.Beltsignalnumberoutput[index].Remove(beltId);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(CargoTraffic), "SetBeltSignalNumber")]
	public static void SetBeltSignalNumberPatch(float number, int entityId, CargoTraffic __instance)
	{
		if (!Multifunction.BeltSignalFunction.Value || __instance.factory.entitySignPool[entityId].iconType == 0 || __instance.factory.entitySignPool[entityId].iconId0 == 0)
		{
			return;
		}
		int index = __instance.factory.index;
		int beltId = __instance.factory.entityPool[entityId].beltId;
		if (__instance.factory.entitySignPool[entityId].iconId0 == 600)
		{
			return;
		}
		if (__instance.factory.entitySignPool[entityId].iconId0 == 601)
		{
			if (!Multifunction.Beltsignalnumberoutput.ContainsKey(index))
			{
				Multifunction.Beltsignalnumberoutput.Add(index, new Dictionary<int, int>());
			}
			if (!Multifunction.Beltsignalnumberoutput[index].ContainsKey(beltId))
			{
				Multifunction.Beltsignalnumberoutput[index].Add(beltId, (int)number);
			}
			else
			{
				Multifunction.Beltsignalnumberoutput[index][beltId] = (int)number;
			}
		}
		else if (Multifunction.Beltsignalnumberoutput.ContainsKey(index) && Multifunction.Beltsignalnumberoutput[index].ContainsKey(beltId))
		{
			Multifunction.Beltsignalnumberoutput[index][beltId] = (int)number;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(CargoTraffic), "TryPickItemAtRear")]
	public static void Prefix(ref int[] needs)
	{
		if (Multifunction.Tankcontentall.Value && needs != null && ItemProto.fluids == needs)
		{
			needs = null;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(CargoTraffic), "RemoveBeltComponent")]
	public static void Prefix(CargoTraffic __instance, int id)
	{
		if (Multifunction.BeltSignalFunction.Value)
		{
			int index = __instance.factory.index;
			if (Multifunction.Beltsignal.ContainsKey(index) && Multifunction.Beltsignal[index].ContainsKey(id))
			{
				Multifunction.Beltsignal[index].Remove(id);
			}
			if (Multifunction.Beltsignalnumberoutput.ContainsKey(index) && Multifunction.Beltsignalnumberoutput[index].ContainsKey(id))
			{
				Multifunction.Beltsignalnumberoutput[index].Remove(id);
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(CargoTraffic), "SplitterGameTick")]
	public static void CargoTrafficSplitterGameTickPatch(CargoTraffic __instance)
	{
		CargoSignalFunction(__instance);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameMain), "FixedUpdate")]
	public static void CargoTrafficGameTickPatch()
	{
		if (!GameMain.isPaused)
		{
			for (int i = 0; i < GameMain.data.factoryCount; i++)
			{
				CargoSignalFunction(GameMain.data.factories[i].cargoTraffic);
			}
		}
	}

	public static void CargoSignalFunction(CargoTraffic __instance)
	{
		if (!Multifunction.BeltSignalFunction.Value || !Multifunction.FinallyInit)
		{
			return;
		}
		int index = __instance.factory.index;
		if (!Multifunction.Beltsignal.ContainsKey(index))
		{
			return;
		}
		FactorySystem factorySystem = __instance.factory.factorySystem;
		foreach (KeyValuePair<int, int> item2 in Multifunction.Beltsignal[index])
		{
			int value = item2.Value;
			if (value == 404)
			{
				__instance.TryPickItem(item2.Key, 0, 0, out var _, out var _);
				continue;
			}
			int cargoId;
			int offset;
			if (1000 <= value && value < 20000)
			{
				int key = item2.Key;
				BeltComponent beltComponent = factorySystem.traffic.beltPool[key];
				int index2 = beltComponent.segIndex + beltComponent.segPivotOffset;
				int num = (int)factorySystem.factory.entitySignPool[factorySystem.traffic.beltPool[key].entityId].count0;
				if (num == 999999)
				{
					__instance.TryInsertItem(key, 0, value, 1, 0);
				}
				else if (num > 999900 && num % 10 != 0)
				{
					int num2 = num % 100;
					int num3 = num2 % 10;
					int num4 = ((num2 / 10 >= 3) ? 4 : (num2 / 10)) * num3;
					__instance.TryInsertItem(key, 0, value, (byte)num3, (byte)num4);
				}
				else if (num >= 11 && num <= 14)
				{
					bool flag = false;
					int num5 = num % 10;
					CargoPath cargoPath = __instance.GetCargoPath(beltComponent.segPathId);
					cargoPath.GetCargoAtIndex(index2, out var cargo, out cargoId, out offset);
					if (cargo.item > 0)
					{
						continue;
					}
					if (factorySystem.factory.transport?.stationPool != null)
					{
						StationComponent[] stationPool = factorySystem.factory.transport.stationPool;
						foreach (StationComponent stationComponent in stationPool)
						{
							if (flag)
							{
								break;
							}
							if (stationComponent == null || stationComponent.storage == null)
							{
								continue;
							}
							for (int j = 0; j < stationComponent.storage.Length; j++)
							{
								if (stationComponent.storage[j].itemId == value)
								{
									if (stationComponent.storage[j].count < num5)
									{
										break;
									}
									int num6 = Math.Min(stationComponent.storage[j].inc, 4 * num5);
									if (cargoPath.TryInsertItem(index2, value, (byte)num5, (byte)num6))
									{
										stationComponent.storage[j].count -= num5;
										stationComponent.storage[j].inc -= num6;
									}
									flag = true;
								}
							}
						}
					}
					if (flag || factorySystem.factory.factoryStorage == null)
					{
						continue;
					}
					StorageComponent[] storagePool = factorySystem.factory.factoryStorage.storagePool;
					if (storagePool != null)
					{
						StorageComponent[] array = storagePool;
						foreach (StorageComponent storageComponent in array)
						{
							if (flag)
							{
								break;
							}
							if (storageComponent != null && !storageComponent.isEmpty && storageComponent.GetItemCount(value) >= num5)
							{
								storageComponent.TakeItem(value, num5, out var inc2);
								if (!cargoPath.TryInsertItem(index2, value, (byte)num5, (byte)inc2))
								{
									storageComponent.AddItem(value, num5, inc2, out offset);
								}
								flag = true;
								break;
							}
						}
					}
					if (flag)
					{
						continue;
					}
					TankComponent[] tankPool = factorySystem.factory.factoryStorage.tankPool;
					if (tankPool == null)
					{
						continue;
					}
					TankComponent[] array2 = tankPool;
					for (int l = 0; l < array2.Length; l++)
					{
						TankComponent tankComponent = array2[l];
						if (flag)
						{
							break;
						}
						if (tankComponent.fluidId == value && tankComponent.id > 0 && tankComponent.fluidCount >= num5)
						{
							int num7 = Math.Min(tankComponent.fluidInc, num5 * 4);
							if (cargoPath.TryInsertItem(index2, value, (byte)num5, (byte)num7))
							{
								factorySystem.factory.factoryStorage.tankPool[tankComponent.id].fluidInc -= num7;
								factorySystem.factory.factoryStorage.tankPool[tankComponent.id].fluidCount -= num5;
							}
							flag = true;
							break;
						}
					}
				}
				else
				{
					if (num < 21 || num > 24 || factorySystem.minerPool == null)
					{
						continue;
					}
					int num8 = num % 20;
					CargoPath cargoPath2 = __instance.GetCargoPath(beltComponent.segPathId);
					cargoPath2.GetCargoAtIndex(index2, out var cargo2, out offset, out cargoId);
					if (cargo2.item > 0)
					{
						continue;
					}
					MinerComponent[] minerPool = factorySystem.minerPool;
					for (int m = 0; m < minerPool.Length; m++)
					{
						MinerComponent minerComponent = minerPool[m];
						if (minerComponent.id > 0 && minerComponent.entityId > 0 && minerComponent.productId == value && minerComponent.productCount >= num8)
						{
							factorySystem.minerPool[minerComponent.id].productCount -= (cargoPath2.TryInsertItem(index2, value, (byte)num8, 0) ? num8 : 0);
							break;
						}
					}
				}
				continue;
			}
			switch (value)
			{
			case 405:
			{
				BeltComponent beltComponent2 = factorySystem.traffic.beltPool[item2.Key];
				CargoPath cargoPath3 = __instance.GetCargoPath(beltComponent2.segPathId);
				int num10 = beltComponent2.segIndex + beltComponent2.segPivotOffset;
				cargoPath3.GetCargoAtIndex(num10, out var cargo3, out cargoId, out offset);
				int item = cargo3.item;
				if (item < 1000)
				{
					break;
				}
				float count = factorySystem.factory.entitySignPool[beltComponent2.entityId].count0;
				float num11 = count;
				byte stack3;
				byte inc4;
				if (num11 != 1f)
				{
					if (num11 != 5f)
					{
						if (num11 != 6f)
						{
							if (num11 != 8f)
							{
								if (num11 == 9f)
								{
								}
							}
							else
							{
								if (factorySystem.labPool == null)
								{
									break;
								}
								bool flag2 = false;
								LabComponent[] labPool = factorySystem.labPool;
								for (int num12 = 0; num12 < labPool.Length; num12++)
								{
									LabComponent labComponent = labPool[num12];
									if (flag2)
									{
										break;
									}
									if (labComponent.id <= 0 || labComponent.entityId <= 0)
									{
										continue;
									}
									if (labComponent.researchMode)
									{
										if (item < 6001 || item > 6006)
										{
											continue;
										}
										for (int num13 = 0; num13 < labComponent.matrixServed.Length; num13++)
										{
											if (item == 6001 + num13 && labComponent.matrixServed[num13] <= 36000)
											{
												if (cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4) == 0)
												{
													return;
												}
												labComponent.matrixServed[num13] += 3600 * stack3;
												labComponent.matrixIncServed[num13] += inc4;
												break;
											}
										}
									}
									else
									{
										if (!labComponent.matrixMode)
										{
											continue;
										}
										for (int num14 = 0; num14 < labComponent.served.Length; num14++)
										{
											if (item == labComponent.recipeExecuteData.requires[num14] && labComponent.served[num14] <= labComponent.recipeExecuteData.requireCounts[num14] * 2)
											{
												if (cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4) == 0)
												{
													return;
												}
												labComponent.served[num14] += stack3;
												labComponent.incServed[num14] += inc4;
												break;
											}
										}
									}
								}
								if (item != 1503 && item != 1501 && item != 1209 && item != 1803 && item != 1804)
								{
									break;
								}
								if (item == 1209 || item == 1803 || item == 1804)
								{
									if (factorySystem.factory.powerSystem == null || factorySystem.factory.powerSystem.genPool == null)
									{
										break;
									}
									PowerGeneratorComponent[] genPool = factorySystem.factory.powerSystem.genPool;
									for (int num15 = 0; num15 < genPool.Length; num15++)
									{
										PowerGeneratorComponent powerGeneratorComponent = genPool[num15];
										if (powerGeneratorComponent.id <= 0)
										{
											continue;
										}
										if (powerGeneratorComponent.gamma)
										{
											if (item == 1209 && powerGeneratorComponent.catalystPoint == 0)
											{
												if (cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4) == 0)
												{
													return;
												}
												factorySystem.factory.powerSystem.genPool[powerGeneratorComponent.id].catalystPoint += 3600 * stack3;
												factorySystem.factory.powerSystem.genPool[powerGeneratorComponent.id].catalystInc += (short)(3600 * inc4);
												flag2 = true;
												break;
											}
										}
										else if (powerGeneratorComponent.fuelMask == 4 && (item == 1803 || item == 1804) && powerGeneratorComponent.fuelCount <= 2 && (item == 1803 || item == 1804))
										{
											if (cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4) == 0)
											{
												return;
											}
											factorySystem.factory.powerSystem.genPool[powerGeneratorComponent.id].SetNewFuel(item, (short)(factorySystem.factory.powerSystem.genPool[powerGeneratorComponent.id].fuelCount + stack3), inc4);
											flag2 = true;
											break;
										}
									}
									break;
								}
								switch (item)
								{
								case 1503:
								{
									if (factorySystem.siloPool == null)
									{
										break;
									}
									SiloComponent[] siloPool = factorySystem.siloPool;
									for (int num17 = 0; num17 < siloPool.Length; num17++)
									{
										SiloComponent siloComponent = siloPool[num17];
										if (siloComponent.id > 0 && siloComponent.entityId > 0 && siloComponent.bulletCount <= 1)
										{
											cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4);
											factorySystem.siloPool[siloComponent.id].bulletCount += stack3;
											factorySystem.siloPool[siloComponent.id].bulletInc += inc4;
											break;
										}
									}
									break;
								}
								case 1501:
								{
									if (factorySystem.ejectorPool == null)
									{
										break;
									}
									EjectorComponent[] ejectorPool = factorySystem.ejectorPool;
									for (int num16 = 0; num16 < ejectorPool.Length; num16++)
									{
										EjectorComponent ejectorComponent = ejectorPool[num16];
										if (ejectorComponent.id > 0 && ejectorComponent.entityId > 0 && ejectorComponent.bulletCount <= 1)
										{
											cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4);
											factorySystem.ejectorPool[ejectorComponent.id].bulletCount += stack3;
											factorySystem.ejectorPool[ejectorComponent.id].bulletInc += inc4;
											break;
										}
									}
									break;
								}
								}
							}
						}
						else
						{
							if (factorySystem.factory.transport == null || factorySystem.factory.transport.stationPool == null)
							{
								break;
							}
							bool flag2 = false;
							StationComponent[] stationPool2 = factorySystem.factory.transport.stationPool;
							foreach (StationComponent stationComponent2 in stationPool2)
							{
								if (stationComponent2 == null || stationComponent2.storage == null)
								{
									continue;
								}
								for (int num19 = 0; num19 < stationComponent2.storage.Length; num19++)
								{
									if (stationComponent2.storage[num19].itemId == item && stationComponent2.storage[num19].count < stationComponent2.storage[num19].max)
									{
										cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4);
										stationComponent2.AddItem(item, stack3, inc4);
										flag2 = true;
										break;
									}
								}
								if (flag2)
								{
									break;
								}
							}
						}
					}
					else
					{
						if (factorySystem.assemblerPool == null)
						{
							break;
						}
						bool flag2 = false;
						AssemblerComponent[] assemblerPool = factorySystem.assemblerPool;
						for (int num20 = 0; num20 < assemblerPool.Length; num20++)
						{
							AssemblerComponent assemblerComponent = assemblerPool[num20];
							if (flag2)
							{
								break;
							}
							if (assemblerComponent.id <= 0 || assemblerComponent.entityId <= 0 || assemblerComponent.recipeId <= 0)
							{
								continue;
							}
							for (int num21 = 0; num21 < assemblerComponent.served.Length; num21++)
							{
								if (item != assemblerComponent.recipeExecuteData.requires[num21])
								{
									continue;
								}
								if (assemblerComponent.served[num21] < 0)
								{
									assemblerComponent.served[num21] = 0;
								}
								else if (assemblerComponent.served[num21] <= assemblerComponent.recipeExecuteData.requireCounts[num21] * 2)
								{
									if (cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4) == 0)
									{
										return;
									}
									assemblerComponent.served[num21] += stack3;
									assemblerComponent.incServed[num21] += inc4;
									flag2 = true;
									break;
								}
							}
						}
					}
				}
				else
				{
					if (item != 1006 && item != 1007 && item != 1011 && item != 1109 && item != 1114 && item != 1120 && item != 1801 && item != 1802)
					{
						break;
					}
					PowerGeneratorComponent[] array3 = factorySystem.factory.powerSystem?.genPool;
					if (array3 == null)
					{
						break;
					}
					PowerGeneratorComponent[] array4 = array3;
					for (int num22 = 0; num22 < array4.Length; num22++)
					{
						PowerGeneratorComponent powerGeneratorComponent2 = array4[num22];
						if (powerGeneratorComponent2.id <= 0 || powerGeneratorComponent2.fuelCount > 2)
						{
							continue;
						}
						if (powerGeneratorComponent2.fuelMask == 1 && item != 1802)
						{
							if (item == array3[powerGeneratorComponent2.id].fuelId)
							{
								cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4);
								array3[powerGeneratorComponent2.id].SetNewFuel(item, (short)(array3[powerGeneratorComponent2.id].fuelCount + stack3), inc4);
								break;
							}
							if (powerGeneratorComponent2.fuelCount == 0)
							{
								cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4);
								array3[powerGeneratorComponent2.id].SetNewFuel(item, (short)(array3[powerGeneratorComponent2.id].fuelCount + stack3), inc4);
								break;
							}
						}
						if (powerGeneratorComponent2.fuelMask == 2 && item == 1802)
						{
							cargoPath3.TryPickItem(num10 - 5, 12, out stack3, out inc4);
							array3[powerGeneratorComponent2.id].SetNewFuel(1802, (short)(array3[powerGeneratorComponent2.id].fuelCount + stack3), inc4);
							break;
						}
					}
				}
				break;
			}
			case 600:
			{
				if (!Multifunction.Beltsignalnumberoutput.ContainsKey(index))
				{
					break;
				}
				int index3 = (int)factorySystem.factory.entitySignPool[factorySystem.traffic.beltPool[item2.Key].entityId].count0;
				int key2 = Multifunction.Beltsignalnumberoutput[index].FirstOrDefault((KeyValuePair<int, int> x) => x.Value == index3).Key;
				if (index3 > 0 && key2 > 0)
				{
					byte stack2;
					byte inc3;
					int num9 = __instance.TryPickItem(item2.Key, 0, 0, out stack2, out inc3);
					if (num9 >= 1000 && !__instance.TryInsertItem(key2, 0, num9, stack2, inc3))
					{
						__instance.TryInsertItem(item2.Key, 0, num9, stack2, inc3);
					}
				}
				break;
			}
			}
		}
	}
}
