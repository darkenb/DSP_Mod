using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class EjectAnywayPatch
{
	private static Harmony _patch;

	private static bool enable;

	public static string Patchid => "cn.blacksnipe.dsp.Multfuntion_mod.EjectAnywayPatch";

	public static bool Enable
	{
		get
		{
			return enable;
		}
		set
		{
			if (enable != value)
			{
				enable = value;
				if (enable)
				{
					_patch = Harmony.CreateAndPatchAll(typeof(EjectAnywayPatch), Patchid);
				}
				else
				{
					_patch.UnpatchSelf();
				}
			}
		}
	}

	[HarmonyTranspiler]
	[HarmonyPriority(0)]
	[HarmonyPatch(typeof(EjectorComponent), "InternalUpdate")]
	private static IEnumerable<CodeInstruction> EjectorComponent_InternalUpdate_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		codeMatcher.End().MatchBack(true, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(EjectorComponent), "autoOrbit"))).Insert(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldc_I4_1), new CodeInstruction(OpCodes.Stfld, AccessTools.Field(typeof(EjectorComponent), "targetState")), new CodeInstruction(OpCodes.Ldc_I4_1), new CodeInstruction(OpCodes.Stloc_3));
		return codeMatcher.InstructionEnumeration();
	}
}
