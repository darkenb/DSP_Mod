using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class UIPatch
{
	public static bool tempisInstantItem;

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIGame), "On_E_Switch")]
	public static bool CloseWindowPatch()
	{
		if (Multifunction.guidraw.DisplayingWindow)
		{
			Multifunction.guidraw.CloseMainWindow();
			return false;
		}
		return true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIReplicatorWindow), "SetSelectedRecipeIndex")]
	public static void UIReplicatorWindowSetSelectedRecipe(ref UIReplicatorWindow __instance)
	{
		if (!Multifunction.isInstantItem.Value || !tempisInstantItem || !(Traverse.Create(__instance).Field("selectedRecipe").GetValue() is RecipeProto recipeProto))
		{
			return;
		}
		Player mainPlayer = GameMain.mainPlayer;
		RecipeProto recipeProto2 = recipeProto;
		if (recipeProto == null)
		{
			return;
		}
		int num = 1;
		if (__instance.multipliers.ContainsKey(recipeProto.ID))
		{
			num = __instance.multipliers[recipeProto.ID];
		}
		if (num < 1)
		{
			num = 1;
		}
		else if (num > 10)
		{
			num = 10;
		}
		for (int i = 0; i < recipeProto2.Results.Length; i++)
		{
			int num2 = recipeProto2.Results[i];
			int stackSize = LDB.items.Select(num2).StackSize;
			int num3 = (__instance.isBatch ? (num * stackSize) : num);
			int num4 = mainPlayer.TryAddItemToPackage(num2, num3, 0, throwTrash: true);
			int num5 = num3 - num4;
			if (num5 > 0)
			{
				ItemProto itemProto = LDB.items.Select(num2);
				if (itemProto != null)
				{
					UIRealtimeTip.Popup(string.Format("背包已满未添加".Translate(), num5, itemProto.name));
				}
			}
			if (num4 > 0)
			{
				UIItemup.Up(num2, num4);
			}
			mainPlayer.mecha.AddProductionStat(num2, num3, mainPlayer.nearestFactory);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIReplicatorWindow), "_OnOpen")]
	public static void UIReplicatorWindow_OnOpen(ref UIReplicatorWindow __instance)
	{
		if (Multifunction.isInstantItem.Value)
		{
			__instance.isInstantItem = tempisInstantItem;
			__instance.instantItemSwitch.gameObject.SetActive(value: true);
			__instance.instantItemSwitch.SetToggleNoEvent(tempisInstantItem);
			if (tempisInstantItem)
			{
				Traverse.Create(__instance).Method("RefreshRecipeIcons").GetValue();
			}
			__instance.instantItemSwitch.SetToggleNoEvent(tempisInstantItem);
			__instance.batchSwitch.gameObject.SetActive(tempisInstantItem);
			__instance.batchSwitch.SetToggleNoEvent(_isOn: true);
			__instance.sandboxAddUsefulItemButton.gameObject.SetActive(tempisInstantItem);
			__instance.sandboxClearPackageButton.gameObject.SetActive(tempisInstantItem);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIReplicatorWindow), "OnInstantSwitchClick")]
	public static void UIReplicatorWindowOnInstantSwitchClick(ref UIReplicatorWindow __instance)
	{
		if (Multifunction.isInstantItem.Value)
		{
			tempisInstantItem = __instance.isInstantItem;
			__instance.sandboxAddUsefulItemButton.gameObject.SetActive(tempisInstantItem);
			__instance.sandboxClearPackageButton.gameObject.SetActive(tempisInstantItem);
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIReplicatorWindow), "OnOkButtonClick")]
	public static bool UIReplicatorWindowOnOkButtonClick(ref UIReplicatorWindow __instance)
	{
		if (!Multifunction.isInstantItem.Value || !tempisInstantItem)
		{
			return true;
		}
		if (!(Traverse.Create(__instance).Field("selectedRecipe").GetValue() is RecipeProto { ID: var iD }))
		{
			return false;
		}
		int num = 1;
		if (__instance.multipliers.ContainsKey(iD))
		{
			num = __instance.multipliers[iD];
		}
		if (num < 1)
		{
			num = 1;
		}
		else if (num > 10)
		{
			num = 10;
		}
		Player mainPlayer = GameMain.mainPlayer;
		RecipeProto recipeProto2 = LDB.recipes.Select(iD);
		for (int i = 0; i < recipeProto2.Results.Length; i++)
		{
			int num2 = recipeProto2.Results[i];
			int stackSize = LDB.items.Select(num2).StackSize;
			int num3 = (__instance.isBatch ? (num * stackSize) : num);
			int num4 = mainPlayer.TryAddItemToPackage(num2, num3, 0, throwTrash: true);
			int num5 = num3 - num4;
			if (num5 > 0)
			{
				ItemProto itemProto = LDB.items.Select(num2);
				if (itemProto != null)
				{
					UIRealtimeTip.Popup(string.Format("背包已满未添加".Translate(), num5, itemProto.name));
				}
			}
			if (num4 > 0)
			{
				UIItemup.Up(num2, num4);
			}
			mainPlayer.mecha.AddProductionStat(num2, num3, mainPlayer.nearestFactory);
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UITechTree), "_OnUpdate")]
	public static void UITechTreeSelectTechPatch(UITechTree __instance)
	{
		if (!Multifunction.unlockpointtech || __instance.selected == null)
		{
			return;
		}
		TechProto techProto = __instance.selected.techProto;
		if (GameMain.history.techStates[techProto.ID].unlocked || techProto.MaxLevel > 10)
		{
			return;
		}
		if (techProto.Level < techProto.MaxLevel)
		{
			for (int i = 1; i < techProto.MaxLevel; i++)
			{
				for (int j = 0; j < techProto.itemArray.Length; j++)
				{
					Multifunction.AddComsumeItemtoTotal(techProto.Items[j], (int)(techProto.ItemPoints[j] * techProto.GetHashNeeded(techProto.Level) / 3600));
				}
				GameMain.history.UnlockTechFunction(techProto.UnlockFunctions[0], techProto.UnlockValues[0], i);
			}
			GameMain.history.UnlockTech(techProto.ID);
		}
		if (!GameMain.history.techStates[techProto.ID].unlocked)
		{
			for (int k = 0; k < techProto.itemArray.Length; k++)
			{
				Multifunction.AddComsumeItemtoTotal(techProto.Items[k], (int)(techProto.ItemPoints[k] * techProto.GetHashNeeded(techProto.Level) / 3600));
			}
			GameMain.history.UnlockTech(techProto.ID);
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UITechTree), "UpdateScale")]
	public static bool UITechTreeUpdateScalePatch(UITechTree __instance)
	{
		if (Multifunction.unlockpointtech && (__instance.selected != null || __instance.centerViewNode != null))
		{
			return false;
		}
		return true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIStationStorage), "GetAdditionStorage")]
	public static void UIStationWindow_OnOpen(UIStationStorage __instance, ref int __result)
	{
		if (Multifunction.StationStoExtra.Value != 0 && !__instance.station.isCollector)
		{
			int num = (__instance.station.isStellar ? 10000 : 5000);
			__result += Multifunction.StationStoExtra.Value * num;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIAbnormalityTip), "_OnOpen")]
	public static void UIAbnormalityTipDeterminePatch(UIAbnormalityTip __instance)
	{
		if (Multifunction.CloseUIAbnormalityTip.Value)
		{
			__instance._Close();
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIStarmap), "UpdateCursorView")]
	public static void UIStarmapUpdateCursorView(UIStarmap __instance)
	{
		if (Multifunction.EnableTp.Value && __instance.focusPlanet != null)
		{
			Player mainPlayer = GameMain.mainPlayer;
			__instance.fastTravelButton.gameObject.SetActive(mainPlayer.planetId != __instance.focusPlanet.planet.id && !mainPlayer.warping);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIStarmap), "OnFastTravelButtonClick")]
	public static void UIStarmapOnFastTravelButtonClick(UIStarmap __instance)
	{
		if (Multifunction.EnableTp.Value && __instance.focusPlanet != null)
		{
			GameMain.mainPlayer.controller.actionSail.StartFastTravelToPlanet(__instance.focusPlanet.planet);
		}
	}
}
