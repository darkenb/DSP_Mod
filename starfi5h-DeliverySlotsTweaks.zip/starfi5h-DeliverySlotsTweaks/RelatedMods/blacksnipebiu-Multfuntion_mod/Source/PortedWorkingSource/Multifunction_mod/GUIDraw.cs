using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using Multifunction_mod.API;
using Multifunction_mod.Models;
using Multifunction_mod.Patchs;
using Multifunction_mod.Utils;
using UnityEngine;

namespace Multifunction_mod;

public class GUIDraw
{
	private bool isDragging;

	public float DragStartWindowX = 200f;

	public float DragStartWindowY = 200f;

	public float DragStartMouseX = 10f;

	public float DragStartMouseY = 200f;

	private const float TitleBarHeight = 20f;

	private const float BorderMargin = 10f;

	private const float EdgeTolerance = 10f;

	private GUIStyle style;

	private GUIStyle normalStyle;

	private GUIStyle selectedIconStyle;

	private Texture2D selectedTexture;

	private GUIStyle labelmarginStyle;

	private GUIStyle selectedButtonStyle;

	private GUILayoutOption[] slideroptions;

	private GUILayoutOption[] MoreWidthslideroptions;

	private GUILayoutOption[] textfieldoptions;

	private GUILayoutOption[] menusbuttonoptions;

	private GUILayoutOption[] iconbuttonoptions;

	private bool leftscaling;

	private bool rightscaling;

	private bool bottomscaling;

	private bool firstDraw;

	private string stackmultipleStr;

	private Multifunction MainFunction;

	private int whichpannel;

	private Vector2 scrollPosition;

	private Vector2 TabscrollPosition;

	private GameObject ui_MultiFunctionPanel;

	private bool RefreshBaseSize;

	private bool ChangePlayerbool;

	private int baseSize;

	private int heightdis;

	private float mainWindow_x;

	private float mainWindow_y;

	private float mainWindowWidth;

	private float mainWindowHeight;

	private Color textColor;

	private Color mainWindowTextureColor;

	private Texture2D mainWindowTexture;

	public bool ColorChanged;

	public bool MouseInWindow;

	public int BaseSize
	{
		get
		{
			return baseSize;
		}
		set
		{
			baseSize = value;
			Multifunction.scale.Value = value;
			RefreshBaseSize = true;
			heightdis = value * 2;
		}
	}

	public float MainWindow_x
	{
		get
		{
			return mainWindow_x;
		}
		set
		{
			mainWindow_x = value;
			Multifunction.MainWindow_x_config.Value = value;
		}
	}

	public float MainWindow_y
	{
		get
		{
			return mainWindow_y;
		}
		set
		{
			mainWindow_y = value;
			Multifunction.MainWindow_y_config.Value = value;
		}
	}

	public float MainWindowWidth
	{
		get
		{
			return mainWindowWidth;
		}
		set
		{
			mainWindowWidth = value;
			Multifunction.MainWindow_width.Value = value;
		}
	}

	public float MainWindowHeight
	{
		get
		{
			return mainWindowHeight;
		}
		set
		{
			mainWindowHeight = value;
			Multifunction.MainWindow_height.Value = value;
		}
	}

	public bool DisplayingWindow { get; private set; }

	public Color TextColor
	{
		get
		{
			return textColor;
		}
		set
		{
			ColorChanged = true;
			textColor = value;
			Multifunction.Textcolor.Value = value;
		}
	}

	public Color MainWindowTextureColor
	{
		get
		{
			return mainWindowTextureColor;
		}
		set
		{
			mainWindowTextureColor = value;
			Multifunction.mainWindowTextureColor_config.Value = value;
		}
	}

	public Texture2D MainWindowTexture
	{
		get
		{
			return mainWindowTexture;
		}
		set
		{
			mainWindowTexture = value;
		}
	}

	public GUIDraw(int baseSize, GameObject panel, Multifunction multifunction)
	{
		BaseSize = baseSize;
		ui_MultiFunctionPanel = panel;
		MainFunction = multifunction;
		Init();
	}

	private void Init()
	{
		whichpannel = 0;
		scrollPosition[0] = 0f;
		TabscrollPosition[0] = 0f;
		RefreshBaseSize = true;
		ColorChanged = true;
		stackmultipleStr = Multifunction.StackMultiple.Value.ToString();
		MultifunctionAPI.ClearMenus();
		MultifunctionAPI.RegisterMenu("人物", PlayerPannel);
		MultifunctionAPI.RegisterMenu("战斗", BattlePannel);
		MultifunctionAPI.RegisterMenu("建筑", BuildPannel);
		MultifunctionAPI.RegisterMenu("星球", PlanetPannel);
		MultifunctionAPI.RegisterMenu("戴森球", DysonPannel);
		MultifunctionAPI.RegisterMenu("其它功能", OtherPannel);
		MultifunctionAPI.RegisterMenu("机甲物流", LogisticsPannel);
		TextColor = Multifunction.Textcolor.Value;
		MainWindowTextureColor = Multifunction.mainWindowTextureColor_config.Value;
		MainWindowTexture = new Texture2D(10, 10);
		selectedTexture = new Texture2D(1, 1);
		selectedTexture.SetPixel(0, 0, new Color(10f / 51f, 10f / 51f, 10f / 51f));
		selectedTexture.Apply();
		mainWindowTexture.SetPixels(Enumerable.Repeat(MainWindowTextureColor, 100).ToArray());
		mainWindowTexture.Apply();
		mainWindowWidth = Multifunction.MainWindow_width.Value;
		mainWindowHeight = Multifunction.MainWindow_height.Value;
		textColor = Multifunction.Textcolor.Value;
		MainWindow_x = Multifunction.MainWindow_x_config.Value;
		MainWindow_y = Multifunction.MainWindow_y_config.Value;
	}

	public void MainWindowKeyInvoke()
	{
		DisplayingWindow = !DisplayingWindow;
		if (DisplayingWindow)
		{
			firstDraw = true;
		}
		ui_MultiFunctionPanel.SetActive(DisplayingWindow);
	}

	public void OpenMainWindow()
	{
		DisplayingWindow = true;
		ui_MultiFunctionPanel.SetActive(value: true);
	}

	public void CloseMainWindow()
	{
		DisplayingWindow = false;
		ui_MultiFunctionPanel.SetActive(value: false);
	}

	public void Draw()
	{
		if (firstDraw)
		{
			firstDraw = false;
			BaseSize = GUI.skin.label.fontSize;
		}
		if (DisplayingWindow && Input.GetKey(KeyCode.LeftControl))
		{
			int num = (int)(Input.GetAxis("Mouse Wheel") * 10f);
			int num2 = BaseSize + num;
			if (Input.GetKeyDown(KeyCode.UpArrow))
			{
				num2++;
			}
			if (Input.GetKeyDown(KeyCode.DownArrow))
			{
				num2--;
			}
			num2 = Math.Max(5, Math.Min(num2, 35));
			BaseSize = num2;
		}
		if (style == null)
		{
			style = new GUIStyle
			{
				wordWrap = true,
				fontSize = baseSize - 2
			};
			selectedButtonStyle = new GUIStyle(GUI.skin.button);
			selectedButtonStyle.normal.textColor = new Color32(215, 186, 245, byte.MaxValue);
			normalStyle = new GUIStyle();
			selectedIconStyle = new GUIStyle();
			selectedIconStyle.normal.background = selectedTexture;
			labelmarginStyle = new GUIStyle(style)
			{
				margin = new RectOffset(0, 0, 3, 0)
			};
		}
		if (RefreshBaseSize)
		{
			RefreshBaseSize = false;
			GUI.skin.label.fontSize = BaseSize;
			GUI.skin.button.fontSize = BaseSize;
			GUI.skin.toggle.fontSize = BaseSize;
			GUI.skin.textField.fontSize = BaseSize;
			GUI.skin.textArea.fontSize = BaseSize;
			style.fontSize = BaseSize;
			labelmarginStyle.fontSize = BaseSize;
			slideroptions = new GUILayoutOption[1] { GUILayout.Width(heightdis * 6) };
			MoreWidthslideroptions = new GUILayoutOption[1] { GUILayout.Width(heightdis * 8) };
			textfieldoptions = new GUILayoutOption[1] { GUILayout.Width(heightdis * 3) };
			menusbuttonoptions = new GUILayoutOption[2]
			{
				GUILayout.Height(heightdis),
				GUILayout.Width(heightdis * 4)
			};
			iconbuttonoptions = new GUILayoutOption[2]
			{
				GUILayout.Height(heightdis),
				GUILayout.Width(heightdis)
			};
		}
		if (ColorChanged)
		{
			ColorChanged = false;
			GUI.skin.button.normal.textColor = TextColor;
			GUI.skin.textArea.normal.textColor = TextColor;
			GUI.skin.textField.normal.textColor = TextColor;
			GUI.skin.toggle.normal.textColor = TextColor;
			GUI.skin.toggle.onNormal.textColor = TextColor;
			style.normal.textColor = TextColor;
			labelmarginStyle.normal.textColor = TextColor;
		}
		if (DisplayingWindow)
		{
			bool flag = MoveWindow();
			bool flag2 = Scaling_window();
			Rect rect = new Rect(MainWindow_x, MainWindow_y, MainWindowWidth, MainWindowHeight);
			GUI.DrawTexture(rect, mainWindowTexture);
			GUI.Window(20210218, rect, MainWindow, "OP面板".getTranslate() + "(4.0.6)ps:ctrl+↑↓");
			if (flag || flag2)
			{
				UIPanelSet();
			}
			if (MainWindow_x < 0f || MainWindow_x > (float)Screen.width)
			{
				MainWindow_x = 100f;
			}
			if (MainWindow_y < 0f || MainWindow_y > (float)Screen.height)
			{
				MainWindow_y = 100f;
			}
		}
	}

	private void UIPanelSet()
	{
		RectTransform component = ui_MultiFunctionPanel.GetComponent<RectTransform>();
		RectTransform component2 = UIRoot.instance.overlayCanvas.GetComponent<RectTransform>();
		float num = component2.sizeDelta.x * 1f / (float)Screen.width;
		float num2 = component2.sizeDelta.y * 1f / (float)Screen.height;
		component.sizeDelta = new Vector2(num * MainWindowWidth, num2 * MainWindowHeight);
		component.localPosition = new Vector2((0f - component2.sizeDelta.x) / 2f + MainWindow_x * num, component2.sizeDelta.y / 2f - MainWindow_y * num2 - component.sizeDelta.y);
	}

	private void MainWindow(int winId)
	{
		GUILayout.BeginArea(new Rect(10f, 20f, MainWindowWidth, MainWindowHeight));
		GUILayout.BeginVertical();
		GUILayout.BeginHorizontal();
		List<ExternalMenu> externalMenus = MultifunctionAPI.ExternalMenus;
		for (int i = 0; i < externalMenus.Count; i++)
		{
			if (whichpannel == i)
			{
				GUILayout.Button(externalMenus[i].Name.getTranslate(), selectedButtonStyle, menusbuttonoptions);
			}
			else if (GUILayout.Button(externalMenus[i].Name.getTranslate(), menusbuttonoptions))
			{
				whichpannel = i;
			}
		}
		GUILayout.EndHorizontal();
		scrollPosition = GUILayout.BeginScrollView(scrollPosition, GUILayout.Width(MainWindowWidth - 20f), GUILayout.Height(MainWindowHeight - (float)(heightdis * 2)));
		if (whichpannel >= 0 && whichpannel < externalMenus.Count)
		{
			externalMenus[whichpannel].OnDraw?.Invoke();
		}
		GUILayout.EndScrollView();
		GUILayout.EndVertical();
		GUILayout.EndArea();
	}

	public float PropertyDataUIDraw(float num, float left, float right, string propertyName, int resulttype = 0, bool morewidth = false)
	{
		GUILayout.BeginHorizontal();
		float result = GUILayout.HorizontalSlider(num, left, right, morewidth ? MoreWidthslideroptions : slideroptions);
		string text;
		switch (resulttype)
		{
		case 0:
			text = ((int)result).ToString() ?? "";
			break;
		case 1:
			text = NumberUtils.TGMKinttostring(GameMain.mainPlayer.mecha.reactorPowerGen, "W");
			break;
		case 2:
			text = $"{result:N2}";
			break;
		case 3:
			text = NumberUtils.TGMKinttostring(result, "J");
			break;
		case 4:
			text = $"{result:N6}";
			break;
		default:
			return 0f;
		}
		string text2 = GUILayout.TextField(text, textfieldoptions);
		if (text2 != text)
		{
			if (resulttype != 0)
			{
				result = NumberUtils.ConvertToNumber(text2);
			}
			else
			{
				float.TryParse(Regex.Replace(text2, "^[^0-9]", ""), out result);
			}
		}
		GUILayout.Label(propertyName.getTranslate(), labelmarginStyle);
		GUILayout.EndHorizontal();
		return Math.Max(left, Math.Min(right, result));
	}

	private void PlayerPannel()
	{
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical(GUILayout.Width(Multifunction.IsEnglish ? (18 * heightdis) : (14 * heightdis)));
		if (GameMain.mainPlayer != null && Multifunction.propertyData != null)
		{
			PropertyData propertyData = Multifunction.propertyData;
			if (ChangePlayerbool != GUILayout.Toggle(ChangePlayerbool, "启动属性修改".getTranslate()))
			{
				ChangePlayerbool = !ChangePlayerbool;
				if (ChangePlayerbool)
				{
					Multifunction.propertyData.SetContent(Multifunction.player.mecha, GameMain.history, Multifunction.player.deliveryPackage.stackSizeMultiplier);
				}
			}
			if (ChangePlayerbool)
			{
				propertyData.WalkSpeed = PropertyDataUIDraw(propertyData.WalkSpeed, 1f, 100f, "走路速度", 2);
				propertyData.TechSpeed = PropertyDataUIDraw(propertyData.TechSpeed, 1f, 10000f, "研发速度");
				propertyData.DroneSpeed = PropertyDataUIDraw(propertyData.DroneSpeed, 1f, 100f, "小飞机速度");
				propertyData.DroneCount = PropertyDataUIDraw(propertyData.DroneCount, 1f, 256f, "小飞机数量");
				propertyData.MaxSailSpeed = PropertyDataUIDraw(propertyData.MaxSailSpeed, 1f, 10f, "最大航行速度");
				propertyData.MaxWarpSpeed = PropertyDataUIDraw(propertyData.MaxWarpSpeed, 1f, 100f, "最大曲速");
				propertyData.BuildArea = PropertyDataUIDraw(propertyData.BuildArea, 80f, 400f, "建造范围");
				propertyData.ReactorPowerGen = PropertyDataUIDraw(propertyData.ReactorPowerGen, 800000f, 1E+10f, "核心功率", 1);
				propertyData.LogisticCourierSpeed = PropertyDataUIDraw(propertyData.LogisticCourierSpeed, 1f, 100f, "配送机速度");
				propertyData.LogisticDroneSpeedScale = PropertyDataUIDraw(propertyData.LogisticDroneSpeedScale, 1f, 10000f, "运输机速度", 2);
				propertyData.LogisticShipSpeedScale = PropertyDataUIDraw(propertyData.LogisticShipSpeedScale, 1f, 10000f, "运输船速度", 2);
				propertyData.LogisticCourierCarries = PropertyDataUIDraw(propertyData.LogisticCourierCarries, 1f, 10000f, "配送机载量");
				propertyData.LogisticDroneCarries = PropertyDataUIDraw(propertyData.LogisticDroneCarries, 20f, 10000f, "运输机载量");
				propertyData.LogisticShipCarries = PropertyDataUIDraw(propertyData.LogisticShipCarries, 100f, 100000f, "运输船载量");
				propertyData.MiningCostRate = PropertyDataUIDraw(propertyData.MiningCostRate, 0f, 1f, "采矿消耗矿物比例", 4);
				propertyData.MiningSpeedScale = PropertyDataUIDraw(propertyData.MiningSpeedScale, 1f, 10000f, "采矿机速度倍率", 2);
				propertyData.LabLevel = PropertyDataUIDraw(propertyData.LabLevel, 2f, 100f, "建筑堆叠高度");
				propertyData.StorageLevel = PropertyDataUIDraw(propertyData.StorageLevel, 1f, 20f, "货物集装数量");
				propertyData.StackSizeMultiplier = PropertyDataUIDraw(propertyData.StackSizeMultiplier, 1f, 20f, "物流背包堆叠倍率");
			}
			else
			{
				PropertyDataUIDraw(propertyData.WalkSpeed, 1f, 100f, "走路速度", 2);
				PropertyDataUIDraw(propertyData.TechSpeed, 1f, 10000f, "研发速度");
				PropertyDataUIDraw(propertyData.DroneSpeed, 1f, 100f, "小飞机速度");
				PropertyDataUIDraw(propertyData.DroneCount, 1f, 400f, "小飞机数量");
				PropertyDataUIDraw(propertyData.MaxSailSpeed, 1f, 10f, "最大航行速度");
				PropertyDataUIDraw(propertyData.MaxWarpSpeed, 1f, 100f, "最大曲速");
				PropertyDataUIDraw(propertyData.BuildArea, 80f, 400f, "建造范围");
				PropertyDataUIDraw(propertyData.ReactorPowerGen, 1000000f, 1E+10f, "核心功率", 1);
				PropertyDataUIDraw(propertyData.LogisticCourierSpeed, 1f, 100f, "配送机速度");
				PropertyDataUIDraw(propertyData.LogisticDroneSpeedScale, 1f, 10000f, "运输机速度", 2);
				PropertyDataUIDraw(propertyData.LogisticShipSpeedScale, 1f, 10000f, "运输船速度", 2);
				PropertyDataUIDraw(propertyData.LogisticCourierCarries, 1f, 10000f, "配送机载量");
				PropertyDataUIDraw(propertyData.LogisticDroneCarries, 20f, 10000f, "运输机载量");
				PropertyDataUIDraw(propertyData.LogisticShipCarries, 100f, 100000f, "运输船载量");
				PropertyDataUIDraw(propertyData.MiningCostRate, 0f, 1f, "采矿消耗矿物比例", 4);
				PropertyDataUIDraw(propertyData.MiningSpeedScale, 1f, 10000f, "采矿机速度倍率", 2);
				PropertyDataUIDraw(propertyData.LabLevel, 2f, 100f, "建筑堆叠高度");
				PropertyDataUIDraw(propertyData.StorageLevel, 1f, 20f, "货物集装数量");
				PropertyDataUIDraw(propertyData.StackSizeMultiplier, 1f, 20f, "物流背包堆叠倍率");
			}
		}
		GUILayout.EndVertical();
		GUILayout.BeginVertical();
		Multifunction.Infinitething.Value = GUILayout.Toggle(Multifunction.Infinitething.Value, "无限物品".getTranslate());
		Multifunction.InfiniteSand.Value = GUILayout.Toggle(Multifunction.InfiniteSand.Value, "无限沙土".getTranslate());
		Multifunction.Property9999999 = GUILayout.Toggle(Multifunction.Property9999999, "无限元数据".getTranslate());
		Multifunction.DroneNoenergy_bool.Value = GUILayout.Toggle(Multifunction.DroneNoenergy_bool.Value, "小飞机不耗能".getTranslate());
		Multifunction.Infiniteplayerpower.Value = GUILayout.Toggle(Multifunction.Infiniteplayerpower.Value, "无限机甲能量".getTranslate());
		Multifunction.EnableTp.Value = GUILayout.Toggle(Multifunction.EnableTp.Value, "启用传送".getTranslate());
		Multifunction.unlockpointtech = GUILayout.Toggle(Multifunction.unlockpointtech, "科技点击解锁".getTranslate());
		Multifunction.dismantle_but_nobuild.Value = GUILayout.Toggle(Multifunction.dismantle_but_nobuild.Value, "不往背包放东西".getTranslate());
		Multifunction.MiddleMouseLockGrid.Value = GUILayout.Toggle(Multifunction.MiddleMouseLockGrid.Value, "鼠标中键锁定玩家背包格子Max".getTranslate());
		if (Multifunction.QuickHandcraft.Value != GUILayout.Toggle(Multifunction.QuickHandcraft.Value, "机甲制造MAX".getTranslate()))
		{
			Multifunction.QuickHandcraft.Value = !Multifunction.QuickHandcraft.Value;
			if (Multifunction.QuickHandcraft.Value)
			{
				GameMain.mainPlayer.mecha.replicateSpeed = 100f;
			}
			else
			{
				GameMain.mainPlayer.mecha.replicateSpeed = Configs.freeMode.mechaMiningSpeed;
			}
		}
		if (Multifunction.QuickPlayerMine.Value != GUILayout.Toggle(Multifunction.QuickPlayerMine.Value, "机甲采矿MAX".getTranslate()))
		{
			Multifunction.QuickPlayerMine.Value = !Multifunction.QuickPlayerMine.Value;
			if (Multifunction.QuickPlayerMine.Value)
			{
				GameMain.mainPlayer.mecha.miningSpeed = 100f;
			}
			else
			{
				GameMain.mainPlayer.mecha.miningSpeed = Configs.freeMode.mechaReplicateSpeed;
			}
		}
		Multifunction.QuickResearch.Value = GUILayout.Toggle(Multifunction.QuickResearch.Value, "研究秒完成".Translate());
		Multifunction.isInstantItem.Value = GUILayout.Toggle(Multifunction.isInstantItem.Value, "直接获取物品".getTranslate());
		Multifunction.noneedwarp.Value = GUILayout.Toggle(Multifunction.noneedwarp.Value, "无需翘曲器曲速飞行".getTranslate());
		if (GUILayout.Button("清空背包".getTranslate()))
		{
			MainFunction.Clearpackage();
		}
		if (GUILayout.Button("初始化玩家".getTranslate()))
		{
			MainFunction.InitPlayer();
		}
		GUILayout.BeginHorizontal();
		GUILayout.Button("背包".getTranslate(), GUILayout.Height(heightdis * 2));
		GUILayout.BeginVertical();
		if (GUILayout.Button("加一行".getTranslate(), GUILayout.Height(heightdis)))
		{
			MainFunction.Operatepackagesize(1, 0);
		}
		if (GUILayout.Button("加一列".getTranslate(), GUILayout.Height(heightdis)))
		{
			MainFunction.Operatepackagesize(0, 1);
		}
		GUILayout.EndVertical();
		GUILayout.BeginVertical();
		if (GUILayout.Button("减一行".getTranslate(), GUILayout.Height(heightdis)))
		{
			MainFunction.Operatepackagesize(1, 0, add: false);
		}
		if (GUILayout.Button("减一列".getTranslate(), GUILayout.Height(heightdis)))
		{
			MainFunction.Operatepackagesize(0, 1, add: false);
		}
		GUILayout.EndVertical();
		GUILayout.EndHorizontal();
		if (GUILayout.Button("解锁全部科技".getTranslate() + "(" + "补充原料".getTranslate() + ")"))
		{
			MainFunction.UnlockallTech(addstat: true);
		}
		if (GUILayout.Button("解锁全部科技".getTranslate()))
		{
			MainFunction.UnlockallTech();
		}
		if (GUILayout.Button("回退无穷科技".getTranslate()))
		{
			MainFunction.lockTech();
		}
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private void BattlePannel()
	{
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		Multifunction.LockPlayerHp.Value = GUILayout.Toggle(Multifunction.LockPlayerHp.Value, "玩家锁血".getTranslate());
		Multifunction.LockBuildHp.Value = GUILayout.Toggle(Multifunction.LockBuildHp.Value, "建筑锁血".getTranslate());
		Multifunction.LockEnemyHp.Value = GUILayout.Toggle(Multifunction.LockEnemyHp.Value, "怪物锁血".getTranslate());
		Multifunction.PlayerQuickAttack.Value = GUILayout.Toggle(Multifunction.PlayerQuickAttack.Value, "玩家攻速Max".getTranslate());
		Multifunction.PlayerFakeDeath.Value = GUILayout.Toggle(Multifunction.PlayerFakeDeath.Value, "玩家隐身".getTranslate());
		Multifunction.TurrentKeepSuperNoval.Value = GUILayout.Toggle(Multifunction.TurrentKeepSuperNoval.Value, "炮塔永久超新星".getTranslate());
		GUILayout.BeginHorizontal();
		GUILayout.Space(20f);
		Multifunction.TurrentKeepSuperNovalQuickKey.Value = GUILayout.Toggle(Multifunction.TurrentKeepSuperNovalQuickKey.Value, "启用快捷键(ctrl+s)".getTranslate());
		GUILayout.EndHorizontal();
		Multifunction.ClickGenerateDFRelay = GUILayout.Toggle(Multifunction.ClickGenerateDFRelay, "点击生成中继站".getTranslate());
		Multifunction.ClickKillEnemy.Value = GUILayout.Toggle(Multifunction.ClickKillEnemy.Value, "点击杀死敌人".getTranslate());
		if (Multifunction.ClickKillEnemy.Value)
		{
			GUILayout.BeginHorizontal();
			GUILayout.Label("点击模式".getTranslate());
			bool flag = GUILayout.Toggle(Multifunction.ClickKillEnemyMode.Value == 0, "点按".getTranslate());
			bool flag2 = GUILayout.Toggle(Multifunction.ClickKillEnemyMode.Value == 1, "按压".getTranslate());
			if (flag && Multifunction.ClickKillEnemyMode.Value == 1)
			{
				Multifunction.ClickKillEnemyMode.Value = 0;
			}
			else if (flag2 && Multifunction.ClickKillEnemyMode.Value == 0)
			{
				Multifunction.ClickKillEnemyMode.Value = 1;
			}
			GUILayout.EndHorizontal();
			Multifunction.ClickKillEnemyBaseChain = GUILayout.Toggle(Multifunction.ClickKillEnemyBaseChain, "基地核心连锁拆除".getTranslate());
		}
		Multifunction.LocalAlwaysClearThreat.Value = GUILayout.Toggle(Multifunction.LocalAlwaysClearThreat.Value, "星球永远0威胁".getTranslate());
		Multifunction.LocalAlwaysMaxThreat.Value = GUILayout.Toggle(Multifunction.LocalAlwaysMaxThreat.Value, "玩家所在星球永远满威胁".getTranslate());
		Multifunction.SpaceAlwaysClearThreat.Value = GUILayout.Toggle(Multifunction.SpaceAlwaysClearThreat.Value, "太空永远0威胁".getTranslate());
		Multifunction.SpaceAlwaysMaxThreat.Value = GUILayout.Toggle(Multifunction.SpaceAlwaysMaxThreat.Value, "玩家所在星系永远满威胁".getTranslate());
		Multifunction.ModifyDarkFogLevel.Value = GUILayout.Toggle(Multifunction.ModifyDarkFogLevel.Value, "调整黑雾怪物等级".getTranslate());
		GUILayout.Label("黑雾怪物等级".getTranslate() + ":" + Multifunction.ModifyDarkFogLevelValue.Value, style);
		Multifunction.ModifyDarkFogLevelValue.Value = (int)GUILayout.HorizontalSlider(Multifunction.ModifyDarkFogLevelValue.Value, 0f, 30f);
		if (GUILayout.Button("设置当前星球黑雾等级"))
		{
			ObjectPool<DFGBaseComponent> objectPool = GameMain.localPlanet?.factory?.enemySystem?.bases;
			if (objectPool != null)
			{
				for (int i = 1; i < objectPool.cursor; i++)
				{
					DFGBaseComponent dFGBaseComponent = objectPool[i];
					if (dFGBaseComponent != null && dFGBaseComponent.id == i)
					{
						Debug.Log(i);
						dFGBaseComponent.evolve.level = Multifunction.ModifyDarkFogLevelValue.Value;
					}
				}
			}
		}
		if (GUILayout.Button("设置当前星系太空黑雾等级") && GameMain.localStar != null)
		{
			EnemyDFHiveSystem[] array = GameMain.data?.spaceSector?.dfHives;
			if (array != null)
			{
				EnemyDFHiveSystem[] array2 = array;
				foreach (EnemyDFHiveSystem enemyDFHiveSystem in array2)
				{
					if (enemyDFHiveSystem != null && enemyDFHiveSystem.starData != null && enemyDFHiveSystem.starData.id == GameMain.localStar.id)
					{
						enemyDFHiveSystem.evolve.level = Multifunction.ModifyDarkFogLevelValue.Value;
					}
				}
			}
		}
		GUILayout.EndVertical();
		GUILayout.Space(10f);
		GUILayout.BeginVertical();
		PropertyData propertyData = Multifunction.propertyData;
		if (GameMain.mainPlayer != null && Multifunction.propertyData != null)
		{
			if (ChangePlayerbool != GUILayout.Toggle(ChangePlayerbool, "启动属性修改".getTranslate()))
			{
				ChangePlayerbool = !ChangePlayerbool;
				if (ChangePlayerbool)
				{
					Multifunction.propertyData.SetContent(Multifunction.player.mecha, GameMain.history, Multifunction.player.deliveryPackage.stackSizeMultiplier);
				}
			}
			ModeConfig freeMode = Configs.freeMode;
			if (ChangePlayerbool)
			{
				propertyData.KineticDamageScale = PropertyDataUIDraw(propertyData.KineticDamageScale, 1f, 100f, "动能武器伤害系数", 2, morewidth: true);
				propertyData.EnergyDamageScale = PropertyDataUIDraw(propertyData.EnergyDamageScale, 1f, 100f, "能量武器伤害系数", 2, morewidth: true);
				propertyData.BlastDamageScale = PropertyDataUIDraw(propertyData.BlastDamageScale, 1f, 100f, "爆破武器伤害系数", 2, morewidth: true);
				propertyData.MagneticDamageScale = PropertyDataUIDraw(propertyData.MagneticDamageScale, 1f, 100f, "电磁武器伤害系数", 2, morewidth: true);
				propertyData.GlobalHpEnhancement = PropertyDataUIDraw(propertyData.GlobalHpEnhancement, 0f, 100f, "全局耐久度倍率", 2, morewidth: true);
				propertyData.EnemyDropScale = PropertyDataUIDraw(propertyData.EnemyDropScale, 0f, 1000f, "残骸产出倍率", 2, morewidth: true);
				propertyData.EnergyShieldRadius = PropertyDataUIDraw(propertyData.EnergyShieldRadius, freeMode.energyShieldRadius, 450f, "玩家护盾半径", 2, morewidth: true);
				propertyData.EnergyShieldCapacity = (long)PropertyDataUIDraw(propertyData.EnergyShieldCapacity, freeMode.energyShieldCapacity, 1E+11f, "玩家护盾能量上限", 3, morewidth: true);
				propertyData.HpMaxUpgrade = (int)PropertyDataUIDraw(propertyData.HpMaxUpgrade, 0f, 100000f, "玩家额外血量", 0, morewidth: true);
				propertyData.LaserAttackLocalRange = PropertyDataUIDraw(propertyData.LaserAttackLocalRange, freeMode.mechaLocalLaserAttackRange, 150f, "机甲激光本地攻击范围", 2, morewidth: true);
				propertyData.LaserAttackSpaceRange = PropertyDataUIDraw(propertyData.LaserAttackSpaceRange, freeMode.mechaSpaceLaserAttackRange, 15000f, "机甲激光太空攻击范围", 2, morewidth: true);
				propertyData.LaserAttackDamage = PropertyDataUIDraw(propertyData.LaserAttackDamage, 0f, 10000f, "机甲激光伤害", 2, morewidth: true);
				propertyData.LaserEnergyCost = PropertyDataUIDraw(propertyData.LaserEnergyCost, 0f, freeMode.mechaLocalLaserEnergyCost, "机甲激光消耗能量", 3, morewidth: true);
				propertyData.CombatDroneDamageRatio = PropertyDataUIDraw(propertyData.CombatDroneDamageRatio, 1f, 100f, "战斗飞机伤害倍率", 2, morewidth: true);
				propertyData.CombatDroneROFRatio = PropertyDataUIDraw(propertyData.CombatDroneROFRatio, 1f, 100f, "战斗飞机攻击速度倍率", 2, morewidth: true);
				propertyData.CombatDroneDurabilityRatio = PropertyDataUIDraw(propertyData.CombatDroneDurabilityRatio, 1f, 100f, "战斗飞机耐久度倍率", 2, morewidth: true);
				propertyData.CombatDroneSpeedRatio = PropertyDataUIDraw(propertyData.CombatDroneSpeedRatio, 1f, 100f, "战斗飞机速度倍率", 2, morewidth: true);
				propertyData.CombatShipDamageRatio = PropertyDataUIDraw(propertyData.CombatShipDamageRatio, 1f, 100f, "战斗飞船伤害倍率", 2, morewidth: true);
				propertyData.CombatShipROFRatio = PropertyDataUIDraw(propertyData.CombatShipROFRatio, 1f, 100f, "战斗飞船攻击速度倍率", 2, morewidth: true);
				propertyData.CombatShipDurabilityRatio = PropertyDataUIDraw(propertyData.CombatShipDurabilityRatio, 1f, 100f, "战斗飞船耐久度倍率", 2, morewidth: true);
				propertyData.CombatShipSpeedRatio = PropertyDataUIDraw(propertyData.CombatShipSpeedRatio, 1f, 100f, "战斗飞船速度倍率", 2, morewidth: true);
				propertyData.PlanetaryATFieldEnergyRate = (int)PropertyDataUIDraw(propertyData.PlanetaryATFieldEnergyRate, 1f, 100f, "星球防御盾能量倍率", 2, morewidth: true);
			}
			else
			{
				PropertyDataUIDraw(propertyData.KineticDamageScale, 1f, 100f, "动能武器伤害系数", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.EnergyDamageScale, 1f, 100f, "能量武器伤害系数", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.BlastDamageScale, 1f, 100f, "爆破武器伤害系数", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.MagneticDamageScale, 1f, 100f, "电磁武器伤害系数", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.GlobalHpEnhancement, 0f, 100f, "全局耐久度倍率", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.EnemyDropScale, 0f, 1000f, "残骸产出倍率", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.EnergyShieldRadius, freeMode.energyShieldRadius, 450f, "玩家护盾半径", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.EnergyShieldCapacity, freeMode.energyShieldCapacity, 1E+11f, "玩家护盾能量上限", 3, morewidth: true);
				PropertyDataUIDraw(propertyData.HpMaxUpgrade, 0f, 100000f, "玩家额外血量", 1, morewidth: true);
				PropertyDataUIDraw(propertyData.LaserAttackLocalRange, freeMode.mechaLocalLaserAttackRange, 150f, "机甲激光本地攻击范围", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.LaserAttackSpaceRange, freeMode.mechaSpaceLaserAttackRange, 15000f, "机甲激光太空攻击范围", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.LaserAttackDamage, 0f, 10000f, "机甲激光伤害", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.LaserEnergyCost, 0f, freeMode.mechaLocalLaserEnergyCost, "机甲激光消耗能量", 3, morewidth: true);
				PropertyDataUIDraw(propertyData.CombatDroneDamageRatio, 1f, 100f, "战斗飞机伤害倍率", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.CombatDroneROFRatio, 1f, 100f, "战斗飞机攻击速度倍率", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.CombatDroneDurabilityRatio, 1f, 100f, "战斗飞机耐久度倍率", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.CombatDroneSpeedRatio, 1f, 100f, "战斗飞机速度倍率", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.CombatShipDamageRatio, 1f, 100f, "战斗飞船伤害倍率", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.CombatShipROFRatio, 1f, 100f, "战斗飞船攻击速度倍率", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.CombatShipDurabilityRatio, 1f, 100f, "战斗飞船耐久度倍率", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.CombatShipSpeedRatio, 1f, 100f, "战斗飞船速度倍率", 2, morewidth: true);
				PropertyDataUIDraw(propertyData.PlanetaryATFieldEnergyRate, 1f, 100f, "星球防御盾能量倍率", 2, morewidth: true);
			}
		}
		GUILayout.EndVertical();
		GUILayout.EndHorizontal();
	}

	private void BuildPannel()
	{
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		GUILayout.Label("物流站功能".getTranslate() + ":", style);
		GUILayout.BeginHorizontal();
		GUILayout.Space(BaseSize);
		GUILayout.BeginVertical();
		GUILayout.Label("额外存储倍率".getTranslate() + ":" + Multifunction.StationStoExtra.Value, style);
		Multifunction.StationStoExtra.Value = (int)GUILayout.HorizontalSlider(Multifunction.StationStoExtra.Value, 0f, 100f, GUILayout.Width(heightdis * 4));
		Multifunction.Stationfullenergy.Value = GUILayout.Toggle(Multifunction.Stationfullenergy.Value, "永久满电".getTranslate());
		Multifunction.StationfullCount = GUILayout.Toggle(Multifunction.StationfullCount, "要啥有啥".getTranslate());
		Multifunction.StationMaxproliferator.Value = GUILayout.Toggle(Multifunction.StationMaxproliferator.Value, "无限增产".getTranslate());
		Multifunction.StationSpray.Value = GUILayout.Toggle(Multifunction.StationSpray.Value, "内置喷涂".getTranslate());
		Multifunction.StationPowerGen.Value = GUILayout.Toggle(Multifunction.StationPowerGen.Value, "内置发电".getTranslate());
		Multifunction.Station_infiniteWarp_bool.Value = GUILayout.Toggle(Multifunction.Station_infiniteWarp_bool.Value, "无限翘曲".getTranslate());
		Multifunction.build_station_nocondition.Value = GUILayout.Toggle(Multifunction.build_station_nocondition.Value, "建造无需条件".getTranslate());
		GUILayout.Label("以下功能需改名".getTranslate() + ":", style);
		Multifunction.StationfullCount_bool.Value = GUILayout.Toggle(Multifunction.StationfullCount_bool.Value, "星球无限供货机".getTranslate());
		Multifunction.StationTrash.Value = GUILayout.Toggle(Multifunction.StationTrash.Value, "垃圾站".getTranslate());
		if (Multifunction.StationTrash.Value)
		{
			GUILayout.BeginHorizontal();
			GUILayout.Space(BaseSize);
			Multifunction.needtrashsand.Value = GUILayout.Toggle(Multifunction.needtrashsand.Value, "需要沙土".getTranslate());
			GUILayout.EndHorizontal();
		}
		Multifunction.StationMiner.Value = GUILayout.Toggle(Multifunction.StationMiner.Value, "星球矿机".getTranslate());
		if (Multifunction.StationMiner.Value)
		{
			GUILayout.BeginHorizontal();
			GUILayout.Space(BaseSize);
			GUILayout.BeginVertical();
			GUILayout.Label("采矿速率".getTranslate() + ":" + Multifunction.Stationminenumber.Value, style);
			Multifunction.Stationminenumber.Value = (int)GUILayout.HorizontalSlider(Multifunction.Stationminenumber.Value, 1f, 100f, GUILayout.Width(heightdis * 4));
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
		}
		Multifunction.StationSprayer.Value = GUILayout.Toggle(Multifunction.StationSprayer.Value, "喷涂加工厂".getTranslate());
		Multifunction.StationMinerSmelter.Value = GUILayout.Toggle(Multifunction.StationMinerSmelter.Value, "星球熔炉矿机".getTranslate());
		if (Multifunction.StationMinerSmelter.Value)
		{
			GUILayout.BeginHorizontal();
			GUILayout.Space(BaseSize);
			GUILayout.BeginVertical();
			GUILayout.Label("等价高级熔炉数量".getTranslate() + ":" + Multifunction.StationMinerSmelterNum.Value, style);
			int num = (int)GUILayout.HorizontalSlider(Multifunction.StationMinerSmelterNum.Value, 30f, 1000f, GUILayout.Width(heightdis * 4));
			if (num % 100 <= num % 30)
			{
				Multifunction.StationMinerSmelterNum.Value = num / 100 * 100;
			}
			else
			{
				Multifunction.StationMinerSmelterNum.Value = num / 30 * 30;
			}
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
		}
		GUILayout.Label("自动改名".getTranslate() + ":", style);
		string[] array = new string[7] { "星球无限供货机", "垃圾站", "星球矿机", "喷涂加工厂", "星球熔炉矿机", "星球量子传输站", "星系量子传输站" };
		for (int i = 0; i < array.Length; i++)
		{
			bool flag = GUILayout.Toggle(Multifunction.AutoChangeStationName.Value == array[i], array[i].getTranslate());
			if (flag && Multifunction.AutoChangeStationName.Value != array[i])
			{
				Multifunction.AutoChangeStationName.Value = array[i];
			}
			else if (!flag && Multifunction.AutoChangeStationName.Value == array[i])
			{
				Multifunction.AutoChangeStationName.Value = "";
			}
		}
		GUILayout.EndVertical();
		GUILayout.EndHorizontal();
		GUILayout.EndVertical();
		GUILayout.BeginVertical();
		GUILayout.Label("其它建筑功能".getTranslate() + ":", style);
		GUILayout.BeginHorizontal();
		GUILayout.Space(BaseSize);
		GUILayout.BeginVertical();
		GUILayout.Label("建造数量最大值".getTranslate() + ":" + Multifunction.Buildmaxlen.Value, style);
		int num2 = (int)GUILayout.HorizontalSlider(Multifunction.Buildmaxlen.Value, 15f, 100f, GUILayout.Width(heightdis * 4));
		if (num2 != Multifunction.Buildmaxlen.Value)
		{
			Multifunction.Buildmaxlen.Value = num2;
			GameMain.mainPlayer.controller.actionBuild.clickTool.dotsSnapped = new Vector3[num2];
		}
		Multifunction.InspectDisNoLimit.Value = GUILayout.Toggle(Multifunction.InspectDisNoLimit.Value, "操作范围不受限制".getTranslate());
		Multifunction.BuildNotime_bool.Value = GUILayout.Toggle(Multifunction.BuildNotime_bool.Value, "建筑秒完成".getTranslate());
		Multifunction.blueprintpastenoneed_bool.Value = GUILayout.Toggle(Multifunction.blueprintpastenoneed_bool.Value, "蓝图建造无需材料".getTranslate());
		Multifunction.ArchitectMode.Value = GUILayout.Toggle(Multifunction.ArchitectMode.Value, "建筑师模式".getTranslate());
		if (Multifunction.DriftBuildings != GUILayout.Toggle(Multifunction.DriftBuildings, "建筑抬升".getTranslate()))
		{
			Multifunction.DriftBuildings = !Multifunction.DriftBuildings;
			if (Multifunction.DriftBuildings && !DriftBuildingsPatch.IsPatched)
			{
				DriftBuildingsPatch.IsPatched = true;
				Multifunctionpatch.harmony.PatchAll(typeof(DriftBuildingsPatch));
			}
		}
		if (Multifunction.DriftBuildings)
		{
			GUILayout.Label("抬升层数:" + Multifunction.DriftBuildingLevel, style);
		}
		if (Multifunction.BeltSignalFunction.Value != GUILayout.Toggle(Multifunction.BeltSignalFunction.Value, "传送带信号功能".getTranslate()))
		{
			Multifunction.BeltSignalFunction.Value = !Multifunction.BeltSignalFunction.Value;
			if (Multifunction.BeltSignalFunction.Value)
			{
				MainFunction.InitBeltSignalDiction();
			}
		}
		GUILayout.EndVertical();
		GUILayout.EndHorizontal();
		GUILayout.Label("电力设备".getTranslate() + ":", style);
		GUILayout.BeginHorizontal();
		GUILayout.Space(BaseSize);
		GUILayout.BeginVertical();
		Multifunction.Buildingnoconsume.Value = GUILayout.Toggle(Multifunction.Buildingnoconsume.Value, "新建设备不耗电".getTranslate());
		Multifunction.InfineteStarPower.Value = GUILayout.Toggle(Multifunction.InfineteStarPower.Value, "人造恒星无限能源".getTranslate());
		Multifunction.PlanetPower_bool.Value = GUILayout.Toggle(Multifunction.PlanetPower_bool.Value, "星球电网(人造恒星)".getTranslate());
		if (Multifunction.PlanetPower_bool.Value)
		{
			GUILayout.BeginHorizontal();
			GUILayout.Space(BaseSize);
			GUILayout.BeginVertical();
			Multifunction.PlanetPower_bool.Value = GUILayout.Toggle(Multifunction.PlanetPower_bool.Value, "覆盖全球".getTranslate());
			Multifunction.farconnectdistance = GUILayout.Toggle(Multifunction.farconnectdistance, "超长连接".getTranslate());
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
		}
		Multifunction.WindturbinesUnlimitedEnergy.Value = GUILayout.Toggle(Multifunction.WindturbinesUnlimitedEnergy.Value, "风力涡轮机无限能源".getTranslate());
		Multifunction.Windturbinescovertheglobe.Value = GUILayout.Toggle(Multifunction.Windturbinescovertheglobe.Value, "风力涡轮机覆盖全球".getTranslate());
		GUILayout.EndVertical();
		GUILayout.EndHorizontal();
		GUILayout.Label("储液站功能".getTranslate() + ":", style);
		GUILayout.BeginHorizontal();
		GUILayout.Space(BaseSize);
		GUILayout.BeginVertical();
		Multifunction.Tankcontentall.Value = GUILayout.Toggle(Multifunction.Tankcontentall.Value, "储液站任意存".getTranslate());
		Multifunction.Infinitestoragetank.Value = GUILayout.Toggle(Multifunction.Infinitestoragetank.Value, "无限储液站".getTranslate());
		Multifunction.TankMaxproliferator.Value = GUILayout.Toggle(Multifunction.TankMaxproliferator.Value, "储液站无限增产".getTranslate());
		GUILayout.EndVertical();
		GUILayout.EndHorizontal();
		GUILayout.EndVertical();
		GUILayout.BeginVertical();
		Multifunction.Quantumtransport_bool.Value = GUILayout.Toggle(Multifunction.Quantumtransport_bool.Value, "量子传输站".getTranslate());
		if (Multifunction.Quantumtransport_bool.Value)
		{
			Multifunction.Quantumtransportpdwarp_bool.Value = GUILayout.Toggle(Multifunction.Quantumtransportpdwarp_bool.Value, "星球级翘曲全面供应".getTranslate());
			Multifunction.Quantumtransportstarwarp_bool.Value = GUILayout.Toggle(Multifunction.Quantumtransportstarwarp_bool.Value, "星系级翘曲全面供应".getTranslate());
			Multifunction.Quantumtransportbuild_bool.Value = GUILayout.Toggle(Multifunction.Quantumtransportbuild_bool.Value, "星球级材料供应".getTranslate());
			if (Multifunction.Quantumtransportbuild_bool.Value)
			{
				GUILayout.BeginVertical();
				GUILayout.BeginHorizontal();
				Multifunction.QuantumtransportCollectorSupply.Value = GUILayout.Toggle(Multifunction.QuantumtransportCollectorSupply.Value, "采集器拿取");
				GUILayout.EndHorizontal();
				GUILayout.BeginHorizontal();
				Multifunction.QuantumtransportstationSupply.Value = GUILayout.Toggle(Multifunction.QuantumtransportstationSupply.Value, "物流站供应");
				Multifunction.QuantumtransportstationDemand.Value = GUILayout.Toggle(Multifunction.QuantumtransportstationDemand.Value, "物流站拿取");
				GUILayout.EndHorizontal();
				GUILayout.BeginHorizontal();
				Multifunction.QuantumtransportminerDemand.Value = GUILayout.Toggle(Multifunction.QuantumtransportminerDemand.Value, "矿机拿取");
				GUILayout.EndHorizontal();
				GUILayout.BeginHorizontal();
				Multifunction.QuantumtransportsiloDemand.Value = GUILayout.Toggle(Multifunction.QuantumtransportsiloDemand.Value, "发射井弹射器供应");
				GUILayout.EndHorizontal();
				GUILayout.BeginHorizontal();
				Multifunction.QuantumtransportlabSupply.Value = GUILayout.Toggle(Multifunction.QuantumtransportlabSupply.Value, "研究站供应");
				Multifunction.QuantumtransportlabDemand.Value = GUILayout.Toggle(Multifunction.QuantumtransportlabDemand.Value, "研究站拿取");
				GUILayout.EndHorizontal();
				GUILayout.BeginHorizontal();
				Multifunction.QuantumtransportpowerSupply.Value = GUILayout.Toggle(Multifunction.QuantumtransportpowerSupply.Value, "电力设备供应");
				Multifunction.QuantumtransportpowerDemand.Value = GUILayout.Toggle(Multifunction.QuantumtransportpowerDemand.Value, "电力设备拿取");
				GUILayout.EndHorizontal();
				GUILayout.BeginHorizontal();
				Multifunction.QuantumtransportassembleSupply.Value = GUILayout.Toggle(Multifunction.QuantumtransportassembleSupply.Value, "组装机供应");
				Multifunction.QuantumtransportassembleDemand.Value = GUILayout.Toggle(Multifunction.QuantumtransportassembleDemand.Value, "组装机拿取");
				GUILayout.EndHorizontal();
				GUILayout.EndVertical();
			}
			GUILayoutOption[] options = new GUILayoutOption[2]
			{
				GUILayout.Height(heightdis),
				GUILayout.Width(heightdis * 5)
			};
			GUILayout.BeginHorizontal();
			int num3 = (int)GUILayout.HorizontalSlider(Multifunction.planetquamaxpowerpertick.Value, 60f, 10000f, options);
			GUILayout.Label((num3 > 1000) ? (num3 / 1000 + "G") : (num3 + "MW " + "星球量子充电功率".getTranslate()), style);
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal();
			int num4 = (int)GUILayout.HorizontalSlider(Multifunction.starquamaxpowerpertick.Value, 60f, 10000f, options);
			GUILayout.Label((num4 > 1000) ? (num4 / 1000 + "G") : (num4 + "MW " + "星系量子充电功率".getTranslate()), style);
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal();
			Multifunction.Quantumenergy.Value = (int)GUILayout.HorizontalSlider(Multifunction.Quantumenergy.Value, 0f, 1000000f, options);
			GUILayout.Label(NumberUtils.TGMKinttostring(Multifunction.Quantumenergy.Value, "J") + " " + "量子耗能/个".getTranslate(), style);
			GUILayout.EndHorizontal();
			if ((float)num3 != Multifunction.planetquamaxpowerpertick.Value || (float)num4 != Multifunction.starquamaxpowerpertick.Value)
			{
				Multifunction.changequapowerpertick = true;
				Multifunction.planetquamaxpowerpertick.Value = num3;
				Multifunction.starquamaxpowerpertick.Value = num4;
			}
		}
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private void PlanetPannel()
	{
		GUILayout.Label("\"生成矿物\":鼠标左键生成矿物，鼠标右键取消。\"删除矿物\"：按x键进入拆除模式可拆除矿物。".getTranslate(), style);
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		VeinControlProperty veinproperty = Multifunction.veinproperty;
		veinproperty.DeleteVein = GUILayout.Toggle(veinproperty.DeleteVein, "删除矿物".getTranslate());
		veinproperty.Changeveinpos = GUILayout.Toggle(veinproperty.Changeveinpos, "移动单矿".getTranslate());
		veinproperty.Changeveingrouppos = GUILayout.Toggle(veinproperty.Changeveingrouppos, "移动矿堆".getTranslate());
		veinproperty.NotTidyVein = GUILayout.Toggle(veinproperty.NotTidyVein, "不排列".getTranslate());
		veinproperty.GetallVein = GUILayout.Toggle(veinproperty.GetallVein, "整理所有矿".getTranslate());
		GUILayout.Label("整理为".getTranslate() + veinproperty.VeinLines + "行".getTranslate());
		veinproperty.VeinLines = (int)GUILayout.HorizontalSlider(veinproperty.VeinLines, 1f, 20f);
		veinproperty.Changexveinspos = GUILayout.Toggle(veinproperty.Changexveinspos, "切割矿脉".getTranslate());
		GUILayout.Label("切割出".getTranslate() + veinproperty.CuttingVeinNumbers + "个".getTranslate());
		veinproperty.CuttingVeinNumbers = (int)GUILayout.HorizontalSlider(veinproperty.CuttingVeinNumbers, 2f, 72f);
		GUILayout.EndVertical();
		GUILayout.Space(heightdis);
		GUILayout.BeginVertical();
		GUILayoutOption[] options = new GUILayoutOption[2]
		{
			GUILayout.Height(heightdis),
			GUILayout.Width(heightdis)
		};
		int num = 8;
		int num2 = LDB.veins.dataArray.Length;
		int num3 = num2 / num + ((num2 % num > 0) ? 1 : 0);
		for (int i = 0; i < num3; i++)
		{
			GUILayout.BeginHorizontal();
			for (int j = 0; j < num; j++)
			{
				int num4 = i * num + j + 1;
				if (num4 == num2 + 1)
				{
					break;
				}
				if (GUILayout.Button(LDB.items?.Select(LDB.veins.Select(num4).MiningItem)?.iconSprite?.texture, (veinproperty.VeinType == num4) ? selectedIconStyle : normalStyle, options))
				{
					veinproperty.VeinType = ((veinproperty.VeinType != num4) ? num4 : 0);
				}
			}
			GUILayout.EndHorizontal();
		}
		GUILayout.BeginHorizontal();
		GUILayout.Label("生成矿物模式".getTranslate());
		bool flag = GUILayout.Toggle(veinproperty.AddVeinMode == 0, "点按".getTranslate());
		bool flag2 = GUILayout.Toggle(veinproperty.AddVeinMode == 1, "按压".getTranslate());
		GUILayout.EndHorizontal();
		if (flag && veinproperty.AddVeinMode == 1)
		{
			veinproperty.AddVeinMode = 0;
		}
		else if (flag2 && veinproperty.AddVeinMode == 0)
		{
			veinproperty.AddVeinMode = 1;
		}
		if (veinproperty.VeinType == 7)
		{
			GUILayout.BeginHorizontal();
			GUILayout.Label("添加油井速率".getTranslate());
			for (int k = 0; k < 3; k++)
			{
				bool flag3 = GUILayout.Toggle(veinproperty.OilAddIntervalBool[k], (float)veinproperty.OilAddIntervalValue[k] / 10f + "/s");
				if (flag3 != veinproperty.OilAddIntervalBool[k] && flag3)
				{
					veinproperty.SetOilAddInterval(k);
				}
			}
			GUILayout.EndHorizontal();
		}
		else
		{
			GUILayout.BeginHorizontal();
			GUILayout.Label("添加矿脉数量".getTranslate());
			bool flag4 = GUILayout.Toggle(veinproperty.AddVeinNumber == 500, "500");
			bool flag5 = GUILayout.Toggle(veinproperty.AddVeinNumber != 500, "无穷".getTranslate());
			if (flag4 && veinproperty.AddVeinNumber != 500)
			{
				veinproperty.AddVeinNumber = 500;
			}
			else if (flag5 && veinproperty.AddVeinNumber == 500)
			{
				veinproperty.AddVeinNumber = 1000000000;
			}
			GUILayout.EndHorizontal();
		}
		GUILayout.EndVertical();
		GUILayout.Space(heightdis);
		GUILayout.BeginVertical();
		Multifunction.restorewater = GUILayout.Toggle(Multifunction.restorewater, "还原海洋".getTranslate());
		string[] array = new string[6]
		{
			(!Multifunction.restorewater) ? "铺平整个星球" : "还原全部海洋",
			"掩埋全部矿",
			"删除全部矿",
			"超密铺采集器",
			"删除当前星球所有建筑",
			"删除当前星球所有建筑(不掉落)"
		};
		for (int l = 0; l < array.Length; l++)
		{
			if (GUILayout.Button(array[l].getTranslate(), GUILayout.Height(heightdis)))
			{
				switch (l)
				{
				case 0:
					MainFunction.OnSetBase();
					break;
				case 1:
					veinproperty.BuryAllvein();
					break;
				case 2:
					veinproperty.RemoveAllvein();
					break;
				case 3:
					MainFunction.SetMaxGasStation();
					break;
				case 4:
					MainFunction.RemoveAllBuild(0);
					break;
				case 5:
					MainFunction.RemoveAllBuild(1);
					break;
				}
			}
		}
		MainFunction.currentPlanetWaterType = GUILayout.TextField(MainFunction.currentPlanetWaterType, GUILayout.MinWidth(heightdis * 3));
		if (GUILayout.Button("设置当前星球海洋类型".getTranslate(), GUILayout.Height(heightdis)))
		{
			MainFunction.SetWaterType();
		}
		if (GUILayout.Button("恢复所有星球海洋类型".getTranslate(), GUILayout.Height(heightdis)))
		{
			MainFunction.RestoreWaterType();
		}
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private void DysonPannel()
	{
		GUILayout.Label("注意事项:戴森云和戴森壳不要出现一层轨道都没有的情况(用前存档)".getTranslate(), style);
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		if (GameMain.localStar != null && GameMain.data.dysonSpheres != null && GameMain.data.dysonSpheres[GameMain.localStar.index] != null)
		{
			DysonSphere dysonSphere = GameMain.data.dysonSpheres[GameMain.localStar.index];
			List<int> list = new List<int>();
			DysonSphereLayer[] layersIdBased = GameMain.data.dysonSpheres[GameMain.localStar.index].layersIdBased;
			foreach (DysonSphereLayer dysonSphereLayer in layersIdBased)
			{
				if (dysonSphereLayer != null)
				{
					list.Add(dysonSphereLayer.id);
				}
			}
			GUILayout.Label("点击删除下列戴森壳层级".getTranslate(), style);
			GUILayout.BeginHorizontal();
			for (int j = 1; j <= 5; j++)
			{
				bool flag = list.Contains(j);
				bool flag2 = GUILayout.Button(flag ? j.ToString() : "", iconbuttonoptions);
				if (!(flag2 && flag))
				{
					continue;
				}
				for (int k = 1; k < dysonSphere.rocketCursor; k++)
				{
					if (dysonSphere.rocketPool[k].id == k)
					{
						dysonSphere.RemoveDysonRocket(k);
					}
				}
				dysonSphere.RemoveLayer(j);
			}
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal();
			for (int l = 6; l <= 10; l++)
			{
				bool flag3 = list.Contains(l);
				bool flag4 = GUILayout.Button(flag3 ? l.ToString() : "", iconbuttonoptions);
				if (!(flag4 && flag3))
				{
					continue;
				}
				for (int m = 1; m < dysonSphere.rocketCursor; m++)
				{
					if (dysonSphere.rocketPool[m].id == m)
					{
						dysonSphere.RemoveDysonRocket(m);
					}
				}
				dysonSphere.RemoveLayer(l);
			}
			GUILayout.EndHorizontal();
			if (GUILayout.Button("初始化当前戴森球".getTranslate(), GUILayout.Height(heightdis)) && GameMain.localStar != null && GameMain.data.dysonSpheres[GameMain.localStar.index] != null)
			{
				int index = GameMain.localStar.index;
				GameMain.data.dysonSpheres[index] = new DysonSphere();
				GameMain.data.dysonSpheres[index].Init(GameMain.data, GameMain.localStar);
				GameMain.data.dysonSpheres[index].ResetNew();
			}
			if (GUILayout.Button("瞬间完成戴森球(用前存档)".getTranslate(), GUILayout.Height(heightdis)))
			{
				MainFunction.FinishDysonShell();
			}
		}
		Multifunction.quickEjector = GUILayout.Toggle(Multifunction.quickEjector, "极速轨道弹射器(慎用)".getTranslate());
		Multifunction.quicksilo = GUILayout.Toggle(Multifunction.quicksilo, "极速垂直发射井(慎用)".getTranslate());
		if (Multifunction.cancelsolarbullet.Value != GUILayout.Toggle(Multifunction.cancelsolarbullet.Value, "跳过太阳帆子弹阶段".getTranslate()))
		{
			Multifunction.cancelsolarbullet.Value = !Multifunction.cancelsolarbullet.Value;
		}
		Multifunction.quickabsorbsolar.Value = GUILayout.Toggle(Multifunction.quickabsorbsolar.Value, "跳过太阳帆吸收阶段".getTranslate());
		Multifunction.QuickabortSwarm.Value = GUILayout.Toggle(Multifunction.QuickabortSwarm.Value, "太阳帆帧吸收".getTranslate() + ":" + Multifunction.Solarsailsabsorbeveryframe.Value);
		if (Multifunction.QuickabortSwarm.Value)
		{
			GUILayout.BeginHorizontal();
			GUILayout.Space(10f);
			Multifunction.Solarsailsabsorbeveryframe.Value = (int)GUILayout.HorizontalSlider(Multifunction.Solarsailsabsorbeveryframe.Value, 1f, 100f);
			GUILayout.EndHorizontal();
		}
		if (Multifunction.alwaysemission.Value != GUILayout.Toggle(Multifunction.alwaysemission.Value, "全球打帆".getTranslate()))
		{
			Multifunction.alwaysemission.Value = !Multifunction.alwaysemission.Value;
			Multifunction.alwaysemissiontemp = Multifunction.alwaysemission.Value;
		}
		bool flag5 = GUILayout.Toggle(Multifunction.ChangeDysonradius.Value, "开放戴森壳半径上下限(用前存档)".getTranslate());
		GUILayout.Label("最小半径".getTranslate() + ":100", style);
		GUILayout.Label("最大半径".getTranslate() + ":" + NumberUtils.TGMKinttostring(Multifunction.MaxOrbitRadiusConfig.Value, ""), style);
		string valueStr = Regex.Replace(GUILayout.TextField(Multifunction.MaxOrbitRadiusConfig.Value.ToString() ?? "", 10), "[^0-9]", "");
		Multifunction.MaxOrbitRadiusConfig.Value = NumberUtils.IntParseLimit(valueStr, 100000, 10000000);
		if (flag5 != Multifunction.ChangeDysonradius.Value)
		{
			Multifunction.ChangeDysonradius.Value = flag5;
			DysonSphere dysonSphere2 = UIRoot.instance?.uiGame?.dysonEditor?.selection?.viewDysonSphere;
			DysonSphere[] array = GameMain.data?.dysonSpheres;
			foreach (DysonSphere dysonSphere3 in array)
			{
				if (dysonSphere3 == null)
				{
					continue;
				}
				if (flag5)
				{
					dysonSphere3.maxOrbitRadius = Multifunction.MaxOrbitRadiusConfig.Value;
					dysonSphere3.minOrbitRadius = 100f;
				}
				else
				{
					dysonSphere3.minOrbitRadius = dysonSphere3.starData.physicsRadius * 1.5f;
					if (dysonSphere3.minOrbitRadius < 4000f)
					{
						dysonSphere3.minOrbitRadius = 4000f;
					}
					dysonSphere3.maxOrbitRadius = dysonSphere3.defOrbitRadius * 2f;
					if (dysonSphere3.starData.type == EStarType.GiantStar)
					{
						dysonSphere3.minOrbitRadius *= 0.6f;
					}
					dysonSphere3.minOrbitRadius = Mathf.Ceil(dysonSphere3.minOrbitRadius / 100f) * 100f;
					dysonSphere3.maxOrbitRadius = Mathf.Round(dysonSphere3.maxOrbitRadius / 100f) * 100f;
				}
				if (dysonSphere2 == dysonSphere3)
				{
					UIRoot.instance.uiGame.dysonEditor.controlPanel.OnViewStarChange(dysonSphere3);
				}
			}
		}
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private void OtherPannel()
	{
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		GUILayout.Label("以下设置需要进入存档".getTranslate(), style);
		if (GameMain.mainPlayer != null)
		{
			Multifunction.CloseUIAbnormalityTip.Value = GUILayout.Toggle(Multifunction.CloseUIAbnormalityTip.Value, "关闭异常提示".getTranslate());
			Multifunction.IgnoreControlPanelLocalLimit.Value = GUILayout.Toggle(Multifunction.IgnoreControlPanelLocalLimit.Value, "取消总控面板本地限制".getTranslate());
			Multifunction.Maxproliferator.Value = GUILayout.Toggle(Multifunction.Maxproliferator.Value, "增产点数上限10".getTranslate());
			Multifunction.incAbility = (Multifunction.Maxproliferator.Value ? 10 : 4);
			Multifunction.pasteanyway = GUILayout.Toggle(Multifunction.pasteanyway, "蓝图强制粘贴".getTranslate());
			if (Multifunction.PasteBuildAnyWay != GUILayout.Toggle(Multifunction.PasteBuildAnyWay, "建筑铺设无需条件".getTranslate()))
			{
				Multifunction.PasteBuildAnyWay = !Multifunction.PasteBuildAnyWay;
				if (Multifunction.PasteBuildAnyWay && !PasteAnywayPatch.IsPatched)
				{
					PasteAnywayPatch.IsPatched = true;
					Multifunctionpatch.harmony.PatchAll(typeof(PasteAnywayPatch));
				}
			}
			if (Multifunction.closeallcollider != GUILayout.Toggle(Multifunction.closeallcollider, "关闭所有碰撞体".getTranslate()))
			{
				Multifunction.closeallcollider = !Multifunction.closeallcollider;
				ColliderPool.instance.gameObject.SetActive(!Multifunction.closeallcollider);
			}
			if (Multifunction.allhandcraft.Value != GUILayout.Toggle(Multifunction.allhandcraft.Value, "全部手搓".getTranslate()))
			{
				Multifunction.allhandcraft.Value = !Multifunction.allhandcraft.Value;
				Multifunction.refreshLDB = true;
			}
			if (Multifunction.quickproduce.Value != GUILayout.Toggle(Multifunction.quickproduce.Value, "快速生产".getTranslate()))
			{
				Multifunction.quickproduce.Value = !Multifunction.quickproduce.Value;
				Multifunction.refreshLDB = true;
			}
			GUILayout.Label("堆叠倍率".getTranslate() + ":", style);
			GUILayout.BeginHorizontal();
			stackmultipleStr = Regex.Replace(GUILayout.TextField(stackmultipleStr, 10, GUILayout.MinWidth(heightdis * 3)), "[^0-9]", "");
			int multiple = NumberUtils.IntParseLimit(stackmultipleStr, 1, 5000000);
			stackmultipleStr = multiple.ToString();
			if (GUILayout.Button("设置".getTranslate()))
			{
				MainFunction.SetmultipleItemStatck(multiple);
			}
			GUILayout.EndHorizontal();
			if (GUILayout.Button("取消所有勾选".getTranslate()))
			{
				MainFunction.CancelAllToggle();
			}
		}
		GUILayout.EndVertical();
		GUILayout.Space(heightdis);
		GUILayout.BeginVertical();
		GUILayout.Label("窗口颜色及透明度".getTranslate() + " RGBA", style);
		GUILayout.BeginHorizontal();
		float num = GUILayout.HorizontalSlider(mainWindowTextureColor.r, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
		GUILayout.Label("R:" + $"{num:N2}", style);
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal();
		float num2 = GUILayout.HorizontalSlider(mainWindowTextureColor.g, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
		GUILayout.Label("G:" + $"{num2:N2}", style);
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal();
		float num3 = GUILayout.HorizontalSlider(mainWindowTextureColor.b, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
		GUILayout.Label("B:" + $"{num3:N2}", style);
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal();
		float num4 = GUILayout.HorizontalSlider(mainWindowTextureColor.a, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
		GUILayout.Label("A:" + $"{num4:N2}", style);
		GUILayout.EndHorizontal();
		if (num != mainWindowTextureColor.r || num2 != mainWindowTextureColor.g || num3 != mainWindowTextureColor.b || num4 != mainWindowTextureColor.a)
		{
			mainWindowTextureColor = new Color(num, num2, num3, num4);
			for (int i = 0; i < MainWindowTexture.width; i++)
			{
				for (int j = 0; j < MainWindowTexture.height; j++)
				{
					MainWindowTexture.SetPixel(i, j, mainWindowTextureColor);
				}
			}
			MainWindowTexture.Apply();
		}
		GUILayout.Label("窗口字体颜色".getTranslate() + " RGB", style);
		GUILayout.BeginHorizontal();
		float num5 = GUILayout.HorizontalSlider(TextColor.r, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
		GUILayout.Label("R:" + $"{num5:N2}", style);
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal();
		float num6 = GUILayout.HorizontalSlider(TextColor.g, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
		GUILayout.Label("G:" + $"{num6:N2}", style);
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal();
		float num7 = GUILayout.HorizontalSlider(TextColor.b, 0f, 1f, GUILayout.MinWidth(4 * heightdis));
		GUILayout.Label("B:" + $"{num7:N2}", style);
		GUILayout.EndHorizontal();
		if (num5 != TextColor.r || num6 != TextColor.g || num7 != TextColor.b)
		{
			TextColor = new Color(num5, num6, num7);
		}
		Multifunction.ChangeQuickKey = GUILayout.Toggle(Multifunction.ChangeQuickKey, (!Multifunction.ChangeQuickKey) ? "改变窗口快捷键".getTranslate() : "点击确认".getTranslate());
		GUILayout.Label("快捷键".getTranslate() + ":" + Multifunction.tempShowWindow.ToString());
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private void LogisticsPannel()
	{
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		GUILayout.Label("如果启动机甲物流，物流背包没有解锁会自动解锁一列。", style);
		GUILayout.Label("物流背包里的设置可以直接从全星系的存储设备中获取或回收", style);
		GUILayout.Label("设置机甲物流专用星后，只有名字是\"机甲物流\"的星球才会进行物流操作", style);
		GUILayoutOption[] options = new GUILayoutOption[1] { GUILayout.Height(heightdis) };
		if (Multifunction.Mechalogistics_bool.Value != GUILayout.Toggle(Multifunction.Mechalogistics_bool.Value, "强化机甲物流".getTranslate(), options))
		{
			Multifunction.Mechalogistics_bool.Value = !Multifunction.Mechalogistics_bool.Value;
			if (Multifunction.Mechalogistics_bool.Value && !Multifunction.player.deliveryPackage.unlocked)
			{
				Multifunction.player.deliveryPackage.unlocked = true;
				Multifunction.player.deliveryPackage.colCount = 1;
				Multifunction.player.deliveryPackage.NotifySizeChange();
			}
		}
		GUILayout.BeginHorizontal();
		GUILayout.Label("所有物品(优先度）");
		Multifunction.MechalogPlayerStorageFirst_bool.Value = GUILayout.Toggle(Multifunction.MechalogPlayerStorageFirst_bool.Value, "玩家背包".getTranslate(), options);
		if (GUILayout.Toggle(!Multifunction.MechalogPlayerStorageFirst_bool.Value, "物流背包".getTranslate(), options) == Multifunction.MechalogPlayerStorageFirst_bool.Value)
		{
			Multifunction.MechalogPlayerStorageFirst_bool.Value = false;
		}
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal();
		GUILayout.Label("建筑物品(优先度）");
		Multifunction.MechalogBuildGotoPlayerStorageFirst_bool.Value = GUILayout.Toggle(Multifunction.MechalogBuildGotoPlayerStorageFirst_bool.Value, "玩家背包".getTranslate(), options);
		if (GUILayout.Toggle(!Multifunction.MechalogBuildGotoPlayerStorageFirst_bool.Value, "物流背包".getTranslate(), options) == Multifunction.MechalogBuildGotoPlayerStorageFirst_bool.Value)
		{
			Multifunction.MechalogBuildGotoPlayerStorageFirst_bool.Value = false;
		}
		if (Multifunction.MechalogPlayerStorageFirst_bool.Value)
		{
			Multifunction.MechalogBuildGotoPlayerStorageFirst_bool.Value = true;
		}
		GUILayout.EndHorizontal();
		Multifunction.MechalogisticsPlanet_bool.Value = GUILayout.Toggle(Multifunction.MechalogisticsPlanet_bool.Value, "机甲物流专用星".getTranslate(), options);
		Multifunction.MechalogStoragerecycle_bool.Value = GUILayout.Toggle(Multifunction.MechalogStoragerecycle_bool.Value, "回收使用储物仓".getTranslate(), options);
		Multifunction.MechalogStorageprovide_bool.Value = GUILayout.Toggle(Multifunction.MechalogStorageprovide_bool.Value, "需求使用储物仓".getTranslate(), options);
		Multifunction.MechalogStationrecycle_bool.Value = GUILayout.Toggle(Multifunction.MechalogStationrecycle_bool.Value, "回收使用物流站".getTranslate(), options);
		Multifunction.MechalogStationprovide_bool.Value = GUILayout.Toggle(Multifunction.MechalogStationprovide_bool.Value, "需求使用物流站".getTranslate(), options);
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private bool MoveWindow()
	{
		float num = MainWindow_x;
		float num2 = MainWindow_y;
		if (leftscaling || rightscaling || bottomscaling)
		{
			return false;
		}
		Vector2 vector = Input.mousePosition;
		float x = vector.x;
		float num3 = (float)Screen.height - vector.y;
		bool flag = x > MainWindow_x && x < MainWindow_x + MainWindowWidth && num3 > MainWindow_y && num3 < MainWindow_y + 20f;
		if (Input.GetMouseButtonDown(0) && flag)
		{
			DragStartWindowX = MainWindow_x;
			DragStartWindowY = MainWindow_y;
			DragStartMouseX = x;
			DragStartMouseY = num3;
			isDragging = true;
		}
		if (isDragging && Input.GetMouseButton(0))
		{
			MainWindow_x = DragStartWindowX + x - DragStartMouseX;
			MainWindow_y = DragStartWindowY + num3 - DragStartMouseY;
		}
		if (Input.GetMouseButtonUp(0))
		{
			isDragging = false;
		}
		MainWindow_y = Math.Max(10f, Math.Min((float)Screen.height - 10f, MainWindow_y));
		MainWindow_x = Math.Max(10f, Math.Min((float)Screen.width - 10f, MainWindow_x));
		return MainWindow_x != num || MainWindow_y != num2;
	}

	private bool Scaling_window()
	{
		float num = MainWindowWidth;
		float num2 = MainWindowHeight;
		Vector2 vector = Input.mousePosition;
		float num3 = MainWindowWidth;
		float num4 = MainWindowHeight;
		if (Input.GetMouseButton(0))
		{
			if ((vector.x + 10f > MainWindow_x && vector.x - 10f < MainWindow_x && (float)Screen.height - vector.y >= MainWindow_y && (float)Screen.height - vector.y <= MainWindow_y + num4) || leftscaling)
			{
				num3 -= vector.x - MainWindow_x;
				MainWindow_x = vector.x;
				leftscaling = true;
				rightscaling = false;
			}
			if ((vector.x + 10f > MainWindow_x + num3 && vector.x - 10f < MainWindow_x + num3 && (float)Screen.height - vector.y >= MainWindow_y && (float)Screen.height - vector.y <= MainWindow_y + num4) || rightscaling)
			{
				num3 += vector.x - MainWindow_x - num3;
				rightscaling = true;
				leftscaling = false;
			}
			if (((float)Screen.height - vector.y + 10f > num4 + MainWindow_y && (float)Screen.height - vector.y - 10f < num4 + MainWindow_y && vector.x >= MainWindow_x && vector.x <= MainWindow_x + num3) || bottomscaling)
			{
				num4 += (float)Screen.height - vector.y - (MainWindow_y + num4);
				bottomscaling = true;
			}
		}
		if (Input.GetMouseButtonUp(0))
		{
			rightscaling = false;
			leftscaling = false;
			bottomscaling = false;
		}
		MainWindowWidth = Math.Max(100f, num3);
		MainWindowHeight = Math.Max(100f, num4);
		return MainWindowWidth != num || MainWindowHeight != num2;
	}
}
