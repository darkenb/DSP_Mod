using System.Reflection;
using HarmonyLib;
using Multifunction_mod.Patchs;

namespace Multifunction_mod;

public class Multifunctionpatch
{
	public static Harmony harmony;

	public static int ability = 4;

	public static void Patchallmethod()
	{
		harmony = new Harmony("cn.blacksnipe.dsp.Multfuntion_mod");
		MethodInfo[] methods = typeof(StorageComponent).GetMethods();
		MethodInfo[] array = methods;
		foreach (MethodInfo methodInfo in array)
		{
			if (methodInfo.Name == "TakeTailItems" && methodInfo.ReturnType == typeof(void))
			{
				MethodInfo method = typeof(Multifunctionpatch).GetMethod("TakeTailItemsPatch");
				harmony.Patch(methodInfo, new HarmonyMethod(method));
				break;
			}
		}
		harmony.PatchAll(typeof(Multifunction_modGameLogic));
		harmony.PatchAll(typeof(DysonPatch));
		harmony.PatchAll(typeof(PlayerPatch));
		harmony.PatchAll(typeof(PowerSystemPatch));
		harmony.PatchAll(typeof(PlanetFactoryPatch));
		harmony.PatchAll(typeof(StorageComponentPatch));
		harmony.PatchAll(typeof(StationComponentPatch));
		harmony.PatchAll(typeof(FactorySystemPatch));
		harmony.PatchAll(typeof(CargoTrafficPatch));
		harmony.PatchAll(typeof(SomePatch));
		harmony.PatchAll(typeof(UIPatch));
		harmony.PatchAll(typeof(PlanetTransportPatch));
		harmony.PatchAll(typeof(TankComponentPatch));
		harmony.PatchAll(typeof(SpraycoaterComponentPatch));
		harmony.PatchAll(typeof(CombatPatch));
		harmony.PatchAll(typeof(BuildTool_ClickPatch));
	}

	public static bool TakeTailItemsPatch(StorageComponent __instance, ref int itemId)
	{
		if (Multifunction.ArchitectMode.Value)
		{
			if (itemId <= 0 || itemId >= 6007 || __instance == null || __instance.id != GameMain.mainPlayer.package.id)
			{
				return true;
			}
			if (LDB.items.Select(itemId).CanBuild)
			{
				return false;
			}
		}
		return true;
	}
}
