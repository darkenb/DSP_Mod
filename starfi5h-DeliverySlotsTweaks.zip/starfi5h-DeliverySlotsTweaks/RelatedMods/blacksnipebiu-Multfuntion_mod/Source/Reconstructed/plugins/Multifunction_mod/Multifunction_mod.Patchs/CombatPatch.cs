using System;
using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class CombatPatch
{
	[HarmonyPrefix]
	[HarmonyPatch(typeof(Mecha), "TakeDamage")]
	public static bool MechaTakeDamage(Mecha __instance)
	{
		if (Multifunction.LockPlayerHp.Value)
		{
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(Mecha), "UpdateCombatStats")]
	public static void MechaTakeUpdateCombatStats(Mecha __instance)
	{
		if (Multifunction.LockPlayerHp.Value)
		{
			__instance.energyShieldEnergy = __instance.energyShieldCapacity;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(ConstructionSystem), "GameTick")]
	public static void PlanetFactoryGameTick(ConstructionSystem __instance)
	{
		if (!Multifunction.LockBuildHp.Value && !Multifunction.LockEnemyHp.Value)
		{
			return;
		}
		CombatStat[] buffer = __instance.factory.skillSystem.combatStats.buffer;
		CombatStat[] array = buffer;
		for (int i = 0; i < array.Length; i++)
		{
			CombatStat combatStat = array[i];
			if (Multifunction.LockBuildHp.Value && combatStat.objectType == 0)
			{
				buffer[combatStat.id].hp = combatStat.hpMax;
			}
			if (Multifunction.LockEnemyHp.Value && combatStat.objectType == 4)
			{
				buffer[combatStat.id].hp = combatStat.hpMax;
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(Mecha), "TickLaserFireCondition")]
	public static void MechaTickLaserFireCondition(Mecha __instance)
	{
		if (Multifunction.PlayerQuickAttack.Value)
		{
			__instance.laserFire = 0;
			__instance.laserEnergy = __instance.laserEnergyCapacity;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(Mecha), "TestLaserTurretEnergy")]
	public static bool MechaTestLaserTurretEnergy(ref bool __result)
	{
		if (Multifunction.PlayerQuickAttack.Value)
		{
			__result = true;
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(SkillSystem), "GameTick")]
	public static void SkillSystemGameTick(SkillSystem __instance)
	{
		if (Multifunction.killEnemys.Count <= 0)
		{
			return;
		}
		EnemyData enemyData = Multifunction.killEnemys.Dequeue();
		if (enemyData.id > 0)
		{
			if (enemyData.combatStatId > 0 && __instance.combatStats.buffer[enemyData.combatStatId].id == enemyData.combatStatId)
			{
				__instance.combatStats.buffer[enemyData.combatStatId].hp = 0;
			}
			else if (enemyData.originAstroId > 1000000)
			{
				ref EnemyData reference = ref __instance.sector.enemyPool[enemyData.id];
				__instance.sector.KillEnemyFinal(reference.id, ref CombatStat.empty);
			}
			else if (enemyData.originAstroId > 100 && enemyData.originAstroId <= 204899 && enemyData.originAstroId % 100 > 0)
			{
				PlanetFactory obj = __instance.astroFactories[enemyData.originAstroId];
				obj.KillEnemyFinally(obj.enemyPool[enemyData.id].id, ref CombatStat.empty);
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(EnemyDFHiveSystem), "GameTickLogic")]
	public static void EnemyDFHiveSystemPreGameTickLogic(EnemyDFHiveSystem __instance)
	{
		if (Multifunction.SpaceAlwaysClearThreat.Value)
		{
			__instance.evolve.threat = 0;
			__instance.evolve.threatshr = 0;
		}
		if (Multifunction.SpaceAlwaysMaxThreat.Value && __instance.evolve.threat < __instance.evolve.maxThreat && __instance.evolve.waveTicks == 0 && GameMain.localStar != null && __instance.starData.index == GameMain.localStar.index)
		{
			__instance.evolve.threat = __instance.evolve.maxThreat * 2 + 1;
			__instance.evolve.threatshr = __instance.evolve.maxThreat * 2 + 1;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(EnemyDFHiveSystem), "GameTickLogic")]
	public static void EnemyDFHiveSystemGameTickLogic(EnemyDFHiveSystem __instance)
	{
		if (Multifunction.SpaceAlwaysClearThreat.Value)
		{
			__instance.evolve.threat = 0;
			__instance.evolve.threatshr = 0;
		}
		if (Multifunction.SpaceAlwaysMaxThreat.Value && __instance.evolve.threat < __instance.evolve.maxThreat && __instance.evolve.waveTicks == 0 && GameMain.localStar != null && __instance.starData.index == GameMain.localStar.index)
		{
			__instance.evolve.threat = __instance.evolve.maxThreat * 2 + 1;
			__instance.evolve.threatshr = __instance.evolve.maxThreat * 2 + 1;
		}
		if (Multifunction.PlayerFakeDeath.Value && __instance.isLocal)
		{
			__instance.local_player_exist_alive = false;
			__instance.local_player_in_range = false;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DFGBaseComponent), "UpdateFactoryThreat")]
	public static void DFGBaseComponentPreLogicTick(DFGBaseComponent __instance, ref float power_threat_factor, ref float player_threat)
	{
		if (Multifunction.LocalAlwaysClearThreat.Value)
		{
			power_threat_factor = 0f;
			player_threat = 0f;
			__instance.evolve.threat = 0;
			__instance.evolve.threatshr = 0;
		}
		if (Multifunction.LocalAlwaysMaxThreat.Value && __instance.evolve.threat < __instance.evolve.maxThreat && __instance.evolve.waveTicks == 0 && GameMain.localPlanet != null && __instance.groundSystem.factory.planet.index == GameMain.localPlanet.index)
		{
			__instance.evolve.threat = __instance.evolve.maxThreat * 2 + 1;
			__instance.evolve.threatshr = __instance.evolve.maxThreat * 2 + 1;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(DFGBaseComponent), "UpdateFactoryThreat")]
	public static void DFGBaseComponentLogicTick(DFGBaseComponent __instance, ref float power_threat_factor, ref float player_threat)
	{
		if (Multifunction.LocalAlwaysClearThreat.Value)
		{
			power_threat_factor = 0f;
			player_threat = 0f;
			__instance.evolve.threat = 0;
			__instance.evolve.threatshr = 0;
		}
		if (Multifunction.LocalAlwaysMaxThreat.Value && __instance.evolve.threat < __instance.evolve.maxThreat && __instance.evolve.waveTicks == 0 && GameMain.localPlanet != null && __instance.groundSystem.factory.planet.index == GameMain.localPlanet.index)
		{
			__instance.evolve.threat = __instance.evolve.maxThreat * 2 + 1;
			__instance.evolve.threatshr = __instance.evolve.maxThreat * 2 + 1;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(EnemyBuilderComponent), "LogicTick")]
	public static void EnemyBuilderComponentBuildLogic_Ground(EnemyBuilderComponent __instance)
	{
		if (Multifunction.DarkFogBuilderQuickBuild.Value)
		{
			__instance.energy = __instance.maxEnergy;
			__instance.matter = __instance.maxMatter;
			__instance.sp = __instance.spMax;
			__instance.buildCDTime = 0;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(TurretComponent), "InternalUpdate")]
	public static void TurretComponentInternalUpdate(ref TurretComponent __instance)
	{
		if (Multifunction.TurrentKeepSuperNoval.Value)
		{
			__instance.supernovaTick = 901;
			__instance.supernovaStrength = 30f;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(HatredList), "HateTarget", new Type[]
	{
		typeof(ETargetType),
		typeof(int),
		typeof(int),
		typeof(int),
		typeof(EHatredOperation)
	})]
	public static bool HatredListHateTarget(ETargetType type)
	{
		if (Multifunction.PlayerFakeDeath.Value && type == ETargetType.Player)
		{
			return false;
		}
		return true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(EnemyDFGroundSystem), "GameTickLogic_Prepare")]
	public static void EnemyDFGroundSystemGameTickLogic(EnemyDFGroundSystem __instance)
	{
		if (Multifunction.PlayerFakeDeath.Value && __instance.isLocalLoaded)
		{
			__instance.local_player_exist_alive = false;
		}
	}
}
