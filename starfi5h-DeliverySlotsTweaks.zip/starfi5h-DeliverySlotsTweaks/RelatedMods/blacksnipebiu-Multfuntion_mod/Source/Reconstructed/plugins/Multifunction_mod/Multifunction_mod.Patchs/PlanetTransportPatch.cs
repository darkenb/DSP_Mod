using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class PlanetTransportPatch
{
	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetTransport), "NewStationComponent")]
	public static void PlanetTransportNewStationComponent(ref StationComponent __result, PlanetTransport __instance, int _entityId)
	{
		if (__result.isCollector)
		{
			Multifunction.CollectorStation.Add(__result.gid);
		}
		else if (!__result.isVeinCollector)
		{
			if (!string.IsNullOrEmpty(Multifunction.AutoChangeStationName.Value))
			{
				__instance.factory.WriteExtraInfoOnEntity(_entityId, Multifunction.AutoChangeStationName.Value.getTranslate());
			}
			if (Multifunction.Buildingnoconsume.Value)
			{
				GameMain.localPlanet.factory.powerSystem.consumerPool[__result.pcId].idleEnergyPerTick = 1000L;
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlanetTransport), "RemoveStationComponent")]
	public static void PlanetTransportRemoveStationComponent(PlanetTransport __instance, int id)
	{
		if (__instance.stationPool[id] != null && __instance.stationPool[id].id != 0 && __instance.stationPool[id].isCollector)
		{
			int gid = __instance.stationPool[id].gid;
			if (Multifunction.CollectorStation.Contains(gid))
			{
				Multifunction.CollectorStation.Remove(gid);
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlanetTransport), "SetStationStorage")]
	public static bool UIStationWindow_SetStationStorage(PlanetTransport __instance, int stationId, int storageIdx, int itemId, int itemCountMax, ELogisticStorage localLogic, ELogisticStorage remoteLogic, Player player)
	{
		if (Multifunction.StationStoExtra.Value <= 0)
		{
			return true;
		}
		if (itemId != 0 && LDB.items.Select(itemId) == null)
		{
			itemId = 0;
		}
		StationComponent stationComponent = __instance.GetStationComponent(stationId);
		bool flag = false;
		bool flag2 = false;
		if (stationComponent != null)
		{
			if (!stationComponent.isStellar)
			{
				remoteLogic = ELogisticStorage.None;
			}
			if (itemId <= 0)
			{
				itemId = 0;
				itemCountMax = 0;
				localLogic = ELogisticStorage.None;
				remoteLogic = ELogisticStorage.None;
			}
			int modelIndex = __instance.factory.entityPool[stationComponent.entityId].modelIndex;
			ModelProto modelProto = LDB.models.Select(modelIndex);
			int num = 0;
			if (modelProto != null)
			{
				num = modelProto.prefabDesc.stationMaxItemCount;
			}
			int num2 = (stationComponent.isStellar ? 10000 : 5000);
			int num3 = num + (Multifunction.StationStoExtra.Value + 1) * num2;
			if (itemCountMax > num3)
			{
				itemCountMax = num3;
			}
			if (storageIdx >= 0 && storageIdx < stationComponent.storage.Length)
			{
				StationStore stationStore = stationComponent.storage[storageIdx];
				if (stationStore.localLogic != localLogic)
				{
					flag = true;
				}
				if (stationStore.remoteLogic != remoteLogic)
				{
					flag2 = true;
				}
				if (stationStore.itemId == itemId)
				{
					stationComponent.storage[storageIdx].max = itemCountMax;
					stationComponent.storage[storageIdx].localLogic = localLogic;
					stationComponent.storage[storageIdx].remoteLogic = remoteLogic;
				}
				else
				{
					if (stationStore.localLogic != ELogisticStorage.None || localLogic != ELogisticStorage.None)
					{
						flag = true;
					}
					if (stationStore.remoteLogic != ELogisticStorage.None || remoteLogic != ELogisticStorage.None)
					{
						flag2 = true;
					}
					if (stationStore.count > 0 && stationStore.itemId > 0 && player != null)
					{
						int num4 = player.TryAddItemToPackage(stationStore.itemId, stationStore.count, stationStore.inc, throwTrash: true);
						UIItemup.Up(stationStore.itemId, num4);
						if (num4 < stationStore.count)
						{
							UIRealtimeTip.Popup("无法收回仓储物品".Translate());
						}
					}
					stationComponent.storage[storageIdx].itemId = itemId;
					stationComponent.storage[storageIdx].count = 0;
					stationComponent.storage[storageIdx].inc = 0;
					stationComponent.storage[storageIdx].localOrder = 0;
					stationComponent.storage[storageIdx].remoteOrder = 0;
					stationComponent.storage[storageIdx].max = itemCountMax;
					stationComponent.storage[storageIdx].localLogic = localLogic;
					stationComponent.storage[storageIdx].remoteLogic = remoteLogic;
				}
				if (itemId == 0)
				{
					stationComponent.storage[storageIdx] = default(StationStore);
					for (int i = 0; i < stationComponent.slots.Length; i++)
					{
						if (stationComponent.slots[i].dir == IODir.Output && stationComponent.slots[i].storageIdx - 1 == storageIdx)
						{
							stationComponent.slots[i].counter = 0;
							stationComponent.slots[i].storageIdx = 0;
							stationComponent.slots[i].dir = IODir.Output;
						}
					}
				}
			}
			if (!stationComponent.isStellar)
			{
				flag2 = false;
			}
		}
		if (flag)
		{
			__instance.RefreshStationTraffic(stationId);
		}
		if (flag2)
		{
			__instance.gameData.galacticTransport.RefreshTraffic(stationComponent.gid);
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlanetTransport), "GameTick")]
	public static void PlanetTransportGameTick(long time, PlanetTransport __instance)
	{
		int num = (int)(time % 20);
		if (num < 0)
		{
			num += 20;
		}
		int num2 = (int)(time % 60);
		if (num2 < 0)
		{
			num2 += 60;
		}
		bool flag = num == 0;
		bool flag2 = num2 == 0;
		FactoryProductionStat obj = GameMain.statistics.production.factoryStatPool[__instance.factory.index];
		int[] productRegister = obj.productRegister;
		int[] consumeRegister = obj.consumeRegister;
		for (int num3 = __instance.stationPool.Length - 1; num3 > 0; num3--)
		{
			StationComponent stationComponent = __instance.stationPool[num3];
			if (stationComponent != null && stationComponent.id == num3)
			{
				if (flag)
				{
					if (Multifunction.Stationfullenergy.Value)
					{
						stationComponent.energy = stationComponent.energyMax;
					}
					if (Multifunction.StationMaxproliferator.Value)
					{
						for (int i = 0; i < stationComponent.storage.Length; i++)
						{
							if (stationComponent.storage[i].itemId > 0)
							{
								stationComponent.storage[i].inc = stationComponent.storage[i].count * Multifunction.incAbility;
							}
						}
					}
					if (Multifunction.StationfullCount)
					{
						StationComponentPatch.StationFullItemCount(stationComponent);
					}
				}
				if (!stationComponent.isCollector && !stationComponent.isVeinCollector)
				{
					if (Multifunction.StationSpray.Value)
					{
						StationComponentPatch.StationSprayInc(stationComponent, consumeRegister);
					}
					if (Multifunction.StationPowerGen.Value)
					{
						StationComponentPatch.StationPowerGeneration(stationComponent, consumeRegister);
					}
					if (flag && Multifunction.Station_infiniteWarp_bool.Value && stationComponent.isStellar)
					{
						stationComponent.warperCount = 50;
					}
					string text = __instance.factory.ReadExtraInfoOnEntity(stationComponent.entityId);
					if (!string.IsNullOrEmpty(text))
					{
						switch (text)
						{
						case "星球无限供货机":
							if (!(!Multifunction.StationfullCount_bool.Value && flag2) && !Multifunction.StationfullCount)
							{
								StationComponentPatch.StationFullItemCount(stationComponent);
							}
							break;
						case "Station_trash":
						case "垃圾站":
							if (!(!Multifunction.StationTrash.Value && flag2))
							{
								StationComponentPatch.StationTrashMethod(stationComponent, consumeRegister);
							}
							break;
						case "喷涂加工厂":
							if (Multifunction.StationSprayer.Value && !Multifunction.StationSpray.Value)
							{
								StationComponentPatch.StationSprayInc(stationComponent, consumeRegister);
							}
							break;
						case "星球熔炉矿机":
							if (Multifunction.StationMinerSmelter.Value)
							{
								if (flag2)
								{
									StationComponentPatch.StationMine(stationComponent, __instance.planet, productRegister);
								}
								StationComponentPatch.StationFurnaceMiner(stationComponent, time, consumeRegister, productRegister);
							}
							break;
						case "Station_miner":
						case "星球矿机":
							if (Multifunction.StationMiner.Value && flag2)
							{
								StationComponentPatch.StationMine(stationComponent, __instance.planet, productRegister);
							}
							break;
						}
					}
				}
			}
		}
	}
}
