using HarmonyLib;
using UnityEngine;

namespace Multifunction_mod.Patchs;

public class PasteAnywayPatch
{
	public static bool IsPatched { get; internal set; }

	[HarmonyPrefix]
	[HarmonyPatch(typeof(BuildTool_Inserter), "CheckBuildConditions")]
	public static bool BuildTool_InserterCheckBuildConditionsPatch(ref bool __result)
	{
		if (Multifunction.PasteBuildAnyWay)
		{
			__result = true;
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(BuildTool_Addon), "CheckBuildConditions")]
	public static bool BuildTool_AddonCheckBuildConditionsPatch(ref bool __result)
	{
		if (Multifunction.PasteBuildAnyWay)
		{
			__result = true;
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(BuildTool_Path), "CheckBuildConditions")]
	public static bool BuildTool_PathCheckBuildConditionsPatch(ref bool __result, BuildTool_Path __instance)
	{
		if (Multifunction.PasteBuildAnyWay)
		{
			int count = __instance.buildPreviews.Count;
			float num = __instance.altitude;
			float num2 = __instance.altitude;
			float tilt = __instance.tilt;
			float tilt2 = __instance.tilt;
			if (count > 0)
			{
				num = (__instance.buildPreviews[0].lpos.magnitude - __instance.planet.realRadius - 0.2f) / 1.3333333f;
				num2 = (__instance.buildPreviews[count - 1].lpos.magnitude - __instance.planet.realRadius - 0.2f) / 1.3333333f;
				num = Mathf.Round(num * 100f) / 100f;
				num2 = Mathf.Round(num2 * 100f) / 100f;
				if ((double)num < 0.041)
				{
					num = 0f;
				}
				if ((double)num2 < 0.041)
				{
					num2 = 0f;
				}
				tilt = __instance.buildPreviews[0].tilt;
				tilt2 = __instance.buildPreviews[count - 1].tilt;
			}
			if (num > 0f || num2 > 0f || tilt != 0f || tilt2 != 0f)
			{
				__instance.actionBuild.model.cursorText += "<size=12>";
				if (num > 0f || num2 > 0f)
				{
					string arg = ((num != num2) ? $"{num:0.##}\u2006～\u2006{num2:0.##}" : $"{num:0.##}");
					__instance.actionBuild.model.cursorText += string.Format("传送带高度提示".Translate(), arg);
				}
				if (tilt != 0f || tilt2 != 0f)
				{
					string arg2 = ((tilt != tilt2) ? $"{0f - tilt:+0.#;-0.#;0}\u2006～\u2006{0f - tilt2:+0.#;-0.#;0}" : $"{0f - tilt:+0.#;-0.#;0}°");
					__instance.actionBuild.model.cursorText += string.Format("传送带倾斜提示".Translate(), arg2);
				}
				__instance.actionBuild.model.cursorText += "</size>";
			}
			__result = true;
			return false;
		}
		return true;
	}
}
