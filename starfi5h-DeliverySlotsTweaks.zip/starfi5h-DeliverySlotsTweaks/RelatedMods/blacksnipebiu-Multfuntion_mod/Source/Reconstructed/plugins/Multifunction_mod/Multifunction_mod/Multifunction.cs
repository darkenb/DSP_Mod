using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using Multifunction_mod.Models;
using Multifunction_mod.Patchs;
using Multifunction_mod.Utils;
using UnityEngine;

namespace Multifunction_mod;

[BepInPlugin("cn.blacksnipe.dsp.Multfuntion_mod", "Multfuntion_mod", "4.0.7")]
public class Multifunction : BaseUnityPlugin
{
	public const string GUID = "cn.blacksnipe.dsp.Multfuntion_mod";

	public const string NAME = "Multfuntion_mod";

	public const string VERSION = "4.0.7";

	public static bool IsEnglish;

	public int ReformType;

	public int ReformColor;

	public float OnesecondTime;

	public float HalfsecondTime;

	public string currentPlanetWaterType = "";

	private SeedPlanetWater originWaterTypes;

	private SeedPlanetWater currentWaterTypes;

	public Dictionary<long, SeedPlanetWater> seedPlanetWaterTypes;

	public static GUIDraw guidraw;

	public static PropertyData propertyData;

	public static VeinControlProperty veinproperty;

	public static bool OneSecondTimeElapse;

	public static bool HalfSecondTimeElapse;

	public RecipeProto[] originRecipeProtos;

	public static Player player;

	public static Queue<EnemyData> killEnemys = new Queue<EnemyData>();

	public static KeyboardShortcut tempShowWindow;

	private static int driftBuildingLevel;

	public static float DriftBuildingHeight = 1f;

	public static int incAbility = 4;

	private static bool LDBInitSave;

	public static bool refreshLDB;

	public static bool GameRunning;

	public static bool refreshPlayerData;

	public static bool changequapowerpertick;

	public static bool StationfullCount;

	public static bool ChangeQuickKey;

	public static bool ChangingQuickKey;

	public static bool blueprintPasteToolActive;

	public static bool DriftBuildings;

	public static bool Property9999999;

	public static bool alwaysemissiontemp;

	public static bool FinallyInit;

	public static bool restorewater;

	public static bool entityitemnoneed;

	public static bool quickEjector;

	public static bool quicksilo;

	public static bool ClickKillEnemyBaseChain;

	public static int temp;

	public static bool farconnectdistance;

	public static bool pasteanyway;

	public static bool PasteBuildAnyWay;

	public static bool closeallcollider;

	public static bool unlockpointtech;

	public static bool ClickGenerateDFRelay;

	public static bool ClickGenerateDFRelayLockClick;

	public string watertype = "";

	public static Dictionary<int, List<RecipeProto>> smeltRecipes = new Dictionary<int, List<RecipeProto>>();

	public static Dictionary<int, Dictionary<int, int>> Beltsignal = new Dictionary<int, Dictionary<int, int>>();

	public static Dictionary<int, Dictionary<int, int>> Beltsignalnumberoutput = new Dictionary<int, Dictionary<int, int>>();

	public static ConfigEntry<KeyboardShortcut> QuickKey;

	public static ConfigEntry<int> veinlines;

	public static ConfigEntry<int> scale;

	public static ConfigEntry<int> StackMultiple;

	public static ConfigEntry<int> StationStoExtra;

	public static ConfigEntry<int> Stationminenumber;

	public static ConfigEntry<int> Buildmaxlen;

	public static ConfigEntry<int> Quantumenergy;

	public static ConfigEntry<int> CuttingVeinNumbers;

	public static ConfigEntry<int> MaxOrbitRadiusConfig;

	public static ConfigEntry<int> Solarsailsabsorbeveryframe;

	public static ConfigEntry<int> StationMinerSmelterNum;

	public static ConfigEntry<int> ClickKillEnemyMode;

	public static ConfigEntry<Color> Textcolor;

	public static ConfigEntry<Color> mainWindowTextureColor_config;

	public static ConfigEntry<float> MainWindow_width;

	public static ConfigEntry<float> MainWindow_height;

	public static ConfigEntry<float> MainWindow_x_config;

	public static ConfigEntry<float> MainWindow_y_config;

	public static ConfigEntry<float> starquamaxpowerpertick;

	public static ConfigEntry<float> planetquamaxpowerpertick;

	public static ConfigEntry<bool> InfiniteSand;

	public static ConfigEntry<bool> isInstantItem;

	public static ConfigEntry<bool> WindturbinesUnlimitedEnergy;

	public static ConfigEntry<bool> Windturbinescovertheglobe;

	public static ConfigEntry<bool> NotTidyVein;

	public static ConfigEntry<bool> InspectDisNoLimit;

	public static ConfigEntry<bool> StationMaxproliferator;

	public static ConfigEntry<bool> Mechalogistics_bool;

	public static ConfigEntry<bool> MechalogBuildGotoPlayerStorageFirst_bool;

	public static ConfigEntry<bool> MechalogPlayerStorageFirst_bool;

	public static ConfigEntry<bool> MechalogStoragerecycle_bool;

	public static ConfigEntry<bool> MechalogStorageprovide_bool;

	public static ConfigEntry<bool> MechalogStationrecycle_bool;

	public static ConfigEntry<bool> MechalogStationprovide_bool;

	public static ConfigEntry<bool> Infinitestoragetank;

	public static ConfigEntry<bool> QuickHandcraft;

	public static ConfigEntry<bool> QuickPlayerMine;

	public static ConfigEntry<bool> QuickResearch;

	public static ConfigEntry<bool> TankMaxproliferator;

	public static ConfigEntry<bool> Quantumtransport_bool;

	public static ConfigEntry<bool> Quantumtransportbuild_bool;

	public static ConfigEntry<bool> Quantumtransportpdwarp_bool;

	public static ConfigEntry<bool> Quantumtransportstarwarp_bool;

	public static ConfigEntry<bool> needtrashsand;

	public static ConfigEntry<bool> InfineteStarPower;

	public static ConfigEntry<bool> PlanetPower_bool;

	public static ConfigEntry<bool> allhandcraft;

	public static ConfigEntry<bool> quickproduce;

	public static ConfigEntry<bool> blueprintpastenoneed_bool;

	public static ConfigEntry<bool> noneedwarp;

	public static ConfigEntry<bool> Infinitething;

	public static ConfigEntry<bool> Infiniteplayerpower;

	public static ConfigEntry<bool> EnableTp;

	public static ConfigEntry<bool> deleteveinbool;

	public static ConfigEntry<bool> MechalogisticsPlanet_bool;

	public static ConfigEntry<bool> StationMiner;

	public static ConfigEntry<bool> StationSprayer;

	public static ConfigEntry<bool> StationMinerSmelter;

	public static ConfigEntry<bool> dismantle_but_nobuild;

	public static ConfigEntry<bool> MiddleMouseLockGrid;

	public static ConfigEntry<bool> build_station_nocondition;

	public static ConfigEntry<bool> StationTrash;

	public static ConfigEntry<bool> DroneNoenergy_bool;

	public static ConfigEntry<bool> BuildNotime_bool;

	public static ConfigEntry<bool> Station_infiniteWarp_bool;

	public static ConfigEntry<bool> StationfullCount_bool;

	public static ConfigEntry<bool> Buildingnoconsume;

	public static ConfigEntry<bool> Stationfullenergy;

	public static ConfigEntry<bool> BeltSignalFunction;

	public static ConfigEntry<bool> Tankcontentall;

	public static ConfigEntry<bool> ArchitectMode;

	public static ConfigEntry<bool> quickabsorbsolar;

	public static ConfigEntry<bool> cancelsolarbullet;

	public static ConfigEntry<bool> QuickabortSwarm;

	public static ConfigEntry<bool> alwaysemission;

	public static ConfigEntry<bool> StationSpray;

	public static ConfigEntry<bool> Maxproliferator;

	public static ConfigEntry<bool> StationPowerGen;

	public static ConfigEntry<bool> ChangeDysonradius;

	public static ConfigEntry<bool> CloseUIAbnormalityTip;

	public static ConfigEntry<bool> IgnoreControlPanelLocalLimit;

	public static ConfigEntry<bool> QuantumtransportstationSupply;

	public static ConfigEntry<bool> QuantumtransportCollectorSupply;

	public static ConfigEntry<bool> QuantumtransportlabSupply;

	public static ConfigEntry<bool> QuantumtransportpowerSupply;

	public static ConfigEntry<bool> QuantumtransportassembleSupply;

	public static ConfigEntry<bool> QuantumtransportstationDemand;

	public static ConfigEntry<bool> LockPlayerHp;

	public static ConfigEntry<bool> LockBuildHp;

	public static ConfigEntry<bool> LockEnemyHp;

	public static ConfigEntry<bool> PlayerQuickAttack;

	public static ConfigEntry<bool> PlayerFakeDeath;

	public static ConfigEntry<bool> TurrentKeepSuperNoval;

	public static ConfigEntry<bool> TurrentKeepSuperNovalQuickKey;

	public static ConfigEntry<bool> ClickKillEnemy;

	public static ConfigEntry<bool> LocalAlwaysClearThreat;

	public static ConfigEntry<bool> SpaceAlwaysClearThreat;

	public static ConfigEntry<bool> LocalAlwaysMaxThreat;

	public static ConfigEntry<bool> SpaceAlwaysMaxThreat;

	public static ConfigEntry<bool> DarkFogBuilderQuickBuild;

	public static ConfigEntry<string> seedPlanetWater;

	public static ConfigEntry<string> AutoChangeStationName;

	public static ConfigEntry<bool> QuantumtransportminerDemand;

	public static ConfigEntry<bool> QuantumtransportsiloDemand;

	public static ConfigEntry<bool> QuantumtransportlabDemand;

	public static ConfigEntry<bool> QuantumtransportpowerDemand;

	public static ConfigEntry<bool> QuantumtransportassembleDemand;

	public static ConfigEntry<bool> ModifyDarkFogLevel;

	public static ConfigEntry<int> ModifyDarkFogLevelValue;

	private int dockindex = -1;

	public static List<int> CollectorStation = new List<int>();

	public static List<int> SuperStation = new List<int>();

	public static List<int> StarSuperStation = new List<int>();

	public static Dictionary<int, int[]> StarSuperStationItemidstore = new Dictionary<int, int[]>();

	public static Dictionary<int, Dictionary<int, List<int[]>>> PlanetSuperStationItemidstore = new Dictionary<int, Dictionary<int, List<int[]>>>();

	private Dictionary<RecipeProto, RecipeProto> handcraftOriginals;

	public static int DriftBuildingLevel
	{
		get
		{
			return driftBuildingLevel;
		}
		set
		{
			driftBuildingLevel = value;
			DriftBuildingHeight = 1f + (float)DriftBuildingLevel * 0.0066f;
		}
	}

	private static bool ResizePackage(Player target, int rowDelta, int columnDelta, bool add)
	{
		if (target?.package == null || rowDelta < 0 || columnDelta < 0 || target.packageColCount <= 0)
		{
			return false;
		}
		StorageComponent package = target.package;
		int packageColCount = target.packageColCount;
		long num = ((long)package.size + (long)packageColCount - 1) / packageColCount;
		long num2 = Math.Max(10L, Math.Min(30L, packageColCount + (add ? columnDelta : (-columnDelta))));
		long num3 = Math.Max(1L, num + (add ? rowDelta : (-rowDelta)));
		long num4 = num3 * num2;
		if (num4 > int.MaxValue)
		{
			return false;
		}
		for (int i = 0; i < package.size; i++)
		{
			if ((i / packageColCount >= num3 || i % packageColCount >= num2) && (package.grids[i].count != 0 || package.grids[i].filter != 0))
			{
				return false;
			}
		}
		StorageComponent.GRID[] array = new StorageComponent.GRID[(int)num4];
		for (int j = 0; j < package.size; j++)
		{
			if (j / packageColCount < num3 && j % packageColCount < num2)
			{
				array[j / packageColCount * (int)num2 + j % packageColCount] = package.grids[j];
			}
		}
		target.packageColCount = (int)num2;
		package.grids = array;
		package.size = (int)num4;
		package.ResetOptimizationFlags();
		package.NotifyStorageChange();
		package.NotifyStorageSizeChange();
		return true;
	}

	private void Start()
	{
		Constant.preparedraw();
		originWaterTypes = new SeedPlanetWater();
		seedPlanetWaterTypes = new Dictionary<long, SeedPlanetWater>();
		MultifunctionTranslate.regallTranslate();
		Quantumtransport_bool = base.Config.Bind("量子传输站", "Quantumtransport_bool", defaultValue: false);
		Quantumtransportstarwarp_bool = base.Config.Bind("星系级翘曲全面供应", "Quantumtransportstarwarp_bool", defaultValue: false);
		Quantumtransportpdwarp_bool = base.Config.Bind("星球级翘曲全面供应", "Quantumtransportpdwarp_bool", defaultValue: false);
		Quantumtransportbuild_bool = base.Config.Bind("星球级材料供应", "Quantumtransportbuild_bool", defaultValue: true);
		QuantumtransportCollectorSupply = base.Config.Bind("采集器拿取", "QuantumtransportCollectorSupply", defaultValue: true);
		QuantumtransportstationSupply = base.Config.Bind("星球级物流站材料供应", "QuantumtransportstationSupply", defaultValue: true);
		QuantumtransportlabSupply = base.Config.Bind("星球级研究站材料供应", "QuantumtransportlabSupply", defaultValue: true);
		QuantumtransportpowerSupply = base.Config.Bind("星球级电力设备材料供应", "QuantumtransportpowerSupply", defaultValue: true);
		QuantumtransportassembleSupply = base.Config.Bind("星球级组装机材料供应", "QuantumtransportassembleSupply", defaultValue: true);
		QuantumtransportstationDemand = base.Config.Bind("星球级物流站材料拿取", "QuantumtransportstationDemand", defaultValue: true);
		QuantumtransportminerDemand = base.Config.Bind("星球级矿机材料拿取", "QuantumtransportminerDemand", defaultValue: true);
		QuantumtransportsiloDemand = base.Config.Bind("星球级发射井弹射器材料拿取", "QuantumtransportsiloDemand", defaultValue: true);
		QuantumtransportlabDemand = base.Config.Bind("星球级研究站材料拿取", "QuantumtransportlabDemand", defaultValue: true);
		QuantumtransportpowerDemand = base.Config.Bind("星球级电力设备材料拿取", "QuantumtransportpowerDemand", defaultValue: true);
		QuantumtransportassembleDemand = base.Config.Bind("星球级组装机材料拿取", "QuantumtransportassembleDemand", defaultValue: true);
		scale = base.Config.Bind("大小适配", "scale", 16);
		LockPlayerHp = base.Config.Bind("玩家锁血", "LockPlayerHp", defaultValue: false);
		LockBuildHp = base.Config.Bind("建筑锁血", "LockBuildHp", defaultValue: false);
		LockEnemyHp = base.Config.Bind("怪物锁血", "LockEnemyHp", defaultValue: false);
		PlayerQuickAttack = base.Config.Bind("玩家攻速Max", "PlayerQuickAttack", defaultValue: false);
		PlayerFakeDeath = base.Config.Bind("玩家假死", "PlayerFakeDeath", defaultValue: false);
		TurrentKeepSuperNoval = base.Config.Bind("炮塔永久超新星", "TurrentKeepSuperNoval", defaultValue: false);
		TurrentKeepSuperNovalQuickKey = base.Config.Bind("启用快捷键(ctrl+s)", "TurrentKeepSuperNovalQuickKey", defaultValue: false);
		LocalAlwaysClearThreat = base.Config.Bind("星球永远0威胁", "LocalAlwaysClearThreat", defaultValue: false);
		SpaceAlwaysClearThreat = base.Config.Bind("太空永远0威胁", "SpaceAlwaysClearThreat", defaultValue: false);
		LocalAlwaysMaxThreat = base.Config.Bind("玩家所在星球永远满威胁", "LocalAlwaysMaxThreat", defaultValue: false);
		SpaceAlwaysMaxThreat = base.Config.Bind("玩家所在星系永远满威胁", "SpaceAlwaysMaxThreat", defaultValue: false);
		DarkFogBuilderQuickBuild = base.Config.Bind("黑雾巢穴快速产怪", "DarkFogBuilderQuickBuild", defaultValue: false);
		ClickKillEnemy = base.Config.Bind("点击杀死敌人", "ClickKillEnemy", defaultValue: false);
		ClickKillEnemyMode = base.Config.Bind("点击杀死敌人模式", "ClickKillEnemyMode", 0);
		ModifyDarkFogLevel = base.Config.Bind("调整黑雾怪物等级", "ModifyDarkFogLevel", defaultValue: false);
		ModifyDarkFogLevelValue = base.Config.Bind("调整黑雾怪物等级数值", "ModifyDarkFogLevelValue", 15);
		ArchitectMode = base.Config.Bind("建筑师模式", "ArchitectMode", defaultValue: false);
		EnableTp = base.Config.Bind("启用传送", "EnableTp", defaultValue: false);
		Quantumenergy = base.Config.Bind("量子耗能", "Quantumenergy", 1000000);
		StationMinerSmelterNum = base.Config.Bind("星球熔炉矿机等价高级熔炉数量", "StationMinerSmelterNum", 120);
		StationfullCount_bool = base.Config.Bind("星球无限供货机", "StationfullCount_bool", defaultValue: false);
		StationMinerSmelter = base.Config.Bind("星球熔炉矿机", "StationMinerSmelter", defaultValue: false);
		StationSprayer = base.Config.Bind("喷涂加工厂", "StationSprayer", defaultValue: false);
		InfineteStarPower = base.Config.Bind("人造卫星无限能源", "InfineteStarPower", defaultValue: false);
		WindturbinesUnlimitedEnergy = base.Config.Bind("风力涡轮机无限能源", "WindturbinesUnlimitedEnergy", defaultValue: false);
		Windturbinescovertheglobe = base.Config.Bind("风力涡轮机覆盖全球", "Windturbinescovertheglobe", defaultValue: false);
		Infinitestoragetank = base.Config.Bind("无限储液站", "Infinitestoragetank", defaultValue: false);
		TankMaxproliferator = base.Config.Bind("储液站无限增产", "TankMaxproliferator", defaultValue: false);
		Tankcontentall = base.Config.Bind("储液站任意存", "Tankcontentall", defaultValue: false);
		allhandcraft = base.Config.Bind("全部手搓", "allhandcraft", defaultValue: false);
		quickproduce = base.Config.Bind("快速生产", "quickproduce", defaultValue: false);
		noneedwarp = base.Config.Bind("无翘曲器曲速", "noneedwarp", defaultValue: false);
		isInstantItem = base.Config.Bind("直接获取物品", "isInstantItem", defaultValue: false);
		QuickResearch = base.Config.Bind("鼠标中键锁定格子", "QuickResearch", defaultValue: false);
		MiddleMouseLockGrid = base.Config.Bind("鼠标中键锁定格子", "MiddleMouseLockGrid", defaultValue: false);
		CuttingVeinNumbers = base.Config.Bind("切割矿脉数量", "CuttingVeinNumbers", 3);
		veinlines = base.Config.Bind("矿物行数", "veinlines", 3);
		NotTidyVein = base.Config.Bind("矿堆不整理", "NotTidyVein", defaultValue: false);
		deleteveinbool = base.Config.Bind("删除矿物", "deleteveinbool", defaultValue: false);
		StationMaxproliferator = base.Config.Bind("物流站无限增产点数", "StationMaxproliferator", defaultValue: false);
		BeltSignalFunction = base.Config.Bind("传送带信号功能", "BeltSignalFunction", defaultValue: false);
		Mechalogistics_bool = base.Config.Bind("机甲物流", "Mechalogistics_bool", defaultValue: false);
		MechalogisticsPlanet_bool = base.Config.Bind("机甲物流专用星", "MechalogisticsPlanet_bool", defaultValue: false);
		MechalogBuildGotoPlayerStorageFirst_bool = base.Config.Bind("建筑优先进入玩家背包", "MechalogBuildGotoPlayerStorageFirst_bool", defaultValue: false);
		MechalogPlayerStorageFirst_bool = base.Config.Bind("所有物品优先进入玩家背包", "MechalogPlayerStorageFirst_bool", defaultValue: false);
		MechalogStationprovide_bool = base.Config.Bind("需求使用物流站", "MechalogStationprovide_bool", defaultValue: false);
		MechalogStationrecycle_bool = base.Config.Bind("回收使用物流站", "MechalogStationrecycle_bool", defaultValue: false);
		MechalogStorageprovide_bool = base.Config.Bind("需求使用储物仓", "MechalogStorageprovide_bool", defaultValue: false);
		MechalogStoragerecycle_bool = base.Config.Bind("回收使用储物仓", "MechalogStoragerecycle_bool", defaultValue: false);
		Infinitething = base.Config.Bind("无限物品", "Infinitething", defaultValue: false);
		InfiniteSand = base.Config.Bind("无限沙土", "InfiniteSand", defaultValue: false);
		Infiniteplayerpower = base.Config.Bind("无限机甲能量", "Infiniteplayerpower", defaultValue: false);
		StationMiner = base.Config.Bind("星球矿机", "stationmineropen", defaultValue: false);
		StationTrash = base.Config.Bind("星球垃圾箱", "stationtrashopen", defaultValue: false);
		Buildingnoconsume = base.Config.Bind("全设备不耗电", "Buildingnoconsume", defaultValue: false);
		Stationfullenergy = base.Config.Bind("物流站永久满电", "Stationfullenergy", defaultValue: false);
		StationSpray = base.Config.Bind("物流站喷涂", "StationSpray", defaultValue: false);
		StationPowerGen = base.Config.Bind("物流站内置发电", "StationPowerGen", defaultValue: false);
		build_station_nocondition = base.Config.Bind("建造无需条件", "build_station_nocondition", defaultValue: false);
		QuickHandcraft = base.Config.Bind("机甲制造MAX", "QuickHandcraft", defaultValue: false);
		QuickPlayerMine = base.Config.Bind("机甲采矿Max", "QuickPlayerMine", defaultValue: false);
		InspectDisNoLimit = base.Config.Bind("操作范围不受限制", "InspectDisNoLimit", defaultValue: false);
		needtrashsand = base.Config.Bind("需要垃圾沙土", "needtrashsand", defaultValue: false);
		dismantle_but_nobuild = base.Config.Bind("拆除不添加至背包", "dismantle_but_nobuild", defaultValue: false);
		DroneNoenergy_bool = base.Config.Bind("小飞机不耗能", "DroneNoenergy_bool", defaultValue: false);
		Station_infiniteWarp_bool = base.Config.Bind("星际运输站无限曲速", "Station_infiniteWarp_bool", defaultValue: false);
		BuildNotime_bool = base.Config.Bind("建筑秒完成", "BuildNotime_bool", defaultValue: false);
		PlanetPower_bool = base.Config.Bind("星球电网", "PlanetPower_bool", defaultValue: false);
		blueprintpastenoneed_bool = base.Config.Bind("蓝图建造无需材料", "blueprintpastenoneed_bool", defaultValue: false);
		quickabsorbsolar = base.Config.Bind("跳过太阳帆吸收阶段", "quickabsorbsolar", defaultValue: false);
		cancelsolarbullet = base.Config.Bind("跳过太阳帆子弹阶段", "cancelsolarbullet", defaultValue: false);
		alwaysemission = base.Config.Bind("全球打帆", "alwaysemission", defaultValue: false);
		QuickabortSwarm = base.Config.Bind("太阳帆秒吸收", "QuickabortSwarm", defaultValue: false);
		ChangeDysonradius = base.Config.Bind("改变戴森球半径上下限", "ChangeDysonradius", defaultValue: false);
		MaxOrbitRadiusConfig = base.Config.Bind("戴森球最大半径", "MaxOrbitRadiusConfig", 1000000);
		StationStoExtra = base.Config.Bind("运输站额外储量", "StationStoExtra", 0);
		StackMultiple = base.Config.Bind("堆叠倍数", "StackMultiple", 1);
		Stationminenumber = base.Config.Bind("星球矿机速率", "Stationminenumber", 1);
		Buildmaxlen = base.Config.Bind("建筑数量最大值", "Buildmaxlen", 15);
		Maxproliferator = base.Config.Bind("增产点数上限10", "Maxproliferator", defaultValue: false);
		starquamaxpowerpertick = base.Config.Bind("实时修改星球量子充电功率", "starquamaxpowerpertick", 60f);
		planetquamaxpowerpertick = base.Config.Bind("实时修改星系量子充电功率", "planetquamaxpowerpertick", 60f);
		CloseUIAbnormalityTip = base.Config.Bind("关闭异常提示", "CloseUIAbnormalityTip", defaultValue: false);
		Textcolor = base.Config.Bind("字体颜色", "Textcolor", Color.white);
		mainWindowTextureColor_config = base.Config.Bind("窗口材质颜色", "mainWindowTextureColor", Color.black);
		seedPlanetWater = base.Config.Bind("海洋类型修改", "seedPlanetWater", "");
		AutoChangeStationName = base.Config.Bind("物流站自动改名", "AutoChangeStationName", "");
		Solarsailsabsorbeveryframe = base.Config.Bind("每帧吸收个数", "Solarsailsabsorbeveryframe", 1);
		IgnoreControlPanelLocalLimit = base.Config.Bind("取消总控面板本地限制", "IgnoreControlPanelLocalLimit", defaultValue: false);
		MainWindow_x_config = base.Config.Bind("第一窗口x", "xl_SimpleUI_1_x_config", 448f);
		MainWindow_y_config = base.Config.Bind("第一窗口y", "xl_SimpleUI_1_y_config", 199f);
		MainWindow_width = base.Config.Bind("第一窗口宽度", "xl_SimpleUI_1_x_config", 1400f);
		MainWindow_height = base.Config.Bind("第一窗口高度", "xl_SimpleUI_1_y_config", 1000f);
		QuickKey = base.Config.Bind("打开窗口快捷键", "Key", new KeyboardShortcut(KeyCode.LeftAlt, KeyCode.Alpha1));
		if (QuickKey.Value.MainKey == KeyCode.Alpha1 && QuickKey.Value.Modifiers.Count() == 1 && QuickKey.Value.Modifiers.ElementAt(0) == KeyCode.LeftAlt)
		{
			QuickKey.Value = new KeyboardShortcut(KeyCode.LeftAlt, KeyCode.Alpha1);
		}
		GameObject gameObject = UnityEngine.Object.Instantiate(AssetBundle.LoadFromStream(Assembly.GetExecutingAssembly().GetManifestResourceStream("Multifunction_mod.multifunctionpanel")).LoadAsset<GameObject>("MultiFunctionPanel"), UIRoot.instance.overlayCanvas.transform);
		gameObject.SetActive(value: false);
		guidraw = new GUIDraw(Math.Max(5, Math.Min(scale.Value, 35)), gameObject, this);
		veinproperty = new VeinControlProperty
		{
			VeinLines = veinlines.Value,
			CuttingVeinNumbers = CuttingVeinNumbers.Value,
			oillowerlimit = (int)(0.1f / VeinData.oilSpeedMultiplier),
			DeleteVein = deleteveinbool.Value,
			NotTidyVein = NotTidyVein.Value
		};
		incAbility = (Maxproliferator.Value ? 10 : 4);
		tempShowWindow = QuickKey.Value;
		CollectorStation = new List<int>();
		InitWaterTypes();
		IgnoreControlPanelLocalLimit.SettingChanged += delegate
		{
			UIControlPanelPatch.Enable = IgnoreControlPanelLocalLimit.Value;
		};
		alwaysemission.SettingChanged += delegate
		{
			EjectAnywayPatch.Enable = alwaysemission.Value;
		};
		cancelsolarbullet.SettingChanged += delegate
		{
			SkipBulletPatch.Enable = cancelsolarbullet.Value;
		};
		SkipBulletPatch.Enable = cancelsolarbullet.Value;
		EjectAnywayPatch.Enable = alwaysemission.Value;
		UIControlPanelPatch.Enable = IgnoreControlPanelLocalLimit.Value;
		Multifunctionpatch.Patchallmethod();
	}

	private void Update()
	{
		if (FinallyInit)
		{
			if (Time.time > OnesecondTime + 1f)
			{
				OnesecondTime = Time.time;
				OneSecondTimeElapse = true;
			}
			if (Time.time > HalfsecondTime + 0.5f)
			{
				HalfsecondTime = Time.time;
				HalfSecondTimeElapse = true;
			}
		}
		ChangeQuickKeyMethod();
		QuickKeyOpenWindow();
		FirstStartGame();
		AfterGameStart();
		Input.GetKeyDown(KeyCode.F9);
	}

	private void OnGUI()
	{
		IsEnglish = Localization.CurrentLanguage.glyph == Localization.EGlyph.Latin;
		guidraw.Draw();
	}

	public void RefreshSuperStation()
	{
		if (GameMain.data?.galacticTransport?.stationPool == null)
		{
			return;
		}
		StarSuperStation.Clear();
		SuperStation.Clear();
		StarSuperStationItemidstore.Clear();
		PlanetSuperStationItemidstore.Clear();
		for (int i = 0; i < GameMain.data.galacticTransport.stationPool.Length; i++)
		{
			StationComponent stationComponent = GameMain.data.galacticTransport.stationPool[i];
			if (stationComponent == null)
			{
				continue;
			}
			string text = (GameMain.galaxy.PlanetById(stationComponent.planetId)?.factory).ReadExtraInfoOnEntity(stationComponent.entityId);
			if (string.IsNullOrEmpty(text) || stationComponent.storage == null || !stationComponent.isStellar)
			{
				continue;
			}
			if (text == "星系量子传输站")
			{
				StarSuperStation.Add(i);
				for (int j = 0; j < stationComponent.storage.Length; j++)
				{
					ref StationStore reference = ref stationComponent.storage[j];
					if (reference.itemId > 0)
					{
						if (!StarSuperStationItemidstore.ContainsKey(reference.itemId))
						{
							StarSuperStationItemidstore.Add(reference.itemId, new int[2]
							{
								StarSuperStation.Count - 1,
								j
							});
						}
						if (reference.count < 0)
						{
							reference.count = 0;
						}
						if (reference.inc < 0)
						{
							reference.inc = 0;
						}
						else if (reference.inc > reference.count * 4)
						{
							reference.inc = reference.count * 4;
						}
					}
				}
				if (changequapowerpertick)
				{
					try
					{
						GameMain.galaxy.PlanetById(stationComponent.planetId).factory.powerSystem.consumerPool[stationComponent.pcId].workEnergyPerTick = (long)starquamaxpowerpertick.Value * 16667;
					}
					catch
					{
					}
				}
			}
			if (!(text == "星球量子传输站"))
			{
				continue;
			}
			SuperStation.Add(i);
			if (changequapowerpertick)
			{
				try
				{
					GameMain.galaxy.PlanetById(stationComponent.planetId).factory.powerSystem.consumerPool[stationComponent.pcId].workEnergyPerTick = (long)planetquamaxpowerpertick.Value * 16667;
				}
				catch
				{
				}
			}
		}
	}

	public void takeitemfromstarsuperstation()
	{
		if (GameMain.data?.galacticTransport?.stationPool == null)
		{
			return;
		}
		RefreshSuperStation();
		int count = SuperStation.Count;
		int count2 = StarSuperStation.Count;
		if (count == 0 && count2 == 0)
		{
			return;
		}
		changequapowerpertick = false;
		for (int i = 0; i < count; i++)
		{
			StationComponent stationComponent = GameMain.data.galacticTransport.stationPool[SuperStation[i]];
			int planetId = stationComponent.planetId;
			for (int num = stationComponent.storage.Length - 1; num >= 0; num--)
			{
				ref StationStore reference = ref stationComponent.storage[num];
				int itemId = reference.itemId;
				if (itemId > 0)
				{
					if (!PlanetSuperStationItemidstore.ContainsKey(planetId))
					{
						PlanetSuperStationItemidstore.Add(planetId, new Dictionary<int, List<int[]>>());
					}
					Dictionary<int, List<int[]>> dictionary = PlanetSuperStationItemidstore[planetId];
					if (!dictionary.ContainsKey(itemId))
					{
						dictionary.Add(itemId, new List<int[]> { new int[2] { i, num } });
					}
					else
					{
						dictionary[itemId].Add(new int[2] { i, num });
					}
					if (reference.remoteLogic == ELogisticStorage.Demand && reference.count < reference.max)
					{
						if (reference.max > reference.count)
						{
							int[] array = doitemfromStarsuper(itemId, reference.max - reference.count);
							reference.count += array[0];
							reference.inc += array[1];
						}
						else if (reference.max < reference.count)
						{
							int[] array2 = doitemfromStarsuper(itemId, reference.count - reference.max, reference.inc, take: false);
							reference.count -= array2[0];
							reference.inc -= array2[1];
						}
					}
					else if (reference.remoteLogic == ELogisticStorage.Supply && reference.count > 0)
					{
						int[] array3 = doitemfromStarsuper(itemId, reference.count, reference.inc, take: false);
						reference.count -= array3[0];
						reference.inc -= array3[1];
					}
					if (reference.count < 0)
					{
						reference.count = 0;
					}
					if (reference.inc < 0)
					{
						reference.inc = 0;
					}
				}
			}
			if (Quantumtransportpdwarp_bool.Value && stationComponent.warperCount <= 5)
			{
				stationComponent.warperCount += doitemfromStarsuper(1210, 50)[0];
			}
		}
		for (int j = 0; j < count2; j++)
		{
			StationComponent stationComponent2 = GameMain.data.galacticTransport.stationPool[StarSuperStation[j]];
			if (Quantumtransportstarwarp_bool.Value && stationComponent2.warperCount <= 5)
			{
				stationComponent2.warperCount += doitemfromStarsuper(1210, 50)[0];
			}
		}
		if (QuantumtransportCollectorSupply.Value)
		{
			CollectorStationDemand();
		}
		if (Quantumtransportbuild_bool.Value)
		{
			SuperStationProvide();
		}
	}

	public void StationSupplyDemand(FactorySystem fs, int pdid)
	{
		StationComponent[] stationPool = fs.factory.transport.stationPool;
		foreach (StationComponent stationComponent in stationPool)
		{
			if (stationComponent?.storage == null)
			{
				continue;
			}
			string text = fs.factory.ReadExtraInfoOnEntity(stationComponent.entityId);
			if (text == "星球量子传输站")
			{
				continue;
			}
			for (int j = 0; j < stationComponent.storage.Length; j++)
			{
				ref StationStore reference = ref stationComponent.storage[j];
				if (reference.itemId > 0)
				{
					if (QuantumtransportstationDemand.Value && reference.localLogic == ELogisticStorage.Supply && reference.count > 0 && text != "星系量子传输站")
					{
						int[] array = doitemfromPlanetSuper(reference.itemId, reference.count, pdid, reference.inc, take: false);
						reference.count -= array[0];
						reference.inc -= array[1];
					}
					if (QuantumtransportstationSupply.Value && reference.localLogic == ELogisticStorage.Demand && reference.count <= reference.max)
					{
						int[] array2 = doitemfromPlanetSuper(reference.itemId, reference.max - reference.count, pdid);
						reference.count += array2[0];
						reference.inc += array2[1];
					}
				}
			}
		}
	}

	public void MinerSupplyDemand(FactorySystem fs, int pdid)
	{
		MinerComponent[] minerPool = fs.minerPool;
		for (int i = 0; i < minerPool.Length; i++)
		{
			MinerComponent minerComponent = minerPool[i];
			if (minerComponent.id > 0 && minerComponent.entityId > 0 && minerComponent.productCount > 20 && minerComponent.productId > 0)
			{
				fs.minerPool[minerComponent.id].productCount -= doitemfromPlanetSuper(minerComponent.productId, minerComponent.productCount, pdid, 0, take: false)[0];
			}
		}
	}

	public void SiloComponentSupplyDemand(FactorySystem fs, int pdid)
	{
		SiloComponent[] siloPool = fs.siloPool;
		for (int i = 0; i < siloPool.Length; i++)
		{
			SiloComponent siloComponent = siloPool[i];
			if (siloComponent.id > 0 && siloComponent.entityId > 0 && siloComponent.bulletCount <= 1)
			{
				int[] array = doitemfromPlanetSuper(1503, 20, pdid);
				fs.siloPool[siloComponent.id].bulletCount += array[0];
				fs.siloPool[siloComponent.id].bulletInc += array[1];
			}
		}
		EjectorComponent[] ejectorPool = fs.ejectorPool;
		for (int j = 0; j < ejectorPool.Length; j++)
		{
			EjectorComponent ejectorComponent = ejectorPool[j];
			if (ejectorComponent.id > 0 && ejectorComponent.entityId > 0 && ejectorComponent.bulletCount <= 1)
			{
				int[] array2 = doitemfromPlanetSuper(1501, 20, pdid);
				fs.ejectorPool[ejectorComponent.id].bulletCount += array2[0];
				fs.ejectorPool[ejectorComponent.id].bulletInc += array2[1];
			}
		}
	}

	public void AssemblerSupplyDemand(FactorySystem fs, int pdid)
	{
		AssemblerComponent[] assemblerPool = fs.assemblerPool;
		for (int i = 0; i < assemblerPool.Length; i++)
		{
			AssemblerComponent assemblerComponent = assemblerPool[i];
			if (assemblerComponent.id <= 0 || assemblerComponent.entityId <= 0 || assemblerComponent.recipeId <= 0)
			{
				continue;
			}
			if (QuantumtransportassembleDemand.Value)
			{
				int[] productCounts = assemblerComponent.recipeExecuteData.productCounts;
				int[] products = assemblerComponent.recipeExecuteData.products;
				for (int j = 0; j < productCounts.Length; j++)
				{
					int num = assemblerComponent.produced[j];
					if (num > 500)
					{
						num = 200;
					}
					if (num > 0)
					{
						num -= doitemfromPlanetSuper(products[j], num, pdid, 0, take: false)[0];
					}
					assemblerComponent.produced[j] = num;
				}
			}
			if (!QuantumtransportassembleSupply.Value)
			{
				continue;
			}
			int[] requireCounts = assemblerComponent.recipeExecuteData.requireCounts;
			int[] requires = assemblerComponent.recipeExecuteData.requires;
			for (int k = 0; k < assemblerComponent.served.Length; k++)
			{
				if (assemblerComponent.served[k] <= requireCounts[k] * 2)
				{
					int[] array = doitemfromPlanetSuper(requires[k], 20, pdid);
					assemblerComponent.served[k] += array[0];
					assemblerComponent.incServed[k] += array[1];
				}
				if (assemblerComponent.served[k] < 0)
				{
					assemblerComponent.served[k] = 0;
				}
			}
		}
	}

	public void LabSupplyDemand(FactorySystem fs, int pdid)
	{
		LabComponent[] labPool = fs.labPool;
		for (int i = 0; i < labPool.Length; i++)
		{
			LabComponent labComponent = labPool[i];
			if (labComponent.id <= 0 || labComponent.entityId <= 0)
			{
				continue;
			}
			if (QuantumtransportlabSupply.Value && labComponent.researchMode)
			{
				for (int j = 0; j < labComponent.matrixServed.Length; j++)
				{
					if (labComponent.matrixServed[j] <= 288000)
					{
						int[] array = doitemfromPlanetSuper(6001 + j, 20, pdid);
						labComponent.matrixServed[j] += array[0] * 3600;
						labComponent.matrixIncServed[j] += array[1] * 3600;
					}
				}
			}
			if (!labComponent.matrixMode)
			{
				continue;
			}
			if (QuantumtransportlabDemand.Value)
			{
				for (int k = 0; k < labComponent.recipeExecuteData.productCounts.Length; k++)
				{
					if (labComponent.produced[k] > 5)
					{
						labComponent.produced[k] -= doitemfromPlanetSuper(labComponent.recipeExecuteData.products[k], labComponent.produced[k], pdid, 0, take: false)[0];
					}
				}
			}
			if (!QuantumtransportlabSupply.Value)
			{
				continue;
			}
			for (int l = 0; l < labComponent.served.Length; l++)
			{
				if (labComponent.served[l] <= 20)
				{
					int[] array2 = doitemfromPlanetSuper(labComponent.recipeExecuteData.requires[l], 20, pdid);
					labComponent.served[l] += array2[0];
					labComponent.incServed[l] += array2[1];
				}
			}
		}
	}

	public void PowerSupplyDemand(FactorySystem fs, int pdid)
	{
		PowerGeneratorComponent[] genPool = fs.factory.powerSystem.genPool;
		for (int i = 0; i < genPool.Length; i++)
		{
			PowerGeneratorComponent powerGeneratorComponent = genPool[i];
			if (powerGeneratorComponent.id <= 0)
			{
				continue;
			}
			if (powerGeneratorComponent.gamma)
			{
				if (QuantumtransportpowerDemand.Value && powerGeneratorComponent.productCount >= 1f)
				{
					fs.factory.powerSystem.genPool[powerGeneratorComponent.id].productCount -= doitemfromPlanetSuper(1208, (int)powerGeneratorComponent.productCount, pdid, 0, take: false)[0];
				}
				if (QuantumtransportpowerSupply.Value && powerGeneratorComponent.catalystPoint == 0)
				{
					int[] array = doitemfromPlanetSuper(1209, 5, pdid);
					fs.factory.powerSystem.genPool[powerGeneratorComponent.id].catalystPoint += array[0] * 3600;
					fs.factory.powerSystem.genPool[powerGeneratorComponent.id].catalystInc += (short)(array[1] * 3600);
				}
			}
			else
			{
				if (!QuantumtransportpowerSupply.Value)
				{
					continue;
				}
				int num = 0;
				switch (powerGeneratorComponent.fuelMask)
				{
				case 1:
					num = 1006;
					break;
				case 2:
					num = 1802;
					break;
				case 4:
					num = 1803;
					break;
				}
				if (num > 0 && powerGeneratorComponent.fuelCount <= 2)
				{
					int[] array2 = doitemfromPlanetSuper(num, 20, pdid);
					short num2 = (short)array2[0];
					if (num2 == 0)
					{
						break;
					}
					short num3 = (short)array2[1];
					if (powerGeneratorComponent.fuelCount == 0)
					{
						fs.factory.powerSystem.genPool[powerGeneratorComponent.id].SetNewFuel(num, num2, num3);
						continue;
					}
					fs.factory.powerSystem.genPool[powerGeneratorComponent.id].fuelCount += num2;
					fs.factory.powerSystem.genPool[powerGeneratorComponent.id].fuelInc += num3;
				}
			}
		}
	}

	public void CollectorStationDemand()
	{
		foreach (int item in CollectorStation)
		{
			StationComponent obj = GameMain.data.galacticTransport.stationPool[item];
			ref StationStore reference = ref obj.storage[0];
			ref StationStore reference2 = ref obj.storage[1];
			reference.count -= doitemfromStarsuper(reference.itemId, reference.count, 0, take: false)[0];
			reference2.count -= doitemfromStarsuper(reference2.itemId, reference2.count, 0, take: false)[0];
		}
	}

	public void SuperStationProvide()
	{
		foreach (int key in PlanetSuperStationItemidstore.Keys)
		{
			FactorySystem factorySystem = GameMain.galaxy.PlanetById(key).factory.factorySystem;
			if (QuantumtransportstationSupply.Value || QuantumtransportstationDemand.Value)
			{
				StationSupplyDemand(factorySystem, key);
			}
			if (QuantumtransportminerDemand.Value)
			{
				MinerSupplyDemand(factorySystem, key);
			}
			if (QuantumtransportsiloDemand.Value)
			{
				SiloComponentSupplyDemand(factorySystem, key);
			}
			if (QuantumtransportlabSupply.Value || QuantumtransportlabDemand.Value)
			{
				LabSupplyDemand(factorySystem, key);
			}
			if (QuantumtransportpowerSupply.Value || QuantumtransportpowerDemand.Value)
			{
				PowerSupplyDemand(factorySystem, key);
			}
			if (QuantumtransportassembleSupply.Value || QuantumtransportassembleDemand.Value)
			{
				AssemblerSupplyDemand(factorySystem, key);
			}
		}
	}

	public static int[] doitemfromStarsuper(int itemid, int itemcount, int inc = 0, bool take = true)
	{
		if (!StarSuperStationItemidstore.ContainsKey(itemid) || itemcount <= 0)
		{
			return new int[2];
		}
		StationComponent stationComponent = GameMain.data.galacticTransport.stationPool[StarSuperStation[StarSuperStationItemidstore[itemid][0]]];
		_ = StarSuperStationItemidstore[itemid][0];
		int num = StarSuperStationItemidstore[itemid][1];
		long num2 = ((!Stationfullenergy.Value) ? Quantumenergy.Value : 0);
		int num3 = itemcount;
		ref StationStore reference = ref stationComponent.storage[num];
		if (take)
		{
			num3 = Math.Min(num3, reference.count);
			if (stationComponent.energy <= num3 * num2 && stationComponent.energy > 0)
			{
				num3 = Math.Min(num3, (int)(stationComponent.energy / num2));
				if (num3 == 0)
				{
					return new int[2];
				}
			}
			inc = Math.Min(num3 * 4, reference.inc);
			stationComponent.energy -= num3 * num2;
			reference.count -= num3;
			reference.inc -= inc;
		}
		else
		{
			if (stationComponent.energy >= 0 && stationComponent.energy < num3 * num2)
			{
				num3 = Math.Min(num3, (int)(stationComponent.energy / num2));
				if (num3 == 0)
				{
					return new int[2];
				}
			}
			if (reference.count + num3 <= reference.max)
			{
				inc = Math.Min(num3 * incAbility, inc);
				reference.count += num3;
				reference.inc += inc;
			}
			else if (reference.localLogic == ELogisticStorage.None && reference.remoteLogic == ELogisticStorage.None && reference.max < 2147483547)
			{
				if (reference.count + num3 <= 2147483547)
				{
					inc = Math.Min(num3 * incAbility, inc);
					reference.max = reference.count + num3;
					reference.count = reference.max;
					reference.inc += inc;
				}
				else
				{
					num3 = 2147483547 - reference.count;
					reference.max = reference.count + num3;
					reference.count = reference.max;
					reference.inc += inc;
				}
			}
			else
			{
				num3 = reference.max - reference.count;
				inc = Math.Min(num3 * incAbility, inc);
				reference.count = reference.max;
				reference.inc += inc;
			}
			stationComponent.energy -= num3 * num2;
		}
		return new int[2]
		{
			num3,
			StationMaxproliferator.Value ? (incAbility * num3) : inc
		};
	}

	public static int[] doitemfromPlanetSuper(int itemid, int itemcount, int planetid, int inc = 0, bool take = true)
	{
		if (!PlanetSuperStationItemidstore.ContainsKey(planetid) || !PlanetSuperStationItemidstore[planetid].ContainsKey(itemid) || itemcount == 0)
		{
			return new int[2];
		}
		int count = PlanetSuperStationItemidstore[planetid][itemid].Count;
		for (int i = 0; i < count; i++)
		{
			int index = PlanetSuperStationItemidstore[planetid][itemid][i][0];
			int num = PlanetSuperStationItemidstore[planetid][itemid][i][1];
			StationComponent stationComponent = GameMain.data.galacticTransport.stationPool[SuperStation[index]];
			ref StationStore reference = ref stationComponent.storage[num];
			if (stationComponent.storage[num].localLogic != ELogisticStorage.None && ((take && stationComponent.storage[num].localLogic != ELogisticStorage.Supply) || (!take && stationComponent.storage[num].localLogic != ELogisticStorage.Demand)))
			{
				continue;
			}
			long num2 = ((!Stationfullenergy.Value) ? Quantumenergy.Value : 0);
			int num3 = itemcount;
			if (take)
			{
				if (stationComponent.energy < num3 * num2)
				{
					num3 = Math.Min(num3, (int)(stationComponent.energy / num2));
				}
				if (num3 == 0)
				{
					return new int[2];
				}
				if (num3 > reference.count)
				{
					int itemcount2 = num3 - reference.count;
					int[] array = doitemfromStarsuper(itemid, itemcount2);
					num3 = reference.count + array[0];
					inc = reference.inc + array[1];
					reference.count = 0;
					reference.inc = 0;
				}
				else
				{
					inc = Math.Min(num3 * incAbility, reference.inc);
					reference.count -= num3;
					reference.inc -= inc;
				}
			}
			else
			{
				if (stationComponent.energy < num3 * num2)
				{
					num3 = Math.Min(num3, (int)(stationComponent.energy / num2));
					if (num3 == 0)
					{
						return new int[2];
					}
				}
				inc = Math.Min(num3 * incAbility, inc);
				if (reference.count + num3 >= reference.max)
				{
					int num4 = reference.count + num3 - reference.max;
					int[] array2 = doitemfromStarsuper(itemid, num4, inc, take: false);
					num3 -= num4 - array2[0];
					inc = Math.Min(num3 * incAbility, inc);
					reference.count = reference.max;
					reference.inc += inc - array2[1];
				}
				else
				{
					reference.count += num3;
					reference.inc += inc;
				}
			}
			return new int[2]
			{
				num3,
				StationMaxproliferator.Value ? (incAbility * num3) : inc
			};
		}
		return new int[2];
	}

	public void FirstStartGame()
	{
		if (GameMain.instance == null)
		{
			return;
		}
		if (!GameMain.instance.running && FinallyInit)
		{
			GameRunning = false;
			FinallyInit = false;
			closeallcollider = false;
			Beltsignal = new Dictionary<int, Dictionary<int, int>>();
			Beltsignalnumberoutput = new Dictionary<int, Dictionary<int, int>>();
			StarSuperStation = new List<int>();
			SuperStation = new List<int>();
			StarSuperStationItemidstore = new Dictionary<int, int[]>();
			PlanetSuperStationItemidstore = new Dictionary<int, Dictionary<int, List<int[]>>>();
			CollectorStation.Clear();
			SuperStation = new List<int>();
			StarSuperStation = new List<int>();
			alwaysemissiontemp = false;
			originWaterTypes = new SeedPlanetWater();
			GC.Collect();
		}
		if (!GameMain.instance.running || FinallyInit)
		{
			return;
		}
		FinallyInit = true;
		InitPlanetWaterType();
		if (BeltSignalFunction.Value)
		{
			InitBeltSignalDiction();
		}
		if (Quantumtransport_bool.Value)
		{
			InitQuantumTransport();
		}
		if (LDB.recipes != null && !LDBInitSave)
		{
			LDBInitSave = true;
			originRecipeProtos = new RecipeProto[LDB.recipes.dataArray.Length];
			for (int i = 0; i < originRecipeProtos.Length; i++)
			{
				RecipeProto recipeProto = LDB.recipes.dataArray[i];
				originRecipeProtos[i] = new RecipeProto
				{
					TimeSpend = recipeProto.TimeSpend,
					Handcraft = recipeProto.Handcraft
				};
				if (recipeProto.Type != ERecipeType.Smelt)
				{
					continue;
				}
				int[] items = recipeProto.Items;
				foreach (int key in items)
				{
					if (smeltRecipes.ContainsKey(key))
					{
						smeltRecipes[key].Add(recipeProto);
						continue;
					}
					smeltRecipes.Add(key, new List<RecipeProto> { recipeProto });
				}
			}
			ChangeRecipe();
		}
		alwaysemissiontemp = alwaysemission.Value;
		SetmultipleItemStatck(StackMultiple.Value);
		ChangeItemstack();
	}

	public void AfterGameStart()
	{
		if (GameMain.history == null || !FinallyInit)
		{
			return;
		}
		GameRunning = true;
		PlayerDataInit();
		if (GameMain.localPlanet == null)
		{
			currentPlanetWaterType = "";
		}
		else
		{
			BluePrintpasteNoneed();
			if (string.IsNullOrEmpty(currentPlanetWaterType))
			{
				currentPlanetWaterType = LDB.items.Select(GameMain.localPlanet.waterItemId)?.name ?? "无海洋".getTranslate();
			}
		}
		if (!guidraw.DisplayingWindow || !guidraw.MouseInWindow)
		{
			veinproperty.ControlVein();
			CombatFunction();
		}
		if (refreshLDB)
		{
			refreshLDB = false;
			ChangeRecipe();
		}
		OnsecondMethod();
		if (Infinitething.Value)
		{
			InfiniteAllThingInPackage();
		}
		if (QuickResearch.Value)
		{
			GameMain.history.AddTechHash(600000000000000L);
		}
		SetDronenocomsume();
		DriftBuild();
	}

	private void CombatFunction()
	{
		if (Input.GetMouseButtonUp(0) || (ClickGenerateDFRelayLockClick && Input.GetMouseButtonDown(0)))
		{
			ClickGenerateDFRelayLockClick = false;
		}
		if (ClickGenerateDFRelay && Input.GetMouseButtonDown(0) && Physics.Raycast(GameCamera.main.ScreenPointToRay(Input.mousePosition), out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide))
		{
			ClickGenerateDFRelay = false;
			ClickGenerateDFRelayLockClick = true;
			VectorLF3 vectorLF = hitInfo.point.normalized * (GameMain.localPlanet.realRadius + 70f);
			EnemyDFHiveSystem enemyDFHiveSystem = GameMain.data.spaceSector.dfHives[GameMain.localStar.index];
			if (enemyDFHiveSystem == null)
			{
				return;
			}
			int relayCount = enemyDFHiveSystem.relayCount;
			for (EnemyDFHiveSystem enemyDFHiveSystem2 = GameMain.data.spaceSector.dfHives[GameMain.localStar.index]; enemyDFHiveSystem2 != null; enemyDFHiveSystem2 = enemyDFHiveSystem2.nextSibling)
			{
				if (enemyDFHiveSystem2.isAlive && relayCount > enemyDFHiveSystem2.relayCount)
				{
					enemyDFHiveSystem = enemyDFHiveSystem2;
				}
			}
			System.Random random = new System.Random(enemyDFHiveSystem.seed);
			double x = random.NextDouble();
			double num = random.NextDouble();
			int num2 = GameMain.data.spaceSector.CreateEnemyFinal(enemyDFHiveSystem, 8116, GameMain.localPlanet.astroId, vectorLF, Maths.SphericalRotation(vectorLF, (float)num * 360f));
			int dfRelayId = enemyDFHiveSystem.sector.enemyPool[num2].dfRelayId;
			DFRelayComponent dFRelayComponent = enemyDFHiveSystem.relays.buffer[dfRelayId];
			Vector3 vector = -(GameMain.localPlanet.veinBiasVector * 0.97f).normalized;
			if (dFRelayComponent != null)
			{
				dFRelayComponent.SetDockIndex(enemyDFHiveSystem.relayCount);
				dFRelayComponent.hiveAstroId = enemyDFHiveSystem.hiveAstroId;
				dFRelayComponent.targetAstroId = GameMain.localPlanet.astroId;
				dFRelayComponent.targetLPos = vectorLF;
				dFRelayComponent.targetYaw = (float)num * 360f;
				dFRelayComponent.baseState = 1;
				dFRelayComponent.baseId = 0;
				double num3 = VectorLF3.Dot(vectorLF.normalized, vector);
				num3 = Maths.Clamp01((num3 + 1.0) * 0.5);
				num3 = Math.Pow(num3, 0.5);
				dFRelayComponent.baseTicks = (int)(6400f * (float)(Math.Pow(x, 2.0) * num3) + 200.5f);
				dFRelayComponent.baseEvolve = enemyDFHiveSystem.evolve;
				dFRelayComponent.baseEvolve.threat = 0;
				dFRelayComponent.baseEvolve.waves = 1;
				dFRelayComponent.direction = 0;
				dFRelayComponent.stage = 2;
				int num4 = random.Next(180001) * 100;
				int builderId = dFRelayComponent.builderId;
				enemyDFHiveSystem.builders.buffer[builderId].energy = enemyDFHiveSystem.builders.buffer[builderId].maxEnergy + num4;
				enemyDFHiveSystem.sector.enemyAnimPool[num2].time = 1f;
				enemyDFHiveSystem.sector.enemyAnimPool[num2].state = 1u;
				enemyDFHiveSystem.sector.enemyAnimPool[num2].power = -1f;
			}
			enemyDFHiveSystem.idleRelayCount = 0;
			for (int i = 0; i < enemyDFHiveSystem.relayDocks.Length; i++)
			{
				ref DFDock reference = ref enemyDFHiveSystem.relayDocks[i % enemyDFHiveSystem.relayDocks.Length];
				int num5 = enemyDFHiveSystem.sector.CreateEnemyFinal(enemyDFHiveSystem, 8116, enemyDFHiveSystem.hiveAstroId, reference.pos, reference.rot);
				int dfRelayId2 = enemyDFHiveSystem.sector.enemyPool[num5].dfRelayId;
				DFRelayComponent dFRelayComponent2 = enemyDFHiveSystem.relays.buffer[dfRelayId2];
				Assert.True(dFRelayComponent2 != null && dfRelayId2 > 0 && dfRelayId2 == dFRelayComponent2.id);
				if (dFRelayComponent2 != null)
				{
					dFRelayComponent2.SetDockIndex(i);
					enemyDFHiveSystem.idleRelayIds[enemyDFHiveSystem.idleRelayCount++] = dfRelayId2;
				}
			}
		}
		else
		{
			if (ClickGenerateDFRelayLockClick || !ClickKillEnemy.Value || ((!Input.GetMouseButton(0) || ClickKillEnemyMode.Value != 1) && (!Input.GetMouseButtonDown(0) || ClickKillEnemyMode.Value != 0)))
			{
				return;
			}
			GameData data = GameMain.data;
			PlanetData localPlanet = data.localPlanet;
			PlanetFactory planetFactory = ((localPlanet != null && localPlanet.factoryLoaded) ? localPlanet.factory : null);
			PlanetPhysics planetPhysics = planetFactory?.planet.physics;
			SpaceSector spaceSector = data.spaceSector;
			SectorPhysics physics = spaceSector.physics;
			EnemyData item = default(EnemyData);
			EnemyDFGroundSystem enemyDFGroundSystem = null;
			EnemyDFHiveSystem enemyDFHiveSystem3 = null;
			if (planetPhysics != null)
			{
				item = planetPhysics.raycastLogic.castEnemy;
				if (item.id > 0)
				{
					enemyDFGroundSystem = planetFactory.enemySystem;
				}
			}
			if (enemyDFGroundSystem == null && physics != null && physics.spaceColliderLogic.cursorCastAllCount > 0)
			{
				RaycastData raycastData = physics.spaceColliderLogic.cursorCastAll[0];
				if (raycastData.objType == EObjectType.Enemy && raycastData.objId > 0)
				{
					item = spaceSector.enemyPool[raycastData.objId];
					enemyDFGroundSystem = null;
					enemyDFHiveSystem3 = spaceSector.GetHiveByAstroId(item.originAstroId);
				}
			}
			if (item.id <= 0 || item.modelIndex <= 0)
			{
				return;
			}
			if (enemyDFHiveSystem3 != null)
			{
				if (item.dfSCoreId > 0 && ClickKillEnemyBaseChain)
				{
					EnemyData[] enemyPool = GameMain.data.spaceSector.enemyPool;
					for (int j = 0; j < enemyPool.Length; j++)
					{
						EnemyData item2 = enemyPool[j];
						if (item2.originAstroId == enemyDFHiveSystem3.hiveAstroId)
						{
							killEnemys.Enqueue(item2);
						}
					}
				}
				killEnemys.Enqueue(item);
			}
			else
			{
				if (enemyDFGroundSystem == null)
				{
					return;
				}
				EnemyData[] enemyPool2 = planetFactory.enemyPool;
				int dfGBaseId = item.dfGBaseId;
				if (dfGBaseId > 0 && ClickKillEnemyBaseChain)
				{
					EnemyData[] array = enemyPool2;
					for (int k = 0; k < array.Length; k++)
					{
						EnemyData item3 = array[k];
						if (item3.owner == dfGBaseId)
						{
							killEnemys.Enqueue(item3);
						}
					}
				}
				killEnemys.Enqueue(item);
			}
		}
	}

	private void InitPlanetWaterType()
	{
		if (GameMain.galaxy?.stars == null || GameMain.data?.gameDesc == null)
		{
			return;
		}
		long seedKey = GameMain.data.gameDesc.seedKey64;
		originWaterTypes.seedKey64 = seedKey;
		StarData[] stars = GameMain.galaxy.stars;
		foreach (StarData starData in stars)
		{
			if (starData == null)
			{
				continue;
			}
			PlanetData[] planets = starData.planets;
			foreach (PlanetData planetData in planets)
			{
				if (planetData != null && !(planetData.gasTotalHeat > 0.0))
				{
					originWaterTypes.waterTypes.Add(planetData.id, planetData.waterItemId);
				}
			}
		}
		if (seedPlanetWaterTypes.ContainsKey(seedKey))
		{
			currentWaterTypes = seedPlanetWaterTypes[seedKey];
			{
				foreach (KeyValuePair<int, int> waterType in currentWaterTypes.waterTypes)
				{
					PlanetData planetData2 = GameMain.galaxy.PlanetById(waterType.Key);
					if (planetData2 != null)
					{
						planetData2.waterItemId = waterType.Value;
					}
				}
				return;
			}
		}
		currentWaterTypes = new SeedPlanetWater(seedKey);
		seedPlanetWaterTypes.Add(seedKey, currentWaterTypes);
	}

	private void OnsecondMethod()
	{
		if (!OneSecondTimeElapse)
		{
			return;
		}
		if (Quantumtransport_bool.Value)
		{
			try
			{
				takeitemfromstarsuperstation();
			}
			catch (Exception ex)
			{
				Debug.Log("量子传输失败1" + ex.Message);
			}
		}
		if (Mechalogistics_bool.Value)
		{
			MechaLogisticsMethod();
		}
		if (Infinitething.Value)
		{
			InfiniteAllThingInPackage();
		}
		if (MiddleMouseLockGrid.Value)
		{
			InfiniteFilterThingInPackage();
		}
	}

	public void CancelAllToggle()
	{
		InfiniteSand.Value = false;
		QuickHandcraft.Value = false;
		QuickPlayerMine.Value = false;
		QuickabortSwarm.Value = false;
		ChangeDysonradius.Value = false;
		NotTidyVein.Value = false;
		isInstantItem.Value = false;
		InspectDisNoLimit.Value = false;
		StationMaxproliferator.Value = false;
		Mechalogistics_bool.Value = false;
		MechalogStoragerecycle_bool.Value = false;
		MechalogStorageprovide_bool.Value = false;
		MechalogStationrecycle_bool.Value = false;
		MechalogStationprovide_bool.Value = false;
		Infinitestoragetank.Value = false;
		TankMaxproliferator.Value = false;
		Quantumtransport_bool.Value = false;
		Quantumtransportbuild_bool.Value = false;
		Quantumtransportpdwarp_bool.Value = false;
		Quantumtransportstarwarp_bool.Value = false;
		needtrashsand.Value = false;
		InfineteStarPower.Value = false;
		PlanetPower_bool.Value = false;
		allhandcraft.Value = false;
		quickproduce.Value = false;
		blueprintpastenoneed_bool.Value = false;
		noneedwarp.Value = false;
		Infinitething.Value = false;
		Infiniteplayerpower.Value = false;
		deleteveinbool.Value = false;
		MechalogisticsPlanet_bool.Value = false;
		StationMiner.Value = false;
		dismantle_but_nobuild.Value = false;
		build_station_nocondition.Value = false;
		StationTrash.Value = false;
		DroneNoenergy_bool.Value = false;
		BuildNotime_bool.Value = false;
		Station_infiniteWarp_bool.Value = false;
		StationfullCount_bool.Value = false;
		Buildingnoconsume.Value = false;
		Stationfullenergy.Value = false;
		BeltSignalFunction.Value = false;
		Tankcontentall.Value = false;
		ArchitectMode.Value = false;
		quickabsorbsolar.Value = false;
		cancelsolarbullet.Value = false;
		alwaysemission.Value = false;
		StationSpray.Value = false;
		Maxproliferator.Value = false;
		StationPowerGen.Value = false;
		CloseUIAbnormalityTip.Value = false;
		QuantumtransportstationSupply.Value = false;
		QuantumtransportlabSupply.Value = false;
		QuantumtransportpowerSupply.Value = false;
		QuantumtransportassembleSupply.Value = false;
		QuantumtransportstationDemand.Value = false;
		QuantumtransportminerDemand.Value = false;
		QuantumtransportsiloDemand.Value = false;
		QuantumtransportlabDemand.Value = false;
		QuantumtransportpowerDemand.Value = false;
		QuantumtransportassembleDemand.Value = false;
		Windturbinescovertheglobe.Value = false;
		WindturbinesUnlimitedEnergy.Value = false;
		AutoChangeStationName.Value = "";
		StationMinerSmelter.Value = false;
		StationSprayer.Value = false;
	}

	public void QuickKeyOpenWindow()
	{
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			guidraw.CloseMainWindow();
		}
		if (!ChangingQuickKey)
		{
			bool flag = false;
			if (QuickKey.Value.Modifiers.Count() == 0)
			{
				if (Input.GetKeyDown(QuickKey.Value.MainKey))
				{
					flag = true;
				}
			}
			else if (Input.GetKey(QuickKey.Value.MainKey))
			{
				flag = true;
				foreach (KeyCode modifier in QuickKey.Value.Modifiers)
				{
					if (!Input.GetKeyDown(modifier))
					{
						flag = false;
					}
				}
			}
			if (flag)
			{
				guidraw.MainWindowKeyInvoke();
			}
		}
		if (TurrentKeepSuperNovalQuickKey.Value && Input.GetKey(KeyCode.LeftControl) && Input.GetKeyDown(KeyCode.S))
		{
			TurrentKeepSuperNoval.Value = !TurrentKeepSuperNoval.Value;
			UIRealtimeTip.Popup("炮塔永久超新星" + (TurrentKeepSuperNoval.Value ? "开启" : "关闭"));
		}
	}

	public void ChangeQuickKeyMethod()
	{
		if (ChangeQuickKey)
		{
			setQuickKey();
			ChangingQuickKey = true;
		}
		else if (!ChangeQuickKey && ChangingQuickKey)
		{
			QuickKey.Value = tempShowWindow;
			ChangingQuickKey = false;
		}
	}

	public void DriftBuild()
	{
		if (!DriftBuildings)
		{
			return;
		}
		PlayerAction_Build playerAction_Build = player?.controller?.actionBuild;
		if (playerAction_Build != null && player.controller.cmd.type == ECommand.Build)
		{
			if (blueprintPasteToolActive != playerAction_Build.blueprintPasteTool.active)
			{
				blueprintPasteToolActive = !blueprintPasteToolActive;
				DriftBuildingLevel = 0;
			}
			if (Input.GetKeyDown(KeyCode.UpArrow))
			{
				DriftBuildingLevel++;
				if (blueprintPasteToolActive)
				{
					playerAction_Build.blueprintPasteTool.cursorValid = true;
					playerAction_Build.blueprintPasteTool.DeterminePreviewsPrestage();
				}
			}
			if (Input.GetKeyDown(KeyCode.DownArrow))
			{
				DriftBuildingLevel--;
				if (blueprintPasteToolActive)
				{
					playerAction_Build.blueprintPasteTool.cursorValid = true;
					playerAction_Build.blueprintPasteTool.DeterminePreviewsPrestage();
				}
			}
		}
		else if (DriftBuildingLevel != 0)
		{
			DriftBuildingLevel = 0;
		}
	}

	public void SetMaxGasStation()
	{
		if (GameMain.localPlanet != null && GameMain.localPlanet.type == EPlanetType.Gas)
		{
			for (int i = 0; i < Constant.nodepos.Count; i++)
			{
				Vector3 vector = Constant.nodepos[i] * GameMain.localPlanet.realRadius;
				Vector3 vector2 = 0.025f * vector.normalized * player.planetData.realRadius;
				Quaternion quaternion = Maths.SphericalRotation(vector, player.controller.actionBuild.clickTool.yaw);
				vector += vector2;
				PrebuildData prebuild = default(PrebuildData);
				prebuild.protoId = 2105;
				prebuild.modelIndex = 117;
				prebuild.pos = vector + quaternion * Vector3.zero;
				prebuild.pos2 = vector + quaternion * Vector3.zero;
				prebuild.rot = quaternion * Quaternion.identity;
				prebuild.rot2 = quaternion * Quaternion.identity;
				prebuild.pickOffset = 0;
				prebuild.insertOffset = 0;
				prebuild.recipeId = 0;
				prebuild.filterId = 0;
				prebuild.paramCount = 0;
				prebuild.InitParametersArray(0);
				player.controller.actionBuild.clickTool.factory.AddPrebuildDataWithComponents(prebuild);
			}
		}
	}

	public void InitPlayer()
	{
		if (player == null || player.mecha == null || player.mecha.constructionModule.droneIdleCount < player.mecha.constructionModule.droneAliveCount)
		{
			return;
		}
		refreshPlayerData = true;
		ModeConfig freeMode = Configs.freeMode;
		GameHistoryData history = GameMain.history;
		Mecha mecha = player.mecha;
		mecha.coreEnergyCap = freeMode.mechaCoreEnergyCap;
		mecha.coreLevel = freeMode.mechaCoreLevel;
		mecha.corePowerGen = freeMode.mechaCorePowerGen;
		mecha.miningSpeed = freeMode.mechaMiningSpeed;
		mecha.walkSpeed = freeMode.mechaWalkSpeed;
		mecha.jumpSpeed = freeMode.mechaJumpSpeed;
		mecha.walkPower = freeMode.mechaWalkPower;
		mecha.thrusterLevel = freeMode.mechaThrusterLevel;
		mecha.jumpEnergy = freeMode.mechaJumpEnergy;
		mecha.constructionModule.Setup(freeMode);
		mecha.maxSailSpeed = freeMode.mechaSailSpeedMax;
		mecha.maxWarpSpeed = freeMode.mechaWarpSpeedMax;
		mecha.buildArea = freeMode.mechaBuildArea;
		mecha.replicateSpeed = freeMode.mechaReplicateSpeed;
		mecha.reactorPowerGen = freeMode.mechaReactorPowerGen;
		mecha.thrustPowerPerAcc = freeMode.mechaThrustPowerPerAcc;
		mecha.warpKeepingPowerPerSpeed = freeMode.mechaWarpKeepingPowerPerSpeed;
		mecha.warpStartPowerPerSpeed = freeMode.mechaWarpStartPowerPerSpeed;
		mecha.miningPower = freeMode.mechaMiningPower;
		mecha.hpMaxUpgrade = 0;
		mecha.laserLocalAttackRange = freeMode.mechaLocalLaserAttackRange;
		mecha.laserSpaceAttackRange = freeMode.mechaSpaceLaserAttackRange;
		mecha.laserLocalDamage = freeMode.mechaLocalLaserDamage;
		mecha.laserEnergyCapacity = freeMode.mechaLaserEnergyCapacity;
		mecha.laserLocalEnergyCost = freeMode.mechaLocalLaserEnergyCost;
		mecha.laserSpaceEnergyCost = freeMode.mechaSpaceLaserEnergyCost;
		mecha.energyShieldRadius = freeMode.energyShieldRadius;
		mecha.energyShieldCapacity = freeMode.energyShieldCapacity;
		mecha.groundCombatModule.fleetCount = 0;
		mecha.spaceCombatModule.fleetCount = 0;
		player.deliveryPackage.colCount = 0;
		player.packageColCount = 10;
		player.deliveryPackage.stackSizeMultiplier = Configs.freeMode.deliveryPackageStackSizeMultiplier;
		int playerPackageSize = freeMode.playerPackageSize;
		player.deliveryPackage.rowCount = (playerPackageSize - 1) / 10 + 1;
		history.constructionDroneSpeed = freeMode.droneSpeed;
		history.globalHpEnhancement = 0f;
		history.constructionDroneMovement = freeMode.droneMovement;
		history.stationPilerLevel = 1;
		history.logisticDroneCarries = freeMode.logisticDroneCarries;
		history.logisticDroneSpeed = freeMode.logisticDroneSpeed;
		history.logisticShipCarries = freeMode.logisticShipCarries;
		history.logisticShipSailSpeed = freeMode.logisticShipSailSpeed;
		history.logisticShipWarpSpeed = freeMode.logisticShipWarpSpeed;
		history.logisticCourierSpeed = freeMode.logisticCourierSpeed;
		history.logisticCourierCarries = freeMode.logisticCourierCarries;
		history.dispenserDeliveryMaxAngle = freeMode.dispenserDeliveryMaxAngle;
		history.logisticShipSpeedScale = 1f;
		history.logisticDroneSpeedScale = 1f;
		history.logisticCourierSpeedScale = 1f;
		history.inserterStackInput = 2;
		history.logisticShipWarpDrive = freeMode.logisticShipWarpDrive;
		history.miningCostRate = freeMode.miningCostRate;
		history.miningSpeedScale = freeMode.miningSpeedScale;
		history.storageLevel = 2;
		history.labLevel = 3;
		history.enemyDropScale = 1f;
		history.techSpeed = freeMode.techSpeed;
		history.dysonNodeLatitude = 0f;
		history.solarEnergyLossRate = 0.7f;
		history.solarSailLife = freeMode.solarSailLife;
		history.localStationExtraStorage = 0;
		history.remoteStationExtraStorage = 0;
		history.autoReconstructSpeed = 0;
		history.kineticDamageScale = 1f;
		history.energyDamageScale = 1f;
		history.blastDamageScale = 1f;
		history.magneticDamageScale = 1f;
		history.combatDroneDamageRatio = 1f;
		history.combatDroneROFRatio = 1f;
		history.combatDroneDurabilityRatio = 1f;
		history.combatDroneSpeedRatio = 1f;
		history.combatShipSpeedRatio = 1f;
		history.combatShipDamageRatio = 1f;
		history.combatShipROFRatio = 1f;
		history.combatShipDurabilityRatio = 1f;
		history.planetaryATFieldEnergyRate = freeMode.planetaryATFieldEnergyRate;
		history.groundFleetPortCount = 0;
		history.spaceFleetPortCount = 0;
		StorageComponent.GRID[] array = new StorageComponent.GRID[player.package.size];
		Array.Copy(player.package.grids, array, player.package.size);
		player.package.SetSize(playerPackageSize);
		foreach (TechProto item in new List<TechProto>(LDB.techs.dataArray))
		{
			if (item.Level < item.MaxLevel)
			{
				for (int i = item.Level; i < GameMain.history.techStates[item.ID].curLevel + ((GameMain.history.techStates[item.ID].curLevel >= item.MaxLevel) ? 1 : 0); i++)
				{
					for (int j = 0; j < item.UnlockFunctions.Length; j++)
					{
						if (item.UnlockFunctions[j] == 30)
						{
							history.localStationExtraStorage += (int)item.UnlockValues[j];
						}
						else if (item.UnlockFunctions[j] == 31)
						{
							history.remoteStationExtraStorage += (int)item.UnlockValues[j];
						}
						else
						{
							GameMain.history.UnlockTechFunction(item.UnlockFunctions[j], item.UnlockValues[j], i);
						}
					}
				}
			}
			else if (GameMain.history.techStates[item.ID].unlocked)
			{
				for (int k = 0; k < item.UnlockFunctions.Length; k++)
				{
					GameMain.history.UnlockTechFunction(item.UnlockFunctions[k], item.UnlockValues[k], GameMain.history.techStates[item.ID].maxLevel);
				}
			}
		}
		int num = 0;
		for (int l = 0; l < array.Length; l++)
		{
			if (num == player.package.size)
			{
				break;
			}
			if (array[l].count != 0 || array[l].filter != 0 || array[l].itemId != 0)
			{
				player.package.grids[num++] = array[l];
			}
		}
	}

	public void MechaLogisticsMethod()
	{
		_ = player.package;
		if (player.inhandItemId != 0)
		{
			return;
		}
		int num = (MechalogPlayerStorageFirst_bool.Value ? 1 : 0);
		for (int i = 0; i < player.deliveryPackage.grids.Length; i++)
		{
			DeliveryPackage.GRID gRID = player.deliveryPackage.grids[i];
			int itemId = gRID.itemId;
			if (itemId == 0)
			{
				continue;
			}
			if (num == 0 && MechalogBuildGotoPlayerStorageFirst_bool.Value && LDB.items.Select(itemId).CanBuild)
			{
				num = 1;
			}
			int count = gRID.count;
			int num2 = player.packageUtility.GetPackageItemCount(itemId) + count;
			int remainInc;
			if (gRID.requireCount > num2)
			{
				int packageItemCapacity = player.packageUtility.GetPackageItemCapacity(itemId);
				int num3 = Math.Min(gRID.requireCount - num2, packageItemCapacity);
				int num4 = 0;
				int num5 = 0;
				for (int j = 0; j < GameMain.data.factoryCount; j++)
				{
					PlanetFactory planetFactory = GameMain.data.factories[j];
					if (MechalogisticsPlanet_bool.Value && !planetFactory.planet.displayName.Equals("机甲物流"))
					{
						continue;
					}
					if (MechalogStationprovide_bool.Value && planetFactory.transport?.stationPool != null)
					{
						StationComponent[] stationPool = planetFactory.transport.stationPool;
						foreach (StationComponent stationComponent in stationPool)
						{
							if (stationComponent != null && stationComponent.storage != null)
							{
								int count2 = num3;
								int itemId2 = itemId;
								stationComponent.TakeItem(ref itemId2, ref count2, out var inc);
								num4 += count2;
								num3 -= count2;
								num5 += inc;
								if (num4 >= num3)
								{
									break;
								}
							}
						}
					}
					if (!MechalogStorageprovide_bool.Value || planetFactory.factoryStorage == null)
					{
						continue;
					}
					if (num4 < num3 && planetFactory.factoryStorage.tankPool != null)
					{
						TankComponent[] tankPool = planetFactory.factoryStorage.tankPool;
						for (int l = 0; l < tankPool.Length; l++)
						{
							TankComponent tankComponent = tankPool[l];
							if (tankComponent.id > 0 && tankComponent.fluidId > 0 && tankComponent.fluidCount > 0 && itemId == tankComponent.fluidId)
							{
								int num6 = ((tankComponent.fluidCount > num3) ? num3 : tankComponent.fluidCount);
								int num7 = (int)((double)(tankComponent.fluidInc / tankComponent.fluidCount) + 0.5) * num6;
								planetFactory.factoryStorage.tankPool[tankComponent.id].fluidCount -= num6;
								planetFactory.factoryStorage.tankPool[tankComponent.id].fluidInc -= num7;
								num5 += num7;
								num4 += num6;
								num3 -= num6;
								if (num4 >= num3)
								{
									break;
								}
							}
						}
					}
					if (num4 >= num3 || planetFactory.factoryStorage.storagePool == null)
					{
						continue;
					}
					StorageComponent[] storagePool = planetFactory.factoryStorage.storagePool;
					foreach (StorageComponent storageComponent in storagePool)
					{
						if (storageComponent != null)
						{
							int inc2;
							int num8 = storageComponent.TakeItem(itemId, num3, out inc2);
							num4 += num8;
							num5 += inc2;
							num3 -= num8;
							if (num4 >= num3)
							{
								break;
							}
						}
					}
					if (num4 >= num3)
					{
						break;
					}
				}
				player.packageUtility.AddItemToAllPackages(itemId, num4, i, num5, out remainInc, num);
			}
			if (gRID.recycleCount >= num2)
			{
				continue;
			}
			int count3 = num2 - gRID.recycleCount;
			player.packageUtility.TakeItemFromAllPackages(i, ref itemId, ref count3, out var inc3, deliveryFirst: true);
			if (itemId == 0 || count3 == 0)
			{
				continue;
			}
			for (int m = 0; m < GameMain.data.factoryCount; m++)
			{
				PlanetFactory planetFactory2 = GameMain.data.factories[m];
				if (MechalogisticsPlanet_bool.Value && !planetFactory2.planet.displayName.Equals("机甲物流"))
				{
					continue;
				}
				if (MechalogStationrecycle_bool.Value && planetFactory2.transport?.stationPool != null)
				{
					StationComponent[] stationPool = planetFactory2.transport.stationPool;
					foreach (StationComponent stationComponent2 in stationPool)
					{
						if (stationComponent2 == null || stationComponent2.storage == null)
						{
							continue;
						}
						for (int n = 0; n < stationComponent2.storage.Length; n++)
						{
							if (stationComponent2.storage[n].itemId == itemId)
							{
								int num9 = stationComponent2.storage[n].max - stationComponent2.storage[n].count;
								int num10 = SplitIncUtil.split_inc(ref count3, ref inc3, num9);
								stationComponent2.storage[n].count = stationComponent2.storage[n].count + num9;
								stationComponent2.storage[n].inc = stationComponent2.storage[n].inc + num10;
							}
						}
						if (count3 == 0)
						{
							break;
						}
					}
				}
				if (planetFactory2.transport != null && planetFactory2.transport.stationPool != null && MechalogStationrecycle_bool.Value && count3 == 0)
				{
					break;
				}
				if (!MechalogStoragerecycle_bool.Value || planetFactory2.factoryStorage == null)
				{
					continue;
				}
				if (count3 > 0 && planetFactory2.factoryStorage.tankPool != null)
				{
					TankComponent[] tankPool2 = planetFactory2.factoryStorage.tankPool;
					for (int num11 = 0; num11 < tankPool2.Length; num11++)
					{
						TankComponent tankComponent2 = tankPool2[num11];
						if (tankComponent2.id > 0 && tankComponent2.fluidId > 0 && tankComponent2.fluidCount > 0 && itemId == tankComponent2.fluidId)
						{
							if (tankComponent2.fluidCount > 10000)
							{
								planetFactory2.factoryStorage.tankPool[tankComponent2.id].fluidCount += count3;
								planetFactory2.factoryStorage.tankPool[tankComponent2.id].fluidInc += inc3;
								count3 = 0;
							}
							else
							{
								int num12 = ((tankComponent2.fluidCapacity - tankComponent2.fluidCount > count3) ? count3 : (tankComponent2.fluidCapacity - tankComponent2.fluidCount));
								int num13 = SplitIncUtil.split_inc(ref count3, ref inc3, num12);
								planetFactory2.factoryStorage.tankPool[tankComponent2.id].fluidCount += num12;
								planetFactory2.factoryStorage.tankPool[tankComponent2.id].fluidInc += num13;
							}
							if (count3 == 0)
							{
								break;
							}
						}
					}
				}
				if (count3 <= 0 || planetFactory2.factoryStorage.storagePool == null)
				{
					continue;
				}
				StorageComponent[] storagePool = planetFactory2.factoryStorage.storagePool;
				foreach (StorageComponent storageComponent2 in storagePool)
				{
					if (storageComponent2 != null)
					{
						count3 -= storageComponent2.AddItem(itemId, count3, inc3, out var remainInc2);
						inc3 -= remainInc2;
						if (count3 == 0)
						{
							break;
						}
					}
				}
			}
			player.packageUtility.AddItemToAllPackages(itemId, count3, i, inc3, out remainInc);
		}
	}

	public void InitBeltSignalDiction()
	{
		if (GameMain.galaxy == null || GameMain.galaxy.stars == null)
		{
			return;
		}
		StarData[] stars = GameMain.galaxy.stars;
		for (int i = 0; i < stars.Length; i++)
		{
			PlanetData[] planets = stars[i].planets;
			foreach (PlanetData planetData in planets)
			{
				if (planetData == null || planetData.factory == null || planetData.factory.entitySignPool == null)
				{
					continue;
				}
				EntityData[] entityPool = planetData.factory.entityPool;
				for (int k = 0; k < entityPool.Length; k++)
				{
					EntityData entityData = entityPool[k];
					if (entityData.id > 0 && entityData.beltId != 0 && planetData.factory.entitySignPool[entityData.id].iconId0 != 0)
					{
						int iconId = (int)planetData.factory.entitySignPool[entityData.id].iconId0;
						int beltId = entityData.beltId;
						if (!Beltsignal.ContainsKey(planetData.factoryIndex))
						{
							Beltsignal.Add(planetData.factoryIndex, new Dictionary<int, int>());
						}
						if (!Beltsignal[planetData.factoryIndex].ContainsKey(beltId))
						{
							Beltsignal[planetData.factoryIndex].Add(beltId, iconId);
						}
						else
						{
							Beltsignal[planetData.factoryIndex][beltId] = iconId;
						}
						if (!Beltsignalnumberoutput.ContainsKey(planetData.factoryIndex))
						{
							Beltsignalnumberoutput.Add(planetData.factoryIndex, new Dictionary<int, int>());
						}
						if (!Beltsignalnumberoutput[planetData.factoryIndex].ContainsKey(beltId) && planetData.factory.entitySignPool[entityData.id].iconId0 == 601 && planetData.factory.entitySignPool[entityData.id].count0 > 0f)
						{
							Beltsignalnumberoutput[planetData.factoryIndex].Add(beltId, (int)planetData.factory.entitySignPool[entityData.id].count0);
						}
					}
				}
			}
		}
	}

	private void InitQuantumTransport()
	{
		StationComponent[] stationPool = GameMain.data.galacticTransport.stationPool;
		foreach (StationComponent stationComponent in stationPool)
		{
			if (stationComponent != null && stationComponent.isCollector)
			{
				CollectorStation.Add(stationComponent.gid);
			}
		}
	}

	public static void AddComsumeItemtoTotal(int itemid, int count)
	{
		List<int> list = new List<int>();
		List<long> list2 = new List<long>();
		list.Add(itemid);
		list2.Add(count);
		int num = 0;
		while (num < list.Count)
		{
			ItemProto itemProto = LDB.items.Select(list[num]);
			if (itemProto.recipes == null || itemProto.recipes.Count == 0 || list[num] == 1003)
			{
				num++;
				continue;
			}
			for (int i = 0; i < itemProto.recipes[0].Items.Length; i++)
			{
				list.Add(itemProto.recipes[0].Items[i]);
				list2.Add(itemProto.recipes[0].ItemCounts[i] * list2[num]);
			}
			num++;
		}
		for (int num2 = list.Count - 1; num2 >= 0; num2--)
		{
			try
			{
				if (itemid == 1503 && list[num2] == 1501)
				{
					list2[num2] *= 12L;
				}
				if (itemid == 1503 && list[num2] == 1404)
				{
					list2[num2] *= 12L;
				}
				while (list2[num2] > 0)
				{
					int num3 = (int)((list2[num2] > int.MaxValue) ? int.MaxValue : list2[num2]);
					GameMain.data.statistics.production.factoryStatPool[GameMain.localPlanet.factory.index].AddProductionToTotalArray(list[num2], num3);
					GameMain.data.statistics.production.factoryStatPool[GameMain.localPlanet.factory.index].AddConsumptionToTotalArray(list[num2], num3);
					list2[num2] -= num3;
				}
			}
			catch
			{
			}
		}
	}

	public void PlayerDataInit()
	{
		if (refreshPlayerData || player == null || GameMain.mainPlayer != player)
		{
			refreshPlayerData = false;
			player = GameMain.mainPlayer;
			propertyData = new PropertyData();
			propertyData.SetContent(player.mecha, GameMain.history, player.deliveryPackage.stackSizeMultiplier);
			if (Mechalogistics_bool.Value && !player.deliveryPackage.unlocked)
			{
				player.deliveryPackage.unlocked = true;
				player.deliveryPackage.colCount = 1;
				player.deliveryPackage.NotifySizeChange();
			}
		}
	}

	public void BluePrintpasteNoneed()
	{
		if (!blueprintpastenoneed_bool.Value)
		{
			return;
		}
		PlanetFactory planetFactory = GameMain.localPlanet?.factory;
		if (planetFactory == null)
		{
			return;
		}
		for (int i = 1; i < planetFactory.prebuildCursor; i++)
		{
			if (planetFactory.prebuildPool[i].protoId > 0)
			{
				planetFactory.prebuildPool[i].itemRequired = 0;
			}
		}
	}

	public void FinishDysonShell()
	{
		DysonSphere[] dysonSpheres = GameMain.data.dysonSpheres;
		foreach (DysonSphere dysonSphere in dysonSpheres)
		{
			if (dysonSphere == null || dysonSphere.starData != GameMain.localStar)
			{
				continue;
			}
			int num = 0;
			DysonSphereLayer[] layersIdBased = dysonSphere.layersIdBased;
			foreach (DysonSphereLayer dysonSphereLayer in layersIdBased)
			{
				if (dysonSphereLayer == null)
				{
					continue;
				}
				DysonNode[] nodePool = dysonSphereLayer.nodePool;
				foreach (DysonNode dysonNode in nodePool)
				{
					if (dysonNode == null)
					{
						continue;
					}
					if (dysonNode.totalSp < dysonNode.totalSpMax)
					{
						num += dysonNode.totalSpMax - dysonNode.totalSp;
						dysonNode.sp = 30;
						for (int l = 0; l < dysonNode.frames.Count; l++)
						{
							if (dysonNode.frames[l].nodeA == dysonNode)
							{
								dysonNode.frames[l].spA = dysonNode.frames[l].spMax / 2;
							}
							else if (dysonNode.frames[l].nodeB == dysonNode)
							{
								dysonNode.frames[l].spB = dysonNode.frames[l].spMax / 2;
							}
						}
					}
					if (dysonNode.totalCp < dysonNode.totalCpMax)
					{
						_ = dysonNode.totalCpMax;
						_ = dysonNode.totalCp;
						for (int m = 0; m < dysonNode.shells.Count; m++)
						{
							DysonShell dysonShell = dysonNode.shells[m];
							int num2 = dysonShell.nodeIndexMap[dysonNode.id];
							dysonShell.nodecps[num2] += (dysonShell.vertsqOffset[num2 + 1] - dysonShell.vertsqOffset[num2]) * dysonShell.cpPerVertex;
							dysonShell.nodecps[dysonShell.nodecps.Length - 1] += (dysonShell.vertsqOffset[num2 + 1] - dysonShell.vertsqOffset[num2]) * dysonShell.cpPerVertex;
						}
					}
				}
			}
			dysonSphere.modelRenderer.RebuildModels();
		}
	}

	public void RemoveAllBuild(int type)
	{
		if (GameMain.localPlanet == null || GameMain.localPlanet.factory == null)
		{
			return;
		}
		if (type == 1)
		{
			entityitemnoneed = true;
		}
		EntityData[] entityPool = GameMain.localPlanet.factory.entityPool;
		for (int i = 0; i < entityPool.Length; i++)
		{
			EntityData entityData = entityPool[i];
			int stationId = entityData.stationId;
			if (stationId > 0)
			{
				StationComponent stationComponent = GameMain.localPlanet.factory.transport.stationPool[stationId];
				for (int j = 0; j < stationComponent.storage.Length; j++)
				{
					if (type != 0)
					{
						break;
					}
					int upCount = player.TryAddItemToPackage(stationComponent.storage[j].itemId, stationComponent.storage[j].count, 0, throwTrash: true, entityData.id);
					UIItemup.Up(stationComponent.storage[j].itemId, upCount);
				}
				stationComponent.storage = new StationStore[stationComponent.storage.Length];
				stationComponent.needs = new int[stationComponent.needs.Length];
			}
			if (type == 1)
			{
				GameMain.localPlanet.factory.RemoveEntityWithComponents(entityData.id, returnItems: false);
			}
			else
			{
				player.controller.actionBuild.DoDismantleObject(entityData.id);
			}
		}
		entityitemnoneed = false;
	}

	public void OnSetBase()
	{
		PlanetData localPlanet = GameMain.localPlanet;
		if (localPlanet != null && localPlanet.type != EPlanetType.Gas)
		{
			PlanetFactory factory = localPlanet.factory;
			if (restorewater)
			{
				factory.PlanetReformRevert();
				return;
			}
			BuildTool_Reform reformTool = player.controller.actionBuild.reformTool;
			factory.PlanetReformAll(reformTool.brushType, reformTool.brushColor, reformTool.buryVeins);
		}
	}

	public void Clearpackage()
	{
		if (player == null)
		{
			return;
		}
		for (int i = 0; i < player.package.grids.Length; i++)
		{
			player.package.grids[i].count = 0;
			if (player.package.grids[i].filter == 0)
			{
				player.package.grids[i].itemId = 0;
				player.package.grids[i].stackSize = 0;
			}
		}
		player.package.NotifyStorageChange();
	}

	public void Operatepackagesize(int rownum, int colnum, bool add = true)
	{
		ResizePackage(player, rownum, colnum, add);
	}

	public void UnlockallTech(bool addstat = false)
	{
		if (player == null)
		{
			return;
		}
		bool flag = true;
		while (flag)
		{
			flag = false;
			foreach (TechProto item in new List<TechProto>(LDB.techs.dataArray))
			{
				if (GameMain.data.history.TechUnlocked(item.ID) || item.IsObsolete || !GameMain.data.history.CanEnqueueTech(item.ID) || item.MaxLevel > 15)
				{
					continue;
				}
				flag = true;
				if (item.Level < item.MaxLevel)
				{
					for (int i = item.Level; i < item.MaxLevel; i++)
					{
						if (addstat)
						{
							for (int j = 0; j < item.itemArray.Length; j++)
							{
								AddComsumeItemtoTotal(item.Items[j], (int)(item.ItemPoints[j] * item.GetHashNeeded(item.Level) / 3600));
							}
						}
						for (int k = 0; k < item.UnlockFunctions.Length; k++)
						{
							_ = item.UnlockFunctions[k];
							_ = 7;
							GameMain.history.UnlockTechFunction(item.UnlockFunctions[k], item.UnlockValues[k], i);
						}
					}
				}
				if (GameMain.history.techStates[item.ID].unlocked)
				{
					continue;
				}
				if (addstat)
				{
					for (int l = 0; l < item.itemArray.Length; l++)
					{
						AddComsumeItemtoTotal(item.Items[l], (int)(item.ItemPoints[l] * item.GetHashNeeded(item.Level) / 3600));
					}
				}
				for (int m = 0; m < item.UnlockFunctions.Length; m++)
				{
					_ = item.UnlockFunctions[m];
					_ = 7;
				}
				GameMain.history.UnlockTech(item.ID);
			}
		}
	}

	public void lockTech()
	{
		TechProto[] dataArray = LDB.techs.dataArray;
		foreach (TechProto techProto in dataArray)
		{
			if (techProto.MaxLevel > 30 && techProto.Level != techProto.MaxLevel)
			{
				TechState value = GameMain.history.techStates[techProto.ID];
				value.unlocked = false;
				value.curLevel = techProto.Level;
				value.hashUploaded = 0L;
				value.hashNeeded = techProto.GetHashNeeded(value.curLevel);
				GameMain.history.techStates[techProto.ID] = value;
			}
		}
	}

	public void InfiniteFilterThingInPackage()
	{
		if (GameMain.mainPlayer == null)
		{
			return;
		}
		StorageComponent.GRID[] grids = GameMain.mainPlayer.package.grids;
		bool flag = false;
		for (int i = 0; i < grids.Length; i++)
		{
			if (grids[i].itemId > 0 && grids[i].filter > 0 && grids[i].count != grids[i].stackSize)
			{
				flag = true;
				grids[i].count = grids[i].stackSize;
			}
		}
		if (flag)
		{
			GameMain.mainPlayer.package.NotifyStorageChange();
		}
	}

	public void InfiniteAllThingInPackage()
	{
		if (GameMain.mainPlayer == null)
		{
			return;
		}
		StorageComponent.GRID[] grids = GameMain.mainPlayer.package.grids;
		if (grids.Length < LDB.items.dataArray.Length)
		{
			GameMain.mainPlayer.package.SetSize((LDB.items.dataArray.Length / player.packageColCount + 1) * player.packageColCount);
		}
		int num = 0;
		bool flag = false;
		ItemProto[] dataArray = LDB.items.dataArray;
		foreach (ItemProto itemProto in dataArray)
		{
			if (itemProto.ID != 1099)
			{
				if (grids[num].itemId != itemProto.ID || grids[num].count != StorageComponent.itemStackCount[itemProto.ID] || grids[num].stackSize != StorageComponent.itemStackCount[itemProto.ID])
				{
					flag = true;
					grids[num].itemId = itemProto.ID;
					grids[num].stackSize = StorageComponent.itemStackCount[itemProto.ID];
					grids[num].count = StorageComponent.itemStackCount[itemProto.ID];
				}
				num++;
				if (num == grids.Length)
				{
					break;
				}
			}
		}
		if (flag)
		{
			GameMain.mainPlayer.package.NotifyStorageChange();
		}
	}

	public void SetDronenocomsume()
	{
		if (player.mecha != null)
		{
			if (DroneNoenergy_bool.Value && player.mecha.droneEjectEnergy != 0.0)
			{
				player.mecha.droneEjectEnergy = 0.0;
				player.mecha.droneEnergyPerMeter = 0.0;
			}
			if (!DroneNoenergy_bool.Value && player.mecha.droneEjectEnergy == 0.0)
			{
				player.mecha.droneEjectEnergy = 300000.0;
				player.mecha.droneEnergyPerMeter = 60000.0;
			}
		}
	}

	public void ChangeRecipe()
	{
		ApplyRecipeSettings(ref handcraftOriginals, allhandcraft.Value, quickproduce.Value);
		RebuildHandcraftCache();
	}

	public void SetmultipleItemStatck(int multiple)
	{
		int num = LDB.items.dataArray.Length;
		for (int i = 0; i < num; i++)
		{
			ItemProto itemProto = LDB.items.dataArray[i];
			StorageComponent.itemStackCount[itemProto.ID] = itemProto.StackSize * multiple;
		}
		StackMultiple.Value = multiple;
	}

	public void ChangeItemstack()
	{
	}

	private void InitWaterTypes()
	{
		string[] array = Multifunction.seedPlanetWater.Value.Split(new char[1] { '|' });
		foreach (string text in array)
		{
			if (string.IsNullOrEmpty(text))
			{
				continue;
			}
			SeedPlanetWater seedPlanetWater = new SeedPlanetWater();
			string[] array2 = text.Split(new char[1] { ',' });
			if (array2[0] == "0")
			{
				continue;
			}
			if (array2[1].Length > 0)
			{
				seedPlanetWater.seedKey64 = Convert.ToInt64(array2[0]);
				string[] array3 = array2[1].Split(new char[1] { '-' });
				foreach (string text2 in array3)
				{
					if (!string.IsNullOrEmpty(text2))
					{
						string[] array4 = text2.Split(new char[1] { ':' });
						seedPlanetWater.waterTypes.Add(Convert.ToInt32(array4[0]), Convert.ToInt32(array4[1]));
					}
				}
			}
			if (seedPlanetWater.seedKey64 != 0L)
			{
				seedPlanetWaterTypes.Add(seedPlanetWater.seedKey64, seedPlanetWater);
			}
		}
	}

	public void SetWaterType()
	{
		if (GameMain.localPlanet == null)
		{
			return;
		}
		ItemProto itemProto = LDB.items.dataArray.ToList().Find((ItemProto x) => x.name == currentPlanetWaterType);
		if (itemProto == null)
		{
			UIMessageBox.Show("", "设置海洋类型失败".getTranslate(), "确定".Translate(), 3);
		}
		else
		{
			if (GameMain.localPlanet.waterItemId == itemProto.ID)
			{
				return;
			}
			GameMain.localPlanet.waterItemId = itemProto.ID;
			int id = GameMain.localPlanet.id;
			int num = originWaterTypes.waterTypes[id];
			if (num == itemProto.ID && currentWaterTypes.waterTypes.ContainsKey(id))
			{
				currentWaterTypes.waterTypes.Remove(id);
			}
			else if (num != itemProto.ID)
			{
				if (!currentWaterTypes.waterTypes.ContainsKey(id))
				{
					currentWaterTypes.waterTypes.Add(id, itemProto.ID);
				}
				else
				{
					currentWaterTypes.waterTypes[id] = itemProto.ID;
				}
			}
			string text = "";
			foreach (KeyValuePair<long, SeedPlanetWater> seedPlanetWaterType in seedPlanetWaterTypes)
			{
				if (seedPlanetWaterType.Value.seedKey64 != 0L && seedPlanetWaterType.Value.waterTypes.Count != 0)
				{
					text = text + seedPlanetWaterType.Value.ToStr() + "|";
				}
			}
			seedPlanetWater.Value = text;
		}
	}

	public void RestoreWaterType()
	{
		string text = "";
		foreach (KeyValuePair<int, int> waterType in currentWaterTypes.waterTypes)
		{
			if (originWaterTypes.waterTypes.ContainsKey(waterType.Key))
			{
				GameMain.galaxy.PlanetById(waterType.Key).waterItemId = originWaterTypes.waterTypes[waterType.Key];
				if (GameMain.localPlanet.id == waterType.Key)
				{
					currentPlanetWaterType = LDB.items.Select(originWaterTypes.waterTypes[waterType.Key])?.name ?? "无海洋".getTranslate();
				}
			}
		}
		currentWaterTypes.waterTypes.Clear();
		foreach (KeyValuePair<long, SeedPlanetWater> seedPlanetWaterType in seedPlanetWaterTypes)
		{
			if (seedPlanetWaterType.Value.seedKey64 != 0L && seedPlanetWaterType.Value.waterTypes.Count != 0)
			{
				text = text + seedPlanetWaterType.Value.ToStr() + "|";
			}
		}
		seedPlanetWater.Value = text;
	}

	public void setQuickKey()
	{
		bool flag = true;
		int[] array = new int[2];
		if (Input.GetKey(KeyCode.LeftShift) && flag)
		{
			flag = false;
			array[0] = 304;
		}
		if (Input.GetKey(KeyCode.LeftControl) && flag)
		{
			flag = false;
			array[0] = 306;
		}
		if (Input.GetKey(KeyCode.LeftAlt) && flag)
		{
			flag = false;
			array[0] = 308;
		}
		bool flag2 = true;
		for (int i = 48; i <= 57 && flag2; i++)
		{
			if (Input.GetKey((KeyCode)i))
			{
				array[1] = i;
				flag2 = false;
				break;
			}
		}
		for (int j = 97; j <= 122 && flag2; j++)
		{
			if (Input.GetKey((KeyCode)j))
			{
				array[1] = j;
				flag2 = false;
				break;
			}
		}
		for (int k = 282; k <= 291 && flag2; k++)
		{
			if (Input.GetKey((KeyCode)k))
			{
				array[1] = k;
				flag2 = false;
				break;
			}
		}
		switch ((!(flag && flag2)) ? ((flag || flag2) ? 1 : 2) : 0)
		{
		case 2:
			tempShowWindow = new KeyboardShortcut((KeyCode)array[1], (KeyCode)array[0]);
			break;
		case 1:
		{
			int mainKey = Math.Max(array[0], array[1]);
			tempShowWindow = new KeyboardShortcut((KeyCode)mainKey);
			break;
		}
		}
	}

	private static void RebuildHandcraftCache()
	{
		ItemProto[] dataArray = LDB.items.dataArray;
		foreach (ItemProto itemProto in dataArray)
		{
			RecipeProto handcraft = itemProto.handcraft;
			if (itemProto.handcrafts == null)
			{
				itemProto.handcrafts = new List<RecipeProto>();
			}
			else
			{
				itemProto.handcrafts.Clear();
			}
			itemProto.handcraft = null;
			itemProto.handcraftProductCount = 0;
			int num = int.MaxValue;
			RecipeProto[] dataArray2 = LDB.recipes.dataArray;
			foreach (RecipeProto recipeProto in dataArray2)
			{
				if (!recipeProto.Handcraft)
				{
					continue;
				}
				int num2 = Array.IndexOf(recipeProto.Results, itemProto.ID);
				if (num2 >= 0)
				{
					itemProto.handcrafts.Add(recipeProto);
					if (num2 < num)
					{
						itemProto.handcraft = recipeProto;
						itemProto.handcraftProductCount = recipeProto.ResultCounts[num2];
						num = num2;
					}
				}
			}
			if (handcraft != null && itemProto.handcrafts.Contains(handcraft))
			{
				itemProto.handcraft = handcraft;
				itemProto.handcraftProductCount = handcraft.ResultCounts[Array.IndexOf(handcraft.Results, itemProto.ID)];
			}
		}
		UIReplicatorWindow uIReplicatorWindow = UIRoot.instance?.uiGame?.replicator;
		if (uIReplicatorWindow != null && uIReplicatorWindow.active)
		{
			uIReplicatorWindow.OnTechUnlocked(0, 0, arg2: false);
			uIReplicatorWindow.OnSelectedRecipeChange(changed: false);
		}
	}

	private static void ApplyRecipeSettings(ref Dictionary<RecipeProto, RecipeProto> originals, bool all, bool quick)
	{
		if (originals == null)
		{
			originals = new Dictionary<RecipeProto, RecipeProto>();
		}
		RecipeProto[] dataArray = LDB.recipes.dataArray;
		foreach (RecipeProto recipeProto in dataArray)
		{
			if (!originals.TryGetValue(recipeProto, out var value))
			{
				value = new RecipeProto
				{
					Handcraft = recipeProto.Handcraft,
					TimeSpend = recipeProto.TimeSpend
				};
				originals.Add(recipeProto, value);
			}
			recipeProto.Handcraft = all || value.Handcraft;
			recipeProto.TimeSpend = (quick ? 10 : value.TimeSpend);
		}
	}
}
