using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace Multifunction_mod.Patchs;

public class PlanetFactoryPatch
{
	private static void RemoveVegeAndCollect(PlanetFactory factory, int id)
	{
		int num = ((id > 0 && id < factory.vegePool.Length && factory.vegePool[id].id == id) ? factory.vegePool[id].protoId : 0);
		VegetableCollection vegetableCollection = factory.gameData.mainPlayer?.vegetableCollection;
		int value = 0;
		vegetableCollection?.playerVegeDict.TryGetValue(num, out value);
		factory.RemoveVegeWithComponents(id);
		int value2 = 0;
		vegetableCollection?.playerVegeDict.TryGetValue(num, out value2);
		if (num > 0 && vegetableCollection != null && factory.vegePool[id].id == 0 && value == value2)
		{
			vegetableCollection.AddVegeToPlayer(num);
		}
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(PlanetFactory), "PlanetReformAll")]
	private static IEnumerable<CodeInstruction> BulkReformCollection(IEnumerable<CodeInstruction> instructions)
	{
		List<CodeInstruction> list = new List<CodeInstruction>(instructions);
		MethodInfo method = AccessTools.Method(typeof(PlanetFactory), "RemoveVegeWithComponents");
		int num = 0;
		foreach (CodeInstruction item in list)
		{
			if (item.Calls(method))
			{
				item.opcode = OpCodes.Call;
				item.operand = AccessTools.Method(typeof(PlanetFactoryPatch), "RemoveVegeAndCollect");
				num++;
			}
		}
		if (num != 1)
		{
			throw new InvalidOperationException("Native bulk vegetation removal changed: " + num);
		}
		return list;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetFactory), "ComputeFlattenTerrainReform")]
	public static void PlanetFactoryNoComsumeSand(ref int costSandCount)
	{
		if (Multifunction.InfiniteSand.Value)
		{
			if (GameMain.mainPlayer != null && GameMain.mainPlayer.sandCount < int.MaxValue)
			{
				GameMain.mainPlayer.SetSandCount(2147483647L, ESandSource.Other);
			}
			costSandCount = 0;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetFactory), "UpgradeEntityWithComponents")]
	public static void UpgradeEntityWithComponentsPatch(int entityId, PlanetFactory __instance)
	{
		if (Multifunction.Buildingnoconsume.Value && entityId != 0 && __instance.entityPool[entityId].id != 0 && GameMain.localPlanet.factory.entityPool[entityId].stationId <= 0)
		{
			int powerConId = __instance.entityPool[entityId].powerConId;
			if (powerConId > 0)
			{
				__instance.powerSystem.consumerPool[powerConId].idleEnergyPerTick = 0L;
				__instance.powerSystem.consumerPool[powerConId].workEnergyPerTick = 0L;
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlanetFactory), "TakeBackItemsInEntity")]
	public static bool TakeBackItemsInEntityPatch()
	{
		return !Multifunction.entityitemnoneed;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlanetFactory), "CreateEntityLogicComponents")]
	public static void CreateEntityLogicComponentsPatch(PlanetFactory __instance, int entityId, PrefabDesc desc, int prebuildId)
	{
		if (desc.isStation && !string.IsNullOrEmpty(Multifunction.AutoChangeStationName.Value))
		{
			__instance.WriteExtraInfoOnPrebuild(prebuildId, Multifunction.AutoChangeStationName.Value.getTranslate());
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(ConstructionSystem), "GameTick")]
	public static void ConstructionSystemGameTick(ConstructionSystem __instance)
	{
		if (!Multifunction.BuildNotime_bool.Value)
		{
			return;
		}
		PlanetFactory planetFactory = Multifunction.player?.factory;
		if (GameMain.localPlanet == null || planetFactory == null)
		{
			return;
		}
		PrebuildData[] prebuildPool = planetFactory.prebuildPool;
		if (planetFactory.prebuildCount <= 0)
		{
			return;
		}
		int num = 0;
		PlanetFactory.batchBuild = true;
		new HighStopwatch().Begin();
		planetFactory.BeginFlattenTerrain();
		for (int num2 = planetFactory.prebuildCursor - 1; num2 > 0; num2--)
		{
			if ((prebuildPool[num2].itemRequired <= 0 || Multifunction.Infinitething.Value || Multifunction.ArchitectMode.Value) && prebuildPool[num2].id == num2 && !prebuildPool[num2].isDestroyed)
			{
				planetFactory.BuildFinally(GameMain.mainPlayer, prebuildPool[num2].id, autoRefresh: false);
				num++;
			}
		}
		planetFactory.EndFlattenTerrain();
		PlanetFactory.batchBuild = false;
		if (num > 0)
		{
			GameMain.localPlanet.physics?.raycastLogic?.NotifyBatchObjectRemove();
			GameMain.localPlanet.audio?.SetPlanetAudioDirty();
		}
	}
}
