# blacksnipebiu-Multfuntion_mod

Preserve inventory contents and native vegetation collection; rebuild handcraft links and apply settings across late/reordered recipe prototypes and world/UI reloads.

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.

[Review map](REVIEW_GUIDE.md) · [Receiving package relationship index](../../RELATED_MODS.md) · [Detailed changes](CHANGELOG.md) · [Build/review notes](BUILD.md) · [Assembly metadata](metadata.json)

Prepared for maintainer review on 15 October 2026. This is a local modified build, not an official upstream release, published package or pull request.

Installed plugin version(s): **4.0.7**. Existing package manifest version: **4.0.6**. Manifest, plugin and assembly versions are separate; the original manifest is retained.

## Package layout

- `InstalledPackage/`: actual installed mod files and companion preloader when present.
- `Source/Reconstructed/`: full projects reconstructed from the exact installed assemblies.
- `Source/EarlierWorkingSource/`, `PortedWorkingSource/`, `UpstreamSnapshot/`: source snapshots when available; provenance is recorded separately.
- `Evidence/`: development helpers, focused check sources and structured validation/installation records.
- `Diffs/`: source-port patches and normalized structural IL comparison.
- `Baselines/`: previous binary and its provenance for review, not an automatic rollback.

## Plugin identifiers and declared dependencies

- `cn.blacksnipe.dsp.Multfuntion_mod` — Multfuntion_mod 4.0.7; dependencies: none declared on this plugin.

## Installed assembly hashes

| Recorded path | SHA-256 |
|---|---|
| `plugins/blacksnipebiu-Multfuntion_mod/Multifunction_mod.dll` | `3f25164c5740a96cb137e58cc38422c716e33715129727ef123a8de87b3a274a` |

## Scope and limitations

Not every source project has been rebuilt. Historical compile/test evidence is limited to its recorded hashes. Headless/embedded-Mono checks do not establish real Unity UI, the user's world, all-mod startup, multiplayer or sustained-memory acceptance.
