# blacksnipebiu-Multfuntion_mod — detailed change report

Installed plugin version(s): **4.0.7**. Preserve inventory contents and native vegetation collection; rebuild handcraft links and apply settings across late/reordered recipe prototypes and world/UI reloads.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Inventory and native vegetation — 4.0.6, carried into 4.0.7

The older installed package labeled 4.0.5 actually contained plugin 4.0.4; public GitHub 4.0.2 was not substituted. Retain the installed contract and assembly identity 1.0.0.0.

- Reject inventory shrinking if any removed cell contains an item or filter. Remap every grid field when changing rows/columns, preserving count/inc/filter and native notifications rather than overflowing the old column-shrink loop or discarding stock.
- Bridge native bulk `PlanetReformAll` vegetation removal to native collection only after successful removal. Do not count twice if another patch already collected it.
- Use native bulk restoration when restore mode is selected; do not convert vegetation-planting mode to bulk foundation.
- The 15 October 4.0.7 port retains current `PlanetReformRevert` and other upstream options while carrying these fixes forward.

## First All hand craft correction — 15 October

Changing only `RecipeProto.Handcraft` and `TimeSpend` left the game's item-level crafting cache stale. Native recursive crafting also uses `ItemProto.handcraft`, `handcrafts` and `handcraftProductCount`.

Rebuild these links after recipe changes for all loaded handcraft-enabled recipes and every output, including co-products and alternatives, without a recipe-class or fixed-ID limit. Preserve an existing valid default route: preferring the newly enabled primary salt output from recipe 704 can introduce a salt → chlorine → salt cycle; the established desalination route 801 avoids it. Do not change `isRaw`, `maincraft`, factory recipe execution data, ingredient/output quantities or research locks. Refresh recipe icons if the panel is open.

The actual 229 Genesis definitions reproduced 118 missing product links in the original DLL; a water → oxygen → consumer chain failed even when recipe 702's flag was true. The first fix restored those links but did not address the separate refresh problems below.

## Complete recipe application and lifecycle refresh — final installed correction

The old `ChangeRecipe` traversed only the shorter of the current array and the one-time `originRecipeProtos` snapshot, matching by position. Late recipes could be omitted, and reordered arrays could restore another recipe's defaults. `LDBInitSave` also prevented normal reapplication after the initial load, with no refresh requested on world begin or replicator reopening.

- Traverse every current recipe. Store its original Handcraft/time values by prototype-object identity, independent of the old snapshot's length or order.
- Give appended recipes and replacement objects with the same ID their own baseline. Restore their own values when options are disabled.
- Extend the existing world-begin and replicator-open hooks to request `refreshLDB`. Existing `AfterGameStart` consumes that request; the entire database is not scanned every frame.
- Retain the first cache/alternative/co-product correction and default-route protection.
- Refresh the selected recipe's tree/time display as well as icons.

The previous installed DLL reproduced a short-baseline case with 3 water in inventory and both settings enabled: recipe 702 remained `Handcraft=false`, at 240 ticks/4 seconds, failing native UI's `Handcraft && PredictTaskCount > 0` gate. This matches the reported symptom; the live session's array length and inventory IDs were not directly measured.

Fresh water 1000 and seawater 7018 are distinct items. Desalination recipe 801 must be researched to use seawater as fresh water. All-handcraft enables crafting routes; it does not waive research or create missing raw materials.

## Validation, installed identity and limits

- 235 assertions cover the short snapshot, native prediction for recipe 702, reordering, appended/replacement prototypes, correct restoration and both refresh hooks.
- 4,614 assertions cover all 229 actual Genesis recipes, native input reservation, two production cycles, every co-product, queue completion, duplicate-free repeated toggles, quick-time restoration, graph acyclicity and seawater → water/salt → hydrogen/oxygen → consumer. Research/raw-material failures remain enforced.
- Inventory cargo/filter/inc and native bulk-vegetation bridge regressions passed.
- Relative to the preceding cache-fixed DLL, 406 methods remain unchanged. ChangeRecipe, its private cache helper and two existing hooks changed; their original hook behavior remains. One private field and method were added, with no runtime helper DLL. Panel resource, plugin GUID/version and assembly identity are retained.

Installed SHA-256: `3f25164c5740a96cb137e58cc38422c716e33715129727ef123a8de87b3a274a`. Preceding stages were `9ed0c79bce53aed7e237f7aaa3cdde10ed5260de637cd028a6f75bde45cefbb8` and pre-cache `3afd0a48bb66854c93f144624ddfdc3f27f9e79466e365156e1e9abe056ab756`. Rollback ZIP paths are relative to plugins. Only this target changed among 148 protected DLLs during the final installation.

Tests ran in embedded Mono with disposable Unity/LDB environment boundaries; native forge/storage/queue bodies were retained. Real UI, the user's save and all mods loaded together were not run. The screenshot's exact live failure cause is not claimed proven by the fixture. The latest fix supersedes the first cache-only report.

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
