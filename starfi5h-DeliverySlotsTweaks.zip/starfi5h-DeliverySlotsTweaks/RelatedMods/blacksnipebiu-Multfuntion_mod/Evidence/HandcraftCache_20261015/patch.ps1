param([string]$Original, [string]$Helper, [string]$Built, [string]$Core)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $Core 'Mono.Cecil.dll')
$assembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Original)
$helperAssembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Helper)
try {
    $module = $assembly.MainModule
    $type = $module.GetType('Multifunction_mod.Multifunction')
    $source = $helperAssembly.MainModule.GetType('HandcraftCache').Methods | Where-Object Name -eq 'RebuildHandcraftCache'
    $method = New-Object Mono.Cecil.MethodDefinition($source.Name, $source.Attributes, $module.ImportReference($source.ReturnType))
    $type.Methods.Add($method)
    $method.Body.InitLocals = $source.Body.InitLocals
    $method.Body.MaxStackSize = $source.Body.MaxStackSize
    $variables = @{}
    foreach ($variable in $source.Body.Variables) {
        $copy = New-Object Mono.Cecil.Cil.VariableDefinition($module.ImportReference($variable.VariableType))
        $method.Body.Variables.Add($copy); $variables[$variable] = $copy
    }
    $instructions = @{}
    foreach ($instruction in $source.Body.Instructions) {
        $copy = [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Nop)
        $copy.OpCode = $instruction.OpCode
        $method.Body.Instructions.Add($copy); $instructions[$instruction] = $copy
    }
    foreach ($instruction in $source.Body.Instructions) {
        $operand = $instruction.Operand
        if ($operand -is [Mono.Cecil.Cil.Instruction]) { $operand = $instructions[$operand] }
        elseif ($operand -is [Mono.Cecil.Cil.Instruction[]]) { $operand = [Mono.Cecil.Cil.Instruction[]]@($operand | ForEach-Object { $instructions[$_] }) }
        elseif ($operand -is [Mono.Cecil.Cil.VariableDefinition]) { $operand = $variables[$operand] }
        elseif ($operand -is [Mono.Cecil.TypeReference]) { $operand = $module.ImportReference($operand) }
        elseif ($operand -is [Mono.Cecil.MethodReference]) { $operand = $module.ImportReference($operand) }
        elseif ($operand -is [Mono.Cecil.FieldReference]) { $operand = $module.ImportReference($operand) }
        $instructions[$instruction].Operand = $operand
    }
    if ($source.Body.ExceptionHandlers.Count) { throw 'Unexpected helper exception handlers' }
    $refresh = $type.Methods | Where-Object Name -eq 'ChangeRecipe'
    $returns = @($refresh.Body.Instructions | Where-Object { $_.OpCode.Code -eq 'Ret' })
    if ($returns.Count -ne 1) { throw 'ChangeRecipe control flow changed' }
    $returns[0].OpCode = [Mono.Cecil.Cil.OpCodes]::Call
    $returns[0].Operand = $method
    $refresh.Body.GetILProcessor().Append([Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ret))
    $module.Mvid = [Guid]::NewGuid()
    $assembly.Write($Built)
    Write-Output 'PASS appended cache refresh to ChangeRecipe; all original settings/recipe logic retained'
} finally { $helperAssembly.Dispose(); $assembly.Dispose() }
