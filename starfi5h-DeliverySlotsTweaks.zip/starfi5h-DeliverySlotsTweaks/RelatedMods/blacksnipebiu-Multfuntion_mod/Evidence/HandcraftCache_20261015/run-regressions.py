"""Check the retained inventory fix and the independent Turkish plugin on the candidate."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('handcraft_build', HERE / 'build-and-patch.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
build, out = module.build, module.OUT
candidate = out / 'candidate/Multifunction_mod.dll'
contract = out.parent / 'game-update-audit/runtime-contract'
refs = [p for p in build.references() if p.name != 'Assembly-CSharp.dll']
refs += [out.parent / 'game-update-audit/compile-reference/Assembly-CSharp.dll', candidate]
inventory = out / 'inventory-check/Check.exe'
build.compile_cs([HERE.parent / '_compat_fixes_20261001/FAZ_29_Multfuntion_mod/check.cs'], inventory, refs, executable=True)
turkish = module.PLUGINS / 'BUG-MultifunctionModTurkceYama/BUG.MultifunctionModTurkish.dll'
tasks = [
    ('inventory', inventory, [candidate.parent, contract, build.GAME, build.CORE], dict(os.environ)),
    ('turkish', out.parent / 'turkish-patches/checks/Check.exe', [turkish.parent, candidate.parent, contract, build.GAME, build.CORE],
        dict(os.environ, PATCH_TARGET_PATH=str(candidate), PATCH_DLL_PATH=str(turkish))),
]
results = []
for name, check, directories, env in tasks:
    p = subprocess.run([sys.executable, str(HERE.parent / '_compat_fixes_20261001/mono-host.py'), str(check)] + list(map(str, directories)),
        env=env, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=60)
    log = p.stdout + p.stderr
    (HERE / (name + '-regression.log')).write_text(log, encoding='utf-8')
    results.append({'name': name, 'passed': p.returncode == 0, 'log': log})
    (HERE / 'regressions.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(name, p.returncode, '\n'.join(line for line in log.splitlines() if line.startswith('PASS ')), flush=True)
    assert p.returncode == 0, log[-3000:]
