"""Surgically extend the installed mod's recipe refresh, retaining all other code."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
PLUGINS = HERE.parent.parent
OUT = Path(r'C:\Users\BUG\.codex\visualizations\2026\10\15\01a13d1f-8009-7f92-a336-872d04e36b4b\handcraft-fix')
spec = importlib.util.spec_from_file_location('existing_build', HERE.parent / '_compat_fixes_20261001/build.py')
build = importlib.util.module_from_spec(spec)
spec.loader.exec_module(build)
ORIGINAL = PLUGINS / 'blacksnipebiu-Multfuntion_mod/Multifunction_mod.dll'

def ps(script, *args):
    env = dict(os.environ, PSModulePath=r'C:\Windows\System32\WindowsPowerShell\v1.0\Modules;C:\Program Files\WindowsPowerShell\Modules')
    p = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(script)] + list(map(str, args)), env=env,
        capture_output=True, text=True, encoding='utf-8', errors='replace')
    assert p.returncode == 0, p.stdout + p.stderr
    return p.stdout + p.stderr

if __name__ == '__main__':
    assert build.digest(ORIGINAL) == '3afd0a48bb66854c93f144624ddfdc3f27f9e79466e365156e1e9abe056ab756', 'Installed mod changed; review before patching'
    OUT.mkdir(parents=True, exist_ok=True)
    baseline = HERE / 'protected-before.json'
    if not baseline.exists():
        paths = [p for folder in PLUGINS.iterdir() if folder.is_dir() and folder.name != '_calisma' for p in folder.rglob('*.dll')]
        paths += list((PLUGINS.parent / 'patchers').rglob('*.dll')) + list(build.GAME.glob('*.dll'))
        baseline.write_text(json.dumps({str(p): build.digest(p) for p in paths}, indent=2), encoding='utf-8')
    helper = OUT / 'HandcraftHelper.dll'
    log = build.compile_cs([HERE / 'HandcraftCache.cs'], helper, build.references())
    candidate = OUT / 'candidate/Multifunction_mod.dll'
    candidate.parent.mkdir(parents=True, exist_ok=True)
    log += ps(HERE / 'patch.ps1', '-Original', ORIGINAL, '-Helper', helper, '-Built', candidate, '-Core', build.CORE)
    (HERE / 'build.log').write_text(log, encoding='utf-8')
    print(log, flush=True)
