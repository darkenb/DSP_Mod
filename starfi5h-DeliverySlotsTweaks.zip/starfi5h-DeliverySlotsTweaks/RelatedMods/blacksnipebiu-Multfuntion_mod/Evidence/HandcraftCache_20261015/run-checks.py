"""Reproduce the old failure and verify actual native forge execution after the fix."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('handcraft_build', HERE / 'build-and-patch.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
build, out, plugins = module.build, module.OUT, module.PLUGINS
data = json.loads((HERE / 'ProjectGenesis.data.recipes.json').read_text(encoding='utf-8-sig'))
assert len(data) == 229
def array(values):
    return 'new int[] {' + ','.join(map(str, values)) + '}'
fixture = ['static class Fixture { internal static RecipeProto[] Recipes() => new RecipeProto[] {']
for row in data:
    fixture.append('new RecipeProto { ID = ' + str(row['ID']) + ', Type = (ERecipeType)' + str(row['Type'])
        + ', Handcraft = ' + str(row['Handcraft']).lower() + ', TimeSpend = ' + str(row['Time'])
        + ', Items = ' + array(row['Input']) + ', ItemCounts = ' + array(row['InCounts'])
        + ', Results = ' + array(row['Output']) + ', ResultCounts = ' + array(row['OutCounts']) + ' },')
fixture.append('}; }')
fixture_file = out / 'Fixture.cs'
fixture_file.write_text('\n'.join(fixture), encoding='utf-8')
prepare_log = module.ps(HERE.parent / '_compat_fixes_20261001/FAZ_03_DSPReplicatorPlus/check-prepare.ps1',
    '-Game', build.GAME, '-Core', build.CORE, '-Output', out / 'headless')
(HERE / 'headless-preparation.log').write_text(prepare_log, encoding='utf-8')
queue = plugins / 'BUG-DSPCompleteReplicatorQueue/DSPCompleteReplicatorQueue/DSPCompleteReplicatorQueue.dll'
check = out / 'checks/Check.exe'
refs = [p for p in build.references() if p.name != 'Assembly-CSharp.dll']
refs += [out.parent / 'game-update-audit/compile-reference/Assembly-CSharp.dll', queue, module.ORIGINAL]
build.compile_cs([HERE / 'check.cs', fixture_file], check, refs, executable=True)
results = []
for variant, target, fixed in [('original', module.ORIGINAL, '0'), ('candidate', out / 'candidate/Multifunction_mod.dll', '1')]:
    directories = [target.parent, out / 'headless', build.GAME, build.CORE, queue.parent]
    env = dict(os.environ, HANDCRAFT_TEST_CONFIG=str(out / (variant + '-config.cfg')), HANDCRAFT_EXPECT_FIXED=fixed)
    p = subprocess.run([sys.executable, str(HERE.parent / '_compat_fixes_20261001/mono-host.py'), str(check)] + list(map(str, directories)),
        env=env, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=60)
    log = p.stdout + p.stderr
    (HERE / (variant + '-check.log')).write_text(log, encoding='utf-8')
    result = {'variant': variant, 'passed': p.returncode == 0, 'sha256': build.digest(target), 'log': log}
    results.append(result)
    (HERE / 'check-results.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(variant, p.returncode, log[-4500:], flush=True)
    assert p.returncode == 0, 'Native check failed: ' + variant
