"""Back up the old DLL, install the validated candidate, and verify every protected DLL."""
import importlib.util
import json
from pathlib import Path
import os
import shutil
import subprocess
import sys
import zipfile

sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('handcraft_build', HERE / 'build-and-patch.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
build = module.build
target = module.ORIGINAL
candidate = module.OUT / 'candidate/Multifunction_mod.dll'

if __name__ == '__main__':
    validation = json.loads((HERE / 'validation.json').read_text(encoding='utf-8-sig'))
    checks = json.loads((HERE / 'check-results.json').read_text(encoding='utf-8'))
    regressions = json.loads((HERE / 'regressions.json').read_text(encoding='utf-8'))
    assert validation['passed'] and len(checks) == 2 and all(r['passed'] for r in checks)
    assert len(regressions) == 2 and all(r['passed'] for r in regressions)
    candidate_hash = build.digest(candidate)
    assert candidate_hash == validation['candidate_sha256'].lower()
    assert candidate_hash == next(r['sha256'] for r in checks if r['variant'] == 'candidate')
    before = json.loads((HERE / 'protected-before.json').read_text(encoding='utf-8'))
    assert all(build.digest(Path(p)) == sha for p, sha in before.items()), 'A protected DLL changed during validation'
    process = subprocess.run(['powershell.exe', '-NoProfile', '-Command', "@(Get-Process -Name DSPGAME -ErrorAction SilentlyContinue).Count"], capture_output=True, text=True, check=True)
    assert process.stdout.strip() == '0', 'Close the game before installing'
    relative = target.relative_to(module.PLUGINS).as_posix()
    rollback = HERE / 'rollback-before-handcraft.zip'
    with zipfile.ZipFile(rollback, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.write(target, relative)
    with zipfile.ZipFile(rollback) as archive:
        assert archive.read(relative) == target.read_bytes() and archive.testzip() is None
    update = HERE / 'Multifunction_mod-handcraft-update.zip'
    with zipfile.ZipFile(update, 'w', zipfile.ZIP_DEFLATED) as archive:
        archive.write(candidate, relative)
    temporary = target.with_suffix('.handcraft.tmp')
    shutil.copyfile(candidate, temporary)
    assert build.digest(temporary) == candidate_hash
    os.replace(temporary, target)
    assert build.digest(target) == candidate_hash
    changed = [p for p, sha in before.items() if build.digest(Path(p)) != sha]
    assert changed == [str(target)], 'Unexpected DLL modification: ' + repr(changed)
    result = {
        'installed': str(target), 'sha256': candidate_hash, 'original_sha256': before[str(target)],
        'rollback': str(rollback), 'rollback_sha256': build.digest(rollback),
        'update_zip': str(update), 'protected_dlls': len(before),
        'only_expected_dll_changed': True, 'game_dlls_unchanged': True,
        'turkish_plugins_unchanged': True, 'live_game_tested': False,
    }
    (HERE / 'installation.json').write_text(json.dumps(result, indent=2), encoding='utf-8')
    print('PASS installed:', target)
    print('PASS only Multifunction_mod.dll changed among', len(before), 'protected DLLs; rollback verified')
