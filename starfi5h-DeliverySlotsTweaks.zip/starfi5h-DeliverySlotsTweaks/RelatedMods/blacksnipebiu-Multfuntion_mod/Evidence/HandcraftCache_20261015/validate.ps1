param([string]$Original, [string]$Built, [string]$Core, [string]$Report)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $Core 'Mono.Cecil.dll')
function Get-AllTypes($types) { foreach ($type in $types) { $type; Get-AllTypes $type.NestedTypes } }
function Get-Body($method) {
    if (!$method.HasBody) { return '' }
    return ($method.Body.Instructions | ForEach-Object ToString) -join "`n"
}
function Get-ResourceHash($resource) {
    $hasher = [System.Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($hasher.ComputeHash($resource.GetResourceData())).Replace('-', '') }
    finally { $hasher.Dispose() }
}
$old = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Original)
$new = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Built)
try {
    if ($old.Name.FullName -ne $new.Name.FullName) { throw 'Assembly identity changed' }
    if ($old.MainModule.Mvid -eq $new.MainModule.Mvid) { throw 'Patched assembly must have a new MVID' }
    if ($new.MainModule.AssemblyReferences.Name -contains 'HandcraftHelper') { throw 'Unexpected runtime helper dependency' }
    $oldTypes = @(Get-AllTypes $old.MainModule.Types)
    $newTypes = @(Get-AllTypes $new.MainModule.Types)
    if ($oldTypes.Count -ne $newTypes.Count) { throw 'Type count changed' }
    $unchanged = 0
    $changed = @()
    foreach ($oldType in $oldTypes) {
        $newType = $newTypes | Where-Object FullName -eq $oldType.FullName
        if ($newType.Attributes -ne $oldType.Attributes) { throw "Type attributes changed: $($oldType.FullName)" }
        if (($oldType.Fields.FullName -join '|') -ne ($newType.Fields.FullName -join '|')) { throw "Fields changed: $($oldType.FullName)" }
        foreach ($oldMethod in $oldType.Methods) {
            $newMethod = $newType.Methods | Where-Object FullName -eq $oldMethod.FullName
            if (!$newMethod -or $newMethod.Attributes -ne $oldMethod.Attributes) { throw "Method contract changed: $($oldMethod.FullName)" }
            if ((Get-Body $oldMethod) -eq (Get-Body $newMethod)) { $unchanged++ }
            else { $changed += $oldMethod.FullName }
        }
    }
    if ($changed.Count -ne 1 -or $changed[0] -ne 'System.Void Multifunction_mod.Multifunction::ChangeRecipe()') {
        throw ('Unexpected modified methods: ' + ($changed -join '; '))
    }
    $oldMethods = @($oldTypes.Methods).Count
    $newMethods = @($newTypes.Methods).Count
    if ($newMethods -ne $oldMethods + 1) { throw 'Expected exactly one added helper method' }
    $helper = $new.MainModule.GetType('Multifunction_mod.Multifunction').Methods | Where-Object Name -eq 'RebuildHandcraftCache'
    if (!$helper.IsPrivate -or !$helper.IsStatic) { throw 'Helper must remain private and static' }
    $oldRefresh = @($old.MainModule.GetType('Multifunction_mod.Multifunction').Methods | Where-Object Name -eq 'ChangeRecipe')[0]
    $newRefresh = @($new.MainModule.GetType('Multifunction_mod.Multifunction').Methods | Where-Object Name -eq 'ChangeRecipe')[0]
    if ($newRefresh.Body.Instructions.Count -ne $oldRefresh.Body.Instructions.Count + 1) { throw 'Recipe logic was rewritten unexpectedly' }
    for ($index = 0; $index -lt $oldRefresh.Body.Instructions.Count - 1; $index++) {
        if ($oldRefresh.Body.Instructions[$index].ToString() -ne $newRefresh.Body.Instructions[$index].ToString()) { throw "Original recipe instruction changed: $index" }
    }
    foreach ($resource in $old.MainModule.Resources) {
        $target = $new.MainModule.Resources | Where-Object Name -eq $resource.Name
        if (!$target -or (Get-ResourceHash $resource) -ne (Get-ResourceHash $target)) { throw "Resource changed: $($resource.Name)" }
    }
    $result = [ordered]@{
        passed = $true
        original_sha256 = (Get-FileHash -LiteralPath $Original).Hash
        candidate_sha256 = (Get-FileHash -LiteralPath $Built).Hash
        unchanged_methods = $unchanged
        modified_methods = $changed
        added_private_methods = @($helper.FullName)
        original_recipe_logic_retained = $true
        embedded_resources_unchanged = $old.MainModule.Resources.Count
        assembly_identity = $new.Name.FullName
        old_mvid = $old.MainModule.Mvid.ToString()
        new_mvid = $new.MainModule.Mvid.ToString()
    }
    $result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $Report -Encoding utf8
    Write-Output "PASS $unchanged original methods unchanged; only appended recipe-cache refresh and one private helper; resources intact"
} finally { $old.Dispose(); $new.Dispose() }
