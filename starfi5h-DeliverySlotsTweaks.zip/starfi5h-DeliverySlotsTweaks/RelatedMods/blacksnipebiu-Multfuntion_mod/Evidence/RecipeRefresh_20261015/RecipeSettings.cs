using System.Collections.Generic;

internal static class RecipeSettings
{
    private static void ApplyRecipeSettings(ref Dictionary<RecipeProto, RecipeProto> originals, bool all, bool quick)
    {
        if (originals == null) originals = new Dictionary<RecipeProto, RecipeProto>();
        foreach (RecipeProto recipe in LDB.recipes.dataArray)
        {
            RecipeProto original;
            // Prototype identity survives reordering; newly added or replaced recipes need their own baseline.
            if (!originals.TryGetValue(recipe, out original))
            {
                original = new RecipeProto { Handcraft = recipe.Handcraft, TimeSpend = recipe.TimeSpend };
                originals.Add(recipe, original);
            }
            recipe.Handcraft = all || original.Handcraft;
            recipe.TimeSpend = quick ? 10 : original.TimeSpend;
        }
    }
}
