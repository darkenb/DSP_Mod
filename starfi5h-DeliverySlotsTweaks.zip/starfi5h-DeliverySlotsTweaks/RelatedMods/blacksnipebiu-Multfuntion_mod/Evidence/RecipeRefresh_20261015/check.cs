using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using BepInEx.Configuration;
using DSPCompleteReplicatorQueue;
using HarmonyLib;
using Multifunction_mod;

static class Check
{
    sealed class LogHandler : UnityEngine.ILogHandler
    {
        public void LogFormat(UnityEngine.LogType type, UnityEngine.Object context, string format, params object[] args)
            => Console.Error.WriteLine(type + ": " + string.Format(format, args));
        public void LogException(Exception error, UnityEngine.Object context) => Console.Error.WriteLine(error);
    }
    static int assertions;
    static T Bare<T>() => (T)FormatterServices.GetUninitializedObject(typeof(T));
    static void Assert(bool condition, string message)
    {
        assertions++;
        if (!condition) throw new Exception(message);
    }
    static void Set(object target, string name, object value)
    {
        var field = AccessTools.Field(target.GetType(), name) ?? AccessTools.Field(target.GetType(), "<" + name + ">k__BackingField");
        field.SetValue(target, value);
    }

    static Multifunction Protos()
    {
        var recipeSet = Bare<RecipeProtoSet>();
        recipeSet.dataArray = Fixture.Recipes();
        Set(recipeSet, "dataIndices", recipeSet.dataArray.Select((r, i) => new { r.ID, i }).ToDictionary(x => x.ID, x => x.i));
        AccessTools.Field(typeof(LDB), "_recipes").SetValue(null, recipeSet);
        var itemSet = Bare<ItemProtoSet>();
        itemSet.dataArray = recipeSet.dataArray.SelectMany(r => r.Items.Concat(r.Results)).Distinct().OrderBy(id => id)
            .Select(id => new ItemProto { ID = id, StackSize = 10000 }).ToArray();
        Set(itemSet, "dataIndices", itemSet.dataArray.Select((p, i) => new { p.ID, i }).ToDictionary(x => x.ID, x => x.i));
        AccessTools.Field(typeof(LDB), "_items").SetValue(null, itemSet);
        foreach (var item in itemSet.dataArray) AccessTools.Method(typeof(ItemProto), "FindRecipes").Invoke(item, null);
        // GenesisBook's installed FindRecipes postfix changes this UI flag independently of handcraft eligibility.
        foreach (var item in itemSet.dataArray) item.isRaw = item.recipes.Count == 0;
        AccessTools.Field(typeof(StorageComponent), "staticLoaded").SetValue(null, true);
        StorageComponent.itemStackCount = new int[12000];
        foreach (var item in itemSet.dataArray) StorageComponent.itemStackCount[item.ID] = 10000;
        RecipeProto.InitRecipeItems();
        var instance = Bare<Multifunction>();
        instance.originRecipeProtos = recipeSet.dataArray.Select(r => new RecipeProto { TimeSpend = r.TimeSpend, Handcraft = r.Handcraft }).ToArray();
        return instance;
    }

    static MechaForge Forge(Dictionary<int, int> stock, HashSet<int> unlocked = null)
    {
        var player = new Player { isAlive = true };
        var package = new StorageComponent(400);
        int index = 0;
        foreach (var entry in stock)
            package.grids[index++] = new StorageComponent.GRID { itemId = entry.Key, count = entry.Value, inc = entry.Value * 3, stackSize = 10000 };
        Set(player, "package", package);
        var delivery = new DeliveryPackage(); delivery.Init(); Set(player, "deliveryPackage", delivery);
        var history = Bare<GameHistoryData>(); history.featureValues = new Dictionary<int, int>();
        Set(history, "recipeUnlocked", unlocked ?? new HashSet<int>(LDB.recipes.dataArray.Select(r => r.ID)));
        var data = Bare<GameData>(); data.history = history;
        GameMain.data = data;
        var controller = Bare<PlayerController>(); controller.gameData = data; Set(player, "controller", controller);
        var mecha = new Mecha { player = player, gameData = data, replicateSpeed = 1f }; Set(player, "mecha", mecha);
        var forge = new MechaForge(); forge.Init(mecha); forge.gameHistory = history;
        return forge;
    }

    static Dictionary<int, int> Inputs(RecipeProto recipe, int count)
    {
        var stock = new Dictionary<int, int>();
        for (int i = 0; i < recipe.Items.Length; i++)
        {
            int existing; stock.TryGetValue(recipe.Items[i], out existing);
            stock[recipe.Items[i]] = existing + recipe.ItemCounts[i] * count;
        }
        return stock;
    }
    static int Stored(MechaForge forge, int id) => id == 1099 ? (int)forge.player.sandCount : forge.player.package.grids.Where(g => g.itemId == id).Sum(g => g.count);
    static bool SkipPopup() => false;
    static void Finish(MechaForge forge)
    {
        var completion = new QueueCompletion(forge);
        int attempts = 0;
        while (completion.Active && attempts++ < 100) completion.ProcessBatch(0, 128, 1000);
        Assert(!completion.Active && completion.StopReason == null && forge.tasks.Count == 0, "Native completion failed: " + completion.StopReason);
    }
    static RecipeProto AddConsumer(int itemId, int count)
    {
        var recipe = new RecipeProto { ID = 10001, Handcraft = true, TimeSpend = 1, Items = new[] { itemId }, ItemCounts = new[] { count }, Results = new[] { 7999 }, ResultCounts = new[] { 1 } };
        var set = LDB.recipes;
        var data = set.dataArray.ToList(); data.Add(recipe); set.dataArray = data.ToArray();
        Set(set, "dataIndices", set.dataArray.Select((r, i) => new { r.ID, i }).ToDictionary(x => x.ID, x => x.i));
        var items = LDB.items;
        var itemData = items.dataArray.ToList(); itemData.Add(new ItemProto { ID = 7999, StackSize = 10000 }); items.dataArray = itemData.ToArray();
        Set(items, "dataIndices", items.dataArray.Select((p, i) => new { p.ID, i }).ToDictionary(x => x.ID, x => x.i));
        StorageComponent.itemStackCount[7999] = 10000;
        return recipe;
    }

    static void Acyclic(int itemId, HashSet<int> active, HashSet<int> done)
    {
        if (done.Contains(itemId)) return;
        Assert(active.Add(itemId), "Default handcraft path has a cycle at item " + itemId);
        var item = LDB.items.Select(itemId);
        if (item?.handcraft != null)
            foreach (int input in item.handcraft.Items) Acyclic(input, active, done);
        active.Remove(itemId); done.Add(itemId);
    }

    static void Lifecycle(ConfigFile config)
    {
        var instance = Protos();
        var originals = LDB.recipes.dataArray.ToDictionary(r => r.ID, r => new RecipeProto { Handcraft = r.Handcraft, TimeSpend = r.TimeSpend });
        instance.originRecipeProtos = instance.originRecipeProtos.Take(1).ToArray();
        Multifunction.allhandcraft.Value = true; Multifunction.quickproduce.Value = true;
        instance.ChangeRecipe();
        var recipe = LDB.recipes.Select(702);
        var forge = Forge(new Dictionary<int, int> { {1000, 3} });
        bool uiCanCraft = recipe.Handcraft && forge.PredictTaskCount(702) > 0;
        if (Environment.GetEnvironmentVariable("HANDCRAFT_EXPECT_FIXED") != "1")
        {
            Assert(!uiCanCraft && recipe.TimeSpend == 240, "Short-baseline reproduction changed");
            Console.WriteLine("PASS reproduced previous fix: recipe 702 remains machine-only at 4s despite water in inventory and both settings enabled");
            return;
        }
        Assert(uiCanCraft && recipe.TimeSpend == 10, "Late recipe still blocked by old baseline length");
        var set = LDB.recipes;
        set.dataArray = set.dataArray.Reverse().ToArray();
        Set(set, "dataIndices", set.dataArray.Select((r, i) => new { r.ID, i }).ToDictionary(x => x.ID, x => x.i));
        Multifunction.allhandcraft.Value = false; Multifunction.quickproduce.Value = false; instance.ChangeRecipe();
        foreach (var current in set.dataArray)
            Assert(current.Handcraft == originals[current.ID].Handcraft && current.TimeSpend == originals[current.ID].TimeSpend,
                "Reordered recipe restored another recipe's baseline: " + current.ID);
        var added = AddConsumer(7019, 3); added.Handcraft = false; added.TimeSpend = 300;
        Multifunction.allhandcraft.Value = true; Multifunction.quickproduce.Value = true; instance.ChangeRecipe();
        Assert(added.Handcraft && added.TimeSpend == 10, "New recipe omitted after initial snapshot");
        var replacement = new RecipeProto { ID = 702, Items = recipe.Items, ItemCounts = recipe.ItemCounts,
            Results = recipe.Results, ResultCounts = recipe.ResultCounts, Handcraft = false, TimeSpend = 360 };
        set.dataArray[Array.IndexOf(set.dataArray, recipe)] = replacement;
        instance.ChangeRecipe();
        Assert(replacement.Handcraft && replacement.TimeSpend == 10, "Replacement prototype omitted");
        Multifunction.allhandcraft.Value = false; Multifunction.quickproduce.Value = false; instance.ChangeRecipe();
        Assert(!added.Handcraft && added.TimeSpend == 300 && !replacement.Handcraft && replacement.TimeSpend == 360,
            "Late/replacement recipe originals lost");
        Multifunction.refreshLDB = false;
        var logic = typeof(Multifunction).Assembly.GetType("Multifunction_mod.Patchs.Multifunction_modGameLogic");
        AccessTools.Method(logic, "GameMain_Begin_Postfix").Invoke(null, null);
        Assert(Multifunction.refreshLDB, "Second world begin did not request recipe refresh");
        Multifunction.refreshLDB = false;
        Multifunction.isInstantItem = config.Bind("test", "instant", false);
        AccessTools.Method(typeof(Multifunction_mod.Patchs.UIPatch), "UIReplicatorWindow_OnOpen").Invoke(null, new object[] { null });
        Assert(Multifunction.refreshLDB, "Reopening replicator did not request recipe refresh");
        Console.WriteLine("PASS short baseline + recipe 702 native prediction, reordered IDs, appended and replacement prototypes, original flags/times, world-begin and replicator-open refresh hooks");
    }

    static int Main()
    {
        UnityEngine.Debug.unityLogger.logHandler = new LogHandler();
        AccessTools.Field(typeof(Localization), "namesIndexer").SetValue(null, new Dictionary<string, int>());
        var uiBoundary = new Harmony("BUG.Handcraft.HeadlessUIBoundary");
        foreach (var popup in typeof(UIRealtimeTip).GetMethods(BindingFlags.Static | BindingFlags.Public).Where(m => m.Name == "Popup"))
            uiBoundary.Patch(popup, prefix: new HarmonyMethod(typeof(Check), nameof(SkipPopup)));
        string folder = System.IO.Path.GetDirectoryName(Environment.GetEnvironmentVariable("HANDCRAFT_TEST_CONFIG"));
        AccessTools.Method(typeof(BepInEx.Paths), "SetExecutablePath").Invoke(null, new object[] {
            System.IO.Path.Combine(folder, "DSPGAME.exe"), System.IO.Path.Combine(folder, "BepInEx"),
            "D:/Games/Dyson Sphere Program/DSPGAME_Data/Managed", new string[0] });
        var config = new ConfigFile(Environment.GetEnvironmentVariable("HANDCRAFT_TEST_CONFIG"), false) { SaveOnConfigSet = false };
        Multifunction.allhandcraft = config.Bind("test", "all", false);
        Multifunction.quickproduce = config.Bind("test", "quick", false);
        if (Environment.GetEnvironmentVariable("HANDCRAFT_LIFECYCLE_ONLY") == "1")
        {
            Lifecycle(config);
            Console.WriteLine("PASS lifecycle assertions: " + assertions);
            return 0;
        }
        var instance = Protos();
        var originalPaths = LDB.items.dataArray.ToDictionary(i => i.ID, i => i.handcraft);
        var originalRaw = LDB.items.dataArray.ToDictionary(i => i.ID, i => i.isRaw);
        var originalMain = LDB.items.dataArray.ToDictionary(i => i.ID, i => i.maincraft);
        var originalFlags = LDB.recipes.dataArray.Select(r => r.Handcraft).ToArray();
        var originalTimes = LDB.recipes.dataArray.Select(r => r.TimeSpend).ToArray();
        var executeData = RecipeProto.recipeExecuteData;
        Multifunction.allhandcraft.Value = true;
        instance.ChangeRecipe();
        int missing = LDB.items.dataArray.Count(i => i.handcraft == null && LDB.recipes.dataArray.Any(r => r.Results.Contains(i.ID)));
        if (Environment.GetEnvironmentVariable("HANDCRAFT_EXPECT_FIXED") != "1")
        {
            Assert(missing == 118, "Original missing-cache reproduction changed: " + missing);
            var consumer = AddConsumer(7019, 3);
            var forge = Forge(new Dictionary<int, int> { {1000, 3} });
            Assert(!forge.TryAddTask(consumer.ID, 1), "Original unexpectedly auto-crafted oxygen from water");
            Assert(LDB.recipes.Select(702).Handcraft, "Flag was not enabled in original reproduction");
            Console.WriteLine("PASS reproduced original: 118 products missing handcraft links; water -> oxygen intermediate chain rejected despite enabled recipe 702");
            return 0;
        }
        Assert(missing == 0, "Some products still have no handcraft path: " + missing);
        foreach (var recipe in LDB.recipes.dataArray)
        {
            Assert(recipe.Handcraft, "GenesisBook recipe not enabled: " + recipe.ID);
            for (int j = 0; j < recipe.Results.Length; j++)
            {
                var item = LDB.items.Select(recipe.Results[j]);
                Assert(item.handcrafts.Contains(recipe), "Alternative/co-product recipe missing: " + recipe.ID);
                Assert(item.handcraftProductCount == item.handcraft.ResultCounts[Array.IndexOf(item.handcraft.Results, item.ID)], "Wrong output quantity: " + item.ID);
            }
        }
        foreach (var item in LDB.items.dataArray)
        {
            if (originalPaths[item.ID] != null) Assert(ReferenceEquals(item.handcraft, originalPaths[item.ID]), "Existing path replaced: " + item.ID);
            Assert(item.isRaw == originalRaw[item.ID], "GenesisBook raw flag changed");
            Assert(ReferenceEquals(item.maincraft, originalMain[item.ID]), "Factory/default recipe changed");
        }
        Assert(ReferenceEquals(executeData, RecipeProto.recipeExecuteData), "Factory recipe execution cache was replaced");
        var visited = new HashSet<int>();
        foreach (var item in LDB.items.dataArray) Acyclic(item.ID, new HashSet<int>(), visited);
        Assert(LDB.items.Select(7101).handcraft.ID == 801, "Salt path changed to the chlorine cycle");
        Console.WriteLine("PASS 229 GenesisBook recipes registered with all outputs/alternatives; 118 missing product links repaired; original paths and factory data preserved; no default dependency cycles");

        int direct = 0;
        foreach (var recipe in LDB.recipes.dataArray)
        {
            var forge = Forge(Inputs(recipe, 2));
            Assert(forge.TryAddTask(recipe.ID, 2), "Direct native prediction rejected recipe " + recipe.ID);
            Assert(forge.AddTask(recipe.ID, 2) != null, "Direct native reservation failed: " + recipe.ID);
            Finish(forge);
            var expected = new Dictionary<int, int>();
            for (int i = 0; i < recipe.Results.Length; i++)
            {
                int previous; expected.TryGetValue(recipe.Results[i], out previous);
                expected[recipe.Results[i]] = previous + recipe.ResultCounts[i] * 2;
            }
            foreach (var pair in expected) Assert(Stored(forge, pair.Key) == pair.Value, "Native output count mismatch for recipe " + recipe.ID);
            direct++;
        }
        Console.WriteLine("PASS " + direct + " actual native forge recipes: input reservation, two production cycles, every co-product and queue completion");

        var water = Forge(new Dictionary<int, int> { {7018, 3} });
        Assert(water.AddTask(801, 1) != null, "Brine desalination rejected"); Finish(water);
        Assert(Stored(water, 1000) == 3 && Stored(water, 7101) == 1 && Stored(water, 7018) == 0, "Water/salt coproduct mismatch");
        var oxygenConsumer = AddConsumer(7019, 3);
        var oxygen = Forge(new Dictionary<int, int> { {7018, 3} });
        Assert(oxygen.TryAddTask(oxygenConsumer.ID, 1), "Brine -> water -> oxygen chain not discovered");
        Assert(oxygen.AddTask(oxygenConsumer.ID, 1) != null, "Brine -> water -> oxygen reservation failed");
        Assert(oxygen.tasks.Any(t => t.recipeId == 801) && oxygen.tasks.Any(t => t.recipeId == 702), "Expected native intermediates missing");
        Finish(oxygen);
        Assert(Stored(oxygen, 7999) == 1 && Stored(oxygen, 1120) == 6 && Stored(oxygen, 7101) == 1, "Multi-stage coproduct count mismatch");
        var locked = Forge(new Dictionary<int, int> { {7018, 3} }, new HashSet<int> {801, oxygenConsumer.ID});
        Assert(!locked.TryAddTask(oxygenConsumer.ID, 1), "Research lock was bypassed");
        Assert(!Forge(new Dictionary<int, int>()).TryAddTask(801, 1), "Raw brine was created without a recipe");
        Console.WriteLine("PASS brine -> water + salt -> hydrogen + oxygen -> consumer; technology locks and required raw materials retained");

        instance = Protos();
        for (int repeat = 0; repeat < 3; repeat++)
        {
            Multifunction.allhandcraft.Value = true; Multifunction.quickproduce.Value = true; instance.ChangeRecipe();
            Assert(LDB.recipes.dataArray.All(r => r.TimeSpend == 10), "Quick production regressed");
            foreach (var item in LDB.items.dataArray) Assert(item.handcrafts.Distinct().Count() == item.handcrafts.Count, "Repeated refresh duplicated links");
            Multifunction.allhandcraft.Value = false; Multifunction.quickproduce.Value = false; instance.ChangeRecipe();
            for (int i = 0; i < LDB.recipes.dataArray.Length; i++)
                Assert(LDB.recipes.dataArray[i].Handcraft == originalFlags[i] && LDB.recipes.dataArray[i].TimeSpend == originalTimes[i], "Disabled state did not restore original recipe");
            foreach (var item in LDB.items.dataArray)
                Assert(item.handcraft?.ID == originalPaths[item.ID]?.ID, "Disabled state did not restore original handcraft path");
        }
        Console.WriteLine("PASS repeated enable/disable, original recipe flags/times, quick production and no duplicate links");
        Console.WriteLine("PASS total assertions: " + assertions);
        return 0;
    }
}
