param([string]$Original, [string]$Helper, [string]$Built, [string]$Core)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $Core 'Mono.Cecil.dll')
$assembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Original)
$helperAssembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Helper)
try {
    $module = $assembly.MainModule
    $type = $module.GetType('Multifunction_mod.Multifunction')
    function Copy-Body($source, $method) {
        $method.Body = New-Object Mono.Cecil.Cil.MethodBody($method)
        $method.Body.InitLocals = $source.Body.InitLocals
        $method.Body.MaxStackSize = $source.Body.MaxStackSize
        $variables = @{}; $instructions = @{}
        foreach ($variable in $source.Body.Variables) {
            $copy = New-Object Mono.Cecil.Cil.VariableDefinition($module.ImportReference($variable.VariableType))
            $method.Body.Variables.Add($copy); $variables[$variable] = $copy
        }
        foreach ($instruction in $source.Body.Instructions) {
            $copy = [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Nop)
            $copy.OpCode = $instruction.OpCode
            $method.Body.Instructions.Add($copy); $instructions[$instruction] = $copy
        }
        foreach ($instruction in $source.Body.Instructions) {
            $operand = $instruction.Operand
            if ($operand -is [Mono.Cecil.Cil.Instruction]) { $operand = $instructions[$operand] }
            elseif ($operand -is [Mono.Cecil.Cil.Instruction[]]) { $operand = [Mono.Cecil.Cil.Instruction[]]@($operand | ForEach-Object { $instructions[$_] }) }
            elseif ($operand -is [Mono.Cecil.Cil.VariableDefinition]) { $operand = $variables[$operand] }
            elseif ($operand -is [Mono.Cecil.ParameterDefinition]) { $operand = $method.Parameters[$operand.Index] }
            elseif ($operand -is [Mono.Cecil.TypeReference]) { $operand = $module.ImportReference($operand) }
            elseif ($operand -is [Mono.Cecil.MethodReference]) { $operand = $module.ImportReference($operand) }
            elseif ($operand -is [Mono.Cecil.FieldReference]) { $operand = $module.ImportReference($operand) }
            $instructions[$instruction].Operand = $operand
        }
        if ($source.Body.ExceptionHandlers.Count) { throw 'Unexpected helper exception handlers' }
    }
    $source = $helperAssembly.MainModule.GetType('RecipeSettings').Methods | Where-Object Name -eq 'ApplyRecipeSettings'
    $apply = New-Object Mono.Cecil.MethodDefinition($source.Name, $source.Attributes, $module.TypeSystem.Void)
    foreach ($p in $source.Parameters) {
        $apply.Parameters.Add((New-Object Mono.Cecil.ParameterDefinition($p.Name, $p.Attributes, $module.ImportReference($p.ParameterType))))
    }
    $type.Methods.Add($apply)
    Copy-Body $source $apply
    $fieldType = ([Mono.Cecil.ByReferenceType]$apply.Parameters[0].ParameterType).ElementType
    $originals = New-Object Mono.Cecil.FieldDefinition('handcraftOriginals', [Mono.Cecil.FieldAttributes]::Private, $fieldType)
    $type.Fields.Add($originals)
    $cache = $type.Methods | Where-Object Name -eq 'RebuildHandcraftCache'
    Copy-Body ($helperAssembly.MainModule.GetType('HandcraftCache').Methods | Where-Object Name -eq 'RebuildHandcraftCache') $cache
    $change = $type.Methods | Where-Object Name -eq 'ChangeRecipe'
    $change.Body = New-Object Mono.Cecil.Cil.MethodBody($change)
    $il = $change.Body.GetILProcessor()
    $il.Append([Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldarg_0))
    $il.Append([Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldflda, $originals))
    # Reuse the existing generic ConfigEntry<bool>.Value getter reference.
    $getter = $type.Methods.Body.Instructions | Where-Object { $_.Operand -is [Mono.Cecil.MethodReference] -and $_.Operand.Name -eq 'get_Value' -and $_.Operand.DeclaringType.FullName -eq 'BepInEx.Configuration.ConfigEntry`1<System.Boolean>' } | Select-Object -First 1
    if (!$getter) { throw 'ConfigEntry<bool> getter missing' }
    foreach ($name in @('allhandcraft','quickproduce')) {
        $field = $type.Fields | Where-Object Name -eq $name
        $il.Append([Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldsfld, $field))
        $il.Append([Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Callvirt, $getter.Operand))
    }
    $il.Append([Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Call, $apply))
    $il.Append([Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Call, $cache))
    $il.Append([Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ret))
    $refresh = $type.Fields | Where-Object Name -eq 'refreshLDB'
    foreach ($target in @(
        @('Multifunction_mod.Patchs.Multifunction_modGameLogic', 'GameMain_Begin_Postfix'),
        @('Multifunction_mod.Patchs.UIPatch', 'UIReplicatorWindow_OnOpen')
    )) {
        $method = $module.GetType($target[0]).Methods | Where-Object Name -eq $target[1]
        $il = $method.Body.GetILProcessor(); $first = $method.Body.Instructions[0]
        $il.InsertBefore($first, [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Ldc_I4_1))
        $il.InsertBefore($first, [Mono.Cecil.Cil.Instruction]::Create([Mono.Cecil.Cil.OpCodes]::Stsfld, $refresh))
    }
    $module.Mvid = [Guid]::NewGuid()
    $assembly.Write($Built)
    Write-Output 'PASS recipe-object baselines, complete recipe traversal, begin/open refresh hooks and selected-tree refresh; unrelated methods retained'
} finally { $helperAssembly.Dispose(); $assembly.Dispose() }
