using System;
using System.Collections.Generic;

internal static class HandcraftCache
{
    private static void RebuildHandcraftCache()
    {
        foreach (ItemProto item in LDB.items.dataArray)
        {
            RecipeProto previous = item.handcraft;
            if (item.handcrafts == null) item.handcrafts = new List<RecipeProto>();
            else item.handcrafts.Clear();
            item.handcraft = null;
            item.handcraftProductCount = 0;
            int bestOutputIndex = int.MaxValue;

            foreach (RecipeProto recipe in LDB.recipes.dataArray)
            {
                if (!recipe.Handcraft) continue;
                int outputIndex = Array.IndexOf(recipe.Results, item.ID);
                if (outputIndex < 0) continue;
                item.handcrafts.Add(recipe);
                if (outputIndex < bestOutputIndex)
                {
                    item.handcraft = recipe;
                    item.handcraftProductCount = recipe.ResultCounts[outputIndex];
                    bestOutputIndex = outputIndex;
                }
            }

            // Keep existing paths: preferring a newly enabled primary output can create salt/chlorine cycles.
            if (previous != null && item.handcrafts.Contains(previous))
            {
                item.handcraft = previous;
                item.handcraftProductCount = previous.ResultCounts[Array.IndexOf(previous.Results, item.ID)];
            }
        }

        UIReplicatorWindow window = UIRoot.instance?.uiGame?.replicator;
        if (window != null && window.active)
        {
            window.OnTechUnlocked(0, 0, false);
            window.OnSelectedRecipeChange(false);
        }
    }
}
