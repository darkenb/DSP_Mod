param([string]$Original, [string]$Built, [string]$Core, [string]$Report)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $Core 'Mono.Cecil.dll')
function Get-AllTypes($types) { foreach ($type in $types) { $type; Get-AllTypes $type.NestedTypes } }
function Get-Body($method, $skip = 0) {
    if (!$method.HasBody) { return '' }
    $all = $method.Body.Instructions
    return ($all | Select-Object -Skip $skip | ForEach-Object {
        $operand = $_.Operand
        if ($operand -is [Mono.Cecil.Cil.Instruction]) { $operand = 'target:' + ($all.IndexOf($operand) - $skip) }
        elseif ($operand -is [Mono.Cecil.Cil.Instruction[]]) { $operand = ($operand | ForEach-Object { $all.IndexOf($_) - $skip }) -join ',' }
        $_.OpCode.Code.ToString() + ':' + [string]$operand
    }) -join "`n"
}
function Get-ResourceHash($resource) {
    $sha = [System.Security.Cryptography.SHA256]::Create()
    try { return [BitConverter]::ToString($sha.ComputeHash($resource.GetResourceData())).Replace('-', '') }
    finally { $sha.Dispose() }
}
$old = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Original)
$new = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Built)
try {
    if ($old.Name.FullName -ne $new.Name.FullName) { throw 'Assembly identity changed' }
    if ($old.MainModule.Mvid -eq $new.MainModule.Mvid) { throw 'MVID was not renewed' }
    if ($new.MainModule.AssemblyReferences.Name -contains 'RecipeSettingsHelper') { throw 'Runtime helper dependency leaked' }
    $oldTypes = @(Get-AllTypes $old.MainModule.Types); $newTypes = @(Get-AllTypes $new.MainModule.Types)
    if ($oldTypes.Count -ne $newTypes.Count) { throw 'Type count changed' }
    $changed = @(); $unchanged = 0
    $hooks = @('GameMain_Begin_Postfix', 'UIReplicatorWindow_OnOpen')
    foreach ($ot in $oldTypes) {
        $nt = $newTypes | Where-Object FullName -eq $ot.FullName
        if ($ot.Attributes -ne $nt.Attributes) { throw 'Type attributes changed' }
        foreach ($of in $ot.Fields) {
            $nf = $nt.Fields | Where-Object FullName -eq $of.FullName
            if (!$nf -or $of.Attributes -ne $nf.Attributes) { throw 'Original field changed' }
        }
        if ($nt.Fields.Count -ne $ot.Fields.Count + [int]($ot.FullName -eq 'Multifunction_mod.Multifunction')) { throw 'Unexpected added fields' }
        foreach ($om in $ot.Methods) {
            $nm = $nt.Methods | Where-Object FullName -eq $om.FullName
            if (!$nm -or $om.Attributes -ne $nm.Attributes) { throw 'Method contract changed' }
            if ((Get-Body $om) -eq (Get-Body $nm)) { $unchanged++; continue }
            $changed += $om.FullName
            if ($hooks -contains $om.Name) {
                if ((Get-Body $om) -ne (Get-Body $nm 2)) { throw 'Hook original logic changed' }
                if ($nm.Body.Instructions[0].OpCode.Code -ne 'Ldc_I4_1' -or $nm.Body.Instructions[1].Operand.Name -ne 'refreshLDB') { throw 'Wrong refresh hook' }
            } elseif ($om.Name -notin @('ChangeRecipe','RebuildHandcraftCache')) { throw 'Unrelated method changed' }
        }
    }
    if ($changed.Count -ne 4) { throw 'Expected four modified methods' }
    if (@($newTypes.Methods).Count -ne @($oldTypes.Methods).Count + 1) { throw 'Unexpected added methods' }
    $type = $new.MainModule.GetType('Multifunction_mod.Multifunction')
    $apply = $type.Methods | Where-Object Name -eq 'ApplyRecipeSettings'
    $field = $type.Fields | Where-Object Name -eq 'handcraftOriginals'
    if (!$apply.IsPrivate -or !$apply.IsStatic -or !$field.IsPrivate -or $field.IsStatic) { throw 'Unexpected helper contracts' }
    foreach ($resource in $old.MainModule.Resources) {
        $target = $new.MainModule.Resources | Where-Object Name -eq $resource.Name
        if (!$target -or (Get-ResourceHash $resource) -ne (Get-ResourceHash $target)) { throw 'Embedded resource changed' }
    }
    $result = [ordered]@{ passed = $true; original_sha256 = (Get-FileHash -LiteralPath $Original).Hash
        candidate_sha256 = (Get-FileHash -LiteralPath $Built).Hash; unchanged_methods = $unchanged
        modified_methods = $changed; hooks_original_logic_preserved = $true
        new_private_method = $apply.FullName; new_private_field = $field.FullName
        embedded_resources_unchanged = $old.MainModule.Resources.Count; assembly_identity = $new.Name.FullName
        old_mvid = $old.MainModule.Mvid.ToString(); new_mvid = $new.MainModule.Mvid.ToString() }
    $result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath $Report -Encoding utf8
    Write-Output "PASS $unchanged methods unchanged; four scoped methods changed, original begin/open behavior preserved; resources intact"
} finally { $old.Dispose(); $new.Dispose() }
