"""Exercise the previous fix's uncovered lifecycle cases and retain the full native-forge suite."""
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys

sys.stdout.reconfigure(encoding='utf-8')
HERE = Path(__file__).resolve().parent
spec = importlib.util.spec_from_file_location('refresh_build', HERE / 'build-and-patch.py')
module = importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
build, out, plugins = module.build, module.OUT, module.PLUGINS
previous = out.parent / 'handcraft-fix'
queue = plugins / 'BUG-DSPCompleteReplicatorQueue/DSPCompleteReplicatorQueue/DSPCompleteReplicatorQueue.dll'
candidate = out / 'candidate/Multifunction_mod.dll'
refs = [p for p in build.references() if p.name != 'Assembly-CSharp.dll']
refs += [out.parent / 'game-update-audit/compile-reference/Assembly-CSharp.dll', queue, candidate]
check = out / 'checks/Check.exe'
print(build.compile_cs([HERE / 'check.cs', previous / 'Fixture.cs'], check, refs, executable=True))
results = []
for variant, target, fixed, lifecycle in [
    ('previous-reproduction', module.ORIGINAL, '0', '1'),
    ('candidate-lifecycle', candidate, '1', '1'),
    ('candidate-full', candidate, '1', '0'),
]:
    directories = [target.parent, previous / 'headless', build.GAME, build.CORE, queue.parent]
    env = dict(os.environ, HANDCRAFT_TEST_CONFIG=str(out / (variant + '-config.cfg')),
        HANDCRAFT_EXPECT_FIXED=fixed, HANDCRAFT_LIFECYCLE_ONLY=lifecycle)
    p = subprocess.run([sys.executable, str(HERE.parent / '_compat_fixes_20261001/mono-host.py'), str(check)] + list(map(str, directories)),
        env=env, capture_output=True, text=True, encoding='utf-8', errors='replace', timeout=60)
    log = p.stdout + p.stderr
    (HERE / (variant + '.log')).write_text(log, encoding='utf-8')
    results.append({'variant': variant, 'passed': p.returncode == 0, 'sha256': build.digest(target), 'log': log})
    (HERE / 'check-results.json').write_text(json.dumps(results, indent=2), encoding='utf-8')
    print(variant, p.returncode, '\n'.join(s for s in log.splitlines() if s.startswith('PASS ')), flush=True)
    assert p.returncode == 0, log[-4500:]
