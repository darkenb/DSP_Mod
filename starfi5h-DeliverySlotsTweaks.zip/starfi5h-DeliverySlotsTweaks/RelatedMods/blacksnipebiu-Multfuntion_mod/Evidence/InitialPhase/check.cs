using System;
using System.Linq;
using System.Reflection.Emit;
using HarmonyLib;
using Multifunction_mod;
using Multifunction_mod.Patchs;

static class Check
{
    static int Main()
    {
        AccessTools.Field(typeof(StorageComponent), "staticLoaded").SetValue(null, true); StorageComponent.itemStackCount = new int[12000];
        var player = new Player();
        AccessTools.Field(typeof(Player), "<package>k__BackingField").SetValue(player, new StorageComponent(24)); player.packageColCount = 12;
        player.package.grids[23] = new StorageComponent.GRID {itemId = 5001, count = 3, inc = 9, filter = 5001, stackSize = 100};
        var resize = AccessTools.Method(typeof(Multifunction), "ResizePackage");
        if ((bool)resize.Invoke(null, new object[] {player, 0, 1, false}) || player.package.size != 24 || player.package.grids[23].inc != 9)
            throw new Exception("Occupied/filtered removed column accepted");
        if (!(bool)resize.Invoke(null, new object[] {player, 0, 1, true}) || player.package.grids[24].count != 3 || player.package.grids[24].inc != 9 || player.package.grids[24].filter != 5001)
            throw new Exception("Column remap lost cargo/inc/filter");
        if (!(bool)resize.Invoke(null, new object[] {player, 0, 1, false}) || player.package.grids[23].count != 3) throw new Exception("Empty column shrink failed");
        var gen = new DynamicMethod("test", typeof(void), Type.EmptyTypes).GetILGenerator();
        var original = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(PlanetFactory), "PlanetReformAll"), gen);
        var result = ((System.Collections.Generic.IEnumerable<CodeInstruction>)AccessTools.Method(typeof(PlanetFactoryPatch), "BulkReformCollection").Invoke(null, new object[] {original})).ToList();
        if (result.Count(i => i.Calls(AccessTools.Method(typeof(PlanetFactoryPatch), "RemoveVegeAndCollect"))) != 1) throw new Exception("Native bulk collection bridge missing");
        Console.WriteLine("PASS cargo/filter/inc preserving inventory resize and actual native bulk vegetation IL bridge");
        return 0;
    }
}
