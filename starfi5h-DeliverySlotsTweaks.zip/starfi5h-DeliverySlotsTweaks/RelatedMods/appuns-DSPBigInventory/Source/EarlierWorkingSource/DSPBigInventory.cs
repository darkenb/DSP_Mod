using System;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;

[assembly: AssemblyVersion("0.1.0.0")]
[assembly: AssemblyFileVersion("1.0.10.0")]
namespace DSPBigInventory
{
    [BepInPlugin("Appun.DSP.plugin.BigInventory", "DSPBigInventory", "1.0.10")]
    [BepInProcess("DSPGAME.exe")]
    [HarmonyPatch]
    public class DSPBigInventory : BaseUnityPlugin
    {
        public static ConfigEntry<int> colCount, rowCount, DeliveryColCount;
        public static ConfigEntry<bool> defaultSetting;
        Harmony harmony;
        public void Start()
        {
            LogManager.Logger = Logger;
            colCount = Config.Bind("General", "colCount", 16, "Minimum inventory columns (native range 10-30).");
            rowCount = Config.Bind("General", "rowCount", 14, "Minimum inventory rows (1-100). Existing items and larger saves are preserved.");
            DeliveryColCount = Config.Bind("General", "DeliveryColCount", 5, "Minimum delivery columns (native range 0-5). Research unlock is preserved.");
            defaultSetting = Config.Bind("DefaultSetting", "DefaultSize?", false, "Use native sizing. Existing saves are never shrunk or reconstructed from vanilla tech IDs.");
            harmony = Harmony.CreateAndPatchAll(Assembly.GetExecutingAssembly(), "Appun.DSP.plugin.BigInventory");
        }
        void OnDestroy() { ViewportFit.RemoveAll(); harmony?.UnpatchSelf(); }
        public static int Clamp(int value, int min, int max) => Math.Max(min, Math.Min(max, value));
        public static void Apply(Player player, int columns, int rows, int deliveryColumns, bool native)
        {
            if (native || player?.package == null) return;
            columns = Clamp(columns, 10, 30);
            rows = Clamp(rows, 1, 100);
            int oldColumns = player.GetPackageColumnCount();
            int newColumns = Math.Max(oldColumns, columns);
            int oldRows = (player.package.size - 1) / oldColumns + 1;
            int target = checked(newColumns * Math.Max(rows, oldRows));
            player.packageColCount = newColumns;
            if (newColumns != oldColumns) player.package.SetSize(target, oldColumns, newColumns);
            else if (player.package.size < target) player.package.SetSize(target);
            if (player.deliveryPackage != null)
            {
                player.deliveryPackage.colCount = Math.Max(player.deliveryPackage.colCount, Clamp(deliveryColumns, 0, 5));
                player.OnPackageSizeChange(); // native 20-row/5-column clamp, maps and UI notification
            }
        }
        static void Apply(Player player) => Apply(player, colCount?.Value ?? 16, rowCount?.Value ?? 14,
                                                  DeliveryColCount?.Value ?? 5, defaultSetting?.Value ?? false);
        [HarmonyPostfix, HarmonyPatch(typeof(Player), "Import")]
        public static void Mecha_Import_Postfix(Player __instance) => Apply(__instance);
        [HarmonyPostfix, HarmonyPatch(typeof(Player), "SetForNewGame")]
        public static void Mecha_SetForNewGame_Postfix(Player __instance) => Apply(__instance);
        // Preserve the legacy public entry point, but no longer suppress native research.
        public static bool GameHistoryData_UnlockTechFunction_Prefix(GameHistoryData __instance, int func) => true;
        [HarmonyPostfix, HarmonyPatch(typeof(GameHistoryData), "UnlockTechFunction")]
        public static void ResearchPostfix(int func)
        {
            if (func == 5 || func == 32 || func == 38) Apply(GameMain.mainPlayer);
        }
        // Current native UI consumes Player.GetPackageColumnCount and handles delivery,
        // sorting and filtering. The obsolete replacement UI methods stay callable for ABI.
        public static void UIInventoryWindow_OnPlayerDeliveryPackageSizeChange_Postfix(UIInventoryWindow __instance) { }
        public static void UIInventoryWindow_OnPackageSizeChange_Postfix(Player __instance) { }
        public static bool UIAssemblerWindow_OpenPlayerPackage_Prefix(UIAssemblerWindow __instance) => true;
        public static bool UIMinerWindow_OnOpen_Prefix(UIMinerWindow __instance) => true;

        [HarmonyPostfix, HarmonyPatch(typeof(UIInventoryWindow), "_OnOpen")]
        static void InventoryOpened(UIInventoryWindow __instance) => ViewportFit.Attach(__instance.windowTrans);
        [HarmonyPostfix, HarmonyPatch(typeof(UIAssemblerWindow), "_OnOpen")]
        static void AssemblerOpened(UIAssemblerWindow __instance) => ViewportFit.Attach(__instance.windowTrans);
        [HarmonyPostfix, HarmonyPatch(typeof(UIMinerWindow), "_OnOpen")]
        static void MinerOpened(UIMinerWindow __instance) => ViewportFit.Attach(__instance.windowTrans);
    }
    public class LogManager { public static ManualLogSource Logger; }
}
