using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyFileVersion("1.0.10.0")]
[assembly: AssemblyVersion("0.1.0.0")]
[module: RefSafetyRules(11)]
