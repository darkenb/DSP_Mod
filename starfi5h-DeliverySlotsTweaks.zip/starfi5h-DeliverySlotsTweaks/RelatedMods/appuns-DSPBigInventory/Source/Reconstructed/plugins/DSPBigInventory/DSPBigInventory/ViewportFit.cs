using System;
using System.Collections.Generic;
using UnityEngine;

namespace DSPBigInventory;

[DefaultExecutionOrder(10000)]
public sealed class ViewportFit : MonoBehaviour
{
	private static readonly List<ViewportFit> instances = new List<ViewportFit>();

	private readonly Vector3[] corners = new Vector3[4];

	private RectTransform window;

	private Vector3 originalScale;

	public static void Attach(RectTransform rect)
	{
		if (!(rect == null) && !(rect.GetComponent<ViewportFit>() != null))
		{
			ViewportFit viewportFit = rect.gameObject.AddComponent<ViewportFit>();
			viewportFit.window = rect;
			viewportFit.originalScale = rect.localScale;
			instances.Add(viewportFit);
		}
	}

	public static void RemoveAll()
	{
		foreach (ViewportFit instance in instances)
		{
			if (!(instance == null))
			{
				if (instance.window != null)
				{
					instance.window.localScale = instance.originalScale;
				}
				UnityEngine.Object.Destroy(instance);
			}
		}
		instances.Clear();
	}

	private void OnDestroy()
	{
		if (window != null)
		{
			window.localScale = originalScale;
		}
		instances.Remove(this);
	}

	public static float ScaleToFit(float width, float height, Rect available)
	{
		if (!(width > 0f) || !(height > 0f) || !(available.width > 0f) || !(available.height > 0f) || float.IsInfinity(width) || float.IsInfinity(height))
		{
			return 1f;
		}
		return Math.Min(1f, Math.Min(available.width / width, available.height / height));
	}

	public static Vector2 OffsetToFit(Rect bounds, Rect available)
	{
		float x = ((bounds.xMin < available.xMin) ? (available.xMin - bounds.xMin) : ((bounds.xMax > available.xMax) ? (available.xMax - bounds.xMax) : 0f));
		float y = ((bounds.yMin < available.yMin) ? (available.yMin - bounds.yMin) : ((bounds.yMax > available.yMax) ? (available.yMax - bounds.yMax) : 0f));
		return new Vector2(x, y);
	}

	private Rect Measure(Camera camera)
	{
		window.GetWorldCorners(corners);
		Vector2 vector = RectTransformUtility.WorldToScreenPoint(camera, corners[0]);
		float num = vector.x;
		float num2 = vector.x;
		float num3 = vector.y;
		float num4 = vector.y;
		for (int i = 1; i < corners.Length; i++)
		{
			Vector2 vector2 = RectTransformUtility.WorldToScreenPoint(camera, corners[i]);
			num = Math.Min(num, vector2.x);
			num2 = Math.Max(num2, vector2.x);
			num3 = Math.Min(num3, vector2.y);
			num4 = Math.Max(num4, vector2.y);
		}
		return Rect.MinMaxRect(num, num3, num2, num4);
	}

	private void LateUpdate()
	{
		if (window == null || UIRoot.instance == null || UIRoot.instance.overlayCanvas == null)
		{
			return;
		}
		RectTransform rectTransform = window.parent as RectTransform;
		if (rectTransform == null || originalScale.x <= 0f || window.localScale.x <= 0f)
		{
			return;
		}
		Rect safeArea = Screen.safeArea;
		safeArea = new Rect(safeArea.x + 8f, safeArea.y + 8f, safeArea.width - 16f, safeArea.height - 16f);
		if (!(safeArea.width <= 0f) && !(safeArea.height <= 0f))
		{
			Camera worldCamera = UIRoot.instance.overlayCanvas.worldCamera;
			Rect bounds = Measure(worldCamera);
			float num = window.localScale.x / originalScale.x;
			float num2 = ScaleToFit(bounds.width / num, bounds.height / num, safeArea);
			Vector3 vector = new Vector3(originalScale.x * num2, originalScale.y * num2, originalScale.z);
			if (window.localScale != vector)
			{
				window.localScale = vector;
				bounds = Measure(worldCamera);
			}
			Vector2 vector2 = OffsetToFit(bounds, safeArea);
			if (!(vector2 == Vector2.zero) && RectTransformUtility.ScreenPointToLocalPointInRectangle(rectTransform, bounds.min, worldCamera, out var localPoint) && RectTransformUtility.ScreenPointToLocalPointInRectangle(rectTransform, bounds.min + vector2, worldCamera, out var localPoint2))
			{
				window.anchoredPosition += localPoint2 - localPoint;
			}
		}
	}
}
