using BepInEx.Logging;

namespace DSPBigInventory;

public class LogManager
{
	public static ManualLogSource Logger;
}
