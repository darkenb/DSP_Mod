using System;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;

namespace DSPBigInventory;

[BepInPlugin("Appun.DSP.plugin.BigInventory", "DSPBigInventory", "1.0.10")]
[BepInProcess("DSPGAME.exe")]
[HarmonyPatch]
public class DSPBigInventory : BaseUnityPlugin
{
	public static ConfigEntry<int> colCount;

	public static ConfigEntry<int> rowCount;

	public static ConfigEntry<int> DeliveryColCount;

	public static ConfigEntry<bool> defaultSetting;

	private Harmony harmony;

	public void Start()
	{
		LogManager.Logger = base.Logger;
		colCount = base.Config.Bind("General", "colCount", 16, "Minimum inventory columns (native range 10-30).");
		rowCount = base.Config.Bind("General", "rowCount", 14, "Minimum inventory rows (1-100). Existing items and larger saves are preserved.");
		DeliveryColCount = base.Config.Bind("General", "DeliveryColCount", 5, "Minimum delivery columns (native range 0-5). Research unlock is preserved.");
		defaultSetting = base.Config.Bind("DefaultSetting", "DefaultSize?", defaultValue: false, "Use native sizing. Existing saves are never shrunk or reconstructed from vanilla tech IDs.");
		harmony = Harmony.CreateAndPatchAll(Assembly.GetExecutingAssembly(), "Appun.DSP.plugin.BigInventory");
	}

	private void OnDestroy()
	{
		ViewportFit.RemoveAll();
		harmony?.UnpatchSelf();
	}

	public static int Clamp(int value, int min, int max)
	{
		return Math.Max(min, Math.Min(max, value));
	}

	public static void Apply(Player player, int columns, int rows, int deliveryColumns, bool native)
	{
		if (!native && player?.package != null)
		{
			columns = Clamp(columns, 10, 30);
			rows = Clamp(rows, 1, 100);
			int packageColumnCount = player.GetPackageColumnCount();
			int num = Math.Max(packageColumnCount, columns);
			int val = (player.package.size - 1) / packageColumnCount + 1;
			int num2 = checked(num * Math.Max(rows, val));
			player.packageColCount = num;
			if (num != packageColumnCount)
			{
				player.package.SetSize(num2, packageColumnCount, num);
			}
			else if (player.package.size < num2)
			{
				player.package.SetSize(num2);
			}
			if (player.deliveryPackage != null)
			{
				player.deliveryPackage.colCount = Math.Max(player.deliveryPackage.colCount, Clamp(deliveryColumns, 0, 5));
				player.OnPackageSizeChange();
			}
		}
	}

	private static void Apply(Player player)
	{
		Apply(player, colCount?.Value ?? 16, rowCount?.Value ?? 14, DeliveryColCount?.Value ?? 5, defaultSetting?.Value ?? false);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(Player), "Import")]
	public static void Mecha_Import_Postfix(Player __instance)
	{
		Apply(__instance);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(Player), "SetForNewGame")]
	public static void Mecha_SetForNewGame_Postfix(Player __instance)
	{
		Apply(__instance);
	}

	public static bool GameHistoryData_UnlockTechFunction_Prefix(GameHistoryData __instance, int func)
	{
		return true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameHistoryData), "UnlockTechFunction")]
	public static void ResearchPostfix(int func)
	{
		if (func == 5 || func == 32 || func == 38)
		{
			Apply(GameMain.mainPlayer);
		}
	}

	public static void UIInventoryWindow_OnPlayerDeliveryPackageSizeChange_Postfix(UIInventoryWindow __instance)
	{
	}

	public static void UIInventoryWindow_OnPackageSizeChange_Postfix(Player __instance)
	{
	}

	public static bool UIAssemblerWindow_OpenPlayerPackage_Prefix(UIAssemblerWindow __instance)
	{
		return true;
	}

	public static bool UIMinerWindow_OnOpen_Prefix(UIMinerWindow __instance)
	{
		return true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIInventoryWindow), "_OnOpen")]
	private static void InventoryOpened(UIInventoryWindow __instance)
	{
		ViewportFit.Attach(__instance.windowTrans);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIAssemblerWindow), "_OnOpen")]
	private static void AssemblerOpened(UIAssemblerWindow __instance)
	{
		ViewportFit.Attach(__instance.windowTrans);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIMinerWindow), "_OnOpen")]
	private static void MinerOpened(UIMinerWindow __instance)
	{
		ViewportFit.Attach(__instance.windowTrans);
	}
}
