using DSPBigInventory;
using System;
using System.Reflection;
using System.Runtime.Serialization;
using HarmonyLib;
using Mod = DSPBigInventory.DSPBigInventory;
static class Check
{
    static T Empty<T>() => (T)FormatterServices.GetUninitializedObject(typeof(T));
    static void Set(object target, string name, object value) =>
        (AccessTools.Field(target.GetType(), name) ?? AccessTools.Field(target.GetType(), "<" + name + ">k__BackingField")).SetValue(target, value);
    static void Assert(bool value, string message) { if (!value) throw new Exception(message); Console.WriteLine("PASS " + message); }
    static int Main()
    {
        AccessTools.Field(typeof(StorageComponent), "staticLoaded").SetValue(null, true);
        StorageComponent.itemStackCount = new int[12000]; StorageComponent.itemStackCount[5001] = 100;
        var player = new Player(); var package = new StorageComponent(400);
        Set(player, "package", package); player.packageColCount = 10;
        var delivery = new DeliveryPackage(); delivery.Init(); Set(player, "deliveryPackage", delivery);
        delivery.colCount = 2; delivery.stackSizeMultiplier = 8; delivery.unlocked = false;
        package.grids[399] = new StorageComponent.GRID {itemId = 5001, count = 17, inc = 51, stackSize = 100};
        Mod.Apply(player, 16, 14, 5, false);
        int mapped = 39 * 16 + 9;
        Assert(package.size == 640 && package.grids[mapped].count == 17 && package.grids[mapped].inc == 51, "native width remapping preserves last saved item and inc");
        Assert(delivery.rowCount == 20 && delivery.colCount == 5 && delivery.activeCount == 0 && delivery.stackSizeMultiplier == 8, "native delivery bounds preserve unlock and research multiplier");
        Mod.Apply(player, 0, int.MinValue, int.MaxValue, false);
        Assert(package.size == 640 && package.grids[mapped].count == 17, "invalid/reduced settings cannot shrink loaded inventory");
        Mod.Apply(player, int.MaxValue, int.MaxValue, -1, true);
        Assert(package.size == 640 && player.packageColCount == 16, "default mode preserves native saved layout without vanilla tech IDs");
        var data = Empty<GameData>(); Set(data, "mainPlayer", player); GameMain.data = data;
        Set(player, "mecha", new Mecha()); var history = Empty<GameHistoryData>(); Set(history, "gameData", data);
        int callbacks = 0; history.onFunctionUnlocked += (f,v,l) => callbacks++;
        var harmony = new Harmony("phase12.native.check");
        // UI creation needs Unity's player; patch only the research path exercised here.
        harmony.Patch(AccessTools.Method(typeof(GameHistoryData), "UnlockTechFunction"),
            postfix: new HarmonyMethod(AccessTools.Method(typeof(Mod), "ResearchPostfix")));
        history.UnlockTechFunction(5, 1, 1);
        history.UnlockTechFunction(33, 2, 1);
        delivery.colCount = 2; history.UnlockTechFunction(32, 1, 1);
        history.UnlockTechFunction(38, 1, 1);
        Assert(callbacks == 4 && delivery.stackSizeMultiplier == 10 && player.packageColCount == 17,
               "actual native inventory/delivery/column/stack research and callbacks execute through Harmony");
        bool found = false; foreach (var grid in package.grids) if (grid.itemId == 5001 && grid.count == 17 && grid.inc == 51) found = true;
        Assert(found, "native research remapping retains existing cargo");
        harmony.UnpatchSelf(); CheckViewport(); return 0;
    }
    static void CheckViewport()
    {
        int scenarios = 0;
        foreach (var resolution in new[] { new UnityEngine.Vector2(1280,720), new UnityEngine.Vector2(1366,768), new UnityEngine.Vector2(1920,1080), new UnityEngine.Vector2(2560,1440), new UnityEngine.Vector2(3840,2160), new UnityEngine.Vector2(3440,1440), new UnityEngine.Vector2(1080,1920) })
        foreach (float canvasScale in new[] { 0.75f, 1f, 1.5f, 2f })
        foreach (var frame in new[] { new UnityEngine.Vector2(888,826), new UnityEngine.Vector2(1144,852), new UnityEngine.Vector2(1844,5152), new UnityEngine.Vector2(1194,2152), new UnityEngine.Vector2(700,808), new UnityEngine.Vector2(700,896) })
        {
            var safe = new UnityEngine.Rect(8,8,resolution.x-16,resolution.y-16);
            float width=frame.x*canvasScale, height=frame.y*canvasScale;
            float scale=ViewportFit.ScaleToFit(width,height,safe);
            if (!(scale > 0 && scale <= 1 && width*scale <= safe.width+0.01 && height*scale <= safe.height+0.01)) throw new Exception("Viewport fit failed: " + resolution + " at UI scale " + canvasScale);
            scenarios++;
            foreach (var position in new[] { new UnityEngine.Vector2(-200,-300), new UnityEngine.Vector2(resolution.x-10,resolution.y-20), new UnityEngine.Vector2(8,8) })
            {
                var bounds = new UnityEngine.Rect(position.x,position.y,width*scale,height*scale);
                var offset = ViewportFit.OffsetToFit(bounds,safe);
                bounds.position += offset;
                if (!(bounds.xMin >= safe.xMin-0.01 && bounds.yMin >= safe.yMin-0.01 && bounds.xMax <= safe.xMax+0.01 && bounds.yMax <= safe.yMax+0.01))
                    throw new Exception("Outer frame clamping failed");
            }
            float repeated=ViewportFit.ScaleToFit((width*scale)/scale,(height*scale)/scale,safe);
            if (Math.Abs(repeated-scale)>0.00001) throw new Exception("Scale accumulated on repeated frame");
        }
        var small=new UnityEngine.Rect(8,8,1264,704);
        Assert(ViewportFit.ScaleToFit(800,700,small)==1 && ViewportFit.ScaleToFit(1144,852,small)<1, "outer frame and delivery area count beyond slot grid");
        Assert(ViewportFit.ScaleToFit(1144,852,new UnityEngine.Rect(8,8,1904,1064))==1, "larger viewport restores original scale");
        Assert(ViewportFit.ScaleToFit(0,0,small)==1 && ViewportFit.ScaleToFit(float.NaN,852,small)==1, "uninitialized dimensions handled safely");
        Console.WriteLine("PASS " + scenarios + " resolution/UI-scale/full-frame combinations, edge clamping and stable scale");
    }

}
