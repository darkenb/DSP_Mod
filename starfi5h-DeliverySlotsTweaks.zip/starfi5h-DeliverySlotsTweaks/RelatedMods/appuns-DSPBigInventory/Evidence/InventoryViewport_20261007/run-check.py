"""Run the single check for each installed mod, without starting DSP or changing saves."""
from pathlib import Path
import shutil
import subprocess
import sys

AUDIT = Path(__file__).resolve().parent
sys.path.insert(0, str(AUDIT.parent))
import build

for name, folder, assembly in [
    ('FAZ_01_DSPBigMechaStorage', 'appuns-DSPBigMechaStorage', 'DSPBigMechaStorage'),
    ('FAZ_12_DSPBigInventory', 'appuns-DSPBigInventory', 'DSPBigInventory')]:
    output = build.OUTPUT / 'InventoryViewport_20261007' / 'installed' / name
    output.mkdir(parents=True, exist_ok=True)
    target = output / (assembly + '.dll')
    shutil.copyfile(build.PLUGINS / folder / target.name, target)
    check = output / 'Check.exe'
    build.compile_cs([build.ROOT / name / 'check.cs'], check, build.references() + [target], executable=True)
    result = build.run_check(check, [build.GAME, build.CORE])
    (AUDIT / (name + '-installed-clr.log')).write_text(result.stdout + result.stderr, encoding='utf-8')
    if result.returncode: raise RuntimeError(result.stdout + result.stderr)
    result = subprocess.run([sys.executable, str(build.ROOT / 'mono-host.py'), str(check),
        str(output), str(build.GAME), str(build.CORE)], capture_output=True,
        text=True, encoding='utf-8', errors='replace', timeout=60)
    log = result.stdout + result.stderr
    (AUDIT / (name + '-installed-mono.log')).write_text(log, encoding='utf-8')
    if result.returncode or 'cant resolve' in log: raise RuntimeError(log)
    print('PASS installed', assembly, 'CLR and embedded Mono; SHA-256', build.digest(target))
