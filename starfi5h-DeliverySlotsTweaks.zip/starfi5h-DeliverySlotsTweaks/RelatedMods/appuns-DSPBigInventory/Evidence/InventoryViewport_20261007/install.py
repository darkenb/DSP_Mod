"""Install only the two checked UI fixes, with a verified rollback ZIP."""
from datetime import datetime
import hashlib
import os
from pathlib import Path
import sys
import zipfile

AUDIT = Path(__file__).resolve().parent
sys.path.insert(0, str(AUDIT.parent))
import build
import finalize as files

baseline = files.read(AUDIT / 'baseline.json')
mono = files.read(AUDIT / 'mono-checks.json')
metadata = files.read(AUDIT / 'assembly-metadata.json')
rows = []
payloads = {}
for name, version in [('FAZ_01_DSPBigMechaStorage', '1.0.8'), ('FAZ_12_DSPBigInventory', '1.0.10')]:
    phase = build.ROOT / name
    result = files.read(phase / 'build-result.json')
    assert result['version'] == version and result['checks_passed'] and result['api_findings'] == 0
    target = files.target_path(result['original_relative_path'])
    assert build.digest(target) == result['original_sha256']
    assert build.digest(Path(result['loose_output'])) == result['output_sha256']
    assert files.read(phase / 'validation.json')['passed']
    assert mono[name]['passed'] and mono[name]['dll_sha256'] == result['output_sha256']
    assert metadata[name]['built_sha256'] == result['output_sha256']
    assert metadata[name]['original_mvid'] != metadata[name]['built_mvid']
    for group in ('source_sha256', 'validation_source_sha256', 'embedded_resource_sha256'):
        for path, expected in result[group].items():
            assert build.digest(phase / path) == expected, 'Changed input: ' + path
    package = phase / (result['folder'] + '-' + version + '.zip')
    assert build.digest(package) == package.with_suffix('.zip.sha256').read_text().split()[0]
    with zipfile.ZipFile(package) as archive:
        assert archive.testzip() is None
        payload = archive.read('plugins/' + result['folder'] + '/' + target.name)
        assert hashlib.sha256(payload).hexdigest() == result['output_sha256']
    row = dict(phase=name, version=version, target=str(target), relative=result['original_relative_path'],
        previous_sha256=result['original_sha256'], output_sha256=result['output_sha256'],
        previous_mvid=metadata[name]['original_mvid'], output_mvid=metadata[name]['built_mvid'],
        package=str(package), package_sha256=build.digest(package),
        api_references=result['api_reference_count'], harmony_patches=result['harmony_patch_count'])
    assert not target.with_suffix('.dll.installing').exists(), 'Pending install file exists'
    rows.append(row)
    payloads[row['relative']] = payload

def verify_protected():
    assert build.digest(build.GAME / 'Assembly-CSharp.dll') == baseline['game_sha256']
    for path, expected in baseline['saves'].items():
        assert build.digest(Path(path)) == expected, 'Save changed: ' + path
    for path, expected in baseline['configs'].items():
        assert build.digest(build.PLUGINS.parent / 'config' / path) == expected, 'Config changed: ' + path

files.ensure_game_closed()
verify_protected()
before = {str(p.relative_to(build.PLUGINS)): build.digest(p) for p in build.PLUGINS.rglob('*.dll')}
assert before == baseline['plugins'], 'Plugin baseline changed'
assert not list((build.PLUGINS / '_calisma').rglob('*.dll')), 'Loose DLL in work directory'
folder = AUDIT / ('backup-' + datetime.now().strftime('%Y%m%d-%H%M%S'))
folder.mkdir()
backup = folder / 'previous-plugin-dlls.zip'
with zipfile.ZipFile(backup, 'w', zipfile.ZIP_DEFLATED) as archive:
    for row in rows:
        archive.write(row['target'], row['relative'].replace('\\', '/'))
with zipfile.ZipFile(backup) as archive:
    assert archive.testzip() is None
    originals = {row['relative']: archive.read(row['relative'].replace('\\', '/')) for row in rows}
    for row in rows:
        assert hashlib.sha256(originals[row['relative']]).hexdigest() == row['previous_sha256']
record = dict(status='backup_verified', phases=rows, backup=str(backup), backup_sha256=build.digest(backup),
    embedded_mono_checks_passed=True, real_game_visual_acceptance=False)
journal = folder / 'installation.json'
files.write(journal, record)
changed = []
try:
    files.ensure_game_closed()
    for row in rows:
        target = Path(row['target'])
        assert build.digest(target) == row['previous_sha256'], 'Target changed before replacement'
        pending = target.with_suffix('.dll.installing')
        pending.write_bytes(payloads[row['relative']])
        assert build.digest(pending) == row['output_sha256']
        os.replace(pending, target)
        changed.append(row)
        assert build.digest(target) == row['output_sha256']
    after = {str(p.relative_to(build.PLUGINS)): build.digest(p) for p in build.PLUGINS.rglob('*.dll')}
    expected = dict(before)
    for row in rows:
        expected[row['relative']] = row['output_sha256']
    assert after == expected, 'Unexpected plugin DLL changes'
    verify_protected()
except BaseException:
    for row in changed:
        target = Path(row['target'])
        pending = target.with_suffix('.dll.installing')
        pending.write_bytes(originals[row['relative']])
        os.replace(pending, target)
    record['status'] = 'rolled_back_after_error'
    files.write(journal, record)
    raise
finally:
    for row in rows:
        pending = Path(row['target']).with_suffix('.dll.installing')
        if pending.exists(): pending.unlink()
record.update(status='installed_and_hash_verified', unrelated_dll_count=len(before)-2,
    configs_unchanged=len(baseline['configs']), saves_unchanged=len(baseline['saves']), game_assembly_unchanged=True)
files.write(journal, record)
files.write(AUDIT / 'installation.json', record)
print('PASS both DLLs installed; other 44 DLLs, configs, saves and game assembly unchanged')
print('BACKUP', backup)
