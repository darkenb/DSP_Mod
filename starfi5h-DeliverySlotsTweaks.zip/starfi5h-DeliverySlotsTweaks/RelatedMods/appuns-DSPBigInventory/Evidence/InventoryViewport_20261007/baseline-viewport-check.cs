using System;
using System.Reflection;
using UnityEngine;
class Check {
 static int Main() {
  int failures=0;
  foreach (string name in new[]{"DSPBigInventory", "DSPBigMechaStorage"}) {
   Assembly assembly=Assembly.Load(name);
   var type=assembly.GetType(name+".ViewportFit");
   var method=type == null ? null : type.GetMethod("ScaleToFit");
   Rect available=new Rect(8,8,1264,704);
   float width=name=="DSPBigInventory"?1144:700;
   float height=name=="DSPBigInventory"?852:896;
   float scale=method==null?1:(float)method.Invoke(null,new object[]{width,height,available});
   bool fits=width*scale<=available.width+0.01f && height*scale<=available.height+0.01f;
   Console.WriteLine((fits?"PASS ":"FAIL ")+name+" full outer frame at 1280x720: "+width*scale+" x "+height*scale+", available "+available.width+" x "+available.height);
   if(!fits)failures++;
  }
  return failures==0?0:1;
 }
}