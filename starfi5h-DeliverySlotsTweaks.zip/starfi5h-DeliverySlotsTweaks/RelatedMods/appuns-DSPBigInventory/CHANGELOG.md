# appuns-DSPBigInventory — detailed change report

Installed plugin version(s): **1.0.10**. Keep inventory expansion data-safe and fit the complete window within the screen and safe area.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Safe capacity rules — 1.0.9

Use installed 1.0.8 rather than older upstream 1.0.4, which lacked delivery support.

- Clamp inventory columns to native 10–30, delivery columns to 0–5 and configured rows to 1–100; prevent divide-by-zero and arithmetic overflow.
- Treat settings as minimum capacity. Never shrink a larger loaded inventory or discard item/inc data. Preserve research expansion of inventory/delivery and stack multipliers.
- Default-size mode uses native save/research values. Do not rebuild a GenesisBook/modded save from a vanilla-only 2301–2307 technology list or automatically shrink older enlarged saves.
- Preserve current native UI, filters/sorting, delivery unlock state, 100 physical delivery slots and index mapping. Do not re-enable obsolete assembler/miner UI replacements.
- Bind config before installing Harmony; remove only owned patches on unload.

## Complete-window fitting — 1.0.10, 7 October

Measure the outer RectTransform in actual screen pixels, including title/borders and native delivery extensions, rather than estimating from the 50x50 slot grid. Fit inside `Screen.safeArea` with an 8-pixel margin using uniform scaling and translation; consider Canvas scale and windowed mode. Bind on open even for windows created before `Start`, recompute after native layout/dragging in LateUpdate, and restore the original scale on a sufficiently large screen.

Main inventory plus assembler/miner inventory windows are covered. With delivery open, the recorded native formulas are width `88 + columns*50 + (deliveryColumns*50+6)` and height `126 + rows*50 + 26`; a 16-column/14-row/5-delivery-column layout is 1144x852 UI units before Canvas scaling. Capacity and save mapping are unchanged; fitting affects presentation only.

## Validation and limits

The two viewport mods passed 336 geometry combinations, 168 each, across 720p/768p/1080p/1440p/4K/ultrawide/portrait, Canvas scales 0.75/1/1.5/2, delivery open/closed and enlarged frames. Repeated fitting did not accumulate scale; overflow was repositioned and original scale restored. Native checks covered column remapping, an item in the last slot, delivery bounds and actual Harmony research/callback behavior. Installed-DLL CLR/embedded-Mono checks passed; this mod's recorded audit had 15 references, 6 Harmony patches and no findings.

Real drawing, dragging, clicks/tooltips and item movement remain untested. Fitting extremely large windows makes slots smaller; no scrolling full-size layout was added, and geometry checks do not prove readability. The historical two-DLL installation preserved the other 44 DLLs, 34 configs, 20 saves and game Assembly-CSharp hash.

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
