# appuns-DSPBigInventory

Keep inventory expansion data-safe and fit the complete window within the screen and safe area.

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.

[Review map](REVIEW_GUIDE.md) · [Receiving package relationship index](../../RELATED_MODS.md) · [Detailed changes](CHANGELOG.md) · [Build/review notes](BUILD.md) · [Assembly metadata](metadata.json)

Prepared for maintainer review on 15 October 2026. This is a local modified build, not an official upstream release, published package or pull request.

Installed plugin version(s): **1.0.10**. Existing package manifest version: **1.0.8**. Manifest, plugin and assembly versions are separate; the original manifest is retained.

## Package layout

- `InstalledPackage/`: actual installed mod files and companion preloader when present.
- `Source/Reconstructed/`: full projects reconstructed from the exact installed assemblies.
- `Source/EarlierWorkingSource/`, `PortedWorkingSource/`, `UpstreamSnapshot/`: source snapshots when available; provenance is recorded separately.
- `Evidence/`: development helpers, focused check sources and structured validation/installation records.
- `Diffs/`: source-port patches and normalized structural IL comparison.
- `Baselines/`: previous binary and its provenance for review, not an automatic rollback.

## Plugin identifiers and declared dependencies

- `Appun.DSP.plugin.BigInventory` — DSPBigInventory 1.0.10; dependencies: none declared on this plugin.

## Installed assembly hashes

| Recorded path | SHA-256 |
|---|---|
| `plugins/appuns-DSPBigInventory/DSPBigInventory.dll` | `3853388dd4428a548e5b782c3de47bc861144814768617e24d38279d8e99ca6e` |

## Scope and limitations

Not every source project has been rebuilt. Historical compile/test evidence is limited to its recorded hashes. Headless/embedded-Mono checks do not establish real Unity UI, the user's world, all-mod startup, multiplayer or sustained-memory acceptance.
