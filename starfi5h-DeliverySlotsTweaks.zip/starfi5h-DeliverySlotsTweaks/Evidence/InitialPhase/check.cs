using System;
using System.IO;
using System.Runtime.Serialization;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using DeliverySlotsTweaks;
static class Check
{
    static T Empty<T>() => (T)FormatterServices.GetUninitializedObject(typeof(T));
    static void Set(object target, string name, object value) =>
        (AccessTools.Field(target.GetType(), name) ?? AccessTools.Field(target.GetType(), "<" + name + ">k__BackingField")).SetValue(target, value);
    static void Assert(bool value, string message) { if (!value) throw new Exception(message); Console.WriteLine("PASS " + message); }
    static int Main()
    {
        var cfg = new ConfigFile(Path.Combine(Path.GetTempPath(), "dsp-phase13-check.cfg"), false); cfg.SaveOnConfigSet = false;
        Plugin.Log = new ManualLogSource("DeliveryCheck");
        Plugin.ColCount = cfg.Bind("Test", "Columns", 1); Plugin.StackSizeMultiplier = cfg.Bind("Test", "Stack", 2);
        AccessTools.Field(typeof(StorageComponent), "staticLoaded").SetValue(null, true);
        StorageComponent.itemStackCount = new int[12000]; StorageComponent.itemStackCount[5001] = 100;
        var player = new Player(); var package = new StorageComponent(40); Set(player, "package", package);
        var delivery = new DeliveryPackage(); delivery.Init(); Set(player, "deliveryPackage", delivery);
        var data = Empty<GameData>(); Set(data, "mainPlayer", player); GameMain.data = data;
        Set(player, "packageUtility", new PlayerPackageUtility(player));
        package.grids[0] = new StorageComponent.GRID {itemId = 5001, count = 7, inc = 14, stackSize = 100};
        delivery.colCount = 1; delivery.rowCount = 2; delivery.unlocked = true;
        delivery.grids[0] = new DeliveryPackage.GRID {itemId = 5001, count = 99, inc = 99, stackSize = 100, stackSizeMultiplier = 1};
        delivery.grids[4] = new DeliveryPackage.GRID {itemId = 5001, count = 3, inc = 6, stackSize = 100, stackSizeMultiplier = 1};
        delivery.grids[9] = new DeliveryPackage.GRID {itemId = 5001, count = 2, inc = 4, stackSize = 100, stackSizeMultiplier = 1};
        DeliveryPackagePatch.maxDeliveryGridIndex = 99;
        DeliveryPackagePatch.Count(package); DeliveryPackagePatch.Count(delivery);
        Assert(DeliveryPackagePatch.GetItemCount(package, 5001) == 12, "sparse native geometry excludes inactive slot and sums duplicate imported items");
        delivery.unlocked = false; DeliveryPackagePatch.Count(delivery);
        Assert(DeliveryPackagePatch.GetItemCount(package, 5001) == 7, "locked delivery contributes no forge ingredients");
        delivery.unlocked = true; delivery.grids[9].itemId = 0; delivery.grids[9].count = 0;
        DeliveryPackagePatch.Count(delivery);
        int removed = DeliveryPackagePatch.TakeItem(package, 5001, 5, out int inc);
        Assert(removed == 5 && inc == 10 && delivery.grids[0].count == 99 && package.grids[0].count == 2 && delivery.grids[4].count == 3,
               "actual native package-first transfer preserves inactive cargo and inc");
        DSPBigInventory.DSPBigInventory.Apply(player, 16, 14, 5, false);
        delivery.stackSizeMultiplier = 10;
        AccessTools.Method(typeof(Plugin), "ParameterOverwrite").Invoke(null, null);
        Assert(delivery.colCount == 5 && delivery.stackSizeMultiplier == 10,
               "smaller DeliverySlots settings preserve BigInventory and native research values");
        DeliveryPackagePatch.Count(package); DeliveryPackagePatch.Count(delivery);
        Assert(DeliveryPackagePatch.GetItemCount(package, 5001) == 104, "newly active former inactive cargo counted after native map rebuild");
        return 0;
    }
}
