# Related mods and code references — starfi5h-DeliverySlotsTweaks

All listed copies are inside this mod folder. They are one-level reference copies with their own Source, InstalledPackage, metadata and English change notes. Required installed dependencies of those copies are flattened into the same RelatedMods directory; copies never recursively contain another RelatedMods directory.

Dependency declarations (including optional compatibility plugins), compiled member calls and native integration/test context are distinguished below. A shared native API touchpoint is not presented as a direct foreign-method call. Original game/BepInEx SDK files and uninstalled optional mods are not fabricated or downloaded. 

## BUG-DSPCompleteReplicatorQueue

Copy: `RelatedMods/BUG-DSPCompleteReplicatorQueue/`.

- **fix_integration_context**: Native crafting and delivery accounting are shared by the queue-completion and delivery-material fixes.

### Code in this mod

`Source/Reconstructed/plugins/DeliverySlotsTweaks/DeliverySlotsTweaks/DeliveryPackagePatch.cs:252`

```csharp

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(MechaForge), "TryAddTask")]
	[HarmonyPatch(typeof(MechaForge), "TryTaskWithTestPackage")]
	public static IEnumerable<CodeInstruction> TryAddTask_Transpiler(IEnumerable<CodeInstruction> instructions)
```

`Source/Reconstructed/plugins/DeliverySlotsTweaks/DeliverySlotsTweaks/UIBuildMenuPatch.cs:62`

```csharp
			return;
		}
		MechaForge forge = GameMain.mainPlayer.mecha.forge;
		int num2 = forge.PredictTaskCount(iD);
		if (num > num2)
```

`Source/EarlierWorkingSource/DeliveryPackagePatch.cs:278`

```csharp
		#endregion

		#region MechaForge

		[HarmonyTranspiler]
```

`Source/EarlierWorkingSource/UIBuildMenuPatch.cs:59`

```csharp
                return;
            }
            var mechaForge = GameMain.mainPlayer.mecha.forge;
            var predictNum = mechaForge.PredictTaskCount(id, 99);
            if (num > predictNum)
```

`Source/Reconstructed/plugins/DeliverySlotsTweaks/DeliverySlotsTweaks/Compatibility.cs:23`

```csharp
				{
					Type type = value.Instance.GetType().Assembly.GetType("Auxilaryfunction.Auxilaryfunction");
					harmony.Patch(AccessTools.Method(type, "AutoMovetounbuilt"), null, null, new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("UIBuildMenu_Transpiler")));
				}
			}
```

### Code in the related copy

`RelatedMods/BUG-DSPCompleteReplicatorQueue/Source/Reconstructed/plugins/DSPCompleteReplicatorQueue/DSPCompleteReplicatorQueue/InstantCraft.cs:5`

```csharp
public static class InstantCraft
{
	public static void CompleteAllTasks(MechaForge forge)
	{
		if (Main.Instance != null)
```

`RelatedMods/BUG-DSPCompleteReplicatorQueue/Source/Reconstructed/plugins/DSPCompleteReplicatorQueue/DSPCompleteReplicatorQueue/Main.cs:38`

```csharp
	}

	internal void Request(MechaForge forge)
	{
		if (!Busy)
```

`RelatedMods/BUG-DSPCompleteReplicatorQueue/Source/Reconstructed/plugins/DSPCompleteReplicatorQueue/DSPCompleteReplicatorQueue/QueueCompletion.cs:13`

```csharp
	private bool processing;

	public MechaForge Forge { get; private set; }

	public bool Active { get; private set; }
```

`RelatedMods/BUG-DSPCompleteReplicatorQueue/Source/Reconstructed/plugins/DSPCompleteReplicatorQueue/DSPCompleteReplicatorQueue/WindowUI.cs:20`

```csharp
	private static bool createFailed;

	private static readonly FieldInfo ForgeField = typeof(UIReplicatorWindow).GetField("mechaForge", BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

	private static MechaForge GetForge(UIReplicatorWindow window)
```

`RelatedMods/BUG-DSPCompleteReplicatorQueue/Evidence/InitialPhase/check.cs:73`

```csharp
        };
    }
    static MechaForge Forge(params ForgeTask[] tasks)
    {
        trash = trashInc = deliveries = queueComplete = scenarios = 0;
```

## appuns-DSPBigInventory

Copy: `RelatedMods/appuns-DSPBigInventory/`.

- **fix_integration_context**: Both configure delivery/inventory geometry; minimum capacities, active grids and item data must be preserved.

### Code in this mod

`Source/Reconstructed/plugins/DeliverySlotsTweaks/DeliverySlotsTweaks/Compatibility.cs:23`

```csharp
				{
					Type type = value.Instance.GetType().Assembly.GetType("Auxilaryfunction.Auxilaryfunction");
					harmony.Patch(AccessTools.Method(type, "AutoMovetounbuilt"), null, null, new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("UIBuildMenu_Transpiler")));
				}
			}
```

`Source/Reconstructed/plugins/DeliverySlotsTweaks/DeliverySlotsTweaks/DeliveryPackagePatch.cs:10`

```csharp
namespace DeliverySlotsTweaks;

public class DeliveryPackagePatch
{
	public static bool architectMode = false;
```

`Source/Reconstructed/plugins/DeliverySlotsTweaks/DeliverySlotsTweaks/Plugin.cs:50`

```csharp
	private void InitConfig()
	{
		UseLogisticSlots = base.Config.Bind("DeliveryPackage", "UseLogisticSlots", defaultValue: true, "Let replicator and build tools use items in logistic slots. (require restart)\n使手动制造和建筑工具可以使用物流清单内的物品");
		AutoRefillFuel = base.Config.Bind("DeliveryPackage", "AutoRefillFuel", defaultValue: false, "Allow fuel chamber to also take from logistics slots. (require restart)\n自动补充燃料时也会使用物流清单内的物品");
		AutoRefillWarper = base.Config.Bind("DeliveryPackage", "AutoRefillWarper", defaultValue: false, "Auto refill space warper from inventory and logistics slots.\n从背包和物流清单自动补充翘曲器");
```

`Evidence/InitialPhase/check.cs:22`

```csharp
        StorageComponent.itemStackCount = new int[12000]; StorageComponent.itemStackCount[5001] = 100;
        var player = new Player(); var package = new StorageComponent(40); Set(player, "package", package);
        var delivery = new DeliveryPackage(); delivery.Init(); Set(player, "deliveryPackage", delivery);
        var data = Empty<GameData>(); Set(data, "mainPlayer", player); GameMain.data = data;
        Set(player, "packageUtility", new PlayerPackageUtility(player));
```

`Source/EarlierWorkingSource/Compatibility.cs:12`

```csharp
    {
        public static bool IsArchitectModeModExist { get; private set; } = false;
        public static bool IsDeliveryPackageModExist { get; private set; } = false;

        public static void Init(Harmony harmony)
```

### Code in the related copy

`RelatedMods/appuns-DSPBigInventory/Source/Reconstructed/plugins/DSPBigInventory/DSPBigInventory/DSPBigInventory.cs:64`

```csharp
				player.package.SetSize(num2);
			}
			if (player.deliveryPackage != null)
			{
				player.deliveryPackage.colCount = Math.Max(player.deliveryPackage.colCount, Clamp(deliveryColumns, 0, 5));
```

`RelatedMods/appuns-DSPBigInventory/Evidence/InitialPhase/check.cs:19`

```csharp
        var player = new Player(); var package = new StorageComponent(400);
        Set(player, "package", package); player.packageColCount = 10;
        var delivery = new DeliveryPackage(); delivery.Init(); Set(player, "deliveryPackage", delivery);
        delivery.colCount = 2; delivery.stackSizeMultiplier = 8; delivery.unlocked = false;
        package.grids[399] = new StorageComponent.GRID {itemId = 5001, count = 17, inc = 51, stackSize = 100};
```

`RelatedMods/appuns-DSPBigInventory/Source/EarlierWorkingSource/DSPBigInventory.cs:43`

```csharp
            if (newColumns != oldColumns) player.package.SetSize(target, oldColumns, newColumns);
            else if (player.package.size < target) player.package.SetSize(target);
            if (player.deliveryPackage != null)
            {
                player.deliveryPackage.colCount = Math.Max(player.deliveryPackage.colCount, Clamp(deliveryColumns, 0, 5));
```

## appuns-DSPMultiDistributor

Copy: `RelatedMods/appuns-DSPMultiDistributor/`.

- **fix_integration_context**: Multi-item matching and material accounting share active delivery geometry and native rematching.

### Code in this mod

`Source/Reconstructed/plugins/DeliverySlotsTweaks/DeliverySlotsTweaks/Compatibility.cs:23`

```csharp
				{
					Type type = value.Instance.GetType().Assembly.GetType("Auxilaryfunction.Auxilaryfunction");
					harmony.Patch(AccessTools.Method(type, "AutoMovetounbuilt"), null, null, new HarmonyMethod(typeof(DeliveryPackagePatch).GetMethod("UIBuildMenu_Transpiler")));
				}
			}
```

`Source/Reconstructed/plugins/DeliverySlotsTweaks/DeliverySlotsTweaks/DeliveryPackagePatch.cs:10`

```csharp
namespace DeliverySlotsTweaks;

public class DeliveryPackagePatch
{
	public static bool architectMode = false;
```

`Source/Reconstructed/plugins/DeliverySlotsTweaks/DeliverySlotsTweaks/Plugin.cs:50`

```csharp
	private void InitConfig()
	{
		UseLogisticSlots = base.Config.Bind("DeliveryPackage", "UseLogisticSlots", defaultValue: true, "Let replicator and build tools use items in logistic slots. (require restart)\n使手动制造和建筑工具可以使用物流清单内的物品");
		AutoRefillFuel = base.Config.Bind("DeliveryPackage", "AutoRefillFuel", defaultValue: false, "Allow fuel chamber to also take from logistics slots. (require restart)\n自动补充燃料时也会使用物流清单内的物品");
		AutoRefillWarper = base.Config.Bind("DeliveryPackage", "AutoRefillWarper", defaultValue: false, "Auto refill space warper from inventory and logistics slots.\n从背包和物流清单自动补充翘曲器");
```

`Evidence/InitialPhase/check.cs:22`

```csharp
        StorageComponent.itemStackCount = new int[12000]; StorageComponent.itemStackCount[5001] = 100;
        var player = new Player(); var package = new StorageComponent(40); Set(player, "package", package);
        var delivery = new DeliveryPackage(); delivery.Init(); Set(player, "deliveryPackage", delivery);
        var data = Empty<GameData>(); Set(data, "mainPlayer", player); GameMain.data = data;
        Set(player, "packageUtility", new PlayerPackageUtility(player));
```

`Source/EarlierWorkingSource/Compatibility.cs:12`

```csharp
    {
        public static bool IsArchitectModeModExist { get; private set; } = false;
        public static bool IsDeliveryPackageModExist { get; private set; } = false;

        public static void Init(Harmony harmony)
```

### Code in the related copy

`RelatedMods/appuns-DSPMultiDistributor/Evidence/InitialPhase/check.cs:15`

```csharp
        var storage = new StorageComponent(3);
        storage.grids[0].filter = 5001; storage.grids[1].filter = 5001; storage.grids[2].filter = 5002;
        var delivery = new DeliveryPackage(); delivery.Init();
        GameMain.data = Empty<GameData>(); GameMain.data.history = new GameHistoryData {logisticCourierCarries = 5};
        GameMain.data.factories = new PlanetFactory[0];
```

`RelatedMods/appuns-DSPMultiDistributor/Source/Reconstructed/plugins/DSPMultiDistributor/DSPMultiDistributor/Main.cs:98`

```csharp
	public static void UIDispenserWindow_OnClose_Prefix2(UIDispenserWindow __instance)
	{
		AccessTools.FieldRefAccess<UIDispenserWindow, PlanetTransport>(__instance, "transport")?.RefreshDispenserTraffic();
	}

```

`RelatedMods/appuns-DSPMultiDistributor/Source/EarlierWorkingSource/Plugin.cs:90`

```csharp
	public static void UIDispenserWindow_OnClose_Prefix2(UIDispenserWindow __instance)
	{
		AccessTools.FieldRefAccess<UIDispenserWindow, PlanetTransport>(__instance, "transport")?.RefreshDispenserTraffic();
	}

```

## blacksnipebiu-Multfuntion_mod

Copy: `RelatedMods/blacksnipebiu-Multfuntion_mod/`.

- **declared_soft_dependency**: Plugin-level dependency declaration; this may belong to an optional compatibility plugin.

### Code in this mod

`Source/Reconstructed/plugins/DeliverySlotsTweaks/DeliverySlotsTweaks/Compatibility.cs:98`

```csharp
	public static class Multfunction_mod_Patch
	{
		public const string GUID = "cn.blacksnipe.dsp.Multfuntion_mod";

		private static ConfigEntry<bool> architectMode;
```

`Source/Reconstructed/plugins/DeliverySlotsTweaks/DeliverySlotsTweaks/Plugin.cs:10`

```csharp

[BepInPlugin("starfi5h.plugin.DeliverySlotsTweaks", "DeliverySlotsTweaks", "1.5.21")]
[BepInDependency("cn.blacksnipe.dsp.Multfuntion_mod", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class Plugin : BaseUnityPlugin
```

`Source/EarlierWorkingSource/Compatibility.cs:111`

```csharp
        public static class Multfunction_mod_Patch
        {
            public const string GUID = "cn.blacksnipe.dsp.Multfuntion_mod";
            static ConfigEntry<bool> architectMode = null;

```

### Code in the related copy

`RelatedMods/blacksnipebiu-Multfuntion_mod/Source/PortedWorkingSource/Multifunction_mod/Multifunction.cs:14`

```csharp
namespace Multifunction_mod;

[BepInPlugin("cn.blacksnipe.dsp.Multfuntion_mod", "Multfuntion_mod", "4.0.7")]
public class Multifunction : BaseUnityPlugin
{
```

`RelatedMods/blacksnipebiu-Multfuntion_mod/Source/PortedWorkingSource/Multifunction_mod/Multifunctionpatch.cs:15`

```csharp
	public static void Patchallmethod()
	{
		harmony = new Harmony("cn.blacksnipe.dsp.Multfuntion_mod");
		MethodInfo[] methods = typeof(StorageComponent).GetMethods();
		MethodInfo[] array = methods;
```

`RelatedMods/blacksnipebiu-Multfuntion_mod/Source/PortedWorkingSource/Multifunction_mod.Patchs/EjectAnywayPatch.cs:13`

```csharp
	private static bool enable;

	public static string Patchid => "cn.blacksnipe.dsp.Multfuntion_mod.EjectAnywayPatch";

	public static bool Enable
```

`RelatedMods/blacksnipebiu-Multfuntion_mod/Source/PortedWorkingSource/Multifunction_mod.Patchs/SkipBulletPatch.cs:22`

```csharp
	private static bool enable;

	public static string Patchid => "cn.blacksnipe.dsp.Multfuntion_mod.SkipBulletPatch";

	public static bool Enable
```

`RelatedMods/blacksnipebiu-Multfuntion_mod/Source/Reconstructed/plugins/Multifunction_mod/Multifunction_mod/Multifunction.cs:14`

```csharp
namespace Multifunction_mod;

[BepInPlugin("cn.blacksnipe.dsp.Multfuntion_mod", "Multfuntion_mod", "4.0.7")]
public class Multifunction : BaseUnityPlugin
{
```

## nebula-NebulaMultiplayerModApi

Copy: `RelatedMods/nebula-NebulaMultiplayerModApi/`.

- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Actual compiled code references

```text
System.Boolean DeliverySlotsTweaks.Compatibility/Nebula_Patch::IsOthers()
  Call -> NebulaAPI.GameState.IMultiplayerSession NebulaAPI.NebulaModAPI::get_MultiplayerSession()
```

```text
System.Boolean DeliverySlotsTweaks.Compatibility/Nebula_Patch::IsOthers()
  Callvirt -> NebulaAPI.GameState.IFactoryManager NebulaAPI.GameState.IMultiplayerSession::get_Factories()
```

```text
System.Boolean DeliverySlotsTweaks.Compatibility/Nebula_Patch::IsOthers()
  Callvirt -> NebulaAPI.Interfaces.IToggle NebulaAPI.GameState.IFactoryManager::get_IsIncomingRequest()
```

```text
System.Boolean DeliverySlotsTweaks.Compatibility/Nebula_Patch::IsOthers()
  Callvirt -> System.Boolean NebulaAPI.Interfaces.IToggle::get_Value()
```

```text
System.Boolean DeliverySlotsTweaks.Compatibility/Nebula_Patch::IsOthers()
  Callvirt -> System.Int32 NebulaAPI.GameState.IFactoryManager::get_PacketAuthor()
```

```text
System.Boolean DeliverySlotsTweaks.Compatibility/Nebula_Patch::IsOthers()
  Callvirt -> NebulaAPI.GameState.ILocalPlayer NebulaAPI.GameState.IMultiplayerSession::get_LocalPlayer()
```

```text
System.Boolean DeliverySlotsTweaks.Compatibility/Nebula_Patch::IsOthers()
  Callvirt -> System.UInt16 NebulaAPI.GameState.ILocalPlayer::get_Id()
```

```text
System.Void DeliverySlotsTweaks.Compatibility/Nebula_Patch::Patch(HarmonyLib.Harmony)
  Call -> System.Boolean NebulaAPI.NebulaModAPI::get_NebulaIsInstalled()
```

```text
System.Void DeliverySlotsTweaks.Compatibility/Nebula_Patch::Patch(HarmonyLib.Harmony)
  Ldsfld -> System.Action NebulaAPI.NebulaModAPI::OnMultiplayerGameStarted
```

```text
System.Void DeliverySlotsTweaks.Compatibility/Nebula_Patch::Patch(HarmonyLib.Harmony)
  Ldsfld -> System.Action NebulaAPI.NebulaModAPI::OnMultiplayerGameEnded
```

```text
System.Void DeliverySlotsTweaks.Compatibility/Nebula_Patch::OnMultiplayerGameStarted()
  Call -> System.Boolean NebulaAPI.NebulaModAPI::get_IsMultiplayerActive()
```

### Code in this mod

`Source/Reconstructed/plugins/DeliverySlotsTweaks/DeliverySlotsTweaks/Compatibility.cs:155`

```csharp
		public static bool IsOthers()
		{
			IFactoryManager factories = NebulaModAPI.MultiplayerSession.Factories;
			if (factories.IsIncomingRequest.Value)
			{
```

`Source/EarlierWorkingSource/Compatibility.cs:164`

```csharp
            public static bool IsOthers() // Action triggered by packets from other player
            {
                var factoryManager = NebulaModAPI.MultiplayerSession.Factories;
                return factoryManager.IsIncomingRequest.Value && factoryManager.PacketAuthor != NebulaModAPI.MultiplayerSession.LocalPlayer.Id;
            }
```

### Code in the related copy

`RelatedMods/nebula-NebulaMultiplayerModApi/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs:15`

```csharp
[BepInPlugin("dsp.nebula-multiplayer-api", "NebulaMultiplayerModApi", "2.1.0.7")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class NebulaModAPI : BaseUnityPlugin
{
	public const string NEBULA_MODID = "dsp.nebula-multiplayer";
```

`RelatedMods/nebula-NebulaMultiplayerModApi/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/ConcurrentPlayerCollection.cs:116`

```csharp
	{
		List<IPlayerData> list = playerCollections[EConnectionStatus.Connected].Select((KeyValuePair<INebulaConnection, INebulaPlayer> p) => p.Value.Data).ToList();
		if (!NebulaModAPI.MultiplayerSession.IsDedicated)
		{
			list.Add(NebulaModAPI.MultiplayerSession.LocalPlayer.Data);
```

`RelatedMods/nebula-NebulaMultiplayerModApi/Evidence/InitialPhase/check.cs:9`

```csharp
    static int Main()
    {
        NebulaModAPI.OnMultiplayerSessionChange(false);
        if (NebulaModAPI.IsMultiplayerActive || NebulaModAPI.MultiplayerSession != null) throw new Exception("Inactive API retained session");
        var value = new Float3(1, 2, 3);
```

`RelatedMods/nebula-NebulaMultiplayerModApi/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.GameState/IMultiplayerSession.cs:3`

```csharp
namespace NebulaAPI.GameState;

public interface IMultiplayerSession
{
	INetworkProvider Network { get; set; }
```

`RelatedMods/nebula-NebulaMultiplayerModApi/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.GameState/IFactoryManager.cs:6`

```csharp
namespace NebulaAPI.GameState;

public interface IFactoryManager : IDisposable
{
	IToggle IsIncomingRequest { get; }
```

## Declared mods not installed in this profile

These are recorded declarations, not supplied copies or newly established requirements for the main plugin. Some belong to optional/inactive compatibility plugins.

- `dsp.nebula-multiplayer` for `starfi5h.plugin.DeliverySlotsTweaks` (soft).
