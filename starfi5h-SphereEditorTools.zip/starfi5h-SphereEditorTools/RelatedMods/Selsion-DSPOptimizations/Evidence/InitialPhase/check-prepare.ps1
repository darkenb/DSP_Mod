param([string]$Game, [string]$Core, [string]$Output)
$ErrorActionPreference = 'Stop'
& (Join-Path $PSScriptRoot 'prepare-reference.ps1') -Game $Game -Core $Core -Output $Output
