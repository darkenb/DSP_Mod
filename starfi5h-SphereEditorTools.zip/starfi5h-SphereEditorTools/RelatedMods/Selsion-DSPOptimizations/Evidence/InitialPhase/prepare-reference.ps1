param([string]$Game, [string]$Core, [string]$Output)
$ErrorActionPreference = 'Stop'
$plugins = Split-Path (Split-Path (Split-Path $PSScriptRoot))
$preloader = Join-Path (Split-Path $plugins) 'patchers/Selsion-DSPOptimizations/DSPOptimizationsPreloader.dll'
Add-Type -Path (Join-Path $Core 'Mono.Cecil.dll')
Add-Type -Path (Join-Path $Core 'Mono.Cecil.Rocks.dll')
[Reflection.Assembly]::LoadFrom((Join-Path $Game 'UnityEngine.CoreModule.dll')) | Out-Null
[Reflection.Assembly]::LoadFrom((Join-Path $Game 'UnityEngine.dll')) | Out-Null
[Reflection.Assembly]::LoadFrom((Join-Path $Core 'BepInEx.dll')) | Out-Null
[Reflection.Assembly]::LoadFrom($preloader) | Out-Null
$original = Join-Path $Game 'Assembly-CSharp.dll'
$hash = (Get-FileHash -LiteralPath $original).Hash
$resolver = New-Object Mono.Cecil.DefaultAssemblyResolver
$resolver.AddSearchDirectory($Game); $resolver.AddSearchDirectory($Core)
$reader = New-Object Mono.Cecil.ReaderParameters
$reader.AssemblyResolver = $resolver
$assembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($original, $reader)
try {
    [DSPOptimizations.Preloader]::Initialize()
    [DSPOptimizations.Preloader]::Patch($assembly)
    function Publish-Type($type) {
        if ($type.IsNested) { $type.IsNestedPublic = $true } else { $type.IsPublic = $true }
        foreach ($field in $type.Fields) { if (-not ($type.Events | Where-Object Name -eq $field.Name)) { $field.IsPublic = $true } }
        foreach ($method in $type.Methods) { $method.IsPublic = $true }
        foreach ($nested in $type.NestedTypes) { Publish-Type $nested }
    }
    foreach ($type in $assembly.MainModule.Types) { Publish-Type $type }
    [IO.Directory]::CreateDirectory($Output) | Out-Null
    $assembly.Write((Join-Path $Output 'Assembly-CSharp.dll'))
} finally { $assembly.Dispose() }
if ((Get-FileHash -LiteralPath $original).Hash -ne $hash) { throw 'Original game changed' }
Write-Output 'Installed preloader field contract prepared in Temp; native method bodies unchanged.'
