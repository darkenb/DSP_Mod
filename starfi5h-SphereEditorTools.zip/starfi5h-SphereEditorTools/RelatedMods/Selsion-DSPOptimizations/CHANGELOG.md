# Selsion-DSPOptimizations — detailed change report

Installed plugin version(s): **1.1.21**. Retain optimization behavior while declaring the existing save dependency and improving patch failure diagnostics.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Conservative optimization compatibility — 1.1.20/1.1.21

Prepare a disposable compile reference with the installed preloader's existing field contract; leave the actual game and preloader untouched. Native scheduling already owns station jobs, so commented-out `StationStorageOpt` remains disabled, as do ChargerOpt/ReceiverOpt/PCStateOpt/EntityNeedsOpt experiments. Do not replace the game's newer lens calculations.

- Declare the already required `CommonAPI-DSPModSave-1.2.2` dependency in the prepared manifest.
- Log patch failure type and message alongside the stack trace.
- Keep version-2 save data exactly four bytes and retain public ABI/GUID contracts.
- The 1.1.21 build adds `/unsafe+` metadata; private native access was tested in game Mono.

Actual native `BeforeGameTick` tests applied the existing Dyson optimization and matched vanilla node/frame/shell totals, swarm and real Dark Fog hive debuff calculations while preserving cache/demand resets. Only profiler entry/exit were skipped in the test process; the energy method body was retained.

Reflection listed CommandManager, DysonNodeOpt, LayerDismantleOpt, LowResShellsLegacySupport, MonitorOpt, ShellShaderVarOpt and SphereBufferOpt. The audit checked 187 API references and 55 declared Harmony targets; that count includes disabled experiments and is not an active-patch count. Desktop checks establish neither GPU behavior nor speedup. Real UPS/performance and LossyCompression integration need live testing.

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
