# Selsion-DSPOptimizations

Retain optimization behavior while declaring the existing save dependency and improving patch failure diagnostics.

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.

[Review map](REVIEW_GUIDE.md) · [Receiving package relationship index](../../RELATED_MODS.md) · [Detailed changes](CHANGELOG.md) · [Build/review notes](BUILD.md) · [Assembly metadata](metadata.json)

Prepared for maintainer review on 15 October 2026. This is a local modified build, not an official upstream release, published package or pull request.

Installed plugin version(s): **1.1.21**. Existing package manifest version: **1.1.19**. Manifest, plugin and assembly versions are separate; the original manifest is retained.

## Package layout

- `InstalledPackage/`: actual installed mod files and companion preloader when present.
- `Source/Reconstructed/`: full projects reconstructed from the exact installed assemblies.
- `Source/EarlierWorkingSource/`, `PortedWorkingSource/`, `UpstreamSnapshot/`: source snapshots when available; provenance is recorded separately.
- `Evidence/`: development helpers, focused check sources and structured validation/installation records.
- `Diffs/`: source-port patches and normalized structural IL comparison.
- `Baselines/`: previous binary and its provenance for review, not an automatic rollback.

## Plugin identifiers and declared dependencies

- `com.Selsion.DSPOptimizations` — DSPOptimizations 1.1.21; dependencies: crecheng.DSPModSave | hard.

## Installed assembly hashes

| Recorded path | SHA-256 |
|---|---|
| `plugins/Selsion-DSPOptimizations/DSPOptimizations.dll` | `6573a749e5cb02bb6e029664a9ac0122e47e2f02f2852ad7b37532a51db6331d` |
| `patchers/Selsion-DSPOptimizations/DSPOptimizationsPreloader.dll` | `f8d41d1b781cfd60952cfa06f645d66dd4ac6bdae80b3d5eb3cc5b3b88c4332b` |

## Scope and limitations

Not every source project has been rebuilt. Historical compile/test evidence is limited to its recorded hashes. Headless/embedded-Mono checks do not establish real Unity UI, the user's world, all-mod startup, multiplayer or sustained-memory acceptance.
