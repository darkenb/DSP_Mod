using System;
using HarmonyLib;
using PowerNetworkStructures;

namespace DSPOptimizations;

[Optimization("ChargerOpt", "", false, new Type[] { })]
internal class ChargerOpt
{
	private class Patch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(PowerSystem), "Import")]
		public static void ImportPatch(PowerSystem __instance)
		{
			__instance.substationEnergyDemand = 0L;
			for (int i = 1; i < __instance.netCursor; i++)
			{
				PowerNetwork powerNetwork = __instance.netPool[i];
				if (powerNetwork == null || powerNetwork.id != i)
				{
					continue;
				}
				foreach (Node node in powerNetwork.nodes)
				{
					int id = node.id;
					if (__instance.nodePool[id].id == id && __instance.nodePool[id].isCharger)
					{
						if (IsSubstation(__instance, id))
						{
							__instance.substationEnergyDemand += __instance.nodePool[id].idleEnergyPerTick;
						}
						else
						{
							AddCharger(__instance, id);
						}
					}
				}
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(PowerSystem), "NewNodeComponent")]
		public static void AddNodePatch(PowerSystem __instance, int __result)
		{
			if (__instance.nodePool[__result].isCharger)
			{
				if (IsSubstation(__instance, __result))
				{
					__instance.substationEnergyDemand += __instance.nodePool[__result].idleEnergyPerTick;
				}
				else
				{
					AddCharger(__instance, __result);
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(PowerSystem), "RemoveNodeComponent")]
		public static void RemoveNodePatch(PowerSystem __instance, int id)
		{
			if (__instance.nodePool[id].isCharger)
			{
				if (IsSubstation(__instance, id))
				{
					__instance.substationEnergyDemand -= __instance.nodePool[id].idleEnergyPerTick;
				}
				else
				{
					RemoveCharger(__instance, id);
				}
			}
		}
	}

	private const int INITIAL_CHARGER_POOL_SIZE = 8;

	private static void SetChargerCapacity(PowerSystem powerSystem, int newCapacity)
	{
		int[] chargerPool = powerSystem.chargerPool;
		powerSystem.chargerPool = new int[newCapacity];
		if (chargerPool != null)
		{
			int num = chargerPool.Length;
			Array.Copy(chargerPool, powerSystem.chargerPool, (newCapacity > num) ? num : newCapacity);
		}
	}

	private static void AddCharger(PowerSystem powerSystem, int nodeId)
	{
		if (powerSystem.chargerPool == null)
		{
			SetChargerCapacity(powerSystem, 8);
			powerSystem.chargerCursor = 0;
		}
		else if (powerSystem.chargerCursor == powerSystem.chargerPool.Length)
		{
			SetChargerCapacity(powerSystem, powerSystem.chargerCursor * 2);
		}
		powerSystem.chargerPool[powerSystem.chargerCursor] = nodeId;
		powerSystem.chargerCursor++;
	}

	private static void RemoveCharger(PowerSystem powerSystem, int nodeId)
	{
		int i;
		for (i = 0; i < powerSystem.chargerCursor && powerSystem.chargerPool[i] != nodeId; i++)
		{
		}
		if (i != powerSystem.chargerCursor)
		{
			int num = powerSystem.chargerCursor - 1;
			if (i < num)
			{
				powerSystem.chargerPool[i] = powerSystem.chargerPool[num];
			}
			powerSystem.chargerPool[num] = 0;
			powerSystem.chargerCursor--;
		}
	}

	private static bool IsSubstation(PowerSystem powerSystem, int nodeId)
	{
		return powerSystem.nodePool[nodeId].coverRadius >= 15f;
	}
}
