using System;

namespace DSPOptimizations;

[AttributeUsage(AttributeTargets.Method, AllowMultiple = false, Inherited = false)]
public class CommandAttribute : Attribute
{
	private string name;

	public string Name => name;

	public CommandAttribute(string name)
	{
		this.name = name;
	}
}
