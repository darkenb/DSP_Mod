using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;

namespace DSPOptimizations;

[RunPatches(typeof(Patch))]
[Optimization("SphereBufferOpt", "Reduces lag for hidden layers under construction", false, new Type[] { })]
internal class SphereBufferOpt : OptimizationSet
{
	private class Patch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonSphereSegmentRenderer), "Init")]
		public static void InitBatchMasks_Postfix(DysonSphereSegmentRenderer __instance)
		{
			__instance.layersDirtyMask = new int[DysonSphereSegmentRenderer.protoMeshes.Length];
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonSphere), "UpdateProgress", new Type[] { typeof(DysonNode) })]
		public static void BatchMask_UpdateProgress_Postfix1(DysonSphere __instance, DysonNode node)
		{
			__instance.modelRenderer.layersDirtyMask[node.protoId] |= 1 << node.layerId;
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonSphere), "UpdateProgress", new Type[] { typeof(DysonFrame) })]
		public static void BatchMask_UpdateProgress_Postfix2(DysonSphere __instance, DysonFrame frame)
		{
			__instance.modelRenderer.layersDirtyMask[frame.protoId] |= 1 << frame.layerId;
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonSphereSegmentRenderer), "RebuildModels")]
		public static void DysonSphereSegmentRenderer_RebuildModels_Postfix(DysonSphereSegmentRenderer __instance)
		{
			for (int i = 0; i < DysonSphereSegmentRenderer.totalProtoCount; i++)
			{
				__instance.layersDirtyMask[i] = -1;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonSphere), "UpdateStates", new Type[]
		{
			typeof(DysonNode),
			typeof(uint),
			typeof(bool),
			typeof(bool)
		})]
		public static void DysonSphere_UpdateStates_Postfix1(DysonSphere __instance, DysonNode node)
		{
			__instance.modelRenderer.layersDirtyMask[node.protoId] |= 1 << node.layerId;
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonSphere), "UpdateStates", new Type[]
		{
			typeof(DysonFrame),
			typeof(uint),
			typeof(bool),
			typeof(bool)
		})]
		public static void DysonSphere_UpdateStates_Postfix2(DysonSphere __instance, DysonFrame frame)
		{
			__instance.modelRenderer.layersDirtyMask[frame.protoId] |= 1 << frame.layerId;
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(DysonSphereSegmentRenderer), "DrawModels")]
		private static IEnumerable<CodeInstruction> DrawModels_SyncBuffers_Patch(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(DysonSphereSegmentRenderer.Batch), "SyncBufferData"))).Advance(-3).SetOpcodeAndAdvance(OpCodes.Nop)
				.Advance(1)
				.RemoveInstructions(2)
				.InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_2), new CodeInstruction(OpCodes.Ldarg_3), Transpilers.EmitDelegate<Action<DysonSphereSegmentRenderer, int, int, int>>(delegate(DysonSphereSegmentRenderer renderer, int batchIdx, int editorMask, int gameMask)
				{
					if ((((DysonSphere.renderPlace == ERenderPlace.Dysonmap) ? editorMask : gameMask) & renderer.layersDirtyMask[batchIdx]) != 0)
					{
						renderer.batches[batchIdx].SyncBufferData();
						renderer.layersDirtyMask[batchIdx] = 0;
					}
				}));
			return codeMatcher.InstructionEnumeration();
		}
	}
}
