using System;
using System.Collections.Generic;

namespace DSPOptimizations;

internal static class Utils
{
	private static Random rng = new Random();

	public static void Shuffle<T>(this IList<T> list, int n = -1)
	{
		if (n == -1)
		{
			n = list.Count;
		}
		while (n > 1)
		{
			list.RandomPrefixSwap(--n);
		}
	}

	public static void RandomPrefixSwap<T>(this IList<T> list, int idx)
	{
		int index = rng.Next(idx + 1);
		T value = list[index];
		list[index] = list[idx];
		list[idx] = value;
	}

	public static int LowerBound<T>(IList<T> list, T val) where T : IComparable<T>
	{
		return LowerBound(list, val, 0, list.Count);
	}

	public static int LowerBound<T>(IList<T> list, T val, int low, int high) where T : IComparable<T>
	{
		while (low < high)
		{
			int num = low + (high - low) / 2;
			if (val.CompareTo(list[num]) <= 0)
			{
				high = num;
			}
			else
			{
				low = num + 1;
			}
		}
		return low;
	}
}
