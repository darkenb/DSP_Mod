using System;
using System.Reflection;
using HarmonyLib;

namespace DSPOptimizations;

internal class PatchManager
{
	public static void Init(Harmony harmony)
	{
		Type[] types = Assembly.GetExecutingAssembly().GetTypes();
		foreach (Type type in types)
		{
			try
			{
				foreach (Attribute customAttribute in type.GetCustomAttributes())
				{
					if (customAttribute is RunPatchesAttribute)
					{
						harmony.PatchAll((customAttribute as RunPatchesAttribute).Patches);
					}
				}
			}
			catch (Exception ex)
			{
				Plugin.logger.LogError("PatchManager error: " + type.Name + "\n" + ex);
			}
		}
	}
}
