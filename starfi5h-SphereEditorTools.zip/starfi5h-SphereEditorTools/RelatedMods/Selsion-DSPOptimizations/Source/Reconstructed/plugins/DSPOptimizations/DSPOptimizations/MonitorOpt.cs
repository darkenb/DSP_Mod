using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;

namespace DSPOptimizations;

[RunPatches(typeof(Patch))]
[Optimization("MonitorOpt", "Optimizes the game logic for traffic monitors", false, new Type[] { })]
internal class MonitorOpt : OptimizationSet
{
	private class Patch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(MonitorComponent), "SetEmpty")]
		[HarmonyPatch(typeof(MonitorComponent), "Import")]
		public static void InitIdxPatch(ref MonitorComponent __instance)
		{
			__instance.startIdx = 0;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(MonitorComponent), "Export")]
		[HarmonyPatch(typeof(MonitorComponent), "SetPeriodTickCount")]
		public static void ResizeArraysPatch(ref MonitorComponent __instance)
		{
			ResetArrays(ref __instance);
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UIMonitorWindow), "_OnUpdate")]
		public static void WindowPatch(UIMonitorWindow __instance)
		{
			if (__instance.monitorAvailable && __instance.monitorId != 0 && __instance.factory != null)
			{
				ResetArrays(ref __instance.cargoTraffic.monitorPool[__instance.monitorId]);
			}
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(MonitorComponent), "InternalUpdate")]
		private static IEnumerable<CodeInstruction> UpdatePatch(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			LocalBuilder operand = generator.DeclareLocal(typeof(int));
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(MonitorComponent), "cargoFlow"))).Advance(-2).InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(MonitorComponent), "startIdx")), new CodeInstruction(OpCodes.Stloc_S, operand));
			codeMatcher.Advance(5).SetInstruction(new CodeInstruction(OpCodes.Ldloc_S, operand));
			for (int i = 0; i < 2; i++)
			{
				codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(Array), "Copy", new Type[5]
				{
					typeof(Array),
					typeof(int),
					typeof(Array),
					typeof(int),
					typeof(int)
				})));
				codeMatcher.Advance(-10).SetOpcodeAndAdvance(OpCodes.Nop).RemoveInstructions(10);
			}
			codeMatcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(MonitorComponent), "startIdx")), new CodeInstruction(OpCodes.Ldc_I4_1), new CodeInstruction(OpCodes.Add), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(MonitorComponent), "periodTickCount")), new CodeInstruction(OpCodes.Rem), new CodeInstruction(OpCodes.Stfld, AccessTools.Field(typeof(MonitorComponent), "startIdx")));
			for (int j = 0; j < 2; j++)
			{
				codeMatcher.Advance(2).RemoveInstructions(4).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand))
					.Advance(2);
			}
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(MonitorComponent), "cargoBytesArray")));
			for (int k = 0; k < 2; k++)
			{
				codeMatcher.Advance(2).RemoveInstructions(4).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand))
					.Advance(3);
			}
			return codeMatcher.InstructionEnumeration();
		}
	}

	private const int MAX_TICK_COUNT = 3600;

	private static int[] COPY_BUFFER = new int[3600];

	private static sbyte[] COPY_BUFFER_2 = new sbyte[3600];

	private static void ResetArrays(ref MonitorComponent monitor)
	{
		if (monitor.startIdx != 0)
		{
			int num = monitor.periodTickCount - monitor.startIdx;
			Array.Copy(monitor.periodCargoBytesArray, monitor.startIdx, COPY_BUFFER, 0, num);
			Array.Copy(monitor.periodCargoBytesArray, 0, COPY_BUFFER, num, monitor.startIdx);
			Array.Copy(COPY_BUFFER, monitor.periodCargoBytesArray, monitor.periodTickCount);
			Array.Copy(monitor.cargoBytesArray, monitor.startIdx, COPY_BUFFER_2, 0, num);
			Array.Copy(monitor.cargoBytesArray, 0, COPY_BUFFER_2, num, monitor.startIdx);
			Array.Copy(COPY_BUFFER_2, monitor.cargoBytesArray, monitor.periodTickCount);
			monitor.startIdx = 0;
		}
	}
}
