using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;

namespace DSPOptimizations;

[RunPatches(typeof(Patch))]
[Optimization("LayerDismantleOpt", "", false, new Type[] { })]
public class LayerDismantleOpt
{
	private class Patch
	{
		[HarmonyTranspiler]
		[HarmonyPatch(typeof(DysonSphereLayer), "RemoveDysonFrame")]
		[HarmonyPatch(typeof(DysonSphereLayer), "RemoveDysonNode")]
		private static IEnumerable<CodeInstruction> RemoveRebuildModelsCall(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(DysonSphereLayer), "dysonSphere")), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(DysonSphere), "modelRenderer")), new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(DysonSphereSegmentRenderer), "RebuildModels"))).Advance(1).CreateLabel(out var label)
				.Advance(-4)
				.InsertAndAdvance(new CodeInstruction(OpCodes.Ldsfld, AccessTools.Field(typeof(LayerDismantleOpt), "dismantling")), new CodeInstruction(OpCodes.Brtrue, label));
			return codeMatcher.InstructionEnumeration();
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(DysonSphereLayer), "RemoveAllStructure")]
		public static void DismantlePrefix(DysonSphereLayer __instance)
		{
			dismantling = true;
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonSphereLayer), "RemoveAllStructure")]
		public static void DismantlePostfix(DysonSphereLayer __instance)
		{
			__instance.dysonSphere.modelRenderer.RebuildModels();
			dismantling = false;
		}
	}

	public static bool dismantling;
}
