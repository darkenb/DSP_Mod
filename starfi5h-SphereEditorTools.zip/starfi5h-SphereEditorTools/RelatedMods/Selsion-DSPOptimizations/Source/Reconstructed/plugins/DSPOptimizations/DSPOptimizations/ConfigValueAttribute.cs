using System;

namespace DSPOptimizations;

[AttributeUsage(AttributeTargets.Field, AllowMultiple = false, Inherited = false)]
internal class ConfigValueAttribute : Attribute
{
	private string description;

	private object defaultValue;

	public string Description => description;

	public object DefaultValue => defaultValue;

	public ConfigValueAttribute(object defaultValue, string description)
	{
		this.description = description;
		this.defaultValue = defaultValue;
	}
}
