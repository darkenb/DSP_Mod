using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;

namespace DSPOptimizations;

[Optimization("EntityNeedsOpt", "", false, new Type[] { })]
internal class EntityNeedsOpt : OptimizationSet
{
	private class Patch
	{
		[HarmonyTranspiler]
		[HarmonyPatch(typeof(AssemblerComponent), "InternalUpdate")]
		private static IEnumerable<CodeInstruction> NeedsDirtyPatch1(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldc_I4_1), new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(AssemblerComponent), "replicating"))).Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldc_I4_1), new CodeInstruction(OpCodes.Stfld, AccessTools.Field(typeof(AssemblerComponent), "needsDirty")));
			return codeMatcher.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(UIAssemblerWindow), "OnManualServingContentChange")]
		private static IEnumerable<CodeInstruction> NeedsDirtyPatch2(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.End().MatchBack(true, new CodeMatch(OpCodes.Ret)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(UIAssemblerWindow), "factorySystem")), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(FactorySystem), "assemblerPool")), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(UIAssemblerWindow), "get_assemblerId")), new CodeInstruction(OpCodes.Ldelema, typeof(AssemblerComponent)), new CodeInstruction(OpCodes.Ldc_I4_1), new CodeInstruction(OpCodes.Stfld, AccessTools.Field(typeof(AssemblerComponent), "needsDirty")));
			return codeMatcher.InstructionEnumeration();
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(PlanetFactory), "InsertInto")]
		public static void NeedsDirtyPatch3(PlanetFactory __instance, int __result, int entityId)
		{
			if (__result != 0)
			{
				int assemblerId = __instance.entityPool[entityId].assemblerId;
				if (assemblerId > 0)
				{
					__instance.factorySystem.assemblerPool[assemblerId].needsDirty = true;
				}
			}
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(PlanetFactory), "EntityFastFillIn")]
		private static IEnumerable<CodeInstruction> NeedsDirtyPatch4(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(AssemblerComponent), "requires"))).Advance(-3).InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(PlanetFactory), "factorySystem")), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(FactorySystem), "assemblerPool")), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(PlanetFactory), "entityPool")), new CodeInstruction(OpCodes.Ldarg_1), new CodeInstruction(OpCodes.Ldelema, typeof(EntityData)), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(EntityData), "assemblerId")), new CodeInstruction(OpCodes.Ldelema, typeof(AssemblerComponent)), new CodeInstruction(OpCodes.Ldc_I4_1), new CodeInstruction(OpCodes.Stfld, AccessTools.Field(typeof(AssemblerComponent), "needsDirty")));
			return codeMatcher.InstructionEnumeration();
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(AssemblerComponent), "Import")]
		[HarmonyPatch(typeof(AssemblerComponent), "SetEmpty")]
		[HarmonyPatch(typeof(AssemblerComponent), "SetRecipe")]
		public static void NeedsDirtyPatch5(ref AssemblerComponent __instance)
		{
			__instance.needsDirty = true;
		}
	}
}
