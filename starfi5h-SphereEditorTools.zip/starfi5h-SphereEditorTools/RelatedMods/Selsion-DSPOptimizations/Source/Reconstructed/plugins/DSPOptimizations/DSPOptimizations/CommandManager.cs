using System;
using System.Collections.Generic;
using System.Reflection;
using HarmonyLib;

namespace DSPOptimizations;

[RunPatches(typeof(Patch))]
public class CommandManager
{
	private class Patch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(XConsole), "InitCommands")]
		public static void InitCommandsPostfix()
		{
			foreach (Assembly item in initQueue)
			{
				Init(item);
			}
			initQueue.Clear();
			initialized = true;
		}
	}

	private static List<string> cmds;

	private static List<Assembly> srcAssm;

	private static List<Assembly> initQueue;

	private static bool initialized;

	public static void QueueInit(Assembly assm = null)
	{
		if (initialized)
		{
			Init(assm);
			return;
		}
		if (initQueue == null)
		{
			initQueue = new List<Assembly>();
		}
		initQueue.Add(assm);
	}

	private static void Init(Assembly assm)
	{
		if (assm == null)
		{
			assm = Assembly.GetExecutingAssembly();
		}
		if (cmds == null)
		{
			cmds = new List<string>();
		}
		if (srcAssm == null)
		{
			srcAssm = new List<Assembly>();
		}
		int num = FindCommands(assm);
		Plugin.logger.LogInfo(string.Format("{0} command{1} loaded from {2}", num, (num == 1) ? "" : "s", assm.GetName().Name));
	}

	public static void OnDestroy(Assembly assm = null)
	{
		if (cmds == null || cmds.Count == 0)
		{
			return;
		}
		for (int i = 0; i < cmds.Count; i++)
		{
			string cmd = cmds[i];
			Assembly assembly = srcAssm[i];
			if (assm == null || assm == assembly)
			{
				XConsole.UnregisterCommand(cmd);
				cmds.RemoveAt(i);
				srcAssm.RemoveAt(i);
				i--;
			}
		}
	}

	private static void AddCommand(string name, Func<string, string> cmd, Assembly assm)
	{
		XConsole.RegisterCommand(name, cmd.Invoke);
		cmds.Add(name);
		srcAssm.Add(assm);
	}

	private static bool IsValidCommand(MethodInfo method)
	{
		if (method.ReturnType != typeof(string))
		{
			return false;
		}
		ParameterInfo[] parameters = method.GetParameters();
		if (parameters.Length == 1 && !parameters[0].IsOut)
		{
			return parameters[0].ParameterType == typeof(string);
		}
		return false;
	}

	private static int FindCommands(Assembly assm)
	{
		int num = 0;
		Type[] types = assm.GetTypes();
		foreach (Type type in types)
		{
			MethodInfo[] methods = type.GetMethods();
			foreach (MethodInfo methodInfo in methods)
			{
				CommandAttribute commandAttribute = (CommandAttribute)methodInfo.GetCustomAttribute(typeof(CommandAttribute));
				if (commandAttribute != null)
				{
					if (IsValidCommand(methodInfo))
					{
						AddCommand(commandAttribute.Name, (Func<string, string>)methodInfo.CreateDelegate(typeof(Func<string, string>)), assm);
						num++;
					}
					else
					{
						Plugin.logger.LogError($"{type.Name}.{methodInfo.Name} from {assm.GetName().Name} is not a valid command");
					}
				}
			}
		}
		return num;
	}
}
