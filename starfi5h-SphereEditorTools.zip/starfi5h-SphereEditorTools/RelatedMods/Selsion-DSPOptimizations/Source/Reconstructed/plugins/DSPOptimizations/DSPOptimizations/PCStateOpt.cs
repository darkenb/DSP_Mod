using System;

namespace DSPOptimizations;

[Optimization("PCStateOpt", "", false, new Type[] { })]
internal class PCStateOpt
{
	private class Patch
	{
	}
}
