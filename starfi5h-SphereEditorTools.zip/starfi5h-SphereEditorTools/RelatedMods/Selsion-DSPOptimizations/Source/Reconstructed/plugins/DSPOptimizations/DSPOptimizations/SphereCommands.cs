namespace DSPOptimizations;

internal class SphereCommands
{
	private enum EResetError
	{
		None,
		InvalidIndex,
		DoesNotExist,
		Unknown
	}

	private static EResetError ResetSwarm(int star_index)
	{
		DysonSphere dysonSphere = GameMain.data.dysonSpheres[star_index];
		if (dysonSphere?.swarm == null)
		{
			return EResetError.DoesNotExist;
		}
		for (int i = 0; i < 10; i++)
		{
			DysonSphereLayer dysonSphereLayer = dysonSphere.layersSorted[i];
			if (dysonSphereLayer == null)
			{
				continue;
			}
			for (int j = 1; j < dysonSphereLayer.nodeCursor; j++)
			{
				DysonNode dysonNode = dysonSphereLayer.nodePool[j];
				if (dysonNode != null && dysonNode.id == j)
				{
					dysonNode.cpOrdered = 0;
				}
			}
		}
		dysonSphere.swarm = new DysonSwarm(dysonSphere);
		dysonSphere.swarm.Init();
		dysonSphere.swarm.ResetNew();
		return EResetError.None;
	}

	[Command("resetLocalSwarm")]
	public static string CmdResetLocalSwarm(string param)
	{
		StarData localStar = GameMain.data.localStar;
		if (localStar == null)
		{
			return "Failed to reset local swarm: No nearby star";
		}
		return ResetSwarm(localStar.index) switch
		{
			EResetError.None => "Successfully reset local swarm", 
			EResetError.DoesNotExist => "Failed to reset local swarm: No swarm exists", 
			_ => "Failed to reset local swarm: Cause unknown", 
		};
	}

	[Command("resetLocalSphereLayer")]
	public static string CmdResetLocalSphereLayer(string param)
	{
		if (param == "")
		{
			return "Invalid Usage. Correct usage: -resetLocalSphereLayer layerId";
		}
		GameData data = GameMain.data;
		StarData localStar = data.localStar;
		if (localStar == null)
		{
			return "Failed to reset local sphere layer: No nearby star";
		}
		DysonSphere dysonSphere = data.dysonSpheres[localStar.index];
		if (dysonSphere == null)
		{
			return "Failed to reset local sphere layer: sphere does not exist";
		}
		if (!int.TryParse(param, out var result) || result < 1 || result > 10)
		{
			return "Failed to reset local sphere layer: invalid layer id";
		}
		DysonSphereLayer dysonSphereLayer = dysonSphere.layersIdBased[result];
		if (dysonSphereLayer == null)
		{
			return "Failed to reset local sphere layer: layer does not exist";
		}
		for (int i = 0; i < dysonSphereLayer.nodePool.Length; i++)
		{
			if (dysonSphereLayer.nodePool[i] != null)
			{
				dysonSphere.swarm.OnNodeRemove(dysonSphereLayer.id, i);
				dysonSphere.RemoveAutoNode(dysonSphereLayer.nodePool[i]);
				dysonSphere.RemoveNodeRocket(dysonSphereLayer.nodePool[i]);
				dysonSphere.RemoveDysonNodeRData(dysonSphereLayer.nodePool[i]);
			}
		}
		dysonSphere.RemoveLayer(result);
		UIDysonEditor dysonEditor = UIRoot._instance.uiGame.dysonEditor;
		if (!dysonEditor.IsRender(result, isSwarm: false, inEditor: true))
		{
			dysonEditor.SwitchRenderState(result, isSwarm: false, inEditor: true);
		}
		if (!dysonEditor.IsRender(result, isSwarm: false, inEditor: false))
		{
			dysonEditor.SwitchRenderState(result, isSwarm: false, inEditor: false);
		}
		dysonEditor.selection.ClearAllSelection();
		dysonSphere.CheckAutoNodes();
		dysonSphere.PickAutoNode();
		dysonSphere.modelRenderer.RebuildModels();
		return "Successfully reset sphere layer " + result;
	}

	[Command("resetAllSpheresAndSwarms")]
	public static string CmdResetAllSpheresAndSwarms(string param)
	{
		int num = 0;
		GameData data = GameMain.data;
		for (int i = 0; i < data.dysonSpheres.Length; i++)
		{
			if (data.dysonSpheres[i] != null)
			{
				data.dysonSpheres[i] = new DysonSphere();
				data.dysonSpheres[i].Init(data, data.galaxy.stars[i]);
				data.dysonSpheres[i].ResetNew();
				num++;
			}
		}
		return $"Reset spheres and swarms around {num}/{data.dysonSpheres.Length} stars";
	}
}
