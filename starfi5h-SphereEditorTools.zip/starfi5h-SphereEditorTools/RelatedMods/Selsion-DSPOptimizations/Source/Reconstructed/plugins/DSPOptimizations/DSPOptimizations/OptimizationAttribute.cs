using System;

namespace DSPOptimizations;

[AttributeUsage(AttributeTargets.Class, AllowMultiple = false, Inherited = false)]
internal class OptimizationAttribute : Attribute
{
	private string name;

	private string description;

	private bool hasSaveData;

	private Type[] subModules;

	public string Name => name;

	public string Description => description;

	public Type[] SubModules => subModules;

	public bool HasSaveData => hasSaveData;

	public OptimizationAttribute(string name, string description, bool hasSaveData, Type[] subModules = null)
	{
		this.name = name;
		this.description = description;
		this.hasSaveData = hasSaveData;
		this.subModules = subModules;
	}
}
