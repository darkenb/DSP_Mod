using BepInEx;

namespace DSPOptimizations;

public abstract class OptimizationSet
{
	protected bool enabled = true;

	public bool Enabled
	{
		get
		{
			return enabled;
		}
		set
		{
			enabled = value;
		}
	}

	public virtual void Init(BaseUnityPlugin plugin)
	{
	}

	public virtual void OnDestroy()
	{
	}
}
