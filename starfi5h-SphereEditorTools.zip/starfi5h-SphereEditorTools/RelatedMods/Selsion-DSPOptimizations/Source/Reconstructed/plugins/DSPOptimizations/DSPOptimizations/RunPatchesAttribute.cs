using System;

namespace DSPOptimizations;

[AttributeUsage(AttributeTargets.Class, AllowMultiple = true, Inherited = false)]
internal class RunPatchesAttribute : Attribute
{
	private Type patches;

	public Type Patches => patches;

	public RunPatchesAttribute(Type patches)
	{
		this.patches = patches;
	}
}
