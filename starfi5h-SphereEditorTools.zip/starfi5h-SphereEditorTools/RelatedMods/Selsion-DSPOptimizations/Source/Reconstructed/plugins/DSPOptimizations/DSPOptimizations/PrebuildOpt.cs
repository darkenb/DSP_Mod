using System;

namespace DSPOptimizations;

[Optimization("PrebuildOpt", "Reduces permanent lag caused by placing large blueprints", false, new Type[] { })]
internal class PrebuildOpt : OptimizationSet
{
	private class Patch
	{
	}
}
