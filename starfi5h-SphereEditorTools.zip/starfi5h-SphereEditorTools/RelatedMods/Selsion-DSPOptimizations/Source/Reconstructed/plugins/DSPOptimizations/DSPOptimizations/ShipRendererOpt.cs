using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;

namespace DSPOptimizations;

internal class ShipRendererOpt : OptimizationSet
{
	private class Patch
	{
		[HarmonyTranspiler]
		[HarmonyPatch(typeof(StationComponent), "ShipRenderersOnTick")]
		private static IEnumerable<CodeInstruction> IdleShipPoseFix(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			LocalBuilder operand = generator.DeclareLocal(typeof(bool));
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(Assert), "Zero", new Type[1] { typeof(int) }))).Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0), Transpilers.EmitDelegate<Func<StationComponent, bool>>(delegate(StationComponent station)
			{
				PlanetData localPlanet = GameMain.data.localPlanet;
				return localPlanet != null && localPlanet.id == station.planetId;
			}), new CodeInstruction(OpCodes.Stloc_S, operand));
			codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(ShipRenderingData), "SetPose"))).Advance(1).CreateLabel(out var label)
				.MatchBack(true, new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(ShipRenderingData), "gid")))
				.Advance(-4);
			OpCode opcode = codeMatcher.Opcode;
			object operand2 = codeMatcher.Operand;
			codeMatcher.Advance(5).CreateLabel(out var label2).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand), new CodeInstruction(OpCodes.Brtrue, label2), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, AccessTools.Field(typeof(StationComponent), "shipRenderers")), new CodeInstruction(opcode, operand2), new CodeInstruction(OpCodes.Ldelema, typeof(ShipRenderingData)), new CodeInstruction(OpCodes.Ldflda, AccessTools.Field(typeof(ShipRenderingData), "pos")), new CodeInstruction(OpCodes.Ldc_R4, 1E+09f), new CodeInstruction(OpCodes.Stfld, AccessTools.Field(typeof(Vector3), "x")), new CodeInstruction(OpCodes.Br, label));
			return codeMatcher.InstructionEnumeration();
		}
	}
}
