using System;
using System.Collections.Generic;

namespace DSPOptimizations;

internal class FactoryCommands
{
	private static Dictionary<int, int> planetIdToFactoryIdx;

	public static string CmdResetLocalPlanet(string param)
	{
		PlanetData localPlanet = GameMain.localPlanet;
		if (localPlanet == null)
		{
			return "no local planet";
		}
		ResetPlanet(localPlanet);
		return "successfully reset local planet";
	}

	[Command("resetLocalFactory")]
	public static string CmdResetLocalFactory(string param)
	{
		PlanetData localPlanet = GameMain.localPlanet;
		if (localPlanet == null)
		{
			return "no local planet";
		}
		if (localPlanet.factory == null)
		{
			return "local factory is null";
		}
		ResetFactory(localPlanet);
		return "successfully reset local factory";
	}

	private static void PrepareReset(PlanetData planet)
	{
		UIRoot.instance.uiGame.ShutAllFunctionWindow();
		PlanetFactory factory = planet.factory;
		PlanetTransport transport = factory.transport;
		GalacticTransport galacticTransport = GameMain.data.galacticTransport;
		for (int i = 1; i < transport.stationCursor; i++)
		{
			StationComponent stationComponent = transport.stationPool[i];
			if (stationComponent != null && stationComponent.id == i && stationComponent.gid > 0)
			{
				galacticTransport.RemoveStationComponent(stationComponent.gid);
			}
		}
		WarningSystem warningSystem = GameMain.data.warningSystem;
		for (int j = 1; j < warningSystem.warningCursor; j++)
		{
			WarningData warningData = warningSystem.warningPool[j];
			if (warningData.id == j && warningData.factoryId == factory.index)
			{
				warningSystem.RemoveWarningData(j);
			}
		}
		planet.audio.nearAudioLogic.RefreshAudiosOnArrayChange();
		planet.physics.nearColliderLogic.RefreshCollidersLive();
		planet.physics.nearColliderLogic.DeleteDeadColliders();
	}

	private static void CacheFactoryIndex(PlanetData planet)
	{
		if (planetIdToFactoryIdx == null)
		{
			planetIdToFactoryIdx = new Dictionary<int, int>();
		}
		if (planetIdToFactoryIdx.ContainsKey(planet.id))
		{
			planetIdToFactoryIdx[planet.id] = planet.factory.index;
		}
		else
		{
			planetIdToFactoryIdx.Add(planet.id, planet.factory.index);
		}
	}

	private static void ResetPlanet(PlanetData planet)
	{
		PrepareReset(planet);
		GameMain.data.LeavePlanet();
		planet.Unload();
		CacheFactoryIndex(planet);
		planet.loaded = (planet.loading = (planet.factoryLoaded = (planet.factoryLoading = false)));
		planet.data = null;
		planet.factory = null;
		planet.onLoaded += ResetPlanetFinish;
		PlanetModelingManager.RequestLoadPlanet(planet);
	}

	private static void ResetPlanetFinish(PlanetData planet)
	{
		if (planetIdToFactoryIdx.TryGetValue(planet.id, out var value))
		{
			planetIdToFactoryIdx.Remove(planet.id);
			planet.onLoaded -= ResetPlanetFinish;
			GameData data = GameMain.data;
			PlanetFactory planetFactory = new PlanetFactory();
			planetFactory.Init(data, planet, value);
			data.factories[value] = planetFactory;
			planet.factory = planetFactory;
		}
	}

	private static void ResetFactory(PlanetData planet)
	{
		PrepareReset(planet);
		planet.UnloadFactory();
		PlanetFactory factory = planet.factory;
		GameData data = GameMain.data;
		int index = factory.index;
		PlanetRawData data2 = planet.data;
		data2.veinCursor = factory.veinCursor;
		data2.SetVeinCapacity(data2.veinCursor + 2);
		Array.Copy(factory.veinPool, data2.veinPool, data2.veinCursor);
		data2.vegeCursor = factory.vegeCursor;
		data2.SetVegeCapacity(data2.vegeCursor + 2);
		Array.Copy(factory.vegePool, data2.vegePool, data2.vegeCursor);
		lock (planet.veinGroupsLock)
		{
			int num = Math.Max(factory.veinGroups.Length, 1);
			planet.veinGroups = new VeinGroup[num];
			Array.Copy(factory.veinGroups, planet.veinGroups, num);
		}
		PlatformSystem platformSystem = factory.platformSystem;
		PlanetFactory planetFactory = new PlanetFactory();
		planetFactory.Init(data, planet, index);
		data.factories[index] = planetFactory;
		planet.factory = planetFactory;
		planetFactory.platformSystem = platformSystem;
		platformSystem.factory = planetFactory;
		PlanetModelingManager.fctPlanetReqList.Enqueue(planet);
	}
}
