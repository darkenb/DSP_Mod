using System;
using System.Collections.Generic;
using System.Reflection;
using BepInEx;

namespace DSPOptimizations;

internal class OptimizationSetManager
{
	private static List<OptimizationSet> optSetInstances;

	public static void Init(BaseUnityPlugin plugin)
	{
		optSetInstances = new List<OptimizationSet>();
		int num = 0;
		Type[] types = Assembly.GetExecutingAssembly().GetTypes();
		for (int i = 0; i < types.Length; i++)
		{
			if (RegisterOptimization(types[i], isSubModule: false))
			{
				num++;
			}
		}
		Plugin.logger.LogInfo(string.Format("{0} optimization set{1} loaded", num, (num == 1) ? "" : "s"));
		foreach (OptimizationSet optSetInstance in optSetInstances)
		{
			optSetInstance.Init(plugin);
		}
	}

	private static bool RegisterOptimization(Type type, bool isSubModule)
	{
		if (!type.IsSubclassOf(typeof(OptimizationSet)))
		{
			return false;
		}
		OptimizationSet item = (OptimizationSet)Activator.CreateInstance(type);
		optSetInstances.Add(item);
		return true;
	}

	public static void OnDestroy()
	{
		foreach (OptimizationSet optSetInstance in optSetInstances)
		{
			optSetInstance.OnDestroy();
		}
		optSetInstances.Clear();
	}
}
