using System;
using HarmonyLib;

namespace DSPOptimizations;

[Optimization("ReceiverOpt", "", false, new Type[] { })]
internal class ReceiverOpt : OptimizationSet
{
	private class Patch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(PowerSystem), "Import")]
		public static void ImportPatch(PowerSystem __instance)
		{
			for (int i = 1; i < __instance.genCursor; i++)
			{
				if (__instance.genPool[i].gamma)
				{
					AddReceiver(__instance, i);
				}
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(PowerSystem), "NewGeneratorComponent")]
		public static void AddGenPatch(PowerSystem __instance, int __result)
		{
			if (__instance.genPool[__result].gamma)
			{
				AddReceiver(__instance, __result);
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(PowerSystem), "RemoveGeneratorComponent")]
		public static void RemoveGenPatch(PowerSystem __instance, int id)
		{
			if (__instance.genPool[id].gamma)
			{
				RemoveReceiver(__instance, id);
			}
		}
	}

	private const int INITIAL_RECEIVER_POOL_SIZE = 8;

	private static void SetReceiverCapacity(PowerSystem powerSystem, int newCapacity)
	{
		int[] receiverPool = powerSystem.receiverPool;
		powerSystem.receiverPool = new int[newCapacity];
		if (receiverPool != null)
		{
			int num = receiverPool.Length;
			Array.Copy(receiverPool, powerSystem.receiverPool, (newCapacity > num) ? num : newCapacity);
		}
	}

	private static void AddReceiver(PowerSystem powerSystem, int genId)
	{
		if (powerSystem.receiverPool == null)
		{
			SetReceiverCapacity(powerSystem, 8);
			powerSystem.receiverCursor = 0;
		}
		else if (powerSystem.receiverCursor == powerSystem.receiverPool.Length)
		{
			SetReceiverCapacity(powerSystem, powerSystem.receiverCursor * 2);
		}
		powerSystem.receiverPool[powerSystem.receiverCursor] = genId;
		powerSystem.receiverCursor++;
	}

	private static void RemoveReceiver(PowerSystem powerSystem, int genId)
	{
		int i;
		for (i = 0; i < powerSystem.receiverCursor && powerSystem.receiverPool[i] != genId; i++)
		{
		}
		if (i != powerSystem.receiverCursor)
		{
			int num = powerSystem.receiverCursor - 1;
			if (i < num)
			{
				powerSystem.receiverPool[i] = powerSystem.receiverPool[num];
			}
			powerSystem.receiverPool[num] = 0;
			powerSystem.receiverCursor--;
		}
	}
}
