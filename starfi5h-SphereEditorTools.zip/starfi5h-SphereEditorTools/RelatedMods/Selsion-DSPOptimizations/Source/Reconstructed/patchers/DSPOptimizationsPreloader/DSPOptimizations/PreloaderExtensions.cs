using Mono.Cecil;

namespace DSPOptimizations;

public static class PreloaderExtensions
{
	public static TypeDefinition AddField(this TypeDefinition type, string name, TypeReference fieldType, FieldAttributes attr = FieldAttributes.Public)
	{
		type.Fields.Add(new FieldDefinition(name, attr, fieldType));
		return type;
	}
}
