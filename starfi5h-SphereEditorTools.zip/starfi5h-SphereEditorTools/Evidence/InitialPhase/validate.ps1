param([string]$Original, [string]$Built, [string]$Core, [string]$PhaseRoot)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $Core 'Mono.Cecil.dll')
function Get-Types($types) {
    foreach ($type in $types) { $type; Get-Types $type.NestedTypes }
}
function Get-PublicContract($assembly) {
    foreach ($type in (Get-Types $assembly.MainModule.Types)) {
        if (-not ($type.IsPublic -or $type.IsNestedPublic)) { continue }
        'TYPE ' + $type.FullName
        foreach ($method in $type.Methods) {
            if ($method.IsPublic -or $method.IsFamily -or $method.IsFamilyOrAssembly) { 'METHOD ' + $method.FullName }
        }
        foreach ($field in $type.Fields) {
            if ($field.IsPublic -or $field.IsFamily -or $field.IsFamilyOrAssembly) { 'FIELD ' + $field.FullName }
        }
    }
}
$oldAssembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Original)
$newAssembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Built)
try {
    if ($oldAssembly.Name.FullName -ne $newAssembly.Name.FullName) { throw 'Assembly identity changed' }
    $oldContract = @(Get-PublicContract $oldAssembly)
    $newContract = @(Get-PublicContract $newAssembly)
    $missing = @($oldContract | Where-Object { $_ -notin $newContract })
    if ($missing.Count) { throw ('Public API removed: ' + ($missing -join '; ')) }
    $oldIds = @((Get-Types $oldAssembly.MainModule.Types).CustomAttributes | Where-Object { $_.AttributeType.FullName -eq 'BepInEx.BepInPlugin' } | ForEach-Object { $_.ConstructorArguments[0].Value })
    $newIds = @((Get-Types $newAssembly.MainModule.Types).CustomAttributes | Where-Object { $_.AttributeType.FullName -eq 'BepInEx.BepInPlugin' } | ForEach-Object { $_.ConstructorArguments[0].Value })
    if (@(Compare-Object $oldIds $newIds).Count) { throw 'Plugin GUID set changed' }
    $move = ($newAssembly.MainModule.GetType('SphereEditorTools.EditOrbit').Methods | Where-Object Name -eq MoveShells)
    $il = @($move.Body.Instructions)
    $readColor = -1; $remove = -1; $create = -1; $writeColor = -1
    for ($i = 0; $i -lt $il.Count; $i++) {
        $operand = [string]$il[$i].Operand
        if ($il[$i].OpCode.Name -eq 'ldfld' -and $operand -eq 'UnityEngine.Color32 DysonShell::color') { $readColor = $i }
        if ($operand -match 'DysonSphereLayer::RemoveDysonShell\(') { $remove = $i }
        if ($operand -match 'DysonSphereLayer::NewDysonShell\(') { $create = $i }
        if ($il[$i].OpCode.Name -eq 'stfld' -and $operand -eq 'UnityEngine.Color32 DysonShell::color') { $writeColor = $i }
    }
    if (-not (0 -le $readColor -and $readColor -lt $remove -and $remove -lt $create -and $create -lt $writeColor)) {
        throw 'Shell paint is not preserved across geometry reconstruction'
    }
    $result = [ordered]@{ assembly_identity = $newAssembly.Name.FullName; public_contract_preserved = $oldContract.Count; plugin_guids = $newIds;  original_sha256 = (Get-FileHash -LiteralPath $Original).Hash; built_sha256 = (Get-FileHash -LiteralPath $Built).Hash; passed = $true }
    $result | ConvertTo-Json -Depth 5 | Set-Content -LiteralPath (Join-Path $PhaseRoot 'validation.json') -Encoding UTF8
    Write-Output ('PASS assembly identity, {0} public contract entries, {1} plugin GUIDs' -f $oldContract.Count,$newIds.Count)
} finally { $oldAssembly.Dispose(); $newAssembly.Dispose() }
