using System;
using System.Runtime.Serialization;
using HarmonyLib;
using SphereEditorTools;

static class Check
{
    static int Main()
    {
        var layer = (DysonSphereLayer)FormatterServices.GetUninitializedObject(typeof(DysonSphereLayer));
        layer.orbitAngularSpeed = 2.5f;
        AccessTools.Field(typeof(EditOrbit), "selectedLayer").SetValue(null, layer);
        EditOrbit.AuglarSpeed = 99;
        if (!EditOrbit.Toggle(true) || layer.orbitAngularSpeed != 0 || EditOrbit.AuglarSpeed != 2.5f) throw new Exception("Anchor failed to capture current speed");
        EditOrbit.Toggle(true);
        if (EditOrbit.AuglarSpeed != 2.5f) throw new Exception("Repeated anchor overwrote saved speed");
        EditOrbit.Free();
        if (layer.orbitAngularSpeed != 2.5f || EditOrbit.EnableAnchorMode || AccessTools.Field(typeof(EditOrbit), "selectedLayer").GetValue(null) != null) throw new Exception("Close failed to restore layer");
        AccessTools.Field(typeof(EditOrbit), "selectedLayer").SetValue(null, layer);
        EditOrbit.TrySetAngularSpeed(float.NaN);
        EditOrbit.TrySetAngularSpeed(float.PositiveInfinity);
        if (layer.orbitAngularSpeed != 2.5f) throw new Exception("Nonfinite speed accepted");
        Console.WriteLine("PASS native layer current speed captured once, close restores speed and selection, nonfinite input rejected");
        return 0;
    }
}
