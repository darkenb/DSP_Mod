# Related mods and code references — starfi5h-SphereEditorTools

All listed copies are inside this mod folder. They are one-level reference copies with their own Source, InstalledPackage, metadata and English change notes. Required installed dependencies of those copies are flattened into the same RelatedMods directory; copies never recursively contain another RelatedMods directory.

Dependency declarations (including optional compatibility plugins), compiled member calls and native integration/test context are distinguished below. A shared native API touchpoint is not presented as a direct foreign-method call. Original game/BepInEx SDK files and uninstalled optional mods are not fabricated or downloaded. 

## CommonAPI-DSPModSave

Copy: `RelatedMods/CommonAPI-DSPModSave/`.

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder. Via: `Selsion-DSPOptimizations`, `starfi5h-LossyCompression`.

### Dependency references inside the copied mods

`RelatedMods/Selsion-DSPOptimizations/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/DysonNodeOpt.cs:16`

```csharp
	{
		[HarmonyPostfix]
		[HarmonyAfter(new string[] { "crecheng.DSPModSave" })]
		[HarmonyPatch(typeof(GameData), "NewGame")]
		[HarmonyPatch(typeof(GameSave), "LoadCurrentGame")]
```

`RelatedMods/Selsion-DSPOptimizations/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/LowResShellsSaveManager.cs:13`

```csharp
		[HarmonyPostfix]
		[HarmonyPatch(typeof(GameSave), "LoadCurrentGame")]
		[HarmonyAfter(new string[] { "crecheng.DSPModSave" })]
		public static void DSPModSaveLoadingFix()
		{
```

`RelatedMods/Selsion-DSPOptimizations/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/Plugin.cs:11`

```csharp

[BepInPlugin("com.Selsion.DSPOptimizations", "DSPOptimizations", "1.1.21")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class Plugin : BaseUnityPlugin, IModCanSave
{
```

`RelatedMods/starfi5h-LossyCompression/Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs:11`

```csharp

[BepInPlugin("starfi5h.plugin.LossyCompression", "LossyCompression", "0.3.10")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("com.Selsion.DSPOptimizations", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
```

`RelatedMods/starfi5h-LossyCompression/Source/EarlierWorkingSource/Plugin.cs:12`

```csharp
{
    [BepInPlugin(GUID, NAME, VERSION)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [BepInDependency(ModCompatibility.DSPOptimizations.GUID, BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency(ModCompatibility.NebulaAPI.GUID, BepInDependency.DependencyFlags.SoftDependency)]
```

### Code in the related copy

`RelatedMods/CommonAPI-DSPModSave/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs:15`

```csharp
namespace crecheng.DSPModSave;

[BepInPlugin("crecheng.DSPModSave", "DSP Mod Save", "1.2.3")]
public class DSPModSavePlugin : BaseUnityPlugin
{
```

`RelatedMods/CommonAPI-DSPModSave/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs:12`

```csharp
	private static void EnterGame()
	{
		DSPModSavePlugin.logger.LogInfo("Enter New Game");
		foreach (ModSaveSettings value in DSPModSavePlugin.allModData.Values)
		{
```

`RelatedMods/CommonAPI-DSPModSave/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs:13`

```csharp
		if (__result)
		{
			DSPModSavePlugin.OnSave(saveName);
		}
	}
```

`RelatedMods/CommonAPI-DSPModSave/Evidence/InitialPhase/check.cs:19`

```csharp
static class Check
{
    static void Call(string method, params object[] args) {AccessTools.Method(typeof(DSPModSavePlugin), method).Invoke(null, args);}
    static int Main()
    {
```

`RelatedMods/CommonAPI-DSPModSave/Source/EarlierWorkingSource/DSPModSavePlugin.cs:20`

```csharp
{
    [BepInPlugin(MODGUID, MODNAME, VERSION)]
    public class DSPModSavePlugin : BaseUnityPlugin
    {
        public const string MODGUID = "crecheng.DSPModSave";
```

## Selsion-DSPOptimizations

Copy: `RelatedMods/Selsion-DSPOptimizations/`.

- **fix_integration_context**: Layer/shell editing must preserve native geometry and energy data used by the active Dyson optimizations.

### Code in this mod

`Source/Reconstructed/plugins/SphereEditorTools/SphereEditorTools/EditOrbit.cs:190`

```csharp
		for (int i = 0; i < layer.shellCursor; i++)
		{
			DysonShell dysonShell = layer.shellPool[i];
			if (dysonShell == null || i != dysonShell.id)
			{
```

`Source/Reconstructed/plugins/SphereEditorTools/SphereEditorTools/SymmetryTool.cs:559`

```csharp
	[HarmonyPrefix]
	[HarmonyPatch(typeof(DESelection), "OnShellClick")]
	public static bool Overwrite_OnFrameClick(DESelection __instance, DysonShell shell)
	{
		if (!overwrite || shell == null)
```

`Source/EarlierWorkingSource/EditOrbit.cs:179`

```csharp
            for (int sid = 0; sid < layer.shellCursor; sid++)
            {
                DysonShell shell = layer.shellPool[sid];
                if (shell == null || sid != shell.id)
                    continue;
```

`Source/EarlierWorkingSource/SymmetryTool.cs:521`

```csharp

        [HarmonyPrefix, HarmonyPatch(typeof(DESelection), "OnShellClick")]
        public static bool Overwrite_OnFrameClick(DESelection __instance, DysonShell shell)
        {
            if (!overwrite || shell == null)
```

`Source/Reconstructed/plugins/SphereEditorTools/SphereEditorTools/Comm.cs:111`

```csharp
		}
		infoCounter = 0;
		DysonSphereLayer singleSelectedLayer = __instance.selection.singleSelectedLayer;
		if (singleSelectedLayer != null && SphereEditorTools.EnableToolboxHotkey.Value)
		{
```

### Code in the related copy

`RelatedMods/Selsion-DSPOptimizations/Source/Reconstructed/patchers/DSPOptimizationsPreloader/DSPOptimizations/Preloader.cs:32`

```csharp
	{
		TypeSystem typeSystem = assembly.MainModule.TypeSystem;
		GetType(assembly, "DysonShell")?.AddField("vertsqOffset_lowRes", typeSystem.Int32.MakeArrayType())?.AddField("radius_lowRes", typeSystem.Single)?.AddField("surfaceAreaUnitSphere", typeSystem.Single);
		GetType(assembly, "DysonSphereLayer")?.AddField("radius_lowRes", typeSystem.Single)?.AddField("surfaceAreaUnitSphere", typeSystem.Single)?.AddField("totalNodeSP", typeSystem.Int64)?.AddField("totalFrameSP", typeSystem.Int64)?.AddField("totalCP", typeSystem.Int64);
		GetType(assembly, "DysonSphereSegmentRenderer")?.AddField("layersDirtyMask", typeSystem.Int32.MakeArrayType());
```

`RelatedMods/Selsion-DSPOptimizations/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/DysonNodeOpt.cs:47`

```csharp

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonShell), "Construct")]
		public static void DysonShell_Construct_Postfix(DysonShell __instance, bool __result)
		{
```

`RelatedMods/Selsion-DSPOptimizations/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/LowResShellsLegacySupport.cs:17`

```csharp
		public static void ResetShellUpdateListPatch()
		{
			shellsToUpdate = new List<DysonShell>();
		}

```

`RelatedMods/Selsion-DSPOptimizations/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/LowResShellsSaveManager.cs:161`

```csharp
						for (int k = 1; k < dysonSphereLayer.shellCursor; k++)
						{
							DysonShell dysonShell = dysonSphereLayer.shellPool[k];
							if (dysonShell != null && dysonShell.id == k)
							{
```

`RelatedMods/Selsion-DSPOptimizations/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/ShellShaderVarOpt.cs:15`

```csharp
	private class Patch
	{
		[HarmonyPatch(typeof(DysonShell), "GenerateModelObjects")]
		public static void ShellMatInitPostfix(DysonShell __instance)
		{
```

## nebula-NebulaMultiplayerModApi

Copy: `RelatedMods/nebula-NebulaMultiplayerModApi/`.

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder. Via: `starfi5h-LossyCompression`.

### Dependency references inside the copied mods

`RelatedMods/starfi5h-LossyCompression/Source/Reconstructed/plugins/LossyCompression/LossyCompression/ModCompatibility.cs:89`

```csharp
	public static class NebulaAPI
	{
		public const string GUID = "dsp.nebula-multiplayer-api";

		public static void Init(Harmony harmony)
```

`RelatedMods/starfi5h-LossyCompression/Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs:13`

```csharp
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("com.Selsion.DSPOptimizations", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
public class Plugin : BaseUnityPlugin, IModCanSave
{
```

`RelatedMods/starfi5h-LossyCompression/Source/EarlierWorkingSource/ModCompatibility.cs:128`

```csharp
        public static class NebulaAPI
        {
            public const string GUID = "dsp.nebula-multiplayer-api";

            public static void Init(Harmony harmony)
```

### Code in the related copy

`RelatedMods/nebula-NebulaMultiplayerModApi/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs:15`

```csharp
[BepInPlugin("dsp.nebula-multiplayer-api", "NebulaMultiplayerModApi", "2.1.0.7")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class NebulaModAPI : BaseUnityPlugin
{
	public const string NEBULA_MODID = "dsp.nebula-multiplayer";
```

`RelatedMods/nebula-NebulaMultiplayerModApi/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs:5`

```csharp
namespace NebulaAPI.DataStructures;

public static class CollectionExtensions
{
	public static Locker Lock(this ICollection collection)
```

## starfi5h-LossyCompression

Copy: `RelatedMods/starfi5h-LossyCompression/`.

- **fix_integration_context**: Shell rebuild/paint restoration retains native shell serialization consumed by the codec; live combined acceptance remains outstanding.

### Code in this mod

`Source/Reconstructed/plugins/SphereEditorTools/SphereEditorTools/EditOrbit.cs:190`

```csharp
		for (int i = 0; i < layer.shellCursor; i++)
		{
			DysonShell dysonShell = layer.shellPool[i];
			if (dysonShell == null || i != dysonShell.id)
			{
```

`Source/Reconstructed/plugins/SphereEditorTools/SphereEditorTools/SymmetryTool.cs:559`

```csharp
	[HarmonyPrefix]
	[HarmonyPatch(typeof(DESelection), "OnShellClick")]
	public static bool Overwrite_OnFrameClick(DESelection __instance, DysonShell shell)
	{
		if (!overwrite || shell == null)
```

`Source/EarlierWorkingSource/EditOrbit.cs:179`

```csharp
            for (int sid = 0; sid < layer.shellCursor; sid++)
            {
                DysonShell shell = layer.shellPool[sid];
                if (shell == null || sid != shell.id)
                    continue;
```

`Source/EarlierWorkingSource/SymmetryTool.cs:521`

```csharp

        [HarmonyPrefix, HarmonyPatch(typeof(DESelection), "OnShellClick")]
        public static bool Overwrite_OnFrameClick(DESelection __instance, DysonShell shell)
        {
            if (!overwrite || shell == null)
```

### Code in the related copy

`RelatedMods/starfi5h-LossyCompression/Source/Reconstructed/plugins/LossyCompression/LossyCompression/DysonShellCompress.cs:12`

```csharp
namespace LossyCompression;

internal class DysonShellCompress
{
	public static readonly int EncodedVersion = 2;
```

`RelatedMods/starfi5h-LossyCompression/Source/Reconstructed/plugins/LossyCompression/LossyCompression/LazyLoading.cs:76`

```csharp
		{
			dysonSphereMasks[___dysonSphere] |= editorMask | gameMask;
			DysonShellCompress.GenerateModel(viewingSphere, dysonSphereMasks[___dysonSphere]);
			if (dysonSphereMasks[___dysonSphere] == -1)
			{
```

`RelatedMods/starfi5h-LossyCompression/Source/Reconstructed/plugins/LossyCompression/LossyCompression/ModCompatibility.cs:61`

```csharp

		[HarmonyPrefix]
		[HarmonyPatch(typeof(DysonShell), "SetMaterialDynamicVars")]
		public static bool SetMaterialDynamicVars(DysonShell __instance)
		{
```

`RelatedMods/starfi5h-LossyCompression/Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs:40`

```csharp
		ConfigEntry<bool> configEntry3 = base.Config.Bind("Advance", "ReduceRAM", defaultValue: false, "Release models generated by lazy load for vanilla game save to reduce RAM usage.\n不保留延迟载入在保存原版存档时生成的模型。可减少内存占用");
		ConfigEntry<bool> configEntry4 = base.Config.Bind("Dependent", "CargoPath", defaultValue: false, "Lossy compress for belts & cargo (will change vanilla save)\n有损压缩传送带数据（将更改原档）");
		ConfigEntry<bool> configEntry5 = base.Config.Bind("Independent", "DysonShell", defaultValue: true, "Lossless compress for dyson shells\n无损压缩戴森壳面");
		ConfigEntry<bool> configEntry6 = base.Config.Bind("Independent", "DysonSwarm", defaultValue: true, "Lossy compress for dyson swarm\n有损压缩太阳帆");
		enableFlags += (configEntry4.Value ? 1 : 0);
```

`RelatedMods/starfi5h-LossyCompression/Evidence/InitialPhase/check.cs:54`

```csharp
        try { Call(cargoType, "Decode", path, new BinaryReader(bad)); throw new Exception("unanchored run accepted"); }
        catch (TargetInvocationException e) { Assert(e.InnerException is InvalidDataException, "run without an initial point rejected before geometry mutation"); }
        var shell = Empty<DysonShell>(); shell.id = 1; shell.protoId = 2; shell.randSeed = 17;
        shell.nodes = new List<DysonNode> {new DysonNode {id = 1}, new DysonNode {id = 2}};
        shell.nodecps = new[] {7,11,18}; shell.vertsqOffset = new[] {0, 4, 9}; shell.vertexCount = 9; shell.cpPerVertex = 2;
```
