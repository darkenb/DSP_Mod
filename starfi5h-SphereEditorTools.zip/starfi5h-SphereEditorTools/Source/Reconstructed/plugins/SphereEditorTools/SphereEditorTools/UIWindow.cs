using System;
using UnityEngine;

namespace SphereEditorTools;

internal class UIWindow
{
	public static bool isShow;

	private static bool isMin;

	private static Rect normalSize = new Rect(0f, 0f, 240f, 200f);

	private static Rect miniSize = new Rect(0f, 0f, 75f, 20f);

	private static Rect windowRect = new Rect(300f, 250f, 240f, 200f);

	private static GUIStyle textStyle;

	public static string SpeedInput;

	public static void LoadWindowPos()
	{
		try
		{
			string[] array = SphereEditorTools.WindowPosition.Value.Split(new char[1] { ',' });
			int num = int.Parse(array[0].Trim());
			int num2 = int.Parse(array[^1].Trim());
			windowRect.x = num;
			windowRect.y = num2;
		}
		catch (Exception obj)
		{
			Log.LogWarning("WindowPos parse error, use defualt position (300, 250)");
			Log.LogWarning(obj);
		}
	}

	public static void LoadWindowSize()
	{
		try
		{
			string[] array = SphereEditorTools.WindowSize.Value.Split(new char[1] { ',' });
			int num = int.Parse(array[0].Trim());
			int num2 = int.Parse(array[^1].Trim());
			normalSize.width = num;
			normalSize.height = num2;
			Log.LogDebug($"window size: {num},{num2}");
		}
		catch (Exception obj)
		{
			Log.LogWarning("WindowPos parse error, use defualt size (240, 200)");
			Log.LogWarning(obj);
			normalSize.width = 240f;
			normalSize.height = 200f;
		}
		windowRect.width = normalSize.width;
		windowRect.height = normalSize.height;
	}

	public static void SaveWindowPos()
	{
		string value = $"{windowRect.x}, {windowRect.y}";
		SphereEditorTools.WindowPosition.Value = value;
	}

	public static void OnOpen()
	{
		isShow = true;
		SpeedInput = "";
	}

	public static void OnClose()
	{
		isShow = false;
	}

	public static void OnGUI()
	{
		if (isMin)
		{
			windowRect = GUI.Window(1297890671, windowRect, MinWindowFun, Stringpool.Tool);
		}
		else
		{
			windowRect = GUI.Window(1297890671, windowRect, NormalWindowFun, Stringpool.Tool);
		}
		EatInputInRect(windowRect);
	}

	private static void MinWindowFun(int id)
	{
		GUILayout.BeginArea(new Rect(10f, 1f, 40f, 16f));
		GUILayout.Label(Stringpool.Tool);
		GUILayout.EndArea();
		GUILayout.BeginArea(new Rect(windowRect.width - 27f, 1f, 25f, 16f));
		if (GUILayout.Button("▼"))
		{
			isMin = false;
			windowRect.height = normalSize.height;
			windowRect.width = normalSize.width;
			windowRect.x -= normalSize.width - miniSize.width;
		}
		GUILayout.EndArea();
		GUI.DragWindow();
	}

	private static void NormalWindowFun(int id)
	{
		GUILayout.BeginArea(new Rect(windowRect.width - 27f, 1f, 25f, 16f));
		if (GUILayout.Button("▲"))
		{
			isMin = true;
			windowRect.height = miniSize.height;
			windowRect.width = miniSize.width;
			windowRect.x += normalSize.width - miniSize.width;
			return;
		}
		GUILayout.EndArea();
		if (SphereEditorTools.EnableDisplayOptions.Value)
		{
			GUILayout.BeginVertical(GUI.skin.box);
			GUILayout.BeginHorizontal();
			GUILayout.Label(Stringpool.Display_options);
			bool flag = Comm.DisplayMode < 2;
			if (flag != GUILayout.Toggle(flag, Stringpool.Star))
			{
				Comm.DisplayMode ^= 2;
				HideLayer.SetDisplayMode(Comm.DisplayMode);
			}
			if (HideLayer.EnableMask != GUILayout.Toggle(HideLayer.EnableMask, Stringpool.Mask))
			{
				HideLayer.SetMask(!HideLayer.EnableMask);
			}
			GUILayout.EndHorizontal();
			GUILayout.EndVertical();
		}
		if (SphereEditorTools.EnableSymmetryTool.Value)
		{
			GUILayout.BeginVertical(GUI.skin.box);
			GUILayout.BeginHorizontal();
			GUILayout.Label(Stringpool.SymmetryTool, GUILayout.MinWidth(180f));
			if (GUILayout.Toggle(Comm.SymmetricMode, "", GUILayout.Width(20f)) != Comm.SymmetricMode)
			{
				Comm.SetSymmetricMode(!Comm.SymmetricMode);
			}
			GUILayout.EndHorizontal();
			int result = GUILayout.Toolbar(Comm.MirrorMode, Stringpool.MirrorModes);
			if (result != Comm.MirrorMode)
			{
				Comm.MirrorMode = result;
				SymmetryTool.ChangeParameters(Comm.MirrorMode, Comm.RadialCount);
				Comm.SymmetricMode = true;
			}
			GUILayout.BeginHorizontal();
			if (GUILayout.Button("<<"))
			{
				Comm.RadialCount = Math.Max(Comm.RadialCount - 10, 1);
				SymmetryTool.ChangeParameters(Comm.MirrorMode, Comm.RadialCount);
				Comm.SymmetricMode = true;
			}
			if (GUILayout.Button("-"))
			{
				if (Comm.RadialCount > 1)
				{
					SymmetryTool.ChangeParameters(Comm.MirrorMode, --Comm.RadialCount);
				}
				Comm.SymmetricMode = true;
			}
			if (textStyle == null)
			{
				textStyle = new GUIStyle(GUI.skin.textField)
				{
					alignment = TextAnchor.MiddleCenter
				};
			}
			if (int.TryParse(GUILayout.TextField(Comm.RadialCount.ToString(), 3, textStyle, GUILayout.MinWidth(35f)), out result) && result != Comm.RadialCount && result < Comm.MaxRadialCount && result > 0)
			{
				Comm.RadialCount = result;
				SymmetryTool.ChangeParameters(Comm.MirrorMode, Comm.RadialCount);
				Comm.SymmetricMode = true;
			}
			if (GUILayout.Button("+"))
			{
				if (Comm.RadialCount < Comm.MaxRadialCount)
				{
					SymmetryTool.ChangeParameters(Comm.MirrorMode, ++Comm.RadialCount);
				}
				Comm.SymmetricMode = true;
			}
			if (GUILayout.Button(">>"))
			{
				Comm.RadialCount = Math.Min(Comm.RadialCount + 10, Comm.MaxRadialCount);
				SymmetryTool.ChangeParameters(Comm.MirrorMode, Comm.RadialCount);
				Comm.SymmetricMode = true;
			}
			GUILayout.EndHorizontal();
			GUILayout.EndVertical();
		}
		if (SphereEditorTools.EnableOrbitTool.Value)
		{
			GUILayout.BeginVertical(GUI.skin.box);
			GUILayout.BeginHorizontal();
			GUILayout.Label(Stringpool.OrbitTool);
			bool flag = EditOrbit.EnableAnchorMode;
			if (flag != GUILayout.Toggle(flag, Stringpool.AnchorMode))
			{
				EditOrbit.Toggle(!flag);
			}
			GUILayout.EndHorizontal();
			GUILayout.BeginHorizontal();
			GUILayout.Label(Stringpool.AngularSpeed);
			SpeedInput = GUILayout.TextField(SpeedInput, 7, GUILayout.MinWidth(35f));
			if (GUILayout.Button(Stringpool.Set1))
			{
				if (float.TryParse(SpeedInput, out var result2) && result2 >= 0f)
				{
					EditOrbit.TrySetAngularSpeed(result2);
				}
				else if (SpeedInput == "")
				{
					EditOrbit.TrySetAngularSpeed(-1f);
				}
				else
				{
					SpeedInput = EditOrbit.AuglarSpeed.ToString();
				}
			}
			GUILayout.EndHorizontal();
			GUILayout.EndVertical();
		}
		GUI.DragWindow();
	}

	public static void EatInputInRect(Rect eatRect)
	{
		if ((Input.GetMouseButton(0) || Input.GetMouseButtonDown(0)) && eatRect.Contains(new Vector2(Input.mousePosition.x, (float)Screen.height - Input.mousePosition.y)))
		{
			Input.ResetInputAxes();
		}
	}
}
