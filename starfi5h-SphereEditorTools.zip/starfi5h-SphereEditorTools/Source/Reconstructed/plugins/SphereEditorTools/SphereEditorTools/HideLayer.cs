using HarmonyLib;
using UnityEngine;

namespace SphereEditorTools;

internal class HideLayer : MonoBehaviour
{
	private static int displayMode;

	public static bool EnableMask;

	private static GameObject blackmask;

	[HarmonyPostfix]
	[HarmonyPatch(typeof(DESelection), "SetViewStar")]
	public static void SetViewStar_Postfix()
	{
		Free();
		SetDisplayMode(displayMode);
		SetMask(EnableMask);
	}

	public static void Free()
	{
		if (blackmask != null)
		{
			Object.Destroy(blackmask);
			blackmask = null;
		}
	}

	public static void SetDisplayMode(int mode)
	{
		displayMode = mode;
		GameObject.Find("UI Root/Dyson Map/Star")?.SetActive(displayMode < 2);
		SetMask((mode & 1) == 1);
	}

	public static void SetMask(bool enable)
	{
		if (blackmask == null)
		{
			GameObject gameObject = GameObject.Find("UI Root/Dyson Map/Star/black-mask");
			if (gameObject == null)
			{
				return;
			}
			blackmask = Object.Instantiate(gameObject, gameObject.transform.parent.parent);
			Object.Destroy(blackmask.GetComponent<SphereCollider>());
			GameObject gameObject2 = GameObject.Find("UI Root/Dyson Map/preview/compass");
			blackmask.transform.localScale = new Vector3(gameObject2.transform.localScale.x, gameObject2.transform.localScale.y, 0f);
		}
		blackmask.SetActive(enable);
		EnableMask = enable;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(DysonMapCamera), "_OnLateUpdate")]
	public static void UpdateMask(DysonMapCamera __instance)
	{
		if (EnableMask && blackmask != null)
		{
			blackmask.transform.rotation = __instance.editorCamera.transform.rotation;
		}
	}
}
