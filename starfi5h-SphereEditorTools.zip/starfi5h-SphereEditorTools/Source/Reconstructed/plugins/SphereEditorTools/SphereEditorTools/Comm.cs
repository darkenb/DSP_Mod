using HarmonyLib;
using UnityEngine;

namespace SphereEditorTools;

internal class Comm
{
	public static UIDysonEditor dysonEditor;

	private static string infoString;

	private static int infoCounter;

	public static int DisplayMode;

	public static bool SymmetricMode = true;

	public static int MirrorMode;

	public static int RadialCount = 1;

	public static int MaxRadialCount = 90;

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDysonEditor), "_OnOpen")]
	public static void Init(UIDysonEditor __instance)
	{
		dysonEditor = __instance;
		Stringpool.Set();
		if (SphereEditorTools.EnableGUI.Value)
		{
			UIWindow.OnOpen();
		}
		HideLayer.SetDisplayMode(DisplayMode);
		HideLayer.SetMask(HideLayer.EnableMask);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDysonEditor), "_OnClose")]
	public static void Free()
	{
		dysonEditor = null;
		if (SphereEditorTools.EnableGUI.Value)
		{
			UIWindow.OnClose();
		}
		HideLayer.Free();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameMain), "Resume")]
	public static void OnResume()
	{
		UIWindow.SaveWindowPos();
		SphereEditorTools.Config.Reload();
		Stringpool.Set();
		UIWindow.LoadWindowPos();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameMain), "End")]
	public static void OnGameEnd()
	{
		if (SphereEditorTools.EnableGUI.Value)
		{
			UIWindow.SaveWindowPos();
		}
		SphereEditorTools.Config.Save();
	}

	public static void SetInfoString(string str, int counter)
	{
		infoString = str;
		infoCounter = counter;
	}

	public static void ShowSymmetricToolStatus()
	{
		string str = ((!SymmetricMode) ? $"{Stringpool.SymmetricTool} OFF" : $"{Stringpool.SymmetricTool} {Stringpool.Rotation}:{RadialCount,-2} {Stringpool.Mirror}:{Stringpool.MirrorModes[MirrorMode]}");
		SetInfoString(str, 120);
	}

	public static void SetSymmetricMode(bool state)
	{
		SymmetricMode = state;
		if (SymmetricMode)
		{
			SymmetryTool.ChangeParameters(MirrorMode, RadialCount);
		}
		else
		{
			SymmetryTool.ChangeParameters(0, 1);
		}
		ShowSymmetricToolStatus();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDysonEditor), "UpdateBrushes")]
	public static void Update_CheckKeyDown(UIDysonEditor __instance)
	{
		if (infoCounter > 0)
		{
			__instance.controlPanel.toolbox.brushError = infoString;
			infoCounter--;
		}
		if (!Input.anyKeyDown)
		{
			return;
		}
		infoCounter = 0;
		DysonSphereLayer singleSelectedLayer = __instance.selection.singleSelectedLayer;
		if (singleSelectedLayer != null && SphereEditorTools.EnableToolboxHotkey.Value)
		{
			if (Input.GetKeyDown(SphereEditorTools.KeySelect.Value))
			{
				__instance.brushMode = UIDysonEditor.EBrushMode.Select;
			}
			else if (Input.GetKeyDown(SphereEditorTools.KeyNode.Value))
			{
				__instance.brushMode = ((__instance.brushMode == UIDysonEditor.EBrushMode.Node) ? UIDysonEditor.EBrushMode.Select : UIDysonEditor.EBrushMode.Node);
			}
			else if (Input.GetKeyDown(SphereEditorTools.KeyFrameGeo.Value))
			{
				__instance.brushMode = ((__instance.brushMode == UIDysonEditor.EBrushMode.FrameGeo) ? UIDysonEditor.EBrushMode.Select : UIDysonEditor.EBrushMode.FrameGeo);
			}
			else if (Input.GetKeyDown(SphereEditorTools.KeyFrameEuler.Value))
			{
				__instance.brushMode = ((__instance.brushMode == UIDysonEditor.EBrushMode.FrameEuler) ? UIDysonEditor.EBrushMode.Select : UIDysonEditor.EBrushMode.FrameEuler);
			}
			else if (Input.GetKeyDown(SphereEditorTools.KeyShell.Value))
			{
				__instance.brushMode = ((__instance.brushMode == UIDysonEditor.EBrushMode.Shell) ? UIDysonEditor.EBrushMode.Select : UIDysonEditor.EBrushMode.Shell);
			}
			else if (Input.GetKeyDown(SphereEditorTools.KeyGrid.Value))
			{
				singleSelectedLayer.drawingGridMode = (singleSelectedLayer.drawingGridMode + 1) % 5;
			}
		}
		if (Input.GetKeyDown(SphereEditorTools.KeyHideMode.Value))
		{
			DisplayMode = (DisplayMode + 1) % 4;
			HideLayer.SetDisplayMode(DisplayMode);
			SetInfoString(Stringpool.DisplayMode[DisplayMode], 120);
		}
		if (!SphereEditorTools.EnableSymmetryTool.Value)
		{
			return;
		}
		if (Input.GetKeyDown(SphereEditorTools.KeySymmetryTool.Value))
		{
			SetSymmetricMode(!SymmetricMode);
		}
		else if (Input.GetKeyDown(SphereEditorTools.KeyMirroring.Value))
		{
			SymmetricMode = true;
			MirrorMode = (MirrorMode + 1) % 3;
			SymmetryTool.ChangeParameters(MirrorMode, RadialCount);
			ShowSymmetricToolStatus();
		}
		else if (Input.GetKeyDown(SphereEditorTools.KeyRotationInc.Value))
		{
			SymmetricMode = true;
			if (RadialCount < MaxRadialCount)
			{
				SymmetryTool.ChangeParameters(MirrorMode, ++RadialCount);
			}
			ShowSymmetricToolStatus();
		}
		else if (Input.GetKeyDown(SphereEditorTools.KeyRotationDec.Value))
		{
			SymmetricMode = true;
			if (RadialCount > 1)
			{
				SymmetryTool.ChangeParameters(MirrorMode, --RadialCount);
			}
			ShowSymmetricToolStatus();
		}
	}
}
