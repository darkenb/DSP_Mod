using BepInEx.Logging;

namespace SphereEditorTools;

public static class Log
{
	private static ManualLogSource _logger;

	public static void Init(ManualLogSource logger)
	{
		_logger = logger;
	}

	public static void LogError(object obj)
	{
		_logger.LogError(obj);
	}

	public static void LogWarning(object obj)
	{
		_logger.LogWarning(obj);
	}

	public static void LogInfo(object obj)
	{
		_logger.LogInfo(obj);
	}

	public static void LogDebug(object obj)
	{
		_logger.LogDebug(obj);
	}

	public static void LogPeriod(object obj)
	{
		if (GameMain.gameTick % 600 == 0L)
		{
			_logger.LogDebug(obj);
		}
	}
}
