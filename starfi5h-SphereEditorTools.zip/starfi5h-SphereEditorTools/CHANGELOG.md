# starfi5h-SphereEditorTools — detailed change report

Installed plugin version(s): **2.2.7**. Anchor only the selected layer and restore its actual rotation speed on editor/game/plugin exit.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Selected-layer state and paint preservation — 2.2.6/2.2.7

Use the source matching installed 2.2.5. Retain assembly identity, native geometry and save paths.

- Restrict anchored-orbit intervention to the selected layer. Other layers still run native `InitOrbitRotation`.
- Save the actual rotation speed on entering anchor mode; repeated entry must not overwrite it with zero. Restore it and release selection on editor close, game end and plugin unload.
- Tolerate lost/null selection and reject NaN/Infinity angular-speed input before writing layer state.
- Preserve shell paint when rebuilding after a radius change: retain native `DysonShell.color` before dismantling and restore it to the new shell. Validate the relevant IL order.
- Do not change shell/node serialization or add unrelated vegetation/lens/research features.

Version 2.2.7 adds `/unsafe+` access metadata, verified in embedded Mono without changing game files. Native layer-data tests cover entry, repeated entry and speed restoration. Real shader/paint appearance, populated-shell editing, complete geometry and color/energy round trips with LossyCompression/DSPOptimizations remain unverified in game.

## Recorded source commits

- `bfd39e2629922da1d5b89b82199e05dada9f6b1e`

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
