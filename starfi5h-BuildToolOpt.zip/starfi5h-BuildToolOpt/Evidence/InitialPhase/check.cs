using System;
using System.Reflection;
using HarmonyLib;

static class Check
{
    static void Require(bool condition, string message) { if (!condition) throw new Exception(message); }
    static int Main()
    {
        var type = typeof(BuildToolOpt.Plugin).Assembly.GetType("BuildToolOpt.ReplaceStationLogic");
        var merge = AccessTools.Method(type, "MergeStock");
        foreach (var sample in new[] {new[] {3,4,10,7,0}, new[] {9,4,10,10,3}, new[] {5,0,10,5,0}, new[] {7,4,0,0,11}})
        {
            object[] args = {sample[0], sample[1], sample[2], 0};
            Require((int)merge.Invoke(null, args) == sample[3] && (int)args[3] == sample[4], "Stock not conserved");
        }
        var takeBack = AccessTools.Method(type, "TakeBackItems_Station");
        object[] skipped = {null, 1, false};
        takeBack.Invoke(null, skipped);
        Require(!(bool)skipped[2], "Earlier Harmony skip overridden");
        object[] unrelated = {null, 1, true};
        takeBack.Invoke(null, unrelated);
        Require((bool)unrelated[2], "Unrelated transport suppressed");
        try { AccessTools.Method(type, "ReplaceStation").Invoke(null, new object[] {null, 1}); }
        catch (TargetInvocationException) { }
        Require(!(bool)AccessTools.Property(type, "IsReplacing").GetValue(null, null), "Failed operation retained flag");
        Console.WriteLine("PASS stock conservation and earlier Harmony skip; exception cleanup verified");
        return 0;
    }
}
