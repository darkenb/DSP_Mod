using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading;
using Auxilaryfunction.Models;
using Auxilaryfunction.Patch;
using UnityEngine;
using UnityEngine.UI;

namespace Auxilaryfunction.Services;

public class GUIDraw
{
	private const float TitleBarHeight = 20f;

	private const float BorderMargin = 10f;

	private const float EdgeTolerance = 10f;

	public static Color BlueColor;

	public static bool blueprintopen;

	public static Vector2 dysonBluePrintscrollPosition;

	public static Sprite flatsprite;

	public static Sprite leftsprite;

	public static bool limitmaterial;

	public static Color OrangeColor;

	public static Sprite rightsprite;

	public static Vector2 scrollPosition;

	public static bool showwindow;

	public static Sprite trashcan;

	public static Sprite trashcanOpen;

	public bool AutoUnlockTechInSandBox;

	public float MainWindow_x = 300f;

	public float DragStartWindowX = 200f;

	public float MainWindow_y = 200f;

	public float DragStartWindowY = 200f;

	public Texture2D mytexture;

	public bool selectautoaddtechid;

	public Texture2D stationbluetexture;

	public float DragStartMouseX = 10f;

	public float DragStartMouseY = 200f;

	public int whichpannel;

	private float _windowheight;

	private float _windowwidth;

	private int baseSize;

	private GUILayoutOption[] bigiconbuttonoptions;

	private bool bottomscaling;

	private GUILayoutOption[] buttonoptions;

	private GUIStyle buttonstyleblue;

	private GUIStyle buttonstyleyellow;

	private bool DeleteDysonLayer;

	private bool firstDraw;

	private bool wasShowWindow;

	private int panelSyncScreenW = -1;

	private int panelSyncScreenH = -1;

	private float panelSyncCanvasW = -1f;

	private float panelSyncCanvasH = -1f;

	private int heightdis;

	private GUILayoutOption[] HorizontalSlideroptions;

	private GUILayoutOption[] iconbuttonoptions;

	private GUIStyle imageButtonNormalStyle;

	private GUIStyle imageButtonSelectedStyle;

	private GUIStyle labelstyle;

	private bool leftscaling;

	private string[] menus;

	private bool isDragging;

	private GUIStyle nomarginButtonStyle;

	private GUIStyle normalstyle;

	private GUILayoutOption[] numberButtonoptions;

	private bool RefreshBaseSize;

	private bool rightscaling;

	private GUIStyle selectedButtonStyle;

	private GUIStyle styleblue;

	private GUIStyle styleitemname;

	private GUIStyle styleyellow;

	private GameObject ui_AuxilaryPanelPanel;

	public StationTip[] stationtips = new StationTip[Auxilaryfunction.maxCount];

	private static int stationGroupButtonCountCache;

	public int BaseSize
	{
		get
		{
			return baseSize;
		}
		set
		{
			baseSize = value;
			AuxConfig.scale.Value = value;
			RefreshBaseSize = true;
			heightdis = value * 2;
		}
	}

	public float MainWindowHeight
	{
		get
		{
			return _windowheight;
		}
		set
		{
			if (_windowheight != value)
			{
				_windowheight = value;
				AuxConfig.window_height.Value = value;
			}
		}
	}

	public float MainWindowWidth
	{
		get
		{
			return _windowwidth;
		}
		set
		{
			if (_windowwidth != value)
			{
				_windowwidth = value;
				AuxConfig.window_width.Value = value;
			}
		}
	}

	public GUIDraw(int baseSize, GameObject panel)
	{
		BaseSize = baseSize;
		ui_AuxilaryPanelPanel = panel;
		Init();
	}

	public void CloseTrashStorageWindow()
	{
		Auxilaryfunction.TrashCanButton.transform.Find("button-1/icon").GetComponent<Image>().sprite = trashcan;
		Auxilaryfunction.TrashStorageWindow.SetActive(value: false);
		Auxilaryfunction.uiTrashStorageWindow.storageUI._Free();
		Auxilaryfunction.TrashStorage.Clear();
	}

	public void Draw()
	{
		if (firstDraw)
		{
			firstDraw = false;
			BaseSize = GUI.skin.label.fontSize;
		}
		if (showwindow && Input.GetKey(KeyCode.LeftControl))
		{
			int num = (int)(Input.GetAxis("Mouse Wheel") * 10f);
			int num2 = BaseSize + num;
			if (Input.GetKeyDown(KeyCode.UpArrow))
			{
				num2++;
			}
			if (Input.GetKeyDown(KeyCode.DownArrow))
			{
				num2--;
			}
			num2 = Math.Max(5, Math.Min(num2, 35));
			BaseSize = num2;
		}
		if (RefreshBaseSize)
		{
			RefreshBaseSize = false;
			GUI.skin.label.fontSize = BaseSize;
			GUI.skin.button.fontSize = BaseSize;
			GUI.skin.toggle.fontSize = BaseSize;
			GUI.skin.textField.fontSize = BaseSize;
			GUI.skin.textArea.fontSize = BaseSize;
			labelstyle = new GUIStyle(GUI.skin.label)
			{
				fontSize = BaseSize - 3
			};
			labelstyle.normal.textColor = GUI.skin.toggle.normal.textColor;
			if (selectedButtonStyle != null)
			{
				selectedButtonStyle.fontSize = BaseSize;
			}
			for (int i = 0; i < Constant.StationStoreStyles.Length; i++)
			{
				if (Constant.StationStoreStyles[i] != null)
				{
					Constant.StationStoreStyles[i].fontSize = BaseSize;
				}
			}
			HorizontalSlideroptions = new GUILayoutOption[2]
			{
				GUILayout.Height(BaseSize),
				GUILayout.Width(BaseSize * 10)
			};
			buttonoptions = new GUILayoutOption[1] { GUILayout.Height(BaseSize * 2) };
			iconbuttonoptions = new GUILayoutOption[2]
			{
				GUILayout.Width(heightdis),
				GUILayout.Height(heightdis)
			};
			numberButtonoptions = iconbuttonoptions;
			bigiconbuttonoptions = new GUILayoutOption[2]
			{
				GUILayout.Width((float)heightdis * 1.5f),
				GUILayout.Height((float)heightdis * 1.5f)
			};
		}
		if (styleitemname == null)
		{
			imageButtonNormalStyle = new GUIStyle
			{
				margin = new RectOffset()
			};
			imageButtonSelectedStyle = new GUIStyle
			{
				margin = new RectOffset()
			};
			imageButtonSelectedStyle.normal.background = Texture2D.whiteTexture;
			styleitemname = new GUIStyle(GUI.skin.label);
			styleitemname.normal.textColor = Color.white;
			buttonstyleblue = new GUIStyle(GUI.skin.button);
			buttonstyleblue.normal.textColor = styleblue.normal.textColor;
			buttonstyleblue.hover.textColor = styleblue.normal.textColor;
			buttonstyleblue.margin = new RectOffset();
			buttonstyleyellow = new GUIStyle(GUI.skin.button);
			buttonstyleyellow.normal.textColor = styleyellow.normal.textColor;
			buttonstyleyellow.hover.textColor = styleyellow.normal.textColor;
			buttonstyleyellow.margin = new RectOffset();
			selectedButtonStyle = new GUIStyle(GUI.skin.button);
			selectedButtonStyle.normal.textColor = new Color32(215, 186, 245, byte.MaxValue);
			nomarginButtonStyle = new GUIStyle(GUI.skin.button)
			{
				margin = new RectOffset()
			};
			Constant.StationStoreStyles[0] = nomarginButtonStyle;
			Constant.StationStoreStyles[1] = buttonstyleblue;
			Constant.StationStoreStyles[2] = buttonstyleyellow;
		}
		if (showwindow)
		{
			bool num3 = MoveWindow();
			bool flag = Scaling_window();
			Rect rect = new Rect(MainWindow_x, MainWindow_y, MainWindowWidth, MainWindowHeight);
			GUI.DrawTexture(rect, mytexture);
			rect = GUI.Window(20210827, rect, MainWindow, "辅助面板".getTranslate() + "(3.0.9)ps:ctrl+↑↓");
			RectTransform component = UIRoot.instance.overlayCanvas.GetComponent<RectTransform>();
			if (num3 || flag || !wasShowWindow || panelSyncScreenW != Screen.width || panelSyncScreenH != Screen.height || panelSyncCanvasW != component.sizeDelta.x || panelSyncCanvasH != component.sizeDelta.y)
			{
				UIPanelSet();
				panelSyncScreenW = Screen.width;
				panelSyncScreenH = Screen.height;
				panelSyncCanvasW = component.sizeDelta.x;
				panelSyncCanvasH = component.sizeDelta.y;
			}
			ui_AuxilaryPanelPanel.SetActive(value: true);
		}
		else
		{
			ResetWindowInteraction();
		}
		wasShowWindow = showwindow;
		NavigateGUI();
	}

	public void GUIUpdate()
	{
		if (Auxilaryfunction.GameDataImported)
		{
			bool flag = false;
			if (!AuxConfig.ChangingQuickKey)
			{
				if (AuxConfig.QuickKey.Value.Modifiers.Count() == 0)
				{
					if (Input.GetKeyDown(AuxConfig.QuickKey.Value.MainKey))
					{
						flag = true;
					}
				}
				else if (Input.GetKey(AuxConfig.QuickKey.Value.MainKey))
				{
					flag = true;
					foreach (KeyCode modifier in AuxConfig.QuickKey.Value.Modifiers)
					{
						if (!Input.GetKeyDown(modifier))
						{
							flag = false;
						}
					}
				}
			}
			if (flag)
			{
				showwindow = !showwindow;
				if (showwindow)
				{
					firstDraw = true;
				}
				ui_AuxilaryPanelPanel.SetActive(showwindow);
			}
			else if (!AuxConfig.ChangingBluePrintQuickKey)
			{
				if (AuxConfig.BluePrintShowWindow.Value.Modifiers.Count() == 0)
				{
					if (Input.GetKeyDown(AuxConfig.BluePrintShowWindow.Value.MainKey))
					{
						flag = true;
					}
				}
				else if (Input.GetKey(AuxConfig.BluePrintShowWindow.Value.MainKey))
				{
					flag = true;
					foreach (KeyCode modifier2 in AuxConfig.BluePrintShowWindow.Value.Modifiers)
					{
						if (!Input.GetKeyDown(modifier2))
						{
							flag = false;
						}
					}
				}
				if (flag)
				{
					showwindow = !showwindow;
					if (showwindow)
					{
						firstDraw = true;
						whichpannel = 7;
						MainWindow_x = Input.mousePosition.x;
						MainWindow_y = (float)Screen.height - Input.mousePosition.y;
					}
					else
					{
						ui_AuxilaryPanelPanel.SetActive(value: false);
					}
				}
			}
		}
		StationInfoWindowUpdate();
	}

	public Sprite LoadImage(string filename)
	{
		Stream manifestResourceStream = Assembly.GetExecutingAssembly().GetManifestResourceStream(filename);
		byte[] array = new byte[manifestResourceStream.Length];
		manifestResourceStream.Read(array, 0, (int)manifestResourceStream.Length);
		manifestResourceStream.Close();
		Texture2D texture2D = new Texture2D(16, 16);
		texture2D.LoadImage(array);
		return Sprite.Create(texture2D, new Rect(0f, 0f, 16f, 16f), new Vector2(0.5f, 0.5f));
	}

	private void NavigateGUI()
	{
		if (!Auxilaryfunction.GameDataImported || Auxilaryfunction.player == null || GameMain.mainPlayer == null)
		{
			return;
		}
		if (AuxConfig.autonavigation_bool.Value && PlayerOperationPatch.NeedNavigation)
		{
			Rect rect = new Rect(10f, Screen.height / 2 - BaseSize * 5, BaseSize * 7, BaseSize * 5);
			GUI.DrawTexture(rect, mytexture);
			GUILayout.BeginArea(rect);
			GUILayout.BeginHorizontal();
			GUILayout.BeginVertical();
			if (GUILayout.Button(PlayerOperationPatch.FlyStatus ? "暂停导航".getTranslate() : "继续导航".getTranslate(), GUILayout.MinHeight(heightdis)))
			{
				PlayerOperationPatch.FlyStatus = !PlayerOperationPatch.FlyStatus;
			}
			if (GUILayout.Button("取消方向指示".getTranslate(), GUILayout.MinHeight(heightdis)))
			{
				PlayerOperationPatch.FlyStatus = false;
				UIRoot.instance?.uiGame?.dfMonitor?.trackingHives?.Clear();
				PlayerOperationPatch.ClearFollow();
			}
			GUILayout.EndVertical();
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
			GUILayout.EndArea();
		}
		if (AuxConfig.LocalPlanet?.factory != null && Auxilaryfunction.player.movementState == EMovementState.Fly)
		{
			GUILayout.BeginArea(new Rect(10f, Screen.height / 2 - BaseSize * 5, BaseSize * 15, BaseSize * 5));
			GUILayout.BeginHorizontal();
			GUILayout.BeginVertical();
			if (AuxConfig.automovetounbuilt.Value)
			{
				if (AuxConfig.LocalPlanet.factory.prebuildCount > 0)
				{
					if (GUILayout.Button(Auxilaryfunction.StartAutoMovetounbuilt ? "停止寻找未完成建筑".getTranslate() : "开始寻找未完成建筑".getTranslate()))
					{
						Auxilaryfunction.StartAutoMovetounbuilt = !Auxilaryfunction.StartAutoMovetounbuilt;
						Auxilaryfunction.player.gameObject.GetComponent<SphereCollider>().enabled = !Auxilaryfunction.StartAutoMovetounbuilt;
						Auxilaryfunction.player.gameObject.GetComponent<CapsuleCollider>().enabled = !Auxilaryfunction.StartAutoMovetounbuilt;
					}
					if (Auxilaryfunction.StartAutoMovetounbuilt && AuxConfig.LocalPlanet.gasItems == null && GUILayout.Button(Auxilaryfunction.autobuildgetitem ? "停止自动补充材料".getTranslate() : "开始自动补充材料".getTranslate()))
					{
						Auxilaryfunction.autobuildgetitem = !Auxilaryfunction.autobuildgetitem;
					}
				}
				else if (Auxilaryfunction.StartAutoMovetounbuilt)
				{
					Auxilaryfunction.StartAutoMovetounbuilt = false;
					Auxilaryfunction.player.gameObject.GetComponent<SphereCollider>().enabled = true;
					Auxilaryfunction.player.gameObject.GetComponent<CapsuleCollider>().enabled = true;
				}
			}
			if (AuxConfig.automovetodarkfog.Value)
			{
				if (AuxConfig.LocalPlanet.factory.enemyCount > 0)
				{
					if (GUILayout.Button(Auxilaryfunction.StartAutoMovetoDarkfog ? "停止飞向黑雾基地".getTranslate() : "开始飞向黑雾基地".getTranslate()))
					{
						Auxilaryfunction.StartAutoMovetoDarkfog = !Auxilaryfunction.StartAutoMovetoDarkfog;
						Auxilaryfunction.player.gameObject.GetComponent<SphereCollider>().enabled = !Auxilaryfunction.StartAutoMovetoDarkfog;
						Auxilaryfunction.player.gameObject.GetComponent<CapsuleCollider>().enabled = !Auxilaryfunction.StartAutoMovetoDarkfog;
					}
					if (Auxilaryfunction.StartAutoMovetoDarkfog && GUILayout.Button(Auxilaryfunction.autoRemoveRuin ? "停止自动填埋".getTranslate() : "开始自动填埋".getTranslate()))
					{
						Auxilaryfunction.autoRemoveRuin = !Auxilaryfunction.autoRemoveRuin;
					}
				}
				else if (Auxilaryfunction.StartAutoMovetoDarkfog)
				{
					Auxilaryfunction.StartAutoMovetoDarkfog = false;
					Auxilaryfunction.player.gameObject.GetComponent<SphereCollider>().enabled = true;
					Auxilaryfunction.player.gameObject.GetComponent<CapsuleCollider>().enabled = true;
				}
			}
			GUILayout.EndVertical();
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
			GUILayout.EndArea();
		}
		else if (Auxilaryfunction.StartAutoMovetounbuilt || Auxilaryfunction.StartAutoMovetoDarkfog)
		{
			Auxilaryfunction.StartAutoMovetounbuilt = false;
			Auxilaryfunction.StartAutoMovetoDarkfog = false;
			Auxilaryfunction.player.gameObject.GetComponent<SphereCollider>().enabled = true;
			Auxilaryfunction.player.gameObject.GetComponent<CapsuleCollider>().enabled = true;
		}
	}

	private void GameWindowCopyInit()
	{
		try
		{
			Auxilaryfunction.stationTipRoot = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Scene UIs/Vein Marks"), GameObject.Find("UI Root/Overlay Canvas/In Game/Scene UIs").transform);
			Auxilaryfunction.stationTipRoot.name = "stationTip";
			UnityEngine.Object.Destroy(Auxilaryfunction.stationTipRoot.GetComponent<UIVeinDetail>());
			Auxilaryfunction.tipPrefab = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Scene UIs/Vein Marks/vein-tips/vein-tip-prefab"), Auxilaryfunction.stationTipRoot.transform);
			Auxilaryfunction.tipPrefab.name = "tipPrefab";
			Auxilaryfunction.tipPrefab.GetComponent<Image>().sprite = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Key Tips/tip-prefab").GetComponent<Image>().sprite;
			Auxilaryfunction.tipPrefab.GetComponent<Image>().color = new Color(0f, 0f, 0f, 0.8f);
			Auxilaryfunction.tipPrefab.GetComponent<RectTransform>().sizeDelta = new Vector2(150f, 160f);
			Auxilaryfunction.tipPrefab.GetComponent<Image>().enabled = true;
			Auxilaryfunction.tipPrefab.transform.localPosition = new Vector3(200f, 800f, 0f);
			Auxilaryfunction.tipPrefab.GetComponent<RectTransform>().pivot = new Vector2(0.5f, 0.5f);
			UnityEngine.Object.Destroy(Auxilaryfunction.tipPrefab.GetComponent<UIVeinDetailNode>());
			GameObject gameObject = Auxilaryfunction.tipPrefab.transform.Find("info-text").gameObject;
			for (int i = 0; i < 13; i++)
			{
				GameObject gameObject2 = UnityEngine.Object.Instantiate(gameObject, Vector3.zero, Quaternion.identity, Auxilaryfunction.tipPrefab.transform);
				gameObject2.name = "countText" + i;
				float num = -5 - 35 * i;
				gameObject2.GetComponent<Text>().fontSize = ((i == 5) ? 15 : 19);
				gameObject2.GetComponent<Text>().text = "99999";
				gameObject2.GetComponent<Text>().alignment = TextAnchor.MiddleRight;
				gameObject2.GetComponent<RectTransform>().sizeDelta = new Vector2(95f, 30f);
				gameObject2.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
				gameObject2.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
				gameObject2.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
				gameObject2.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(70f, num, 0f);
				UnityEngine.Object.Destroy(gameObject2.GetComponent<Shadow>());
				GameObject gameObject3 = UnityEngine.Object.Instantiate(Auxilaryfunction.tipPrefab.transform.Find("icon").gameObject, new Vector3(0f, 0f, 0f), Quaternion.identity, Auxilaryfunction.tipPrefab.transform);
				gameObject3.name = "icon" + i;
				gameObject2.GetComponent<RectTransform>().sizeDelta = new Vector2(30f, 30f);
				gameObject3.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
				gameObject3.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
				gameObject3.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
				gameObject3.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(0f, num, 0f);
				GameObject gameObject4 = UnityEngine.Object.Instantiate(Auxilaryfunction.tipPrefab.transform.Find("icon").gameObject, new Vector3(0f, 0f, 0f), Quaternion.identity, Auxilaryfunction.tipPrefab.transform);
				gameObject4.name = "iconLocal" + i;
				gameObject4.GetComponent<Image>().material = null;
				gameObject4.GetComponent<RectTransform>().sizeDelta = new Vector2(21f, 21f);
				gameObject4.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
				gameObject4.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
				gameObject4.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
				gameObject4.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(105f, num, 0f);
				GameObject gameObject5 = UnityEngine.Object.Instantiate(Auxilaryfunction.tipPrefab.transform.Find("icon").gameObject, new Vector3(0f, 0f, 0f), Quaternion.identity, Auxilaryfunction.tipPrefab.transform);
				gameObject5.name = "iconremote" + i;
				gameObject5.GetComponent<Image>().material = null;
				gameObject5.GetComponent<RectTransform>().sizeDelta = new Vector2(21f, 21f);
				gameObject5.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
				gameObject5.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
				gameObject5.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
				gameObject5.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(105f, num - 15f, 0f);
			}
			for (int j = 0; j < 3; j++)
			{
				GameObject gameObject6 = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Top Tips/Entity Briefs/brief-info-top/brief-info/content/icons/icon"), new Vector3(0f, 0f, 0f), Quaternion.identity, Auxilaryfunction.tipPrefab.transform);
				gameObject6.name = "icontext" + j;
				gameObject6.GetComponent<RectTransform>().localScale = new Vector3(0.7f, 0.7f, 1f);
				gameObject6.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
				gameObject6.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
				gameObject6.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
				gameObject6.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(j * 30, -180f, 0f);
				GameObject gameObject7 = UnityEngine.Object.Instantiate(gameObject, Vector3.zero, Quaternion.identity, gameObject6.transform);
				gameObject7.name = "countText";
				gameObject7.GetComponent<Text>().fontSize = 22;
				gameObject7.GetComponent<Text>().text = "100";
				gameObject7.GetComponent<Text>().alignment = TextAnchor.MiddleRight;
				gameObject7.GetComponent<RectTransform>().sizeDelta = new Vector2(95f, 30f);
				gameObject7.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
				gameObject7.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
				gameObject7.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
				gameObject7.GetComponent<RectTransform>().localPosition = new Vector3(-50f, -20f, 0f);
				UnityEngine.Object.Destroy(gameObject7.GetComponent<Shadow>());
				if (j != 2)
				{
					GameObject gameObject8 = UnityEngine.Object.Instantiate(gameObject, Vector3.zero, Quaternion.identity, gameObject6.transform);
					gameObject8.name = "countText2";
					gameObject8.GetComponent<Text>().fontSize = 22;
					gameObject8.GetComponent<Text>().text = "100";
					gameObject8.GetComponent<Text>().alignment = TextAnchor.MiddleRight;
					gameObject8.GetComponent<RectTransform>().sizeDelta = new Vector2(95f, 30f);
					gameObject8.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
					gameObject8.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
					gameObject8.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
					gameObject8.GetComponent<RectTransform>().localPosition = new Vector3(-50f, 10f, 0f);
					UnityEngine.Object.Destroy(gameObject8.GetComponent<Shadow>());
				}
				UnityEngine.Object.Destroy(gameObject6.transform.Find("count-text").gameObject);
				UnityEngine.Object.Destroy(gameObject6.transform.Find("bg").gameObject);
				UnityEngine.Object.Destroy(gameObject6.transform.Find("inc").gameObject);
				UnityEngine.Object.Destroy(gameObject6.GetComponent<UIIconCountInc>());
			}
			Auxilaryfunction.tipPrefab.transform.Find("icon").gameObject.SetActive(value: false);
			Auxilaryfunction.tipPrefab.SetActive(value: false);
			for (int k = 0; k < Auxilaryfunction.maxCount; k++)
			{
				StationTip stationTip = UnityEngine.Object.Instantiate(Auxilaryfunction.tipPrefab, Auxilaryfunction.stationTipRoot.transform).AddComponent<StationTip>();
				stationtips[k] = stationTip;
			}
		}
		catch
		{
			Console.WriteLine("StationWindow错误");
		}
		try
		{
			Auxilaryfunction.TrashCanButton = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Game Menu/button-1-bg"), GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Player Inventory").transform);
			Auxilaryfunction.TrashCanButton.transform.Find("button-1/icon").GetComponent<Image>().sprite = trashcan;
			Auxilaryfunction.TrashCanButton.transform.Find("button-1/icon").GetComponent<RectTransform>().sizeDelta = new Vector2(22f, 22f);
			Auxilaryfunction.TrashCanButton.transform.localPosition = new Vector3(630f, -60f, 0f);
			Auxilaryfunction.TrashCanButton.GetComponent<RectTransform>().sizeDelta = new Vector2(40f, 40f);
			Auxilaryfunction.TrashCanButton.GetComponent<RectTransform>().anchorMin = new Vector2(1f, 1f);
			Auxilaryfunction.TrashCanButton.GetComponent<RectTransform>().anchorMax = new Vector2(1f, 1f);
			Auxilaryfunction.TrashCanButton.GetComponent<RectTransform>().anchoredPosition = new Vector2(-58f, -65f);
			Auxilaryfunction.TrashCanButton.GetComponent<UIButton>().tips.tipTitle = "垃圾桶".getTranslate();
			Auxilaryfunction.TrashCanButton.GetComponent<UIButton>().tips.tipText = "开关显示垃圾桶，垃圾桶关闭后自动清理内部物品".getTranslate();
			Auxilaryfunction.TrashCanButton.GetComponent<UIButton>().onClick += delegate
			{
				bool flag = !Auxilaryfunction.TrashStorageWindow.activeSelf;
				if (flag)
				{
					UIRoot.instance.uiGame.ShutAllFunctionWindow();
					Auxilaryfunction.TrashStorageWindow.SetActive(flag);
					Auxilaryfunction.TrashCanButton.transform.Find("button-1/icon").GetComponent<Image>().sprite = trashcanOpen;
					Auxilaryfunction.uiTrashStorageWindow.storageUI._Free();
					Auxilaryfunction.uiTrashStorageWindow.storageUI._Init(Auxilaryfunction.TrashStorage);
					Auxilaryfunction.uiTrashStorageWindow.storageUI._Open();
					Auxilaryfunction.uiTrashStorageWindow.storageUI.OnStorageDataChanged();
				}
				else
				{
					CloseTrashStorageWindow();
				}
			};
			Auxilaryfunction.TrashStorage = new StorageComponent(30);
			Auxilaryfunction.TrashStorageWindow = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Storage Window"), GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Player Inventory").transform);
			Auxilaryfunction.TrashStorageWindow.name = "TrashStorageWindow";
			UnityEngine.Object.Destroy(Auxilaryfunction.TrashStorageWindow.transform.Find("filter-group").gameObject);
			UnityEngine.Object.Destroy(Auxilaryfunction.TrashStorageWindow.transform.Find("panel-bg/drag-trigger").gameObject);
			UnityEngine.Object.Destroy(Auxilaryfunction.TrashStorageWindow.transform.Find("bans-bar").gameObject);
			Auxilaryfunction.uiTrashStorageWindow = Auxilaryfunction.TrashStorageWindow.GetComponent<UIStorageWindow>();
			Auxilaryfunction.uiTrashStorageWindow.windowTrans.anchorMin = new Vector2(1f, 1f);
			Auxilaryfunction.uiTrashStorageWindow.windowTrans.anchorMax = new Vector2(1f, 1f);
			Auxilaryfunction.uiTrashStorageWindow.windowTrans.anchoredPosition = new Vector2(-14f, -25f);
			Auxilaryfunction.uiTrashStorageWindow.windowTrans.pivot = new Vector2(0f, 1f);
			Auxilaryfunction.uiTrashStorageWindow.windowTrans.sizeDelta = new Vector2(Auxilaryfunction.uiTrashStorageWindow.windowTrans.sizeDelta.x, 240f);
			Auxilaryfunction.uiTrashStorageWindow.titleText.text = "垃圾桶".getTranslate();
			Auxilaryfunction.uiTrashStorageWindow.storageUI._Create();
			Auxilaryfunction.uiTrashStorageWindow.transform.Find("panel-bg/btn-box/sort-btn").GetComponent<UIButton>().onClick += delegate
			{
				Auxilaryfunction.TrashStorage.Sort();
			};
			Auxilaryfunction.TrashStorageWindow.transform.Find("panel-bg/btn-box/close-wnd-btn").GetComponent<UIButton>().onClick += delegate
			{
				CloseTrashStorageWindow();
			};
			Auxilaryfunction.TrashStorageWindow.SetActive(value: false);
			Auxilaryfunction.TrashCanButton.SetActive(AuxConfig.TrashStorageWindow_bool.Value);
		}
		catch
		{
			Console.WriteLine("TrashStorageWindow错误");
		}
	}

	private void Init()
	{
		whichpannel = 1;
		RefreshBaseSize = true;
		normalstyle = new GUIStyle();
		styleblue = new GUIStyle();
		styleyellow = new GUIStyle();
		MainWindowWidth = AuxConfig.window_width.Value;
		MainWindowHeight = AuxConfig.window_height.Value;
		leftsprite = LoadImage("Auxilaryfunction.Resources.left.png");
		rightsprite = LoadImage("Auxilaryfunction.Resources.right.png");
		flatsprite = LoadImage("Auxilaryfunction.Resources.flat.png");
		trashcan = LoadImage("Auxilaryfunction.Resources.trashcan.png");
		trashcanOpen = LoadImage("Auxilaryfunction.Resources.trashcanOpen.png");
		OrangeColor = new Color(0.8784314f, 0.54509807f, 31f / 85f);
		BlueColor = new Color(0.29411766f, 0.6745098f, 41f / 51f);
		mytexture = new Texture2D(10, 10);
		for (int i = 0; i < mytexture.width; i++)
		{
			for (int j = 0; j < mytexture.height; j++)
			{
				mytexture.SetPixel(i, j, Color.black);
			}
		}
		mytexture.Apply();
		stationbluetexture = new Texture2D(10, 10);
		Color color = new Color(0.23921569f, 0.54509807f, 0.654902f);
		for (int k = 0; k < stationbluetexture.width; k++)
		{
			for (int l = 0; l < stationbluetexture.height; l++)
			{
				stationbluetexture.SetPixel(k, l, color);
			}
		}
		stationbluetexture.Apply();
		menus = new string[8] { "", "自动菜单", "渲染屏蔽", "便捷小功能", "文字科技树", "戴森球面板", "战斗", "蓝图设置" };
		styleblue.fontStyle = FontStyle.Bold;
		styleblue.fontSize = 20;
		styleblue.normal.textColor = new Color32(167, byte.MaxValue, byte.MaxValue, byte.MaxValue);
		styleyellow.fontStyle = FontStyle.Bold;
		styleyellow.fontSize = 20;
		styleyellow.normal.textColor = new Color32(240, 191, 103, byte.MaxValue);
		GameWindowCopyInit();
	}

	private void StationInfoWindowUpdate()
	{
		PlanetData localPlanet = GameMain.localPlanet;
		PlanetTransport planetTransport = localPlanet?.factory?.transport;
		if (!AuxConfig.ShowStationInfo.Value || planetTransport == null || planetTransport.stationCursor == 0 || (UIGame.viewMode != EViewMode.Normal && UIGame.viewMode != EViewMode.Globe))
		{
			if (Auxilaryfunction.stationTipRoot.activeSelf)
			{
				Auxilaryfunction.stationTipRoot.SetActive(value: false);
			}
			return;
		}
		Auxilaryfunction.stationTipRoot.SetActive(value: true);
		int num = 0;
		Vector3 localPosition = GameCamera.main.transform.localPosition;
		Vector3 forward = GameCamera.main.transform.forward;
		float realRadius = localPlanet.realRadius;
		StationComponent[] stationPool = planetTransport.stationPool;
		foreach (StationComponent stationComponent in stationPool)
		{
			if (stationComponent?.storage == null)
			{
				continue;
			}
			if (num == Auxilaryfunction.maxCount)
			{
				Auxilaryfunction.maxCount++;
				StationTip stationTip = UnityEngine.Object.Instantiate(Auxilaryfunction.tipPrefab, Auxilaryfunction.stationTipRoot.transform).AddComponent<StationTip>();
				stationTip.Init();
				Array.Resize(ref stationtips, Auxilaryfunction.maxCount);
				stationtips[Auxilaryfunction.maxCount - 1] = stationTip;
			}
			bool isStellarorCollector = stationComponent.isStellar || stationComponent.isCollector;
			Vector3 normalized = localPlanet.factory.entityPool[stationComponent.entityId].pos.normalized;
			int num2 = Math.Min(stationComponent.storage.Length, 5);
			float num3 = 40 * num2 + 20;
			if (stationComponent.isCollector)
			{
				num2 = 2;
				normalized *= realRadius + 35f;
				num3 -= 20f;
			}
			else if (stationComponent.isStellar)
			{
				normalized *= realRadius + 20f;
			}
			else if (stationComponent.isVeinCollector)
			{
				num3 -= 20f;
			}
			else
			{
				normalized *= realRadius + 15f;
			}
			StationTip stationTip2 = stationtips[num];
			Vector3 vector = normalized - localPosition;
			float magnitude = vector.magnitude;
			if ((double)magnitude < 1.0 || (double)Vector3.Dot(forward, vector) < 1.0 || !UIRoot.ScreenPointIntoRect(GameCamera.main.WorldToScreenPoint(normalized), Auxilaryfunction.stationTipRoot.GetComponent<RectTransform>(), out var rectPoint) || (double)Mathf.Abs(rectPoint.x) > 8000.0 || (double)Mathf.Abs(rectPoint.y) > 8000.0 || Phys.RayCastSphere(localPosition, vector / magnitude, magnitude, Vector3.zero, realRadius, out var _))
			{
				continue;
			}
			bool flag = false;
			for (int j = 0; j < stationComponent.storage.Length; j++)
			{
				if (stationComponent.storage[j].itemId != 0)
				{
					flag = true;
					break;
				}
			}
			if (!flag)
			{
				continue;
			}
			num++;
			stationTip2.gameObject.SetActive(value: true);
			rectPoint.x = Mathf.Round(rectPoint.x);
			rectPoint.y = Mathf.Round(rectPoint.y);
			stationTip2.RectTransform.anchoredPosition = rectPoint;
			for (int k = 0; k < num2; k++)
			{
				StationStore stationStore = stationComponent.storage[k];
				stationTip2.SetItem(stationStore.itemId, stationStore.count, k, stationStore.localLogic, stationStore.remoteLogic, AuxConfig.ShowStationInfoMode.Value, isStellarorCollector);
			}
			int num4 = num2;
			string text = localPlanet.factory.ReadExtraInfoOnEntity(stationComponent.entityId);
			stationTip2.SetStationName(text, num4);
			if (!string.IsNullOrEmpty(text))
			{
				num3 += 27f;
				num4++;
			}
			for (int l = 0; l < 3; l++)
			{
				if (stationComponent.isCollector || stationComponent.isVeinCollector || (l >= 1 && !stationComponent.isStellar))
				{
					stationTip2.SetDroneShipWarp(l, 0, 0, 0, num4);
					continue;
				}
				int currentCount = 0;
				int itemId;
				int totalCount;
				switch (l)
				{
				case 0:
					itemId = 5001;
					totalCount = stationComponent.idleDroneCount + stationComponent.workDroneCount;
					currentCount = stationComponent.idleDroneCount;
					break;
				case 1:
					itemId = 5002;
					totalCount = stationComponent.idleShipCount + stationComponent.workShipCount;
					currentCount = stationComponent.idleShipCount;
					break;
				default:
					itemId = 1210;
					totalCount = stationComponent.warperCount;
					break;
				}
				stationTip2.SetDroneShipWarp(l, itemId, totalCount, currentCount, num4);
			}
			float num5 = (((double)magnitude < 50.0) ? 1.5f : ((!((double)magnitude < 250.0)) ? 0.5f : ((float)(1.75 - (double)magnitude * 0.005))));
			stationTip2.transform.localScale = Vector3.one * num5;
			stationTip2.RectTransform.sizeDelta = new Vector2(125f, num3);
		}
		for (int m = num; m < Auxilaryfunction.maxCount; m++)
		{
			stationtips[m].gameObject.SetActive(value: false);
		}
	}

	private void BattlePanel()
	{
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		GUILayout.BeginHorizontal();
		AuxConfig.AutoNavigateToDarkFogHive.Value = GUILayout.Toggle(AuxConfig.AutoNavigateToDarkFogHive.Value, "黑雾巢穴自动导航".getTranslate());
		AuxConfig.AutoNavigateToDarkFogHiveKeepDistance.Value = (int)GUILayout.HorizontalSlider(AuxConfig.AutoNavigateToDarkFogHiveKeepDistance.Value, 10f, 240f);
		GUILayout.Label("跟随距离".getTranslate() + ":" + NumberTranslate.DistanceTranslate(AuxConfig.AutoNavigateToDarkFogHiveKeepDistance.Value * 100));
		GUILayout.EndHorizontal();
		if (GameMain.data?.spaceSector?.dfHives != null)
		{
			int num = 0;
			List<string> list = new List<string>();
			List<string> list2 = new List<string>();
			List<string> list3 = new List<string>();
			List<string> list4 = new List<string>();
			List<int> list5 = new List<int>();
			SpaceSector spaceSector = GameMain.data.spaceSector;
			EnemyDFHiveSystem[] dfHives = spaceSector.dfHives;
			foreach (EnemyDFHiveSystem enemyDFHiveSystem in dfHives)
			{
				if (enemyDFHiveSystem == null)
				{
					continue;
				}
				for (EnemyDFHiveSystem enemyDFHiveSystem2 = enemyDFHiveSystem; enemyDFHiveSystem2 != null; enemyDFHiveSystem2 = enemyDFHiveSystem2.nextSibling)
				{
					DFTinderComponent[] buffer = enemyDFHiveSystem2.tinders.buffer;
					for (int j = 0; j < buffer.Length; j++)
					{
						DFTinderComponent dFTinderComponent = buffer[j];
						if (dFTinderComponent.id <= 0 || dFTinderComponent.enemyId <= 0)
						{
							continue;
						}
						VectorLF3 pos = GameMain.data.spaceSector.enemyPool[dFTinderComponent.enemyId].pos;
						if (!(pos.magnitude < 1000.0))
						{
							StarData starData = spaceSector.GetHiveByAstroId(dFTinderComponent.targetHiveAstroId)?.starData;
							if (starData != null)
							{
								string item = spaceSector.GetHiveByAstroId(dFTinderComponent.targetHiveAstroId)?.starData?.displayName ?? "无".getTranslate();
								list2.Add(item);
								double magnitude = (pos - starData.uPosition).magnitude;
								list4.Add(NumberTranslate.DistanceTranslate(magnitude));
							}
							num++;
							list.Add(spaceSector.GetHiveByAstroId(dFTinderComponent.originHiveAstroId)?.starData?.displayName ?? "无".getTranslate());
							double magnitude2 = (Auxilaryfunction.player.uPosition - pos).magnitude;
							list3.Add(NumberTranslate.DistanceTranslate(magnitude2));
							list5.Add(dFTinderComponent.enemyId);
						}
					}
				}
			}
			GUILayout.Space(30f);
			GUILayout.Label("火种列表".getTranslate());
			if (num == 0)
			{
				GUILayout.Label("无火种".getTranslate());
			}
			else
			{
				GUILayout.BeginHorizontal();
				GUILayout.BeginVertical();
				GUILayout.Label("出发星系".getTranslate());
				for (int k = 0; k < num; k++)
				{
					GUILayout.Label(list[k]);
				}
				GUILayout.EndVertical();
				GUILayout.BeginVertical();
				GUILayout.Label("目标星系".getTranslate());
				for (int l = 0; l < num; l++)
				{
					GUILayout.Label(list2[l]);
				}
				GUILayout.EndVertical();
				GUILayout.BeginVertical();
				GUILayout.Label("与玩家距离".getTranslate());
				for (int m = 0; m < num; m++)
				{
					GUILayout.Label(list3[m]);
				}
				GUILayout.EndVertical();
				GUILayout.BeginVertical();
				GUILayout.Label("离目标星系距离".getTranslate());
				for (int n = 0; n < num; n++)
				{
					GUILayout.Label(list4[n]);
				}
				GUILayout.EndVertical();
				GUILayout.BeginVertical();
				GUILayout.Label("");
				for (int num2 = 0; num2 < num; num2++)
				{
					if (GUILayout.Button("导航".getTranslate()))
					{
						if (AuxConfig.autonavigation_bool.Value)
						{
							GameMain.mainPlayer.navigation.indicatorEnemyId = list5[num2];
						}
						else
						{
							UIMessageBox.Show("自动导航失败".getTranslate(), "未启用自动导航".getTranslate(), "确定".Translate(), 3);
						}
					}
				}
				GUILayout.EndVertical();
				GUILayout.EndHorizontal();
			}
		}
		if (GameMain.gameScenario?.cosmicMessageManager?.messageSimulators != null)
		{
			int num3 = 0;
			GUILayout.Space(30f);
			List<string> list6 = new List<string>();
			List<CosmicMessageData> list7 = new List<CosmicMessageData>();
			CosmicMessageSimulator[] messageSimulators = GameMain.gameScenario.cosmicMessageManager.messageSimulators;
			foreach (CosmicMessageSimulator cosmicMessageSimulator in messageSimulators)
			{
				if (cosmicMessageSimulator?.messageData != null)
				{
					num3++;
					double magnitude3 = (Auxilaryfunction.player.uPosition - cosmicMessageSimulator.messageData.uPosition).magnitude;
					list6.Add(NumberTranslate.DistanceTranslate(magnitude3));
					list7.Add(cosmicMessageSimulator.messageData);
				}
			}
			GUILayout.Label("通讯器列表".getTranslate());
			if (num3 == 0)
			{
				GUILayout.Label("无通讯器".getTranslate());
			}
			else
			{
				GUILayout.BeginHorizontal();
				GUILayout.BeginVertical();
				GUILayout.Label("与玩家距离".getTranslate());
				for (int num4 = 0; num4 < num3; num4++)
				{
					GUILayout.Label(list6[num4]);
				}
				GUILayout.EndVertical();
				GUILayout.BeginVertical();
				GUILayout.Label("");
				for (int num5 = 0; num5 < num3; num5++)
				{
					if (GUILayout.Button("导航".getTranslate()))
					{
						if (AuxConfig.autonavigation_bool.Value)
						{
							Auxilaryfunction.player.navigation.indicatorMsgId = list7[num5].protoId;
							PlayerOperationPatch.FlyStatus = true;
						}
						else
						{
							UIMessageBox.Show("自动导航失败".getTranslate(), "未启用自动导航".getTranslate(), "确定".Translate(), 3);
						}
					}
				}
				GUILayout.EndVertical();
				GUILayout.EndHorizontal();
			}
		}
		GUILayout.EndVertical();
		GUILayout.EndHorizontal();
	}

	private static int GetStationGroupButtonCount()
	{
		if (stationGroupButtonCountCache > 0)
		{
			return stationGroupButtonCountCache;
		}
		UIButton[] array = UIRoot.instance?.uiGame?.stationWindow?.groupBtns;
		if (array != null && array.Length != 0)
		{
			stationGroupButtonCountCache = array.Length;
		}
		if (stationGroupButtonCountCache <= 0)
		{
			return 30;
		}
		return stationGroupButtonCountCache;
	}

	private void BluePrintConfigSetPanel()
	{
		GUILayout.BeginHorizontal();
		AuxConfig.ChangeBluePrintQuickKey = GUILayout.Toggle(AuxConfig.ChangeBluePrintQuickKey, (!AuxConfig.ChangeBluePrintQuickKey) ? "改变蓝图设置快捷键".getTranslate() : "点击确认".getTranslate(), buttonoptions);
		GUILayout.Label(AuxConfig.tempBluePrintShowWindow.ToString(), labelstyle);
		GUILayout.EndHorizontal();
		if (AuxConfig.LocalPlanet == null || BluePrintBatchModifyBuild.blue_copy?.blueprint?.buildings == null)
		{
			BluePrintBatchModifyBuild.Reset();
			GUILayout.Label("进入蓝图模式可使用".getTranslate());
			return;
		}
		BluePrintBatchModifyBuild.CheckBluePrint();
		GUILayout.BeginVertical();
		GUILayout.BeginHorizontal();
		if (GUILayout.Button("全选当前星球建筑".getTranslate(), buttonoptions))
		{
			BluePrintBatchModifyBuild.blue_copy.ArrangeSelection();
			EntityData[] entityPool = AuxConfig.LocalPlanet.factory.entityPool;
			for (int i = 0; i < entityPool.Length; i++)
			{
				EntityData entityData = entityPool[i];
				if (entityData.id != 0)
				{
					BluePrintBatchModifyBuild.blue_copy.preSelectObjIds.Add(entityData.id);
					BluePrintBatchModifyBuild.blue_copy.selectedObjIds.Add(entityData.id);
				}
			}
			BluePrintBatchModifyBuild.blue_copy.ClearPreSelection();
			BluePrintBatchModifyBuild.blue_copy.RefreshBlueprintData();
			BluePrintBatchModifyBuild.blue_copy.DeterminePreviews();
		}
		if (GUILayout.Button("删除选中建筑".getTranslate(), buttonoptions))
		{
			UIMessageBox.Show("辅助面板提示".getTranslate(), "删除选中建筑".getTranslate(), "取消".Translate(), "确定".Translate(), 1, null, delegate
			{
				PlayerAction_Build actionBuild = Auxilaryfunction.player.controller.actionBuild;
				BuildPreview[] bpPool = BluePrintBatchModifyBuild.blue_copy.bpPool;
				foreach (BuildPreview buildPreview in bpPool)
				{
					if (buildPreview != null && buildPreview.item != null && buildPreview.objId != 0)
					{
						if (buildPreview.objId > 0)
						{
							int stationId = AuxConfig.LocalPlanet.factory.entityPool[buildPreview.objId].stationId;
							if (stationId > 0)
							{
								StationComponent stationComponent = AuxConfig.LocalPlanet.factory.transport.stationPool[stationId];
								for (int k = 0; k < stationComponent.storage.Length; k++)
								{
									int upCount = Auxilaryfunction.player.TryAddItemToPackage(stationComponent.storage[k].itemId, stationComponent.storage[k].count, 0, throwTrash: true, buildPreview.objId);
									UIItemup.Up(stationComponent.storage[k].itemId, upCount);
								}
								stationComponent.storage = new StationStore[stationComponent.storage.Length];
								stationComponent.needs = new int[stationComponent.needs.Length];
							}
						}
						actionBuild.DoDismantleObject(buildPreview.objId);
					}
				}
				BluePrintBatchModifyBuild.blue_copy.ClearSelection();
				BluePrintBatchModifyBuild.blue_copy.ClearPreSelection();
				BluePrintBatchModifyBuild.blue_copy.ResetBlueprint();
				BluePrintBatchModifyBuild.blue_copy.ResetBuildPreviews();
				BluePrintBatchModifyBuild.blue_copy.RefreshBlueprintData();
			});
			VFAudio.Create("ui-error", null, Vector3.zero, play: true, 1, -1, -1L);
		}
		GUILayout.EndHorizontal();
		List<int> list = BluePrintBatchModifyBuild.buildIconsDictionary.Keys.ToList();
		GUILayout.BeginHorizontal();
		GUILayout.Label("可修改建筑".getTranslate(), labelstyle);
		for (int num = 0; num < list.Count(); num++)
		{
			ItemProto itemProto = LDB.items.Select(list[num]);
			GUIStyle style = imageButtonNormalStyle;
			if (BluePrintBatchModifyBuild.CurrentSelectedBuilds.Contains(itemProto.ID))
			{
				style = imageButtonSelectedStyle;
			}
			if (GUILayout.Button(itemProto.iconSprite.texture, style, iconbuttonoptions))
			{
				BluePrintBatchModifyBuild.SelectItemId(itemProto.ID);
			}
		}
		BluePrintBatchModifyBuild.CurrentSelectedBuildName = string.Empty;
		for (int num2 = BluePrintBatchModifyBuild.CurrentSelectedBuilds.Count - 1; num2 >= 0; num2--)
		{
			int num3 = BluePrintBatchModifyBuild.CurrentSelectedBuilds[num2];
			if (!BluePrintBatchModifyBuild.buildIconsDictionary.ContainsKey(num3))
			{
				BluePrintBatchModifyBuild.UnSelectItemId(num3);
			}
			else
			{
				BluePrintBatchModifyBuild.CurrentSelectedBuildName = BluePrintBatchModifyBuild.CurrentSelectedBuildName + "【" + LDB.items.Select(num3).Name.Translate() + "x" + BluePrintBatchModifyBuild.buildIconsDictionary[num3] + "】\t";
			}
		}
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.Label(BluePrintBatchModifyBuild.CurrentSelectedBuildName);
		switch (BluePrintBatchModifyBuild.CurrentSelectedBuildType)
		{
		case BuildType.Lab:
			LabModify();
			break;
		case BuildType.Assemble:
			AssemblyGeneral(ERecipeType.Assemble);
			break;
		case BuildType.Smelt:
			AssemblyGeneral(ERecipeType.Smelt);
			break;
		case BuildType.Refine:
			AssemblyGeneral(ERecipeType.Refine);
			break;
		case BuildType.Chemical:
			AssemblyGeneral(ERecipeType.Chemical);
			break;
		case BuildType.Particle:
			AssemblyGeneral(ERecipeType.Particle);
			break;
		case BuildType.Turret:
			TurretModify();
			break;
		case BuildType.NormalStation:
			NormalStationModify();
			break;
		case BuildType.StellarStation:
			StellarStationModify();
			break;
		case BuildType.PowergenGamma:
			PowergenGammaModify();
			break;
		case BuildType.PowerExchanger:
			PowerExchangerModify();
			break;
		case BuildType.Belt:
			BeltModify();
			break;
		case BuildType.Ejector:
			EjectorModify();
			break;
		}
		GUILayout.EndVertical();
	}

	private void DefaultPanel()
	{
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		GUILayout.BeginHorizontal();
		AuxConfig.auto_supply_station.Value = GUILayout.Toggle(AuxConfig.auto_supply_station.Value, "自动配置新运输站".getTranslate(), buttonoptions);
		AuxConfig.autosetstationconfig.Value = GUILayout.Toggle(AuxConfig.autosetstationconfig.Value, "配置参数".getTranslate(), buttonoptions);
		GUILayout.EndHorizontal();
		if (AuxConfig.autosetstationconfig.Value)
		{
			KeyValuePair<string, BuildConfig>[] array = BuildTargetValues.buildConfigsDic.ToArray();
			for (int i = 0; i < array.Length; i++)
			{
				KeyValuePair<string, BuildConfig> keyValuePair = array[i];
				string key = keyValuePair.Key;
				BuildConfig value = keyValuePair.Value;
				GUILayout.BeginHorizontal();
				string text = "";
				bool enabled = GUI.enabled;
				GUI.enabled = value.IsEnabled;
				switch (key)
				{
				default:
					GUI.enabled = enabled;
					GUILayout.EndHorizontal();
					continue;
				case "填充飞机数量":
					BuildTargetValues.StationDroneNumber = (int)GUILayout.HorizontalSlider(BuildTargetValues.StationDroneNumber, value.LowLimit, value.UpperLimit, HorizontalSlideroptions);
					text = BuildTargetValues.StationDroneNumber + " ";
					break;
				case "填充飞船数量":
					BuildTargetValues.StationShipNumber = (int)GUILayout.HorizontalSlider(BuildTargetValues.StationShipNumber, value.LowLimit, value.UpperLimit, HorizontalSlideroptions);
					text = BuildTargetValues.StationShipNumber + " ";
					break;
				case "最大充电功率":
					BuildTargetValues.StationMaxPowerPertick = (int)GUILayout.HorizontalSlider(BuildTargetValues.StationMaxPowerPertick, value.LowLimit, value.UpperLimit, HorizontalSlideroptions);
					text = (int)AuxConfig.stationmaxpowerpertick.Value + "MW ";
					break;
				case "运输机最远路程":
					BuildTargetValues.StationDroneMaxDistance = (int)GUILayout.HorizontalSlider(BuildTargetValues.StationDroneMaxDistance, value.LowLimit, value.UpperLimit, HorizontalSlideroptions);
					text = BuildTargetValues.StationDroneMaxDistance + "° ";
					break;
				case "运输船最远路程":
					BuildTargetValues.StationShipMaxDistance = (int)GUILayout.HorizontalSlider(BuildTargetValues.StationShipMaxDistance, value.LowLimit, value.UpperLimit, HorizontalSlideroptions);
					text = ((BuildTargetValues.StationShipMaxDistance == 61) ? "∞ " : (BuildTargetValues.StationShipMaxDistance + "ly "));
					break;
				case "曲速启用路程":
					BuildTargetValues.StationWarpEnableDistance = (int)GUILayout.HorizontalSlider((float)BuildTargetValues.StationWarpEnableDistance, value.LowLimit, value.UpperLimit, HorizontalSlideroptions);
					if (BuildTargetValues.StationWarpEnableDistance == 0.0)
					{
						BuildTargetValues.StationWarpEnableDistance = 0.5;
					}
					text = BuildTargetValues.StationWarpEnableDistance + "AU ";
					break;
				case "运输机起送量":
					BuildTargetValues.StationDroneStartCarry = GUILayout.HorizontalSlider(BuildTargetValues.StationDroneStartCarry, value.LowLimit, value.UpperLimit, HorizontalSlideroptions);
					BuildTargetValues.StationDroneStartCarry = ((BuildTargetValues.StationDroneStartCarry == 0f) ? 0.01f : BuildTargetValues.StationDroneStartCarry);
					text = (((int)(BuildTargetValues.StationDroneStartCarry * 10f) * 10 == 0) ? "1" : (((int)(BuildTargetValues.StationDroneStartCarry * 10f) * 10).ToString() ?? "")) + "% ";
					break;
				case "运输船起送量":
					BuildTargetValues.StationShipStartCarry = GUILayout.HorizontalSlider(BuildTargetValues.StationShipStartCarry, value.LowLimit, value.UpperLimit, HorizontalSlideroptions);
					text = (((int)(BuildTargetValues.StationShipStartCarry * 10f) * 10 == 0) ? "1" : (((int)(BuildTargetValues.StationShipStartCarry * 10f) * 10).ToString() ?? "")) + "% ";
					break;
				case "翘曲填充数量":
					BuildTargetValues.StationStartWarpNumber = (int)GUILayout.HorizontalSlider(BuildTargetValues.StationStartWarpNumber, value.LowLimit, value.UpperLimit, HorizontalSlideroptions);
					text = BuildTargetValues.StationStartWarpNumber + " ";
					break;
				case "大型采矿机采矿速率":
					BuildTargetValues.VeinCollectorSpeed = (int)GUILayout.HorizontalSlider(BuildTargetValues.VeinCollectorSpeed, value.LowLimit, value.UpperLimit, HorizontalSlideroptions);
					text = (float)BuildTargetValues.VeinCollectorSpeed / 10f + " ";
					break;
				}
				GUI.enabled = enabled;
				value.IsEnabled = GUILayout.Toggle(value.IsEnabled, "启用".getTranslate(), buttonoptions);
				BuildTargetValues.buildConfigsDic[key] = value;
				text += key.getTranslate();
				GUILayout.Label(text, labelstyle, buttonoptions);
				GUILayout.EndHorizontal();
			}
		}
		if (GUILayout.Button("填充当前星球飞机飞船、翘曲器".getTranslate(), buttonoptions))
		{
			LogisticsService.AddDroneShipToStation();
		}
		if (GUILayout.Button("批量配置当前星球物流站".getTranslate(), buttonoptions))
		{
			LogisticsService.ChangeAllStationConfig();
		}
		if (GUILayout.Button("批量配置当前星球大型采矿机采矿速率".getTranslate(), buttonoptions))
		{
			LogisticsService.ChangeAllVeinCollectorSpeedConfig();
		}
		GUILayout.BeginHorizontal();
		GUILayout.Button(LDB.items.Select(2105).iconSprite.texture, normalstyle, iconbuttonoptions);
		if (GUILayout.Button("铺满轨道采集器".getTranslate(), buttonoptions))
		{
			LogisticsService.SetGasStation();
		}
		GUILayout.EndHorizontal();
		GUILayout.EndVertical();
		GUILayout.Space(20f);
		GUILayout.BeginVertical();
		if (AuxConfig.autoaddtech_bool.Value != GUILayout.Toggle(AuxConfig.autoaddtech_bool.Value, "自动添加科技队列".getTranslate()))
		{
			AuxConfig.autoaddtech_bool.Value = !AuxConfig.autoaddtech_bool.Value;
			if (!AuxConfig.autoaddtech_bool.Value)
			{
				AuxConfig.auto_add_techid.Value = 0;
			}
		}
		if (AuxConfig.autoaddtech_bool.Value)
		{
			if (GameMain.sandboxToolsEnabled)
			{
				AutoUnlockTechInSandBox = GUILayout.Toggle(AutoUnlockTechInSandBox, "沙盒模式秒解锁科技");
			}
			GUILayout.BeginHorizontal();
			GUILayout.Label("科技等级上限".getTranslate() + ":");
			string input = GUILayout.TextField(AuxConfig.auto_add_techmaxLevel.Value.ToString(), GUILayout.Height(heightdis), GUILayout.Width(heightdis * 3));
			GUILayout.EndHorizontal();
			int result;
			bool flag = !int.TryParse(Regex.Replace(input, "^[^0-9]", ""), out result);
			if (result != 0)
			{
				AuxConfig.auto_add_techmaxLevel.Value = Math.Min(result, 10000);
			}
			TechProto techProto = LDB.techs.Select(AuxConfig.auto_add_techid.Value);
			string text2 = "未选择".getTranslate();
			if (techProto != null)
			{
				TechState techState = GameMain.history.techStates[techProto.ID];
				if (techState.curLevel != techState.maxLevel)
				{
					text2 = techProto.name + "level" + techState.curLevel;
				}
				if (flag)
				{
					AuxConfig.auto_add_techmaxLevel.Value = techState.maxLevel;
				}
			}
			if (GUILayout.Button(text2, buttonoptions))
			{
				selectautoaddtechid = !selectautoaddtechid;
			}
			if (LDB.techs.dataArray != null && selectautoaddtechid)
			{
				for (int j = 0; j < LDB.techs.dataArray.Length; j++)
				{
					TechState techState2 = GameMain.history.techStates[LDB.techs.dataArray[j].ID];
					if (techState2.curLevel < techState2.maxLevel && techState2.maxLevel > 10 && GUILayout.Button(LDB.techs.dataArray[j].name + " " + techState2.curLevel + " " + techState2.maxLevel, buttonoptions))
					{
						AuxConfig.auto_add_techid.Value = LDB.techs.dataArray[j].ID;
					}
				}
			}
		}
		GUILayout.BeginHorizontal();
		GUILayout.Button(LDB.items.Select(2210).iconSprite.texture, normalstyle, iconbuttonoptions);
		GUILayout.BeginVertical();
		AuxConfig.autosetSomevalue_bool.Value = GUILayout.Toggle(AuxConfig.autosetSomevalue_bool.Value, "自动填充人造恒星".getTranslate());
		GUILayout.BeginHorizontal();
		for (int k = 0; k < 2; k++)
		{
			int num = 1803 + k;
			GUIStyle style = normalstyle;
			if (AuxConfig.auto_supply_starfuelID.Value == num)
			{
				style = imageButtonSelectedStyle;
			}
			if (GUILayout.Button(LDB.items.Select(num).iconSprite.texture, style, iconbuttonoptions))
			{
				AuxConfig.auto_supply_starfuelID.Value = num;
			}
		}
		GUILayout.EndHorizontal();
		GUILayout.Label("人造恒星燃料数量".getTranslate() + "：" + AuxConfig.auto_supply_starfuel.Value);
		AuxConfig.auto_supply_starfuel.Value = (int)GUILayout.HorizontalSlider(AuxConfig.auto_supply_starfuel.Value, 1f, 100f, HorizontalSlideroptions);
		if (GUILayout.Button("填充当前星球人造恒星".getTranslate(), buttonoptions))
		{
			LogisticsService.AddFuelToAllStar();
		}
		GUILayout.EndVertical();
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal();
		GUILayout.Button(LDB.items.Select(2107).iconSprite.texture, normalstyle, iconbuttonoptions);
		GUILayout.BeginVertical();
		AuxConfig.autosetCourier_bool.Value = GUILayout.Toggle(AuxConfig.autosetCourier_bool.Value, "自动填充配送运输机".getTranslate());
		BuildConfig value2 = BuildTargetValues.buildConfigsDic["填充配送机数量"];
		value2.IsEnabled = GUILayout.Toggle(value2.IsEnabled, "启用".getTranslate());
		BuildTargetValues.buildConfigsDic["填充配送机数量"] = value2;
		GUILayout.Label("填充配送运输机数量".getTranslate() + "：" + BuildTargetValues.AutoSupplyCourierNumber);
		BuildTargetValues.AutoSupplyCourierNumber = (int)GUILayout.HorizontalSlider(BuildTargetValues.AutoSupplyCourierNumber, value2.LowLimit, value2.UpperLimit, HorizontalSlideroptions);
		if (GUILayout.Button("填充当前星球配送机".getTranslate(), buttonoptions))
		{
			LogisticsService.AddCourierToAllStar();
		}
		GUILayout.EndVertical();
		GUILayout.EndHorizontal();
		if (AuxConfig.autoabsorttrash_bool.Value != GUILayout.Toggle(AuxConfig.autoabsorttrash_bool.Value, "30s间隔自动吸收垃圾".getTranslate()))
		{
			AuxConfig.autoabsorttrash_bool.Value = !AuxConfig.autoabsorttrash_bool.Value;
			if (AuxConfig.autoabsorttrash_bool.Value)
			{
				AuxConfig.autocleartrash_bool.Value = false;
			}
		}
		if (AuxConfig.autoabsorttrash_bool.Value)
		{
			AuxConfig.onlygetbuildings.Value = GUILayout.Toggle(AuxConfig.onlygetbuildings.Value, "只回收建筑".getTranslate());
		}
		if (AuxConfig.autocleartrash_bool.Value != GUILayout.Toggle(AuxConfig.autocleartrash_bool.Value, "30s间隔自动清除垃圾".getTranslate()))
		{
			AuxConfig.autocleartrash_bool.Value = !AuxConfig.autocleartrash_bool.Value;
			if (AuxConfig.autocleartrash_bool.Value)
			{
				AuxConfig.autoabsorttrash_bool.Value = false;
				AuxConfig.onlygetbuildings.Value = false;
			}
		}
		GUILayout.EndVertical();
		GUILayout.Space(30f);
		GUILayout.BeginVertical();
		GUILayout.Label("机甲自动化".getTranslate());
		AuxConfig.automovetounbuilt.Value = GUILayout.Toggle(AuxConfig.automovetounbuilt.Value, "自动飞向未完成建筑".getTranslate() + $":{AuxConfig.automovetoPrebuildSecondElapse.Value}s");
		if (AuxConfig.automovetounbuilt.Value)
		{
			AuxConfig.automovetoPrebuildSecondElapse.Value = (int)GUILayout.HorizontalSlider(AuxConfig.automovetoPrebuildSecondElapse.Value, 1f, 10f, HorizontalSlideroptions);
		}
		AuxConfig.automovetodarkfog.Value = GUILayout.Toggle(AuxConfig.automovetodarkfog.Value, "自动飞向地面黑雾基地".getTranslate());
		AuxConfig.autonavigation_bool.Value = GUILayout.Toggle(AuxConfig.autonavigation_bool.Value, "自动导航".getTranslate());
		if (AuxConfig.autonavigation_bool.Value)
		{
			GUILayout.BeginHorizontal();
			GUILayout.Space(20f);
			GUILayout.BeginVertical();
			AuxConfig.autoAddPlayerVel.Value = GUILayout.Toggle(AuxConfig.autoAddPlayerVel.Value, "自动加速".getTranslate());
			AuxConfig.autowarpcommand.Value = GUILayout.Toggle(AuxConfig.autowarpcommand.Value, "自动导航使用曲速".getTranslate());
			GUILayout.Label("自动曲速最低距离".getTranslate() + ":" + $"{AuxConfig.autowarpdistance.Value:N2}" + "光年".getTranslate());
			AuxConfig.autowarpdistance.Value = GUILayout.HorizontalSlider(AuxConfig.autowarpdistance.Value, 0f, 15f, HorizontalSlideroptions);
			GUILayout.Label("自动曲速最低能量".getTranslate() + ":" + $"{AuxConfig.autowarpdistanceEnergyPercent.Value:N2}" + "%");
			AuxConfig.autowarpdistanceEnergyPercent.Value = GUILayout.HorizontalSlider(AuxConfig.autowarpdistanceEnergyPercent.Value, 0f, 95f, HorizontalSlideroptions);
			AuxConfig.autowarpdistanceEnergyPercent.Value = (int)(AuxConfig.autowarpdistanceEnergyPercent.Value / 5f * 5f);
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
		}
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private void DisablePaintingPanel()
	{
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		GUILayout.Label("模型屏蔽".getTranslate());
		AuxConfig.norender_dysonshell_bool.Value = GUILayout.Toggle(AuxConfig.norender_dysonshell_bool.Value, "不渲染戴森壳".getTranslate());
		AuxConfig.norender_dysonswarm_bool.Value = GUILayout.Toggle(AuxConfig.norender_dysonswarm_bool.Value, "不渲染戴森云".getTranslate());
		AuxConfig.norender_lab_bool.Value = GUILayout.Toggle(AuxConfig.norender_lab_bool.Value, "不渲染研究站".getTranslate());
		AuxConfig.norender_beltitem.Value = GUILayout.Toggle(AuxConfig.norender_beltitem.Value, "不渲染传送带货物".getTranslate());
		AuxConfig.norender_DarkFog.Value = GUILayout.Toggle(AuxConfig.norender_DarkFog.Value, "不渲染黑雾".getTranslate());
		AuxConfig.norender_shipdrone_bool.Value = GUILayout.Toggle(AuxConfig.norender_shipdrone_bool.Value, "不渲染运输船和飞机".getTranslate());
		AuxConfig.norender_entity_bool.Value = GUILayout.Toggle(AuxConfig.norender_entity_bool.Value, "不渲染实体".getTranslate());
		if (AuxConfig.simulatorrender != GUILayout.Toggle(AuxConfig.simulatorrender, "不渲染全部".getTranslate()))
		{
			AuxConfig.simulatorrender = !AuxConfig.simulatorrender;
			AuxConfig.simulatorchanging = true;
		}
		GUILayout.EndVertical();
		GUILayout.Space(30f);
		GUILayout.BeginVertical();
		GUILayout.Label("UI屏蔽".getTranslate());
		AuxConfig.norender_powerdisk_bool.Value = GUILayout.Toggle(AuxConfig.norender_powerdisk_bool.Value, "不渲染电网覆盖".getTranslate());
		AuxConfig.CloseUIRandomTip.Value = GUILayout.Toggle(AuxConfig.CloseUIRandomTip.Value, "关闭建筑栏提示".getTranslate());
		AuxConfig.CloseUITutorialTip.Value = GUILayout.Toggle(AuxConfig.CloseUITutorialTip.Value, "关闭教学提示".getTranslate());
		AuxConfig.CloseUIAdvisor.Value = GUILayout.Toggle(AuxConfig.CloseUIAdvisor.Value, "关闭顾问".getTranslate());
		AuxConfig.CloseMilestone.Value = GUILayout.Toggle(AuxConfig.CloseMilestone.Value, "关闭里程碑提示".getTranslate());
		AuxConfig.CloseUIGeneralTip.Value = GUILayout.Toggle(AuxConfig.CloseUIGeneralTip.Value, "关闭科技解锁提示".getTranslate());
		if (Auxilaryfunction.HideDarkFogMonitor != GUILayout.Toggle(Auxilaryfunction.HideDarkFogMonitor, "隐藏黑雾威胁度检测".getTranslate()))
		{
			Auxilaryfunction.HideDarkFogMonitor = !Auxilaryfunction.HideDarkFogMonitor;
			UIRoot.instance.uiGame.dfMonitor.gameObject.SetActive(!Auxilaryfunction.HideDarkFogMonitor);
		}
		if (Auxilaryfunction.HideDarkFogAssaultTip != GUILayout.Toggle(Auxilaryfunction.HideDarkFogAssaultTip, "隐藏黑雾入侵提示".getTranslate()))
		{
			Auxilaryfunction.HideDarkFogAssaultTip = !Auxilaryfunction.HideDarkFogAssaultTip;
			UIRoot.instance.uiGame.dfAssaultTip.gameObject.SetActive(!Auxilaryfunction.HideDarkFogAssaultTip);
		}
		GUILayout.EndVertical();
		GUILayout.Space(30f);
		GUILayout.BeginVertical();
		GUILayout.Label("声音屏蔽".getTranslate());
		AuxConfig.closeplayerflyaudio.Value = GUILayout.Toggle(AuxConfig.closeplayerflyaudio.Value, "关闭玩家走路飞行声音".getTranslate());
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private void DysonBluePrintDataDraw(List<TempDysonBlueprintData> datalist)
	{
		GUILayout.BeginHorizontal();
		GUILayout.Space(heightdis);
		GUILayout.BeginVertical();
		for (int i = 0; i < datalist.Count; i++)
		{
			if (GUILayout.Toggle(datalist[i].path == DysonBluePrintDataService.selectDysonBlueprintData.path, datalist[i].name, GUILayout.Height(heightdis)) != (datalist[i].path == DysonBluePrintDataService.selectDysonBlueprintData.path))
			{
				DysonBluePrintDataService.selectDysonBlueprintData = datalist[i];
			}
		}
		GUILayout.EndVertical();
		GUILayout.EndHorizontal();
	}

	private void DysonPanel()
	{
		bool[] array = new bool[11];
		DysonSphere dysonSphere = UIRoot.instance?.uiGame?.dysonEditor?.selection?.viewDysonSphere;
		if (dysonSphere != null)
		{
			for (int i = 1; i <= 10; i++)
			{
				if (dysonSphere.layersIdBased[i] != null && dysonSphere.layersIdBased[i].id != 0 && dysonSphere.layersIdBased[i].nodeCount == 0)
				{
					array[dysonSphere.layersIdBased[i].id] = true;
				}
			}
		}
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		GUILayout.Label("选择一个蓝图后，点击右侧的层级可以自动导入".getTranslate());
		if (GUILayout.Button("打开戴森球蓝图文件夹".getTranslate(), GUILayout.Height(heightdis)))
		{
			string text = new StringBuilder(GameConfig.overrideDocumentFolder).Append(GameConfig.gameName).Append("/DysonBluePrint/").ToString();
			if (!Directory.Exists(text))
			{
				Directory.CreateDirectory(text);
			}
			Application.OpenURL(text);
		}
		if (GUILayout.Button("刷新文件".getTranslate(), GUILayout.Height(heightdis)))
		{
			DysonBluePrintDataService.selectDysonBlueprintData.path = "";
			DysonBluePrintDataService.LoadDysonBluePrintData();
		}
		dysonBluePrintscrollPosition = GUILayout.BeginScrollView(dysonBluePrintscrollPosition);
		GUILayout.BeginVertical();
		if (DysonBluePrintDataService.tempDysonBlueprintData.Exists((TempDysonBlueprintData o) => o.type == EDysonBlueprintType.SingleLayer))
		{
			AuxConfig.DysonPanelSingleLayer.Value = GUILayout.Toggle(AuxConfig.DysonPanelSingleLayer.Value, "单层壳".getTranslate());
			if (AuxConfig.DysonPanelSingleLayer.Value)
			{
				List<TempDysonBlueprintData> datalist = DysonBluePrintDataService.tempDysonBlueprintData.Where((TempDysonBlueprintData x) => x.type == EDysonBlueprintType.SingleLayer).ToList();
				DysonBluePrintDataDraw(datalist);
			}
		}
		if (DysonBluePrintDataService.tempDysonBlueprintData.Exists((TempDysonBlueprintData o) => o.type == EDysonBlueprintType.Layers))
		{
			AuxConfig.DysonPanelLayers.Value = GUILayout.Toggle(AuxConfig.DysonPanelLayers.Value, "多层壳".getTranslate());
			if (AuxConfig.DysonPanelLayers.Value)
			{
				List<TempDysonBlueprintData> datalist2 = DysonBluePrintDataService.tempDysonBlueprintData.Where((TempDysonBlueprintData x) => x.type == EDysonBlueprintType.Layers).ToList();
				DysonBluePrintDataDraw(datalist2);
			}
		}
		if (DysonBluePrintDataService.tempDysonBlueprintData.Exists((TempDysonBlueprintData o) => o.type == EDysonBlueprintType.SwarmOrbits))
		{
			AuxConfig.DysonPanelSwarm.Value = GUILayout.Toggle(AuxConfig.DysonPanelSwarm.Value, "戴森云".getTranslate());
			if (AuxConfig.DysonPanelSwarm.Value)
			{
				List<TempDysonBlueprintData> datalist3 = DysonBluePrintDataService.tempDysonBlueprintData.Where((TempDysonBlueprintData x) => x.type == EDysonBlueprintType.SwarmOrbits).ToList();
				DysonBluePrintDataDraw(datalist3);
			}
		}
		if (DysonBluePrintDataService.tempDysonBlueprintData.Exists((TempDysonBlueprintData o) => o.type == EDysonBlueprintType.DysonSphere))
		{
			AuxConfig.DysonPanelDysonSphere.Value = GUILayout.Toggle(AuxConfig.DysonPanelDysonSphere.Value, "戴森球(包括壳、云)".getTranslate());
			if (AuxConfig.DysonPanelDysonSphere.Value)
			{
				List<TempDysonBlueprintData> datalist4 = DysonBluePrintDataService.tempDysonBlueprintData.Where((TempDysonBlueprintData x) => x.type == EDysonBlueprintType.DysonSphere).ToList();
				DysonBluePrintDataDraw(datalist4);
			}
		}
		GUILayout.EndVertical();
		GUILayout.EndScrollView();
		GUILayout.EndVertical();
		GUILayout.Space(20f);
		GUILayout.BeginVertical();
		if (GUILayout.Button("复制选中文件代码".getTranslate(), GUILayout.Height(heightdis)))
		{
			GUIUtility.systemCopyBuffer = DysonBluePrintDataService.ReaddataFromFile(DysonBluePrintDataService.selectDysonBlueprintData.path);
			ThreadPool.QueueUserWorkItem(delegate
			{
				Thread.Sleep(10000);
				GUIUtility.systemCopyBuffer = "";
			});
		}
		if (GUILayout.Button("清除剪贴板".getTranslate(), GUILayout.Height(heightdis)))
		{
			GUIUtility.systemCopyBuffer = "";
		}
		if (GUILayout.Button("应用蓝图".getTranslate(), GUILayout.Height(heightdis)) && dysonSphere != null)
		{
			DysonBluePrintDataService.ApplyDysonBlueprintManage(DysonBluePrintDataService.ReaddataFromFile(DysonBluePrintDataService.selectDysonBlueprintData.path), dysonSphere, DysonBluePrintDataService.selectDysonBlueprintData.type);
		}
		if (GUILayout.Button("自动生成最大半径戴森壳".getTranslate(), GUILayout.Height(heightdis)) && dysonSphere != null)
		{
			for (int num = 1; num <= 10; num++)
			{
				for (float orbitRadius = dysonSphere.maxOrbitRadius; orbitRadius > dysonSphere.minOrbitRadius; orbitRadius -= 1f)
				{
					if (dysonSphere.QueryLayerRadius(ref orbitRadius, out var orbitAngularSpeed))
					{
						dysonSphere.AddLayer(orbitRadius, Quaternion.identity, orbitAngularSpeed);
						break;
					}
				}
				if (dysonSphere.layerCount == 10)
				{
					break;
				}
			}
		}
		if (GUILayout.Button("删除全部空壳".getTranslate(), GUILayout.Height(heightdis)) && dysonSphere != null)
		{
			for (int num2 = 1; num2 <= 10; num2++)
			{
				if (dysonSphere.layersIdBased[num2] != null && dysonSphere.layersIdBased[num2].nodeCount == 0)
				{
					dysonSphere.RemoveLayer(dysonSphere.layersIdBased[num2]);
				}
			}
		}
		GUILayout.Label("当前选中".getTranslate() + ":" + UIRoot.instance?.uiGame?.dysonEditor?.selection?.viewDysonSphere?.starData.name);
		GUILayout.Label("可用戴森壳层级:".getTranslate());
		for (int num3 = 0; num3 < 2; num3++)
		{
			GUILayout.BeginHorizontal();
			for (int num4 = 0; num4 < 5; num4++)
			{
				int num5 = num3 * 5 + num4 + 1;
				if (GUILayout.Button(array[num5] ? num5.ToString() : "", nomarginButtonStyle, iconbuttonoptions) && array[num5])
				{
					DysonBluePrintDataService.ApplyDysonBlueprintManage(DysonBluePrintDataService.ReaddataFromFile(DysonBluePrintDataService.selectDysonBlueprintData.path), dysonSphere, EDysonBlueprintType.SingleLayer, num5);
				}
			}
			GUILayout.EndHorizontal();
		}
		GUILayout.BeginHorizontal();
		GUILayout.Label("不可用戴森壳层级:".getTranslate());
		DeleteDysonLayer = GUILayout.Toggle(DeleteDysonLayer, "勾选即可点击删除".getTranslate());
		GUILayout.EndHorizontal();
		for (int num6 = 0; num6 < 2; num6++)
		{
			GUILayout.BeginHorizontal();
			for (int num7 = 0; num7 < 5; num7++)
			{
				int num8 = num6 * 5 + num7 + 1;
				if (GUILayout.Button((!array[num8]) ? num8.ToString() : "", nomarginButtonStyle, iconbuttonoptions) && DeleteDysonLayer)
				{
					DysonBluePrintDataService.RemoveLayerById(num8);
				}
			}
			GUILayout.EndHorizontal();
		}
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private void EasyUsePanel()
	{
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		GUILayout.Label("蓝图功能优化".getTranslate());
		AuxConfig.BluePrintSelectAll.Value = GUILayout.Toggle(AuxConfig.BluePrintSelectAll.Value, "蓝图全选".getTranslate() + "(ctrl+A）");
		AuxConfig.BluePrintDelete.Value = GUILayout.Toggle(AuxConfig.BluePrintDelete.Value, "蓝图删除".getTranslate() + "(ctrl+X）");
		AuxConfig.SaveLastOpenBluePrintBrowserPathConfig.Value = GUILayout.Toggle(AuxConfig.SaveLastOpenBluePrintBrowserPathConfig.Value, "记录上次蓝图路径".getTranslate(), buttonoptions);
		GUILayout.EndVertical();
		GUILayout.Space(30f);
		GUILayout.BeginVertical();
		GUILayout.Label("物流站功能优化".getTranslate());
		bool flag = GUILayout.Toggle(AuxConfig.ShowStationInfo.Value, "物流站信息显示".getTranslate());
		if (flag != AuxConfig.ShowStationInfo.Value)
		{
			AuxConfig.ShowStationInfo.Value = flag;
			if (!flag)
			{
				for (int i = 0; i < Auxilaryfunction.maxCount; i++)
				{
					stationtips[i].gameObject.SetActive(value: false);
				}
			}
		}
		if (flag)
		{
			GUILayout.BeginHorizontal();
			GUILayout.Space(30f);
			GUILayout.BeginVertical();
			bool num = GUILayout.Toggle(!AuxConfig.ShowStationInfoMode.Value, "详细模式".getTranslate());
			bool flag2 = GUILayout.Toggle(AuxConfig.ShowStationInfoMode.Value, "简易模式".getTranslate());
			if (num && flag2)
			{
				AuxConfig.ShowStationInfoMode.Value = !AuxConfig.ShowStationInfoMode.Value;
			}
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
		}
		AuxConfig.stationcopyItem_bool.Value = GUILayout.Toggle(AuxConfig.stationcopyItem_bool.Value, "物流站物品设置复制粘贴".getTranslate(), buttonoptions);
		AuxConfig.ChangeQuickKey = GUILayout.Toggle(AuxConfig.ChangeQuickKey, (!AuxConfig.ChangeQuickKey) ? "改变窗口快捷键".getTranslate() : "点击确认".getTranslate(), buttonoptions);
		if (AuxConfig.ChangeQuickKey)
		{
			GUILayout.Label(AuxConfig.tempShowWindow.ToString(), labelstyle);
		}
		GUILayout.EndVertical();
		GUILayout.Space(30f);
		GUILayout.BeginVertical();
		SpeedUpPatch.Enable = GUILayout.Toggle(SpeedUpPatch.Enable, "启动时间流速修改".getTranslate());
		GUILayout.BeginHorizontal();
		GUILayout.Label("流速倍率".getTranslate() + ":");
		string text = GUILayout.TextField($"{SpeedUpPatch.SpeedMultiple:N2}", GUILayout.MinWidth(heightdis * 3));
		if (text != $"{SpeedUpPatch.SpeedMultiple:N2}" && float.TryParse(text, out var result))
		{
			if ((double)result < 0.01)
			{
				result = 0.01f;
			}
			if (result > 10f)
			{
				result = 10f;
			}
			SpeedUpPatch.SpeedMultiple = result;
		}
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		SpeedUpPatch.SpeedMultiple = GUILayout.HorizontalSlider(SpeedUpPatch.SpeedMultiple, 0.01f, 10f, HorizontalSlideroptions);
		AuxConfig.upsquickset.Value = GUILayout.Toggle(AuxConfig.upsquickset.Value, "加速减速".getTranslate() + "(shift,'+''-')", buttonoptions);
		AuxConfig.autosavetimechange.Value = GUILayout.Toggle(AuxConfig.autosavetimechange.Value, "修改自动保存时长".getTranslate(), AuxConfig.autosavetimechange.Value ? new GUILayoutOption[0] : buttonoptions);
		if (AuxConfig.autosavetimechange.Value)
		{
			GUILayout.Label("自动保存时间".getTranslate() + "/min：", buttonoptions);
			int result2 = AuxConfig.autosavetime.Value / 60;
			if (int.TryParse(Regex.Replace(GUILayout.TextField(result2.ToString() ?? "", GUILayout.Height(heightdis), GUILayout.Width(5 * heightdis)), "[^0-9]", ""), out result2))
			{
				if (result2 < 1)
				{
					result2 = 1;
				}
				if (result2 > 10000)
				{
					result2 = 10000;
				}
				AuxConfig.autosavetime.Value = result2 * 60;
			}
		}
		AuxConfig.KeepBeltHeight.Value = GUILayout.Toggle(AuxConfig.KeepBeltHeight.Value, "保持传送带高度(shift)".getTranslate(), buttonoptions);
		AuxConfig.Quickstop_bool.Value = GUILayout.Toggle(AuxConfig.Quickstop_bool.Value, "ctrl+空格快速开关".getTranslate());
		GUILayout.BeginHorizontal();
		GUILayout.Space(30f);
		GameTickPatch.Enable = GUILayout.Toggle(GameTickPatch.Enable, "停止工厂".getTranslate());
		GUILayout.EndHorizontal();
		AuxConfig.noscaleuitech_bool.Value = GUILayout.Toggle(AuxConfig.noscaleuitech_bool.Value, "科技面板选中不缩放".getTranslate(), buttonoptions);
		if (AuxConfig.TrashStorageWindow_bool.Value != GUILayout.Toggle(AuxConfig.TrashStorageWindow_bool.Value, "背包垃圾桶".getTranslate(), buttonoptions))
		{
			AuxConfig.TrashStorageWindow_bool.Value = !AuxConfig.TrashStorageWindow_bool.Value;
			Auxilaryfunction.TrashCanButton.SetActive(AuxConfig.TrashStorageWindow_bool.Value);
		}
		AuxConfig.SunLightOpen.Value = GUILayout.Toggle(AuxConfig.SunLightOpen.Value, "夜灯".getTranslate());
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private void MainWindow(int winId)
	{
		GUILayout.BeginArea(new Rect(10f, 20f, MainWindowWidth, MainWindowHeight));
		GUILayout.BeginVertical();
		GUILayout.BeginHorizontal();
		for (int i = 1; i <= 7; i++)
		{
			if (whichpannel == i)
			{
				GUILayout.Button(menus[i].getTranslate(), selectedButtonStyle, buttonoptions);
			}
			else if (GUILayout.Button(menus[i].getTranslate(), buttonoptions))
			{
				whichpannel = i;
			}
		}
		GUILayout.Space(20f);
		GUILayout.EndHorizontal();
		scrollPosition = GUILayout.BeginScrollView(scrollPosition, GUILayout.Width(MainWindowWidth - 20f), GUILayout.Height(MainWindowHeight - (float)(heightdis * 2)));
		switch (whichpannel)
		{
		case 1:
			DefaultPanel();
			break;
		case 2:
			DisablePaintingPanel();
			break;
		case 3:
			EasyUsePanel();
			break;
		case 4:
			TextTechPanel();
			break;
		case 5:
			DysonPanel();
			break;
		case 6:
			BattlePanel();
			break;
		case 7:
			BluePrintConfigSetPanel();
			break;
		}
		GUILayout.EndScrollView();
		GUILayout.EndVertical();
		GUILayout.EndArea();
	}

	private void TextTechPanel()
	{
		int num = heightdis * 5;
		int num2 = Math.Max(1, (int)(MainWindowWidth / (float)num));
		Texture mainTexture = UIRoot.instance.uiGame.techTree.nodePrefab.buyoutButton.transform.Find("icon").GetComponent<Image>().mainTexture;
		GUILayout.BeginVertical();
		limitmaterial = GUILayout.Toggle(limitmaterial, "限制材料".getTranslate());
		GUILayout.Label("准备研究".getTranslate());
		GUILayoutOption[] options = new GUILayoutOption[2]
		{
			GUILayout.Width(num),
			GUILayout.Height(heightdis * 2)
		};
		int count = Auxilaryfunction.readyresearch.Count;
		int num3 = count / num2 + ((count % num2 > 0) ? 1 : 0);
		List<int> list = new List<int>(Auxilaryfunction.readyresearch);
		for (int i = 0; i < num3; i++)
		{
			GUILayout.BeginHorizontal();
			for (int j = 0; j < num2; j++)
			{
				int num4 = i * num2 + j;
				if (num4 == count)
				{
					break;
				}
				GUILayout.BeginVertical(GUILayout.Width(num));
				TechProto techProto = LDB.techs.Select(list[num4]);
				if (GUILayout.Button((techProto.ID < 2000) ? techProto.name : (techProto.name + techProto.Level), nomarginButtonStyle, options))
				{
					int num5 = list[num4];
					if (GameMain.history.TechInQueue(num5))
					{
						for (int k = 0; k < GameMain.history.techQueue.Length; k++)
						{
							if (GameMain.history.techQueue[k] == num5)
							{
								GameMain.history.RemoveTechInQueue(k);
								break;
							}
						}
					}
					Auxilaryfunction.readyresearch.Remove(num5);
				}
				GUILayout.BeginHorizontal();
				ItemProto[] itemArray = techProto.itemArray;
				for (int l = 0; l < itemArray.Length; l++)
				{
					GUILayout.Button(itemArray[l].iconSprite.texture, nomarginButtonStyle, iconbuttonoptions);
				}
				GUILayout.EndHorizontal();
				GUILayout.BeginHorizontal();
				RecipeProto[] unlockRecipeArray = techProto.unlockRecipeArray;
				for (int l = 0; l < unlockRecipeArray.Length; l++)
				{
					GUILayout.Button(unlockRecipeArray[l].iconSprite.texture, nomarginButtonStyle, iconbuttonoptions);
				}
				GUILayout.FlexibleSpace();
				if (GUILayout.Button(mainTexture, nomarginButtonStyle, iconbuttonoptions))
				{
					TechService.BuyoutTech(techProto);
				}
				GUILayout.EndHorizontal();
				GUILayout.EndVertical();
			}
			GUILayout.EndHorizontal();
		}
		GUILayout.Label("科技".getTranslate());
		List<int> list2 = new List<int>();
		TechProto[] dataArray = LDB.techs.dataArray;
		foreach (TechProto techProto2 in dataArray)
		{
			if (techProto2.ID > 2000 || techProto2.IsHiddenTech || techProto2.IsObsolete)
			{
				break;
			}
			if (Auxilaryfunction.readyresearch.Contains(techProto2.ID) || !GameMain.history.CanEnqueueTech(techProto2.ID) || techProto2.MaxLevel > 20 || GameMain.history.TechUnlocked(techProto2.ID))
			{
				continue;
			}
			if (limitmaterial)
			{
				bool flag = true;
				int[] items = techProto2.Items;
				foreach (int itemId in items)
				{
					if (!GameMain.history.ItemUnlocked(itemId))
					{
						flag = false;
						break;
					}
				}
				if (!flag)
				{
					continue;
				}
			}
			list2.Add(techProto2.ID);
		}
		count = list2.Count;
		num3 = count / num2 + ((count % num2 > 0) ? 1 : 0);
		list = list2;
		for (int n = 0; n < num3; n++)
		{
			GUILayout.BeginHorizontal();
			for (int num6 = 0; num6 < num2; num6++)
			{
				int num7 = n * num2 + num6;
				if (num7 == count)
				{
					break;
				}
				GUILayout.BeginVertical(GUILayout.Width(num));
				TechProto techProto3 = LDB.techs.Select(list[num7]);
				if (GUILayout.Button(techProto3.name, nomarginButtonStyle, options))
				{
					Auxilaryfunction.readyresearch.Add(techProto3.ID);
				}
				GUILayout.BeginHorizontal();
				ItemProto[] itemArray = techProto3.itemArray;
				for (int l = 0; l < itemArray.Length; l++)
				{
					GUILayout.Button(itemArray[l].iconSprite.texture, nomarginButtonStyle, iconbuttonoptions);
				}
				GUILayout.EndHorizontal();
				GUILayout.BeginHorizontal();
				RecipeProto[] unlockRecipeArray = techProto3.unlockRecipeArray;
				for (int l = 0; l < unlockRecipeArray.Length; l++)
				{
					GUILayout.Button(unlockRecipeArray[l].iconSprite.texture, nomarginButtonStyle, iconbuttonoptions);
				}
				GUILayout.FlexibleSpace();
				if (GUILayout.Button(mainTexture, nomarginButtonStyle, iconbuttonoptions))
				{
					TechService.BuyoutTech(techProto3);
				}
				GUILayout.EndHorizontal();
				GUILayout.EndVertical();
			}
			GUILayout.EndHorizontal();
		}
		GUILayout.Label("升级".getTranslate());
		list2 = new List<int>();
		dataArray = LDB.techs.dataArray;
		foreach (TechProto techProto4 in dataArray)
		{
			if (techProto4.ID < 2000 || Auxilaryfunction.readyresearch.Contains(techProto4.ID) || techProto4.IsObsolete || techProto4.IsHiddenTech || !GameMain.history.CanEnqueueTech(techProto4.ID) || techProto4.MaxLevel > 20 || techProto4.MaxLevel > 100 || GameMain.history.TechUnlocked(techProto4.ID))
			{
				continue;
			}
			if (limitmaterial)
			{
				bool flag2 = true;
				int[] items = techProto4.Items;
				foreach (int itemId2 in items)
				{
					if (!GameMain.history.ItemUnlocked(itemId2))
					{
						flag2 = false;
						break;
					}
				}
				if (!flag2)
				{
					continue;
				}
			}
			list2.Add(techProto4.ID);
		}
		count = list2.Count;
		num3 = count / num2 + ((count % num2 > 0) ? 1 : 0);
		list = list2;
		for (int num8 = 0; num8 < num3; num8++)
		{
			GUILayout.BeginHorizontal();
			for (int num9 = 0; num9 < num2; num9++)
			{
				int num10 = num8 * num2 + num9;
				if (num10 == count)
				{
					break;
				}
				GUILayout.BeginVertical(GUILayout.Width(num));
				TechProto techProto5 = LDB.techs.Select(list[num10]);
				if (GUILayout.Button(techProto5.name, nomarginButtonStyle, options))
				{
					Auxilaryfunction.readyresearch.Add(techProto5.ID);
				}
				GUILayout.BeginHorizontal();
				ItemProto[] itemArray = techProto5.itemArray;
				for (int l = 0; l < itemArray.Length; l++)
				{
					GUILayout.Button(itemArray[l].iconSprite.texture, nomarginButtonStyle, iconbuttonoptions);
				}
				GUILayout.EndHorizontal();
				GUILayout.BeginHorizontal();
				RecipeProto[] unlockRecipeArray = techProto5.unlockRecipeArray;
				for (int l = 0; l < unlockRecipeArray.Length; l++)
				{
					GUILayout.Button(unlockRecipeArray[l].iconSprite.texture, nomarginButtonStyle, iconbuttonoptions);
				}
				GUILayout.FlexibleSpace();
				if (GUILayout.Button(mainTexture, nomarginButtonStyle, iconbuttonoptions))
				{
					TechService.BuyoutTech(techProto5);
				}
				GUILayout.EndHorizontal();
				GUILayout.EndVertical();
			}
			GUILayout.FlexibleSpace();
			GUILayout.EndHorizontal();
		}
		GUILayout.EndVertical();
	}

	private bool MoveWindow()
	{
		if (!showwindow)
		{
			isDragging = false;
			return false;
		}
		float mainWindow_x = MainWindow_x;
		float mainWindow_y = MainWindow_y;
		if (leftscaling || rightscaling || bottomscaling)
		{
			return false;
		}
		Vector2 vector = Input.mousePosition;
		float x = vector.x;
		float num = (float)Screen.height - vector.y;
		bool flag = x > MainWindow_x && x < MainWindow_x + MainWindowWidth && num > MainWindow_y && num < MainWindow_y + 20f;
		if (Input.GetMouseButtonDown(0) && flag)
		{
			DragStartWindowX = MainWindow_x;
			DragStartWindowY = MainWindow_y;
			DragStartMouseX = x;
			DragStartMouseY = num;
			isDragging = true;
		}
		if (isDragging && Input.GetMouseButton(0))
		{
			MainWindow_x = DragStartWindowX + x - DragStartMouseX;
			MainWindow_y = DragStartWindowY + num - DragStartMouseY;
		}
		if (Input.GetMouseButtonUp(0))
		{
			isDragging = false;
		}
		MainWindow_y = Math.Max(10f, Math.Min((float)Screen.height - 10f, MainWindow_y));
		MainWindow_x = Math.Max(10f, Math.Min((float)Screen.width - 10f, MainWindow_x));
		if (MainWindow_x == mainWindow_x)
		{
			return MainWindow_y != mainWindow_y;
		}
		return true;
	}

	private bool Scaling_window()
	{
		if (!showwindow)
		{
			leftscaling = false;
			rightscaling = false;
			bottomscaling = false;
			return false;
		}
		float mainWindowWidth = MainWindowWidth;
		float mainWindowHeight = MainWindowHeight;
		Vector2 vector = Input.mousePosition;
		float x = vector.x;
		float num = (float)Screen.height - vector.y;
		float num2 = MainWindowWidth;
		float num3 = MainWindowHeight;
		if (Input.GetMouseButtonDown(0) && !leftscaling && !rightscaling && !bottomscaling && (!(num >= MainWindow_y) || !(num <= MainWindow_y + 20f)))
		{
			bool flag = x >= MainWindow_x - 10f && x <= MainWindow_x + 10f && num >= MainWindow_y && num <= MainWindow_y + num3;
			bool flag2 = x >= MainWindow_x + num2 - 10f && x <= MainWindow_x + num2 + 10f && num >= MainWindow_y && num <= MainWindow_y + num3;
			bool flag3 = num >= MainWindow_y + num3 - 10f && num <= MainWindow_y + num3 + 10f && x >= MainWindow_x && x <= MainWindow_x + num2;
			leftscaling = flag;
			rightscaling = !flag && flag2;
			bottomscaling = !flag && !rightscaling && flag3;
		}
		if (Input.GetMouseButton(0))
		{
			if (leftscaling)
			{
				float num4 = MainWindow_x + MainWindowWidth;
				num2 = Math.Max(100f, num4 - x);
				MainWindow_x = num4 - num2;
			}
			else if (rightscaling)
			{
				num2 = Math.Max(100f, x - MainWindow_x);
			}
			else if (bottomscaling)
			{
				num3 = Math.Max(100f, num - MainWindow_y);
			}
		}
		if (Input.GetMouseButtonUp(0))
		{
			rightscaling = false;
			leftscaling = false;
			bottomscaling = false;
		}
		MainWindowWidth = Math.Max(100f, num2);
		MainWindowHeight = Math.Max(100f, num3);
		if (MainWindowWidth == mainWindowWidth)
		{
			return MainWindowHeight != mainWindowHeight;
		}
		return true;
	}

	private void ResetWindowInteraction()
	{
		isDragging = false;
		leftscaling = false;
		rightscaling = false;
		bottomscaling = false;
	}

	private void UIPanelSet()
	{
		RectTransform component = UIRoot.instance.overlayCanvas.GetComponent<RectTransform>();
		RectTransform component2 = ui_AuxilaryPanelPanel.GetComponent<RectTransform>();
		float num = component.sizeDelta.x * 1f / (float)Screen.width;
		float num2 = component.sizeDelta.y * 1f / (float)Screen.height;
		component2.sizeDelta = new Vector2(num * MainWindowWidth, num2 * MainWindowHeight);
		component2.localPosition = new Vector2((0f - component.sizeDelta.x) / 2f + MainWindow_x * num, component.sizeDelta.y / 2f - MainWindow_y * num2 - component2.sizeDelta.y);
	}

	public void AssemblyGeneral(ERecipeType targetRecipeType)
	{
		List<RecipeProto> list = LDB.recipes.dataArray.Where((RecipeProto rp) => rp.Type == targetRecipeType && GameMain.history.RecipeUnlocked(rp.ID)).ToList();
		int count = list.Count;
		int num = 15;
		int num2 = count / num + ((count % num > 0) ? 1 : 0);
		GUILayout.BeginVertical();
		for (int num3 = 0; num3 < num2; num3++)
		{
			GUILayout.BeginHorizontal();
			for (int num4 = 0; num4 < num; num4++)
			{
				int num5 = num3 * num + num4;
				if (num5 == count)
				{
					if (GUILayout.Button("无".getTranslate(), bigiconbuttonoptions))
					{
						for (int num6 = 0; num6 < BluePrintBatchModifyBuild.FilterAssemblePools.Count; num6++)
						{
							AuxConfig.LocalPlanet.factory.factorySystem.TakeBackItems_Assembler(Auxilaryfunction.player, BluePrintBatchModifyBuild.FilterAssemblePools[num6]);
							AuxConfig.LocalPlanet.factory.factorySystem.assemblerPool[BluePrintBatchModifyBuild.FilterAssemblePools[num6]].SetRecipe(0, AuxConfig.LocalPlanet.factory.entitySignPool);
						}
					}
					break;
				}
				RecipeProto recipeProto = list[num5];
				if (GUILayout.Button(recipeProto.iconSprite.texture, bigiconbuttonoptions))
				{
					for (int num7 = 0; num7 < BluePrintBatchModifyBuild.FilterAssemblePools.Count; num7++)
					{
						AuxConfig.LocalPlanet.factory.factorySystem.TakeBackItems_Assembler(Auxilaryfunction.player, BluePrintBatchModifyBuild.FilterAssemblePools[num7]);
						AuxConfig.LocalPlanet.factory.factorySystem.assemblerPool[BluePrintBatchModifyBuild.FilterAssemblePools[num7]].SetRecipe(recipeProto.ID, AuxConfig.LocalPlanet.factory.entitySignPool);
					}
				}
			}
			GUILayout.EndHorizontal();
		}
		GUILayout.BeginHorizontal();
		if (GUILayout.Button("额外产出".getTranslate(), buttonoptions))
		{
			for (int num8 = 0; num8 < BluePrintBatchModifyBuild.FilterAssemblePools.Count; num8++)
			{
				if (AuxConfig.LocalPlanet.factory.factorySystem.assemblerPool[BluePrintBatchModifyBuild.FilterAssemblePools[num8]].recipeExecuteData.productive)
				{
					AuxConfig.LocalPlanet.factory.factorySystem.assemblerPool[BluePrintBatchModifyBuild.FilterAssemblePools[num8]].forceAccMode = false;
				}
			}
		}
		if (GUILayout.Button("生产加速".getTranslate(), buttonoptions))
		{
			for (int num9 = 0; num9 < BluePrintBatchModifyBuild.FilterAssemblePools.Count; num9++)
			{
				if (AuxConfig.LocalPlanet.factory.factorySystem.assemblerPool[BluePrintBatchModifyBuild.FilterAssemblePools[num9]].recipeExecuteData.productive)
				{
					AuxConfig.LocalPlanet.factory.factorySystem.assemblerPool[BluePrintBatchModifyBuild.FilterAssemblePools[num9]].forceAccMode = true;
				}
			}
		}
		if (GUILayout.Button("开启警报".getTranslate(), buttonoptions))
		{
			for (int num10 = 0; num10 < BluePrintBatchModifyBuild.FilterAssemblePools.Count; num10++)
			{
				AssemblerComponent assemblerComponent = AuxConfig.LocalPlanet.factory.factorySystem.assemblerPool[BluePrintBatchModifyBuild.FilterAssemblePools[num10]];
				if (AuxConfig.LocalPlanet.factory.entityPool[assemblerComponent.entityId].warningId <= 0)
				{
					AuxConfig.LocalPlanet.factory.EnableEntityWarning(assemblerComponent.entityId);
				}
			}
		}
		if (GUILayout.Button("关闭警报".getTranslate(), buttonoptions))
		{
			for (int num11 = 0; num11 < BluePrintBatchModifyBuild.FilterAssemblePools.Count; num11++)
			{
				AssemblerComponent assemblerComponent2 = AuxConfig.LocalPlanet.factory.factorySystem.assemblerPool[BluePrintBatchModifyBuild.FilterAssemblePools[num11]];
				if (AuxConfig.LocalPlanet.factory.entityPool[assemblerComponent2.entityId].warningId > 0)
				{
					AuxConfig.LocalPlanet.factory.DisableEntityWarning(assemblerComponent2.entityId);
				}
			}
		}
		GUILayout.EndHorizontal();
		GUILayout.EndVertical();
	}

	public void BeltModify()
	{
		bool flag = false;
		GUILayout.BeginVertical();
		GUILayout.BeginHorizontal();
		if (BluePrintBatchModifyBuild.BeltSignalIconId == 0)
		{
			if (GUILayout.Button("无".getTranslate(), bigiconbuttonoptions))
			{
				flag = true;
			}
		}
		else if (GUILayout.Button(LDB.signals.IconSprite(BluePrintBatchModifyBuild.BeltSignalIconId).texture, bigiconbuttonoptions))
		{
			flag = true;
		}
		if (flag)
		{
			float num = UIRoot.instance.overlayCanvas.GetComponent<RectTransform>().sizeDelta.x * 1f / (float)Screen.width;
			UISignalPicker.Popup(new Vector2((float)(-Screen.width) * num / 2f, (float)Screen.height * num / 2f), delegate(int signalid)
			{
				BluePrintBatchModifyBuild.BeltSignalIconId = signalid;
			});
		}
		if (GUILayout.Button("设置".getTranslate()))
		{
			foreach (int beltpool in BluePrintBatchModifyBuild.beltpools)
			{
				EntityData entityData = AuxConfig.LocalPlanet.factory.entityPool[beltpool];
				if (BluePrintBatchModifyBuild.CurrentSelectedBuilds.Contains(entityData.protoId))
				{
					AuxConfig.LocalPlanet.factory.cargoTraffic.SetBeltSignalIcon(beltpool, BluePrintBatchModifyBuild.BeltSignalIconId);
				}
			}
		}
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal();
		GUILayout.Label("传送带下标序号".getTranslate() + ":");
		string s = GUILayout.TextField(BluePrintBatchModifyBuild.BeltSignalNumber.ToString(), GUILayout.MinWidth(200f));
		int result = 0;
		if (int.TryParse(s, out result))
		{
			result = Math.Min(999999, result);
			result = Math.Max(-999999, result);
			BluePrintBatchModifyBuild.BeltSignalNumber = result;
		}
		if (GUILayout.Button("设置".getTranslate()))
		{
			foreach (int beltpool2 in BluePrintBatchModifyBuild.beltpools)
			{
				EntityData entityData2 = AuxConfig.LocalPlanet.factory.entityPool[beltpool2];
				if (BluePrintBatchModifyBuild.CurrentSelectedBuilds.Contains(entityData2.protoId))
				{
					AuxConfig.LocalPlanet.factory.cargoTraffic.SetBeltSignalNumber(beltpool2, BluePrintBatchModifyBuild.BeltSignalNumber);
				}
			}
		}
		if (GUILayout.Button("清空选中传送带".getTranslate()))
		{
			foreach (int beltpool3 in BluePrintBatchModifyBuild.beltpools)
			{
				EntityData entityData3 = AuxConfig.LocalPlanet.factory.entityPool[beltpool3];
				if (BluePrintBatchModifyBuild.CurrentSelectedBuilds.Contains(entityData3.protoId))
				{
					AuxConfig.LocalPlanet.factory.cargoTraffic.PickupBeltItems(GameMain.mainPlayer, entityData3.beltId, all: true);
				}
			}
		}
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.EndVertical();
	}

	public void EjectorModify()
	{
		object obj;
		if (GameMain.localStar != null)
		{
			GameData data = GameMain.data;
			if (data == null)
			{
				obj = null;
			}
			else
			{
				DysonSphere[] dysonSpheres = data.dysonSpheres;
				obj = ((dysonSpheres != null) ? dysonSpheres[GameMain.localStar.index] : null);
			}
		}
		else
		{
			obj = null;
		}
		DysonSphere dysonSphere = (DysonSphere)obj;
		if (dysonSphere?.swarm == null)
		{
			GUILayout.Label("当前星系没有戴森球".getTranslate());
			return;
		}
		DysonSwarm swarm = dysonSphere.swarm;
		GUILayout.BeginVertical();
		for (int i = 0; i < 4; i++)
		{
			GUILayout.BeginHorizontal();
			for (int j = 0; j < 5; j++)
			{
				int num = i * 5 + j + 1;
				if (swarm.OrbitExist(num) && GUILayout.Button(num.ToString(), numberButtonoptions))
				{
					for (int k = 0; k < BluePrintBatchModifyBuild.ejectorpools.Count; k++)
					{
						AuxConfig.LocalPlanet.factory.factorySystem.ejectorPool[BluePrintBatchModifyBuild.ejectorpools[k]].SetOrbit(num);
					}
				}
			}
			GUILayout.EndHorizontal();
		}
		GUILayout.EndVertical();
	}

	public void LabModify()
	{
		GUILayout.BeginVertical();
		GUILayout.BeginHorizontal();
		int num = -1;
		for (int i = 0; i <= 5; i++)
		{
			ItemProto itemProto = LDB.items.Select(LabComponent.matrixIds[i]);
			if (GUILayout.Button(itemProto.iconSprite.texture, bigiconbuttonoptions))
			{
				num = itemProto.maincraft.ID;
			}
		}
		if (GUILayout.Button("无".getTranslate(), bigiconbuttonoptions))
		{
			num = 0;
		}
		if (num != -1)
		{
			for (int j = 0; j < BluePrintBatchModifyBuild.Filterlabpools.Count; j++)
			{
				AuxConfig.LocalPlanet.factory.factorySystem.TakeBackItems_Lab(Auxilaryfunction.player, BluePrintBatchModifyBuild.Filterlabpools[j]);
				AuxConfig.LocalPlanet.factory.factorySystem.labPool[BluePrintBatchModifyBuild.Filterlabpools[j]].SetFunction(_researchMode: false, num, 0, AuxConfig.LocalPlanet.factory.entitySignPool);
			}
		}
		GUILayout.EndHorizontal();
		if (GUILayout.Button("科研模式".getTranslate(), buttonoptions))
		{
			for (int k = 0; k < BluePrintBatchModifyBuild.Filterlabpools.Count; k++)
			{
				AuxConfig.LocalPlanet.factory.factorySystem.TakeBackItems_Lab(Auxilaryfunction.player, BluePrintBatchModifyBuild.Filterlabpools[k]);
				AuxConfig.LocalPlanet.factory.factorySystem.labPool[BluePrintBatchModifyBuild.Filterlabpools[k]].SetFunction(_researchMode: true, 0, GameMain.history.currentTech, AuxConfig.LocalPlanet.factory.entitySignPool);
			}
		}
		if (GUILayout.Button("额外产出".getTranslate(), buttonoptions))
		{
			for (int l = 0; l < BluePrintBatchModifyBuild.Filterlabpools.Count; l++)
			{
				if (AuxConfig.LocalPlanet.factory.factorySystem.labPool[BluePrintBatchModifyBuild.Filterlabpools[l]].recipeExecuteData.productive)
				{
					AuxConfig.LocalPlanet.factory.factorySystem.labPool[BluePrintBatchModifyBuild.Filterlabpools[l]].forceAccMode = false;
				}
			}
		}
		if (GUILayout.Button("生产加速".getTranslate(), buttonoptions))
		{
			for (int m = 0; m < BluePrintBatchModifyBuild.Filterlabpools.Count; m++)
			{
				if (AuxConfig.LocalPlanet.factory.factorySystem.labPool[BluePrintBatchModifyBuild.Filterlabpools[m]].recipeExecuteData.productive)
				{
					AuxConfig.LocalPlanet.factory.factorySystem.labPool[BluePrintBatchModifyBuild.Filterlabpools[m]].forceAccMode = true;
				}
			}
		}
		GUILayout.EndVertical();
	}

	public void NormalStationModify()
	{
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		GUILayout.BeginHorizontal();
		GUILayout.Label("物流站名称".getTranslate());
		BluePrintBatchModifyBuild.ModifyStationName = GUILayout.TextArea(BluePrintBatchModifyBuild.ModifyStationName, GUILayout.Width(200f));
		if (GUILayout.Button("设置名称".getTranslate(), buttonoptions))
		{
			foreach (int normalstation in BluePrintBatchModifyBuild.normalstations)
			{
				StationComponent stationComponent = AuxConfig.LocalPlanet.factory.transport.stationPool[normalstation];
				AuxConfig.LocalPlanet.factory.WriteExtraInfoOnEntity(stationComponent.entityId, BluePrintBatchModifyBuild.ModifyStationName);
			}
		}
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.BeginVertical();
		if (GUILayout.Button("重置物流站参数".getTranslate()))
		{
			BluePrintBatchModifyBuild.ResetStationConfig();
		}
		for (int i = 0; i < 4; i++)
		{
			StationStoreConfig stationStoreConfig = BluePrintBatchModifyBuild.stationStoreConfigs[i];
			GUILayout.BeginHorizontal(GUILayout.Height(70f));
			stationStoreConfig.IsEnabled = GUILayout.Toggle(stationStoreConfig.IsEnabled, "启用".getTranslate());
			bool flag = false;
			if (stationStoreConfig.ItemId == 0)
			{
				if (GUILayout.Button("无".getTranslate(), bigiconbuttonoptions))
				{
					flag = true;
				}
			}
			else if (GUILayout.Button(LDB.items.Select(stationStoreConfig.ItemId).iconSprite.texture, bigiconbuttonoptions))
			{
				flag = true;
			}
			if (flag)
			{
				float num = UIRoot.instance.overlayCanvas.GetComponent<RectTransform>().sizeDelta.x * 1f / (float)Screen.width;
				UIItemPicker.Popup(new Vector2((float)(-Screen.width) * num / 2f, (float)Screen.height * num / 2f), delegate(ItemProto item)
				{
					if (item == null)
					{
						stationStoreConfig.ItemId = 0;
					}
					else
					{
						for (int j = 0; j < BluePrintBatchModifyBuild.stationStoreConfigs.Length; j++)
						{
							StationStoreConfig stationStoreConfig3 = BluePrintBatchModifyBuild.stationStoreConfigs[j];
							if (stationStoreConfig3.ItemId == item.ID)
							{
								stationStoreConfig3.ItemId = 0;
								stationStoreConfig3.IsEnabled = false;
							}
						}
						stationStoreConfig.ItemId = item.ID;
					}
				});
			}
			GUILayout.BeginVertical();
			stationStoreConfig.max = (int)GUILayout.HorizontalSlider(stationStoreConfig.max, 0f, 100f, GUILayout.Width(120f));
			GUILayout.Label("上限".getTranslate() + stationStoreConfig.max * 100);
			GUILayout.EndVertical();
			GUILayout.BeginVertical();
			if (GUILayout.Button(LogisticsService.GetLogisticText(stationStoreConfig.localLogic, isStellar: false, careStellar: true), Constant.GetStationStorelogicStyle(stationStoreConfig.localLogic)))
			{
				stationStoreConfig.localLogic = (ELogisticStorage)((int)(stationStoreConfig.localLogic + 1) % 3);
			}
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
		}
		if (GUILayout.Button("设置物流站物品".getTranslate(), buttonoptions))
		{
			foreach (int normalstation2 in BluePrintBatchModifyBuild.normalstations)
			{
				StationComponent stationComponent2 = AuxConfig.LocalPlanet.factory.transport.stationPool[normalstation2];
				List<int> list = (from x in stationComponent2.storage
					where x.itemId != 0
					select x.itemId).ToList();
				for (int num2 = 0; num2 < stationComponent2.storage.Length && num2 < 4; num2++)
				{
					StationStoreConfig stationStoreConfig2 = BluePrintBatchModifyBuild.stationStoreConfigs[num2];
					int itemId = stationComponent2.storage[num2].itemId;
					int itemId2 = stationStoreConfig2.ItemId;
					if (list.Contains(itemId) && itemId2 != itemId)
					{
						if (stationComponent2.storage[num2].count > 0)
						{
							Auxilaryfunction.player.TryAddItemToPackage(itemId, stationComponent2.storage[num2].count, stationComponent2.storage[num2].inc, throwTrash: true);
						}
						stationComponent2.storage[num2].itemId = 0;
					}
					if (stationStoreConfig2.IsEnabled)
					{
						if (stationComponent2.storage[num2].count > 0)
						{
							Auxilaryfunction.player.TryAddItemToPackage(itemId, stationComponent2.storage[num2].count, stationComponent2.storage[num2].inc, throwTrash: true);
						}
						stationComponent2.storage[num2].itemId = itemId2;
						stationComponent2.storage[num2].max = stationStoreConfig2.max * 100;
						stationComponent2.storage[num2].localLogic = stationStoreConfig2.localLogic;
						stationComponent2.storage[num2].remoteLogic = stationStoreConfig2.remoteLogic;
					}
				}
			}
		}
		if (GUILayout.Button("设置物流站参数".getTranslate()))
		{
			foreach (int normalstation3 in BluePrintBatchModifyBuild.normalstations)
			{
				StationComponent stationComponent3 = AuxConfig.LocalPlanet.factory.transport.stationPool[normalstation3];
				stationComponent3.tripRangeDrones = Math.Cos((double)AuxConfig.stationdronedist.Value * Math.PI / 180.0);
				AuxConfig.LocalPlanet.factory.powerSystem.consumerPool[stationComponent3.pcId].workEnergyPerTick = (long)AuxConfig.stationmaxpowerpertick.Value * 16667;
				if (AuxConfig.stationmaxpowerpertick.Value > 60f && !stationComponent3.isStellar)
				{
					AuxConfig.LocalPlanet.factory.powerSystem.consumerPool[stationComponent3.pcId].workEnergyPerTick = 1000020L;
				}
				stationComponent3.deliveryDrones = ((AuxConfig.DroneStartCarry.Value == 0f) ? 1 : ((int)(AuxConfig.DroneStartCarry.Value * 10f) * 10));
				if (stationComponent3.isStellar)
				{
					stationComponent3.warpEnableDist = AuxConfig.stationwarpdist.Value * 40000.0;
					stationComponent3.deliveryShips = ((AuxConfig.ShipStartCarry.Value == 0f) ? 1 : ((int)(AuxConfig.ShipStartCarry.Value * 10f) * 10));
					stationComponent3.tripRangeShips = ((AuxConfig.stationshipdist.Value > 60) ? 24000000000L : (AuxConfig.stationshipdist.Value * 2400000));
				}
			}
			AuxConfig.LocalPlanet.factory.transport.RefreshStationTraffic();
		}
		GUILayout.EndVertical();
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	public void PowerExchangerModify()
	{
		GUILayout.BeginVertical();
		int num = -2;
		if (GUILayout.Button("放电".getTranslate(), buttonoptions))
		{
			num = -1;
		}
		if (GUILayout.Button("待机".getTranslate(), buttonoptions))
		{
			num = 0;
		}
		if (GUILayout.Button("充电".getTranslate(), buttonoptions))
		{
			num = 1;
		}
		if (num != -2)
		{
			foreach (int powerexchangerpool in BluePrintBatchModifyBuild.powerexchangerpools)
			{
				GameMain.localPlanet.factory.powerSystem.excPool[powerexchangerpool].targetState = num;
			}
		}
		GUILayout.EndVertical();
	}

	public void PowergenGammaModify()
	{
		PlanetFactory factory = AuxConfig.LocalPlanet.factory;
		GUILayout.BeginVertical();
		if (GUILayout.Button("直接发电".getTranslate(), buttonoptions))
		{
			for (int i = 0; i < BluePrintBatchModifyBuild.powergenGammapools.Count; i++)
			{
				PowerGeneratorComponent powerGeneratorComponent = factory.powerSystem.genPool[BluePrintBatchModifyBuild.powergenGammapools[i]];
				int num = BluePrintBatchModifyBuild.powergenGammapools[i];
				if (powerGeneratorComponent.gamma)
				{
					PowerGeneratorComponent powerGeneratorComponent2 = factory.powerSystem.genPool[num];
					int productId = powerGeneratorComponent2.productId;
					int num2 = (int)powerGeneratorComponent2.productCount;
					if (productId != 0 && num2 > 0)
					{
						int upCount = Auxilaryfunction.player.TryAddItemToPackage(productId, num2, 0, throwTrash: true);
						UIItemup.Up(productId, upCount);
					}
					factory.powerSystem.genPool[num].productId = 0;
					factory.powerSystem.genPool[num].productCount = 0f;
				}
			}
		}
		if (GUILayout.Button("光子生成".getTranslate(), buttonoptions))
		{
			for (int j = 0; j < BluePrintBatchModifyBuild.powergenGammapools.Count; j++)
			{
				PowerGeneratorComponent powerGeneratorComponent3 = factory.powerSystem.genPool[BluePrintBatchModifyBuild.powergenGammapools[j]];
				int num3 = BluePrintBatchModifyBuild.powergenGammapools[j];
				if (powerGeneratorComponent3.gamma)
				{
					PowerGeneratorComponent powerGeneratorComponent4 = factory.powerSystem.genPool[num3];
					ItemProto itemProto = LDB.items.Select(factory.entityPool[powerGeneratorComponent4.entityId].protoId);
					if (itemProto == null)
					{
						return;
					}
					GameHistoryData history = GameMain.history;
					if (LDB.items.Select(itemProto.prefabDesc.powerProductId) == null || !history.ItemUnlocked(itemProto.prefabDesc.powerProductId))
					{
						factory.powerSystem.genPool[num3].productId = 0;
						return;
					}
					factory.powerSystem.genPool[num3].productId = itemProto.prefabDesc.powerProductId;
				}
			}
		}
		GUILayout.EndVertical();
	}

	public void StellarStationModify()
	{
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		GUILayout.BeginHorizontal();
		GUILayout.Label("物流站名称".getTranslate());
		BluePrintBatchModifyBuild.ModifyStationName = GUILayout.TextArea(BluePrintBatchModifyBuild.ModifyStationName, GUILayout.MinWidth(200f));
		if (GUILayout.Button("设置名称".getTranslate(), buttonoptions))
		{
			foreach (int stellarstation in BluePrintBatchModifyBuild.stellarstations)
			{
				StationComponent stationComponent = AuxConfig.LocalPlanet.factory.transport.stationPool[stellarstation];
				AuxConfig.LocalPlanet.factory.WriteExtraInfoOnEntity(stationComponent.entityId, BluePrintBatchModifyBuild.ModifyStationName);
			}
		}
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.BeginHorizontal();
		GUILayout.BeginVertical();
		if (GUILayout.Button("重置物流站参数".getTranslate()))
		{
			BluePrintBatchModifyBuild.ResetStationConfig();
		}
		for (int i = 0; i < 5; i++)
		{
			StationStoreConfig stationStoreConfig = BluePrintBatchModifyBuild.stationStoreConfigs[i];
			GUILayout.BeginHorizontal(GUILayout.Height(70f));
			stationStoreConfig.IsEnabled = GUILayout.Toggle(stationStoreConfig.IsEnabled, "启用".getTranslate());
			bool flag = false;
			if (stationStoreConfig.ItemId == 0)
			{
				if (GUILayout.Button("无".getTranslate(), bigiconbuttonoptions))
				{
					flag = true;
				}
			}
			else if (GUILayout.Button(LDB.items.Select(stationStoreConfig.ItemId).iconSprite.texture, bigiconbuttonoptions))
			{
				flag = true;
			}
			if (flag)
			{
				float num = UIRoot.instance.overlayCanvas.GetComponent<RectTransform>().sizeDelta.x * 1f / (float)Screen.width;
				UIItemPicker.Popup(new Vector2((float)(-Screen.width) * num / 2f, (float)Screen.height * num / 2f), delegate(ItemProto item)
				{
					if (item == null)
					{
						stationStoreConfig.ItemId = 0;
					}
					else
					{
						for (int j = 0; j < BluePrintBatchModifyBuild.stationStoreConfigs.Length; j++)
						{
							StationStoreConfig stationStoreConfig3 = BluePrintBatchModifyBuild.stationStoreConfigs[j];
							if (stationStoreConfig3.ItemId == item.ID)
							{
								stationStoreConfig3.ItemId = 0;
								stationStoreConfig3.IsEnabled = false;
							}
						}
						stationStoreConfig.ItemId = item.ID;
					}
				});
			}
			GUILayout.BeginVertical();
			stationStoreConfig.max = (int)GUILayout.HorizontalSlider(stationStoreConfig.max, 0f, 200f, GUILayout.Width(120f));
			GUILayout.Label("上限".getTranslate() + stationStoreConfig.max * 100);
			GUILayout.EndVertical();
			GUILayout.BeginVertical();
			if (GUILayout.Button(LogisticsService.GetLogisticText(stationStoreConfig.localLogic, isStellar: false, careStellar: true), Constant.GetStationStorelogicStyle(stationStoreConfig.localLogic)))
			{
				stationStoreConfig.localLogic = (ELogisticStorage)((int)(stationStoreConfig.localLogic + 1) % 3);
			}
			if (GUILayout.Button(LogisticsService.GetLogisticText(stationStoreConfig.remoteLogic, isStellar: true, careStellar: true), Constant.GetStationStorelogicStyle(stationStoreConfig.remoteLogic)))
			{
				stationStoreConfig.remoteLogic = (ELogisticStorage)((int)(stationStoreConfig.remoteLogic + 1) % 3);
			}
			GUILayout.EndVertical();
			GUILayout.EndHorizontal();
		}
		if (GUILayout.Button("设置物流站物品".getTranslate(), buttonoptions))
		{
			foreach (int stellarstation2 in BluePrintBatchModifyBuild.stellarstations)
			{
				StationComponent stationComponent2 = AuxConfig.LocalPlanet.factory.transport.stationPool[stellarstation2];
				List<int> list = (from x in BluePrintBatchModifyBuild.stationStoreConfigs
					where x.ItemId != 0
					select x.ItemId).ToList();
				for (int num2 = 0; num2 < stationComponent2.storage.Length && num2 < 5; num2++)
				{
					StationStoreConfig stationStoreConfig2 = BluePrintBatchModifyBuild.stationStoreConfigs[num2];
					int itemId = stationComponent2.storage[num2].itemId;
					int itemId2 = stationStoreConfig2.ItemId;
					if (itemId2 != itemId && list.Contains(itemId))
					{
						if (stationComponent2.storage[num2].count > 0)
						{
							Auxilaryfunction.player.TryAddItemToPackage(itemId, stationComponent2.storage[num2].count, stationComponent2.storage[num2].inc, throwTrash: true);
							stationComponent2.storage[num2].count = 0;
						}
						stationComponent2.storage[num2].itemId = 0;
					}
					if (stationStoreConfig2.IsEnabled)
					{
						if (itemId != itemId2 && stationComponent2.storage[num2].count > 0)
						{
							Auxilaryfunction.player.TryAddItemToPackage(itemId, stationComponent2.storage[num2].count, stationComponent2.storage[num2].inc, throwTrash: true);
							stationComponent2.storage[num2].count = 0;
						}
						stationComponent2.storage[num2].itemId = itemId2;
						stationComponent2.storage[num2].max = stationStoreConfig2.max * 100;
						stationComponent2.storage[num2].localLogic = stationStoreConfig2.localLogic;
						stationComponent2.storage[num2].remoteLogic = stationStoreConfig2.remoteLogic;
					}
				}
				GameMain.data.galacticTransport.RefreshTraffic(stationComponent2.gid);
			}
			AuxConfig.LocalPlanet.factory.transport.RefreshStationTraffic();
		}
		if (GUILayout.Button("设置物流站参数".getTranslate()))
		{
			foreach (int stellarstation3 in BluePrintBatchModifyBuild.stellarstations)
			{
				StationComponent stationComponent3 = AuxConfig.LocalPlanet.factory.transport.stationPool[stellarstation3];
				stationComponent3.tripRangeDrones = Math.Cos((double)AuxConfig.stationdronedist.Value * Math.PI / 180.0);
				AuxConfig.LocalPlanet.factory.powerSystem.consumerPool[stationComponent3.pcId].workEnergyPerTick = (long)AuxConfig.stationmaxpowerpertick.Value * 16667;
				if (AuxConfig.stationmaxpowerpertick.Value > 60f && !stationComponent3.isStellar)
				{
					AuxConfig.LocalPlanet.factory.powerSystem.consumerPool[stationComponent3.pcId].workEnergyPerTick = 1000020L;
				}
				stationComponent3.deliveryDrones = ((AuxConfig.DroneStartCarry.Value == 0f) ? 1 : ((int)(AuxConfig.DroneStartCarry.Value * 10f) * 10));
				if (stationComponent3.isStellar)
				{
					stationComponent3.warpEnableDist = AuxConfig.stationwarpdist.Value * 40000.0;
					stationComponent3.deliveryShips = ((AuxConfig.ShipStartCarry.Value == 0f) ? 1 : ((int)(AuxConfig.ShipStartCarry.Value * 10f) * 10));
					stationComponent3.tripRangeShips = ((AuxConfig.stationshipdist.Value > 60) ? 24000000000L : (AuxConfig.stationshipdist.Value * 2400000));
				}
				GameMain.data.galacticTransport.RefreshTraffic(stationComponent3.gid);
			}
			AuxConfig.LocalPlanet.factory.transport.RefreshStationTraffic();
		}
		GUILayout.EndVertical();
		GUILayout.BeginVertical();
		BluePrintBatchModifyBuild.EnsureStationGroupCount(GetStationGroupButtonCount());
		if (BluePrintBatchModifyBuild.StationGroupDirty && BluePrintBatchModifyBuild.stellarstations.Count > 0)
		{
			BluePrintBatchModifyBuild.SyncStationGroupFrom(AuxConfig.LocalPlanet.factory.transport.stationPool[BluePrintBatchModifyBuild.stellarstations[0]]);
			BluePrintBatchModifyBuild.StationGroupDirty = false;
		}
		bool flag2 = false;
		if (BluePrintBatchModifyBuild.stellarstations.Count > 1)
		{
			long remoteGroupMask = AuxConfig.LocalPlanet.factory.transport.stationPool[BluePrintBatchModifyBuild.stellarstations[0]].remoteGroupMask;
			for (int num3 = 1; num3 < BluePrintBatchModifyBuild.stellarstations.Count; num3++)
			{
				if (AuxConfig.LocalPlanet.factory.transport.stationPool[BluePrintBatchModifyBuild.stellarstations[num3]].remoteGroupMask != remoteGroupMask)
				{
					flag2 = true;
					break;
				}
			}
		}
		GUILayout.Label("分组".getTranslate() + (flag2 ? "（多站分组不一致）".getTranslate() : ""), buttonoptions);
		GUILayout.BeginHorizontal();
		if (GUILayout.Button("读取当前站".getTranslate()) && BluePrintBatchModifyBuild.stellarstations.Count > 0)
		{
			BluePrintBatchModifyBuild.SyncStationGroupFrom(AuxConfig.LocalPlanet.factory.transport.stationPool[BluePrintBatchModifyBuild.stellarstations[0]]);
		}
		if (GUILayout.Button("全选".getTranslate()))
		{
			for (int num4 = 0; num4 < BluePrintBatchModifyBuild.StationGroup.Length; num4++)
			{
				BluePrintBatchModifyBuild.StationGroup[num4] = true;
			}
		}
		if (GUILayout.Button("反选".getTranslate()))
		{
			for (int num5 = 0; num5 < BluePrintBatchModifyBuild.StationGroup.Length; num5++)
			{
				BluePrintBatchModifyBuild.StationGroup[num5] = !BluePrintBatchModifyBuild.StationGroup[num5];
			}
		}
		if (GUILayout.Button("清空".getTranslate()))
		{
			for (int num6 = 0; num6 < BluePrintBatchModifyBuild.StationGroup.Length; num6++)
			{
				BluePrintBatchModifyBuild.StationGroup[num6] = false;
			}
		}
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		for (int num7 = 0; num7 * 6 < BluePrintBatchModifyBuild.StationGroup.Length; num7++)
		{
			GUILayout.BeginHorizontal();
			for (int num8 = 0; num8 < 6; num8++)
			{
				int num9 = num7 * 6 + num8;
				if (num9 >= BluePrintBatchModifyBuild.StationGroup.Length)
				{
					break;
				}
				if (GUILayout.Button((num9 + 1).ToString(), BluePrintBatchModifyBuild.StationGroup[num9] ? selectedButtonStyle : GUI.skin.button, numberButtonoptions))
				{
					BluePrintBatchModifyBuild.StationGroup[num9] = !BluePrintBatchModifyBuild.StationGroup[num9];
				}
			}
			GUILayout.EndHorizontal();
		}
		GUILayout.Label("行为设置".getTranslate());
		GUILayout.BeginHorizontal();
		if (GUILayout.Button("忽略配队设置".getTranslate(), (BluePrintBatchModifyBuild.eRemoteRoutePriority == ERemoteRoutePriority.Ignore) ? selectedButtonStyle : GUI.skin.button))
		{
			BluePrintBatchModifyBuild.eRemoteRoutePriority = ERemoteRoutePriority.Ignore;
		}
		if (GUILayout.Button("优先配队设置".getTranslate(), (BluePrintBatchModifyBuild.eRemoteRoutePriority == ERemoteRoutePriority.Prioritize) ? selectedButtonStyle : GUI.skin.button))
		{
			BluePrintBatchModifyBuild.eRemoteRoutePriority = ERemoteRoutePriority.Prioritize;
		}
		if (GUILayout.Button("只看配队设置".getTranslate(), (BluePrintBatchModifyBuild.eRemoteRoutePriority == ERemoteRoutePriority.Only) ? selectedButtonStyle : GUI.skin.button))
		{
			BluePrintBatchModifyBuild.eRemoteRoutePriority = ERemoteRoutePriority.Only;
		}
		if (GUILayout.Button("专属配队设置".getTranslate(), (BluePrintBatchModifyBuild.eRemoteRoutePriority == ERemoteRoutePriority.Designated) ? selectedButtonStyle : GUI.skin.button))
		{
			BluePrintBatchModifyBuild.eRemoteRoutePriority = ERemoteRoutePriority.Designated;
		}
		GUILayout.EndHorizontal();
		if (GUILayout.Button("应用到选中物流站".getTranslate(), buttonoptions))
		{
			long num10 = 0L;
			for (int num11 = 0; num11 < BluePrintBatchModifyBuild.StationGroup.Length; num11++)
			{
				if (BluePrintBatchModifyBuild.StationGroup[num11])
				{
					num10 |= 1L << num11;
				}
			}
			foreach (int stellarstation4 in BluePrintBatchModifyBuild.stellarstations)
			{
				StationComponent obj = AuxConfig.LocalPlanet.factory.transport.stationPool[stellarstation4];
				obj.remoteGroupMask = num10;
				obj.routePriority = BluePrintBatchModifyBuild.eRemoteRoutePriority;
			}
			GameMain.data.galacticTransport.RefreshTraffic();
		}
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
		GUILayout.EndVertical();
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	public void TurretModify()
	{
		GUILayout.BeginVertical();
		GUILayout.Label("分组".getTranslate());
		GUILayout.BeginHorizontal();
		for (int i = 1; i <= 5; i++)
		{
			if (GUILayout.Button(i.ToString(), (BluePrintBatchModifyBuild.SelectedTurretGroup == i) ? selectedButtonStyle : GUI.skin.button, numberButtonoptions))
			{
				BluePrintBatchModifyBuild.SelectedTurretGroup = i;
			}
		}
		if (GUILayout.Button("取消分组".getTranslate(), (BluePrintBatchModifyBuild.SelectedTurretGroup == 0) ? selectedButtonStyle : GUI.skin.button))
		{
			BluePrintBatchModifyBuild.SelectedTurretGroup = 0;
		}
		GUILayout.EndHorizontal();
		if (GUILayout.Button("设置分组".getTranslate()))
		{
			foreach (int item in BluePrintBatchModifyBuild.turretpool)
			{
				ref TurretComponent reference = ref AuxConfig.LocalPlanet.factory.defenseSystem.turrets.buffer[item];
				if (reference.id == item)
				{
					reference.SetGroup(BluePrintBatchModifyBuild.SelectedTurretGroup);
				}
			}
		}
		GUILayout.Label("参数配置".getTranslate());
		GUILayout.BeginHorizontal();
		string[] array = new string[4] { "地面", "低空", "高空", "太空" };
		string[] array2 = new string[4] { "OFF", "低优先", "均衡", "高优先" };
		for (int j = 0; j < 4; j++)
		{
			GUILayout.BeginVertical();
			GUILayout.Label(array[j].getTranslate());
			if (GUILayout.Button(array2[BluePrintBatchModifyBuild.TurretConfigs[j]]))
			{
				BluePrintBatchModifyBuild.TurretConfigIsSelected[j] = !BluePrintBatchModifyBuild.TurretConfigIsSelected[j];
				if (BluePrintBatchModifyBuild.TurretConfigIsSelected[j])
				{
					for (int k = 0; k < 4; k++)
					{
						if (j != k)
						{
							BluePrintBatchModifyBuild.TurretConfigIsSelected[k] = false;
						}
					}
				}
			}
			if (BluePrintBatchModifyBuild.TurretConfigIsSelected[j])
			{
				for (int l = 0; l < 4; l++)
				{
					if (GUILayout.Button(array2[l].getTranslate()))
					{
						BluePrintBatchModifyBuild.TurretConfigs[j] = l;
						BluePrintBatchModifyBuild.TurretConfigIsSelected[j] = false;
					}
				}
			}
			GUILayout.EndVertical();
		}
		GUILayout.EndHorizontal();
		if (GUILayout.Button("设置参数".getTranslate()))
		{
			foreach (int item2 in BluePrintBatchModifyBuild.turretpool)
			{
				ref TurretComponent reference2 = ref AuxConfig.LocalPlanet.factory.defenseSystem.turrets.buffer[item2];
				if (reference2.id != item2)
				{
					continue;
				}
				VSLayerMask vsSettings = reference2.vsSettings;
				for (int m = 0; m < 4; m++)
				{
					int num = BluePrintBatchModifyBuild.TurretConfigs[m];
					switch (m)
					{
					case 0:
						reference2.vsSettings &= VSLayerMask.AirAngOrbitAndSpace;
						break;
					case 1:
						reference2.vsSettings &= VSLayerMask.GroundAndOrbitAndSpace;
						break;
					case 2:
						reference2.vsSettings &= VSLayerMask.GroundAndAirAndSpace;
						break;
					case 3:
						reference2.vsSettings &= VSLayerMask.GroundAndAirAndOrbit;
						break;
					}
					reference2.vsSettings |= (VSLayerMask)(byte)(num << m * 2);
				}
				if (reference2.vsSettings != vsSettings)
				{
					reference2.Search(GameMain.localPlanet.factory, PlanetFactory.PrefabDescByModelIndex[GameMain.localPlanet.factory.entityPool[reference2.entityId].modelIndex], GameMain.gameTick);
				}
			}
		}
		GUILayout.EndVertical();
	}
}
