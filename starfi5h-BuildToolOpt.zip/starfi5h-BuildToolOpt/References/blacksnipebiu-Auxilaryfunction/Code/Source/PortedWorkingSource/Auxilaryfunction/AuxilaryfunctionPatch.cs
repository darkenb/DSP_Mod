using static Auxilaryfunction.AuxConfig;
using static Auxilaryfunction.Auxilaryfunction;
using System;
using Auxilaryfunction.Models;
using HarmonyLib;
using UnityEngine;

namespace Auxilaryfunction;

public class AuxilaryfunctionPatch
{
	[HarmonyPrefix]
	[HarmonyPatch(typeof(GameLoader), "CreateLoader")]
	public static void GameLoaderCreateLoaderPrefix()
	{
		Auxilaryfunction.GameDataImported = false;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameLoader), "SelfDestroy")]
	public static void GameLoaderCreateLoaderPostfix()
	{
		Auxilaryfunction.GameDataImported = true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(FactorySystem), "NewMinerComponent")]
	public static void NewMinerComponentPatch(ref int __result, FactorySystem __instance)
	{
		if (AuxConfig.auto_supply_station.Value && __instance.factory.entityPool[__instance.minerPool[__result].entityId].protoId == 2316 && BuildTargetValues.IsConfigEnabled("大型采矿机采矿速率"))
		{
			__instance.minerPool[__result].speed = AuxConfig.veincollectorspeed.Value * 1000;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIBlueprintInspector), "Refresh")]
	public static void UIBlueprintInspectorRefresh(bool refreshComponent)
	{
		BluePrintBatchModifyBuild.NeedRefresh = refreshComponent;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PowerSystem), "NewGeneratorComponent")]
    public static void NewGeneratorComponentPatch(ref int __result, PowerSystem __instance)
    {
        if (player?.factory != __instance.factory || !autosetSomevalue_bool.Value) return;
        NativeInventory.FillFuel(player, __instance.factory, __result, auto_supply_starfuelID.Value, auto_supply_starfuel.Value);
    }

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetTransport), "NewStationComponent")]
    public static void NewStationComponentPatch(ref StationComponent __result, PlanetTransport __instance)
    {
        if (player == null || player.factory != __instance.factory || __result == null) return;
        if (auto_supply_station.Value && !__result.isCollector && !__result.isVeinCollector)
        {
            if (BuildTargetValues.IsConfigEnabled("填充飞机数量"))
            {
                __result.idleDroneCount += NativeInventory.Take(player, 5001, NativeInventory.Missing(__result.workDroneDatas?.Length ?? 0, __result.idleDroneCount, __result.workDroneCount, auto_supply_drone.Value), out _);
            }

            if (BuildTargetValues.IsConfigEnabled("运输机最远路程"))
            {
                __result.tripRangeDrones = Math.Cos(stationdronedist.Value * Math.PI / 180);
            }

            if (BuildTargetValues.IsConfigEnabled("最大充电功率"))
            {
                __instance.planet.factory.powerSystem.consumerPool[__result.pcId].workEnergyPerTick = (long)stationmaxpowerpertick.Value * 16667;
                if (stationmaxpowerpertick.Value > 60 && !__result.isStellar)
                {
                    __instance.planet.factory.powerSystem.consumerPool[__result.pcId].workEnergyPerTick = (long)60 * 16667;
                }
            }

            if (BuildTargetValues.IsConfigEnabled("运输机起送量"))
            {
                __result.deliveryDrones = DroneStartCarry.Value == 0 ? 1 : (int)(DroneStartCarry.Value * 10) * 10;
            }
            if (__result.isStellar)
            {
                if (BuildTargetValues.IsConfigEnabled("翘曲填充数量"))
                {
                    __result.warperCount += NativeInventory.Take(player, 1210, NativeInventory.Missing(int.MaxValue, __result.warperCount, 0, auto_supply_warp.Value), out _);
                }

                if (BuildTargetValues.IsConfigEnabled("曲速启用路程"))
                {
                    __result.warpEnableDist = stationwarpdist.Value * GalaxyData.AU;
                }

                if (BuildTargetValues.IsConfigEnabled("运输船起送量"))
                {
                    __result.deliveryShips = ShipStartCarry.Value == 0 ? 1 : (int)(ShipStartCarry.Value * 10) * 10;
                }

                if (BuildTargetValues.IsConfigEnabled("填充飞船数量"))
                {
                    __result.idleShipCount += NativeInventory.Take(player, 5002, NativeInventory.Missing(Math.Min(64, __result.workShipDatas?.Length ?? 0), __result.idleShipCount, __result.workShipCount, auto_supply_ship.Value), out _);
                }

                if (BuildTargetValues.IsConfigEnabled("运输船最远路程"))
                {
                    __result.tripRangeShips = stationshipdist.Value > 60 ? 24000000000 : stationshipdist.Value * 2400000;
                }

                if (BuildTargetValues.IsConfigEnabled("翘曲填充数量") && GameMain.data.history.TechUnlocked(3404))
                {
                    __result.warperCount += NativeInventory.Take(player, 1210, NativeInventory.Missing(int.MaxValue, __result.warperCount, 0, auto_supply_warp.Value), out _);
                }
            }
        }
        if (auto_supply_station.Value && __result.isVeinCollector)
        {
            if (BuildTargetValues.IsConfigEnabled("大型采矿机采矿速率"))
            {
                __instance.factory.factorySystem.minerPool[__result.minerId].speed = veincollectorspeed.Value * 1000;
            }
        }
    }

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetTransport), "NewDispenserComponent")]
    public static void NewDispenserComponentPatch(int __result, PlanetTransport __instance)
    {
        if (player == null || player.factory != __instance.factory || __result <= 0) return;
        if (autosetCourier_bool.Value)
        {
            if (BuildTargetValues.IsConfigEnabled("填充配送机数量"))
            {
                var dispenser = __instance.dispenserPool[__result];
                dispenser.idleCourierCount += NativeInventory.Take(player, 5003, NativeInventory.Missing(Math.Min(dispenser.workCourierDatas?.Length ?? 0, dispenser.orders?.Length ?? 0), dispenser.idleCourierCount, dispenser.workCourierCount, auto_supply_Courier.Value), out _);
            }
        }
    }

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIBlueprintBrowser), "SetCurrentDirectory")]
	public static void UIBlueprintBrowserSetCurrentDirectory(string fullpath)
	{
		if (AuxConfig.SaveLastOpenBluePrintBrowserPathConfig.Value)
		{
			AuxConfig.LastOpenBluePrintBrowserPathConfig.Value = fullpath;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIBlueprintBrowser), "_OnOpen")]
	public static void UIBlueprintBrowser_OnOpen(ref UIBlueprintBrowser __instance)
	{
		if (AuxConfig.SaveLastOpenBluePrintBrowserPathConfig.Value && string.IsNullOrEmpty(__instance.openPath) && !string.IsNullOrEmpty(AuxConfig.LastOpenBluePrintBrowserPathConfig.Value))
		{
			__instance.openPath = AuxConfig.LastOpenBluePrintBrowserPathConfig.Value;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(BuildingParameters), "CopyFromFactoryObject")]
	public static void CopyFromFactoryObjectPatch(int objectId, PlanetFactory factory)
	{
		if (!AuxConfig.stationcopyItem_bool.Value)
		{
			return;
		}
		if (Auxilaryfunction.player != null && Auxilaryfunction.player.controller != null && Auxilaryfunction.player.controller.actionBuild != null)
		{
			PlayerAction_Build actionBuild = Auxilaryfunction.player.controller.actionBuild;
			if ((actionBuild.blueprintCopyTool != null || actionBuild.blueprintPasteTool != null) && (actionBuild.blueprintPasteTool.active || actionBuild.blueprintCopyTool.active))
			{
				return;
			}
		}
		EntityData[] entityPool = factory.entityPool;
		if (objectId > entityPool.Length || objectId <= 0)
		{
			return;
		}
		int stationId = entityPool[objectId].stationId;
		if (stationId <= 0)
		{
			return;
		}
		StationComponent stationComponent = factory.transport.stationPool[stationId];
		for (int i = 0; i < 5; i++)
		{
			for (int j = 0; j < 6; j++)
			{
				Auxilaryfunction.stationcopyItem[i, j] = 0;
			}
		}
		for (int k = 0; k < stationComponent.storage.Length && k < 5; k++)
		{
			if (stationComponent.storage[k].itemId > 0)
			{
				Auxilaryfunction.stationcopyItem[k, 0] = stationComponent.storage[k].itemId;
				Auxilaryfunction.stationcopyItem[k, 1] = stationComponent.storage[k].max;
				Auxilaryfunction.stationcopyItem[k, 2] = (int)stationComponent.storage[k].localLogic;
				Auxilaryfunction.stationcopyItem[k, 3] = (int)stationComponent.storage[k].remoteLogic;
				Auxilaryfunction.stationcopyItem[k, 4] = stationComponent.storage[k].localOrder;
				Auxilaryfunction.stationcopyItem[k, 5] = stationComponent.storage[k].remoteOrder;
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(BuildTool_Path), "DeterminePreviews")]
	public static void BuildTool_PathPatch(BuildTool_Path __instance)
	{
		if (!AuxConfig.KeepBeltHeight.Value || !Input.GetKey(KeyCode.LeftShift))
		{
			return;
		}
		PlanetAuxData planetAux = Auxilaryfunction.player.controller.actionBuild.planetAux;
		if (planetAux != null && __instance.altitude == 0)
		{
			if (ObjectIsBeltOrSplitter(__instance, __instance.castObjectId))
			{
				__instance.altitude = Altitude(__instance.castObjectPos, planetAux);
			}
			else if (__instance.startObjectId != 0)
			{
				__instance.altitude = Altitude(__instance.pathPoints[0], planetAux);
			}
		}
	}

	private static int Altitude(Vector3 pos, PlanetAuxData aux)
	{
		Vector3 b = aux.Snap(pos, onTerrain: true);
		return (int)Math.Round(Vector3.Distance(pos, b) / 1.3333333f);
	}

	private static bool ObjectIsBeltOrSplitter(BuildTool_Path tool, int objId)
	{
		if (objId == 0)
		{
			return false;
		}
		ItemProto itemProto = LDB.items.Select(tool.factory.entityPool[Math.Abs(objId)].protoId);
		return itemProto != null && itemProto.prefabDesc != null && (itemProto.prefabDesc.isBelt || itemProto.prefabDesc.isSplitter);
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
	public static void PasteToFactoryObjectPatch(int objectId, PlanetFactory factory)
	{
		if (!AuxConfig.stationcopyItem_bool.Value)
		{
			return;
		}
		EntityData[] entityPool = factory.entityPool;
		if (objectId > entityPool.Length || objectId <= 0)
		{
			return;
		}
		int stationId = entityPool[objectId].stationId;
		if (stationId <= 0)
		{
			return;
		}
		StationComponent stationComponent = factory.transport.stationPool[stationId];
		if (stationComponent.isVeinCollector || stationComponent.isCollector)
		{
			return;
		}
		for (int i = 0; i < stationComponent.storage.Length && i < 5; i++)
		{
			if (Auxilaryfunction.stationcopyItem[i, 0] > 0)
			{
				if (stationComponent.storage[i].count > 0 && stationComponent.storage[i].itemId != Auxilaryfunction.stationcopyItem[i, 0])
				{
					Auxilaryfunction.player.TryAddItemToPackage(stationComponent.storage[i].itemId, stationComponent.storage[i].count, 0, throwTrash: false);
				}
				factory.transport.SetStationStorage(stationId, i, Auxilaryfunction.stationcopyItem[i, 0], Auxilaryfunction.stationcopyItem[i, 1], (ELogisticStorage)Auxilaryfunction.stationcopyItem[i, 2], (ELogisticStorage)Auxilaryfunction.stationcopyItem[i, 3], Auxilaryfunction.player);
			}
			else
			{
				factory.transport.SetStationStorage(stationId, i, 0, 0, ELogisticStorage.None, ELogisticStorage.None, Auxilaryfunction.player);
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIVariousPopupCard), "Refresh")]
	public static bool UIVariousPopupCardRefresh(UIVariousPopupCard __instance)
	{
		if (AuxConfig.CloseMilestone.Value && __instance.data is MilestoneProto)
		{
			__instance._Close();
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIGeneralTips), "OnTechUnlocked")]
	public static bool UIGeneralTipsOnTechUnlocked()
	{
		if (AuxConfig.CloseUIGeneralTip.Value)
		{
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIAdvisorTip), "RequestAdvisorTip")]
	public static bool UIAdvisorTipRequestAdvisorTip()
	{
		return !AuxConfig.CloseUIAdvisor.Value;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIRandomTip), "_OnOpen")]
	public static void UIBuildMenu_OnOpenPatch(ref UIRandomTip __instance)
	{
		if (AuxConfig.CloseUIRandomTip.Value)
		{
			__instance._Close();
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UITutorialTip), "PopupTutorialTip")]
	public static bool UITutorialTipPopupTutorialTip()
	{
		if (AuxConfig.CloseUITutorialTip.Value)
		{
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UITechTree), "UpdateScale")]
	public static bool UITechTreeUpdateScalePatch(UITechTree __instance)
	{
		if (AuxConfig.noscaleuitech_bool.Value && (__instance.selected != null || __instance.centerViewNode != null))
		{
			return false;
		}
		return true;
	}
}
