using CommonAPI;
using HarmonyLib;

namespace BlueprintTweaks;

[RegisterPatch("DragRemove")]
public static class PlayerAction_BuildPatch
{
	[HarmonyPatch(typeof(PlayerAction_Build), "Init")]
	[HarmonyPostfix]
	public static void InitTool(PlayerAction_Build __instance)
	{
		BuildTool[] tools = __instance.tools;
		BuildTool[] array = new BuildTool[tools.Length + 1];
		tools.CopyTo(array, 0);
		BlueprintTweaksPlugin.tool = new DragRemoveBuildTool();
		array[^1] = BlueprintTweaksPlugin.tool;
		__instance.tools = array;
	}
}
