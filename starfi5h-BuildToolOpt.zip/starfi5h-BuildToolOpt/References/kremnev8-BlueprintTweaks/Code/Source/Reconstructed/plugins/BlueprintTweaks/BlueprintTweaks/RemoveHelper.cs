using System;
using System.Collections.Generic;
using System.Linq;
using BlueprintTweaks.FactoryUndo;
using BlueprintTweaks.Nebula;
using CommonAPI;
using HarmonyLib;
using NebulaAPI;
using NebulaAPI.GameState;
using UnityEngine;

namespace BlueprintTweaks;

[RegisterPatch("DragRemove")]
public static class RemoveHelper
{
	public static bool excludeStationOverride;

	public static bool ShouldExcludeStations
	{
		get
		{
			if (!excludeStationOverride)
			{
				return BlueprintTweaksPlugin.excludeStations.Value;
			}
			return true;
		}
	}

	private static void GenerateUndoData(PlanetFactory factory, List<int> targetIds)
	{
		if (NebulaModAPI.IsMultiplayerActive && NebulaModAPI.MultiplayerSession.LocalPlayer.IsClient)
		{
			return;
		}
		try
		{
			List<int> objectIds = targetIds.Where(delegate(int objId)
			{
				if (objId < 0)
				{
					int modelIndex = factory.prebuildPool[-objId].modelIndex;
					ModelProto modelProto = LDB.models.Select(modelIndex);
					if (modelProto == null)
					{
						return false;
					}
					if (modelProto.prefabDesc.isStation)
					{
						return !ShouldExcludeStations;
					}
					return true;
				}
				if (objId > 0)
				{
					int modelIndex2 = factory.entityPool[objId].modelIndex;
					ModelProto modelProto2 = LDB.models.Select(modelIndex2);
					if (modelProto2 == null)
					{
						return false;
					}
					if (modelProto2.prefabDesc.isStation)
					{
						return !ShouldExcludeStations;
					}
					return true;
				}
				return false;
			}).ToList();
			Vector3 position;
			BlueprintData blueprintData = UndoUtils.GenerateBlueprint(objectIds, out position);
			if (blueprintData.buildings.Length != 0 && !position.Equals(Vector3.zero))
			{
				PlayerUndo currentPlayerData = UndoManager.GetCurrentPlayerData();
				currentPlayerData.AddUndoItem(new UndoDismantle(currentPlayerData, objectIds, blueprintData, new Vector3[1] { position }, 0f));
			}
		}
		catch (Exception ex)
		{
			BlueprintTweaksPlugin.logger.LogWarning("Failed to generate undo for drag dismantle: " + ex.Message + ", stacktrace:\n" + ex.StackTrace);
		}
	}

	public static void SwitchDelete(PlanetFactory factory, List<int> objectIds)
	{
		if (objectIds.Count <= 0)
		{
			return;
		}
		if (NebulaModAPI.IsMultiplayerActive)
		{
			IMultiplayerSession multiplayerSession = NebulaModAPI.MultiplayerSession;
			int planetId = ((multiplayerSession.Factories.TargetPlanet != -2) ? multiplayerSession.Factories.TargetPlanet : (factory.planet?.id ?? (-1)));
			if (multiplayerSession.LocalPlayer.IsHost || !multiplayerSession.Factories.IsIncomingRequest.Value)
			{
				multiplayerSession.Network.SendPacket<RemoveRequestPacket>(new RemoveRequestPacket(planetId, objectIds.ToArray(), Array.Empty<int>(), (multiplayerSession.Factories.PacketAuthor == -1) ? multiplayerSession.LocalPlayer.Id : multiplayerSession.Factories.PacketAuthor, variant: false, ShouldExcludeStations));
			}
			if (!multiplayerSession.LocalPlayer.IsHost && !multiplayerSession.Factories.IsIncomingRequest.Value)
			{
				return;
			}
		}
		RegularDeleteEntities(factory, objectIds);
	}

	public static void RegularDeleteEntities(PlanetFactory factory, List<int> targetIds)
	{
		PlayerAction_Build actionBuild = GameMain.mainPlayer.controller.actionBuild;
		using (UndoManager.IgnoreAllEvents.On())
		{
			HighStopwatch highStopwatch = new HighStopwatch();
			highStopwatch.Begin();
			foreach (int targetId in targetIds)
			{
				try
				{
					if (!actionBuild.noneTool.GetPrefabDesc(targetId).isStation || !ShouldExcludeStations)
					{
						DoDismantleObject(actionBuild, targetId);
					}
				}
				catch (Exception ex)
				{
					BlueprintTweaksPlugin.logger.LogWarning($"Error while dismantling entity {targetId}, message: {ex.Message}, stacktrace:\n{ex.StackTrace}");
				}
			}
			double duration = highStopwatch.duration;
			BlueprintTweaksPlugin.logger.LogDebug($"Took {duration} s to delete entities");
		}
	}

	[HarmonyPatch(typeof(PlayerAction_Build), "DoDismantleObject")]
	[HarmonyReversePatch(HarmonyReversePatchType.Original)]
	public static bool DoDismantleObject(PlayerAction_Build instance, int objId)
	{
		return true;
	}
}
