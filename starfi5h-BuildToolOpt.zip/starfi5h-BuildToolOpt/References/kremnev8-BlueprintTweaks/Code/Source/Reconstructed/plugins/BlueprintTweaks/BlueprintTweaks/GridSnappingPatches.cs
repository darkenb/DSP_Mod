using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;

namespace BlueprintTweaks;

[HarmonyPatch]
public static class GridSnappingPatches
{
	public static float lockLongitude;

	public static float lockLatitude;

	public static bool isLockedLongitude;

	public static bool isLockedLatitude;

	public static GridData currentGridData = new GridData();

	public static Vector3 GetGroundCastPos()
	{
		if (GameMain.mainPlayer == null)
		{
			return Vector3.zero;
		}
		BuildTool activeTool = GameMain.mainPlayer.controller.actionBuild.activeTool;
		if (activeTool == null || VFInput.onGUI || !VFInput.inScreen)
		{
			return Vector3.zero;
		}
		int layerMask = 8720;
		if (!Physics.Raycast(activeTool.mouseRay, out var hitInfo, 800f, layerMask, QueryTriggerInteraction.Collide))
		{
			return Vector3.zero;
		}
		return hitInfo.point;
	}

	public static void LockLongitude()
	{
		if (!isLockedLongitude)
		{
			Vector3 groundCastPos = GetGroundCastPos();
			if (!groundCastPos.Equals(Vector3.zero))
			{
				BlueprintUtils.GetLongitudeLatitudeRad(groundCastPos.normalized, ref lockLongitude, ref lockLatitude);
				isLockedLongitude = true;
				isLockedLatitude = false;
			}
		}
		else
		{
			isLockedLongitude = false;
		}
	}

	public static void LockLatitude()
	{
		if (!isLockedLatitude)
		{
			Vector3 groundCastPos = GetGroundCastPos();
			if (!groundCastPos.Equals(Vector3.zero))
			{
				BlueprintUtils.GetLongitudeLatitudeRad(groundCastPos.normalized, ref lockLongitude, ref lockLatitude);
				isLockedLatitude = true;
				isLockedLongitude = false;
			}
		}
		else
		{
			isLockedLatitude = false;
		}
	}

	public static void SetOffset()
	{
		if (currentGridData.shouldShap)
		{
			currentGridData.shouldShap = false;
		}
		else if (GameMain.localPlanet.aux != null)
		{
			Vector3 groundCastPos = GetGroundCastPos();
			if (!groundCastPos.Equals(Vector3.zero))
			{
				BlueprintUtils.GetLongitudeLatitudeRad(groundCastPos.normalized, ref lockLongitude, ref lockLatitude);
				currentGridData.shouldShap = true;
				GameMain.localPlanet.aux.CalculateOffset(groundCastPos, currentGridData);
			}
		}
	}

	public static Vector3 SnapModified(this PlanetAuxData auxData, Vector3 pos, bool onTerrain)
	{
		if (auxData.activeGridIndex < auxData.customGrids.Count)
		{
			Vector3 vector = auxData.customGrids[auxData.activeGridIndex].SnapModifiedInternal(pos);
			float num = auxData.planet.realRadius + 0.2f;
			if (!onTerrain)
			{
				num = Mathf.Max(auxData.planet.radius, Mathf.Floor((float)(((double)pos.magnitude - (double)auxData.planet.radius) / 1.33333325386047)) * 1.333333f + auxData.planet.radius) + 0.2f;
			}
			pos = vector * num;
		}
		return pos;
	}

	public static Vector3 SnapModifiedInternal(this PlanetGrid grid, Vector3 pos)
	{
		pos.Normalize();
		float latitudeRad = BlueprintUtils.GetLatitudeRad(pos);
		float longitudeRad = BlueprintUtils.GetLongitudeRad(pos);
		float num = latitudeRad / (MathF.PI * 2f) * (float)grid.segment;
		float num2 = PlanetGrid.DetermineLongitudeSegmentCount(Mathf.FloorToInt(Mathf.Max(0f, Mathf.Abs(num) - 0.1f)), grid.segment);
		float value = longitudeRad / 6.283185f * num2;
		float num3 = SnapWithOffset(num, currentGridData, 1);
		float num4 = SnapWithOffset(value, currentGridData, 0);
		float latitudeRad2 = num3 / (float)grid.segment * (MathF.PI * 2f);
		return BlueprintUtils.GetDir(num4 / num2 * (MathF.PI * 2f), latitudeRad2);
	}

	public static void CalculateOffset(this PlanetAuxData auxData, Vector3 pos, GridData gridData)
	{
		if (auxData.activeGridIndex < auxData.customGrids.Count)
		{
			PlanetGrid planetGrid = auxData.customGrids[auxData.activeGridIndex];
			pos.Normalize();
			float latitudeRad = BlueprintUtils.GetLatitudeRad(pos);
			float longitudeRad = BlueprintUtils.GetLongitudeRad(pos);
			float num = latitudeRad / (MathF.PI * 2f) * (float)planetGrid.segment;
			float num2 = PlanetGrid.DetermineLongitudeSegmentCount(Mathf.FloorToInt(Mathf.Max(0f, Mathf.Abs(num) - 0.1f)), planetGrid.segment);
			float value = longitudeRad / 6.283185f * num2;
			float num3 = Snap(num) * 5f;
			float num4 = Snap(value) * 5f;
			gridData.snapOffset = new Vector2(num4 % gridData.snapGrid.x, num3 % gridData.snapGrid.y);
		}
	}

	public static float Snap(float value)
	{
		return Mathf.Round(value * 5f) / 5f;
	}

	public static float SnapWithOffset(float value, GridData gridData, int index)
	{
		if (!gridData.shouldShap)
		{
			return Snap(value);
		}
		float num = gridData.snapOffset[index];
		return Mathf.Round((value * 5f - num) / gridData.snapGrid[index]) / 5f * gridData.snapGrid[index] + num / 5f;
	}

	[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "_OnClose")]
	[HarmonyPrefix]
	public static void Close()
	{
		if (BlueprintTweaksPlugin.resetFunctionsOnMenuExit.Value)
		{
			isLockedLongitude = false;
			isLockedLatitude = false;
			currentGridData.shouldShap = false;
		}
	}

	[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "UpdateRaycast")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> PasteSnap(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(true, new CodeMatch((CodeInstruction x) => x.IsLdloc()), new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(BuildTool_BlueprintPaste), "castGroundPos"))).Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0))
			.InsertAndAdvance(Transpilers.EmitDelegate<Action<BuildTool_BlueprintPaste>>(delegate(BuildTool_BlueprintPaste tool)
			{
				float x = tool.blueprint.dragBoxSize_x;
				float y = tool.blueprint.dragBoxSize_y;
				currentGridData.snapGrid = new Vector2(x, y);
				float _longitude = 0f;
				float _latitude = 0f;
				BlueprintUtils.GetLongitudeLatitudeRad(tool.castGroundPos.normalized, ref _longitude, ref _latitude);
				if (isLockedLongitude)
				{
					_longitude = lockLongitude;
				}
				if (isLockedLatitude)
				{
					_latitude = lockLatitude;
				}
				tool.castGroundPos = BlueprintUtils.GetDir(_longitude, _latitude) * tool.castGroundPos.magnitude;
			}));
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(PlanetAuxData), "Snap", new Type[2]
		{
			typeof(Vector3),
			typeof(bool)
		}))).SetInstruction(new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(GridSnappingPatches), "SnapModified")));
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(BuildTool_Click), "UpdateRaycast")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> ClickSnap(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(true, new CodeMatch((CodeInstruction x) => x.IsLdloc()), new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(BuildTool_Click), "castGroundPos"))).Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0))
			.InsertAndAdvance(Transpilers.EmitDelegate<Action<BuildTool_Click>>(delegate(BuildTool_Click tool)
			{
				currentGridData.snapGrid = tool.handPrefabDesc.blueprintBoxSize;
				currentGridData.snapGrid.x = Mathf.Round(currentGridData.snapGrid.x);
				currentGridData.snapGrid.y = Mathf.Round(currentGridData.snapGrid.y);
				float _longitude = 0f;
				float _latitude = 0f;
				BlueprintUtils.GetLongitudeLatitudeRad(tool.castGroundPos.normalized, ref _longitude, ref _latitude);
				if (isLockedLongitude)
				{
					_longitude = lockLongitude;
				}
				if (isLockedLatitude)
				{
					_latitude = lockLatitude;
				}
				tool.castGroundPos = BlueprintUtils.GetDir(_longitude, _latitude) * tool.castGroundPos.magnitude;
			}));
		MethodInfo operand = AccessTools.Method(typeof(PlanetAuxData), "Snap", new Type[2]
		{
			typeof(Vector3),
			typeof(bool)
		});
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Callvirt, operand)).Repeat(delegate(CodeMatcher codeMatcher2)
		{
			codeMatcher2.SetInstruction(new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(GridSnappingPatches), "SnapModified")));
		});
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(BuildTool_Reform), "UpdateRaycastAndReform")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> ClickReform(IEnumerable<CodeInstruction> instructions)
	{
		return new CodeMatcher(instructions).MatchForward(true, new CodeMatch((CodeInstruction x) => x.IsLdloc()), new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(BuildTool_Reform), "castGroundPos"))).Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0))
			.InsertAndAdvance(Transpilers.EmitDelegate<Action<BuildTool_Reform>>(delegate(BuildTool_Reform tool)
			{
				currentGridData.snapGrid = new Vector2(tool.brushSize, tool.brushSize);
				float _longitude = 0f;
				float _latitude = 0f;
				BlueprintUtils.GetLongitudeLatitudeRad(tool.castGroundPos.normalized, ref _longitude, ref _latitude);
				if (isLockedLongitude)
				{
					_longitude = lockLongitude;
				}
				if (isLockedLatitude)
				{
					_latitude = lockLatitude;
				}
				tool.castGroundPos = BlueprintUtils.GetDir(_longitude, _latitude) * tool.castGroundPos.magnitude;
			}))
			.InstructionEnumeration();
	}
}
