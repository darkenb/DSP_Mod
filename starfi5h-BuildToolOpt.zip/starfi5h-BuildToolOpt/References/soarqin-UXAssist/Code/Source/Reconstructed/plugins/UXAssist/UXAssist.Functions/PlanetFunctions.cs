using System;
using System.Collections.Generic;
using System.IO;
using System.Threading;
using BepInEx.Configuration;
using UnityEngine;

namespace UXAssist.Functions;

public static class PlanetFunctions
{
	public static ConfigEntry<int> OrbitalCollectorMaxBuildCount;

	public static ConfigEntry<bool> ReturnBuildingsOnInitializeEnabled;

	public static ConfigEntry<bool> ReturnLogisticStorageItemsOnInitializeEnabled;

	public static ConfigEntry<bool> ReturnBeltAFactoryItemsOnInitializeEnabled;

	private const int OrbitalCollectorItemId = 2105;

	public static void DismantleAll(bool toBag)
	{
		Player mainPlayer = GameMain.mainPlayer;
		if (mainPlayer == null)
		{
			return;
		}
		PlanetFactory planetFactory = GameMain.localPlanet?.factory;
		if (planetFactory == null)
		{
			return;
		}
		EntityData[] entityPool = planetFactory.entityPool;
		for (int i = 0; i < entityPool.Length; i++)
		{
			EntityData entityData = entityPool[i];
			if (entityData.id == 0)
			{
				continue;
			}
			int stationId = entityData.stationId;
			if (stationId > 0)
			{
				StationComponent stationComponent = GameMain.localPlanet.factory.transport.stationPool[stationId];
				if (stationComponent == null || stationComponent.id != stationId)
				{
					continue;
				}
				if (toBag)
				{
					for (int num = stationComponent.storage.Length - 1; num >= 0; num--)
					{
						int num2 = mainPlayer.TryAddItemToPackage(stationComponent.storage[num].itemId, stationComponent.storage[num].count, stationComponent.storage[num].inc, throwTrash: true, entityData.id);
						if (num2 > 0)
						{
							UIItemup.Up(stationComponent.storage[num].itemId, num2);
						}
						stationComponent.storage[num].count = 0;
					}
				}
				else
				{
					for (int num3 = stationComponent.storage.Length - 1; num3 >= 0; num3--)
					{
						stationComponent.storage[num3].count = 0;
					}
				}
			}
			if (toBag)
			{
				int protoId = 0;
				planetFactory.DismantleFinally(mainPlayer, entityData.id, ref protoId);
				continue;
			}
			int id = entityData.id;
			planetFactory.BeforeDismantleObject(id);
			planetFactory.RemoveEntityWithComponents(id, returnItems: false);
			planetFactory.OnDismantleObject(id);
		}
	}

	public static void RecreatePlanet(bool revertReform)
	{
		Player mainPlayer = GameMain.mainPlayer;
		if (mainPlayer == null)
		{
			return;
		}
		PlanetData localPlanet = GameMain.localPlanet;
		PlanetFactory planetFactory = localPlanet?.factory;
		if (planetFactory == null)
		{
			return;
		}
		UIGame uiGame = UIRoot.instance.uiGame;
		if ((bool)uiGame)
		{
			uiGame.ShutAllFunctionWindow();
			uiGame.ShutAllFullScreens();
		}
		mainPlayer.controller.actionBuild.Close();
		CombatModuleComponent groundCombatModule = mainPlayer.mecha.groundCombatModule;
		for (int num = groundCombatModule.moduleFleets.Length - 1; num >= 0; num--)
		{
			ModuleFleet moduleFleet = groundCombatModule.moduleFleets[num];
			if (moduleFleet.fleetId > 0 && moduleFleet.fleetEnabled)
			{
				moduleFleet.fleetEnabled = false;
				groundCombatModule.RemoveFleetDirectly(num);
			}
		}
		ConstructionSystem constructionSystem = planetFactory.constructionSystem;
		ConstructionModuleComponent constructionModule = mainPlayer.mecha.constructionModule;
		for (int num2 = constructionSystem.drones.cursor - 1; num2 > 0; num2--)
		{
			ref DroneComponent reference = ref constructionSystem.drones.buffer[num2];
			if (reference.id > 0)
			{
				int owner = reference.owner;
				constructionSystem.ResetDroneTargets(ref reference);
				if (owner == 0)
				{
					planetFactory.RemoveCraftWithComponents(reference.craftId);
					constructionModule.droneIdleCount++;
				}
				else
				{
					reference.movement = planetFactory.gameData.history.constructionDroneMovement;
					planetFactory.craftPool[reference.craftId].pos = constructionSystem.constructionModules[owner].baseEjectPos;
					constructionSystem.constructionModules[owner].droneIdleCount++;
				}
			}
		}
		if (constructionSystem.constructStats?.buffer != null)
		{
			for (int num3 = constructionSystem.constructStats.cursor - 1; num3 > 0; num3--)
			{
				ref ConstructStat reference2 = ref constructionSystem.constructStats.buffer[num3];
				if (reference2.id > 0)
				{
					constructionSystem.RemoveConstructStat(reference2.id);
				}
			}
		}
		constructionModule.autoReconstructTargetTotalCount = 0;
		constructionModule.buildTargetTotalCount = 0;
		constructionModule.repairTargetTotalCount = 0;
		constructionModule.autoReconstructTargets = null;
		constructionModule.buildTargets = null;
		constructionModule.repairTargets = null;
		constructionModule.tmpTargets = null;
		constructionModule.tmpTargetsHash = null;
		constructionModule.checkItemCursor = 0;
		GameData data = GameMain.data;
		bool value = ReturnBuildingsOnInitializeEnabled.Value;
		bool value2 = ReturnLogisticStorageItemsOnInitializeEnabled.Value;
		bool value3 = ReturnBeltAFactoryItemsOnInitializeEnabled.Value;
		Dictionary<int, (long, int)> dictionary = new Dictionary<int, (long, int)>();
		if (value || value3)
		{
			FactoryStorage factoryStorage = planetFactory.factoryStorage;
			FactorySystem factorySystem = planetFactory.factorySystem;
			PlanetTransport transport = planetFactory.transport;
			DefenseSystem defenseSystem = planetFactory.defenseSystem;
			PowerSystem powerSystem = planetFactory.powerSystem;
			CargoTraffic cargoTraffic = planetFactory.cargoTraffic;
			for (int num4 = planetFactory.entityCursor - 1; num4 > 0; num4--)
			{
				ref EntityData reference3 = ref planetFactory.entityPool[num4];
				if (reference3.id == num4 && reference3.protoId > 0)
				{
					if (value)
					{
						AddReturnedItem(reference3.protoId, 1, 0, dictionary);
					}
					if (value3)
					{
						int storageId = reference3.storageId;
						if (storageId > 0)
						{
							StorageComponent storageComponent = factoryStorage.storagePool[storageId];
							if (storageComponent != null)
							{
								for (int num5 = storageComponent.size - 1; num5 >= 0; num5--)
								{
									int count = storageComponent.grids[num5].count;
									if (count > 0)
									{
										AddReturnedItem(storageComponent.grids[num5].itemId, count, storageComponent.grids[num5].inc, dictionary);
									}
								}
							}
						}
						int tankId = reference3.tankId;
						if (tankId > 0)
						{
							ref TankComponent reference4 = ref factoryStorage.tankPool[tankId];
							int fluidId = reference4.fluidId;
							int fluidCount = reference4.fluidCount;
							if (fluidId > 0 && fluidCount > 0)
							{
								AddReturnedItem(fluidId, fluidCount, reference4.fluidInc, dictionary);
							}
						}
						int minerId = reference3.minerId;
						if (minerId > 0)
						{
							ref MinerComponent reference5 = ref factorySystem.minerPool[minerId];
							int productId = reference5.productId;
							int productCount = reference5.productCount;
							if (productId > 0 && productCount > 0)
							{
								AddReturnedItem(productId, productCount, 0, dictionary);
							}
						}
						int inserterId = reference3.inserterId;
						if (inserterId > 0)
						{
							ref InserterComponent reference6 = ref factorySystem.inserterPool[inserterId];
							int itemId = reference6.itemId;
							short itemCount = reference6.itemCount;
							if (itemId > 0 && itemCount > 0)
							{
								AddReturnedItem(itemId, itemCount, reference6.itemInc, dictionary);
							}
						}
						int assemblerId = reference3.assemblerId;
						if (assemblerId > 0)
						{
							ref AssemblerComponent reference7 = ref factorySystem.assemblerPool[assemblerId];
							if (reference7.recipeId > 0)
							{
								int[] products = reference7.recipeExecuteData.products;
								int[] requires = reference7.recipeExecuteData.requires;
								int[] requireCounts = reference7.recipeExecuteData.requireCounts;
								for (int num6 = products.Length - 1; num6 >= 0; num6--)
								{
									int itemId2 = products[num6];
									int num7 = reference7.produced[num6];
									if (num7 > 0)
									{
										AddReturnedItem(itemId2, num7, 0, dictionary);
									}
								}
								for (int num8 = requires.Length - 1; num8 >= 0; num8--)
								{
									int itemId3 = requires[num8];
									int num9 = reference7.served[num8];
									int num10 = reference7.incServed[num8];
									if (num10 > num9 * 10)
									{
										num10 = num9 * 10;
									}
									if (reference7.replicating)
									{
										num9 += requireCounts[num8];
									}
									if (num9 > 0)
									{
										AddReturnedItem(itemId3, num9, num10, dictionary);
									}
								}
							}
						}
						int fractionatorId = reference3.fractionatorId;
						if (fractionatorId > 0)
						{
							ref FractionatorComponent reference8 = ref factorySystem.fractionatorPool[fractionatorId];
							int fluidId2 = reference8.fluidId;
							int fluidInputCount = reference8.fluidInputCount;
							if (fluidInputCount > 0)
							{
								AddReturnedItem(fluidId2, fluidInputCount, reference8.fluidInputInc, dictionary);
							}
							int fluidOutputCount = reference8.fluidOutputCount;
							if (fluidOutputCount > 0)
							{
								AddReturnedItem(fluidId2, fluidOutputCount, reference8.fluidOutputInc, dictionary);
							}
							int productOutputCount = reference8.productOutputCount;
							if (productOutputCount > 0)
							{
								AddReturnedItem(reference8.productId, productOutputCount, 0, dictionary);
							}
						}
						int ejectorId = reference3.ejectorId;
						if (ejectorId > 0)
						{
							ref EjectorComponent reference9 = ref factorySystem.ejectorPool[ejectorId];
							int bulletCount = reference9.bulletCount;
							if (bulletCount > 0)
							{
								AddReturnedItem(reference9.bulletId, bulletCount, reference9.bulletInc, dictionary);
							}
						}
						int siloId = reference3.siloId;
						if (siloId > 0)
						{
							ref SiloComponent reference10 = ref factorySystem.siloPool[siloId];
							int bulletCount2 = reference10.bulletCount;
							if (bulletCount2 > 0)
							{
								AddReturnedItem(reference10.bulletId, bulletCount2, reference10.bulletInc, dictionary);
							}
						}
						int labId = reference3.labId;
						if (labId > 0)
						{
							ref LabComponent reference11 = ref factorySystem.labPool[labId];
							if (reference11.recipeId > 0)
							{
								int[] products2 = reference11.recipeExecuteData.products;
								int[] requires2 = reference11.recipeExecuteData.requires;
								int[] requireCounts2 = reference11.recipeExecuteData.requireCounts;
								for (int num11 = products2.Length - 1; num11 >= 0; num11--)
								{
									int num12 = reference11.produced[num11];
									if (num12 > 0)
									{
										AddReturnedItem(products2[num11], num12, 0, dictionary);
									}
								}
								for (int num13 = requires2.Length - 1; num13 >= 0; num13--)
								{
									int num14 = reference11.served[num13];
									int num15 = reference11.incServed[num13];
									if (num15 > num14 * 10)
									{
										num15 = num14 * 10;
									}
									if (reference11.replicating)
									{
										num14 += requireCounts2[num13];
									}
									if (num14 > 0)
									{
										AddReturnedItem(requires2[num13], num14, num15, dictionary);
									}
								}
							}
							if (reference11.researchMode && reference11.matrixServed != null)
							{
								for (int num16 = reference11.matrixServed.Length - 1; num16 >= 0; num16--)
								{
									int num17 = reference11.matrixServed[num16] / 3600;
									if (num17 > 0)
									{
										AddReturnedItem(LabComponent.matrixIds[num16], num17, reference11.matrixIncServed[num16] / 3600, dictionary);
									}
								}
							}
						}
						int dispenserId = reference3.dispenserId;
						if (dispenserId > 0)
						{
							DispenserComponent dispenserComponent = transport.dispenserPool[dispenserId];
							DispenserStore[] holdupPackage = dispenserComponent.holdupPackage;
							for (int num18 = holdupPackage.Length - 1; num18 >= 0; num18--)
							{
								int count2 = holdupPackage[num18].count;
								if (count2 > 0)
								{
									AddReturnedItem(holdupPackage[num18].itemId, count2, holdupPackage[num18].inc, dictionary);
								}
							}
							int num19 = dispenserComponent.idleCourierCount + dispenserComponent.workCourierCount;
							if (num19 > 0)
							{
								AddReturnedItem(5003, num19, 0, dictionary);
							}
						}
						int turretId = reference3.turretId;
						if (turretId > 0)
						{
							ref TurretComponent reference12 = ref defenseSystem.turrets.buffer[turretId];
							short itemCount2 = reference12.itemCount;
							if (itemCount2 > 0)
							{
								AddReturnedItem(reference12.itemId, itemCount2, reference12.itemInc, dictionary);
							}
						}
						int battleBaseId = reference3.battleBaseId;
						if (battleBaseId > 0)
						{
							CombatModuleComponent combatModule = defenseSystem.battleBases.buffer[battleBaseId].combatModule;
							if (combatModule != null && combatModule.moduleFleets[0].fleetId <= 0)
							{
								ModuleFighter[] fighters = combatModule.moduleFleets[0].fighters;
								for (int num20 = fighters.Length - 1; num20 >= 0; num20--)
								{
									int itemId4 = fighters[num20].itemId;
									int count3 = fighters[num20].count;
									if (itemId4 > 0 && count3 > 0)
									{
										AddReturnedItem(itemId4, count3, 0, dictionary);
									}
								}
							}
						}
						int powerGenId = reference3.powerGenId;
						if (powerGenId > 0)
						{
							ref PowerGeneratorComponent reference13 = ref powerSystem.genPool[powerGenId];
							if (reference13.fuelId > 0 && reference13.fuelCount > 0)
							{
								AddReturnedItem(reference13.fuelId, reference13.fuelCount, reference13.fuelInc, dictionary);
							}
							if (reference13.gamma)
							{
								int productId2 = reference13.productId;
								int num21 = (int)reference13.productCount;
								if (productId2 != 0 && num21 > 0)
								{
									AddReturnedItem(productId2, num21, 0, dictionary);
								}
								int catalystId = reference13.catalystId;
								if (catalystId != 0 && reference13.catalystCount > 0)
								{
									AddReturnedItem(catalystId, reference13.catalystCount, reference13.catalystInc, dictionary);
								}
							}
						}
						int powerExcId = reference3.powerExcId;
						if (powerExcId > 0)
						{
							ref PowerExchangerComponent reference14 = ref powerSystem.excPool[powerExcId];
							int emptyCount = reference14.emptyCount;
							if (emptyCount > 0)
							{
								AddReturnedItem(reference14.emptyId, emptyCount, reference14.emptyInc, dictionary);
							}
							int fullCount = reference14.fullCount;
							if (fullCount > 0)
							{
								AddReturnedItem(reference14.fullId, fullCount, reference14.fullInc, dictionary);
							}
						}
						int spraycoaterId = reference3.spraycoaterId;
						if (spraycoaterId > 0)
						{
							ref SpraycoaterComponent reference15 = ref cargoTraffic.spraycoaterPool[spraycoaterId];
							if (reference15.incItemId != 0 && reference15.incCount != 0)
							{
								ItemProto itemProto = LDB.items.Select(reference15.incItemId);
								int num22 = reference15.incCount / itemProto.HpMax;
								if (num22 != 0)
								{
									AddReturnedItem(reference15.incItemId, num22, 0, dictionary);
								}
							}
						}
						int pilerId = reference3.pilerId;
						if (pilerId > 0)
						{
							ref PilerComponent reference16 = ref cargoTraffic.pilerPool[pilerId];
							int cacheCargoStack = reference16.cacheCargoStack1;
							if (cacheCargoStack > 0)
							{
								AddReturnedItem(reference16.cacheItemId1, cacheCargoStack, reference16.cacheCargoInc1, dictionary);
							}
							int cacheCargoStack2 = reference16.cacheCargoStack2;
							if (cacheCargoStack2 > 0)
							{
								AddReturnedItem(reference16.cacheItemId2, cacheCargoStack2, reference16.cacheCargoInc2, dictionary);
							}
						}
					}
				}
			}
			if (value3)
			{
				for (int num23 = cargoTraffic.pathCursor - 1; num23 > 0; num23--)
				{
					CargoPath cargoPath = cargoTraffic.pathPool[num23];
					if (cargoPath != null)
					{
						int num24 = cargoPath.bufferLength - 5;
						byte[] buffer = cargoPath.buffer;
						int num25 = 0;
						while (num25 <= num24)
						{
							if (buffer[num25] >= 246)
							{
								int num26 = 250 - buffer[num25];
								if (num26 > 0)
								{
									num25 += num26;
								}
								int num27 = buffer[num25 + 1] - 1 + (buffer[num25 + 2] - 1) * 100 + (buffer[num25 + 3] - 1) * 10000 + (buffer[num25 + 4] - 1) * 1000000;
								ref Cargo reference17 = ref cargoPath.cargoContainer.cargoPool[num27];
								byte stack = reference17.stack;
								if (stack > 0)
								{
									AddReturnedItem(reference17.item, stack, reference17.inc, dictionary);
								}
								num25 += 10;
							}
							else
							{
								num25 += 5;
								if (num25 > num24 && num25 < num24 + 5)
								{
									num25 = num24;
								}
							}
						}
					}
				}
			}
		}
		StationComponent[] array = planetFactory.transport?.stationPool;
		if (array != null)
		{
			GalacticTransport galacticTransport = data.galacticTransport;
			for (int num28 = planetFactory.transport.stationCursor - 1; num28 > 0; num28--)
			{
				StationComponent stationComponent = array[num28];
				if (stationComponent != null && stationComponent.id == num28)
				{
					if (value2)
					{
						for (int num29 = stationComponent.storage.Length - 1; num29 >= 0; num29--)
						{
							int count4 = stationComponent.storage[num29].count;
							if (count4 > 0)
							{
								AddReturnedItem(stationComponent.storage[num29].itemId, count4, stationComponent.storage[num29].inc, dictionary);
							}
						}
						int num30 = stationComponent.idleDroneCount + stationComponent.workDroneCount;
						if (num30 > 0)
						{
							AddReturnedItem(5001, num30, 0, dictionary);
						}
						int num31 = stationComponent.idleShipCount + stationComponent.workShipCount;
						if (num31 > 0)
						{
							AddReturnedItem(5002, num31, 0, dictionary);
						}
						int warperCount = stationComponent.warperCount;
						if (warperCount > 0)
						{
							AddReturnedItem(1210, warperCount, 0, dictionary);
						}
					}
					int gid = stationComponent.gid;
					if (galacticTransport.stationPool[gid] != null)
					{
						galacticTransport.stationPool[gid] = null;
						int num32 = galacticTransport.stationRecycleCursor++;
						galacticTransport.stationRecycle[num32] = gid;
					}
					galacticTransport.RemoveStation2StationRoute(gid);
					galacticTransport.RefreshTraffic(gid);
					stationComponent.Reset();
				}
			}
			if (galacticTransport.OnStellarStationRemoved != null)
			{
				galacticTransport.OnStellarStationRemoved();
			}
		}
		PlanetPhysics physics = localPlanet.physics;
		GPUInstancingManager gpuiManager = GameMain.gpuiManager;
		MiniBlockContainer blockContainer = planetFactory.blockContainer;
		PlanetAudio audio = localPlanet.audio;
		for (int num33 = planetFactory.entityCursor - 1; num33 > 0; num33--)
		{
			ref EntityData reference18 = ref planetFactory.entityPool[num33];
			if (reference18.id == num33)
			{
				planetFactory.BeforeDismantleObject(num33);
				if (reference18.colliderId != 0)
				{
					physics.RemoveLinkedColliderData(reference18.colliderId);
					physics.NotifyObjectRemove(EObjectType.None, reference18.id);
				}
				if (reference18.modelId != 0)
				{
					gpuiManager.RemoveModel(reference18.modelIndex, reference18.modelId);
				}
				if (reference18.mmblockId != 0)
				{
					blockContainer.RemoveMiniBlock(reference18.mmblockId);
				}
				if (reference18.audioId != 0)
				{
					audio.RemoveAudioData(reference18.audioId);
				}
				planetFactory.OnDismantleObject(num33);
			}
		}
		for (int num34 = planetFactory.prebuildCursor - 1; num34 > 0; num34--)
		{
			ref PrebuildData reference19 = ref planetFactory.prebuildPool[num34];
			if (reference19.id == num34)
			{
				if (reference19.colliderId != 0)
				{
					physics.RemoveLinkedColliderData(reference19.colliderId);
				}
				if (reference19.modelId != 0)
				{
					gpuiManager.RemovePrebuildModel(reference19.modelIndex, reference19.modelId);
				}
			}
		}
		EnemyDFHiveSystem[] array2 = GameMain.spaceSector?.dfHives;
		if (array2 != null)
		{
			EnemyDFHiveSystem enemyDFHiveSystem = array2[localPlanet.star.index];
			DFRelayComponent[] array3 = enemyDFHiveSystem?.relays?.buffer;
			if (array3 != null)
			{
				int astroId = localPlanet.astroId;
				for (int num35 = array3.Length - 1; num35 >= 0; num35--)
				{
					DFRelayComponent dFRelayComponent = array3[num35];
					if (dFRelayComponent != null && dFRelayComponent.id == num35 && (dFRelayComponent.targetAstroId == astroId || dFRelayComponent.searchAstroId == astroId))
					{
						dFRelayComponent.targetAstroId = 0;
						dFRelayComponent.searchAstroId = 0;
						if (dFRelayComponent.baseId > 0)
						{
							enemyDFHiveSystem.relayNeutralizedCounter++;
						}
						dFRelayComponent.LeaveBase();
					}
				}
			}
		}
		if (planetFactory.enemyPool != null)
		{
			for (int num36 = planetFactory.enemyCursor - 1; num36 > 0; num36--)
			{
				ref EnemyData reference20 = ref planetFactory.enemyPool[num36];
				if (reference20.id == num36)
				{
					int combatStatId = reference20.combatStatId;
					planetFactory.skillSystem.OnRemovingSkillTarget(combatStatId, planetFactory.skillSystem.combatStats.buffer[combatStatId].originAstroId, ETargetType.CombatStat);
					planetFactory.skillSystem.combatStats.Remove(combatStatId);
					planetFactory.KillEnemyFinally(num36, ref CombatStat.empty);
				}
			}
			planetFactory.enemySystem.Free();
			UIRoot.instance.uiGame.dfAssaultTip.ClearAllSpots();
		}
		int id = localPlanet.id;
		GameScenarioLogic gameScenario = GameMain.gameScenario;
		if (gameScenario != null)
		{
			PowerGeneratorComponent[] array4 = planetFactory.powerSystem?.genPool;
			if (array4 != null)
			{
				PowerGeneratorComponent[] array5 = array4;
				for (int i = 0; i < array5.Length; i++)
				{
					PowerGeneratorComponent powerGeneratorComponent = array5[i];
					if (powerGeneratorComponent.id > 0)
					{
						int protoId = planetFactory.entityPool[powerGeneratorComponent.entityId].protoId;
						gameScenario.achievementLogic.NotifyBeforeDismantleEntity(id, protoId, powerGeneratorComponent.entityId);
						gameScenario.NotifyOnDismantleEntity(id, protoId, powerGeneratorComponent.entityId);
					}
				}
			}
		}
		if (revertReform)
		{
			planetFactory.PlanetReformRevert();
		}
		localPlanet.UnloadFactory();
		int index = planetFactory.index;
		WarningSystem warningSystem = data.warningSystem;
		WarningData[] warningPool = warningSystem.warningPool;
		for (int num37 = warningSystem.warningCursor - 1; num37 >= 0; num37--)
		{
			ref WarningData reference21 = ref warningPool[num37];
			if (reference21.id == num37)
			{
				int i = reference21.factoryId;
				if (i < 0)
				{
					if (i == -4 && reference21.astroId == id)
					{
						warningSystem.RemoveWarningData(num37);
					}
				}
				else if (reference21.factoryId == index)
				{
					warningSystem.RemoveWarningData(num37);
				}
			}
		}
		bool isCombatMode = planetFactory.gameData.gameDesc.isCombatMode;
		planetFactory.entityCursor = 1;
		planetFactory.entityRecycleCursor = 0;
		planetFactory.entityCapacity = 0;
		planetFactory.SetEntityCapacity(1024);
		planetFactory.craftCursor = 1;
		planetFactory.craftRecycleCursor = 0;
		planetFactory.craftCapacity = 0;
		planetFactory.SetCraftCapacity(128);
		planetFactory.prebuildCursor = 1;
		planetFactory.prebuildRecycleCursor = 0;
		planetFactory.prebuildCapacity = 0;
		planetFactory.SetPrebuildCapacity(256);
		planetFactory.enemyCursor = 1;
		planetFactory.enemyRecycleCursor = 0;
		planetFactory.enemyCapacity = 0;
		planetFactory.SetEnemyCapacity(isCombatMode ? 1024 : 32);
		planetFactory.hashSystemDynamic = new HashSystem();
		planetFactory.hashSystemStatic = new HashSystem();
		planetFactory.cargoContainer = new CargoContainer();
		planetFactory.cargoTraffic = new CargoTraffic(localPlanet);
		planetFactory.blockContainer = new MiniBlockContainer();
		planetFactory.factoryStorage = new FactoryStorage(localPlanet);
		planetFactory.powerSystem = new PowerSystem(localPlanet);
		planetFactory.constructionSystem = new ConstructionSystem(localPlanet);
		if (planetFactory.veinPool != null)
		{
			for (int num38 = planetFactory.veinPool.Length - 1; num38 >= 0; num38--)
			{
				ref VeinData reference22 = ref planetFactory.veinPool[num38];
				if (reference22.id == num38)
				{
					reference22.minerCount = 0;
					reference22.minerId0 = 0;
					reference22.minerId1 = 0;
					reference22.minerId2 = 0;
					reference22.minerId3 = 0;
				}
			}
		}
		planetFactory.InitVeinHashAddress();
		planetFactory.RecalculateAllVeinGroups();
		planetFactory.InitVegeHashAddress();
		planetFactory.ruinCursor = 1;
		planetFactory.ruinRecycleCursor = 0;
		planetFactory.ruinCapacity = 0;
		planetFactory.SetRuinCapacity(isCombatMode ? 1024 : 32);
		planetFactory.factorySystem = new FactorySystem(localPlanet);
		planetFactory.enemySystem = new EnemyDFGroundSystem(localPlanet);
		planetFactory.combatGroundSystem = new CombatGroundSystem(localPlanet);
		planetFactory.defenseSystem = new DefenseSystem(localPlanet);
		planetFactory.planetATField = new PlanetATField(localPlanet);
		planetFactory.transport = new PlanetTransport(data, localPlanet);
		planetFactory.transport.Init();
		planetFactory.RefreshHashSystems();
		MemoryStream memoryStream = new MemoryStream();
		BinaryWriter w = new BinaryWriter(memoryStream);
		planetFactory.platformSystem.Export(w);
		planetFactory.platformSystem = new PlatformSystem(localPlanet, import: true);
		memoryStream.Position = 0L;
		BinaryReader r = new BinaryReader(memoryStream);
		planetFactory.platformSystem.Import(r);
		memoryStream.Close();
		memoryStream.Dispose();
		planetFactory.digitalSystem = new DigitalSystem(localPlanet);
		localPlanet.LoadFactory();
		while (!localPlanet.factoryLoaded)
		{
			PlanetModelingManager.Update();
			Thread.Sleep(0);
		}
		foreach (KeyValuePair<int, (long, int)> item in dictionary)
		{
			int num39 = mainPlayer.TryAddItemToPackage(item.Key, (int)item.Value.Item1, item.Value.Item2, throwTrash: true);
			if (num39 > 0)
			{
				UIItemup.Up(item.Key, num39);
			}
		}
		static void AddReturnedItem(int key, int num40, int inc, Dictionary<int, (long count, int inc)> returnedItems)
		{
			if (returnedItems.TryGetValue(key, out (long, int) value4))
			{
				returnedItems[key] = (value4.Item1 + num40, value4.Item2 + inc);
			}
			else
			{
				returnedItems[key] = (num40, inc);
			}
		}
	}

	public static void BuildOrbitalCollectors()
	{
		Player mainPlayer = GameMain.mainPlayer;
		if (mainPlayer == null)
		{
			return;
		}
		PlanetData localPlanet = GameMain.localPlanet;
		if (localPlanet == null || localPlanet.type != EPlanetType.Gas)
		{
			return;
		}
		int num = OrbitalCollectorMaxBuildCount.Value;
		if (num == 0)
		{
			num = -1;
		}
		PlanetFactory factory = localPlanet.factory;
		StationComponent[] stationPool = factory.transport.stationPool;
		int stationCursor = factory.transport.stationCursor;
		EntityData[] entityPool = factory.entityPool;
		Vector3 vector = new Vector3(0f, 0f, localPlanet.realRadius * 1.025f + 0.2f);
		bool flag = false;
		for (int num2 = stationCursor - 1; num2 > 0; num2--)
		{
			if (stationPool[num2] != null && stationPool[num2].id == num2)
			{
				vector = entityPool[stationPool[num2].entityId].pos;
				flag = true;
				break;
			}
		}
		int prebuildCursor = factory.prebuildCursor;
		PrebuildData[] prebuildPool = factory.prebuildPool;
		if (!flag)
		{
			for (int num3 = prebuildCursor - 1; num3 > 0; num3--)
			{
				if (prebuildPool[num3].id == num3)
				{
					vector = prebuildPool[num3].pos;
					break;
				}
			}
		}
		Vector3 vector2 = vector;
		int num4 = PlanetGrid.DetermineLongitudeSegmentCount(0, factory.planet.aux.mainGrid.segment) * 5;
		double num5 = Math.PI / (double)num4;
		int num6 = 1;
		for (int i = 1; i <= num4; i++)
		{
			vector2 = Maths.RotateLF(0.0, 1.0, 0.0, num5, vector2);
			if (!((vector2 - vector).sqrMagnitude < 14297f))
			{
				num6 = i;
				break;
			}
		}
		int num7 = 0;
		while (num7 < num4 && num != 0)
		{
			bool flag2 = false;
			for (int num8 = stationCursor - 1; num8 > 0; num8--)
			{
				if (stationPool[num8] != null && stationPool[num8].id == num8 && !((entityPool[stationPool[num8].entityId].pos - vector).sqrMagnitude >= 14297f))
				{
					flag2 = true;
					break;
				}
			}
			for (int j = 1; j < prebuildCursor; j++)
			{
				if (prebuildPool[j].id == j && !((prebuildPool[j].pos - vector).sqrMagnitude >= 14297f))
				{
					flag2 = true;
					break;
				}
			}
			if (flag2)
			{
				vector = Maths.RotateLF(0.0, 1.0, 0.0, num5, vector);
				num7++;
				continue;
			}
			int inc;
			if (mainPlayer.inhandItemId == 2105 && mainPlayer.inhandItemCount > 0)
			{
				mainPlayer.UseHandItems(1, out inc);
			}
			else
			{
				int count = 1;
				int itemId = 2105;
				mainPlayer.package.TakeTailItems(ref itemId, ref count, out inc);
				if (count == 0)
				{
					break;
				}
			}
			Quaternion quaternion = Maths.SphericalRotation(vector, 0f);
			PrebuildData prebuild = new PrebuildData
			{
				protoId = 2105,
				modelIndex = 117,
				pos = vector,
				pos2 = vector,
				rot = quaternion,
				rot2 = quaternion,
				pickOffset = 0,
				insertOffset = 0,
				recipeId = 0,
				filterId = 0,
				paramCount = 0
			};
			factory.AddPrebuildDataWithComponents(prebuild);
			prebuildCursor = factory.prebuildCursor;
			if (num > 0)
			{
				num--;
			}
			vector = Maths.RotateLF(0.0, 1.0, 0.0, num5 * (double)num6, vector);
			num7 += num6;
		}
	}
}
