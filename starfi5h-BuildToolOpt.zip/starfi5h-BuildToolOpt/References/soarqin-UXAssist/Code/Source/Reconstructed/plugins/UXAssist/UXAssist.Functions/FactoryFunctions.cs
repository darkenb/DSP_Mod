using System.Collections.Generic;
using System.Linq;

namespace UXAssist.Functions;

public static class FactoryFunctions
{
	private struct BPBuildingData
	{
		public BlueprintBuilding building;

		public int itemType;

		public double offset;
	}

	private struct BPBeltData
	{
		public BlueprintBuilding building;

		public double offset;
	}

	private static HashSet<int> _itemIsBelt;

	private static Dictionary<int, int> _upgradeTypes;

	public static void CutConveyorBelt(CargoTraffic cargoTraffic, int beltId)
	{
		ref BeltComponent reference = ref cargoTraffic.beltPool[beltId];
		if (reference.id == beltId && reference.outputId > 0)
		{
			PlanetFactory factory = cargoTraffic.factory;
			factory.ReadObjectConn(reference.entityId, 0, out var isOutput, out var otherObjId, out var otherSlot);
			if (isOutput && factory.entityPool[otherObjId].beltId == reference.outputId)
			{
				factory.ClearObjectConnDirect(reference.entityId, 0);
				factory.ClearObjectConnDirect(otherObjId, otherSlot);
			}
			int rightInputId = reference.rightInputId;
			int backInputId = reference.backInputId;
			int i = reference.leftInputId;
			int i2 = backInputId;
			int i3 = rightInputId;
			cargoTraffic._arrInputs(ref i3, ref i2, ref i);
			cargoTraffic.AlterBeltConnections(beltId, 0, i3, i2, i);
		}
	}

	public static bool ObjectIsBeltOrInserter(PlanetFactory factory, int objId)
	{
		if (objId == 0)
		{
			return false;
		}
		ItemProto itemProto = LDB.items.Select((objId > 0) ? factory.entityPool[objId].protoId : factory.prebuildPool[-objId].protoId);
		if (itemProto != null)
		{
			if (!itemProto.prefabDesc.isBelt)
			{
				return itemProto.prefabDesc.isInserter;
			}
			return true;
		}
		return false;
	}

	public static void DismantleBlueprintSelectedBuildings()
	{
		Player mainPlayer = GameMain.mainPlayer;
		PlayerAction_Build playerAction_Build = mainPlayer?.controller?.actionBuild;
		if (playerAction_Build == null)
		{
			return;
		}
		BuildTool_BlueprintCopy blueprintCopyTool = playerAction_Build.blueprintCopyTool;
		if (blueprintCopyTool == null || !blueprintCopyTool.active)
		{
			return;
		}
		PlanetFactory factory = playerAction_Build.factory;
		List<int> list = new List<int>();
		BuildPreview[] bpPool = blueprintCopyTool.bpPool;
		foreach (BuildPreview buildPreview in bpPool)
		{
			if (buildPreview?.item == null)
			{
				continue;
			}
			int objId = buildPreview.objId;
			if (objId == 0)
			{
				continue;
			}
			int num;
			if ((num = list.BinarySearch(objId)) < 0)
			{
				list.Insert(~num, objId);
			}
			bool isBelt = buildPreview.desc.isBelt;
			if (buildPreview.desc.isInserter)
			{
				continue;
			}
			bool isOutput;
			int otherSlot;
			if (isBelt)
			{
				bool flag = false;
				for (int j = 0; j < 2; j++)
				{
					factory.ReadObjectConn(objId, j, out isOutput, out var otherObjId, out otherSlot);
					if (otherObjId != 0 && !ObjectIsBeltOrInserter(factory, otherObjId))
					{
						flag = true;
						break;
					}
				}
				if (flag)
				{
					for (int k = 0; k < 16; k++)
					{
						factory.ReadObjectConn(objId, k, out isOutput, out var otherObjId2, out otherSlot);
						if (otherObjId2 != 0 && (num = list.BinarySearch(otherObjId2)) < 0 && ObjectIsBeltOrInserter(factory, otherObjId2))
						{
							list.Insert(~num, otherObjId2);
						}
					}
				}
				for (int l = 0; l < 4; l++)
				{
					factory.ReadObjectConn(objId, l, out isOutput, out var otherObjId3, out otherSlot);
					if (otherObjId3 == 0 || !factory.ObjectIsBelt(otherObjId3) || list.BinarySearch(otherObjId3) >= 0)
					{
						continue;
					}
					for (int m = 0; m < 2; m++)
					{
						factory.ReadObjectConn(otherObjId3, m, out isOutput, out var otherObjId4, out otherSlot);
						if (otherObjId4 != 0 && (num = list.BinarySearch(otherObjId4)) < 0 && !ObjectIsBeltOrInserter(factory, otherObjId4))
						{
							list.Insert(~num, otherObjId3);
							break;
						}
					}
				}
			}
			else
			{
				if (buildPreview.desc.addonType == EAddonType.Belt)
				{
					continue;
				}
				for (int n = 0; n < 16; n++)
				{
					factory.ReadObjectConn(objId, n, out isOutput, out var otherObjId5, out otherSlot);
					if (otherObjId5 != 0 && (num = list.BinarySearch(otherObjId5)) < 0 && ObjectIsBeltOrInserter(factory, otherObjId5))
					{
						list.Insert(~num, otherObjId5);
					}
				}
			}
		}
		EntityData[] entityPool = factory.entityPool;
		StationComponent[] stationPool = factory.transport.stationPool;
		foreach (int item in list)
		{
			if (item > 0)
			{
				int stationId = entityPool[item].stationId;
				if (stationId > 0)
				{
					StationComponent stationComponent = stationPool[stationId];
					if (stationComponent == null || stationComponent.id != stationId)
					{
						continue;
					}
					for (int num2 = 0; num2 < stationComponent.storage.Length; num2++)
					{
						int num3 = mainPlayer.TryAddItemToPackage(stationComponent.storage[num2].itemId, stationComponent.storage[num2].count, stationComponent.storage[num2].inc, throwTrash: true, item);
						if (num3 > 0)
						{
							UIItemup.Up(stationComponent.storage[num2].itemId, num3);
						}
					}
					stationComponent.storage = new StationStore[stationComponent.storage.Length];
					stationComponent.needs = new int[stationComponent.needs.Length];
				}
			}
			playerAction_Build.DoDismantleObject(item);
		}
		blueprintCopyTool.ClearSelection();
		blueprintCopyTool.ClearPreSelection();
		blueprintCopyTool.ResetBlueprint();
		blueprintCopyTool.ResetBuildPreviews();
		blueprintCopyTool.RefreshBlueprintData();
	}

	public static void SelectAllBuildingsInBlueprintCopy()
	{
		PlanetFactory planetFactory = GameMain.localPlanet?.factory;
		if (planetFactory == null)
		{
			return;
		}
		BuildTool_BlueprintCopy buildTool_BlueprintCopy = GameMain.mainPlayer?.controller?.actionBuild?.blueprintCopyTool;
		if (buildTool_BlueprintCopy == null || !buildTool_BlueprintCopy.active)
		{
			return;
		}
		EntityData[] entityPool = planetFactory.entityPool;
		for (int i = 0; i < entityPool.Length; i++)
		{
			EntityData entityData = entityPool[i];
			if (entityData.id != 0)
			{
				buildTool_BlueprintCopy.preSelectObjIds.Add(entityData.id);
				buildTool_BlueprintCopy.selectedObjIds.Add(entityData.id);
			}
		}
		PrebuildData[] prebuildPool = planetFactory.prebuildPool;
		for (int i = 0; i < prebuildPool.Length; i++)
		{
			PrebuildData prebuildData = prebuildPool[i];
			if (prebuildData.id != 0)
			{
				buildTool_BlueprintCopy.preSelectObjIds.Add(-prebuildData.id);
				buildTool_BlueprintCopy.selectedObjIds.Add(-prebuildData.id);
			}
		}
		buildTool_BlueprintCopy.RefreshBlueprintData();
		buildTool_BlueprintCopy.DeterminePreviews();
	}

	public static void SortBlueprintData(BlueprintData blueprintData)
	{
		if (_itemIsBelt == null)
		{
			_itemIsBelt = new HashSet<int>();
			_upgradeTypes = new Dictionary<int, int>();
			ItemProto[] dataArray = LDB.items.dataArray;
			foreach (ItemProto itemProto in dataArray)
			{
				PrefabDesc prefabDesc = itemProto.prefabDesc;
				if (prefabDesc != null && prefabDesc.isBelt)
				{
					_itemIsBelt.Add(itemProto.ID);
				}
				else if (itemProto.Upgrades != null && itemProto.Upgrades.Length != 0)
				{
					int num = itemProto.Upgrades.Min((int u) => u);
					if (num != 0 && num != itemProto.ID)
					{
						_upgradeTypes.Add(itemProto.ID, num);
					}
				}
			}
		}
		List<BPBuildingData> list = new List<BPBuildingData>();
		Dictionary<BlueprintBuilding, BPBeltData> dictionary = new Dictionary<BlueprintBuilding, BPBeltData>();
		BlueprintBuilding[] buildings = blueprintData.buildings;
		foreach (BlueprintBuilding blueprintBuilding in buildings)
		{
			double offset = (double)blueprintBuilding.areaIndex * 1073741824.0 + (double)blueprintBuilding.localOffset_y * 262144.0 + (double)blueprintBuilding.localOffset_x * 1024.0 + (double)blueprintBuilding.localOffset_z;
			if (_itemIsBelt.Contains(blueprintBuilding.itemId))
			{
				dictionary.Add(blueprintBuilding, new BPBeltData
				{
					building = blueprintBuilding,
					offset = offset
				});
			}
			else
			{
				int value;
				int itemType = (_upgradeTypes.TryGetValue(blueprintBuilding.itemId, out value) ? value : blueprintBuilding.itemId);
				list.Add(new BPBuildingData
				{
					building = blueprintBuilding,
					itemType = itemType,
					offset = offset
				});
			}
		}
		HashSet<BlueprintBuilding> hashSet = new HashSet<BlueprintBuilding>();
		foreach (BlueprintBuilding item in dictionary.Select((KeyValuePair<BlueprintBuilding, BPBeltData> pair) => pair.Value.building.outputObj))
		{
			hashSet.Add(item);
		}
		HashSet<BlueprintBuilding> beltsWithInput = hashSet;
		Dictionary<BlueprintBuilding, BPBeltData> source = dictionary.Where((KeyValuePair<BlueprintBuilding, BPBeltData> pair) => !beltsWithInput.Contains(pair.Value.building)).ToDictionary((KeyValuePair<BlueprintBuilding, BPBeltData> pair) => pair.Key, (KeyValuePair<BlueprintBuilding, BPBeltData> pair) => pair.Value);
		List<BlueprintBuilding> list2 = new List<BlueprintBuilding>();
		foreach (KeyValuePair<BlueprintBuilding, BPBeltData> item2 in source.OrderByDescending((KeyValuePair<BlueprintBuilding, BPBeltData> pair) => pair.Value.offset))
		{
			BlueprintBuilding blueprintBuilding2 = item2.Key;
			while (blueprintBuilding2 != null && dictionary.Remove(blueprintBuilding2))
			{
				list2.Add(blueprintBuilding2);
				blueprintBuilding2 = blueprintBuilding2.outputObj;
			}
		}
		foreach (KeyValuePair<BlueprintBuilding, BPBeltData> item3 in dictionary.OrderByDescending((KeyValuePair<BlueprintBuilding, BPBeltData> pair) => pair.Value.offset))
		{
			BlueprintBuilding blueprintBuilding3 = item3.Key;
			while (blueprintBuilding3 != null && dictionary.Remove(blueprintBuilding3))
			{
				list2.Add(blueprintBuilding3);
				blueprintBuilding3 = blueprintBuilding3.outputObj;
			}
		}
		list.Sort(delegate(BPBuildingData a, BPBuildingData b)
		{
			int num3 = b.itemType.CompareTo(a.itemType);
			if (num3 != 0)
			{
				return num3;
			}
			num3 = b.building.modelIndex.CompareTo(a.building.modelIndex);
			if (num3 != 0)
			{
				return num3;
			}
			num3 = b.building.recipeId.CompareTo(a.building.recipeId);
			if (num3 != 0)
			{
				return num3;
			}
			num3 = a.building.areaIndex.CompareTo(b.building.areaIndex);
			return (num3 != 0) ? num3 : b.offset.CompareTo(a.offset);
		});
		list2.Reverse();
		List<BlueprintBuilding> list3 = new List<BlueprintBuilding>();
		list3.AddRange(list.Select((BPBuildingData b) => b.building));
		list3.AddRange(list2);
		blueprintData.buildings = list3.ToArray();
		BlueprintBuilding[] buildings2 = blueprintData.buildings;
		for (int num2 = buildings2.Length - 1; num2 >= 0; num2--)
		{
			buildings2[num2].index = num2;
		}
	}
}
