using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using UXAssist.Common;
using UnityEngine;
using UnityEngine.Serialization;
using UnityEngine.UI;

namespace UXAssist.Patches.Logistics;

internal static class RealtimeLogisticsInfoPanel
{
	private class PanelUpdatePatch : PatchImpl<PanelUpdatePatch>
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(UIGame), "_OnUpdate")]
		private static void UIGame_OnUpdate_Postfix()
		{
			StationInfoPanelsUpdate();
		}
	}

	internal class StationTip : MonoBehaviour
	{
		private struct StorageItemData
		{
			public int ItemId;

			public int ItemCount;

			public int ItemOrdered;

			public int ItemMax;

			public ELogisticStorage LocalState;

			public ELogisticStorage RemoteState;
		}

		private enum EStationTipLayout
		{
			None,
			Collector,
			VeinCollector,
			PlanetaryLogistics,
			InterstellarLogistics
		}

		[FormerlySerializedAs("RectTransform")]
		public RectTransform rectTransform;

		private Transform[] _icons;

		private Transform[] _iconLocals;

		private Transform[] _iconRemotes;

		private Transform[] _countTexts;

		private Transform[] _sliderBg;

		private Transform[] _sliderMax;

		private Transform[] _sliderCurrent;

		private Transform[] _sliderOrdered;

		private Image[] _sliderOrderedImage;

		private Image[] _iconsImage;

		private Image[] _iconLocalsImage;

		private Image[] _iconRemotesImage;

		private Text[] _countTextsText;

		private Transform[] _carrierIcons;

		private Text[] _carrierTotalCountText;

		private Text[] _carrierIdleCountText;

		private GameObject _infoText;

		private EStationTipLayout _layout;

		private int _storageNum;

		private float _pixelPerItem;

		private StorageItemData[] _storageItems;

		private static readonly Dictionary<int, Sprite> ItemSprites = new Dictionary<int, Sprite>();

		private static readonly Color[] StateColor = new Color[3]
		{
			Color.gray,
			SupplyColor,
			DemandColor
		};

		private static readonly bool[][] CarrierEnabled = new bool[5][]
		{
			new bool[3],
			new bool[3],
			new bool[3],
			new bool[3] { true, false, false },
			new bool[3] { true, true, true }
		};

		private static readonly float[] TipWindowWidths = new float[5] { 0f, 100f, 120f, 120f, 120f };

		private static readonly float[] TipWindowExtraHeights = new float[5] { 0f, 5f, 5f, 40f, 40f };

		private static readonly float[] CarrierPositionX = new float[3] { 5f, 35f, 85f };

		internal void InitStationTip()
		{
			_storageItems = new StorageItemData[_storageMaxSlotCount];
			rectTransform = (RectTransform)base.transform;
			_icons = new Transform[_storageMaxSlotCount];
			_iconLocals = new Transform[_storageMaxSlotCount];
			_iconRemotes = new Transform[_storageMaxSlotCount];
			_iconsImage = new Image[_storageMaxSlotCount];
			_iconLocalsImage = new Image[_storageMaxSlotCount];
			_iconRemotesImage = new Image[_storageMaxSlotCount];
			_countTexts = new Transform[_storageMaxSlotCount];
			_countTextsText = new Text[_storageMaxSlotCount];
			_sliderBg = new Transform[_storageMaxSlotCount];
			_sliderMax = new Transform[_storageMaxSlotCount];
			_sliderCurrent = new Transform[_storageMaxSlotCount];
			_sliderOrdered = new Transform[_storageMaxSlotCount];
			_sliderOrderedImage = new Image[_storageMaxSlotCount];
			_carrierIcons = new Transform[3];
			_carrierTotalCountText = new Text[3];
			_carrierIdleCountText = new Text[2];
			_infoText = base.transform.Find("info-text").gameObject;
			for (int num = 2; num >= 0; num--)
			{
				_carrierIcons[num] = base.transform.Find("carrierIcon" + num);
				_carrierIcons[num].gameObject.SetActive(value: false);
				_carrierTotalCountText[num] = _carrierIcons[num].Find("carrierTotalCountText").GetComponent<Text>();
				if (num < 2)
				{
					_carrierIdleCountText[num] = _carrierIcons[num].Find("carrierIdleCountText").GetComponent<Text>();
				}
			}
			for (int num2 = _storageMaxSlotCount - 1; num2 >= 0; num2--)
			{
				_countTexts[num2] = base.transform.Find("countText" + num2);
				_countTextsText[num2] = _countTexts[num2].GetComponent<Text>();
				_sliderBg[num2] = base.transform.Find("sliderBg" + num2);
				_sliderMax[num2] = _sliderBg[num2].Find("max-fg");
				_sliderCurrent[num2] = _sliderBg[num2].Find("current-fg");
				_sliderOrdered[num2] = _sliderBg[num2].Find("ordered-fg");
				_sliderOrderedImage[num2] = _sliderOrdered[num2].GetComponent<Image>();
				_icons[num2] = base.transform.Find("icon" + num2);
				_iconsImage[num2] = _icons[num2].GetComponent<Image>();
				_iconLocals[num2] = base.transform.Find("iconLocal" + num2);
				_iconRemotes[num2] = base.transform.Find("iconRemote" + num2);
				_iconLocalsImage[num2] = _iconLocals[num2].GetComponent<Image>();
				_iconRemotesImage[num2] = _iconRemotes[num2].GetComponent<Image>();
				_countTexts[num2].gameObject.SetActive(value: false);
				_sliderBg[num2].gameObject.SetActive(value: false);
				_icons[num2].gameObject.SetActive(value: false);
				_iconLocals[num2].gameObject.SetActive(value: false);
				_iconRemotes[num2].gameObject.SetActive(value: false);
				_storageItems[num2] = new StorageItemData
				{
					ItemId = -1,
					ItemCount = -1,
					ItemOrdered = -1,
					ItemMax = -1,
					LocalState = ELogisticStorage.None,
					RemoteState = ELogisticStorage.None
				};
			}
			_infoText.SetActive(value: false);
		}

		internal void ResetStationTip()
		{
			_layout = EStationTipLayout.None;
			for (int num = _storageItems.Length - 1; num >= 0; num--)
			{
				_countTexts[num].gameObject.SetActive(value: false);
				_sliderBg[num].gameObject.SetActive(value: false);
				_icons[num].gameObject.SetActive(value: false);
				_iconLocals[num].gameObject.SetActive(value: false);
				_iconRemotes[num].gameObject.SetActive(value: false);
				_countTextsText[num].color = StateColor[0];
				_iconLocalsImage[num].color = StateColor[0];
				_iconRemotesImage[num].color = StateColor[0];
				ref StorageItemData reference = ref _storageItems[num];
				reference.ItemId = -1;
				reference.ItemCount = -1;
				reference.ItemOrdered = -1;
				reference.ItemMax = -1;
				reference.LocalState = ELogisticStorage.None;
				reference.RemoteState = ELogisticStorage.None;
			}
			for (int num2 = 2; num2 >= 0; num2--)
			{
				_carrierIcons[num2].gameObject.SetActive(value: false);
			}
		}

		internal void ResetStorageSlider()
		{
			for (int num = _storageMaxSlotCount - 1; num >= 0; num--)
			{
				ref StorageItemData reference = ref _storageItems[num];
				reference.ItemId = -1;
				reference.ItemCount = -1;
				reference.ItemOrdered = -1;
				reference.ItemMax = -1;
			}
			_pixelPerItem = ((_layout == EStationTipLayout.InterstellarLogistics) ? _remoteStoragePixelPerItem : _localStoragePixelPerItem);
		}

		private static Sprite GetItemSprite(int itemId)
		{
			if (ItemSprites.TryGetValue(itemId, out var value))
			{
				return value;
			}
			value = LDB.items.Select(itemId)?.iconSprite;
			ItemSprites[itemId] = value;
			return value;
		}

		internal void SetItem(int i, StationStore storage, bool barEnabled)
		{
			ref StorageItemData reference = ref _storageItems[i];
			Text text = _countTextsText[i];
			int itemId = storage.itemId;
			if (itemId != reference.ItemId)
			{
				Transform transform = _icons[i];
				reference.ItemId = itemId;
				if (itemId <= 0)
				{
					transform.gameObject.SetActive(value: false);
					_iconLocals[i].gameObject.SetActive(value: false);
					_iconRemotes[i].gameObject.SetActive(value: false);
					_sliderBg[i].gameObject.SetActive(value: false);
					text.color = StateColor[0];
					text.text = "—  ";
					return;
				}
				storage.count = -1;
				transform.gameObject.SetActive(value: true);
				_iconsImage[i].sprite = GetItemSprite(itemId);
				_iconLocals[i].gameObject.SetActive(CarrierEnabled[(int)_layout][0]);
				_iconLocalsImage[i].sprite = StateSprite[(int)reference.LocalState];
				_iconRemotes[i].gameObject.SetActive(CarrierEnabled[(int)_layout][1]);
				_iconRemotesImage[i].sprite = StateSprite[(int)reference.RemoteState];
				_sliderBg[i].gameObject.SetActive(barEnabled);
				switch (_layout)
				{
				case EStationTipLayout.InterstellarLogistics:
				{
					Color color = (_iconRemotesImage[i].color = StateColor[(int)reference.RemoteState]);
					text.color = color;
					break;
				}
				case EStationTipLayout.VeinCollector:
				case EStationTipLayout.PlanetaryLogistics:
				{
					Color color = (_iconLocalsImage[i].color = StateColor[(int)reference.LocalState]);
					text.color = color;
					break;
				}
				}
			}
			else if (itemId <= 0)
			{
				return;
			}
			int num = storage.count;
			int num2 = ((_layout == EStationTipLayout.InterstellarLogistics) ? _remoteStorageMaxTotal : _localStorageMaxTotal);
			bool flag = false;
			if (reference.ItemCount != num)
			{
				reference.ItemCount = num;
				text.text = num.ToString();
				if (num > num2)
				{
					num = num2;
				}
				if (barEnabled)
				{
					if (num == 0)
					{
						_sliderCurrent[i].gameObject.SetActive(value: false);
					}
					else
					{
						((RectTransform)_sliderCurrent[i].transform).sizeDelta = new Vector2(_pixelPerItem * (float)num, 5f);
						_sliderCurrent[i].gameObject.SetActive(value: true);
					}
					flag = true;
				}
			}
			else if (num > num2)
			{
				num = num2;
			}
			if (barEnabled)
			{
				int num3 = storage.totalOrdered;
				if (reference.ItemOrdered != num3)
				{
					reference.ItemOrdered = num3;
					flag = true;
				}
				if (flag)
				{
					if (num3 <= 0)
					{
						if (num3 < 0)
						{
							if (num3 + num < 0)
							{
								num3 = -num;
							}
							_sliderOrderedImage[i].color = OrderOutColor;
							RectTransform obj = (RectTransform)_sliderOrdered[i].transform;
							obj.localPosition = new Vector3(_pixelPerItem * (float)(num + num3), 0f, 0f);
							obj.sizeDelta = new Vector2(_pixelPerItem * (float)(-num3) + 0.49f, 5f);
						}
					}
					else
					{
						if (num3 + num > num2)
						{
							num3 = num2 - num;
						}
						_sliderOrderedImage[i].color = OrderInColor;
						RectTransform obj2 = (RectTransform)_sliderOrdered[i].transform;
						obj2.localPosition = new Vector3(_pixelPerItem * (float)num, 0f, 0f);
						obj2.sizeDelta = new Vector2(_pixelPerItem * (float)num3 + 0.49f, 5f);
					}
					_sliderOrdered[i].gameObject.SetActive(num3 != 0);
				}
				int num4 = storage.max;
				if (reference.ItemMax != num4)
				{
					reference.ItemMax = num4;
					_sliderBg[i].gameObject.SetActive(num4 > 0);
					if (num4 > num2)
					{
						num4 = num2;
					}
					((RectTransform)_sliderMax[i].transform).sizeDelta = new Vector2(_pixelPerItem * (float)num4, 5f);
				}
			}
			switch (_layout)
			{
			case EStationTipLayout.InterstellarLogistics:
			{
				ELogisticStorage localLogic2 = storage.localLogic;
				if (reference.LocalState != localLogic2)
				{
					reference.LocalState = localLogic2;
					Image obj3 = _iconLocalsImage[i];
					obj3.sprite = StateSprite[(int)localLogic2];
					obj3.color = StateColor[(int)localLogic2];
				}
				ELogisticStorage remoteLogic = storage.remoteLogic;
				if (reference.RemoteState != remoteLogic)
				{
					reference.RemoteState = remoteLogic;
					Image image2 = _iconRemotesImage[i];
					image2.sprite = StateSprite[(int)remoteLogic];
					Color color = (image2.color = StateColor[(int)remoteLogic]);
					text.color = color;
				}
				break;
			}
			case EStationTipLayout.VeinCollector:
			case EStationTipLayout.PlanetaryLogistics:
			{
				ELogisticStorage localLogic = storage.localLogic;
				if (reference.LocalState != localLogic)
				{
					reference.LocalState = localLogic;
					Image image = _iconLocalsImage[i];
					image.sprite = StateSprite[(int)localLogic];
					Color color = (image.color = StateColor[(int)localLogic]);
					text.color = color;
				}
				break;
			}
			case EStationTipLayout.None:
			case EStationTipLayout.Collector:
				break;
			}
		}

		internal void UpdateStationInfo(StationComponent stationComponent)
		{
			EStationTipLayout eStationTipLayout = (stationComponent.isCollector ? EStationTipLayout.Collector : (stationComponent.isVeinCollector ? EStationTipLayout.VeinCollector : (stationComponent.isStellar ? EStationTipLayout.InterstellarLogistics : EStationTipLayout.PlanetaryLogistics)));
			if (_layout != eStationTipLayout)
			{
				_layout = eStationTipLayout;
				for (int num = _storageMaxSlotCount - 1; num >= 0; num--)
				{
					_iconLocals[num].gameObject.SetActive(value: false);
					_iconRemotes[num].gameObject.SetActive(value: false);
					_icons[num].gameObject.SetActive(value: false);
					switch (eStationTipLayout)
					{
					case EStationTipLayout.PlanetaryLogistics:
					{
						RectTransform obj2 = (RectTransform)_iconLocals[num].transform;
						obj2.sizeDelta = new Vector2(20f, 20f);
						obj2.anchoredPosition3D = new Vector3(100f, -5f - 35f * (float)num - 5f, 0f);
						break;
					}
					case EStationTipLayout.InterstellarLogistics:
					{
						RectTransform obj = (RectTransform)_iconLocals[num].transform;
						obj.sizeDelta = new Vector2(16f, 16f);
						obj.anchoredPosition3D = new Vector3(102f, -5f - 35f * (float)num, 0f);
						break;
					}
					}
				}
				for (int i = _storageNum; i < _storageMaxSlotCount; i++)
				{
					_iconLocals[i].gameObject.SetActive(value: false);
					_iconRemotes[i].gameObject.SetActive(value: false);
					_icons[i].gameObject.SetActive(value: false);
					_countTexts[i].gameObject.SetActive(value: false);
					_sliderBg[i].gameObject.SetActive(value: false);
				}
				_storageNum = Math.Min(_storageMaxSlotCount, stationComponent.storage.Length);
				rectTransform.sizeDelta = new Vector2(TipWindowWidths[(int)eStationTipLayout], TipWindowExtraHeights[(int)eStationTipLayout] + 35f * (float)_storageNum);
				for (int num2 = _storageMaxSlotCount - 1; num2 >= 0; num2--)
				{
					_countTexts[num2].gameObject.SetActive(num2 < _storageNum);
				}
				for (int num3 = 2; num3 >= 0; num3--)
				{
					bool flag = CarrierEnabled[(int)eStationTipLayout][num3];
					_carrierIcons[num3].gameObject.SetActive(flag);
					if (flag)
					{
						((RectTransform)_carrierIcons[num3].transform).anchoredPosition3D = new Vector3(CarrierPositionX[num3], -5f - 35f * (float)_storageNum, 0f);
					}
				}
				_pixelPerItem = ((_layout == EStationTipLayout.InterstellarLogistics) ? _remoteStoragePixelPerItem : _localStoragePixelPerItem);
			}
			if (_storageNum > 0)
			{
				StationStore[] storage = stationComponent.storage;
				bool value = LogisticsPatch.RealtimeLogisticsInfoPanelBarsEnabled.Value;
				for (int num4 = _storageNum - 1; num4 >= 0; num4--)
				{
					StationStore storage2 = storage[num4];
					SetItem(num4, storage2, value);
				}
			}
			switch (_layout)
			{
			case EStationTipLayout.PlanetaryLogistics:
			{
				int num5 = stationComponent.idleDroneCount + stationComponent.workDroneCount;
				int idleDroneCount = stationComponent.idleDroneCount;
				_carrierIdleCountText[0].text = idleDroneCount.ToString();
				_carrierTotalCountText[0].text = num5.ToString();
				break;
			}
			case EStationTipLayout.InterstellarLogistics:
			{
				int num5 = stationComponent.idleDroneCount + stationComponent.workDroneCount;
				int idleDroneCount = stationComponent.idleDroneCount;
				_carrierIdleCountText[0].text = idleDroneCount.ToString();
				_carrierTotalCountText[0].text = num5.ToString();
				num5 = stationComponent.idleShipCount + stationComponent.workShipCount;
				idleDroneCount = stationComponent.idleShipCount;
				_carrierIdleCountText[1].text = idleDroneCount.ToString();
				_carrierTotalCountText[1].text = num5.ToString();
				idleDroneCount = stationComponent.warperCount;
				_carrierTotalCountText[2].text = idleDroneCount.ToString();
				break;
			}
			case EStationTipLayout.None:
			case EStationTipLayout.Collector:
			case EStationTipLayout.VeinCollector:
				break;
			}
		}

		internal void SetBarsVisible(bool on)
		{
			for (int num = _storageNum - 1; num >= 0; num--)
			{
				_sliderBg[num].gameObject.SetActive(on && _storageItems[num].ItemId > 0);
			}
			for (int i = _storageNum; i < _storageMaxSlotCount; i++)
			{
				_sliderBg[i].gameObject.SetActive(value: false);
			}
		}
	}

	private static StationTip[] _stationTips = new StationTip[16];

	private static readonly StationTip[] StationTipsRecycle = new StationTip[128];

	private static readonly Sprite[] StateSprite = new Sprite[3];

	private static int _stationTipsRecycleCount;

	private static GameObject _stationTipsRoot;

	private static GameObject _tipPrefab;

	private static readonly Color DemandColor = new Color(0.99215686f, 0.5882353f, 0.36862746f);

	private static readonly Color SupplyColor = new Color(0.38039216f, 72f / 85f, 1f);

	private static readonly Color OrderInColor = new Color(36f / 85f, 11f / 15f, 0.8392157f);

	private static readonly Color OrderOutColor = new Color(1f, 0.6313726f, 73f / 170f);

	private static PlanetTransport _lastTransport;

	private static int _localStorageMax = 5000;

	private static int _remoteStorageMax = 10000;

	private static int _localStorageExtra;

	private static int _remoteStorageExtra;

	private static int _localStorageMaxTotal = _localStorageMax;

	private static int _remoteStorageMaxTotal = _remoteStorageMax;

	private static float _localStoragePixelPerItem = 70f / (float)_localStorageMaxTotal;

	private static float _remoteStoragePixelPerItem = 70f / (float)_remoteStorageMaxTotal;

	private static int _storageMaxSlotCount = 5;

	private const int CarrierSlotCount = 3;

	private static readonly Sprite[] LogisticsExtraItemSprites = new Sprite[3]
	{
		Resources.Load<Sprite>("Icons/ItemRecipe/logistic-drone"),
		Resources.Load<Sprite>("Icons/ItemRecipe/logistic-vessel"),
		Resources.Load<Sprite>("Icons/ItemRecipe/space-warper")
	};

	private static bool UpdateStorageMax()
	{
		GameHistoryData history = GameMain.history;
		if (history == null)
		{
			return false;
		}
		if (_remoteStorageExtra == history.remoteStationExtraStorage && _localStorageExtra == history.localStationExtraStorage)
		{
			return false;
		}
		_localStorageExtra = history.localStationExtraStorage;
		_remoteStorageExtra = history.remoteStationExtraStorage;
		_localStorageMaxTotal = _localStorageMax + _localStorageExtra;
		_remoteStorageMaxTotal = _remoteStorageMax + _remoteStorageExtra;
		_localStoragePixelPerItem = 70f / (float)_localStorageMaxTotal;
		_remoteStoragePixelPerItem = 70f / (float)_remoteStorageMaxTotal;
		return true;
	}

	internal static void Enable(bool on)
	{
		PatchImpl<PanelUpdatePatch>.Enable(on);
		if (!on)
		{
			HideAndRecycleStationTips();
		}
	}

	internal static void EnableBars(bool on)
	{
		StationTip[] stationTips = _stationTips;
		foreach (StationTip stationTip in stationTips)
		{
			if (!(stationTip == null))
			{
				stationTip.SetBarsVisible(on);
			}
		}
	}

	internal static void OnGameBegin()
	{
		HideAndRecycleStationTips();
	}

	internal static void OnGameEnd()
	{
		HideAndRecycleStationTips();
	}

	internal static void OnDataLoaded()
	{
		_storageMaxSlotCount = 5;
		_localStorageMax = 5000;
		_remoteStorageMax = 10000;
		ModelProto[] dataArray = LDB.models.dataArray;
		for (int i = 0; i < dataArray.Length; i++)
		{
			PrefabDesc prefabDesc = dataArray[i]?.prefabDesc;
			if (prefabDesc == null || !prefabDesc.isStation)
			{
				continue;
			}
			_storageMaxSlotCount = Math.Max(_storageMaxSlotCount, prefabDesc.stationMaxItemKinds);
			if (prefabDesc.isStellarStation)
			{
				if (!prefabDesc.isCollectStation)
				{
					_remoteStorageMax = Math.Max(_remoteStorageMax, prefabDesc.stationMaxItemCount);
				}
			}
			else if (!prefabDesc.isVeinCollector)
			{
				_localStorageMax = Math.Max(_localStorageMax, prefabDesc.stationMaxItemCount);
			}
		}
		_localStorageExtra = -1;
		_remoteStorageExtra = -1;
		_localStoragePixelPerItem = 0f;
		_remoteStoragePixelPerItem = 0f;
		UpdateStorageMax();
		InitGUI();
	}

	internal static void InitGUI()
	{
		if (_stationTipsRoot != null)
		{
			return;
		}
		_stationTipsRoot = new GameObject("station-tips-root");
		RectTransform rectTransform = _stationTipsRoot.AddComponent<RectTransform>();
		_stationTipsRoot.transform.SetParent(GameObject.Find("UI Root/Overlay Canvas/In Game/Scene UIs").transform);
		rectTransform.sizeDelta = new Vector2(0f, 0f);
		rectTransform.localScale = new Vector3(1f, 1f, 1f);
		rectTransform.anchorMax = new Vector2(1f, 1f);
		rectTransform.anchorMin = new Vector2(0f, 0f);
		rectTransform.pivot = new Vector2(0f, 0f);
		rectTransform.anchoredPosition3D = new Vector3(0f, 0f, 0f);
		GameObject gameObject = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Station Window/storage-box-0/slider-bg");
		if (gameObject == null)
		{
			UXAssist.Logger.LogWarning("RealtimeLogisticsInfoPanel.InitGUI: slider-bg prefab not found, aborting GUI init");
			UnityEngine.Object.Destroy(_stationTipsRoot);
			_stationTipsRoot = null;
			return;
		}
		GameObject gameObject2 = GameObject.Find("UI Root/Overlay Canvas/In Game/Scene UIs/Vein Marks/vein-tips/vein-tip-prefab");
		if (gameObject2 == null)
		{
			UXAssist.Logger.LogWarning("RealtimeLogisticsInfoPanel.InitGUI: vein-tip-prefab not found, aborting GUI init");
			UnityEngine.Object.Destroy(_stationTipsRoot);
			_stationTipsRoot = null;
			return;
		}
		GameObject gameObject3 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Key Tips/tip-prefab");
		if (gameObject3 == null)
		{
			UXAssist.Logger.LogWarning("RealtimeLogisticsInfoPanel.InitGUI: key tip-prefab not found, aborting GUI init");
			UnityEngine.Object.Destroy(_stationTipsRoot);
			_stationTipsRoot = null;
			return;
		}
		_tipPrefab = UnityEngine.Object.Instantiate(gameObject2, _stationTipsRoot.transform);
		_tipPrefab.name = "tipPrefab";
		UnityEngine.Object.Destroy(_tipPrefab.GetComponent<UIVeinDetailNode>());
		Image component = _tipPrefab.GetComponent<Image>();
		component.sprite = gameObject3.GetComponent<Image>().sprite;
		component.color = new Color(0f, 0f, 0f, 0.8f);
		component.enabled = true;
		RectTransform obj = (RectTransform)_tipPrefab.transform;
		obj.localPosition = new Vector3(200f, 800f, 0f);
		obj.sizeDelta = new Vector2(150f, 160f);
		obj.pivot = new Vector2(0.5f, 0.5f);
		GameObject gameObject4 = _tipPrefab.transform.Find("info-text").gameObject;
		Transform transform = _tipPrefab.transform.Find("icon");
		for (int i = 0; i < _storageMaxSlotCount; i++)
		{
			float num = -5f - 35f * (float)i;
			GameObject gameObject5 = UnityEngine.Object.Instantiate(transform.gameObject, new Vector3(0f, 0f, 0f), Quaternion.identity, _tipPrefab.transform);
			gameObject5.name = "icon" + i;
			gameObject5.GetComponent<Image>().enabled = true;
			RectTransform obj2 = (RectTransform)gameObject5.transform;
			obj2.sizeDelta = new Vector2(30f, 30f);
			obj2.anchorMax = new Vector2(0f, 1f);
			obj2.anchorMin = new Vector2(0f, 1f);
			obj2.pivot = new Vector2(0f, 1f);
			obj2.anchoredPosition3D = new Vector3(0f, num, 0f);
			GameObject gameObject6 = UnityEngine.Object.Instantiate(gameObject.gameObject, new Vector3(0f, 0f, 0f), Quaternion.identity, _tipPrefab.transform);
			gameObject6.name = "sliderBg" + i;
			gameObject6.GetComponent<Image>().enabled = true;
			RectTransform obj3 = (RectTransform)gameObject6.transform;
			obj3.sizeDelta = new Vector2(70f, 5f);
			obj3.anchorMax = new Vector2(0f, 1f);
			obj3.anchorMin = new Vector2(0f, 1f);
			obj3.pivot = new Vector2(0f, 1f);
			obj3.anchoredPosition3D = new Vector3(30f, num - 22f, 0f);
			RectTransform obj4 = (RectTransform)gameObject6.transform.Find("current-fg").transform;
			obj4.sizeDelta = new Vector2(0f, 5f);
			obj4.anchorMax = new Vector2(0f, 1f);
			obj4.anchorMin = new Vector2(0f, 1f);
			obj4.pivot = new Vector2(0f, 1f);
			obj4.localPosition = new Vector3(0f, 0f, 0f);
			RectTransform obj5 = (RectTransform)gameObject6.transform.Find("ordered-fg").transform;
			obj5.sizeDelta = new Vector2(0f, 5f);
			obj5.anchorMax = new Vector2(0f, 1f);
			obj5.anchorMin = new Vector2(0f, 1f);
			obj5.pivot = new Vector2(0f, 1f);
			obj5.localPosition = new Vector3(0f, 0f, 0f);
			RectTransform obj6 = (RectTransform)gameObject6.transform.Find("max-fg").transform;
			obj6.sizeDelta = new Vector2(70f, 5f);
			obj6.anchorMax = new Vector2(0f, 1f);
			obj6.anchorMin = new Vector2(0f, 1f);
			obj6.pivot = new Vector2(0f, 1f);
			obj6.localPosition = new Vector3(0f, 0f, 0f);
			component = obj6.GetComponent<Image>();
			component.color = new Color(component.color.r, component.color.g, component.color.b, 0.15f);
			UnityEngine.Object.Destroy(gameObject6.GetComponent<Slider>());
			UnityEngine.Object.Destroy(gameObject6.transform.Find("thumb").gameObject);
			UnityEngine.Object.Destroy(gameObject6.transform.Find("speed-text").gameObject);
			gameObject6.gameObject.SetActive(value: false);
			GameObject gameObject7 = UnityEngine.Object.Instantiate(gameObject4, Vector3.zero, Quaternion.identity, _tipPrefab.transform);
			gameObject7.name = "countText" + i;
			Text component2 = gameObject7.GetComponent<Text>();
			component2.fontSize = 18;
			component2.text = "";
			component2.alignment = TextAnchor.UpperRight;
			component2.fontStyle = FontStyle.Normal;
			component2.horizontalOverflow = HorizontalWrapMode.Overflow;
			component2.verticalOverflow = VerticalWrapMode.Overflow;
			RectTransform obj7 = (RectTransform)gameObject7.transform;
			obj7.sizeDelta = new Vector2(70f, 20f);
			obj7.anchorMax = new Vector2(0f, 1f);
			obj7.anchorMin = new Vector2(0f, 1f);
			obj7.pivot = new Vector2(0f, 1f);
			obj7.anchoredPosition3D = new Vector3(30f, num, 0f);
			UnityEngine.Object.Destroy(gameObject7.GetComponent<Shadow>());
			GameObject gameObject8 = UnityEngine.Object.Instantiate(transform.gameObject, new Vector3(0f, 0f, 0f), Quaternion.identity, _tipPrefab.transform);
			gameObject8.name = "iconLocal" + i;
			Image component3 = gameObject8.GetComponent<Image>();
			component3.material = null;
			component3.enabled = true;
			RectTransform obj8 = (RectTransform)gameObject8.transform;
			obj8.sizeDelta = new Vector2(16f, 16f);
			obj8.anchorMax = new Vector2(0f, 1f);
			obj8.anchorMin = new Vector2(0f, 1f);
			obj8.pivot = new Vector2(0f, 1f);
			obj8.anchoredPosition3D = new Vector3(102f, num, 0f);
			GameObject gameObject9 = UnityEngine.Object.Instantiate(transform.gameObject, new Vector3(0f, 0f, 0f), Quaternion.identity, _tipPrefab.transform);
			gameObject9.name = "iconRemote" + i;
			Image component4 = gameObject9.GetComponent<Image>();
			component4.material = null;
			component4.enabled = true;
			RectTransform obj9 = (RectTransform)gameObject9.transform;
			obj9.sizeDelta = new Vector2(20f, 20f);
			obj9.anchorMax = new Vector2(0f, 1f);
			obj9.anchorMin = new Vector2(0f, 1f);
			obj9.pivot = new Vector2(0f, 1f);
			obj9.anchoredPosition3D = new Vector3(100f, num - 12f, 0f);
		}
		GameObject gameObject10 = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Top Tips/Entity Briefs/brief-info-top/brief-info/content/icons/icon"), _tipPrefab.transform);
		gameObject10.GetComponent<Image>().enabled = true;
		UnityEngine.Object.Destroy(gameObject10.transform.Find("count-text").gameObject);
		UnityEngine.Object.Destroy(gameObject10.transform.Find("bg").gameObject);
		UnityEngine.Object.Destroy(gameObject10.transform.Find("inc").gameObject);
		UnityEngine.Object.Destroy(gameObject10.GetComponent<UIIconCountInc>());
		gameObject10.SetActive(value: false);
		for (int j = 0; j < 3; j++)
		{
			GameObject gameObject11 = UnityEngine.Object.Instantiate(gameObject10, new Vector3(0f, 0f, 0f), Quaternion.identity, _tipPrefab.transform);
			gameObject11.name = "carrierIcon" + j;
			gameObject11.GetComponent<Image>().sprite = LogisticsExtraItemSprites[j];
			RectTransform obj10 = (RectTransform)gameObject11.transform;
			obj10.localScale = new Vector3(0.7f, 0.7f, 1f);
			obj10.anchorMax = new Vector2(0f, 1f);
			obj10.anchorMin = new Vector2(0f, 1f);
			obj10.pivot = new Vector2(0f, 1f);
			obj10.anchoredPosition3D = new Vector3(0f, -180f, 0f);
			gameObject11.SetActive(value: true);
			GameObject gameObject12 = UnityEngine.Object.Instantiate(gameObject4, Vector3.zero, Quaternion.identity, gameObject11.transform);
			UnityEngine.Object.Destroy(gameObject12.GetComponent<Shadow>());
			gameObject12.name = "carrierTotalCountText";
			Text component5 = gameObject12.GetComponent<Text>();
			component5.fontSize = 22;
			component5.text = "100";
			component5.alignment = TextAnchor.MiddleRight;
			component5.color = Color.white;
			component5.fontStyle = FontStyle.Normal;
			component5.horizontalOverflow = HorizontalWrapMode.Overflow;
			component5.verticalOverflow = VerticalWrapMode.Overflow;
			RectTransform obj11 = (RectTransform)gameObject12.transform;
			obj11.sizeDelta = new Vector2(40f, 30f);
			obj11.anchorMax = new Vector2(0f, 1f);
			obj11.anchorMin = new Vector2(0f, 1f);
			obj11.pivot = new Vector2(0f, 1f);
			obj11.localPosition = new Vector3(0f, -18f, 0f);
			if (j < 2)
			{
				GameObject gameObject13 = UnityEngine.Object.Instantiate(gameObject4, Vector3.zero, Quaternion.identity, gameObject11.transform);
				UnityEngine.Object.Destroy(gameObject13.GetComponent<Shadow>());
				gameObject13.name = "carrierIdleCountText";
				Text component6 = gameObject13.GetComponent<Text>();
				component6.fontSize = 22;
				component6.text = "100";
				component6.alignment = TextAnchor.MiddleRight;
				component6.color = Color.white;
				component6.fontStyle = FontStyle.Normal;
				component6.horizontalOverflow = HorizontalWrapMode.Overflow;
				component6.verticalOverflow = VerticalWrapMode.Overflow;
				RectTransform obj12 = (RectTransform)gameObject13.transform;
				obj12.sizeDelta = new Vector2(40f, 30f);
				obj12.anchorMax = new Vector2(0f, 1f);
				obj12.anchorMin = new Vector2(0f, 1f);
				obj12.pivot = new Vector2(0f, 1f);
				obj12.localPosition = new Vector3(0f, 8f, 0f);
			}
		}
		transform.gameObject.SetActive(value: false);
		_tipPrefab.SetActive(value: false);
		_stationTipsRoot.SetActive(value: false);
		StateSprite[0] = Util.LoadEmbeddedSprite("assets/icon/keep.png");
		StateSprite[1] = Util.LoadEmbeddedSprite("assets/icon/out.png");
		StateSprite[2] = Util.LoadEmbeddedSprite("assets/icon/in.png");
	}

	private static void ReleaseStationTip(StationTip stationTip)
	{
		if ((bool)stationTip)
		{
			GameObject gameObject = stationTip.gameObject;
			gameObject.SetActive(value: false);
			if (_stationTipsRecycleCount < StationTipsRecycle.Length)
			{
				stationTip.ResetStationTip();
				StationTipsRecycle[_stationTipsRecycleCount++] = stationTip;
			}
			else
			{
				UnityEngine.Object.Destroy(gameObject);
			}
		}
	}

	private static void RecycleStationTips()
	{
		StationTip[] stationTips = _stationTips;
		for (int i = 0; i < stationTips.Length; i++)
		{
			ReleaseStationTip(stationTips[i]);
		}
		_stationTips = new StationTip[16];
	}

	private static void RecycleStationTip(int index)
	{
		StationTip stationTip = _stationTips[index];
		if ((bool)stationTip)
		{
			ReleaseStationTip(stationTip);
			_stationTips[index] = null;
		}
	}

	private static void HideAndRecycleStationTips()
	{
		_stationTipsRoot?.SetActive(value: false);
		RecycleStationTips();
		_lastTransport = null;
	}

	private static StationTip AllocateStationTip()
	{
		if (_stationTipsRecycleCount > 0)
		{
			_stationTipsRecycleCount--;
			StationTip result = StationTipsRecycle[_stationTipsRecycleCount];
			StationTipsRecycle[_stationTipsRecycleCount] = null;
			return result;
		}
		StationTip stationTip = UnityEngine.Object.Instantiate(_tipPrefab, _stationTipsRoot.transform).AddComponent<StationTip>();
		stationTip.InitStationTip();
		return stationTip;
	}

	internal static void StationInfoPanelsUpdate()
	{
		if (_stationTipsRoot == null)
		{
			return;
		}
		PlanetData planetData = ((DSPGame.IsMenuDemo || !GameMain.isRunning) ? null : GameMain.data?.localPlanet);
		PlanetFactory planetFactory = ((planetData != null && planetData.factoryLoaded) ? planetData.factory : null);
		PlanetTransport planetTransport = planetFactory?.transport;
		if (_lastTransport != planetTransport)
		{
			RecycleStationTips();
			_lastTransport = planetTransport;
		}
		if (planetTransport == null || planetTransport.stationCursor <= 1 || (UIGame.viewMode != EViewMode.Normal && UIGame.viewMode != EViewMode.Globe))
		{
			_stationTipsRoot.SetActive(value: false);
			return;
		}
		_stationTipsRoot.SetActive(value: true);
		if (UpdateStorageMax())
		{
			StationTip[] stationTips = _stationTips;
			for (int i = 0; i < stationTips.Length; i++)
			{
				stationTips[i]?.ResetStorageSlider();
			}
		}
		Vector3 localPosition = GameCamera.main.transform.localPosition;
		Vector3 forward = GameCamera.main.transform.forward;
		float realRadius = planetData.realRadius;
		StationComponent[] stationPool = planetTransport.stationPool;
		int stationCursor = planetTransport.stationCursor;
		if (stationCursor > _stationTips.Length)
		{
			int num = stationCursor - 1;
			num |= num >> 1;
			num |= num >> 2;
			num |= num >> 4;
			num |= num >> 8;
			num |= num >> 16;
			num++;
			Array.Resize(ref _stationTips, num);
		}
		Vector2 rectPoint = default(Vector2);
		for (int num2 = stationCursor - 1; num2 > 0; num2--)
		{
			StationComponent stationComponent = stationPool[num2];
			if (stationComponent == null || num2 != stationComponent.id)
			{
				RecycleStationTip(num2);
			}
			else
			{
				StationStore[] storage = stationComponent.storage;
				if (storage == null)
				{
					RecycleStationTip(num2);
				}
				else
				{
					StationTip stationTip = _stationTips[num2];
					if (!stationTip)
					{
						stationTip = AllocateStationTip();
						_stationTips[num2] = stationTip;
					}
					Vector3 normalized = planetFactory.entityPool[stationComponent.entityId].pos.normalized;
					float num3 = realRadius;
					num3 = (stationComponent.isCollector ? (num3 + 35f) : (stationComponent.isStellar ? (num3 + 20f) : ((!stationComponent.isVeinCollector) ? (num3 + 15f) : (num3 + 8f))));
					normalized *= num3;
					Vector3 vector = normalized - localPosition;
					float magnitude = vector.magnitude;
					bool flag = (double)magnitude < 1.0 || (double)Vector3.Dot(forward, vector) < 1.0 || !UIRoot.ScreenPointIntoRect(GameCamera.main.WorldToScreenPoint(normalized), (RectTransform)_stationTipsRoot.transform, out rectPoint);
					if (!flag)
					{
						float x = rectPoint.x;
						bool flag2 = ((x < -4096f || x > 4096f) ? true : false);
						flag = flag2;
					}
					bool flag3 = flag;
					if (!flag3)
					{
						float x = rectPoint.y;
						bool flag2 = ((x < -4096f || x > 4096f) ? true : false);
						flag3 = flag2;
					}
					if (flag3 || Phys.RayCastSphere(localPosition, vector / magnitude, magnitude, Vector3.zero, realRadius, out var _) || storage.Select((StationStore stationStore) => stationStore.itemId).All((int num5) => num5 == 0))
					{
						stationTip.gameObject.SetActive(value: false);
					}
					else
					{
						stationTip.gameObject.SetActive(value: true);
						float x = ((magnitude < 50f) ? 1.5f : ((!(magnitude < 250f)) ? 0.5f : (1.75f - magnitude * 0.005f)));
						float num4 = x;
						stationTip.rectTransform.anchoredPosition = rectPoint;
						stationTip.transform.localScale = Vector3.one * num4;
						stationTip.UpdateStationInfo(stationComponent);
					}
				}
			}
		}
	}
}
