using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using CommonAPI;
using HarmonyLib;
using UXAssist.Common;
using UXAssist.Common.ModFeatures;
using UXAssist.Functions;
using UXAssist.ModsCompat;
using UXAssist.Patches;
using UXAssist.Patches.Factory;
using UXAssist.Patches.Logistics;
using UXAssist.UI;
using UnityEngine;
using crecheng.DSPModSave;

namespace UXAssist;

[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "CustomKeyBindSystem" })]
[BepInPlugin("org.soardev.uxassist", "UXAssist", "1.6.3")]
[BepInDependency("testpostpleaseignore.dsp.planet_vein_utilization", BepInDependency.DependencyFlags.SoftDependency)]
public class UXAssist : BaseUnityPlugin, IModCanSave
{
	public new static readonly ManualLogSource Logger = BepInEx.Logging.Logger.CreateLogSource("UXAssist");

	private static ConfigFile _dummyConfig;

	private Type[] _patches;

	private Type[] _compats;

	private readonly Harmony _harmony = new Harmony("org.soardev.uxassist");

	private const ushort ModSaveVersion = 2;

	private static readonly List<Action<BinaryWriter>> _exporters = new List<Action<BinaryWriter>>();

	private static readonly List<Action<BinaryReader, ushort>> _importers = new List<Action<BinaryReader, ushort>>();

	public static void RegisterExporter(Action<BinaryWriter> e)
	{
		_exporters.Add(e);
	}

	public static void RegisterImporter(Action<BinaryReader, ushort> i)
	{
		_importers.Add(i);
	}

	public void Export(BinaryWriter w)
	{
		w.Write((ushort)2);
		foreach (Action<BinaryWriter> exporter in _exporters)
		{
			exporter(w);
		}
	}

	public void Import(BinaryReader r)
	{
		ushort num = r.ReadUInt16();
		if (num <= 0)
		{
			return;
		}
		foreach (Action<BinaryReader, ushort> importer in _importers)
		{
			importer(r, num);
		}
	}

	public void IntoOtherSave()
	{
	}

	private UXAssist()
	{
		PlanetVeinUtilization.Run(_harmony);
		CommonAPIWrapper.Run(_harmony);
	}

	private void Awake()
	{
		_dummyConfig = new ConfigFile(Path.Combine(Paths.ConfigPath, "org.soardev.uxassist_dummy.cfg"), saveOnInit: false)
		{
			SaveOnConfigSet = false
		};
		GamePatch.EnableWindowResizeEnabled = base.Config.Bind("Game", "EnableWindowResize", defaultValue: false, "Enable game window resize (maximum box and thick frame)");
		GamePatch.LoadLastWindowRectEnabled = base.Config.Bind("Game", "LoadLastWindowRect", defaultValue: false, "Load last window position and size when game starts");
		GamePatch.LastWindowRect = base.Config.Bind("Game", "LastWindowRect", new Vector4(0f, 0f, 0f, 0f), "Last window position and size");
		GamePatch.ProfileBasedSaveFolderEnabled = base.Config.Bind("Game", "ProfileBasedSaveFolder", defaultValue: false, "Profile-based save folder");
		GamePatch.ProfileBasedOptionEnabled = base.Config.Bind("Game", "ProfileBasedOption", defaultValue: false, "Profile-based option");
		GamePatch.DefaultProfileName = base.Config.Bind("Game", "DefaultProfileName", "Default", "Default profile name, used when profile-based save folder is enabled. Use original game save folder if matched");
		GamePatch.ConvertSavesFromPeaceEnabled = base.Config.Bind("Game", "ConvertSavesFromPeace", defaultValue: false, "Convert saves from Peace mode to Combat mode on save loading");
		GamePatch.GameUpsFactor = _dummyConfig.Bind("Game", "GameUpsFactor", 1.0, "Game UPS factor (1.0 for normal speed)");
		WindowFunctions.ProcessPriority = base.Config.Bind("Game", "ProcessPriority", 2, new ConfigDescription("Game process priority\n  0: High  1: Above Normal  2: Normal  3: Below Normal  4: Idle", new AcceptableValueRange<int>(0, 4)));
		FactoryPatch.UnlimitInteractiveEnabled = base.Config.Bind("Factory", "UnlimitInteractive", defaultValue: false, "Unlimit interactive range");
		FactoryPatch.RemoveSomeConditionEnabled = base.Config.Bind("Factory", "RemoveSomeBuildConditionCheck", defaultValue: false, "Remove part of build condition checks that does not affect game logic");
		FactoryPatch.NightLightEnabled = base.Config.Bind("Factory", "NightLight", defaultValue: false, "Night light");
		FactoryPatch.NightLightAngleX = base.Config.Bind("Factory", "NightLightAngleX", -8f, "Night light angle X");
		FactoryPatch.NightLightAngleY = base.Config.Bind("Factory", "NightLightAngleY", -2f, "Night light angle Y");
		PlanetPatch.PlayerActionsInGlobeViewEnabled = base.Config.Bind("Planet", "PlayerActionsInGlobeView", defaultValue: false, "Enable player actions in globe view");
		PlanetFunctions.ReturnBuildingsOnInitializeEnabled = base.Config.Bind("Planet", "ReturnBuildingsOnInitialize", defaultValue: false, "Return buildings to player when initializing planet");
		PlanetFunctions.ReturnLogisticStorageItemsOnInitializeEnabled = base.Config.Bind("Planet", "ReturnLogisticStorageItemsOnInitialize", defaultValue: false, "Return logistic storage items to player when initializing planet");
		PlanetFunctions.ReturnBeltAFactoryItemsOnInitializeEnabled = base.Config.Bind("Planet", "ReturnBeltAFactoryItemsOnInitialize", defaultValue: false, "Return belt and factory items to player when initializing planet");
		FactoryPatch.RemoveBuildRangeLimitEnabled = base.Config.Bind("Factory", "RemoveBuildRangeLimit", defaultValue: false, "Remove limit for build range and maximum count of drag building belts/buildings\nNote: this does not affect range limit for mecha drones' action");
		FactoryPatch.LargerAreaForUpgradeAndDismantleEnabled = base.Config.Bind("Factory", "LargerAreaForUpgradeAndDismantle", defaultValue: false, "Increase maximum area size for upgrade and dismantle to 31x31 (from 11x11)");
		FactoryPatch.LargerAreaForTerraformEnabled = base.Config.Bind("Factory", "LargerAreaForTerraform", defaultValue: false, "Increase maximum area size for terraform to 30x30 (from 10x10)\nNote: this may impact game performance while using large area");
		FactoryPatch.OffGridBuildingEnabled = base.Config.Bind("Factory", "OffGridBuilding", defaultValue: false, "Enable off grid building and stepped rotation");
		FactoryPatch.TreatStackingAsSingleEnabled = base.Config.Bind("Factory", "TreatStackingAsSingle", defaultValue: false, "Treat stack items as single in monitor components");
		FactoryPatch.QuickBuildAndDismantleLabsEnabled = base.Config.Bind("Factory", "QuickBuildAndDismantleLab", defaultValue: false, "Quick build and dismantle stacking labs");
		FactoryPatch.ProtectVeinsFromExhaustionEnabled = base.Config.Bind("Factory", "ProtectVeinsFromExhaustion", defaultValue: false, "Protect veins from exhaustion");
		VeinProtectionPatch.ProtectVeinsFromExhaustion.KeepVeinAmount = base.Config.Bind("Factory", "KeepVeinAmount", 1000, new ConfigDescription("Keep veins amount (0 to disable)", new AcceptableValueRange<int>(0, 10000))).Value;
		VeinProtectionPatch.ProtectVeinsFromExhaustion.KeepOilSpeed = base.Config.Bind("Factory", "KeepOilSpeed", 1f, new ConfigDescription("Keep minimal oil speed (< 0.1 to disable)", new AcceptableValueRange<float>(0f, 10f))).Value;
		FactoryPatch.DoNotRenderEntitiesEnabled = base.Config.Bind("Factory", "DoNotRenderEntities", defaultValue: false, "Do not render factory entities");
		FactoryPatch.DoNotRenderEntitiesHideSortersEnabled = base.Config.Bind("Factory", "DoNotRenderEntitiesHideSorters", defaultValue: false, "Hide sorters too when not rendering factory entities (leaves only belts visible)");
		FactoryPatch.DragBuildPowerPolesEnabled = base.Config.Bind("Factory", "DragBuildPowerPoles", defaultValue: false, "Drag building power poles in maximum connection range");
		FactoryPatch.DragBuildPowerPolesAlternatelyEnabled = base.Config.Bind("Factory", "DragBuildPowerPolesAlternately", defaultValue: true, "Build Tesla Tower and Wireless Power Tower alternately");
		FactoryPatch.AutoConstructButtonEnabled = base.Config.Bind("Factory", "AutoConstructButton", defaultValue: false, "Enable auto-construct button");
		FactoryPatch.AutoConstructEnabled = base.Config.Bind("Factory", "AutoConstruct", defaultValue: false, "Fly toward the building to be constructed automatically");
		FactoryPatch.BeltSignalsForBuyOutEnabled = base.Config.Bind("Factory", "BeltSignalsForBuyOut", defaultValue: false, "Belt signals for buy out dark fog items automatically");
		FactoryPatch.TankFastFillInAndTakeOutEnabled = base.Config.Bind("Factory", "TankFastFillInAndTakeOut", defaultValue: false, "Fast fill in to and take out from tanks");
		FactoryPatch.TankFastFillInAndTakeOutMultiplier = base.Config.Bind("Factory", "TankFastFillInAndTakeOutMultiplier", 1000, "Speed multiplier for fast filling in to and takeing out from tanks");
		FactoryPatch.CutConveyorBeltEnabled = base.Config.Bind("Factory", "CutConveyorBeltShortcut", defaultValue: false, "Cut conveyor belt (with shortcut key)");
		FactoryPatch.TweakBuildingBufferEnabled = base.Config.Bind("Factory", "TweakBuildingBuffer", defaultValue: false, "Tweak buffer count for assemblers and power generators");
		FactoryPatch.AssemblerBufferTimeMultiplier = base.Config.Bind("Factory", "AssemblerBufferTimeMultiplier", 4, new ConfigDescription("Assembler buffer time multiplier in seconds", new AcceptableValueRange<int>(2, 10)));
		FactoryPatch.AssemblerBufferMininumMultiplier = base.Config.Bind("Factory", "AssemblerBufferMininumMultiplier", 4, new ConfigDescription("Assembler buffer minimum multiplier", new AcceptableValueRange<int>(2, 10)));
		FactoryPatch.LabBufferMaxCountForAssemble = base.Config.Bind("Factory", "LabBufferMaxCountForAssemble", 6, new ConfigDescription("Buffer count for assembling in labs", new AcceptableValueRange<int>(2, 20)));
		FactoryPatch.LabBufferExtraCountForAdvancedAssemble = base.Config.Bind("Factory", "LabBufferExtraCountForAdvancedAssemble", 3, new ConfigDescription("Extra buffer count for Self-evolution Labs", new AcceptableValueRange<int>(1, 10)));
		FactoryPatch.LabBufferMaxCountForResearch = base.Config.Bind("Factory", "LabBufferMaxCountForResearch", 10, new ConfigDescription("Buffer count for researching in labs", new AcceptableValueRange<int>(2, 20)));
		FactoryPatch.ReceiverBufferCount = base.Config.Bind("Factory", "ReceiverBufferCount", 1, new ConfigDescription("Ray Receiver Graviton Lens buffer count", new AcceptableValueRange<int>(1, 20)));
		FactoryPatch.EjectorBufferCount = base.Config.Bind("Factory", "EjectorBufferCount", 1, new ConfigDescription("Ejector buffer count", new AcceptableValueRange<int>(5, 400)));
		FactoryPatch.SiloBufferCount = base.Config.Bind("Factory", "SiloBufferCount", 1, new ConfigDescription("Silo buffer count", new AcceptableValueRange<int>(1, 40)));
		FactoryPatch.ShortcutKeysForBlueprintCopyEnabled = base.Config.Bind("Factory", "DismantleBlueprintSelection", defaultValue: false, "Dismantle blueprint selected buildings");
		FactoryPatch.PressShiftToTakeWholeBeltItemsEnabled = base.Config.Bind("Factory", "PressShiftToTakeWholeBeltItems", defaultValue: false, "Ctrl+Shift+Click to pick items from whole belts");
		FactoryPatch.PressShiftToTakeWholeBeltItemsIncludeBranches = base.Config.Bind("Factory", "PressShiftToTakeWholeBeltItemsIncludeBranches", defaultValue: false, "Include branches of belts");
		FactoryPatch.PressShiftToTakeWholeBeltItemsIncludeInserters = base.Config.Bind("Factory", "PressShiftToTakeWholeBeltItemsIncludeInserters", defaultValue: false, "Include connected inserters");
		LogisticsPatch.AutoConfigLogisticsEnabled = base.Config.Bind("Factory", "AutoConfigLogistics", defaultValue: false, "Auto-config logistic stations");
		LogisticsPatch.AutoConfigLimitAutoReplenishCount = base.Config.Bind("Factory", "AutoConfigLimitAutoReplenishCount", defaultValue: false, "Limit auto-replenish count to config values");
		LogisticsPatch.SetDefaultRemoteLogicToStorage = base.Config.Bind("Factory", "AutoConfigSetDefaultRemoteLogicToStorage", defaultValue: false, "Set default remote logic to storage");
		LogisticsPatch.AutoConfigDispenserChargePower = base.Config.Bind("Factory", "AutoConfigDispenserChargePower", 30, new ConfigDescription("LD: Max. Charging Power", new AcceptableValueRange<int>(3, 30)));
		LogisticsPatch.AutoConfigDispenserCourierCount = base.Config.Bind("Factory", "AutoConfigDispenserCourierCount", 10, new ConfigDescription("LD: Count of Bots filled", new AcceptableValueRange<int>(0, 10)));
		LogisticsPatch.AutoConfigBattleBaseChargePower = base.Config.Bind("Factory", "AutoConfigBattleBaseChargePower", 8, new ConfigDescription("Battlefield Analysis Base: Max. Charging Power", new AcceptableValueRange<int>(4, 40)));
		LogisticsPatch.AutoConfigPLSChargePower = base.Config.Bind("Factory", "AutoConfigPLSChargePower", 4, new ConfigDescription("PLS: Max. Charging Power", new AcceptableValueRange<int>(2, 20)));
		LogisticsPatch.AutoConfigPLSMaxTripDrone = base.Config.Bind("Factory", "AutoConfigPLSMaxTripDrone", 180, new ConfigDescription("PLS: Drone transport range", new AcceptableValueRange<int>(1, 180)));
		LogisticsPatch.AutoConfigPLSDroneMinDeliver = base.Config.Bind("Factory", "AutoConfigPLSDroneMinDeliver", 10, new ConfigDescription("PLS: Min. Load of Drones", new AcceptableValueRange<int>(0, 10)));
		LogisticsPatch.AutoConfigPLSMinPilerValue = base.Config.Bind("Factory", "AutoConfigPLSMinPilerValue", 0, new ConfigDescription("PLS: Outgoing integration count", new AcceptableValueRange<int>(0, 4)));
		LogisticsPatch.AutoConfigPLSDroneCount = base.Config.Bind("Factory", "AutoConfigPLSDroneCount", 10, new ConfigDescription("PLS: Count of Drones filled", new AcceptableValueRange<int>(0, 50)));
		LogisticsPatch.AutoConfigILSChargePower = base.Config.Bind("Factory", "AutoConfigILSChargePower", 4, new ConfigDescription("ILS: Max. Charging Power", new AcceptableValueRange<int>(2, 20)));
		LogisticsPatch.AutoConfigILSMaxTripDrone = base.Config.Bind("Factory", "AutoConfigILSMaxTripDrone", 180, new ConfigDescription("ILS: Drone transport range", new AcceptableValueRange<int>(1, 180)));
		LogisticsPatch.AutoConfigILSMaxTripShip = base.Config.Bind("Factory", "AutoConfigILSMaxTripShip", 41, new ConfigDescription("ILS: Vessel transport range", new AcceptableValueRange<int>(1, 41)));
		LogisticsPatch.AutoConfigILSWarperDistance = base.Config.Bind("Factory", "AutoConfigILSWarperDistance", 16, new ConfigDescription("ILS: Warp distance", new AcceptableValueRange<int>(2, 21)));
		LogisticsPatch.AutoConfigILSDroneMinDeliver = base.Config.Bind("Factory", "AutoConfigILSDroneMinDeliver", 10, new ConfigDescription("ILS: Min. Load of Drones", new AcceptableValueRange<int>(0, 10)));
		LogisticsPatch.AutoConfigILSShipMinDeliver = base.Config.Bind("Factory", "AutoConfigILSShipMinDeliver", 10, new ConfigDescription("ILS: Min. Load of Vessels", new AcceptableValueRange<int>(0, 10)));
		LogisticsPatch.AutoConfigILSMinPilerValue = base.Config.Bind("Factory", "AutoConfigILSMinPilerValue", 0, new ConfigDescription("ILS: Outgoing integration count", new AcceptableValueRange<int>(0, 4)));
		LogisticsPatch.AutoConfigILSIncludeOrbitCollector = base.Config.Bind("Factory", "AutoConfigILSIncludeOrbitCollector", defaultValue: true, "ILS: Include Orbital Collector");
		LogisticsPatch.AutoConfigILSWarperNecessary = base.Config.Bind("Factory", "AutoConfigILSWarperNecessary", defaultValue: true, "ILS: Warpers required");
		LogisticsPatch.AutoConfigILSDroneCount = base.Config.Bind("Factory", "AutoConfigILSDroneCount", 20, new ConfigDescription("ILS: Count of Drones filled", new AcceptableValueRange<int>(0, 100)));
		LogisticsPatch.AutoConfigILSShipCount = base.Config.Bind("Factory", "AutoConfigILSShipCount", 10, new ConfigDescription("ILS: Count of Vessels filled", new AcceptableValueRange<int>(0, 10)));
		LogisticsPatch.AutoConfigVeinCollectorHarvestSpeed = base.Config.Bind("Factory", "AutoConfigVeinCollectorHarvestSpeed", 20, new ConfigDescription("AMM: Collecting Speed", new AcceptableValueRange<int>(0, 20)));
		LogisticsPatch.AutoConfigVeinCollectorMinPilerValue = base.Config.Bind("Factory", "AutoConfigVeinCollectorMinPilerValue", 0, new ConfigDescription("AMM: Outgoing integration count", new AcceptableValueRange<int>(0, 4)));
		LogisticsPatch.OrbitalCollectorProductLimit = base.Config.Bind("Factory", "OrbitalCollectorProductLimit", 20000, new ConfigDescription("Orbital Collector product limit", new AcceptableValueRange<int>(1, 999999)));
		LogisticsPatch.LogisticsCapacityTweaksEnabled = base.Config.Bind("Factory", "LogisticsCapacityTweaks", defaultValue: true, "Logistics capacity related tweaks");
		LogisticsPatch.AllowOverflowInLogisticsEnabled = base.Config.Bind("Factory", "AllowOverflowInLogistics", defaultValue: false, "Allow overflow in logistic stations");
		LogisticsPatch.GreaterPowerUsageInLogisticsEnabled = base.Config.Bind("Build", "GreaterPowerUsageInLogistics", defaultValue: false, "Increase maximum power usage in Logistic Stations and Advanced Mining Machines");
		LogisticsPatch.LogisticsConstrolPanelImprovementEnabled = base.Config.Bind("Factory", "LogisticsConstrolPanelImprovement", defaultValue: false, "Logistics control panel improvement");
		LogisticsPatch.RealtimeLogisticsInfoPanelEnabled = base.Config.Bind("Factory", "RealtimeLogisticsInfoPanel", defaultValue: false, "Realtime logistics info panel");
		LogisticsPatch.RealtimeLogisticsInfoPanelBarsEnabled = base.Config.Bind("Factory", "RealtimeLogisticsInfoPanelBars", defaultValue: false, "Realtime logistics info panel - Show status bars for storage item");
		PlanetFunctions.OrbitalCollectorMaxBuildCount = base.Config.Bind("Factory", "OCMaxBuildCount", 0, "Maximum Orbital Collectors to build once, set to 0 to build as many as possible");
		PlayerPatch.EnhancedMechaForgeCountControlEnabled = base.Config.Bind("Player", "EnhancedMechaForgeCountControl", defaultValue: false, "Enhanced count control for hand-make, increases maximum of count to 1000, and you can hold Ctrl/Shift/Alt to change the count rapidly");
		PlayerPatch.HideTipsForSandsChangesEnabled = base.Config.Bind("Player", "HideTipsForGettingSands", defaultValue: false, "Hide tips for getting soil piles");
		PlayerPatch.ShortcutKeysForStarsNameEnabled = base.Config.Bind("Player", "ShortcutKeysForStarsName", defaultValue: false, "Shortcut keys for showing stars' name");
		TechPatch.SorterCargoStackingEnabled = base.Config.Bind("Tech", "SorterCargoStacking", defaultValue: false, "Restore upgrades of `Sorter Cargo Stacking` on panel");
		TechPatch.DisableBattleRelatedTechsInPeaceModeEnabled = base.Config.Bind("Tech", "DisableBattleRelatedTechsInPeaceMode", defaultValue: false, "Disable battle-related techs in Peace mode");
		TechPatch.BatchBuyoutTechEnabled = base.Config.Bind("Tech", "BatchBuyoutTech", defaultValue: false, "Can buy out techs with their prerequisites");
		DysonSpherePatch.StopEjectOnNodeCompleteEnabled = base.Config.Bind("DysonSphere", "StopEjectOnNodeComplete", defaultValue: false, "Stop ejectors when available nodes are all filled up");
		DysonSpherePatch.OnlyConstructNodesEnabled = base.Config.Bind("DysonSphere", "OnlyConstructNodes", defaultValue: false, "Construct only nodes but frames");
		DysonSpherePatch.AutoConstructMultiplier = base.Config.Bind("DysonSphere", "AutoConstructMultiplier", 1, "Dyson Sphere auto-construct speed multiplier");
		UIPatch.PlanetVeinUtilizationEnabled = base.Config.Bind("UI", "PlanetVeinUtilization", defaultValue: false, "Planet vein utilization");
		PlayerPatch.AutoNavigation.Awake(base.Config);
		I18N.Init();
		I18NKeys.Register();
		PatchImpl<global::UXAssist.Common.GameLogic>.Enable(enable: true);
		UIConfigWindow.Init();
		_patches = global::UXAssist.Common.Util.GetTypesFiltered(Assembly.GetExecutingAssembly(), (Type t) => (string.Equals(t.Namespace, "UXAssist.Patches", StringComparison.Ordinal) || string.Equals(t.Namespace, "UXAssist.Functions", StringComparison.Ordinal)) && !Attribute.IsDefined(t, typeof(ModFeatureAttribute)));
		_patches?.Do(delegate(Type type)
		{
			type.GetMethod("Init")?.Invoke(null, null);
		});
		_compats = global::UXAssist.Common.Util.GetTypesInNamespace(Assembly.GetExecutingAssembly(), "UXAssist.ModsCompat");
		object[] parameters = new object[1] { _harmony };
		_compats?.Do(delegate(Type type)
		{
			type.GetMethod("Init")?.Invoke(null, parameters);
		});
		ModFeatureRegistry.Discover(Assembly.GetExecutingAssembly());
		I18N.Apply();
	}

	private void Start()
	{
		MyWindowManager.InitBaseObjects();
		MyWindowManager.Enable(on: true);
		ModFeatureRegistry.StartAll();
		_patches?.Do(delegate(Type type)
		{
			type.GetMethod("Start")?.Invoke(null, null);
		});
		object[] parameters = new object[1] { _harmony };
		_compats?.Do(delegate(Type type)
		{
			type.GetMethod("Start")?.Invoke(null, parameters);
		});
	}

	private void OnDestroy()
	{
		ModFeatureRegistry.UninitAll();
		_patches?.Do(delegate(Type type)
		{
			type.GetMethod("Uninit")?.Invoke(null, null);
		});
		MyWindowManager.Enable(on: false);
		PatchImpl<global::UXAssist.Common.GameLogic>.Enable(enable: false);
	}

	internal static void OnInputUpdate()
	{
		if (!VFInput.inputing)
		{
			ModFeatureRegistry.OnInputUpdateAll();
			if (!DSPGame.IsMenuDemo)
			{
				GamePatch.OnInputUpdate();
				PlayerPatch.OnInputUpdate();
			}
		}
	}

	private void Update()
	{
		if (!VFInput.inputing && !DSPGame.IsMenuDemo)
		{
			ModFeatureRegistry.OnUpdateAll();
		}
	}
}
