using System;
using BepInEx.Configuration;
using UXAssist.Common;
using UXAssist.Common.ModFeatures;

namespace UXAssist.Patches.Logistics;

[ModFeature("Logistics", Order = 11)]
public static class LogisticsPatch
{
	private enum StationKind
	{
		Pls,
		Ils,
		VeinCollector
	}

	public static ConfigEntry<bool> AutoConfigLogisticsEnabled;

	public static ConfigEntry<bool> AutoConfigLimitAutoReplenishCount;

	public static ConfigEntry<int> AutoConfigDispenserChargePower;

	public static ConfigEntry<int> AutoConfigDispenserCourierCount;

	public static ConfigEntry<int> AutoConfigBattleBaseChargePower;

	public static ConfigEntry<int> AutoConfigPLSChargePower;

	public static ConfigEntry<int> AutoConfigPLSMaxTripDrone;

	public static ConfigEntry<int> AutoConfigPLSDroneMinDeliver;

	public static ConfigEntry<int> AutoConfigPLSMinPilerValue;

	public static ConfigEntry<int> AutoConfigPLSDroneCount;

	public static ConfigEntry<bool> SetDefaultRemoteLogicToStorage;

	public static ConfigEntry<int> AutoConfigILSChargePower;

	public static ConfigEntry<int> AutoConfigILSMaxTripDrone;

	public static ConfigEntry<int> AutoConfigILSMaxTripShip;

	public static ConfigEntry<int> AutoConfigILSWarperDistance;

	public static ConfigEntry<int> AutoConfigILSDroneMinDeliver;

	public static ConfigEntry<int> AutoConfigILSShipMinDeliver;

	public static ConfigEntry<int> AutoConfigILSMinPilerValue;

	public static ConfigEntry<bool> AutoConfigILSIncludeOrbitCollector;

	public static ConfigEntry<bool> AutoConfigILSWarperNecessary;

	public static ConfigEntry<int> AutoConfigILSDroneCount;

	public static ConfigEntry<int> AutoConfigILSShipCount;

	public static ConfigEntry<int> AutoConfigVeinCollectorHarvestSpeed;

	public static ConfigEntry<int> AutoConfigVeinCollectorMinPilerValue;

	public static ConfigEntry<int> OrbitalCollectorProductLimit;

	public static ConfigEntry<bool> LogisticsCapacityTweaksEnabled;

	public static ConfigEntry<bool> AllowOverflowInLogisticsEnabled;

	public static ConfigEntry<bool> GreaterPowerUsageInLogisticsEnabled;

	public static ConfigEntry<bool> LogisticsConstrolPanelImprovementEnabled;

	public static ConfigEntry<bool> RealtimeLogisticsInfoPanelEnabled;

	public static ConfigEntry<bool> RealtimeLogisticsInfoPanelBarsEnabled;

	public static void Init()
	{
		AutoConfigLogisticsEnabled.SettingChanged += delegate
		{
			PatchImpl<AutoConfigLogistics>.Enable(AutoConfigLogisticsEnabled.Value);
		};
		AutoConfigLimitAutoReplenishCount.SettingChanged += delegate
		{
			AutoConfigLogistics.ToggleLimitAutoReplenishCount();
		};
		SetDefaultRemoteLogicToStorage.SettingChanged += delegate
		{
			PatchImpl<AutoConfigLogisticsSetDefaultRemoteLogicToStorage>.Enable(SetDefaultRemoteLogicToStorage.Value);
		};
		LogisticsCapacityTweaksEnabled.SettingChanged += delegate
		{
			PatchImpl<LogisticsCapacityTweaks>.Enable(LogisticsCapacityTweaksEnabled.Value);
		};
		AllowOverflowInLogisticsEnabled.SettingChanged += delegate
		{
			PatchImpl<AllowOverflowInLogistics>.Enable(AllowOverflowInLogisticsEnabled.Value);
		};
		GreaterPowerUsageInLogisticsEnabled.SettingChanged += delegate
		{
			PatchImpl<GreaterPowerUsageInLogistics>.Enable(GreaterPowerUsageInLogisticsEnabled.Value);
		};
		LogisticsConstrolPanelImprovementEnabled.SettingChanged += delegate
		{
			PatchImpl<LogisticsConstrolPanelImprovement>.Enable(LogisticsConstrolPanelImprovementEnabled.Value);
		};
		RealtimeLogisticsInfoPanelEnabled.SettingChanged += delegate
		{
			RealtimeLogisticsInfoPanel.Enable(RealtimeLogisticsInfoPanelEnabled.Value);
		};
		RealtimeLogisticsInfoPanelBarsEnabled.SettingChanged += delegate
		{
			RealtimeLogisticsInfoPanel.EnableBars(RealtimeLogisticsInfoPanelBarsEnabled.Value);
		};
	}

	public static void Start()
	{
		PatchImpl<AutoConfigLogistics>.Enable(AutoConfigLogisticsEnabled.Value);
		PatchImpl<AutoConfigLogisticsSetDefaultRemoteLogicToStorage>.Enable(SetDefaultRemoteLogicToStorage.Value);
		PatchImpl<LogisticsCapacityTweaks>.Enable(LogisticsCapacityTweaksEnabled.Value);
		PatchImpl<AllowOverflowInLogistics>.Enable(AllowOverflowInLogisticsEnabled.Value);
		PatchImpl<GreaterPowerUsageInLogistics>.Enable(GreaterPowerUsageInLogisticsEnabled.Value);
		PatchImpl<LogisticsConstrolPanelImprovement>.Enable(LogisticsConstrolPanelImprovementEnabled.Value);
		RealtimeLogisticsInfoPanel.Enable(RealtimeLogisticsInfoPanelEnabled.Value);
		RealtimeLogisticsInfoPanel.EnableBars(RealtimeLogisticsInfoPanelBarsEnabled.Value);
		global::UXAssist.Common.GameLogic.OnGameBegin = (Action)Delegate.Combine(global::UXAssist.Common.GameLogic.OnGameBegin, new Action(RealtimeLogisticsInfoPanel.OnGameBegin));
		global::UXAssist.Common.GameLogic.OnGameEnd = (Action)Delegate.Combine(global::UXAssist.Common.GameLogic.OnGameEnd, new Action(RealtimeLogisticsInfoPanel.OnGameEnd));
		global::UXAssist.Common.GameLogic.OnDataLoaded = (Action)Delegate.Combine(global::UXAssist.Common.GameLogic.OnDataLoaded, new Action(RealtimeLogisticsInfoPanel.OnDataLoaded));
	}

	public static void Uninit()
	{
		global::UXAssist.Common.GameLogic.OnDataLoaded = (Action)Delegate.Remove(global::UXAssist.Common.GameLogic.OnDataLoaded, new Action(RealtimeLogisticsInfoPanel.OnDataLoaded));
		global::UXAssist.Common.GameLogic.OnGameEnd = (Action)Delegate.Remove(global::UXAssist.Common.GameLogic.OnGameEnd, new Action(RealtimeLogisticsInfoPanel.OnGameEnd));
		global::UXAssist.Common.GameLogic.OnGameBegin = (Action)Delegate.Remove(global::UXAssist.Common.GameLogic.OnGameBegin, new Action(RealtimeLogisticsInfoPanel.OnGameBegin));
		PatchImpl<AutoConfigLogistics>.Enable(enable: false);
		PatchImpl<AutoConfigLogisticsSetDefaultRemoteLogicToStorage>.Enable(enable: false);
		PatchImpl<LogisticsCapacityTweaks>.Enable(enable: false);
		PatchImpl<AllowOverflowInLogistics>.Enable(enable: false);
		PatchImpl<GreaterPowerUsageInLogistics>.Enable(enable: false);
		PatchImpl<LogisticsConstrolPanelImprovement>.Enable(enable: false);
		RealtimeLogisticsInfoPanel.Enable(on: false);
	}

	public static void OnInputUpdate()
	{
		if (!DSPGame.IsMenuDemo && VFInput.onGUI && LogisticsCapacityTweaksEnabled.Value)
		{
			LogisticsCapacityTweaks.UpdateInput();
		}
	}

	internal static void StationSetChargePower(PlanetFactory factory, StationComponent station)
	{
		factory.powerSystem.consumerPool[station.pcId].workEnergyPerTick = (long)((station.isStellar ? (250000.0 * (double)AutoConfigILSChargePower.Value) : (50000.0 * (double)AutoConfigPLSChargePower.Value)) + 0.5);
	}

	internal static void StationSetTripRangeDrones(PlanetFactory factory, StationComponent station)
	{
		station.tripRangeDrones = Math.Cos((double)(station.isStellar ? AutoConfigILSMaxTripDrone.Value : AutoConfigPLSMaxTripDrone.Value) / 180.0 * Math.PI);
	}

	internal static void StationSetDeliveryDrones(PlanetFactory factory, StationComponent station)
	{
		int num = (station.isStellar ? AutoConfigILSDroneMinDeliver.Value : AutoConfigPLSDroneMinDeliver.Value);
		station.deliveryDrones = ((num == 0) ? 1 : (num * 10));
	}

	internal static void StationSetPilerCount(PlanetFactory factory, StationComponent station)
	{
		station.pilerCount = (station.isStellar ? AutoConfigILSMinPilerValue.Value : AutoConfigPLSMinPilerValue.Value);
	}

	internal static void StationFillDrones(PlanetFactory factory, StationComponent station)
	{
		if (factory != null && GameMain.mainPlayer != null && GameMain.mainPlayer.factory == factory && station?.workDroneDatas != null)
		{
			int num = MissingWorkers(station.isStellar ? AutoConfigILSDroneCount.Value : AutoConfigPLSDroneCount.Value, station.workDroneDatas.Length, station.idleDroneCount, station.workDroneCount);
			if (num > 0)
			{
				station.idleDroneCount += GameMain.data.mainPlayer.package.TakeItem(5001, num, out var _);
			}
		}
	}

	internal static void StationSetTripRangeShips(PlanetFactory factory, StationComponent station)
	{
		int value = AutoConfigILSMaxTripShip.Value;
		int num = ((value <= 20) ? AutoConfigILSMaxTripShip.Value : ((value > 40) ? 10000 : (AutoConfigILSMaxTripShip.Value * 2 - 20)));
		station.tripRangeShips = (double)num * 2400000.0;
	}

	internal static void StationSetWarpDistance(PlanetFactory factory, StationComponent station)
	{
		int value = AutoConfigILSWarperDistance.Value;
		double num = ((value <= 16) ? ((value > 7) ? ((double)AutoConfigILSWarperDistance.Value - 4.0) : ((double)AutoConfigILSWarperDistance.Value * 0.5 - 0.5)) : ((value > 20) ? 60.0 : ((double)(AutoConfigILSWarperDistance.Value * 2) - 20.0)));
		station.warpEnableDist = num * 40000.0;
	}

	internal static void StationSetDeliveryShips(PlanetFactory factory, StationComponent station)
	{
		int value = AutoConfigILSShipMinDeliver.Value;
		station.deliveryShips = ((value == 0) ? 1 : (value * 10));
	}

	internal static void StationFillShips(PlanetFactory factory, StationComponent station)
	{
		if (factory != null && GameMain.mainPlayer != null && GameMain.mainPlayer.factory == factory && station?.workShipDatas != null)
		{
			int num = MissingWorkers(AutoConfigILSShipCount.Value, Math.Min(64, station.workShipDatas.Length), station.idleShipCount, station.workShipCount);
			if (num > 0)
			{
				station.idleShipCount += GameMain.data.mainPlayer.package.TakeItem(5002, num, out var _);
			}
		}
	}

	internal static void StationSetIncludeOrbitCollector(PlanetFactory factory, StationComponent station)
	{
		station.includeOrbitCollector = AutoConfigILSIncludeOrbitCollector.Value;
	}

	internal static void StationSetWarperNecessary(PlanetFactory factory, StationComponent station)
	{
		station.warperNecessary = AutoConfigILSWarperNecessary.Value;
	}

	internal static bool VeinCollectorSetHarvestSpeed(PlanetFactory factory, StationComponent station)
	{
		ref EntityData reference = ref factory.entityPool[station.entityId];
		if (reference.id != station.entityId || reference.minerId <= 0 || reference.minerId >= factory.factorySystem.minerCursor)
		{
			return false;
		}
		factory.factorySystem.minerPool[reference.minerId].speed = 10000 + AutoConfigVeinCollectorHarvestSpeed.Value * 1000;
		return true;
	}

	internal static void VeinCollectorSetPilerCount(PlanetFactory factory, StationComponent station)
	{
		station.pilerCount = AutoConfigVeinCollectorMinPilerValue.Value;
	}

	internal static void DispenserSetChargePower(PlanetFactory factory, DispenserComponent dispenser)
	{
		factory.powerSystem.consumerPool[dispenser.pcId].workEnergyPerTick = (long)(5000.0 * (double)AutoConfigDispenserChargePower.Value + 0.5);
	}

	internal static void DispenserFillCouriers(PlanetFactory factory, DispenserComponent dispenser)
	{
		if (factory != null && GameMain.mainPlayer != null && GameMain.mainPlayer.factory == factory && dispenser?.workCourierDatas != null)
		{
			int num = MissingWorkers(AutoConfigDispenserCourierCount.Value, dispenser.workCourierDatas.Length, dispenser.idleCourierCount, dispenser.workCourierCount);
			if (num > 0)
			{
				dispenser.idleCourierCount += GameMain.data.mainPlayer.package.TakeItem(5003, num, out var _);
			}
		}
	}

	internal static int MissingWorkers(int target, int capacity, int idle, int working)
	{
		if (idle >= 0 && working >= 0)
		{
			return (int)Math.Max(0L, (long)Math.Max(0, Math.Min(target, capacity)) - (long)idle - working);
		}
		return 0;
	}

	internal static void BattleBaseSetChargePower(PlanetFactory factory, BattleBaseComponent battleBase)
	{
		factory.powerSystem.consumerPool[battleBase.pcId].workEnergyPerTick = (long)(5000.0 * (double)AutoConfigBattleBaseChargePower.Value + 0.5);
	}

	internal static void DoConfigStation(PlanetFactory factory, StationComponent station)
	{
		if (station.isCollector)
		{
			return;
		}
		if (station.isVeinCollector)
		{
			if (VeinCollectorSetHarvestSpeed(factory, station))
			{
				VeinCollectorSetPilerCount(factory, station);
			}
			return;
		}
		if (!station.isStellar)
		{
			StationSetChargePower(factory, station);
			StationSetTripRangeDrones(factory, station);
			StationSetDeliveryDrones(factory, station);
			StationSetPilerCount(factory, station);
			StationFillDrones(factory, station);
			return;
		}
		StationSetChargePower(factory, station);
		StationSetTripRangeDrones(factory, station);
		StationSetTripRangeShips(factory, station);
		StationSetWarpDistance(factory, station);
		StationSetDeliveryDrones(factory, station);
		StationSetDeliveryShips(factory, station);
		StationSetPilerCount(factory, station);
		StationSetIncludeOrbitCollector(factory, station);
		StationSetWarperNecessary(factory, station);
		StationFillDrones(factory, station);
		StationFillShips(factory, station);
	}

	private static void ForEachStation(StationKind kind, Action<PlanetFactory, StationComponent> action)
	{
		PlanetFactory planetFactory = GameMain.localPlanet?.factory;
		PlanetTransport planetTransport = planetFactory?.transport;
		StationComponent[] array = planetTransport?.stationPool;
		if (array == null)
		{
			return;
		}
		for (int num = planetTransport.stationCursor - 1; num > 0; num--)
		{
			StationComponent stationComponent = array[num];
			if (stationComponent != null && stationComponent.id == num && !stationComponent.isCollector && kind switch
			{
				StationKind.VeinCollector => (!stationComponent.isVeinCollector) ? 1 : 0, 
				StationKind.Ils => (stationComponent.isVeinCollector || !stationComponent.isStellar) ? 1 : 0, 
				StationKind.Pls => (stationComponent.isVeinCollector || stationComponent.isStellar) ? 1 : 0, 
				_ => 1, 
			} == 0)
			{
				action(planetFactory, stationComponent);
			}
		}
		RefreshOpenLogisticsWindows();
	}

	private static void ForEachDispenser(Action<PlanetFactory, DispenserComponent> action)
	{
		PlanetFactory planetFactory = GameMain.localPlanet?.factory;
		PlanetTransport planetTransport = planetFactory?.transport;
		DispenserComponent[] array = planetTransport?.dispenserPool;
		if (array == null)
		{
			return;
		}
		for (int num = planetTransport.dispenserCursor - 1; num > 0; num--)
		{
			DispenserComponent dispenserComponent = array[num];
			if (dispenserComponent != null && dispenserComponent.id == num)
			{
				action(planetFactory, dispenserComponent);
			}
		}
		RefreshOpenLogisticsWindows();
	}

	private static void ForEachBattleBase(Action<PlanetFactory, BattleBaseComponent> action)
	{
		PlanetFactory planetFactory = GameMain.localPlanet?.factory;
		ObjectPool<BattleBaseComponent> objectPool = planetFactory?.defenseSystem?.battleBases;
		if (objectPool?.buffer == null)
		{
			return;
		}
		for (int num = objectPool.cursor - 1; num > 0; num--)
		{
			BattleBaseComponent battleBaseComponent = objectPool.buffer[num];
			if (battleBaseComponent != null && battleBaseComponent.id == num)
			{
				action(planetFactory, battleBaseComponent);
			}
		}
		RefreshOpenLogisticsWindows();
	}

	internal static void RefreshOpenLogisticsWindows()
	{
		UIRoot instance = UIRoot.instance;
		if (!instance)
		{
			return;
		}
		UIGame uiGame = instance.uiGame;
		if ((bool)uiGame)
		{
			UIStationWindow stationWindow = uiGame.stationWindow;
			if ((bool)stationWindow && stationWindow.active)
			{
				stationWindow.OnStationIdChange();
			}
			UIDispenserWindow dispenserWindow = uiGame.dispenserWindow;
			if ((bool)dispenserWindow && dispenserWindow.active)
			{
				dispenserWindow.OnDispenserIdChange();
			}
			UIBattleBaseWindow battleBaseWindow = uiGame.battleBaseWindow;
			if ((bool)battleBaseWindow && battleBaseWindow.active)
			{
				battleBaseWindow.OnBattleBaseIdChange();
			}
		}
	}

	public static void ApplyDispenserChargePower()
	{
		ForEachDispenser(DispenserSetChargePower);
	}

	public static void ApplyDispenserCourierCount()
	{
		ForEachDispenser(DispenserFillCouriers);
	}

	public static void ApplyAllDispenser()
	{
		ForEachDispenser(delegate(PlanetFactory f, DispenserComponent d)
		{
			DispenserSetChargePower(f, d);
			DispenserFillCouriers(f, d);
		});
	}

	public static void ApplyBattleBaseChargePower()
	{
		ForEachBattleBase(BattleBaseSetChargePower);
	}

	public static void ApplyAllBattleBase()
	{
		ForEachBattleBase(BattleBaseSetChargePower);
	}

	public static void ApplyPLSChargePower()
	{
		ForEachStation(StationKind.Pls, StationSetChargePower);
	}

	public static void ApplyPLSTripRangeDrones()
	{
		ForEachStation(StationKind.Pls, StationSetTripRangeDrones);
	}

	public static void ApplyPLSDroneMinDeliver()
	{
		ForEachStation(StationKind.Pls, StationSetDeliveryDrones);
	}

	public static void ApplyPLSMinPilerValue()
	{
		ForEachStation(StationKind.Pls, StationSetPilerCount);
	}

	public static void ApplyPLSDroneCount()
	{
		ForEachStation(StationKind.Pls, StationFillDrones);
	}

	public static void ApplyAllPLS()
	{
		ForEachStation(StationKind.Pls, DoConfigStation);
	}

	public static void ApplyILSChargePower()
	{
		ForEachStation(StationKind.Ils, StationSetChargePower);
	}

	public static void ApplyILSTripRangeDrones()
	{
		ForEachStation(StationKind.Ils, StationSetTripRangeDrones);
	}

	public static void ApplyILSTripRangeShips()
	{
		ForEachStation(StationKind.Ils, StationSetTripRangeShips);
	}

	public static void ApplyILSWarpDistance()
	{
		ForEachStation(StationKind.Ils, StationSetWarpDistance);
	}

	public static void ApplyILSDroneMinDeliver()
	{
		ForEachStation(StationKind.Ils, StationSetDeliveryDrones);
	}

	public static void ApplyILSShipMinDeliver()
	{
		ForEachStation(StationKind.Ils, StationSetDeliveryShips);
	}

	public static void ApplyILSMinPilerValue()
	{
		ForEachStation(StationKind.Ils, StationSetPilerCount);
	}

	public static void ApplyILSDroneCount()
	{
		ForEachStation(StationKind.Ils, StationFillDrones);
	}

	public static void ApplyILSShipCount()
	{
		ForEachStation(StationKind.Ils, StationFillShips);
	}

	public static void ApplyILSIncludeOrbitCollector()
	{
		ForEachStation(StationKind.Ils, StationSetIncludeOrbitCollector);
	}

	public static void ApplyILSWarperNecessary()
	{
		ForEachStation(StationKind.Ils, StationSetWarperNecessary);
	}

	public static void ApplyAllILS()
	{
		ForEachStation(StationKind.Ils, DoConfigStation);
	}

	public static void ApplyVeinCollectorHarvestSpeed()
	{
		ForEachStation(StationKind.VeinCollector, delegate(PlanetFactory f, StationComponent s)
		{
			VeinCollectorSetHarvestSpeed(f, s);
		});
	}

	public static void ApplyVeinCollectorMinPilerValue()
	{
		ForEachStation(StationKind.VeinCollector, VeinCollectorSetPilerCount);
	}

	public static void ApplyAllVeinCollector()
	{
		ForEachStation(StationKind.VeinCollector, DoConfigStation);
	}

	public static void ApplyOrbitalCollectorProductLimitToUniverse()
	{
		GameData data = GameMain.data;
		PlanetFactory[] array = data?.factories;
		if (array == null)
		{
			return;
		}
		int value = OrbitalCollectorProductLimit.Value;
		for (int num = data.factoryCount - 1; num >= 0; num--)
		{
			PlanetTransport planetTransport = array[num]?.transport;
			StationComponent[] array2 = planetTransport?.stationPool;
			if (array2 != null)
			{
				for (int num2 = planetTransport.stationCursor - 1; num2 > 0; num2--)
				{
					StationComponent stationComponent = array2[num2];
					if (stationComponent != null && stationComponent.id == num2 && stationComponent.isCollector)
					{
						int val = stationComponent.storage.Length;
						int[] collectionIds = stationComponent.collectionIds;
						int num3 = Math.Min(val, (collectionIds != null) ? collectionIds.Length : 0);
						for (int i = 0; i < num3; i++)
						{
							stationComponent.storage[i].max = value;
						}
					}
				}
			}
		}
		RefreshOpenLogisticsWindows();
	}
}
