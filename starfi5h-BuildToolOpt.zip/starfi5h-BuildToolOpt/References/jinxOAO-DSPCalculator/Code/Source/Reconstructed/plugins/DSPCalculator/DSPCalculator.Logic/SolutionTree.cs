using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using DSPCalculator.Bp;
using MathNet.Numerics.LinearAlgebra;
using UnityEngine;

namespace DSPCalculator.Logic;

public class SolutionTree
{
	public UserPreference userPreference;

	public List<ItemTarget> targets;

	public List<ItemNode> root;

	public Dictionary<int, ItemNode> itemNodes;

	public Dictionary<int, RecipeInfo> recipeInfos;

	public List<ItemNode> nodeStack;

	public Dictionary<int, double> proliferatorCount;

	public Dictionary<int, double> proliferatorCountSelfSprayed;

	public bool tempNotShrinkRoot;

	public List<BpBeltInfo> beltsAvailable;

	public List<BpSorterInfo> sortersAvailable;

	public bool unsolved => nodeStack.Count > 0;

	public SolutionTree()
	{
		targets = new List<ItemTarget>();
		root = new List<ItemNode>();
		itemNodes = new Dictionary<int, ItemNode>();
		recipeInfos = new Dictionary<int, RecipeInfo>();
		nodeStack = new List<ItemNode>();
		proliferatorCount = new Dictionary<int, double>();
		proliferatorCountSelfSprayed = new Dictionary<int, double>();
		userPreference = new UserPreference();
		tempNotShrinkRoot = false;
	}

	public void ClearTree()
	{
		root.Clear();
		itemNodes.Clear();
		recipeInfos.Clear();
		nodeStack.Clear();
		proliferatorCount.Clear();
		proliferatorCountSelfSprayed.Clear();
	}

	public void ClearUserPreference()
	{
		userPreference = new UserPreference();
	}

	public bool SetTargetItem0AndBeginSolve(int targetItem)
	{
		ClearTree();
		if (targets.Count <= 0)
		{
			targets.Add(new ItemTarget(targetItem, 360.0));
		}
		else
		{
			targets[0].itemId = targetItem;
		}
		userPreference.ClearWhenChangeTarget();
		tempNotShrinkRoot = false;
		return Solve();
	}

	public bool ChangeTargetSpeed0AndSolve(double targetSpeed)
	{
		if (targets.Count <= 0)
		{
			targets.Add(new ItemTarget(0, 360.0));
		}
		else
		{
			targets[0].speed = targetSpeed;
		}
		ClearTree();
		userPreference.ClearWhenChangeTarget();
		tempNotShrinkRoot = false;
		return Solve();
	}

	public bool SetTargetAndSolve(int index, int targetItem, double targetSpeed)
	{
		if (AddOrUpdateTarget(index, targetItem, targetSpeed))
		{
			ClearTree();
			userPreference.ClearWhenChangeTarget();
			tempNotShrinkRoot = false;
			return Solve();
		}
		return false;
	}

	public bool AddOrUpdateTarget(int index, int targetItem, double targetSpeed)
	{
		if (targets.Count > index)
		{
			targets[index].itemId = targetItem;
			targets[index].speed = targetSpeed;
		}
		else
		{
			if (index != targets.Count)
			{
				Utils.logger.LogWarning("试图新增目标产物，但是新增的index不在targets列表末尾。");
				return false;
			}
			targets.Add(new ItemTarget(targetItem, targetSpeed));
		}
		return true;
	}

	public void MergeDuplicateTargets()
	{
		if (targets.Count <= 1)
		{
			return;
		}
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		List<ItemTarget> list = new List<ItemTarget>();
		for (int i = 0; i < targets.Count; i++)
		{
			int itemId = targets[i].itemId;
			double speed = targets[i].speed;
			if (!dictionary.ContainsKey(itemId))
			{
				dictionary[itemId] = list.Count;
				list.Add(new ItemTarget(itemId, speed));
			}
			else
			{
				int index = dictionary[itemId];
				list[index].speed += speed;
			}
		}
		targets = list;
	}

	public bool ReSolve(double forceSpeed)
	{
		ClearTree();
		if (forceSpeed > 0.0 && targets.Count > 0)
		{
			targets[0].speed = forceSpeed;
		}
		tempNotShrinkRoot = false;
		return Solve();
	}

	public bool ReSolveForRootShrinking(double newTargetSpeed)
	{
		ClearTree();
		targets[0].speed = newTargetSpeed;
		tempNotShrinkRoot = true;
		return Solve();
	}

	public bool Solve()
	{
		if (!RecipeUpdates.ValidateSelection(this))
		{
			return false;
		}
		MergeDuplicateTargets();
		if (targets.Count > 0)
		{
			RefreshBlueprintDicts();
			if (userPreference.solveProliferators)
			{
				for (int i = 0; i < CalcDB.proliferatorItemIds.Count; i++)
				{
					ItemNode node = new ItemNode(CalcDB.proliferatorItemIds[i], 0.0, this);
					Push(node);
				}
			}
			root.Clear();
			for (int j = 0; j < targets.Count; j++)
			{
				if (targets[j].itemId > 0)
				{
					ItemNode itemNode = new ItemNode(targets[j].itemId, targets[j].speed, this);
					root.Add(itemNode);
					Push(itemNode);
				}
			}
			if (root.Count <= 0)
			{
				return false;
			}
			if (SolvePath())
			{
				CalcTree();
				double num = RemoveOverflow();
				if (num > 0.0)
				{
					return ReSolveForRootShrinking(targets[0].speed * num);
				}
				CalcProliferator();
				if (userPreference.solveProliferators && !CalcProliferatorInProductLine())
				{
					return false;
				}
				return true;
			}
		}
		return false;
	}

	public bool SolvePath()
	{
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		for (int i = 0; i < targets.Count; i++)
		{
			dictionary[targets[i].itemId] = 1;
		}
		while (unsolved)
		{
			ItemNode itemNode = Pop();
			int itemId = itemNode.itemId;
			if (itemNodes.ContainsKey(itemId))
			{
				int unsolvedCount = itemNodes[itemId].unsolvedCount;
				if (unsolvedCount <= 0)
				{
					if (itemNode.parents.Count > 0)
					{
						itemNode.parents[0].SolveOne();
					}
					else if (dictionary.ContainsKey(itemNode.itemId))
					{
						itemNodes[itemNode.itemId].needSpeed += itemNode.needSpeed;
					}
					else if ((CalcDB.proliferatorItemIds.Contains(itemNode.itemId) && itemNode.needSpeed == 0.0) || itemNodes[itemNode.itemId].needSpeed == 0.0)
					{
						itemNodes[itemNode.itemId].needSpeed += itemNode.needSpeed;
					}
					else
					{
						Debug.LogWarning($"cur的parent为0，这不正常，出现在itemId={itemId}");
					}
					if (DSPCalculatorPlugin.developerMode)
					{
						int itemId2 = itemNode.parents[0].itemId;
						for (int j = 0; j < itemNodes[itemId].parents.Count; j++)
						{
							int itemId3 = itemNodes[itemId].parents[j].itemId;
							if (itemId3 == itemId2 && itemNodes[itemId].parents[j] != itemNode.parents[0])
							{
								Debug.LogWarning($"在解决itemId={itemId}时，引用了同一个父级itemId={itemId2}，但是不同的节点实例。");
							}
						}
					}
					if (DSPCalculatorPlugin.developerMode)
					{
						if (unsolvedCount < 0)
						{
							Debug.LogWarning($"unsolvedCount 出现了负数，这是一个不正常现象，出现在itemId={itemId}");
						}
						if (itemNode.parents.Count != 1)
						{
							Debug.LogWarning($"cur的parent不为1，这不正常，出现在itemId={itemId}");
						}
					}
					continue;
				}
				bool flag = false;
				while (itemNode.parents.Count > 0)
				{
					ItemNode itemNode2 = itemNode.parents[0];
					for (int num = itemNode2.children.Count - 1; num >= 0; num--)
					{
						ItemNode itemNode3 = itemNode2.children[num];
						if (itemNodes.ContainsKey(itemNode3.itemId) && itemNodes[itemNode3.itemId] == itemNode3)
						{
							if (itemNode3.unsolvedCount > 0)
							{
								itemNodes.Remove(itemNode3.itemId);
							}
							else
							{
								itemNode3.parents.Remove(itemNode2);
							}
						}
						for (int num2 = nodeStack.Count - 1; num2 >= 0; num2--)
						{
							if (nodeStack[num2] == itemNode3)
							{
								nodeStack.RemoveAt(num2);
								break;
							}
						}
					}
					itemNode2.children.Clear();
					if (userPreference.itemConfigs.ContainsKey(itemNode2.itemId) && userPreference.itemConfigs[itemNode2.itemId].recipeID > 0)
					{
						itemNode = itemNode2;
						continue;
					}
					int num3 = CalcDB.itemDict[itemNode2.itemId].recipes.IndexOf(itemNode2.mainRecipe.recipeNorm);
					if (num3 < CalcDB.itemDict[itemNode2.itemId].recipes.Count - 1)
					{
						itemNode = itemNode2;
						NormalizedRecipe normalizedRecipe = CalcDB.itemDict[itemNode2.itemId].recipes[num3 + 1];
						itemNode.TryRecipe(normalizedRecipe);
						for (int k = 0; k < normalizedRecipe.resources.Length; k++)
						{
							if (normalizedRecipe.resourceCounts[k] > 0)
							{
								ItemNode itemNode4 = new ItemNode(normalizedRecipe.resources[k], 0.0, this);
								itemNode.AddChild(itemNode4);
								Push(itemNode4);
							}
						}
						flag = true;
						break;
					}
					itemNode = itemNode2;
				}
				if (!flag)
				{
					UIRealtimeTip.Popup("存在环路警告".Translate());
					return false;
				}
				continue;
			}
			itemNodes[itemId] = itemNode;
			bool flag2 = CalcDB.itemDict[itemId].defaultAsOre || CalcDB.itemDict[itemId].recipes.Count == 0;
			if (userPreference.itemConfigs.ContainsKey(itemId))
			{
				flag2 = userPreference.itemConfigs[itemId].consideredAsOre || flag2;
				if (userPreference.itemConfigs[itemId].forceNotOre && CalcDB.itemDict[itemId].recipes.Count > 0)
				{
					flag2 = false;
				}
			}
			if (flag2)
			{
				itemNode.unsolvedCount = 0;
				if (itemNode.parents.Count > 0)
				{
					itemNode.parents[0].SolveOne();
				}
				continue;
			}
			int key = CalcDB.itemDict[itemId].recipes[0].ID;
			if (userPreference.itemConfigs.ContainsKey(itemId) && userPreference.itemConfigs[itemId].recipeID > 0)
			{
				key = userPreference.itemConfigs[itemId].recipeID;
			}
			NormalizedRecipe normalizedRecipe2 = CalcDB.recipeDict[key];
			itemNode.TryRecipe(normalizedRecipe2);
			for (int l = 0; l < normalizedRecipe2.resources.Length; l++)
			{
				if (normalizedRecipe2.resourceCounts[l] > 0)
				{
					ItemNode itemNode5 = new ItemNode(normalizedRecipe2.resources[l], 0.0, this);
					itemNode.AddChild(itemNode5);
					Push(itemNode5);
				}
			}
		}
		return true;
	}

	public void CalcTree(int proliferatorId = -1, double addedSpeed = 0.0)
	{
		Stack<ItemNode> stack = new Stack<ItemNode>();
		if (proliferatorId <= 0)
		{
			if (root.Count != targets.Count)
			{
				Utils.logger.LogError("Error when ClacTree, root count does not match the targes count.");
				return;
			}
			for (int i = 0; i < root.Count; i++)
			{
				root[i].needSpeed = targets[i].speed;
				stack.Push(root[i]);
			}
		}
		else if (itemNodes.ContainsKey(proliferatorId))
		{
			itemNodes[proliferatorId].needSpeed += addedSpeed;
			stack.Push(itemNodes[proliferatorId]);
		}
		else
		{
			ItemNode item = new ItemNode(proliferatorId, addedSpeed, this);
			stack.Push(item);
		}
		while (stack.Any())
		{
			ItemNode itemNode = stack.Pop();
			int itemId = itemNode.itemId;
			ItemNode itemNode2 = itemNodes[itemId];
			if (itemNode2.children.Count == 0)
			{
				if (itemNode2.satisfiedSpeed < itemNode2.needSpeed)
				{
					itemNode2.speedFromOre += itemNode2.needSpeed - itemNode2.satisfiedSpeed;
					itemNode2.satisfiedSpeed = itemNode2.needSpeed;
				}
			}
			else if (itemNode2.mainRecipe != null)
			{
				RecipeInfo mainRecipe = itemNode2.mainRecipe;
				int iD = mainRecipe.ID;
				double num = itemNode2.needSpeed - itemNode2.satisfiedSpeed;
				if (!(num > 9.999999747378752E-05))
				{
					continue;
				}
				if (!recipeInfos.ContainsKey(iD))
				{
					recipeInfos[iD] = mainRecipe;
				}
				double changedCount = recipeInfos[iD].AddCountByOutputNeed(itemId, num);
				foreach (KeyValuePair<int, int> productIndex in mainRecipe.productIndices)
				{
					int key = productIndex.Key;
					double outputSpeedByChangedCount = mainRecipe.GetOutputSpeedByChangedCount(key, changedCount);
					if (!itemNodes.ContainsKey(key))
					{
						itemNodes[key] = new ItemNode(key, 0.0, this);
					}
					itemNodes[key].satisfiedSpeed += outputSpeedByChangedCount;
					if (itemNodes[key].mainRecipe != null && itemNodes[key].mainRecipe.ID == iD)
					{
						continue;
					}
					bool flag = false;
					for (int j = 0; j < itemNodes[key].byProductRecipes.Count; j++)
					{
						if (itemNodes[key].byProductRecipes[j].ID == iD)
						{
							flag = true;
							break;
						}
					}
					if (!flag)
					{
						itemNodes[key].byProductRecipes.Add(mainRecipe);
					}
				}
				foreach (KeyValuePair<int, int> resourceIndex in mainRecipe.resourceIndices)
				{
					int key2 = resourceIndex.Key;
					itemNodes[key2].needSpeed += mainRecipe.GetInputSpeedByChangedCount(key2, changedCount);
					stack.Push(itemNodes[key2]);
				}
			}
			else
			{
				Debug.LogWarning("有子节点，但是却没有产出此物的配方，这种情况不应出现！");
			}
		}
	}

	public double RemoveOverflow(int proliferatorId = -1)
	{
		Dictionary<int, ItemNode> dictionary = new Dictionary<int, ItemNode>();
		Dictionary<int, int> dictionary2 = new Dictionary<int, int>();
		if (tempNotShrinkRoot)
		{
			root[0].needSpeed = root[0].satisfiedSpeed;
		}
		foreach (KeyValuePair<int, ItemNode> itemNode4 in itemNodes)
		{
			Stack<ItemNode> stack = new Stack<ItemNode>();
			if (dictionary.ContainsKey(itemNode4.Key))
			{
				continue;
			}
			ItemNode item = new ItemNode(itemNode4.Key, 0.0, this);
			stack.Push(item);
			while (stack.Any())
			{
				ItemNode itemNode = stack.Pop();
				int itemId = itemNode.itemId;
				ItemNode itemNode2 = itemNodes[itemId];
				bool flag = CalcDB.itemDict[itemId].defaultAsOre || CalcDB.itemDict[itemId].recipes.Count == 0;
				if (userPreference.itemConfigs.ContainsKey(itemId))
				{
					flag = userPreference.itemConfigs[itemId].consideredAsOre || flag;
					if (userPreference.itemConfigs[itemId].forceNotOre && CalcDB.itemDict[itemId].recipes.Count > 0)
					{
						flag = false;
					}
				}
				if (flag)
				{
					itemNode.unsolvedCount = 0;
					if (itemNode.parents.Count > 0)
					{
						itemNode.parents[0].SolveOne();
					}
					if (itemNode2.satisfiedSpeed < itemNode2.needSpeed)
					{
						itemNode2.satisfiedSpeed = itemNode2.needSpeed;
					}
					else if (itemNode2.satisfiedSpeed > itemNode2.needSpeed)
					{
						double num = itemNode2.satisfiedSpeed - itemNode2.needSpeed;
						if (itemNode2.speedFromOre > num)
						{
							itemNode2.speedFromOre -= num;
							itemNode2.satisfiedSpeed -= num;
						}
						else
						{
							itemNode2.satisfiedSpeed -= itemNode2.speedFromOre;
							itemNode2.speedFromOre = 0.0;
						}
					}
					continue;
				}
				double num2 = itemNode2.satisfiedSpeed - itemNode2.needSpeed;
				if (!(num2 > 9.999999747378752E-05))
				{
					continue;
				}
				if (DSPCalculatorPlugin.developerMode)
				{
					Debug.Log($"检测到溢出 id {LDB.items.Select(itemId).name}, 溢出量{num2}/min");
				}
				RecipeInfo recipeInfo = null;
				if (dictionary.ContainsKey(itemId) && dictionary[itemId].unsolvedCount > 0)
				{
					while (stack.Any() && dictionary.ContainsKey(stack.Last().itemId) && dictionary[stack.Last().itemId].unsolvedCount > 0)
					{
						stack.Pop();
					}
					continue;
				}
				dictionary[itemId] = itemNode;
				if (itemNode2.mainRecipe == null)
				{
					continue;
				}
				recipeInfo = recipeInfos[itemNode2.mainRecipe.ID];
				if (recipeInfo == null)
				{
					continue;
				}
				double num3 = recipeInfo.count;
				foreach (KeyValuePair<int, int> productIndex in recipeInfo.productIndices)
				{
					int key = productIndex.Key;
					if (!itemNodes.ContainsKey(key))
					{
						continue;
					}
					double num4 = itemNodes[key].satisfiedSpeed - itemNodes[key].needSpeed;
					if (!itemNodes[key].IsOre(userPreference))
					{
						if (!(num4 > 9.999999747378752E-05))
						{
							num3 = 0.0;
							break;
						}
						num3 = Math.Min(num3, recipeInfo.CalcCountByOutputSpeed(key, num4));
					}
				}
				if (num3 >= recipeInfo.count - 9.999999747378752E-05)
				{
					num3 = 0.0;
				}
				if (root.Count == 1 && root[0].itemId == itemId && !tempNotShrinkRoot)
				{
					return itemNode2.needSpeed / itemNode2.satisfiedSpeed;
				}
				if (!(num3 > 0.0010000000474974513))
				{
					continue;
				}
				itemNode.SetUnsolvedCountByRecipe(recipeInfo.recipeNorm);
				if (DSPCalculatorPlugin.developerMode)
				{
					Debug.Log($"该溢出可以削减 {num3}x");
				}
				double num5 = 0.0 - num3;
				recipeInfo.count += num5;
				foreach (KeyValuePair<int, int> productIndex2 in recipeInfo.productIndices)
				{
					int key2 = productIndex2.Key;
					double outputSpeedByChangedCount = recipeInfo.GetOutputSpeedByChangedCount(key2, num5);
					if (!itemNodes.ContainsKey(key2))
					{
						Debug.LogWarning("在削减溢出配方数量时，出现了配方产物不在字典中的情况，该情况不应该发生。");
						itemNodes[key2] = new ItemNode(key2, 0.0, this);
					}
					itemNodes[key2].satisfiedSpeed += outputSpeedByChangedCount;
					if (DSPCalculatorPlugin.developerMode)
					{
						Debug.Log($"削减了 {LDB.items.Select(key2).name}, 削减量{outputSpeedByChangedCount}， 现在它satisfied{itemNodes[key2].satisfiedSpeed}");
					}
					if (itemNodes[key2].satisfiedSpeed < itemNodes[key2].needSpeed)
					{
						if (itemNodes[key2].IsOre(userPreference))
						{
							double num6 = itemNodes[key2].needSpeed - itemNodes[key2].satisfiedSpeed;
							itemNodes[key2].speedFromOre += num6;
							itemNodes[key2].satisfiedSpeed = itemNodes[key2].needSpeed;
						}
						else
						{
							Debug.LogWarning($"在削减溢出配方数量时，出现了配方id={recipeInfo.ID}产物{key2}被过度削减的情况（且该产物并未被视作原矿），该情况不应该发生。");
						}
					}
				}
				foreach (KeyValuePair<int, int> resourceIndex in recipeInfo.resourceIndices)
				{
					int key3 = resourceIndex.Key;
					double inputSpeedByChangedCount = recipeInfo.GetInputSpeedByChangedCount(key3, num5);
					itemNodes[key3].needSpeed += inputSpeedByChangedCount;
					if (DSPCalculatorPlugin.developerMode)
					{
						Debug.Log($"削减了 {LDB.items.Select(key3).name}, 削减量{inputSpeedByChangedCount}， need{itemNodes[key3].needSpeed}");
					}
					ItemNode itemNode3 = new ItemNode(key3, 0.0, this);
					itemNode.AddChild(itemNode3);
					itemNode.unsolvedCount++;
					stack.Push(itemNode3);
					if (itemNodes[key3].speedFromOre > 0.0)
					{
						if (itemNodes[key3].speedFromOre > 0.0 - inputSpeedByChangedCount)
						{
							itemNodes[key3].satisfiedSpeed -= 0.0 - inputSpeedByChangedCount;
							itemNodes[key3].speedFromOre -= 0.0 - inputSpeedByChangedCount;
						}
						else
						{
							itemNodes[key3].satisfiedSpeed -= itemNodes[key3].speedFromOre;
							itemNodes[key3].speedFromOre = 0.0;
						}
					}
				}
			}
		}
		return 0.0;
	}

	public void CalcProliferator()
	{
		proliferatorCount.Clear();
		proliferatorCountSelfSprayed.Clear();
		foreach (KeyValuePair<int, RecipeInfo> recipeInfo in recipeInfos)
		{
			recipeInfo.Value.GetProliferatorUsed(out var proliferatorId, out var num);
			if (proliferatorId > 0)
			{
				if (!proliferatorCount.ContainsKey(proliferatorId))
				{
					proliferatorCount[proliferatorId] = num;
				}
				else
				{
					proliferatorCount[proliferatorId] += num;
				}
			}
		}
		for (int i = 0; i < CalcDB.proliferatorItemIds.Count; i++)
		{
			int num2 = CalcDB.proliferatorItemIds[i];
			if (proliferatorCount.ContainsKey(num2))
			{
				int hpMax = LDB.items.Select(num2).HpMax;
				int index = CalcDB.proliferatorAbilitiesMap[num2];
				int num3 = (int)((double)hpMax * (1.0 + Utils.GetIncMilli(index, userPreference)));
				if (num3 - 1 > hpMax)
				{
					proliferatorCountSelfSprayed[num2] = proliferatorCount[num2] * (double)hpMax / (double)(num3 - 1);
				}
				else
				{
					proliferatorCountSelfSprayed[num2] = proliferatorCount[num2];
				}
			}
		}
	}

	public void RefreshBlueprintDicts()
	{
		beltsAvailable = new List<BpBeltInfo>();
		sortersAvailable = new List<BpSorterInfo>();
		for (int i = 0; i < BpDB.beltsAscending.Count; i++)
		{
			if (GameMain.history.ItemUnlocked(BpDB.beltsAscending[i].itemId) || !userPreference.bpBeltTechLimit || i == 0)
			{
				beltsAvailable.Add(BpDB.beltsAscending[i]);
			}
		}
		for (int j = 0; j < BpDB.sortersAscending.Count; j++)
		{
			if (GameMain.history.ItemUnlocked(BpDB.sortersAscending[j].itemId) || !userPreference.bpSorterTechLimit || j == 0)
			{
				sortersAvailable.Add(BpDB.sortersAscending[j]);
			}
		}
	}

	public ItemNode Pop()
	{
		if (nodeStack.Count > 0)
		{
			int index = nodeStack.Count - 1;
			ItemNode result = nodeStack[index];
			nodeStack.RemoveAt(index);
			return result;
		}
		return null;
	}

	public void Push(ItemNode node)
	{
		nodeStack.Add(node);
	}

	public ItemNode StackTail()
	{
		if (nodeStack.Count > 0)
		{
			return nodeStack[nodeStack.Count - 1];
		}
		return null;
	}

	public bool CalcProliferatorInProductLine()
	{
		double[,] array = new double[RecipeUpdates.ProliferatorCount(), RecipeUpdates.ProliferatorCount()];
		for (int i = 0; i < CalcDB.proliferatorItemIds.Count; i++)
		{
			int targetItem = CalcDB.proliferatorItemIds[i];
			SolutionTree solutionTree = new SolutionTree();
			solutionTree.userPreference = userPreference.ShallowCopy();
			solutionTree.userPreference.solveProliferators = false;
			solutionTree.SetTargetAndSolve(0, targetItem, 1.0);
			foreach (KeyValuePair<int, double> item in solutionTree.proliferatorCountSelfSprayed)
			{
				int num = CalcDB.proliferatorItemIds.IndexOf(item.Key);
				if (num >= 0 && num < RecipeUpdates.ProliferatorCount())
				{
					array[i, num] = item.Value;
				}
			}
		}
		for (int j = 0; j < RecipeUpdates.ProliferatorCount(); j++)
		{
			if (array[j, j] >= 1.0 && proliferatorCountSelfSprayed.ContainsKey(CalcDB.proliferatorItemIds[j]))
			{
				UIRealtimeTip.Popup("增产剂生产消耗比产出多警告".Translate());
				return false;
			}
		}
		double[,] array2 = new double[RecipeUpdates.ProliferatorCount(), RecipeUpdates.ProliferatorCount()];
		double[] array3 = new double[RecipeUpdates.ProliferatorCount()];
		for (int k = 0; k < RecipeUpdates.ProliferatorCount(); k++)
		{
			int key = CalcDB.proliferatorItemIds[k];
			for (int l = 0; l < RecipeUpdates.ProliferatorCount(); l++)
			{
				if (k == l)
				{
					array2[k, l] = 1.0 - array[l, k];
				}
				else
				{
					array2[k, l] = 0.0 - array[l, k];
				}
			}
			if (proliferatorCountSelfSprayed.ContainsKey(key))
			{
				array3[k] = proliferatorCountSelfSprayed[key];
			}
			else
			{
				array3[k] = 0.0;
			}
		}
		Vector<double> vector = null;
		try
		{
			Matrix<double> matrix = Matrix<double>.Build.DenseOfArray(array2);
			Vector<double> input = Vector<double>.Build.DenseOfArray(array3);
			vector = matrix.Solve(input);
		}
		catch (Exception)
		{
			Debug.LogWarning("在解方程组时出现错误，该情况不应该发生。");
			UIRealtimeTip.Popup("求解出错警告".Translate());
			return false;
		}
		if (vector == null)
		{
			Debug.LogWarning("在解方程组时出现错误，结果为null，该情况不应该发生。");
			UIRealtimeTip.Popup("求解出错警告".Translate());
			return false;
		}
		for (int m = 0; m < vector.Count; m++)
		{
			if (vector[m] < 0.0)
			{
				Debug.LogWarning($"在解方程组时，增产剂{m}需求数量为负数。");
				UIRealtimeTip.Popup("求解出错警告".Translate());
				return false;
			}
		}
		for (int n = 0; n < vector.Count; n++)
		{
			if (vector[n] > 0.0)
			{
				int proliferatorId = CalcDB.proliferatorItemIds[n];
				CalcTree(proliferatorId, vector[n]);
			}
		}
		double num2 = RemoveOverflow();
		if (num2 > 0.0)
		{
			return ReSolveForRootShrinking(targets[0].speed * num2);
		}
		return true;
	}

	public bool CanShowOverflow(int itemId)
	{
		if (root.Count == 1 && itemId == root[0].itemId && tempNotShrinkRoot)
		{
			return false;
		}
		return true;
	}

	public void Export(BinaryWriter w)
	{
		w.Write(512);
		int count = targets.Count;
		w.Write(count);
		for (int i = 0; i < count; i++)
		{
			w.Write(targets[i].itemId);
			if (tempNotShrinkRoot && count == 1 && itemNodes.ContainsKey(targets[i].itemId))
			{
				w.Write(itemNodes[targets[i].itemId].satisfiedSpeed);
			}
			else
			{
				w.Write(targets[i].speed);
			}
		}
		userPreference.Export(w);
	}

	public void Import(BinaryReader r)
	{
		int num = r.ReadInt32();
		int num2 = r.ReadInt32();
		targets.Clear();
		for (int i = 0; i < num2; i++)
		{
			int itemId = r.ReadInt32();
			double speed = r.ReadDouble();
			targets.Add(new ItemTarget(itemId, speed));
		}
		userPreference.Import(r);
	}
}
