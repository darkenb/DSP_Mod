using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace DSPCalculator.UI;

public class UIHotkeySettingPatcher
{
	public static Text title1;

	public static Text keyText1;

	public static UIButton uibtn1;

	public static GameObject waitingTextObj1;

	public static InputField inputField1;

	public static Text title2;

	public static Text keyText2;

	public static UIButton uibtn2;

	public static GameObject waitingTextObj2;

	public static InputField inputField2;

	public static bool isWaiting1;

	public static bool isWaiting2;

	public static KeyCode temp1;

	public static int tempModifier1;

	public static KeyCode temp2;

	public static int tempModifier2;

	public static void Init()
	{
		GameObject original = GameObject.Find("UI Root/Overlay Canvas/Top Windows/Option Window/details/content-4/list/scroll-view/viewport/content/key-entry");
		GameObject gameObject = GameObject.Find("UI Root/Overlay Canvas/Top Windows/Option Window/details/content-4/list/scroll-view/viewport/content");
		float x = gameObject.GetComponent<RectTransform>().sizeDelta.x;
		float y = gameObject.GetComponent<RectTransform>().sizeDelta.y;
		gameObject.GetComponent<RectTransform>().sizeDelta = new Vector2(x, y + 84f);
		GameObject gameObject2 = Object.Instantiate(original, gameObject.transform);
		gameObject2.SetActive(value: true);
		Object.DestroyImmediate(gameObject2.GetComponent<UIKeyEntry>());
		gameObject2.transform.Find("clear-key-btn").gameObject.SetActive(value: false);
		gameObject2.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(30f, 0f - (y + 42f) + 40f);
		title1 = gameObject2.GetComponent<Text>();
		title1.text = "打开量化计算器窗口".Translate();
		keyText1 = gameObject2.transform.Find("key").GetComponent<Text>();
		uibtn1 = gameObject2.transform.Find("input/InputField").GetComponent<UIButton>();
		inputField1 = gameObject2.transform.Find("input/InputField").GetComponent<InputField>();
		waitingTextObj1 = gameObject2.transform.Find("input/waiting-text").gameObject;
		uibtn1.onClick += delegate
		{
			OnSetKey1ButtonClick();
		};
		gameObject2.transform.Find("set-default-btn").GetComponent<Button>().onClick.RemoveAllListeners();
		gameObject2.transform.Find("set-default-btn").GetComponent<Button>().onClick.AddListener(OnSetDefault1ButtonClick);
		GameObject gameObject3 = Object.Instantiate(original, gameObject.transform);
		gameObject3.SetActive(value: true);
		Object.DestroyImmediate(gameObject3.GetComponent<UIKeyEntry>());
		gameObject3.transform.Find("clear-key-btn").gameObject.SetActive(value: false);
		gameObject3.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(30f, 0f - (y + 84f) + 40f);
		title2 = gameObject3.GetComponent<Text>();
		title2.text = "切换计算器窗口大小".Translate();
		keyText2 = gameObject3.transform.Find("key").GetComponent<Text>();
		uibtn2 = gameObject3.transform.Find("input/InputField").GetComponent<UIButton>();
		inputField2 = gameObject3.transform.Find("input/InputField").GetComponent<InputField>();
		waitingTextObj2 = gameObject3.transform.Find("input/waiting-text").gameObject;
		uibtn2.onClick += delegate
		{
			OnSetKey2ButtonClick();
		};
		gameObject3.transform.Find("set-default-btn").GetComponent<Button>().onClick.RemoveAllListeners();
		gameObject3.transform.Find("set-default-btn").GetComponent<Button>().onClick.AddListener(OnSetDefault2ButtonClick);
		RefreshAll();
	}

	public static bool CheckModifier(int type, bool shift, bool ctrl, bool alt)
	{
		int value = DSPCalculatorPlugin.OpenWindowModifier.Value;
		if (type == 2)
		{
			value = DSPCalculatorPlugin.SwitchWindowModifier.Value;
		}
		if (value <= 0)
		{
			return true;
		}
		if ((value & 1) > 0 && !shift)
		{
			return false;
		}
		if ((value & 2) > 0 && !ctrl)
		{
			return false;
		}
		if ((value & 4) > 0 && !alt)
		{
			return false;
		}
		return true;
	}

	public static void OnUpdate()
	{
		bool shift = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
		bool ctrl = Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl);
		bool alt = Input.GetKey(KeyCode.LeftAlt) || Input.GetKey(KeyCode.RightAlt);
		if (!isWaiting1 && !isWaiting2)
		{
			return;
		}
		KeyCode keyCode = KeyCode.Q;
		bool flag = false;
		for (int i = 0; i < 26; i++)
		{
			if (Input.GetKeyDown((KeyCode)(97 + i)))
			{
				keyCode = (KeyCode)(97 + i);
				flag = true;
				break;
			}
		}
		if (!flag)
		{
			for (int j = 0; j < 12; j++)
			{
				if (Input.GetKeyDown((KeyCode)(282 + j)))
				{
					keyCode = (KeyCode)(282 + j);
					flag = true;
					break;
				}
			}
		}
		if (!flag)
		{
			for (int k = 0; k < 10; k++)
			{
				if (Input.GetKeyDown((KeyCode)(256 + k)))
				{
					keyCode = (KeyCode)(256 + k);
					flag = true;
					break;
				}
			}
		}
		if ((flag && keyCode >= KeyCode.A && keyCode <= KeyCode.Z) || (keyCode >= KeyCode.F1 && keyCode <= KeyCode.F12) || (keyCode >= KeyCode.Keypad0 && keyCode <= KeyCode.Keypad9))
		{
			if (isWaiting1)
			{
				SetOpenWindowHotKey(keyCode, shift, ctrl, alt);
			}
			else if (isWaiting2)
			{
				SetSwitchWindowHotKey(keyCode, shift, ctrl, alt);
			}
			isWaiting1 = false;
			isWaiting2 = false;
			RefreshAll();
		}
	}

	public static void RefreshAll()
	{
		if (isWaiting1)
		{
			uibtn1.highlighted = true;
			waitingTextObj1.SetActive(value: true);
		}
		else
		{
			uibtn1.highlighted = false;
			waitingTextObj1.SetActive(value: false);
		}
		if (isWaiting2)
		{
			uibtn2.highlighted = true;
			waitingTextObj2.SetActive(value: true);
		}
		else
		{
			uibtn2.highlighted = false;
			waitingTextObj2.SetActive(value: false);
		}
		int num = tempModifier1;
		string text = "";
		if ((num & 1) > 0)
		{
			text += "Shift";
		}
		if ((num & 2) > 0)
		{
			if (text.Length > 0)
			{
				text += " + ";
			}
			text += "Ctrl";
		}
		if ((num & 4) > 0)
		{
			if (text.Length > 0)
			{
				text += " + ";
			}
			text += "Alt";
		}
		if (text.Length > 0)
		{
			text += " + ";
		}
		text += temp1;
		keyText1.text = text;
		int num2 = tempModifier2;
		string text2 = "";
		if ((num2 & 1) > 0)
		{
			text2 += "Shift";
		}
		if ((num2 & 2) > 0)
		{
			if (text2.Length > 0)
			{
				text2 += " + ";
			}
			text2 += "Ctrl";
		}
		if ((num2 & 4) > 0)
		{
			if (text2.Length > 0)
			{
				text2 += " + ";
			}
			text2 += "Alt";
		}
		if (text2.Length > 0)
		{
			text2 += " + ";
		}
		text2 += temp2;
		keyText2.text = text2;
	}

	public static void OnSetKey1ButtonClick()
	{
		isWaiting1 = !isWaiting1;
		isWaiting2 = false;
		RefreshAll();
	}

	public static void OnSetKey2ButtonClick()
	{
		isWaiting2 = !isWaiting2;
		isWaiting1 = false;
		RefreshAll();
	}

	public static void OnSetDefault1ButtonClick()
	{
		isWaiting1 = false;
		isWaiting2 = false;
		SetOpenWindowHotKey(KeyCode.Q, shift: false, ctrl: false, alt: false);
		RefreshAll();
	}

	public static void OnSetDefault2ButtonClick()
	{
		isWaiting1 = false;
		isWaiting2 = false;
		SetSwitchWindowHotKey(KeyCode.Tab, shift: false, ctrl: false, alt: false);
		RefreshAll();
	}

	public static void SetOpenWindowHotKey(KeyCode key, bool shift, bool ctrl, bool alt)
	{
		temp1 = key;
		int num = 0;
		if (shift)
		{
			num++;
		}
		if (ctrl)
		{
			num += 2;
		}
		if (alt)
		{
			num += 4;
		}
		tempModifier1 = num;
	}

	public static void SetSwitchWindowHotKey(KeyCode key, bool shift, bool ctrl, bool alt)
	{
		temp2 = key;
		int num = 0;
		if (shift)
		{
			num++;
		}
		if (ctrl)
		{
			num += 2;
		}
		if (alt)
		{
			num += 4;
		}
		tempModifier2 = num;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIOptionWindow), "OnApplyClick")]
	public static void Confirm()
	{
		DSPCalculatorPlugin.OpenWindowHotKey.Value = temp1;
		DSPCalculatorPlugin.SwitchWindowSizeHotKey.Value = temp2;
		DSPCalculatorPlugin.OpenWindowModifier.Value = tempModifier1;
		DSPCalculatorPlugin.SwitchWindowModifier.Value = tempModifier2;
		DSPCalculatorPlugin.OpenWindowHotKey.ConfigFile.Save();
		RefreshAll();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIOptionWindow), "OnCancelClick")]
	public static void Cancel()
	{
		temp1 = DSPCalculatorPlugin.OpenWindowHotKey.Value;
		temp2 = DSPCalculatorPlugin.SwitchWindowSizeHotKey.Value;
		tempModifier1 = DSPCalculatorPlugin.OpenWindowModifier.Value;
		tempModifier2 = DSPCalculatorPlugin.SwitchWindowModifier.Value;
		RefreshAll();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIOptionWindow), "_OnOpen")]
	public static void OnOpen()
	{
		temp1 = DSPCalculatorPlugin.OpenWindowHotKey.Value;
		temp2 = DSPCalculatorPlugin.SwitchWindowSizeHotKey.Value;
		tempModifier1 = DSPCalculatorPlugin.OpenWindowModifier.Value;
		tempModifier2 = DSPCalculatorPlugin.SwitchWindowModifier.Value;
		RefreshAll();
	}

	public static string GetFoldHotkeyString()
	{
		string text = "";
		int value = DSPCalculatorPlugin.SwitchWindowModifier.Value;
		if ((value & 1) > 0)
		{
			text += "Shift";
		}
		if ((value & 2) > 0)
		{
			if (text.Length > 0)
			{
				text += " + ";
			}
			text += "Ctrl";
		}
		if ((value & 4) > 0)
		{
			if (text.Length > 0)
			{
				text += " + ";
			}
			text += "Alt";
		}
		if (text.Length > 0)
		{
			text += " + ";
		}
		text += DSPCalculatorPlugin.SwitchWindowSizeHotKey.Value;
		return " (" + text + ")";
	}
}
