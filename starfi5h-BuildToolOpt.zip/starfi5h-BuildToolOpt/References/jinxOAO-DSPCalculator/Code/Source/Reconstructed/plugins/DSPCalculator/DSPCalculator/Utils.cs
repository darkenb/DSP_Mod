using BepInEx.Logging;
using DSPCalculator.Logic;
using UnityEngine;
using UnityEngine.UI;

namespace DSPCalculator;

public static class Utils
{
	public static ManualLogSource logger => DSPCalculatorPlugin.logger;

	public static string KMG(double num)
	{
		string text = "";
		if (num < 100.0)
		{
			return num.ToString("0.##");
		}
		if (num < 1000.0)
		{
			return num.ToString("0.#");
		}
		if (num < 10000.0)
		{
			return num.ToString("N0");
		}
		if (num < 1000000.0)
		{
			text = "k";
			num /= 1000.0;
		}
		else if (num < 1000000000.0)
		{
			text = "M";
			num /= 1000000.0;
		}
		else if (num < 1000000000000.0)
		{
			text = "G";
			num /= 1000000000.0;
		}
		else if (num < 1000000000000000.0)
		{
			text = "T";
			num /= 1000000000000.0;
		}
		else if (num < 1E+18)
		{
			text = "P";
			num /= 1000000000000000.0;
		}
		else
		{
			text = "E";
			num /= 1E+18;
		}
		if (num < 9.995)
		{
			return $"{num:0.000} {text}";
		}
		if (num < 99.95)
		{
			return $"{num:0.00} {text}";
		}
		if (num < 999.5)
		{
			return $"{num:0.0} {text}";
		}
		return $"{num:N0} {text}";
	}

	public static string KMG(long num)
	{
		if (num <= 9999)
		{
			return num.ToString("N0");
		}
		return KMG((double)num);
	}

	public static string KMGForceDigi(double num)
	{
		if (num < 10000.0)
		{
			return num.ToString("N2");
		}
		return KMG(num);
	}

	public static double GetIncMilli(int index, UserPreference preference)
	{
		if (preference.customizeIncMilli && index > 0)
		{
			return preference.incMilliOverride;
		}
		return Cargo.incTableMilli[index];
	}

	public static double GetAccMilli(int index, UserPreference preference)
	{
		if (preference.customizeAccMilli && index > 0)
		{
			return preference.accMilliOverride;
		}
		return Cargo.accTableMilli[index];
	}

	public static double GetPowerRatio(int index, UserPreference preference)
	{
		return Cargo.powerTableRatio[index];
	}

	public static bool SolveEquationsLimited(double[,] augMatrix, out double[] result)
	{
		int length = augMatrix.GetLength(1);
		result = new double[length];
		int length2 = augMatrix.GetLength(0);
		for (int i = 0; i < length2; i++)
		{
		}
		return true;
	}

	public static string GetItemName(this int itemId)
	{
		ItemProto itemProto = LDB.items.Select(itemId);
		if (itemProto != null)
		{
			return itemProto.name;
		}
		return "null";
	}

	public static string GetRecipeName(this int recipeId)
	{
		RecipeProto recipeProto = LDB.recipes.Select(recipeId);
		if (recipeProto != null)
		{
			return recipeProto.name;
		}
		return "null";
	}

	public static GameObject CreateEmptyGameObject(this GameObject parentObj, string name)
	{
		GameObject gameObject = new GameObject(name);
		gameObject.transform.SetParent(parentObj.transform, worldPositionStays: false);
		gameObject.transform.localScale = Vector3.one;
		gameObject.transform.localPosition = Vector3.zero;
		return gameObject;
	}

	public static GameObject CreateEmptyGameObject(this Transform parent, string name)
	{
		GameObject gameObject = new GameObject(name);
		gameObject.transform.SetParent(parent, worldPositionStays: false);
		gameObject.transform.localScale = Vector3.one;
		gameObject.transform.localPosition = Vector3.zero;
		return gameObject;
	}

	public static UIButton AddUIButtonForImage(this GameObject obj)
	{
		UIButton uIButton = obj.AddComponent<UIButton>();
		uIButton.tips = default(UIButton.TipSettings);
		if (obj.GetComponent<Button>() != null)
		{
			uIButton.button = obj.GetComponent<Button>();
		}
		uIButton.transitions = new UIButton.Transition[1];
		uIButton.transitions[0] = CreateUIButtonTransition(obj.GetComponent<Image>());
		return uIButton;
	}

	public static UIButton.Transition CreateUIButtonTransition(Graphic target)
	{
		UIButton.Transition transition = new UIButton.Transition();
		transition.target = target;
		transition.damp = 0.3f;
		transition.highlightAlphaMultiplier = 1f;
		transition.highlightColorMultiplier = 1f;
		transition.highlightSizeMultiplier = 1f;
		transition.mouseoverSize = 1f;
		transition.pressedSize = 1f;
		return transition;
	}

	public static string ItemName(int itemId)
	{
		return LDB.items.Select(itemId)?.name;
	}

	public static string RecipeName(int recipeId)
	{
		return LDB.recipes.Select(recipeId)?.name;
	}

	public static float Cross(this Vector2 a, Vector2 b)
	{
		return a.x * b.y - a.y * b.x;
	}

	public static float DistanceSquare(this Vector2 p, float k, float b)
	{
		float num = k * p.x + b;
		float num2 = p.y - num;
		return num2 * num2 / (1f + k * k);
	}

	public static float Square(this float x)
	{
		return x * x;
	}
}
