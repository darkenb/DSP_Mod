using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Linq;
using System.Text;
using DSPCalculator.Bp;
using DSPCalculator.Compatibility;
using DSPCalculator.Logic;
using UnityEngine;
using UnityEngine.UI;

namespace DSPCalculator.UI;

public class UICalcWindow
{
	public const float cellWidth = 890f;

	public const float cellHeight = 80f;

	public const float cellDistance = 6f;

	public const float sideCellWidth = 138.66f;

	public const float sideCellHeight = 45f;

	public const int sideCellCountPerRow = 3;

	public const float sidePanelWidth = 400f;

	public static float targetIconAnchoredPosX = 52f;

	public static float targetIconAnchoredPosYLargeWindow = -80f;

	public static float targetIconAnchoredPosYSmallWindow = -60f;

	public const int assemblerDemandCountPerRow = 4;

	public const int TYPE_FILTER = 100000;

	public static Color itemIconNormalColor = new Color(0.6f, 0.6f, 0.6f, 1f);

	public static Color itemIconHighlightColor = new Color(0.7f, 0.7f, 0.7f, 1f);

	public static Color itemIconPressedColor = new Color(0.6f, 0.6f, 0.6f, 1f);

	public static Color itemIconDisabledColor = new Color(0.5f, 0.5f, 0.5f, 1f);

	public static Color TextWhiteColor = new Color(0.588f, 0.588f, 0.588f, 1f);

	public static Color TextWarningColor = new Color(0.852f, 0.487f, 0.022f, 1f);

	public static Color TextBlueColor = new Color(0.282f, 0.845f, 1f, 0.705f);

	public static Color incModeImageColor = new Color(0.287f, 0.824f, 1f, 0.266f);

	public static Color accModeImageColor = new Color(0.9906f, 0.5897f, 0.3691f, 0.384f);

	public static Color incModeTextColor = new Color(0.282f, 0.845f, 1f, 0.705f);

	public static Color accModeTextColor = new Color(0.9906f, 0.5897f, 0.3691f, 0.705f);

	public static Color inProgressColor = new Color(0.9906f, 0.5897f, 0.3691f, 0.705f);

	public static Color finishedProgressColor = new Color(0.282f, 0.845f, 1f, 0.705f);

	public static float largeWindowWidth = 1340f;

	public static float smallWindowWidth = 315f;

	public static float largeWindowViewGroupWidth = 890f;

	public static float smallWindowViewGroupWidth = 290f;

	public static float largeWindowViewGroupHeight = 570f;

	public static float smallWindowViewGroupHeight = 610f;

	public static float animationSpeed = 150f;

	public static int[] IASpecializationIconItemMap = new int[6] { 1201, 1107, 1116, -74, 1305, 1606 };

	public static int IAIconItemId = 9493;

	public static int PLS = 2103;

	public static GameObject recipeObj;

	public static GameObject arrowObj;

	public static GameObject iconObj_NoTip;

	public static GameObject iconObj_ButtonTip;

	public static GameObject TextObj;

	public static GameObject TextWithUITip;

	public static GameObject textButtonObj;

	public static GameObject imageButtonObj;

	public static GameObject incTogglePrefabObj;

	public static GameObject checkBoxObj;

	public static GameObject oriInputFieldObjNoSelIcon;

	public static Sprite itemNotSelectedSprite;

	public static Sprite leftTriangleSprite;

	public static Sprite rightTriangleSprite;

	public static Sprite backgroundSprite = null;

	public static Sprite buttonBackgroundSprite = null;

	public static Sprite gearWithCursorSprite = null;

	public static Sprite gearSimpleSprite = null;

	public static Sprite filterSprite = null;

	public static Sprite biaxialArrowSprite = null;

	public static Sprite oreSprite = null;

	public static Sprite crossSprite = null;

	public static Sprite bannedSprite = null;

	public static Sprite todoListSprite = null;

	public static Sprite resetSprite = null;

	public static Sprite checkboxOnSprite = null;

	public static Sprite checkboxOffSprite = null;

	public static Sprite arrowInBoxSprite = null;

	public static Sprite squarePlusSprite = null;

	public static Sprite blueprintBookSprite = null;

	public static Sprite PLSIconSprite = null;

	public static Sprite LSWhiteSprite = null;

	public static Sprite blueprintIconSprite = null;

	public static Sprite newBPFloderSprite = null;

	public static Sprite copySprite;

	public static Sprite pasteSprite;

	public static Sprite lockSprite;

	public static Sprite listSprite;

	public static Sprite doubleLayerSprite;

	public static Sprite circleThinSprite;

	public static string sonTextObjName = "number-text";

	public GameObject windowObj;

	public GameObject viewGroupObj;

	public GameObject mainCanvasObj;

	public GameObject switchSizeButtonObj;

	public GameObject customTitleInputObj;

	public Image titleInputBG;

	public InputField titleInput;

	public UIButton titleInputUIBtn;

	public Text titleText;

	public GameObject targetProductTextObj;

	public Image targetProductIcon;

	public UIButton targetProductIconUIBtn;

	public List<UIItemNode> uiItemNodes;

	public List<UINode> uiSideItemNodes;

	public ScrollRect contentScrollRect;

	public Transform contentTrans;

	public GameObject targetProductIconObj;

	public GameObject speedInputObj;

	public GameObject perMinTextObj;

	public Transform sideContentTrans;

	public GameObject incToggleObj;

	public Text incText;

	public GameObject proliferatorSelectionObj;

	public GameObject assemblerSelectionObj;

	public Dictionary<int, UIButton> proliferatorUsedButtons;

	public Dictionary<int, Dictionary<int, UIButton>> assemblerUsedButtons;

	public Text finalInfoText;

	public Text assemblerDemandsTitleText;

	public GameObject assemblersDemandsGroupObj;

	public List<GameObject> assemblersDemandObjs;

	public Image IABtnSpecializationImg;

	public List<GameObject> sideInfoPanelObjs;

	public List<UIButton> sideInfoPanelSwitchUIBtns;

	public GameObject genBpButtonObj;

	public UIButton genBpUIBtn;

	public Image progressCircleImg;

	public Image cbBluebuff;

	public Image cbEnergyBurst;

	public Image cbDirac;

	public Image cbInferior;

	public Image cbIncMilli;

	public Image cbAccMilli;

	public Image cbRoundUp;

	public Image cbMixbelt;

	public Image cbSolveProlifer;

	public Text txtBluebuff;

	public Text txtEnergyBurst;

	public Text txtDirac;

	public Text txtInferior;

	public Text txtIncMilli;

	public Text txtAccMilli;

	public Text txtRoundUp;

	public Text txtMixbelt;

	public Text txtSolveProlifer;

	public InputField incInput;

	public InputField accInput;

	public Dictionary<int, int> uiItemNodeOrders;

	public Dictionary<int, UIItemNodeSimple> uiItemSimplesByItemId;

	public SolutionTree solution;

	public bool isLargeWindow;

	public float targetVerticalPosition;

	public bool ShiftState;

	public bool isTopAndActive;

	public bool nextFrameRecalc;

	public int sideInfoPanelIndex;

	public bool hideOutsideTheEdge;

	public int refreshIndex;

	public Image uibtnIcon_bpRowCount1;

	public Image uibtnIcon_bpRowCount2;

	public Image uibtnIcon_bpCoaterAuto;

	public Image uibtnIcon_bpCoaterAlways;

	public Image uibtnIcon_bpCoaterNever;

	public Image uibtnIcon_bpProductCoaterAlways;

	public Image uibtnIcon_bpProductCoaterNever;

	public Image uibtnIcon_bpStationProlifSlotYes;

	public Image uibtnIcon_bpStationProlifSlotNo;

	public Image uibtnIcon_bpBeltHigh;

	public Image uibtnIcon_bpBeltLow;

	public Image uibtnIcon_bpBeltUnlimit;

	public Image uibtnIcon_bpBeltLimit;

	public Image uibtnIcon_bpSorterHigh;

	public Image uibtnIcon_bpSorterLow;

	public Image uibtnIcon_bpSorterUnlimit;

	public Image uibtnIcon_bpSorterLimit;

	public Image uibtnIcon_bpStackCur;

	public Image uibtnIcon_bpStack4;

	public Image uibtnIcon_bpStack3;

	public Image uibtnIcon_bpStack2;

	public Image uibtnIcon_bpStack1;

	public Image uibtnIcon_bpBlackboxConnectCoater;

	public Image uibtnIcon_bpBlackboxNotConnectCoater;

	public UICalcWindow(int idx)
	{
		TryInitStaticPrefabs();
		solution = new SolutionTree();
		uiItemNodes = new List<UIItemNode>();
		uiSideItemNodes = new List<UINode>();
		proliferatorUsedButtons = new Dictionary<int, UIButton>();
		assemblerUsedButtons = new Dictionary<int, Dictionary<int, UIButton>>();
		assemblersDemandObjs = new List<GameObject>();
		uiItemNodeOrders = new Dictionary<int, int>();
		uiItemSimplesByItemId = new Dictionary<int, UIItemNodeSimple>();
		sideInfoPanelObjs = new List<GameObject>();
		sideInfoPanelSwitchUIBtns = new List<UIButton>();
		isTopAndActive = true;
		isLargeWindow = true;
		nextFrameRecalc = false;
		targetVerticalPosition = -1f;
		hideOutsideTheEdge = false;
		refreshIndex = 0;
		GameObject original = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Blueprint Browser");
		GameObject gameObject = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows");
		windowObj = UnityEngine.Object.Instantiate(original);
		windowObj.name = "calc-window " + idx;
		windowObj.transform.SetParent(gameObject.transform);
		windowObj.GetComponent<RectTransform>().pivot = new Vector2(0f, 1f);
		windowObj.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(-670f, 357f, 0f);
		windowObj.transform.localScale = Vector3.one;
		windowObj.AddComponent<RectMask2D>();
		Vector3 localPosition = windowObj.transform.localPosition;
		int num = 40;
		float x = UnityEngine.Random.Range(localPosition.x - (float)num, localPosition.x + (float)num);
		float y = UnityEngine.Random.Range(localPosition.y - (float)num, localPosition.y + (float)num);
		windowObj.transform.localPosition = new Vector3(x, y, localPosition.z);
		UnityEngine.Object.Destroy(windowObj.transform.Find("inspector-group").gameObject);
		UnityEngine.Object.Destroy(windowObj.transform.Find("folder-info-group").gameObject);
		UnityEngine.Object.Destroy(windowObj.transform.Find("title-group").gameObject);
		GameObject gameObject2 = windowObj.transform.Find("view-group/Scroll View/Viewport/Content").gameObject;
		while (gameObject2.transform.childCount > 0)
		{
			UnityEngine.Object.DestroyImmediate(gameObject2.transform.GetChild(gameObject2.transform.childCount - 1).gameObject);
		}
		GameObject gameObject3 = windowObj.transform.Find("panel-bg/title-text").gameObject;
		titleText = windowObj.transform.Find("panel-bg/title-text").GetComponent<Text>();
		GameObject gameObject4 = windowObj.transform.Find("panel-bg/x").gameObject;
		Button component = gameObject4.GetComponent<Button>();
		component.onClick.RemoveAllListeners();
		component.onClick.AddListener(delegate
		{
			CloseWindow();
		});
		switchSizeButtonObj = UnityEngine.Object.Instantiate(gameObject4, windowObj.transform.Find("panel-bg"));
		switchSizeButtonObj.name = "-";
		switchSizeButtonObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(-37f, -13f);
		switchSizeButtonObj.GetComponent<Image>().sprite = leftTriangleSprite;
		switchSizeButtonObj.GetComponent<UIButton>().tips.tipTitle = "收起/展开".Translate() + UIHotkeySettingPatcher.GetFoldHotkeyString();
		switchSizeButtonObj.GetComponent<UIButton>().tips.corner = 3;
		switchSizeButtonObj.GetComponent<UIButton>().tips.delay = 0.3f;
		Button component2 = switchSizeButtonObj.GetComponent<Button>();
		component2.onClick.RemoveAllListeners();
		component2.onClick.AddListener(delegate
		{
			SwitchWindowSize();
		});
		Transform parent = windowObj.transform.Find("panel-bg");
		GameObject gameObject5 = UnityEngine.Object.Instantiate(gameObject4);
		gameObject5.name = "save-all";
		gameObject5.transform.SetParent(parent, worldPositionStays: false);
		gameObject5.transform.localScale = Vector3.one;
		gameObject5.GetComponent<RectTransform>().anchorMin = new Vector2(1f, 1f);
		gameObject5.GetComponent<RectTransform>().anchorMax = new Vector2(1f, 1f);
		gameObject5.GetComponent<RectTransform>().pivot = new Vector2(1f, 1f);
		gameObject5.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(-64f, -14.5f, 0f);
		gameObject5.GetComponent<RectTransform>().sizeDelta = new Vector2(18f, 18f);
		gameObject5.GetComponent<Image>().sprite = doubleLayerSprite;
		gameObject5.GetComponent<Button>().onClick.AddListener(delegate
		{
			SaveAllUserPreferenceAsDefault();
		});
		gameObject5.GetComponent<UIButton>().tips.tipTitle = "保存为默认配置标题".Translate();
		gameObject5.GetComponent<UIButton>().tips.tipText = "保存为默认配置说明".Translate();
		gameObject5.GetComponent<UIButton>().tips.corner = 3;
		gameObject5.GetComponent<UIButton>().tips.width = 200;
		gameObject5.GetComponent<UIButton>().audios.enterName = "ui-hover-0";
		gameObject5.GetComponent<UIButton>().audios.downName = "ui-click-0";
		GameObject gameObject6 = UnityEngine.Object.Instantiate(iconObj_ButtonTip);
		gameObject6.name = "reset-all";
		gameObject6.transform.SetParent(parent, worldPositionStays: false);
		gameObject6.transform.localScale = Vector3.one;
		gameObject6.GetComponent<RectTransform>().anchorMin = new Vector2(1f, 1f);
		gameObject6.GetComponent<RectTransform>().anchorMax = new Vector2(1f, 1f);
		gameObject6.GetComponent<RectTransform>().pivot = new Vector2(1f, 1f);
		gameObject6.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(-89f, -14.5f, 0f);
		gameObject6.GetComponent<RectTransform>().sizeDelta = new Vector2(18f, 18f);
		gameObject6.GetComponent<Image>().sprite = resetSprite;
		gameObject6.GetComponent<Button>().onClick.AddListener(delegate
		{
			ClearAllUserPreference();
		});
		gameObject6.GetComponent<UIButton>().tips.tipTitle = "还原默认配置标题".Translate();
		gameObject6.GetComponent<UIButton>().tips.tipText = "还原默认配置说明".Translate();
		gameObject6.GetComponent<UIButton>().tips.corner = 3;
		gameObject6.GetComponent<UIButton>().tips.width = 200;
		gameObject6.GetComponent<UIButton>().transitions[0].normalColor = new Color(0.6f, 0f, 0f, 1f);
		gameObject6.GetComponent<UIButton>().transitions[0].pressedColor = new Color(0.6f, 0f, 0f, 1f);
		gameObject6.GetComponent<UIButton>().transitions[0].mouseoverColor = new Color(0.9f, 0.2f, 0.2f, 1f);
		viewGroupObj = windowObj.transform.Find("view-group").gameObject;
		viewGroupObj.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 0f);
		viewGroupObj.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 0f);
		viewGroupObj.GetComponent<RectTransform>().pivot = new Vector2(0f, 0f);
		viewGroupObj.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(12f, 12f, 0f);
		viewGroupObj.GetComponent<RectTransform>().sizeDelta = new Vector2(largeWindowViewGroupWidth, largeWindowViewGroupHeight);
		mainCanvasObj = windowObj.transform.Find("view-group/Scroll View/Viewport/Content").gameObject;
		contentTrans = mainCanvasObj.transform;
		GridLayoutGroup gridLayoutGroup = mainCanvasObj.AddComponent<GridLayoutGroup>();
		ContentSizeFitter contentSizeFitter = mainCanvasObj.AddComponent<ContentSizeFitter>();
		gridLayoutGroup.cellSize = new Vector2(890f, 80f);
		contentSizeFitter.horizontalFit = ContentSizeFitter.FitMode.Unconstrained;
		contentSizeFitter.verticalFit = ContentSizeFitter.FitMode.PreferredSize;
		contentScrollRect = windowObj.transform.Find("view-group/Scroll View").GetComponent<ScrollRect>();
		windowObj.transform.Find("view-group/Scroll View/Viewport").GetComponent<RectTransform>().sizeDelta = new Vector2(0f, -3f);
		Vector3 localPosition2 = windowObj.transform.Find("view-group/Scroll View/Viewport").transform.localPosition;
		windowObj.transform.Find("view-group/Scroll View/Viewport").transform.localPosition = new Vector3(localPosition2.x, localPosition2.y - 3f, localPosition2.z);
		Transform transform = windowObj.transform.Find("inspector-group-bg");
		transform.GetComponent<RectTransform>().sizeDelta = new Vector2(416f, 245f);
		GameObject gameObject7 = UnityEngine.Object.Instantiate(viewGroupObj, transform);
		gameObject7.GetComponent<RectTransform>().sizeDelta = new Vector2(416f, 407f);
		gameObject7.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(0f, -412f, 0f);
		GameObject gameObject8 = gameObject7.transform.Find("Scroll View/Viewport/Content").gameObject;
		sideContentTrans = gameObject8.transform;
		gameObject8.GetComponent<GridLayoutGroup>().cellSize = new Vector2(138.66f, 45f);
		windowObj.SetActive(value: true);
		titleText.text = "量化计算器".Translate();
		GameObject gameObject9 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Belt Window/number-input");
		if (gameObject9 == null)
		{
			Debug.LogError("Error when init oriInputField because some other mods has changed the Blueprint Browser UI. Please check if you've install the BluePrintTweaks and then contact jinxOAO.");
		}
		oriInputFieldObjNoSelIcon = UnityEngine.Object.Instantiate(gameObject9);
		oriInputFieldObjNoSelIcon.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
		oriInputFieldObjNoSelIcon.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
		if (oriInputFieldObjNoSelIcon.GetComponent<UIButton>().transitions.Length != 0)
		{
			oriInputFieldObjNoSelIcon.GetComponent<UIButton>().transitions[0].normalColor = new Color(0f, 0f, 0f, 0.4f);
		}
		oriInputFieldObjNoSelIcon.GetComponent<Image>().sprite = Resources.Load<Sprite>("ui/textures/sprites/sci-fi/litter-panel-cc");
		oriInputFieldObjNoSelIcon.GetComponent<InputField>().contentType = InputField.ContentType.Standard;
		oriInputFieldObjNoSelIcon.GetComponent<InputField>().characterValidation = InputField.CharacterValidation.None;
		oriInputFieldObjNoSelIcon.transform.Find(sonTextObjName).GetComponent<Text>().alignment = TextAnchor.MiddleLeft;
		oriInputFieldObjNoSelIcon.transform.Find(sonTextObjName).GetComponent<Text>().color = new Color(1f, 1f, 1f, 0.5f);
		oriInputFieldObjNoSelIcon.transform.Find(sonTextObjName).GetComponent<RectTransform>().anchorMax = new Vector2(0.92f, 1f);
		oriInputFieldObjNoSelIcon.transform.Find(sonTextObjName).GetComponent<RectTransform>().anchorMin = new Vector2(0.08f, 0f);
		oriInputFieldObjNoSelIcon.transform.Find(sonTextObjName).GetComponent<RectTransform>().anchoredPosition3D = Vector3.zero;
		customTitleInputObj = UnityEngine.Object.Instantiate(oriInputFieldObjNoSelIcon, windowObj.transform);
		customTitleInputObj.name = "inputfield-title";
		customTitleInputObj.GetComponent<RectTransform>().sizeDelta = new Vector2(200f, 30f);
		customTitleInputObj.GetComponent<RectTransform>().anchorMax = new Vector2(0.5f, 1f);
		customTitleInputObj.GetComponent<RectTransform>().anchorMin = new Vector2(0.5f, 1f);
		customTitleInputObj.GetComponent<RectTransform>().pivot = new Vector2(0.5f, 1f);
		customTitleInputObj.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(0f, -10f, 0f);
		titleInputBG = customTitleInputObj.GetComponent<Image>();
		titleInput = customTitleInputObj.GetComponent<InputField>();
		titleInput.text = "量化计算器".Translate();
		titleInput.characterLimit = 30;
		titleInput.transition = Selectable.Transition.None;
		titleInput.onEndEdit.RemoveAllListeners();
		customTitleInputObj.GetComponent<Image>().color = new Color(0f, 0f, 0f, 0.5f);
		customTitleInputObj.transform.Find(sonTextObjName).GetComponent<Text>().fontSize = 18;
		customTitleInputObj.transform.Find(sonTextObjName).GetComponent<Text>().font = titleText.font;
		customTitleInputObj.transform.Find(sonTextObjName).GetComponent<Text>().alignment = TextAnchor.MiddleCenter;
		customTitleInputObj.GetComponent<UIButton>().tips.tipTitle = "";
		customTitleInputObj.GetComponent<UIButton>().tips.tipText = "";
		customTitleInputObj.SetActive(value: false);
		customTitleInputObj.SetActive(value: true);
		titleInputUIBtn = customTitleInputObj.GetComponent<UIButton>();
		UIButton.Transition transition = new UIButton.Transition
		{
			target = customTitleInputObj.GetComponent<Image>(),
			normalColor = new Color(0f, 0f, 0f, 0.01f),
			mouseoverColor = new Color(0f, 0f, 0f, 0.3f),
			highlightColorOverride = new Color(0f, 0f, 0f, 0.5f),
			damp = 0.3f,
			highlightColorMultiplier = 1f,
			highlightSizeMultiplier = 1f,
			mouseoverSize = 1f,
			pressedColor = new Color(0f, 0f, 0f, 0.5f),
			pressedSize = 1f
		};
		titleInputUIBtn.transitions = new UIButton.Transition[1] { transition };
		titleInputUIBtn.highlighted = false;
		if (DSPCalculatorPlugin.EditableTitle.Value)
		{
			gameObject3.SetActive(value: false);
		}
		else
		{
			customTitleInputObj.SetActive(value: false);
		}
		targetProductTextObj = UnityEngine.Object.Instantiate(TextObj, parent);
		targetProductTextObj.name = "target-title";
		targetProductTextObj.transform.localScale = Vector3.one;
		targetProductTextObj.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(25f, 318f, 0f);
		targetProductTextObj.GetComponent<Text>().text = "设置目标产物".Translate();
		targetProductTextObj.GetComponent<Text>().fontSize = 16;
		GameObject gameObject10 = UnityEngine.Object.Instantiate(iconObj_ButtonTip, targetProductTextObj.transform);
		gameObject10.name = "copy";
		gameObject10.transform.localScale = Vector3.one;
		gameObject10.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 0.5f);
		gameObject10.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 0.5f);
		gameObject10.GetComponent<RectTransform>().pivot = new Vector2(0f, 0.5f);
		gameObject10.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(100f, -1f, 0f);
		gameObject10.GetComponent<RectTransform>().sizeDelta = new Vector2(16f, 16f);
		gameObject10.GetComponent<Image>().sprite = copySprite;
		gameObject10.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnCopyButtonClick();
		});
		gameObject10.GetComponent<UIButton>().tips.tipTitle = "calc复制标题".Translate();
		gameObject10.GetComponent<UIButton>().tips.tipText = "calc复制说明".Translate();
		gameObject10.GetComponent<UIButton>().tips.corner = 3;
		gameObject10.GetComponent<UIButton>().tips.width = 200;
		gameObject10.GetComponent<UIButton>().transitions[0].normalColor = new Color(0.6f, 0.6f, 0.6f, 1f);
		gameObject10.GetComponent<UIButton>().transitions[0].pressedColor = new Color(0.4f, 0.4f, 0.4f, 1f);
		gameObject10.GetComponent<UIButton>().transitions[0].mouseoverColor = new Color(0.8f, 0.8f, 0.8f, 1f);
		GameObject gameObject11 = UnityEngine.Object.Instantiate(iconObj_ButtonTip, targetProductTextObj.transform);
		gameObject11.name = "paste";
		gameObject11.transform.localScale = Vector3.one;
		gameObject11.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 0.5f);
		gameObject11.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 0.5f);
		gameObject11.GetComponent<RectTransform>().pivot = new Vector2(0f, 0.5f);
		gameObject11.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(120f, -1f, 0f);
		gameObject11.GetComponent<RectTransform>().sizeDelta = new Vector2(16f, 16f);
		gameObject11.GetComponent<Image>().sprite = pasteSprite;
		gameObject11.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnPasteButtonClick();
		});
		gameObject11.GetComponent<UIButton>().tips.tipTitle = "calc粘贴标题".Translate();
		gameObject11.GetComponent<UIButton>().tips.tipText = "calc粘贴说明".Translate();
		gameObject11.GetComponent<UIButton>().tips.corner = 3;
		gameObject11.GetComponent<UIButton>().tips.width = 200;
		gameObject11.GetComponent<UIButton>().transitions[0].normalColor = new Color(0.6f, 0.6f, 0.6f, 1f);
		gameObject11.GetComponent<UIButton>().transitions[0].pressedColor = new Color(0.4f, 0.4f, 0.4f, 1f);
		gameObject11.GetComponent<UIButton>().transitions[0].mouseoverColor = new Color(0.8f, 0.8f, 0.8f, 1f);
		GameObject gameObject12 = UnityEngine.Object.Instantiate(iconObj_ButtonTip, targetProductTextObj.transform);
		gameObject12.name = "pre-set-ore";
		gameObject12.transform.localScale = Vector3.one;
		gameObject12.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(141f, 0f, 0f);
		gameObject12.GetComponent<RectTransform>().sizeDelta = new Vector2(20f, 20f);
		gameObject12.GetComponent<Image>().sprite = oreSprite;
		gameObject12.GetComponent<UIButton>().onClick += delegate
		{
			OnPresetOreButtonClick();
		};
		gameObject12.GetComponent<UIButton>().onRightClick += delegate
		{
			OnPresetOreButtonRightClick();
		};
		gameObject12.GetComponent<UIButton>().tips.tipTitle = "预先设置原矿标题".Translate();
		gameObject12.GetComponent<UIButton>().tips.tipText = "预先设置原矿说明".Translate();
		gameObject12.GetComponent<UIButton>().tips.corner = 3;
		gameObject12.GetComponent<UIButton>().tips.width = 200;
		Navigation navigation = new Navigation
		{
			mode = Navigation.Mode.None
		};
		gameObject12.GetComponent<Button>().navigation = navigation;
		GameObject gameObject13 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Station Window/storage-box-0/storage-icon-empty");
		if (gameObject13 != null)
		{
			targetProductIconObj = UnityEngine.Object.Instantiate(gameObject13);
			targetProductIconObj.name = "target-product";
			targetProductIconObj.transform.SetParent(parent);
			targetProductIconObj.transform.localScale = Vector3.one;
			RectTransform component3 = targetProductIconObj.GetComponent<RectTransform>();
			component3.anchorMax = new Vector2(0f, 1f);
			component3.anchorMin = new Vector2(0f, 1f);
			component3.anchoredPosition3D = new Vector3(targetIconAnchoredPosX, targetIconAnchoredPosYLargeWindow, 0f);
			component3.sizeDelta = new Vector2(54f, 54f);
			targetProductIconObj.transform.Find("white").GetComponent<RectTransform>().sizeDelta = new Vector2(40f, 40f);
			targetProductIconObj.GetComponent<UIButton>().transitions[0].normalColor = itemIconNormalColor;
			targetProductIconObj.GetComponent<UIButton>().transitions[0].mouseoverColor = itemIconHighlightColor;
			targetProductIcon = targetProductIconObj.transform.Find("white").GetComponent<Image>();
			targetProductIconObj.GetComponent<Button>().onClick.RemoveAllListeners();
			targetProductIconObj.GetComponent<Button>().onClick.AddListener(delegate
			{
				OnTargetProductIconClick();
			});
			targetProductIcon.sprite = Resources.Load<Sprite>("ui/textures/sprites/icons/controlpanel-icon-40");
			targetProductIconUIBtn = targetProductIconObj.GetComponent<UIButton>();
			GameObject gameObject14 = new GameObject("circle-progress");
			progressCircleImg = gameObject14.AddComponent<Image>();
			gameObject14.transform.SetParent(targetProductIconObj.transform, worldPositionStays: false);
			gameObject14.transform.localScale = Vector3.one;
			gameObject14.GetComponent<RectTransform>().anchoredPosition3D = Vector3.zero;
			gameObject14.GetComponent<RectTransform>().sizeDelta = new Vector2(54f, 54f);
			progressCircleImg.sprite = circleThinSprite;
			progressCircleImg.type = Image.Type.Filled;
			progressCircleImg.fillMethod = Image.FillMethod.Radial360;
			progressCircleImg.fillAmount = 0f;
			progressCircleImg.fillOrigin = 2;
			progressCircleImg.material = targetProductIcon.material;
			progressCircleImg.color = inProgressColor;
		}
		else
		{
			Debug.LogError("Error when init UICalcWindow.");
		}
		speedInputObj = UnityEngine.Object.Instantiate(oriInputFieldObjNoSelIcon, parent);
		speedInputObj.name = "speed-input";
		speedInputObj.transform.localPosition = new Vector3(120f, 0f, 0f);
		speedInputObj.GetComponent<RectTransform>().sizeDelta = new Vector2(110f, 30f);
		speedInputObj.GetComponent<RectTransform>().pivot = new Vector2(0f, 0.5f);
		speedInputObj.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(90f, targetIconAnchoredPosYLargeWindow, 0f);
		speedInputObj.GetComponent<InputField>().text = "3600";
		speedInputObj.GetComponent<InputField>().contentType = InputField.ContentType.DecimalNumber;
		speedInputObj.GetComponent<InputField>().characterLimit = 12;
		speedInputObj.GetComponent<InputField>().transition = Selectable.Transition.None;
		speedInputObj.GetComponent<InputField>().onEndEdit.RemoveAllListeners();
		speedInputObj.GetComponent<InputField>().onEndEdit.AddListener(delegate(string num10)
		{
			OnTargetSpeedChange(num10);
		});
		speedInputObj.GetComponent<Image>().color = new Color(1f, 1f, 1f, 1f);
		speedInputObj.transform.Find(sonTextObjName).GetComponent<Text>().fontSize = 16;
		speedInputObj.GetComponent<UIButton>().tips.tipTitle = "";
		speedInputObj.GetComponent<UIButton>().tips.tipText = "";
		speedInputObj.SetActive(value: true);
		perMinTextObj = UnityEngine.Object.Instantiate(TextObj, parent);
		perMinTextObj.name = "per-minute";
		perMinTextObj.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
		perMinTextObj.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
		perMinTextObj.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(210f, targetIconAnchoredPosYLargeWindow, 0f);
		perMinTextObj.GetComponent<Text>().text = "/min";
		incToggleObj = UnityEngine.Object.Instantiate(incTogglePrefabObj, parent);
		incToggleObj.name = "inc-setting";
		incToggleObj.transform.localPosition = new Vector3(-38f, 287f, 0f);
		incToggleObj.transform.Find("inc-switch").GetComponent<Button>().onClick.AddListener(delegate
		{
			OnGlobalIncToggleClick();
		});
		incText = incToggleObj.transform.Find("inc-effect-type-text").GetComponent<Text>();
		GameObject gameObject15 = incToggleObj.transform.Find("inc-switch/switch-thumb").gameObject;
		if (solution.userPreference.globalIsInc)
		{
			gameObject15.GetComponent<RectTransform>().anchoredPosition = new Vector2(-10f, 0f);
			incText.text = "额外产出calc".Translate();
			incText.color = incModeTextColor;
			incToggleObj.transform.Find("inc-switch").GetComponent<Image>().color = incModeImageColor;
		}
		else
		{
			gameObject15.GetComponent<RectTransform>().anchoredPosition = new Vector2(10f, 0f);
			incText.text = "生产加速calc".Translate();
			incText.color = accModeTextColor;
			incToggleObj.transform.Find("inc-switch").GetComponent<Image>().color = accModeImageColor;
		}
		incToggleObj.SetActive(value: true);
		proliferatorSelectionObj = new GameObject();
		proliferatorSelectionObj.name = "proliferator-select";
		proliferatorSelectionObj.transform.SetParent(parent, worldPositionStays: false);
		proliferatorSelectionObj.transform.localPosition = new Vector3(82f, 270f, 0f);
		int itemId = 0;
		int incLevel0 = 0;
		GameObject gameObject16 = UnityEngine.Object.Instantiate(imageButtonObj, proliferatorSelectionObj.transform);
		gameObject16.GetComponent<Image>().sprite = buttonBackgroundSprite;
		Image component4 = gameObject16.transform.Find("icon").GetComponent<Image>();
		component4.sprite = bannedSprite;
		component4.color = Color.red;
		gameObject16.transform.localPosition = new Vector3(0f, 0f);
		gameObject16.GetComponent<Button>().onClick.AddListener(delegate
		{
			SetGlobalIncLevel(incLevel0);
		});
		proliferatorUsedButtons[incLevel0] = gameObject16.GetComponent<UIButton>();
		proliferatorUsedButtons[incLevel0].tips.itemId = itemId;
		for (int num2 = 0; num2 < CalcDB.proliferatorItemIds.Count; num2++)
		{
			int num3 = CalcDB.proliferatorItemIds[num2];
			int incLevel1 = CalcDB.proliferatorAbilitiesMap[num3];
			GameObject gameObject17 = UnityEngine.Object.Instantiate(imageButtonObj, proliferatorSelectionObj.transform);
			gameObject17.GetComponent<Image>().sprite = buttonBackgroundSprite;
			Image component5 = gameObject17.transform.Find("icon").GetComponent<Image>();
			component5.sprite = LDB.items.Select(num3).iconSprite;
			gameObject17.transform.localPosition = new Vector3((num2 + 1) * 35, 0f);
			gameObject17.GetComponent<Button>().onClick.AddListener(delegate
			{
				SetGlobalIncLevel(incLevel1);
			});
			proliferatorUsedButtons[incLevel1] = gameObject17.GetComponent<UIButton>();
			proliferatorUsedButtons[incLevel1].tips.itemId = num3;
		}
		assemblerSelectionObj = new GameObject();
		assemblerSelectionObj.name = "assembler-select";
		assemblerSelectionObj.transform.SetParent(parent, worldPositionStays: false);
		float num4 = 0f;
		float num5 = 0f;
		if (CompatManager.GB)
		{
			num4 = -35f;
			num5 = -10f;
		}
		assemblerSelectionObj.transform.localPosition = new Vector3(-358f + num4, 270f + num5, 0f);
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		int num6 = 0;
		int num7 = 0;
		int num8 = 0;
		foreach (KeyValuePair<int, List<AssemblerData>> item in CalcDB.assemblerListByType)
		{
			if ((float)(num6 * 35 + num7 * 10) + num4 > 315f)
			{
				num8++;
				num6 = 0;
				num7 = 0;
			}
			int typeInt = item.Key;
			if (!assemblerUsedButtons.ContainsKey(typeInt))
			{
				assemblerUsedButtons[typeInt] = new Dictionary<int, UIButton>();
			}
			List<AssemblerData> value = item.Value;
			if (value.Count <= 1)
			{
				continue;
			}
			for (int num9 = 0; num9 < value.Count; num9++)
			{
				AssemblerData assemblerData = value[num9];
				int assemblerItemId = assemblerData.ID;
				dictionary[assemblerItemId] = 1;
				GameObject gameObject18 = UnityEngine.Object.Instantiate(imageButtonObj, assemblerSelectionObj.transform);
				gameObject18.GetComponent<Image>().sprite = buttonBackgroundSprite;
				Image component6 = gameObject18.transform.Find("icon").GetComponent<Image>();
				component6.sprite = assemblerData.iconSprite;
				gameObject18.transform.localPosition = new Vector3(num6 * 35 + num7 * 10, num8 * 35);
				gameObject18.GetComponent<Button>().onClick.AddListener(delegate
				{
					SetGlobalAssemblerPreference(typeInt * 100000 + assemblerItemId);
				});
				gameObject18.GetComponent<UIButton>().highlighted = false;
				gameObject18.GetComponent<UIButton>().tips.itemId = assemblerItemId;
				gameObject18.GetComponent<UIButton>().tips.corner = 3;
				gameObject18.GetComponent<UIButton>().tips.delay = 0.1f;
				assemblerUsedButtons[typeInt][assemblerItemId] = gameObject18.GetComponent<UIButton>();
				num6++;
			}
			num7++;
		}
		if (CompatManager.MMS)
		{
			if ((float)(num6 * 35 + num7 * 10) + num4 > 315f)
			{
				num8++;
				num6 = 0;
				num7 = 0;
			}
			GameObject gameObject19 = UnityEngine.Object.Instantiate(imageButtonObj, assemblerSelectionObj.transform);
			gameObject19.GetComponent<Image>().sprite = buttonBackgroundSprite;
			GameObject gameObject20 = gameObject19.transform.Find("icon").gameObject;
			GameObject gameObject21 = UnityEngine.Object.Instantiate(gameObject20, gameObject20.transform);
			gameObject21.name = "sub-icon";
			gameObject21.GetComponent<RectTransform>().sizeDelta = new Vector2(20f, 20f);
			gameObject21.GetComponent<RectTransform>().anchoredPosition = new Vector2(3f, -3f);
			Image component7 = gameObject19.transform.Find("icon").GetComponent<Image>();
			IABtnSpecializationImg = gameObject21.GetComponent<Image>();
			IABtnSpecializationImg.sprite = LDB.items.Select(IASpecializationIconItemMap[0])?.iconSprite;
			Sprite sprite = LDB.items.Select(IAIconItemId)?.iconSprite;
			gameObject20.GetComponent<RectTransform>().sizeDelta = new Vector2(25f, 25f);
			if (sprite != null)
			{
				component7.sprite = sprite;
			}
			else
			{
				component7.sprite = Resources.Load<Sprite>("ui/textures/sprites/starmap/planets-icon");
			}
			gameObject19.transform.localPosition = new Vector3(num6 * 35 + num7 * 10, num8 * 35);
			if (CompatManager.GB)
			{
				gameObject19.transform.localPosition = new Vector3(415f, 0f);
			}
			gameObject19.GetComponent<Button>().onClick.AddListener(delegate
			{
				SetGlobalAssemblerPreference(-1);
			});
			gameObject19.GetComponent<UIButton>().highlighted = false;
			gameObject19.GetComponent<UIButton>().tips.tipTitle = "使用星际组装厂按钮标题".Translate();
			gameObject19.GetComponent<UIButton>().tips.tipText = "使用星际组装厂按钮说明".Translate();
			gameObject19.GetComponent<UIButton>().tips.corner = 3;
			gameObject19.GetComponent<UIButton>().tips.delay = 0.1f;
			gameObject19.GetComponent<UIButton>().tips.width = 250;
			if (!assemblerUsedButtons.ContainsKey(-1))
			{
				assemblerUsedButtons[-1] = new Dictionary<int, UIButton>();
			}
			assemblerUsedButtons[-1][-1] = gameObject19.GetComponent<UIButton>();
			num6++;
			num7++;
		}
		bool flag = true;
		genBpButtonObj = UnityEngine.Object.Instantiate(iconObj_ButtonTip, parent);
		genBpButtonObj.name = "gen-bp";
		genBpButtonObj.transform.localScale = Vector3.one;
		genBpButtonObj.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
		genBpButtonObj.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
		genBpButtonObj.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(245f, -80f, 0f);
		if (CompatManager.GB)
		{
			genBpButtonObj.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(240f, -80f, 0f);
		}
		genBpButtonObj.GetComponent<RectTransform>().sizeDelta = new Vector2(25f, 25f);
		genBpButtonObj.GetComponent<Image>().sprite = blueprintIconSprite;
		genBpButtonObj.GetComponent<Button>().onClick.AddListener(delegate
		{
			GenerateBlackboxBpAndPaste();
		});
		genBpUIBtn = genBpButtonObj.GetComponent<UIButton>();
		genBpButtonObj.GetComponent<UIButton>().tips.tipTitle = "生成黑盒蓝图标题".Translate();
		genBpButtonObj.GetComponent<UIButton>().tips.tipText = "生成黑盒蓝图说明".Translate();
		genBpButtonObj.GetComponent<UIButton>().tips.corner = 3;
		genBpButtonObj.GetComponent<UIButton>().tips.width = 270;
		Navigation navigation2 = new Navigation
		{
			mode = Navigation.Mode.None
		};
		genBpButtonObj.GetComponent<Button>().navigation = navigation2;
		GameObject original2 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy/layers/buttons-group/buttons/add-button");
		GameObject gameObject22 = new GameObject("info-page-switch-btns");
		gameObject22.transform.SetParent(transform);
		gameObject22.transform.localScale = Vector3.one;
		gameObject22.transform.localPosition = Vector3.zero;
		Transform transform2 = gameObject22.transform;
		GameObject gameObject23 = UnityEngine.Object.Instantiate(original2, transform2);
		gameObject23.name = "0";
		gameObject23.transform.localPosition = new Vector3(10f, 23.8f, 0f);
		gameObject23.GetComponent<RectTransform>().sizeDelta = new Vector2(110f, 25f);
		gameObject23.transform.Find("Text").GetComponent<Localizer>().stringKey = "右侧面板0";
		gameObject23.transform.Find("Text").GetComponent<Text>().text = "右侧面板0".Translate();
		gameObject23.GetComponent<Button>().onClick.RemoveAllListeners();
		gameObject23.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnSideInfoPageChange(0);
		});
		UIButton component8 = gameObject23.GetComponent<UIButton>();
		gameObject23.GetComponent<Image>().material = transform.GetComponent<Image>().material;
		component8.transitions[0].highlightColorOverride = transform.GetComponent<Image>().color;
		component8.transitions[0].mouseoverColor = new Color(0.187f, 0.693f, 0.811f, 0.58f);
		sideInfoPanelSwitchUIBtns.Add(gameObject23.GetComponent<UIButton>());
		GameObject gameObject24 = UnityEngine.Object.Instantiate(original2, transform2);
		gameObject24.name = "1";
		gameObject24.transform.localPosition = new Vector3(120f, 23.8f, 0f);
		gameObject24.GetComponent<RectTransform>().sizeDelta = new Vector2(110f, 25f);
		gameObject24.transform.Find("Text").GetComponent<Localizer>().stringKey = "右侧面板1";
		gameObject24.transform.Find("Text").GetComponent<Text>().text = "右侧面板1".Translate();
		gameObject24.GetComponent<Button>().onClick.RemoveAllListeners();
		gameObject24.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnSideInfoPageChange(1);
		});
		UIButton component9 = gameObject24.GetComponent<UIButton>();
		gameObject24.GetComponent<Image>().material = transform.GetComponent<Image>().material;
		component9.transitions[0].highlightColorOverride = transform.GetComponent<Image>().color;
		component9.transitions[0].mouseoverColor = new Color(0.187f, 0.693f, 0.811f, 0.58f);
		sideInfoPanelSwitchUIBtns.Add(gameObject24.GetComponent<UIButton>());
		GameObject gameObject25 = new GameObject("info-panel-0");
		gameObject25.transform.SetParent(transform);
		gameObject25.transform.localScale = Vector3.one;
		gameObject25.transform.localPosition = Vector3.zero;
		Transform transform3 = gameObject25.transform;
		sideInfoPanelObjs.Add(gameObject25);
		GameObject gameObject26 = new GameObject("info-panel-1");
		gameObject26.transform.SetParent(transform);
		gameObject26.transform.localScale = Vector3.one;
		gameObject26.transform.localPosition = Vector3.zero;
		Transform transform4 = gameObject26.transform;
		sideInfoPanelObjs.Add(gameObject26);
		GameObject gameObject27 = UnityEngine.Object.Instantiate(TextObj, transform3);
		gameObject27.name = "final-info";
		gameObject27.transform.localPosition = new Vector3(15f, -20f, 0f);
		finalInfoText = gameObject27.GetComponent<Text>();
		finalInfoText.fontSize = 16;
		finalInfoText.alignment = TextAnchor.UpperLeft;
		GameObject gameObject28 = UnityEngine.Object.Instantiate(TextObj, transform3);
		gameObject28.transform.localPosition = new Vector3(15f, -82f, 0f);
		assemblerDemandsTitleText = gameObject28.GetComponent<Text>();
		assemblerDemandsTitleText.fontSize = 16;
		assemblerDemandsTitleText.alignment = TextAnchor.UpperLeft;
		assemblerDemandsTitleText.text = "工厂需求".Translate();
		assemblersDemandsGroupObj = new GameObject();
		assemblersDemandsGroupObj.name = "assember-demands";
		assemblersDemandsGroupObj.transform.SetParent(transform3);
		assemblersDemandsGroupObj.transform.localScale = Vector3.one;
		assemblersDemandsGroupObj.transform.localPosition = new Vector3(13f, -110f, 0f);
		GameObject gameObject29 = new GameObject();
		gameObject29.name = "checkbox-group";
		gameObject29.transform.SetParent(transform3);
		gameObject29.transform.localScale = Vector3.one;
		gameObject29.transform.localPosition = new Vector3(155f, -20f, 0f);
		if (CompatManager.TCFV)
		{
			GameObject gameObject30 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject29.transform);
			gameObject30.name = "checkbox-bluebuff";
			cbBluebuff = gameObject30.GetComponent<Image>();
			txtBluebuff = gameObject30.transform.Find("text").GetComponent<Text>();
			gameObject30.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(0f, 0f, 0f);
			gameObject30.GetComponent<Button>().onClick.AddListener(OnBluebuffClick);
			gameObject30.transform.Find("text").GetComponent<Localizer>().stringKey = "遗物名称0-1".Translate().Split(new char[1] { '\n' })[0];
			GameObject gameObject31 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject29.transform);
			gameObject31.name = "checkbox-energyburst";
			cbEnergyBurst = gameObject31.GetComponent<Image>();
			txtEnergyBurst = gameObject31.transform.Find("text").GetComponent<Text>();
			gameObject31.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(0f, -20f, 0f);
			gameObject31.GetComponent<Button>().onClick.AddListener(OnEnergyBurstClick);
			gameObject31.transform.Find("text").GetComponent<Localizer>().stringKey = "遗物名称1-6".Translate().Split(new char[1] { '\n' })[0];
			GameObject gameObject32 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject29.transform);
			gameObject32.name = "checkbox-dirac";
			cbDirac = gameObject32.GetComponent<Image>();
			txtDirac = gameObject32.transform.Find("text").GetComponent<Text>();
			gameObject32.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(0f, -40f, 0f);
			gameObject32.GetComponent<Button>().onClick.AddListener(OnDiracClick);
			gameObject32.transform.Find("text").GetComponent<Localizer>().stringKey = "遗物名称2-8".Translate().Split(new char[1] { '\n' })[0];
			GameObject gameObject33 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject29.transform);
			gameObject33.name = "checkbox-inferior";
			cbInferior = gameObject33.GetComponent<Image>();
			txtInferior = gameObject33.transform.Find("text").GetComponent<Text>();
			gameObject33.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(0f, -60f, 0f);
			gameObject33.GetComponent<Button>().onClick.AddListener(OnInferiorClick);
			gameObject33.transform.Find("text").GetComponent<Localizer>().stringKey = "遗物名称3-0".Translate().Split(new char[1] { '\n' })[0];
		}
		GameObject gameObject34 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject29.transform);
		gameObject34.name = "checkbox-custom-inc";
		cbIncMilli = gameObject34.GetComponent<Image>();
		txtIncMilli = gameObject34.transform.Find("text").GetComponent<Text>();
		gameObject34.transform.Find("text").GetComponent<Localizer>().stringKey = "强制增产效能";
		GameObject gameObject35 = UnityEngine.Object.Instantiate(gameObject34.transform.Find("text").gameObject, gameObject34.transform);
		gameObject35.GetComponent<Localizer>().stringKey = "%";
		gameObject35.GetComponent<Text>().text = "%";
		gameObject35.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(132f, 0f, 0f);
		gameObject34.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(110f, 0f, 0f);
		gameObject34.GetComponent<Button>().onClick.AddListener(OnCustomIncMilliClick);
		gameObject34.GetComponent<UIButton>().tips.tipTitle = "强制增产效能标题".Translate();
		gameObject34.GetComponent<UIButton>().tips.tipText = "强制增产效能说明".Translate();
		gameObject34.GetComponent<UIButton>().tips.corner = 1;
		gameObject34.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject34.GetComponent<UIButton>().tips.width = 400;
		GameObject gameObject36 = UnityEngine.Object.Instantiate(oriInputFieldObjNoSelIcon, gameObject29.transform);
		gameObject36.name = "inputfield-inc";
		gameObject36.GetComponent<RectTransform>().sizeDelta = new Vector2(25f, 20f);
		gameObject36.GetComponent<RectTransform>().pivot = new Vector2(0f, 0.5f);
		gameObject36.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(215f, 0f, 0f);
		incInput = gameObject36.GetComponent<InputField>();
		gameObject36.GetComponent<InputField>().text = "25";
		gameObject36.GetComponent<InputField>().contentType = InputField.ContentType.IntegerNumber;
		gameObject36.GetComponent<InputField>().characterLimit = 3;
		gameObject36.GetComponent<InputField>().transition = Selectable.Transition.None;
		gameObject36.GetComponent<InputField>().onEndEdit.RemoveAllListeners();
		gameObject36.GetComponent<InputField>().onEndEdit.AddListener(delegate(string input)
		{
			OnEndEditIncMilli(input);
		});
		gameObject36.GetComponent<Image>().color = new Color(0f, 0f, 0f, 0.5f);
		gameObject36.transform.Find(sonTextObjName).GetComponent<Text>().fontSize = 12;
		gameObject36.GetComponent<UIButton>().tips.tipTitle = "";
		gameObject36.GetComponent<UIButton>().tips.tipText = "";
		GameObject gameObject37 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject29.transform);
		gameObject37.name = "checkbox-custom-acc";
		cbAccMilli = gameObject37.GetComponent<Image>();
		txtAccMilli = gameObject37.transform.Find("text").GetComponent<Text>();
		gameObject37.transform.Find("text").GetComponent<Localizer>().stringKey = "强制加速效能";
		GameObject gameObject38 = UnityEngine.Object.Instantiate(gameObject37.transform.Find("text").gameObject, gameObject37.transform);
		gameObject38.GetComponent<Localizer>().stringKey = "%";
		gameObject38.GetComponent<Text>().text = "%";
		gameObject38.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(132f, 0f, 0f);
		gameObject37.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(110f, -20f, 0f);
		gameObject37.GetComponent<Button>().onClick.AddListener(OnCustomAccMilliClick);
		gameObject37.GetComponent<UIButton>().tips.tipTitle = "强制加速效能标题".Translate();
		gameObject37.GetComponent<UIButton>().tips.tipText = "强制加速效能说明".Translate();
		gameObject37.GetComponent<UIButton>().tips.corner = 1;
		gameObject37.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject37.GetComponent<UIButton>().tips.width = 400;
		GameObject gameObject39 = UnityEngine.Object.Instantiate(oriInputFieldObjNoSelIcon, gameObject29.transform);
		gameObject39.name = "inputfield-acc";
		gameObject39.GetComponent<RectTransform>().sizeDelta = new Vector2(25f, 20f);
		gameObject39.GetComponent<RectTransform>().pivot = new Vector2(0f, 0.5f);
		gameObject39.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(215f, -20f, 0f);
		accInput = gameObject39.GetComponent<InputField>();
		gameObject39.GetComponent<InputField>().text = "100";
		gameObject39.GetComponent<InputField>().contentType = InputField.ContentType.IntegerNumber;
		gameObject39.GetComponent<InputField>().characterLimit = 3;
		gameObject39.GetComponent<InputField>().transition = Selectable.Transition.None;
		gameObject39.GetComponent<InputField>().onEndEdit.RemoveAllListeners();
		gameObject39.GetComponent<InputField>().onEndEdit.AddListener(delegate(string input)
		{
			OnEndEditAccMilli(input);
		});
		gameObject39.GetComponent<Image>().color = new Color(0f, 0f, 0f, 0.5f);
		gameObject39.transform.Find(sonTextObjName).GetComponent<Text>().fontSize = 12;
		gameObject39.GetComponent<UIButton>().tips.tipTitle = "";
		gameObject39.GetComponent<UIButton>().tips.tipText = "";
		GameObject gameObject40 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject29.transform);
		gameObject40.name = "checkbox-roundup";
		cbRoundUp = gameObject40.GetComponent<Image>();
		txtRoundUp = gameObject40.transform.Find("text").GetComponent<Text>();
		gameObject40.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(110f, -40f, 0f);
		gameObject40.GetComponent<Button>().onClick.AddListener(OnAssemblerRoundUpSettingChange);
		gameObject40.transform.Find("text").GetComponent<Localizer>().stringKey = "生产设施数量显示向上取整";
		GameObject gameObject41 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject29.transform);
		gameObject41.name = "checkbox-roundup";
		cbSolveProlifer = gameObject41.GetComponent<Image>();
		txtSolveProlifer = gameObject41.transform.Find("text").GetComponent<Text>();
		gameObject41.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(110f, -60f, 0f);
		gameObject41.GetComponent<Button>().onClick.AddListener(OnSolveProliferatorSettingChange);
		gameObject41.GetComponent<UIButton>().tips.tipTitle = "增产剂并入产线".Translate();
		gameObject41.GetComponent<UIButton>().tips.tipText = "增产剂并入产线描述".Translate();
		gameObject41.GetComponent<UIButton>().tips.corner = 1;
		gameObject41.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject41.GetComponent<UIButton>().tips.width = 300;
		gameObject41.transform.Find("text").GetComponent<Localizer>().stringKey = "增产剂并入产线";
		GameObject gameObject42 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject29.transform);
		gameObject42.name = "checkbox-mixbelt";
		cbMixbelt = gameObject42.GetComponent<Image>();
		txtMixbelt = gameObject42.transform.Find("text").GetComponent<Text>();
		gameObject42.GetComponent<UIButton>().tips.tipTitle = "混带显示标题".Translate();
		gameObject42.GetComponent<UIButton>().tips.tipText = "混带显示说明".Translate();
		gameObject42.GetComponent<UIButton>().tips.corner = 1;
		gameObject42.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject42.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(110f, -60f, 0f);
		gameObject42.GetComponent<Button>().onClick.AddListener(OnMixbeltInfoCbClick);
		gameObject42.SetActive(DSPCalculatorPlugin.showMixBeltCheckbox);
		gameObject42.transform.Find("text").GetComponent<Localizer>().stringKey = "混带显示标题";
		InitBpPreferceUI(transform4);
		RefreshSideInfoPanels();
		RefreshAssemblerButtonDisplay();
		RefreshProliferatorButtonDisplay();
		RefreshBpGenButton();
		RefreshProgressCircle();
		TryLoadDefault();
	}

	public static void TryInitStaticPrefabs()
	{
		if (recipeObj == null)
		{
			UIItemTip uIItemTip = UnityEngine.Object.Instantiate(Configs.builtin.uiItemTipPrefab);
			recipeObj = uIItemTip.gameObject.transform.Find("recipe").gameObject;
			arrowObj = recipeObj.transform.Find("arrow").gameObject;
			iconObj_NoTip = recipeObj.transform.Find("icon").gameObject;
			iconObj_ButtonTip = UnityEngine.Object.Instantiate(iconObj_NoTip);
			iconObj_ButtonTip.GetComponent<Image>().raycastTarget = true;
			iconObj_ButtonTip.transform.Find("count").gameObject.SetActive(value: false);
			UIButton uIButton = iconObj_ButtonTip.AddComponent<UIButton>();
			Button button = iconObj_ButtonTip.AddComponent<Button>();
			uIButton.button = button;
			uIButton.audios = default(UIButton.AudioSettings);
			uIButton.audios.enterName = "ui-hover-0";
			uIButton.audios.downName = "ui-click-0";
			uIButton.audios.upName = "";
			uIButton.transitions = new UIButton.Transition[1];
			UIButton.Transition transition = new UIButton.Transition();
			uIButton.transitions[0] = transition;
			transition.target = iconObj_ButtonTip.GetComponent<Image>();
			transition.damp = 0.3f;
			transition.mouseoverSize = 1f;
			transition.pressedSize = 1f;
			transition.normalColor = itemIconNormalColor;
			transition.mouseoverColor = itemIconHighlightColor;
			transition.pressedColor = itemIconPressedColor;
			transition.disabledColor = itemIconDisabledColor;
			RectTransform component = iconObj_ButtonTip.GetComponent<RectTransform>();
			component.anchorMax = new Vector2(0f, 0.5f);
			component.anchorMin = new Vector2(0f, 0.5f);
			component.pivot = new Vector2(0f, 0.5f);
			TextObj = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Assembler Window/state/state-text"));
			TextObj.GetComponent<Text>().text = "";
			TextObj.GetComponent<Text>().alignment = TextAnchor.MiddleLeft;
			TextObj.GetComponent<Text>().color = TextWhiteColor;
			TextObj.GetComponent<Text>().lineSpacing = 0.7f;
			TextWithUITip = UnityEngine.Object.Instantiate(TextObj);
			UIButton uIButton2 = TextWithUITip.AddComponent<UIButton>();
			Button button2 = TextWithUITip.AddComponent<Button>();
			button2.transition = Selectable.Transition.None;
			uIButton2.button = button2;
			uIButton2.transitions = new UIButton.Transition[0];
			GameObject original = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy/layers/buttons-group/buttons/add-button");
			textButtonObj = UnityEngine.Object.Instantiate(original);
			textButtonObj.name = "button";
			textButtonObj.transform.localScale = Vector3.one;
			textButtonObj.GetComponent<Button>().onClick.RemoveAllListeners();
			textButtonObj.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
			textButtonObj.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
			GameObject original2 = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Power Generator Window/ray-receiver/switch-button-1");
			imageButtonObj = UnityEngine.Object.Instantiate(original2);
			imageButtonObj.name = "button-img";
			imageButtonObj.GetComponent<Button>().onClick.RemoveAllListeners();
			imageButtonObj.GetComponent<RectTransform>().anchorMax = new Vector2(0f, 1f);
			imageButtonObj.GetComponent<RectTransform>().anchorMin = new Vector2(0f, 1f);
			UnityEngine.Object.DestroyImmediate(imageButtonObj.GetComponent<Button>());
			imageButtonObj.AddComponent<Button>();
			UnityEngine.Object.DestroyImmediate(imageButtonObj.transform.Find("button-text").gameObject);
			imageButtonObj.GetComponent<RectTransform>().sizeDelta = new Vector2(32f, 32f);
			imageButtonObj.GetComponent<UIButton>().tips.tipTitle = "";
			imageButtonObj.GetComponent<UIButton>().tips.tipText = "";
			GameObject gameObject = new GameObject();
			gameObject.name = "icon";
			gameObject.transform.SetParent(imageButtonObj.transform, worldPositionStays: false);
			Image image = gameObject.AddComponent<Image>();
			image.sprite = LDB.items.Select(1101)._iconSprite;
			gameObject.GetComponent<RectTransform>().pivot = new Vector2(0.5f, 0.5f);
			gameObject.GetComponent<RectTransform>().anchorMax = new Vector2(0.5f, 0.5f);
			gameObject.GetComponent<RectTransform>().anchorMin = new Vector2(0.5f, 0.5f);
			gameObject.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(0f, 0f, 0f);
			gameObject.GetComponent<RectTransform>().sizeDelta = new Vector2(30f, 30f);
			gameObject.transform.localScale = Vector3.one;
			incTogglePrefabObj = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Assembler Window/produce/inc-info"));
			incTogglePrefabObj.transform.Find("inc-switch").GetComponent<Button>().interactable = true;
			incTogglePrefabObj.transform.Find("inc-switch").GetComponent<Button>().onClick.RemoveAllListeners();
			UnityEngine.Object.DestroyImmediate(incTogglePrefabObj.transform.Find("inc-label").gameObject);
			UnityEngine.Object.DestroyImmediate(incTogglePrefabObj.transform.Find("inc-effect-value-text").gameObject);
			UnityEngine.Object.DestroyImmediate(incTogglePrefabObj.transform.Find("inc-effect-value-text-2").gameObject);
			UnityEngine.Object.DestroyImmediate(incTogglePrefabObj.transform.Find("inc-effect-type-text-2").gameObject);
			incTogglePrefabObj.transform.Find("inc-effect-type-text").GetComponent<RectTransform>().anchoredPosition3D = new Vector3(138f, 0f, 0f);
			incTogglePrefabObj.transform.Find("inc-effect-type-text").GetComponent<Text>().alignment = TextAnchor.MiddleRight;
			checkBoxObj = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Dyson Sphere Editor/Dyson Editor Control Panel/hierarchy/layers/display-group/display-toggle-3/checkbox-back-structures"));
			checkBoxObj.name = "check-box";
			checkBoxObj.GetComponent<Button>().onClick.RemoveAllListeners();
			checkBoxObj.transform.Find("text").GetComponent<Text>().color = Color.white;
			itemNotSelectedSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/controlpanel-icon-40");
			leftTriangleSprite = Resources.Load<Sprite>("ui/textures/sprites/test/last-icon");
			rightTriangleSprite = Resources.Load<Sprite>("ui/textures/sprites/test/next-icon");
			backgroundSprite = Resources.Load<Sprite>("ui/textures/sprites/sci-fi/window-content-3");
			buttonBackgroundSprite = Resources.Load<Sprite>("ui/textures/sprites/sci-fi/window-content-3");
			gearWithCursorSprite = Resources.Load<Sprite>("icons/signal/signal-405");
			gearSimpleSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/settings-icon-24");
			filterSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/filter-icon");
			biaxialArrowSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/biaxial-arrow");
			oreSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/vein-icon-56");
			crossSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/delete-icon");
			bannedSprite = Resources.Load<Sprite>("icons/signal/signal-509");
			todoListSprite = Resources.Load<Sprite>("ui/textures/sprites/test/test-list-alt");
			resetSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/refresh-32-icon");
			checkboxOnSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/checkbox-on");
			checkboxOffSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/checkbox-off");
			arrowInBoxSprite = Resources.Load<Sprite>("ui/textures/sprites/dashboard/pading-icon-2");
			squarePlusSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/insert-icon");
			blueprintBookSprite = Resources.Load<Sprite>("ui/textures/sprites/blueprint-folder-220px");
			PLSIconSprite = LDB.items.Select(PLS).iconSprite;
			LSWhiteSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/logistics-station-40-icon");
			blueprintIconSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/blueprint-icon");
			newBPFloderSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/new-bpfolder-icon");
			copySprite = Resources.Load<Sprite>("ui/textures/sprites/icons/copy");
			pasteSprite = Resources.Load<Sprite>("ui/textures/sprites/icons/paste");
			lockSprite = Resources.Load<Sprite>("ui/textures/sprites/dashboard/menu/lock");
			listSprite = Resources.Load<Sprite>("ui/textures/sprites/test/test-list-alt");
			doubleLayerSprite = Resources.Load<Sprite>("ui/textures/sprites/dashboard/menu/top");
			circleThinSprite = Resources.Load<Sprite>("ui/textures/sprites/sci-fi/circle-thin");
		}
	}

	public void InitBpPreferceUI(Transform parent)
	{
		float num = -20f;
		float num2 = 23f;
		bool flag = true;
		GameObject gameObject = UnityEngine.Object.Instantiate(TextObj, parent);
		gameObject.name = "title0";
		gameObject.transform.localPosition = new Vector3(15f, num, 0f);
		gameObject.GetComponent<Text>().text = "蓝图行数".Translate();
		gameObject.GetComponent<Text>().fontSize = 14;
		GameObject gameObject2 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject.transform);
		gameObject2.name = "cb1";
		uibtnIcon_bpRowCount1 = gameObject2.GetComponent<Image>();
		gameObject2.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(120f, 0f, 0f);
		gameObject2.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpRowSet(1);
		});
		gameObject2.GetComponent<UIButton>().tips.corner = 1;
		gameObject2.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject2.GetComponent<UIButton>().tips.width = 300;
		gameObject2.transform.Find("text").GetComponent<Localizer>().stringKey = "蓝图行数单行";
		GameObject gameObject3 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject.transform);
		gameObject3.name = "cb2";
		uibtnIcon_bpRowCount2 = gameObject3.GetComponent<Image>();
		gameObject3.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(200f, 0f, 0f);
		gameObject3.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpRowSet(2);
		});
		gameObject3.GetComponent<UIButton>().tips.corner = 1;
		gameObject3.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject3.GetComponent<UIButton>().tips.width = 300;
		gameObject3.transform.Find("text").GetComponent<Localizer>().stringKey = "蓝图行数双行";
		bool flag2 = true;
		GameObject gameObject4 = UnityEngine.Object.Instantiate(TextObj, parent);
		gameObject4.name = "title1";
		gameObject4.transform.localPosition = new Vector3(15f, num - 1f * num2, 0f);
		gameObject4.GetComponent<Text>().text = "物流塔提供增产剂".Translate();
		gameObject4.GetComponent<Text>().fontSize = 14;
		GameObject gameObject5 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject4.transform);
		gameObject5.name = "cb1";
		uibtnIcon_bpStationProlifSlotYes = gameObject5.GetComponent<Image>();
		gameObject5.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(120f, 0f, 0f);
		gameObject5.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpStationProliferatorSlotSet(haveSlot: true);
		});
		gameObject5.GetComponent<UIButton>().tips.corner = 1;
		gameObject5.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject5.GetComponent<UIButton>().tips.width = 300;
		gameObject5.transform.Find("text").GetComponent<Localizer>().stringKey = "物流塔提供增产剂是";
		GameObject gameObject6 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject4.transform);
		gameObject6.name = "cb2";
		uibtnIcon_bpStationProlifSlotNo = gameObject6.GetComponent<Image>();
		gameObject6.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(200f, 0f, 0f);
		gameObject6.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpStationProliferatorSlotSet(haveSlot: false);
		});
		gameObject6.GetComponent<UIButton>().tips.corner = 1;
		gameObject6.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject6.GetComponent<UIButton>().tips.width = 300;
		gameObject6.transform.Find("text").GetComponent<Localizer>().stringKey = "物流塔提供增产剂否";
		bool flag3 = true;
		GameObject gameObject7 = UnityEngine.Object.Instantiate(TextObj, parent);
		gameObject7.name = "title2";
		gameObject7.transform.localPosition = new Vector3(15f, num - 2f * num2, 0f);
		gameObject7.GetComponent<Text>().text = "首选传送带".Translate();
		gameObject7.GetComponent<Text>().fontSize = 14;
		GameObject gameObject8 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject7.transform);
		gameObject8.name = "cb1";
		uibtnIcon_bpBeltHigh = gameObject8.GetComponent<Image>();
		gameObject8.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(120f, 0f, 0f);
		gameObject8.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpBeltPreferenceSet(highest: true);
		});
		gameObject8.GetComponent<UIButton>().tips.tipTitle = "首选传送带最高级".Translate();
		gameObject8.GetComponent<UIButton>().tips.tipText = "首选传送带最高级说明".Translate();
		gameObject8.GetComponent<UIButton>().tips.corner = 1;
		gameObject8.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject8.GetComponent<UIButton>().tips.width = 0;
		gameObject8.transform.Find("text").GetComponent<Localizer>().stringKey = "首选传送带最高级";
		GameObject gameObject9 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject7.transform);
		gameObject9.name = "cb2";
		uibtnIcon_bpBeltLow = gameObject9.GetComponent<Image>();
		gameObject9.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(200f, 0f, 0f);
		gameObject9.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpBeltPreferenceSet(highest: false);
		});
		gameObject9.GetComponent<UIButton>().tips.tipTitle = "首选传送带最便宜".Translate();
		gameObject9.GetComponent<UIButton>().tips.tipText = "首选传送带最便宜说明".Translate();
		gameObject9.GetComponent<UIButton>().tips.corner = 1;
		gameObject9.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject9.GetComponent<UIButton>().tips.width = 300;
		gameObject9.transform.Find("text").GetComponent<Localizer>().stringKey = "首选传送带最便宜";
		bool flag4 = true;
		GameObject gameObject10 = UnityEngine.Object.Instantiate(TextObj, parent);
		gameObject10.name = "title3";
		gameObject10.transform.localPosition = new Vector3(15f, num - 3f * num2, 0f);
		gameObject10.GetComponent<Text>().text = "传送带科技限制".Translate();
		gameObject10.GetComponent<Text>().fontSize = 14;
		GameObject gameObject11 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject10.transform);
		gameObject11.name = "cb1";
		uibtnIcon_bpBeltUnlimit = gameObject11.GetComponent<Image>();
		gameObject11.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(120f, 0f, 0f);
		gameObject11.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpBeltTechLimitSet(limited: false);
		});
		gameObject11.GetComponent<UIButton>().tips.corner = 1;
		gameObject11.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject11.GetComponent<UIButton>().tips.width = 300;
		gameObject11.transform.Find("text").GetComponent<Localizer>().stringKey = "传送带科技限制无限制";
		GameObject gameObject12 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject10.transform);
		gameObject12.name = "cb2";
		uibtnIcon_bpBeltLimit = gameObject12.GetComponent<Image>();
		gameObject12.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(200f, 0f, 0f);
		gameObject12.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpBeltTechLimitSet(limited: true);
		});
		gameObject12.GetComponent<UIButton>().tips.corner = 1;
		gameObject12.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject12.GetComponent<UIButton>().tips.width = 300;
		gameObject12.transform.Find("text").GetComponent<Localizer>().stringKey = "传送带科技限制当前科技";
		bool flag5 = true;
		GameObject gameObject13 = UnityEngine.Object.Instantiate(TextObj, parent);
		gameObject13.name = "title4";
		gameObject13.transform.localPosition = new Vector3(15f, num - 4f * num2, 0f);
		gameObject13.GetComponent<Text>().text = "首选分拣器".Translate();
		gameObject13.GetComponent<Text>().fontSize = 14;
		GameObject gameObject14 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject13.transform);
		gameObject14.name = "cb1";
		uibtnIcon_bpSorterHigh = gameObject14.GetComponent<Image>();
		gameObject14.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(120f, 0f, 0f);
		gameObject14.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpSorterPreferenceSet(highest: true);
		});
		gameObject14.GetComponent<UIButton>().tips.tipTitle = "首选分拣器最高级".Translate();
		gameObject14.GetComponent<UIButton>().tips.tipText = "首选分拣器最高级说明".Translate();
		gameObject14.GetComponent<UIButton>().tips.corner = 1;
		gameObject14.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject14.GetComponent<UIButton>().tips.width = 0;
		gameObject14.transform.Find("text").GetComponent<Localizer>().stringKey = "首选分拣器最高级";
		GameObject gameObject15 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject13.transform);
		gameObject15.name = "cb2";
		uibtnIcon_bpSorterLow = gameObject15.GetComponent<Image>();
		gameObject15.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(200f, 0f, 0f);
		gameObject15.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpSorterPreferenceSet(highest: false);
		});
		gameObject15.GetComponent<UIButton>().tips.tipTitle = "首选分拣器最便宜".Translate();
		gameObject15.GetComponent<UIButton>().tips.tipText = "首选分拣器最便宜说明".Translate();
		gameObject15.GetComponent<UIButton>().tips.corner = 1;
		gameObject15.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject15.GetComponent<UIButton>().tips.width = 300;
		gameObject15.transform.Find("text").GetComponent<Localizer>().stringKey = "首选分拣器最便宜";
		bool flag6 = true;
		GameObject gameObject16 = UnityEngine.Object.Instantiate(TextObj, parent);
		gameObject16.name = "title5";
		gameObject16.transform.localPosition = new Vector3(15f, num - 5f * num2, 0f);
		gameObject16.GetComponent<Text>().text = "分拣器科技限制".Translate();
		gameObject16.GetComponent<Text>().fontSize = 14;
		GameObject gameObject17 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject16.transform);
		gameObject17.name = "cb1";
		uibtnIcon_bpSorterUnlimit = gameObject17.GetComponent<Image>();
		gameObject17.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(120f, 0f, 0f);
		gameObject17.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpSorterTechLimitSet(limited: false);
		});
		gameObject17.GetComponent<UIButton>().tips.corner = 1;
		gameObject17.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject17.GetComponent<UIButton>().tips.width = 300;
		gameObject17.transform.Find("text").GetComponent<Localizer>().stringKey = "分拣器科技限制无限制";
		GameObject gameObject18 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject16.transform);
		gameObject18.name = "cb2";
		uibtnIcon_bpSorterLimit = gameObject18.GetComponent<Image>();
		gameObject18.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(200f, 0f, 0f);
		gameObject18.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpSorterTechLimitSet(limited: true);
		});
		gameObject18.GetComponent<UIButton>().tips.corner = 1;
		gameObject18.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject18.GetComponent<UIButton>().tips.width = 300;
		gameObject18.transform.Find("text").GetComponent<Localizer>().stringKey = "分拣器科技限制当前科技";
		bool flag7 = true;
		GameObject gameObject19 = UnityEngine.Object.Instantiate(TextObj, parent);
		gameObject19.name = "title6";
		gameObject19.transform.localPosition = new Vector3(15f, num - 6f * num2, 0f);
		gameObject19.GetComponent<Text>().text = "传送带堆叠".Translate();
		gameObject19.GetComponent<Text>().fontSize = 14;
		GameObject gameObject20 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject19.transform);
		gameObject20.name = "cb0";
		uibtnIcon_bpStackCur = gameObject20.GetComponent<Image>();
		gameObject20.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(120f, 0f, 0f);
		gameObject20.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpStackSet(0);
		});
		gameObject20.GetComponent<UIButton>().tips.corner = 1;
		gameObject20.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject20.GetComponent<UIButton>().tips.width = 0;
		gameObject20.transform.Find("text").GetComponent<Localizer>().stringKey = "传送带堆叠当前科技";
		GameObject gameObject21 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject19.transform);
		gameObject21.name = "cb4";
		uibtnIcon_bpStack4 = gameObject21.GetComponent<Image>();
		gameObject21.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(200f, 0f, 0f);
		gameObject21.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpStackSet(4);
		});
		gameObject21.GetComponent<UIButton>().tips.corner = 1;
		gameObject21.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject21.GetComponent<UIButton>().tips.width = 0;
		gameObject21.transform.Find("text").GetComponent<Localizer>().stringKey = "4";
		GameObject gameObject22 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject19.transform);
		gameObject22.name = "cb3";
		uibtnIcon_bpStack3 = gameObject22.GetComponent<Image>();
		gameObject22.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(240f, 0f, 0f);
		gameObject22.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpStackSet(3);
		});
		gameObject22.GetComponent<UIButton>().tips.corner = 1;
		gameObject22.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject22.GetComponent<UIButton>().tips.width = 0;
		gameObject22.transform.Find("text").GetComponent<Localizer>().stringKey = "3";
		GameObject gameObject23 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject19.transform);
		gameObject23.name = "cb2";
		uibtnIcon_bpStack2 = gameObject23.GetComponent<Image>();
		gameObject23.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(280f, 0f, 0f);
		gameObject23.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpStackSet(2);
		});
		gameObject23.GetComponent<UIButton>().tips.corner = 1;
		gameObject23.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject23.GetComponent<UIButton>().tips.width = 0;
		gameObject23.transform.Find("text").GetComponent<Localizer>().stringKey = "2";
		GameObject gameObject24 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject19.transform);
		gameObject24.name = "cb1";
		uibtnIcon_bpStack1 = gameObject24.GetComponent<Image>();
		gameObject24.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(320f, 0f, 0f);
		gameObject24.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpStackSet(1);
		});
		gameObject24.GetComponent<UIButton>().tips.corner = 1;
		gameObject24.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject24.GetComponent<UIButton>().tips.width = 0;
		gameObject24.transform.Find("text").GetComponent<Localizer>().stringKey = "1";
		bool flag8 = true;
		GameObject gameObject25 = UnityEngine.Object.Instantiate(TextObj, parent);
		gameObject25.name = "title7";
		gameObject25.transform.localPosition = new Vector3(15f, num - 7f * num2, 0f);
		gameObject25.GetComponent<Text>().text = "生成喷涂机".Translate();
		gameObject25.GetComponent<Text>().fontSize = 14;
		GameObject gameObject26 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject25.transform);
		gameObject26.name = "cb1";
		uibtnIcon_bpCoaterAuto = gameObject26.GetComponent<Image>();
		gameObject26.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(120f, 0f, 0f);
		gameObject26.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpCoaterSet(0);
		});
		gameObject26.GetComponent<UIButton>().tips.tipTitle = "生成喷涂机自动".Translate();
		gameObject26.GetComponent<UIButton>().tips.tipText = "生成喷涂机自动说明".Translate();
		gameObject26.GetComponent<UIButton>().tips.corner = 1;
		gameObject26.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject26.GetComponent<UIButton>().tips.width = 300;
		gameObject26.transform.Find("text").GetComponent<Localizer>().stringKey = "生成喷涂机自动";
		GameObject gameObject27 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject25.transform);
		gameObject27.name = "cb2";
		uibtnIcon_bpCoaterAlways = gameObject27.GetComponent<Image>();
		gameObject27.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(200f, 0f, 0f);
		gameObject27.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpCoaterSet(1);
		});
		gameObject27.GetComponent<UIButton>().tips.corner = 1;
		gameObject27.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject27.GetComponent<UIButton>().tips.width = 300;
		gameObject27.transform.Find("text").GetComponent<Localizer>().stringKey = "生成喷涂机总是";
		GameObject gameObject28 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject25.transform);
		gameObject28.name = "cb3";
		uibtnIcon_bpCoaterNever = gameObject28.GetComponent<Image>();
		gameObject28.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(280f, 0f, 0f);
		gameObject28.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpCoaterSet(-1);
		});
		gameObject28.GetComponent<UIButton>().tips.corner = 1;
		gameObject28.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject28.GetComponent<UIButton>().tips.width = 300;
		gameObject28.transform.Find("text").GetComponent<Localizer>().stringKey = "生成喷涂机从不";
		bool flag9 = true;
		GameObject gameObject29 = UnityEngine.Object.Instantiate(TextObj, parent);
		gameObject29.name = "title8";
		gameObject29.transform.localPosition = new Vector3(15f, num - 8f * num2, 0f);
		gameObject29.GetComponent<Text>().text = "生成产物喷涂机".Translate();
		gameObject29.GetComponent<Text>().fontSize = 14;
		GameObject gameObject30 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject29.transform);
		gameObject30.name = "cb1";
		uibtnIcon_bpProductCoaterAlways = gameObject30.GetComponent<Image>();
		gameObject30.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(120f, 0f, 0f);
		gameObject30.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpProductCoaterSet(gen: true);
		});
		gameObject30.GetComponent<UIButton>().tips.corner = 1;
		gameObject30.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject30.GetComponent<UIButton>().tips.width = 300;
		gameObject30.transform.Find("text").GetComponent<Localizer>().stringKey = "生成喷涂机总是";
		gameObject30.GetComponent<UIButton>().tips.tipTitle = "生成喷涂机总是".Translate();
		gameObject30.GetComponent<UIButton>().tips.tipText = "产物生成喷涂机说明".Translate();
		GameObject gameObject31 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject29.transform);
		gameObject31.name = "cb2";
		uibtnIcon_bpProductCoaterNever = gameObject31.GetComponent<Image>();
		gameObject31.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(200f, 0f, 0f);
		gameObject31.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpProductCoaterSet(gen: false);
		});
		gameObject31.GetComponent<UIButton>().tips.corner = 1;
		gameObject31.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject31.GetComponent<UIButton>().tips.width = 300;
		gameObject31.transform.Find("text").GetComponent<Localizer>().stringKey = "生成喷涂机从不";
		bool flag10 = true;
		GameObject gameObject32 = UnityEngine.Object.Instantiate(TextObj, parent);
		gameObject32.name = "title9";
		gameObject32.transform.localPosition = new Vector3(15f, num - 9f * num2, 0f);
		gameObject32.GetComponent<Text>().text = "黑盒连接喷涂机进料口".Translate();
		gameObject32.GetComponent<Text>().fontSize = 14;
		GameObject gameObject33 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject32.transform);
		gameObject33.name = "cb1";
		uibtnIcon_bpBlackboxConnectCoater = gameObject33.GetComponent<Image>();
		gameObject33.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(120f, 0f, 0f);
		gameObject33.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpBlackboxCoaterConnectSet(connect: true);
		});
		gameObject33.GetComponent<UIButton>().tips.tipTitle = "黑盒连接喷涂机进料口标题".Translate();
		gameObject33.GetComponent<UIButton>().tips.tipText = "黑盒连接喷涂机进料口说明".Translate();
		gameObject33.GetComponent<UIButton>().tips.corner = 1;
		gameObject33.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject33.GetComponent<UIButton>().tips.width = 300;
		gameObject33.transform.Find("text").GetComponent<Localizer>().stringKey = "黑盒连接喷涂机生成";
		GameObject gameObject34 = UnityEngine.Object.Instantiate(checkBoxObj, gameObject32.transform);
		gameObject34.name = "cb2";
		uibtnIcon_bpBlackboxNotConnectCoater = gameObject34.GetComponent<Image>();
		gameObject34.GetComponent<RectTransform>().anchoredPosition3D = new Vector3(200f, 0f, 0f);
		gameObject34.GetComponent<Button>().onClick.AddListener(delegate
		{
			OnBpBlackboxCoaterConnectSet(connect: false);
		});
		gameObject34.GetComponent<UIButton>().tips.tipTitle = "黑盒不连接喷涂机进料口标题".Translate();
		gameObject34.GetComponent<UIButton>().tips.tipText = "黑盒不连接喷涂机进料口说明".Translate();
		gameObject34.GetComponent<UIButton>().tips.corner = 1;
		gameObject34.GetComponent<UIButton>().tips.delay = 0.1f;
		gameObject34.GetComponent<UIButton>().tips.width = 300;
		gameObject34.transform.Find("text").GetComponent<Localizer>().stringKey = "黑盒连接喷涂机不生成";
	}

	public void OnUpdate()
	{
		if (windowObj == null)
		{
			isTopAndActive = false;
			WindowsManager.windows.Remove(this);
			return;
		}
		if (windowObj.transform.parent.GetChild(windowObj.transform.parent.childCount - 1) == windowObj.transform && windowObj.activeSelf)
		{
			isTopAndActive = true;
		}
		else
		{
			isTopAndActive = false;
		}
		float num = largeWindowWidth;
		if (!isLargeWindow)
		{
			num = smallWindowWidth;
		}
		else
		{
			hideOutsideTheEdge = false;
		}
		float x = windowObj.GetComponent<RectTransform>().sizeDelta.x;
		float num2 = x;
		if (num2 < num && num - num2 > 0.01f)
		{
			float y = windowObj.GetComponent<RectTransform>().sizeDelta.y;
			float y2 = viewGroupObj.GetComponent<RectTransform>().sizeDelta.y;
			num2 += animationSpeed;
			if (num2 > num)
			{
				num2 = num;
			}
			float num3 = num2 - (smallWindowWidth - smallWindowViewGroupWidth);
			if (num3 > largeWindowViewGroupWidth)
			{
				num3 = largeWindowViewGroupWidth;
			}
			windowObj.GetComponent<RectTransform>().sizeDelta = new Vector2(num2, y);
			float y3 = (num2 - smallWindowWidth) / (largeWindowWidth - smallWindowWidth) * (largeWindowViewGroupHeight - smallWindowViewGroupHeight) + smallWindowViewGroupHeight;
			viewGroupObj.GetComponent<RectTransform>().sizeDelta = new Vector2(num3, y3);
			float y4 = (num2 - smallWindowWidth) / (largeWindowWidth - smallWindowWidth) * (targetIconAnchoredPosYLargeWindow - targetIconAnchoredPosYSmallWindow) + targetIconAnchoredPosYSmallWindow;
			float x2 = targetProductIconObj.GetComponent<RectTransform>().anchoredPosition.x;
			targetProductIconObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(x2, y4);
			x2 = speedInputObj.GetComponent<RectTransform>().anchoredPosition.x;
			speedInputObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(x2, y4);
			x2 = perMinTextObj.GetComponent<RectTransform>().anchoredPosition.x;
			perMinTextObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(x2, y4);
			x2 = genBpButtonObj.GetComponent<RectTransform>().anchoredPosition.x;
			genBpButtonObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(x2, y4);
		}
		else if (num2 > num && num2 - num > 0.01f)
		{
			float y5 = windowObj.GetComponent<RectTransform>().sizeDelta.y;
			float y6 = viewGroupObj.GetComponent<RectTransform>().sizeDelta.y;
			num2 -= animationSpeed;
			if (num2 < num)
			{
				num2 = num;
			}
			float num4 = num2 - (smallWindowWidth - smallWindowViewGroupWidth);
			if (num4 > largeWindowViewGroupWidth)
			{
				num4 = largeWindowViewGroupWidth;
			}
			windowObj.GetComponent<RectTransform>().sizeDelta = new Vector2(num2, y5);
			float y7 = (num2 - smallWindowWidth) / (largeWindowWidth - smallWindowWidth) * (largeWindowViewGroupHeight - smallWindowViewGroupHeight) + smallWindowViewGroupHeight;
			viewGroupObj.GetComponent<RectTransform>().sizeDelta = new Vector2(num4, y7);
			float y8 = (num2 - smallWindowWidth) / (largeWindowWidth - smallWindowWidth) * (targetIconAnchoredPosYLargeWindow - targetIconAnchoredPosYSmallWindow) + targetIconAnchoredPosYSmallWindow;
			float x3 = targetProductIconObj.GetComponent<RectTransform>().anchoredPosition.x;
			targetProductIconObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(x3, y8);
			x3 = speedInputObj.GetComponent<RectTransform>().anchoredPosition.x;
			speedInputObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(x3, y8);
			x3 = perMinTextObj.GetComponent<RectTransform>().anchoredPosition.x;
			perMinTextObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(x3, y8);
			x3 = genBpButtonObj.GetComponent<RectTransform>().anchoredPosition.x;
			genBpButtonObj.GetComponent<RectTransform>().anchoredPosition = new Vector2(x3, y8);
		}
		ShowHideChildrenWhenWindowSizeChanged(x, num2);
		if (nextFrameRecalc)
		{
			nextFrameRecalc = false;
			if (solution.targets.Count > 0)
			{
				if (solution.targets[0].itemId > 0)
				{
					targetProductIcon.sprite = LDB.items.Select(solution.targets[0].itemId)?.iconSprite;
					targetProductIconUIBtn.tips.corner = 3;
					targetProductIconUIBtn.tips.itemId = solution.targets[0].itemId;
					targetProductIconUIBtn.tips.delay = 0.1f;
				}
				speedInputObj.GetComponent<InputField>().text = solution.targets[0].speed.ToString();
			}
			double.TryParse(speedInputObj.GetComponent<InputField>().text, out var result);
			solution.ReSolve(result);
			RefreshAll();
		}
		if (titleInput.isFocused)
		{
			titleInputUIBtn.highlighted = true;
		}
		else
		{
			titleInputUIBtn.highlighted = false;
		}
		if (windowObj.activeSelf)
		{
			if (targetVerticalPosition >= 0f)
			{
				float num5 = targetVerticalPosition - contentScrollRect.verticalNormalizedPosition;
				float num6 = 0.01f;
				float num7 = 0.1f;
				if (uiItemNodeOrders.Count > 12)
				{
					float num8 = (float)uiItemNodeOrders.Count * 1f / 12f;
					num6 *= 0.2f + 0.8f / num8;
					num7 *= 0.8f + 0.2f / num8;
				}
				if (num5 <= num6 && num5 >= 0f - num6)
				{
					contentScrollRect.verticalNormalizedPosition = targetVerticalPosition;
					targetVerticalPosition = -1f;
				}
				else
				{
					float num9 = num5 * num7;
					if (num9 > 0f && num9 < num6)
					{
						num9 = num6;
					}
					else if (num9 < 0f && num9 > 0f - num6)
					{
						num9 = 0f - num6;
					}
					contentScrollRect.verticalNormalizedPosition += num9;
				}
			}
			bool isMoving = targetVerticalPosition >= 0f;
			ShiftState = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
			for (int i = 0; i < uiItemNodes.Count; i++)
			{
				uiItemNodes[i].OnUpdate(isMoving);
			}
			for (int j = 0; j < uiSideItemNodes.Count; j++)
			{
				uiSideItemNodes[j].OnUpdate(isMoving);
			}
		}
		if (windowObj.activeSelf && !isLargeWindow)
		{
			float num10 = windowObj.transform.localPosition.x;
			bool flag = WindowOnLeftEdge();
			bool flag2 = WindowOnRightEdge();
			if (!CursorInWindow())
			{
				if (flag)
				{
					num10 = (0f - WindowsManager.UIResolutionX) / 2f - windowObj.GetComponent<RectTransform>().sizeDelta.x + WindowsManager.windowEdgeDockingWidth;
				}
				else if (flag2)
				{
					num10 = WindowsManager.UIResolutionX / 2f - WindowsManager.windowEdgeDockingWidth;
				}
			}
			else if (flag)
			{
				num10 = (0f - WindowsManager.UIResolutionX) / 2f;
			}
			else if (flag2)
			{
				num10 = WindowsManager.UIResolutionX / 2f - windowObj.GetComponent<RectTransform>().sizeDelta.x;
			}
			if (num10 < windowObj.transform.localPosition.x - 0.1f)
			{
				float num11 = Math.Min(windowObj.transform.localPosition.x - num10, WindowsManager.windowHideOnEdgeSpeed);
				windowObj.transform.localPosition = new Vector3(windowObj.transform.localPosition.x - num11, windowObj.transform.localPosition.y, windowObj.transform.localPosition.z);
			}
			else if (num10 > windowObj.transform.localPosition.x + 0.1f)
			{
				float num12 = Math.Min(num10 - windowObj.transform.localPosition.x, WindowsManager.windowHideOnEdgeSpeed);
				windowObj.transform.localPosition = new Vector3(windowObj.transform.localPosition.x + num12, windowObj.transform.localPosition.y, windowObj.transform.localPosition.z);
			}
			else if (flag || flag2)
			{
				windowObj.transform.SetAsFirstSibling();
				if (CursorInWindow())
				{
					hideOutsideTheEdge = false;
				}
				else
				{
					hideOutsideTheEdge = true;
				}
			}
			else
			{
				hideOutsideTheEdge = false;
			}
		}
		if (isTopAndActive)
		{
			bool shift = Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift);
			bool ctrl = Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl);
			bool alt = Input.GetKey(KeyCode.LeftAlt) || Input.GetKey(KeyCode.RightAlt);
			if (Input.GetKeyDown(DSPCalculatorPlugin.SwitchWindowSizeHotKey.Value) && UIHotkeySettingPatcher.CheckModifier(2, shift, ctrl, alt))
			{
				SwitchWindowSize();
			}
			if (refreshIndex < uiItemNodes.Count)
			{
				uiItemNodes[refreshIndex].CallBpPreProcess();
				refreshIndex++;
			}
		}
	}

	public void AddCellTest()
	{
		GameObject gameObject = new GameObject();
		Image image = gameObject.AddComponent<Image>();
		image.sprite = Resources.Load<Sprite>("Assets/DSPBattle/r3-5");
		gameObject.GetComponent<RectTransform>().sizeDelta = new Vector2(890f, 80f);
		gameObject.transform.SetParent(mainCanvasObj.transform, worldPositionStays: false);
		gameObject.SetActive(value: false);
		gameObject.SetActive(value: true);
	}

	public void CloseWindow()
	{
		WindowsManager.windows.Remove(this);
		if (WindowsManager.closedWindows != null)
		{
			WindowsManager.closedWindows.Add(this);
			while (DSPCalculatorPlugin.MaxWindowsReservedAfterClose.Value > 0 && WindowsManager.closedWindows.Count > DSPCalculatorPlugin.MaxWindowsReservedAfterClose.Value)
			{
				UnityEngine.Object.Destroy(WindowsManager.closedWindows[0].windowObj);
				WindowsManager.closedWindows.RemoveAt(0);
			}
		}
		isTopAndActive = false;
		windowObj.transform.SetAsFirstSibling();
		windowObj.SetActive(value: false);
		RefreshPauseBarStatus();
	}

	public void RefreshPauseBarStatus()
	{
		if (!(UIPauseBarPatcher.pauseBarObj != null))
		{
			return;
		}
		bool flag = false;
		if (WindowsManager.windows != null)
		{
			for (int i = 0; i < WindowsManager.windows.Count; i++)
			{
				if (WindowsManager.windows[i].windowObj.activeSelf && !WindowsManager.windows[i].hideOutsideTheEdge)
				{
					flag = true;
					break;
				}
			}
		}
		if (!flag)
		{
			UIPauseBarPatcher.pauseBarObj.SetActive(value: false);
			if (GameMain.instance != null)
			{
				GameMain.instance._fullscreenPaused = false;
			}
		}
	}

	public void SwitchWindowSize()
	{
		isLargeWindow = !isLargeWindow;
	}

	public void OpenWindow()
	{
		if (WindowsManager.closedWindows != null && WindowsManager.closedWindows.Count > 0 && WindowsManager.closedWindows.Last() == this)
		{
			WindowsManager.closedWindows.RemoveAt(WindowsManager.closedWindows.Count - 1);
		}
		windowObj.transform.SetAsLastSibling();
		windowObj.SetActive(value: true);
		titleText.text = "量化计算器".Translate();
		RefreshCheckBoxes();
	}

	public void OnTargetProductIconClick()
	{
		UIItemPicker.showAll = true;
		if (windowObj.GetComponent<RectTransform>().anchoredPosition.x > -150f && !isLargeWindow)
		{
			UIItemPicker.Popup(new Vector2(-300f, 100f), OnTargetProductChange);
		}
		else
		{
			UIItemPicker.Popup(windowObj.GetComponent<RectTransform>().anchoredPosition + new Vector2(300f, -200f), OnTargetProductChange);
		}
	}

	public void OnTargetProductChange(ItemProto item)
	{
		UIItemPicker.showAll = false;
		if (item != null)
		{
			targetProductIcon.sprite = item.iconSprite;
			targetProductIconUIBtn.tips.corner = 3;
			targetProductIconUIBtn.tips.itemId = item.ID;
			targetProductIconUIBtn.tips.delay = 0.1f;
			double result = 0.0;
			double.TryParse(speedInputObj.GetComponent<InputField>().text, out result);
			solution.SetTargetAndSolve(0, item.ID, result);
			RefreshAll();
		}
	}

	public void OnTargetSpeedChange(string num)
	{
		try
		{
			double.TryParse(num, out var result);
			solution.ChangeTargetSpeed0AndSolve(result);
			RefreshAll();
		}
		catch (Exception)
		{
		}
	}

	public void ShowHideChildrenWhenWindowSizeChanged(float oriWidth, float curWidth)
	{
		if (oriWidth >= 0.5f * largeWindowWidth && curWidth < 0.5f * largeWindowWidth)
		{
			incToggleObj.SetActive(value: false);
			proliferatorSelectionObj.SetActive(value: false);
			targetProductTextObj.SetActive(value: false);
			switchSizeButtonObj.GetComponent<Image>().sprite = rightTriangleSprite;
		}
		else if (oriWidth <= 0.5f * largeWindowWidth && curWidth > 0.5f * largeWindowWidth)
		{
			incToggleObj.SetActive(value: true);
			proliferatorSelectionObj.SetActive(value: true);
			targetProductTextObj.SetActive(value: true);
			switchSizeButtonObj.GetComponent<Image>().sprite = leftTriangleSprite;
		}
		if (oriWidth >= 0.9f * largeWindowWidth && curWidth < 0.9f * largeWindowWidth)
		{
			assemblerSelectionObj.SetActive(value: false);
		}
		else if (oriWidth <= 0.9f * largeWindowWidth && curWidth > 0.9f * largeWindowWidth)
		{
			assemblerSelectionObj.SetActive(value: true);
		}
	}

	public void RefreshAll()
	{
		if (solution.targets.Count == 0 || solution.targets[0].itemId == 0)
		{
			targetProductIcon.sprite = itemNotSelectedSprite;
			targetProductIconUIBtn.tips.itemId = 0;
		}
		RefreshProductContent();
		RefreshResourceNeedAndByProductContent();
		RefreshFinalInfoText();
		RefreshAssemblerDemandsDisplay();
		RefreshAssemblerButtonDisplay();
		RefreshIncToggle();
		RefreshProliferatorButtonDisplay();
		RefreshCheckBoxes();
		RefreshSideInfoPanels();
		RefreshBpGenButton();
		RefreshProgressCircle();
		refreshIndex = 0;
	}

	public bool CursorInWindow()
	{
		Vector3 mousePosition = Input.mousePosition;
		float num = mousePosition.x * WindowsManager.UIResolutionRatio;
		float num2 = mousePosition.y * WindowsManager.UIResolutionRatio;
		num -= WindowsManager.UIResolutionX / 2f;
		num2 -= WindowsManager.UIResolutionY / 2f;
		Vector3 localPosition = windowObj.transform.localPosition;
		float x = windowObj.GetComponent<RectTransform>().sizeDelta.x;
		float y = windowObj.GetComponent<RectTransform>().sizeDelta.y;
		if (num >= localPosition.x && num <= localPosition.x + x && num2 <= localPosition.y && num2 >= localPosition.y - y)
		{
			return true;
		}
		if ((num < (0f - WindowsManager.UIResolutionX) / 2f && WindowOnLeftEdge()) || (num > WindowsManager.UIResolutionX / 2f && WindowOnRightEdge()))
		{
			return true;
		}
		return false;
	}

	public bool WindowOnLeftEdge()
	{
		return !isLargeWindow && windowObj.transform.localPosition.x <= (0f - WindowsManager.UIResolutionX) / 2f + WindowsManager.windowEdgeJudgeDistance;
	}

	public bool WindowOnRightEdge()
	{
		return !isLargeWindow && windowObj.transform.localPosition.x + windowObj.GetComponent<RectTransform>().sizeDelta.x >= WindowsManager.UIResolutionX / 2f - WindowsManager.windowEdgeJudgeDistance;
	}

	public void RefreshProductContent()
	{
		for (int i = 0; i < uiItemNodes.Count; i++)
		{
			UnityEngine.Object.DestroyImmediate(uiItemNodes[i].obj);
		}
		ClearNodes();
		int num = 0;
		if (solution.root.Count > 0 && !solution.userPreference.solveProliferators)
		{
			List<ItemNode> list = new List<ItemNode>();
			for (int num2 = solution.root.Count - 1; num2 >= 0; num2--)
			{
				list.Add(solution.root[num2]);
			}
			Dictionary<int, ItemNode> dictionary = new Dictionary<int, ItemNode>();
			while (list.Count > 0)
			{
				ItemNode itemNode = list[list.Count - 1];
				ItemNode itemNode2 = solution.itemNodes[itemNode.itemId];
				if (!dictionary.ContainsKey(itemNode2.itemId) && itemNode2.needSpeed > 0.0010000000474974513)
				{
					dictionary.Add(itemNode2.itemId, itemNode2);
					if (!itemNode2.IsOre(solution.userPreference) || itemNode2.speedFromOre <= 0.0010000000474974513)
					{
						UIItemNode item = new UIItemNode(itemNode2, this);
						uiItemNodes.Add(item);
						uiItemNodeOrders[itemNode2.itemId] = num;
						num++;
					}
					else if (solution.userPreference.showMixBeltInfo)
					{
						UIItemNode item2 = new UIItemNode(itemNode2, this);
						uiItemNodes.Add(item2);
						uiItemNodeOrders[itemNode2.itemId] = num;
						num++;
					}
				}
				list.RemoveAt(list.Count - 1);
				for (int num3 = itemNode2.children.Count - 1; num3 >= 0; num3--)
				{
					list.Add(itemNode2.children[num3]);
				}
			}
		}
		if (solution.root.Count <= 0 || !solution.userPreference.solveProliferators)
		{
			return;
		}
		Dictionary<int, ItemNode> dictionary2 = new Dictionary<int, ItemNode>();
		for (int num4 = CalcDB.proliferatorItemIds.Count; num4 >= 0; num4--)
		{
			List<ItemNode> list2 = new List<ItemNode>();
			if (num4 == CalcDB.proliferatorItemIds.Count)
			{
				for (int num5 = solution.root.Count - 1; num5 >= 0; num5--)
				{
					list2.Add(solution.root[num5]);
				}
			}
			else
			{
				int index = num4;
				int key = CalcDB.proliferatorItemIds[index];
				if (solution.itemNodes.ContainsKey(key) && solution.itemNodes[key].needSpeed > 0.0)
				{
					list2.Add(solution.itemNodes[key]);
				}
			}
			while (list2.Count > 0)
			{
				ItemNode itemNode3 = list2[list2.Count - 1];
				ItemNode itemNode4 = solution.itemNodes[itemNode3.itemId];
				if (!dictionary2.ContainsKey(itemNode4.itemId) && itemNode4.needSpeed > 0.0010000000474974513)
				{
					dictionary2.Add(itemNode4.itemId, itemNode4);
					if (!itemNode4.IsOre(solution.userPreference))
					{
						UIItemNode item3 = new UIItemNode(itemNode4, this);
						uiItemNodes.Add(item3);
						uiItemNodeOrders[itemNode4.itemId] = num;
						num++;
					}
					else if (solution.userPreference.showMixBeltInfo)
					{
						UIItemNode item4 = new UIItemNode(itemNode4, this);
						uiItemNodes.Add(item4);
						uiItemNodeOrders[itemNode4.itemId] = num;
						num++;
					}
				}
				list2.RemoveAt(list2.Count - 1);
				for (int num6 = itemNode4.children.Count - 1; num6 >= 0; num6--)
				{
					list2.Add(itemNode4.children[num6]);
				}
			}
		}
	}

	public void RefreshResourceNeedAndByProductContent()
	{
		for (int i = 0; i < uiSideItemNodes.Count; i++)
		{
			UnityEngine.Object.DestroyImmediate(uiSideItemNodes[i].obj);
		}
		ClearSideNodes();
		if (solution.itemNodes.Count == 0)
		{
			return;
		}
		int num = 0;
		UIItemNodeSimple item = new UIItemNodeSimple("目标产物".Translate(), this);
		uiSideItemNodes.Add(item);
		for (int j = 1; j < 3; j++)
		{
			UIItemNodeSimple item2 = new UIItemNodeSimple("", this);
			uiSideItemNodes.Add(item2);
		}
		for (int k = 0; k < solution.targets.Count; k++)
		{
			if (solution.targets[k].itemId > 0 && solution.targets[k].speed > 0.0)
			{
				int index = k;
				double speed = solution.targets[k].speed;
				if (solution.tempNotShrinkRoot && k == 0 && solution.itemNodes.ContainsKey(solution.targets[k].itemId))
				{
					speed = solution.itemNodes[solution.targets[k].itemId].needSpeed;
				}
				UIItemNodeTarget item3 = new UIItemNodeTarget(index, solution.targets[k].itemId, speed, this);
				uiSideItemNodes.Add(item3);
				num++;
			}
		}
		UIItemNodeTarget item4 = new UIItemNodeTarget(solution.targets.Count, 0, 0.0, this);
		uiSideItemNodes.Add(item4);
		num++;
		if (num % 3 != 0)
		{
			int num2 = 3 - num % 3;
			for (int l = 0; l < num2; l++)
			{
				UIItemNodeSimple item5 = new UIItemNodeSimple("", this);
				uiSideItemNodes.Add(item5);
			}
		}
		num = 0;
		UIItemNodeSimple item6 = new UIItemNodeSimple("原矿需求".Translate(), this);
		uiSideItemNodes.Add(item6);
		for (int m = 1; m < 3; m++)
		{
			UIItemNodeSimple item7 = new UIItemNodeSimple("", this);
			uiSideItemNodes.Add(item7);
		}
		foreach (KeyValuePair<int, ItemNode> itemNode3 in solution.itemNodes)
		{
			if (itemNode3.Value.IsOre(solution.userPreference) && itemNode3.Value.speedFromOre > 0.0010000000474974513)
			{
				UIItemNodeSimple uIItemNodeSimple = new UIItemNodeSimple(itemNode3.Value, isResources: true, this);
				uiSideItemNodes.Add(uIItemNodeSimple);
				uiItemSimplesByItemId[itemNode3.Value.itemId] = uIItemNodeSimple;
				num++;
			}
		}
		if (!solution.userPreference.solveProliferators)
		{
			foreach (KeyValuePair<int, double> item18 in solution.proliferatorCount)
			{
				if (item18.Key > 0 && item18.Value > 0.0)
				{
					ItemNode itemNode = new ItemNode(item18.Key, 0.0, solution);
					itemNode.satisfiedSpeed = item18.Value;
					UIItemNodeSimple item8 = new UIItemNodeSimple(itemNode, isResources: false, this, isProliferatorDemand: true);
					uiSideItemNodes.Add(item8);
					num++;
				}
			}
		}
		if (num % 3 != 0)
		{
			int num3 = 3 - num % 3;
			for (int n = 0; n < num3; n++)
			{
				UIItemNodeSimple item9 = new UIItemNodeSimple("", this);
				uiSideItemNodes.Add(item9);
			}
		}
		UIItemNodeSimple item10 = new UIItemNodeSimple("副产物和溢出产物".Translate(), this);
		uiSideItemNodes.Add(item10);
		for (int num4 = 1; num4 < 3; num4++)
		{
			UIItemNodeSimple item11 = new UIItemNodeSimple("", this);
			uiSideItemNodes.Add(item11);
		}
		num = 0;
		foreach (KeyValuePair<int, ItemNode> itemNode4 in solution.itemNodes)
		{
			if (itemNode4.Value.satisfiedSpeed - itemNode4.Value.needSpeed > 0.0010000000474974513 && solution.CanShowOverflow(itemNode4.Value.itemId))
			{
				UIItemNodeSimple item12 = new UIItemNodeSimple(itemNode4.Value, isResources: false, this);
				uiSideItemNodes.Add(item12);
				num++;
			}
		}
		if (num == 0)
		{
			int num5 = uiSideItemNodes.Count - 1;
			for (int num6 = 0; num6 < 3; num6++)
			{
				UnityEngine.Object.DestroyImmediate(uiSideItemNodes[num5 - num6].obj);
				uiSideItemNodes.RemoveAt(num5 - num6);
			}
		}
		else if (num % 3 != 0)
		{
			int num7 = 3 - num % 3;
			for (int num8 = 0; num8 < num7; num8++)
			{
				UIItemNodeSimple item13 = new UIItemNodeSimple("", this);
				uiSideItemNodes.Add(item13);
			}
		}
		if (!solution.userPreference.showMixBeltInfo)
		{
			return;
		}
		num = 0;
		int num9 = 0;
		foreach (KeyValuePair<int, ItemNode> itemNode5 in solution.itemNodes)
		{
			num9 += itemNode5.Value.GetInserterRatio();
		}
		UIItemNodeSimple item14 = new UIItemNodeSimple(string.Format("{0} : {1} {2}", "混带需求".Translate(), num9, "份calc".Translate()), this);
		uiSideItemNodes.Add(item14);
		for (int num10 = 1; num10 < 3; num10++)
		{
			UIItemNodeSimple item15 = new UIItemNodeSimple("", this);
			uiSideItemNodes.Add(item15);
		}
		int[] array = new int[CalcDB.beltsDescending.Count];
		for (int num11 = 1; num11 < CalcDB.beltsDescending.Count; num11++)
		{
			if (num9 <= 0)
			{
				break;
			}
			if ((double)num9 > CalcDB.beltsDescending[num11].speed)
			{
				int num12 = (int)((double)num9 / CalcDB.beltsDescending[num11 - 1].speed);
				num9 -= (int)((double)num12 * CalcDB.beltsDescending[num11 - 1].speed);
				array[num11 - 1] = num12;
			}
		}
		if (num9 > 0)
		{
			array[^1]++;
		}
		for (int num13 = 0; num13 < array.Length; num13++)
		{
			if (array[num13] > 0)
			{
				ItemNode itemNode2 = new ItemNode(CalcDB.beltsDescending[num13].ID, 0.0, solution);
				itemNode2.satisfiedSpeed = array[num13];
				UIItemNodeSimple item16 = new UIItemNodeSimple(itemNode2, isResources: false, this, isProliferatorDemand: false, isMixBeltInfo: true);
				uiSideItemNodes.Add(item16);
				num++;
			}
		}
		if (num % 3 != 0)
		{
			int num14 = 3 - num % 3;
			for (int num15 = 0; num15 < num14; num15++)
			{
				UIItemNodeSimple item17 = new UIItemNodeSimple("", this);
				uiSideItemNodes.Add(item17);
			}
		}
	}

	public void ClearNodes()
	{
		uiItemNodes.Clear();
		uiItemNodeOrders.Clear();
	}

	public void ClearSideNodes()
	{
		uiSideItemNodes.Clear();
		uiItemSimplesByItemId.Clear();
	}

	public bool AddOrUpdateTargetThenResolve(int index, int targetItem, double targetSpeed)
	{
		if (solution.AddOrUpdateTarget(index, targetItem, targetSpeed))
		{
			solution.MergeDuplicateTargets();
			speedInputObj.GetComponent<InputField>().text = solution.targets[0].speed.ToString();
			nextFrameRecalc = true;
			return true;
		}
		return false;
	}

	public bool AddOrUpdateTargetButNotResolve(int index, int targetItem, double targetSpeed)
	{
		if (solution.AddOrUpdateTarget(index, targetItem, targetSpeed))
		{
			solution.MergeDuplicateTargets();
			speedInputObj.GetComponent<InputField>().text = solution.targets[0].speed.ToString();
			nextFrameRecalc = false;
			return true;
		}
		return false;
	}

	public void RefreshSideInfoPanels()
	{
		for (int i = 0; i < sideInfoPanelObjs.Count; i++)
		{
			if (i == sideInfoPanelIndex)
			{
				sideInfoPanelObjs[i].SetActive(value: true);
				sideInfoPanelSwitchUIBtns[i].highlighted = true;
			}
			else
			{
				sideInfoPanelObjs[i].SetActive(value: false);
				sideInfoPanelSwitchUIBtns[i].highlighted = false;
			}
		}
		RefreshFinalInfoText();
		RefreshBpPreferences();
		RefreshCheckBoxes();
		RefreshAssemblerDemandsDisplay();
	}

	public void RefreshFinalInfoText()
	{
		double num = 0.0;
		foreach (KeyValuePair<int, RecipeInfo> recipeInfo in solution.recipeInfos)
		{
			num += recipeInfo.Value.GetTotalEnergyConsumption();
		}
		finalInfoText.text = "预估电量".Translate() + "\n" + Utils.KMG(num) + "W";
	}

	public void RefreshBpPreferences()
	{
		if (solution.userPreference.bpRowCount == 1)
		{
			uibtnIcon_bpRowCount1.sprite = checkboxOnSprite;
			uibtnIcon_bpRowCount2.sprite = checkboxOffSprite;
		}
		else
		{
			uibtnIcon_bpRowCount1.sprite = checkboxOffSprite;
			uibtnIcon_bpRowCount2.sprite = checkboxOnSprite;
		}
		if (solution.userPreference.bpResourceCoater == 0)
		{
			uibtnIcon_bpCoaterAuto.sprite = checkboxOnSprite;
			uibtnIcon_bpCoaterAlways.sprite = checkboxOffSprite;
			uibtnIcon_bpCoaterNever.sprite = checkboxOffSprite;
		}
		else if (solution.userPreference.bpResourceCoater == 1)
		{
			uibtnIcon_bpCoaterAuto.sprite = checkboxOffSprite;
			uibtnIcon_bpCoaterAlways.sprite = checkboxOnSprite;
			uibtnIcon_bpCoaterNever.sprite = checkboxOffSprite;
		}
		else if (solution.userPreference.bpResourceCoater == -1)
		{
			uibtnIcon_bpCoaterAuto.sprite = checkboxOffSprite;
			uibtnIcon_bpCoaterAlways.sprite = checkboxOffSprite;
			uibtnIcon_bpCoaterNever.sprite = checkboxOnSprite;
		}
		if (solution.userPreference.bpStationProlifSlot)
		{
			uibtnIcon_bpStationProlifSlotYes.sprite = checkboxOnSprite;
			uibtnIcon_bpStationProlifSlotNo.sprite = checkboxOffSprite;
		}
		else if (!solution.userPreference.bpStationProlifSlot)
		{
			uibtnIcon_bpStationProlifSlotYes.sprite = checkboxOffSprite;
			uibtnIcon_bpStationProlifSlotNo.sprite = checkboxOnSprite;
		}
		if (solution.userPreference.bpBeltHighest)
		{
			uibtnIcon_bpBeltHigh.sprite = checkboxOnSprite;
			uibtnIcon_bpBeltLow.sprite = checkboxOffSprite;
		}
		else
		{
			uibtnIcon_bpBeltHigh.sprite = checkboxOffSprite;
			uibtnIcon_bpBeltLow.sprite = checkboxOnSprite;
		}
		if (solution.userPreference.bpBeltTechLimit)
		{
			uibtnIcon_bpBeltLimit.sprite = checkboxOnSprite;
			uibtnIcon_bpBeltUnlimit.sprite = checkboxOffSprite;
		}
		else
		{
			uibtnIcon_bpBeltLimit.sprite = checkboxOffSprite;
			uibtnIcon_bpBeltUnlimit.sprite = checkboxOnSprite;
		}
		if (solution.userPreference.bpSorterHighest)
		{
			uibtnIcon_bpSorterHigh.sprite = checkboxOnSprite;
			uibtnIcon_bpSorterLow.sprite = checkboxOffSprite;
		}
		else
		{
			uibtnIcon_bpSorterHigh.sprite = checkboxOffSprite;
			uibtnIcon_bpSorterLow.sprite = checkboxOnSprite;
		}
		if (solution.userPreference.bpSorterTechLimit)
		{
			uibtnIcon_bpSorterLimit.sprite = checkboxOnSprite;
			uibtnIcon_bpSorterUnlimit.sprite = checkboxOffSprite;
		}
		else
		{
			uibtnIcon_bpSorterLimit.sprite = checkboxOffSprite;
			uibtnIcon_bpSorterUnlimit.sprite = checkboxOnSprite;
		}
		if (solution.userPreference.bpConnectBlackboxCoater)
		{
			uibtnIcon_bpBlackboxConnectCoater.sprite = checkboxOnSprite;
			uibtnIcon_bpBlackboxNotConnectCoater.sprite = checkboxOffSprite;
		}
		else
		{
			uibtnIcon_bpBlackboxConnectCoater.sprite = checkboxOffSprite;
			uibtnIcon_bpBlackboxNotConnectCoater.sprite = checkboxOnSprite;
		}
		uibtnIcon_bpStack1.sprite = ((solution.userPreference.bpStackSetting == 1) ? checkboxOnSprite : checkboxOffSprite);
		uibtnIcon_bpStack2.sprite = ((solution.userPreference.bpStackSetting == 2) ? checkboxOnSprite : checkboxOffSprite);
		uibtnIcon_bpStack3.sprite = ((solution.userPreference.bpStackSetting == 3) ? checkboxOnSprite : checkboxOffSprite);
		uibtnIcon_bpStack4.sprite = ((solution.userPreference.bpStackSetting == 4) ? checkboxOnSprite : checkboxOffSprite);
		uibtnIcon_bpStackCur.sprite = ((solution.userPreference.bpStackSetting == 0) ? checkboxOnSprite : checkboxOffSprite);
		uibtnIcon_bpProductCoaterAlways.sprite = (solution.userPreference.bpProductCoater ? checkboxOnSprite : checkboxOffSprite);
		uibtnIcon_bpProductCoaterNever.sprite = (solution.userPreference.bpProductCoater ? checkboxOffSprite : checkboxOnSprite);
		solution.RefreshBlueprintDicts();
		foreach (UIItemNode uiItemNode in uiItemNodes)
		{
			uiItemNode.RefreshBpProcessor();
		}
	}

	public void RefreshAssemblerDemandsDisplay()
	{
		foreach (GameObject assemblersDemandObj in assemblersDemandObjs)
		{
			UnityEngine.Object.DestroyImmediate(assemblersDemandObj);
		}
		assemblersDemandObjs.Clear();
		Dictionary<int, long> dictionary = new Dictionary<int, long>();
		foreach (KeyValuePair<int, RecipeInfo> recipeInfo in solution.recipeInfos)
		{
			RecipeInfo value = recipeInfo.Value;
			if (value.useIA)
			{
				continue;
			}
			int assemblerItemId = value.assemblerItemId;
			long num = (long)Math.Ceiling(value.assemblerCount);
			if (!solution.userPreference.finishedRecipes.ContainsKey(value.ID) || !DSPCalculatorPlugin.OnlyCountUnfinishedFacilities.Value)
			{
				if (!dictionary.ContainsKey(assemblerItemId))
				{
					dictionary[assemblerItemId] = num;
				}
				else
				{
					dictionary[assemblerItemId] += num;
				}
			}
		}
		int num2 = 0;
		float num3 = 100f;
		foreach (KeyValuePair<int, long> item in dictionary)
		{
			if (item.Value > 0)
			{
				int key = item.Key;
				long value2 = item.Value;
				GameObject gameObject = UnityEngine.Object.Instantiate(iconObj_ButtonTip, assemblersDemandsGroupObj.transform);
				gameObject.GetComponent<RectTransform>().anchoredPosition3D = new Vector3((float)(num2 % 4) * num3, -(num2 / 4 * 35), 0f);
				gameObject.GetComponent<RectTransform>().sizeDelta = new Vector2(30f, 30f);
				gameObject.GetComponent<Image>().sprite = LDB.items.Select(key).iconSprite;
				gameObject.GetComponent<UIButton>().tips.itemId = key;
				gameObject.GetComponent<UIButton>().tips.corner = 3;
				gameObject.GetComponent<UIButton>().tips.delay = 0.2f;
				GameObject gameObject2 = UnityEngine.Object.Instantiate(TextWithUITip, assemblersDemandsGroupObj.transform);
				gameObject2.name = "assembler-count";
				gameObject2.transform.localScale = Vector3.one;
				gameObject2.GetComponent<RectTransform>().anchoredPosition3D = new Vector3((float)(num2 % 4) * num3 + 35f, -(num2 / 4 * 35), 0f);
				gameObject2.GetComponent<UIButton>().tips.delay = 0.4f;
				gameObject2.GetComponent<UIButton>().tips.corner = 2;
				Text component = gameObject2.GetComponent<Text>();
				component.text = "× " + Utils.KMG(value2);
				component.fontSize = 16;
				component.raycastTarget = true;
				if (value2 > 9999)
				{
					gameObject2.GetComponent<UIButton>().tips.tipTitle = value2.ToString("N0");
				}
				assemblersDemandObjs.Add(gameObject);
				assemblersDemandObjs.Add(gameObject2);
				num2++;
			}
		}
	}

	public void OnGlobalIncToggleClick()
	{
		bool flag = !solution.userPreference.globalIsInc;
		solution.userPreference.globalIsInc = flag;
		foreach (KeyValuePair<int, RecipeConfig> recipeConfig in solution.userPreference.recipeConfigs)
		{
			if (recipeConfig.Value.forceIncMode >= 0)
			{
				recipeConfig.Value.forceIncMode = (flag ? 1 : 0);
			}
		}
		RefreshIncToggle();
		nextFrameRecalc = true;
	}

	public void RefreshIncToggle()
	{
		GameObject gameObject = incToggleObj.transform.Find("inc-switch/switch-thumb").gameObject;
		if (solution.userPreference.globalIsInc)
		{
			gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(-10f, 0f);
			incText.text = "额外产出calc".Translate();
			incText.color = incModeTextColor;
			incToggleObj.transform.Find("inc-switch").GetComponent<Image>().color = incModeImageColor;
		}
		else
		{
			gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(10f, 0f);
			incText.text = "生产加速calc".Translate();
			incText.color = accModeTextColor;
			incToggleObj.transform.Find("inc-switch").GetComponent<Image>().color = accModeImageColor;
		}
	}

	public void SetGlobalIncLevel(int level)
	{
		solution.userPreference.globalIncLevel = level;
		foreach (KeyValuePair<int, RecipeConfig> recipeConfig in solution.userPreference.recipeConfigs)
		{
			recipeConfig.Value.incLevel = level;
		}
		RefreshProliferatorButtonDisplay();
		nextFrameRecalc = true;
	}

	public void RefreshProliferatorButtonDisplay()
	{
		foreach (KeyValuePair<int, UIButton> proliferatorUsedButton in proliferatorUsedButtons)
		{
			if (proliferatorUsedButton.Key == solution.userPreference.globalIncLevel)
			{
				proliferatorUsedButton.Value.highlighted = true;
			}
			else
			{
				proliferatorUsedButton.Value.highlighted = false;
			}
		}
	}

	public void SetGlobalAssemblerPreference(int assemblerFullCode)
	{
		if (assemblerFullCode >= 0)
		{
			int num = assemblerFullCode / 100000;
			int num2 = assemblerFullCode % 100000;
			solution.userPreference.globalUseIA = false;
			solution.userPreference.globalAssemblerIdByType[num] = num2;
			if (assemblerFullCode == -1)
			{
				foreach (KeyValuePair<int, RecipeInfo> recipeInfo in solution.recipeInfos)
				{
					int iD = recipeInfo.Value.ID;
					if (!solution.userPreference.recipeConfigs.ContainsKey(iD))
					{
						solution.userPreference.recipeConfigs[iD] = new RecipeConfig(recipeInfo.Value);
					}
				}
			}
			foreach (KeyValuePair<int, RecipeConfig> recipeConfig in solution.userPreference.recipeConfigs)
			{
				if (CalcDB.recipeDict.ContainsKey(recipeConfig.Value.ID))
				{
					int type = CalcDB.recipeDict[recipeConfig.Value.ID].type;
					if (type == num)
					{
						solution.userPreference.recipeConfigs[recipeConfig.Key].assemblerItemId = num2;
						solution.userPreference.recipeConfigs[recipeConfig.Key].forceUseIA = false;
					}
				}
			}
		}
		else if (assemblerFullCode == -1)
		{
			if (!solution.userPreference.globalUseIA)
			{
				solution.userPreference.globalUseIA = true;
			}
			else
			{
				solution.userPreference.globalIAType = (solution.userPreference.globalIAType + 1) % 6;
			}
			foreach (KeyValuePair<int, RecipeConfig> recipeConfig2 in solution.userPreference.recipeConfigs)
			{
				solution.userPreference.recipeConfigs[recipeConfig2.Key].forceUseIA = solution.userPreference.globalUseIA;
				solution.userPreference.recipeConfigs[recipeConfig2.Key].IAType = solution.userPreference.globalIAType;
			}
		}
		foreach (UIItemNode uiItemNode in uiItemNodes)
		{
			uiItemNode.RefreshAssemblerDisplay(refreshGlobal: false);
		}
		if (CompatManager.GB || CompatManager.MMS)
		{
			nextFrameRecalc = true;
			return;
		}
		RefreshAssemblerButtonDisplay();
		RefreshAssemblerDemandsDisplay();
		RefreshFinalInfoText();
	}

	public void RefreshAssemblerButtonDisplay()
	{
		foreach (KeyValuePair<int, Dictionary<int, UIButton>> assemblerUsedButton in assemblerUsedButtons)
		{
			int key = assemblerUsedButton.Key;
			int num = -1;
			if (CalcDB.assemblerListByType.ContainsKey(key) && CalcDB.assemblerListByType[key].Count > 0)
			{
				num = CalcDB.assemblerListByType[key][0].ID;
			}
			if (solution.userPreference.globalAssemblerIdByType.ContainsKey(key))
			{
				num = solution.userPreference.globalAssemblerIdByType[key];
			}
			foreach (KeyValuePair<int, UIButton> item in assemblerUsedButton.Value)
			{
				if (item.Key >= 0)
				{
					if (!solution.userPreference.globalUseIA && item.Key == num)
					{
						item.Value.highlighted = true;
					}
					else
					{
						item.Value.highlighted = false;
					}
				}
				else
				{
					if (item.Key != -1)
					{
						continue;
					}
					if (solution.userPreference.globalUseIA)
					{
						item.Value.highlighted = true;
						int num2 = IASpecializationIconItemMap[solution.userPreference.globalIAType];
						if (num2 > 0)
						{
							IABtnSpecializationImg.sprite = LDB.items.Select(num2)?.iconSprite;
						}
						else
						{
							IABtnSpecializationImg.sprite = LDB.recipes.Select(-num2)?.iconSprite;
						}
						if (solution.userPreference.globalIAType > 0)
						{
							item.Value.tips.tipTitle = $"特化{solution.userPreference.globalIAType}介绍标题".Translate();
						}
						else
						{
							item.Value.tips.tipTitle = "使用星际组装厂按钮标题".Translate();
						}
						if (item.Value.tipShowing)
						{
							try
							{
								float enterTime = item.Value.enterTime;
								item.Value.OnPointerExit(null);
								item.Value.OnPointerEnter(null);
								item.Value.enterTime = enterTime;
							}
							catch (Exception)
							{
							}
						}
					}
					else
					{
						item.Value.highlighted = false;
					}
				}
			}
		}
	}

	public void ClearAllUserPreference()
	{
		solution.ClearUserPreference();
		double.TryParse(speedInputObj.GetComponent<InputField>().text, out var result);
		solution.ReSolve(result);
		RefreshAll();
	}

	public void SaveAllUserPreferenceAsDefault()
	{
		if (Input.GetKey(KeyCode.LeftControl) || Input.GetKey(KeyCode.RightControl))
		{
			DSPCalculatorPlugin.DefaultNewWindowData.Value = "";
			DSPCalculatorPlugin.DefaultNewWindowData.ConfigFile.Save();
			UIRealtimeTip.Popup("calc设置成功提示".Translate());
			return;
		}
		string text = Copy();
		if (text.Length > 13)
		{
			UIRealtimeTip.Popup("calc设置成功提示".Translate());
			DSPCalculatorPlugin.DefaultNewWindowData.Value = text;
			DSPCalculatorPlugin.DefaultNewWindowData.ConfigFile.Save();
		}
		else
		{
			UIRealtimeTip.Popup("Unknown Error");
		}
	}

	public void TryLoadDefault()
	{
		string value = DSPCalculatorPlugin.DefaultNewWindowData.Value;
		if (value == null || value.Length <= 13)
		{
			return;
		}
		try
		{
			if (!TryPaste(value))
			{
				ClearAllUserPreference();
				DSPCalculatorPlugin.DefaultNewWindowData.Value = "";
				DSPCalculatorPlugin.DefaultNewWindowData.ConfigFile.Save();
			}
		}
		catch (Exception)
		{
			ClearAllUserPreference();
			DSPCalculatorPlugin.DefaultNewWindowData.Value = "";
			DSPCalculatorPlugin.DefaultNewWindowData.ConfigFile.Save();
		}
	}

	public void RefreshCheckBoxes()
	{
		if (cbBluebuff != null)
		{
			if (solution.userPreference.bluebuff)
			{
				cbBluebuff.sprite = checkboxOnSprite;
			}
			else
			{
				cbBluebuff.sprite = checkboxOffSprite;
			}
			txtBluebuff.text = "遗物名称0-1".Translate().Split(new char[1] { '\n' })[0];
		}
		if (cbEnergyBurst != null)
		{
			if (solution.userPreference.energyBurst)
			{
				cbEnergyBurst.sprite = checkboxOnSprite;
			}
			else
			{
				cbEnergyBurst.sprite = checkboxOffSprite;
			}
			txtEnergyBurst.text = "遗物名称1-6".Translate().Split(new char[1] { '\n' })[0];
		}
		if (cbDirac != null)
		{
			if (solution.userPreference.dirac)
			{
				cbDirac.sprite = checkboxOnSprite;
			}
			else
			{
				cbDirac.sprite = checkboxOffSprite;
			}
			txtDirac.text = "遗物名称2-8".Translate().Split(new char[1] { '\n' })[0];
		}
		if (cbInferior != null)
		{
			if (solution.userPreference.inferior)
			{
				cbInferior.sprite = checkboxOnSprite;
			}
			else
			{
				cbInferior.sprite = checkboxOffSprite;
			}
			txtInferior.text = "遗物名称3-0".Translate().Split(new char[1] { '\n' })[0];
		}
		if (cbIncMilli != null)
		{
			if (solution.userPreference.customizeIncMilli)
			{
				cbIncMilli.sprite = checkboxOnSprite;
			}
			else
			{
				cbIncMilli.sprite = checkboxOffSprite;
			}
			txtIncMilli.text = "强制增产效能".Translate();
			incInput.text = ((int)Math.Round(solution.userPreference.incMilliOverride * 100.0)).ToString();
		}
		if (cbAccMilli != null)
		{
			if (solution.userPreference.customizeAccMilli)
			{
				cbAccMilli.sprite = checkboxOnSprite;
			}
			else
			{
				cbAccMilli.sprite = checkboxOffSprite;
			}
			txtAccMilli.text = "强制加速效能".Translate();
			accInput.text = ((int)Math.Round(solution.userPreference.accMilliOverride * 100.0)).ToString();
		}
		if (cbRoundUp != null)
		{
			if (solution.userPreference.roundUpAssemgblerNum)
			{
				cbRoundUp.sprite = checkboxOnSprite;
			}
			else
			{
				cbRoundUp.sprite = checkboxOffSprite;
			}
			txtRoundUp.text = "生产设施数量显示向上取整".Translate();
		}
		if (cbMixbelt != null)
		{
			if (solution.userPreference.showMixBeltInfo)
			{
				cbMixbelt.sprite = checkboxOnSprite;
			}
			else
			{
				cbMixbelt.sprite = checkboxOffSprite;
			}
			txtMixbelt.text = "显示混带信息".Translate();
		}
		if (cbSolveProlifer != null)
		{
			if (solution.userPreference.solveProliferators)
			{
				cbSolveProlifer.sprite = checkboxOnSprite;
			}
			else
			{
				cbSolveProlifer.sprite = checkboxOffSprite;
			}
			txtSolveProlifer.text = "增产剂并入产线".Translate();
		}
	}

	public void GenerateBlackboxBpAndPaste()
	{
		int genLevel = ((Input.GetKey(KeyCode.LeftShift) || Input.GetKey(KeyCode.RightShift)) ? 1 : 0);
		BpConnector bpConnector = new BpConnector(this, genLevel);
		if (bpConnector.succeeded)
		{
			CloseWindow();
			WindowsManager.temporaryCloseBecausePasteBp = true;
			GameMain.mainPlayer.controller.OpenBlueprintPasteMode(bpConnector.blueprintData, GameConfig.blueprintFolder + "DSPCalcBPTemp.txt");
		}
	}

	public void RefreshBpGenButton()
	{
		if (!(genBpButtonObj != null))
		{
			return;
		}
		if (BpConnector.enabled)
		{
			if (solution.targets.Count > 0 && solution.targets[0].itemId > 0)
			{
				genBpButtonObj.SetActive(value: true);
			}
			else
			{
				genBpButtonObj.SetActive(value: false);
			}
		}
		else
		{
			genBpButtonObj.SetActive(value: false);
		}
	}

	public void RefreshProgressCircle()
	{
		double num = 0.0;
		double num2 = 0.0;
		foreach (KeyValuePair<int, RecipeInfo> recipeInfo in solution.recipeInfos)
		{
			RecipeInfo value = recipeInfo.Value;
			if (value.count > 9.999999747378752E-05)
			{
				num += value.assemblerCount;
				if (solution.userPreference.finishedRecipes.ContainsKey(recipeInfo.Key))
				{
					num2 += value.assemblerCount;
				}
			}
		}
		double num3 = 0.0;
		if (num > 0.0)
		{
			num3 = num2 / num;
		}
		progressCircleImg.fillAmount = (float)num3;
		if (num3 >= 1.0)
		{
			progressCircleImg.color = finishedProgressColor;
		}
		else
		{
			progressCircleImg.color = inProgressColor;
		}
	}

	public void FocusTargetNode(int itemId)
	{
		if (uiItemNodeOrders.ContainsKey(itemId))
		{
			int num = uiItemNodeOrders[itemId];
			int count = uiItemNodeOrders.Count;
			if (num >= 0 && num < uiItemNodeOrders.Count)
			{
				if (count >= 8)
				{
					int num2 = num - 3;
					int num3 = count - 7;
					if (num2 < 0)
					{
						num2 = 0;
					}
					if (num2 > num3)
					{
						num2 = num3;
					}
					float num4 = 1f - 1f * (float)num2 / (float)num3;
					targetVerticalPosition = num4;
				}
				UIItemNode uIItemNode = uiItemNodes[num];
				Color color = uIItemNode.backgroundImg.color;
				uIItemNode.backgroundImg.color = new Color(color.r, color.g, color.b, 1f);
			}
		}
		if (uiItemSimplesByItemId.ContainsKey(itemId))
		{
			UIItemNodeSimple uIItemNodeSimple = uiItemSimplesByItemId[itemId];
			Color color2 = uIItemNodeSimple.backgroundImg.color;
			uIItemNodeSimple.backgroundImg.color = new Color(color2.r, color2.g, color2.b, 1f);
		}
	}

	public void OnBluebuffClick()
	{
		solution.userPreference.bluebuff = !solution.userPreference.bluebuff;
		RefreshCheckBoxes();
		nextFrameRecalc = true;
	}

	public void OnEnergyBurstClick()
	{
		solution.userPreference.energyBurst = !solution.userPreference.energyBurst;
		RefreshCheckBoxes();
		nextFrameRecalc = true;
	}

	public void OnDiracClick()
	{
		solution.userPreference.dirac = !solution.userPreference.dirac;
		RefreshCheckBoxes();
		nextFrameRecalc = true;
	}

	public void OnInferiorClick()
	{
		solution.userPreference.inferior = !solution.userPreference.inferior;
		RefreshCheckBoxes();
		nextFrameRecalc = true;
	}

	public void OnCustomIncMilliClick()
	{
		solution.userPreference.customizeIncMilli = !solution.userPreference.customizeIncMilli;
		RefreshCheckBoxes();
		nextFrameRecalc = true;
	}

	public void OnCustomAccMilliClick()
	{
		solution.userPreference.customizeAccMilli = !solution.userPreference.customizeAccMilli;
		RefreshCheckBoxes();
		nextFrameRecalc = true;
	}

	public void OnEndEditIncMilli(string input)
	{
		int num = 25;
		try
		{
			num = Convert.ToInt32(input);
			if (num < 0)
			{
				num = 0;
			}
		}
		catch (Exception)
		{
			num = 25;
		}
		incInput.text = num.ToString();
		solution.userPreference.incMilliOverride = 1.0 * (double)num / 100.0;
		nextFrameRecalc = true;
	}

	public void OnEndEditAccMilli(string input)
	{
		int num = 100;
		try
		{
			num = Convert.ToInt32(input);
			if (num < 0)
			{
				num = 0;
			}
		}
		catch (Exception)
		{
			num = 100;
		}
		accInput.text = num.ToString();
		solution.userPreference.accMilliOverride = 1.0 * (double)num / 100.0;
		nextFrameRecalc = true;
	}

	public void OnAssemblerRoundUpSettingChange()
	{
		bool roundUpAssemgblerNum = solution.userPreference.roundUpAssemgblerNum;
		bool flag = !roundUpAssemgblerNum;
		solution.userPreference.roundUpAssemgblerNum = flag;
		DSPCalculatorPlugin.RoundUpAssemblerNum.Value = flag;
		DSPCalculatorPlugin.RoundUpAssemblerNum.ConfigFile.Save();
		RefreshCheckBoxes();
		foreach (UIItemNode uiItemNode in uiItemNodes)
		{
			uiItemNode.RefreshAssemblerDisplay(refreshGlobal: false);
		}
	}

	public void OnSolveProliferatorSettingChange()
	{
		bool solveProliferators = solution.userPreference.solveProliferators;
		bool solveProliferators2 = !solveProliferators;
		solution.userPreference.solveProliferators = solveProliferators2;
		RefreshCheckBoxes();
		nextFrameRecalc = true;
	}

	public void OnSideInfoPageChange(int page)
	{
		if (sideInfoPanelIndex != page)
		{
			sideInfoPanelIndex = page;
			RefreshSideInfoPanels();
		}
	}

	public void OnMixbeltInfoCbClick()
	{
		solution.userPreference.showMixBeltInfo = !solution.userPreference.showMixBeltInfo;
		cbMixbelt.sprite = (solution.userPreference.showMixBeltInfo ? checkboxOnSprite : checkboxOffSprite);
		nextFrameRecalc = true;
	}

	public void OnBpRowSet(int i)
	{
		solution.userPreference.bpRowCount = i;
		RefreshBpPreferences();
	}

	public void OnBpCoaterSet(int i)
	{
		solution.userPreference.bpResourceCoater = i;
		RefreshBpPreferences();
	}

	public void OnBpProductCoaterSet(bool gen)
	{
		solution.userPreference.bpProductCoater = gen;
		RefreshBpPreferences();
	}

	public void OnBpStationProliferatorSlotSet(bool haveSlot)
	{
		solution.userPreference.bpStationProlifSlot = haveSlot;
		RefreshBpPreferences();
	}

	public void OnBpBeltPreferenceSet(bool highest)
	{
		solution.userPreference.bpBeltHighest = highest;
		RefreshBpPreferences();
	}

	public void OnBpBeltTechLimitSet(bool limited)
	{
		solution.userPreference.bpBeltTechLimit = limited;
		RefreshBpPreferences();
	}

	public void OnBpSorterPreferenceSet(bool highest)
	{
		solution.userPreference.bpSorterHighest = highest;
		RefreshBpPreferences();
	}

	public void OnBpSorterTechLimitSet(bool limited)
	{
		solution.userPreference.bpSorterTechLimit = limited;
		RefreshBpPreferences();
	}

	public void OnBpStackSet(int stack)
	{
		solution.userPreference.bpStackSetting = stack;
		RefreshBpPreferences();
	}

	public void OnBpBlackboxCoaterConnectSet(bool connect)
	{
		solution.userPreference.bpConnectBlackboxCoater = connect;
		RefreshBpPreferences();
	}

	public void OnCopyButtonClick()
	{
		string text = Copy();
		if (text.Length > 13)
		{
			GUIUtility.systemCopyBuffer = text;
			UIRealtimeTip.Popup("calc复制成功提示".Translate());
		}
		else
		{
			UIRealtimeTip.Popup("calc复制失败提示".Translate());
		}
	}

	public void OnPresetOreButtonClick()
	{
		UIItemPicker.showAll = true;
		if (windowObj.GetComponent<RectTransform>().anchoredPosition.x > -150f && !isLargeWindow)
		{
			UIItemPicker.Popup(new Vector2(-300f, 100f), OnRawOreSelected);
		}
		else
		{
			UIItemPicker.Popup(windowObj.GetComponent<RectTransform>().anchoredPosition + new Vector2(300f, -200f), OnRawOreSelected);
		}
	}

	public void OnPresetOreButtonRightClick()
	{
		VFAudio.Create("ui-click-0", null, Vector3.zero, play: true, 4, -1, -1L);
		if (solution.userPreference.itemConfigs.Count > 0)
		{
			foreach (KeyValuePair<int, ItemConfig> itemConfig in solution.userPreference.itemConfigs)
			{
				solution.userPreference.itemConfigs[itemConfig.Key].consideredAsOre = false;
				solution.userPreference.itemConfigs[itemConfig.Key].forceNotOre = false;
			}
			nextFrameRecalc = true;
		}
		UIRealtimeTip.Popup("还原配置成功".Translate(), sound: false);
	}

	public void OnRawOreSelected(ItemProto item)
	{
		UIItemPicker.showAll = false;
		if (item != null)
		{
			if (!solution.userPreference.itemConfigs.ContainsKey(item.ID))
			{
				solution.userPreference.itemConfigs[item.ID] = new ItemConfig(item.ID);
			}
			solution.userPreference.itemConfigs[item.ID].consideredAsOre = true;
			solution.userPreference.itemConfigs[item.ID].forceNotOre = false;
			nextFrameRecalc = true;
			UIRealtimeTip.Popup("已设置为原矿".Translate(), sound: false);
			VFAudio.Create("ui-click-0", null, Vector3.zero, play: true, 4, -1, -1L);
		}
	}

	public string Copy()
	{
		string text = "DSPCalcData,";
		for (int i = 0; i < solution.targets.Count; i++)
		{
			text = text + Utils.GetItemName(solution.targets[i].itemId) + ":" + solution.targets[i].speed;
			text += ",";
		}
		text += "\"";
		string result = "";
		try
		{
			StringBuilder stringBuilder = new StringBuilder(1024);
			using MemoryStream memoryStream = new MemoryStream();
			using BinaryWriter w = new BinaryWriter(memoryStream);
			solution.Export(w);
			memoryStream.Position = 0L;
			using MemoryStream memoryStream2 = new MemoryStream();
			using (GZipStream destination = new GZipStream(memoryStream2, CompressionMode.Compress))
			{
				memoryStream.CopyTo(destination);
			}
			byte[] inArray = memoryStream2.ToArray();
			stringBuilder.Append(text);
			stringBuilder.Append(Convert.ToBase64String(inArray));
			string value = MD5F.Compute(stringBuilder.ToString());
			stringBuilder.Append("\"");
			stringBuilder.Append(value);
			result = stringBuilder.ToString();
		}
		catch (Exception ex)
		{
			Debug.LogError(ex.ToString().Replace("Exception", "Excption"));
			return "";
		}
		return result;
	}

	public void OnPasteButtonClick()
	{
		string systemCopyBuffer = GUIUtility.systemCopyBuffer;
		if (!TryPaste(systemCopyBuffer))
		{
			ClearAllUserPreference();
			UIRealtimeTip.Popup("calc粘贴失败提示".Translate());
		}
		else
		{
			UIRealtimeTip.Popup("calc粘贴成功提示".Translate());
		}
	}

	public bool TryPaste(string str)
	{
		string text = "DSPCalcData,";
		if (str.Length <= text.Length)
		{
			return false;
		}
		for (int i = 0; i < text.Length; i++)
		{
			if (text[i] != str[i])
			{
				return false;
			}
		}
		if (LoadFromBase64String(str))
		{
			RefreshAll();
			nextFrameRecalc = true;
			return true;
		}
		return false;
	}

	public bool LoadFromBase64String(string str)
	{
		try
		{
			int num = -1;
			int num2 = -1;
			for (int i = 0; i < str.Length; i++)
			{
				if (str[i] == '"')
				{
					num = i;
					break;
				}
			}
			if (num < 0)
			{
				return false;
			}
			for (int num3 = str.Length - 1; num3 >= 0; num3--)
			{
				if (str[num3] == '"')
				{
					num2 = num3;
					break;
				}
			}
			if (num2 < num + 2)
			{
				return false;
			}
			using MemoryStream stream = new MemoryStream(Convert.FromBase64String(str.Substring(num + 1, num2 - num - 1)));
			using MemoryStream memoryStream = new MemoryStream();
			using (GZipStream gZipStream = new GZipStream(stream, CompressionMode.Decompress))
			{
				gZipStream.CopyTo(memoryStream);
			}
			memoryStream.Position = 0L;
			using BinaryReader r = new BinaryReader(memoryStream);
			solution.Import(r);
		}
		catch (Exception)
		{
			return false;
		}
		return true;
	}
}
