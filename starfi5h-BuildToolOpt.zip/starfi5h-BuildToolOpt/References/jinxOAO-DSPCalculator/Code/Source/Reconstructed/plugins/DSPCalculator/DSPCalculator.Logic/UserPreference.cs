using System.Collections.Generic;
using System.IO;

namespace DSPCalculator.Logic;

public class UserPreference
{
	public Dictionary<int, RecipeConfig> recipeConfigs;

	public Dictionary<int, ItemConfig> itemConfigs;

	public int globalIncLevel;

	public bool globalIsInc;

	public Dictionary<int, int> globalAssemblerIdByType;

	public bool globalUseIA;

	public int globalIAType;

	public bool bluebuff;

	public bool energyBurst;

	public bool dirac;

	public bool inferior;

	public bool customizeIncMilli;

	public bool customizeAccMilli;

	public double incMilliOverride;

	public double accMilliOverride;

	public Dictionary<int, int> finishedRecipes;

	public bool roundUpAssemgblerNum;

	public bool solveProliferators;

	public int bpRowCount;

	public int bpResourceCoater;

	public bool bpProductCoater;

	public bool bpStationProlifSlot;

	public bool bpBeltHighest;

	public bool bpBeltTechLimit;

	public bool bpSorterHighest;

	public bool bpSorterTechLimit;

	public int bpStackSetting;

	public bool bpConnectBlackboxCoater;

	public bool showMixBeltInfo;

	public int bpStack
	{
		get
		{
			if (bpStackSetting == 0)
			{
				if (GameMain.history.TechUnlocked(3803))
				{
					return 4;
				}
				if (GameMain.history.TechUnlocked(3802))
				{
					return 3;
				}
				if (GameMain.history.TechUnlocked(3801))
				{
					return 2;
				}
				return 1;
			}
			return bpStackSetting;
		}
	}

	public int bpSorterMk4OutputStack
	{
		get
		{
			if (bpStackSetting == 0)
			{
				if (GameMain.history.TechUnlocked(3315))
				{
					return 4;
				}
				if (GameMain.history.TechUnlocked(3313))
				{
					return 3;
				}
				if (GameMain.history.TechUnlocked(3311))
				{
					return 2;
				}
				return 1;
			}
			return bpStackSetting;
		}
	}

	public int labMaxLevel
	{
		get
		{
			if (GameMain.history.TechUnlocked(3706))
			{
				return 15;
			}
			if (GameMain.history.TechUnlocked(3705))
			{
				return 13;
			}
			if (GameMain.history.TechUnlocked(3704))
			{
				return 11;
			}
			if (GameMain.history.TechUnlocked(3703))
			{
				return 9;
			}
			if (GameMain.history.TechUnlocked(3702))
			{
				return 7;
			}
			if (GameMain.history.TechUnlocked(3701))
			{
				return 5;
			}
			return 3;
		}
	}

	public UserPreference()
	{
		recipeConfigs = new Dictionary<int, RecipeConfig>();
		itemConfigs = new Dictionary<int, ItemConfig>();
		finishedRecipes = new Dictionary<int, int>();
		globalIncLevel = 0;
		globalIsInc = true;
		bluebuff = false;
		energyBurst = false;
		dirac = false;
		inferior = false;
		customizeIncMilli = false;
		customizeAccMilli = false;
		roundUpAssemgblerNum = DSPCalculatorPlugin.RoundUpAssemblerNum.Value;
		solveProliferators = false;
		showMixBeltInfo = false;
		incMilliOverride = 0.25;
		accMilliOverride = 1.0;
		globalAssemblerIdByType = new Dictionary<int, int>();
		globalUseIA = false;
		globalIAType = 0;
		bpRowCount = 2;
		bpResourceCoater = 0;
		bpProductCoater = false;
		bpStationProlifSlot = true;
		bpBeltHighest = false;
		bpBeltTechLimit = true;
		bpSorterHighest = false;
		bpSorterTechLimit = true;
		bpStackSetting = 0;
		bpConnectBlackboxCoater = true;
	}

	public void ClearWhenChangeTarget()
	{
		finishedRecipes.Clear();
	}

	public UserPreference ShallowCopy()
	{
		UserPreference userPreference = new UserPreference();
		userPreference.recipeConfigs = recipeConfigs;
		userPreference.itemConfigs = itemConfigs;
		userPreference.finishedRecipes = finishedRecipes;
		userPreference.globalIncLevel = globalIncLevel;
		userPreference.globalIsInc = globalIsInc;
		userPreference.bluebuff = bluebuff;
		userPreference.energyBurst = energyBurst;
		userPreference.dirac = dirac;
		userPreference.inferior = inferior;
		userPreference.customizeIncMilli = customizeIncMilli;
		userPreference.customizeAccMilli = customizeAccMilli;
		userPreference.solveProliferators = solveProliferators;
		userPreference.showMixBeltInfo = showMixBeltInfo;
		userPreference.incMilliOverride = incMilliOverride;
		userPreference.accMilliOverride = accMilliOverride;
		userPreference.globalAssemblerIdByType = globalAssemblerIdByType;
		return userPreference;
	}

	public UserPreference DeepCopy()
	{
		UserPreference userPreference = new UserPreference();
		userPreference.recipeConfigs = new Dictionary<int, RecipeConfig>();
		foreach (KeyValuePair<int, RecipeConfig> recipeConfig in recipeConfigs)
		{
			userPreference.recipeConfigs[recipeConfig.Key] = new RecipeConfig(recipeConfig.Value);
		}
		userPreference.itemConfigs = new Dictionary<int, ItemConfig>();
		foreach (KeyValuePair<int, ItemConfig> itemConfig in itemConfigs)
		{
			userPreference.itemConfigs[itemConfig.Key] = new ItemConfig(itemConfig.Value);
		}
		userPreference.finishedRecipes = new Dictionary<int, int>();
		foreach (KeyValuePair<int, int> finishedRecipe in finishedRecipes)
		{
			userPreference.finishedRecipes[finishedRecipe.Key] = finishedRecipe.Value;
		}
		userPreference.globalIncLevel = globalIncLevel;
		userPreference.globalIsInc = globalIsInc;
		userPreference.bluebuff = bluebuff;
		userPreference.energyBurst = energyBurst;
		userPreference.dirac = dirac;
		userPreference.inferior = inferior;
		userPreference.customizeIncMilli = customizeIncMilli;
		userPreference.customizeAccMilli = customizeAccMilli;
		userPreference.solveProliferators = solveProliferators;
		userPreference.showMixBeltInfo = showMixBeltInfo;
		userPreference.incMilliOverride = incMilliOverride;
		userPreference.accMilliOverride = accMilliOverride;
		userPreference.globalAssemblerIdByType = new Dictionary<int, int>();
		foreach (KeyValuePair<int, int> item in globalAssemblerIdByType)
		{
			userPreference.globalAssemblerIdByType[item.Key] = item.Value;
		}
		return userPreference;
	}

	public bool IsOre(int itemId)
	{
		bool flag = CalcDB.itemDict[itemId].defaultAsOre || CalcDB.itemDict[itemId].recipes.Count == 0;
		if (itemConfigs.ContainsKey(itemId))
		{
			flag = itemConfigs[itemId].consideredAsOre || flag;
			if (itemConfigs[itemId].forceNotOre && CalcDB.itemDict[itemId].recipes.Count > 0)
			{
				flag = false;
			}
		}
		return flag;
	}

	public void Export(BinaryWriter w)
	{
		int count = recipeConfigs.Count;
		w.Write(count);
		foreach (KeyValuePair<int, RecipeConfig> recipeConfig in recipeConfigs)
		{
			w.Write(recipeConfig.Key);
			recipeConfig.Value.Export(w);
		}
		int count2 = itemConfigs.Count;
		w.Write(count2);
		foreach (KeyValuePair<int, ItemConfig> itemConfig in itemConfigs)
		{
			w.Write(itemConfig.Key);
			itemConfig.Value.Export(w);
		}
		w.Write(globalIncLevel);
		w.Write(globalIsInc);
		w.Write(globalAssemblerIdByType.Count);
		foreach (KeyValuePair<int, int> item in globalAssemblerIdByType)
		{
			w.Write(item.Key);
			w.Write(item.Value);
		}
		w.Write(globalUseIA);
		w.Write(globalIAType);
		w.Write(bluebuff);
		w.Write(energyBurst);
		w.Write(dirac);
		w.Write(inferior);
		w.Write(customizeIncMilli);
		w.Write(customizeAccMilli);
		w.Write(incMilliOverride);
		w.Write(accMilliOverride);
		w.Write(finishedRecipes.Count);
		foreach (KeyValuePair<int, int> finishedRecipe in finishedRecipes)
		{
			w.Write(finishedRecipe.Key);
			w.Write(finishedRecipe.Value);
		}
		w.Write(roundUpAssemgblerNum);
		w.Write(solveProliferators);
		w.Write(bpRowCount);
		w.Write(bpResourceCoater);
		w.Write(bpProductCoater);
		w.Write(bpStationProlifSlot);
		w.Write(bpBeltHighest);
		w.Write(bpBeltTechLimit);
		w.Write(bpSorterHighest);
		w.Write(bpSorterTechLimit);
		w.Write(bpStackSetting);
		w.Write(bpConnectBlackboxCoater);
	}

	public void Import(BinaryReader r)
	{
		recipeConfigs.Clear();
		itemConfigs.Clear();
		globalAssemblerIdByType.Clear();
		finishedRecipes.Clear();
		int num = r.ReadInt32();
		for (int i = 0; i < num; i++)
		{
			int key = r.ReadInt32();
			RecipeConfig value = new RecipeConfig(r);
			recipeConfigs[key] = value;
		}
		num = r.ReadInt32();
		for (int j = 0; j < num; j++)
		{
			int num2 = r.ReadInt32();
			ItemConfig itemConfig = new ItemConfig(num2);
			itemConfig.Import(r);
			itemConfigs[num2] = itemConfig;
		}
		globalIncLevel = r.ReadInt32();
		globalIsInc = r.ReadByte() > 0;
		num = r.ReadInt32();
		for (int k = 0; k < num; k++)
		{
			int key2 = r.ReadInt32();
			int value2 = r.ReadInt32();
			globalAssemblerIdByType[key2] = value2;
		}
		globalUseIA = r.ReadByte() > 0;
		globalIAType = r.ReadInt32();
		bluebuff = r.ReadByte() > 0;
		energyBurst = r.ReadByte() > 0;
		dirac = r.ReadByte() > 0;
		inferior = r.ReadByte() > 0;
		customizeIncMilli = r.ReadByte() > 0;
		customizeAccMilli = r.ReadByte() > 0;
		incMilliOverride = r.ReadDouble();
		accMilliOverride = r.ReadDouble();
		num = r.ReadInt32();
		for (int l = 0; l < num; l++)
		{
			int key3 = r.ReadInt32();
			int value3 = r.ReadInt32();
			finishedRecipes[key3] = value3;
		}
		roundUpAssemgblerNum = r.ReadByte() > 0;
		solveProliferators = r.ReadByte() > 0;
		bpRowCount = r.ReadInt32();
		bpResourceCoater = r.ReadInt32();
		bpProductCoater = r.ReadByte() > 0;
		bpStationProlifSlot = r.ReadByte() > 0;
		bpBeltHighest = r.ReadByte() > 0;
		bpBeltTechLimit = r.ReadByte() > 0;
		bpSorterHighest = r.ReadByte() > 0;
		bpSorterTechLimit = r.ReadByte() > 0;
		bpStackSetting = r.ReadInt32();
		bpConnectBlackboxCoater = r.ReadByte() > 0;
	}
}
