using System;
using System.Collections.Generic;
using System.Linq;
using DSPCalculator.Compatibility;
using UnityEngine;

namespace DSPCalculator.Logic;

public class RecipeInfo
{
	public int ID;

	public double count;

	public NormalizedRecipe recipeNorm;

	public Dictionary<int, int> productIndices;

	public Dictionary<int, int> resourceIndices;

	public UserPreference userPreference;

	public int incLevel
	{
		get
		{
			if (IASpecializationType == 2 && GetSpecBuffLevel() > 0)
			{
				return 4;
			}
			if (useIA && !isInc)
			{
				return 0;
			}
			if (userPreference.recipeConfigs.ContainsKey(ID) && userPreference.recipeConfigs[ID].incLevel >= 0)
			{
				RecipeConfig recipeConfig = userPreference.recipeConfigs[ID];
				return recipeConfig.incLevel;
			}
			return userPreference.globalIncLevel;
		}
	}

	public bool isInc
	{
		get
		{
			if (useIA)
			{
				return canInc;
			}
			if (userPreference.recipeConfigs.ContainsKey(ID) && userPreference.recipeConfigs[ID].forceIncMode >= 0)
			{
				return userPreference.recipeConfigs[ID].forceIncMode == 1;
			}
			return recipeNorm.productive && userPreference.globalIsInc;
		}
	}

	public bool canInc
	{
		get
		{
			if (useIA && GetSpecBuffLevel() > 0)
			{
				return true;
			}
			return recipeNorm.productive;
		}
	}

	public int IASpecializationType
	{
		get
		{
			if (!CompatManager.MMS)
			{
				return -1;
			}
			bool flag = false;
			if (userPreference.recipeConfigs.ContainsKey(ID))
			{
				if (userPreference.recipeConfigs[ID].forceUseIA)
				{
					if (userPreference.recipeConfigs[ID].IAType >= 0)
					{
						return userPreference.recipeConfigs[ID].IAType;
					}
					return userPreference.globalIAType;
				}
				if (userPreference.recipeConfigs[ID].assemblerItemId <= 0)
				{
					if (userPreference.globalUseIA)
					{
						if (userPreference.recipeConfigs[ID].IAType >= 0)
						{
							return userPreference.recipeConfigs[ID].IAType;
						}
						return userPreference.globalIAType;
					}
					return -1;
				}
				return -1;
			}
			if (userPreference.globalUseIA)
			{
				return userPreference.globalIAType;
			}
			return -1;
		}
	}

	public bool useIA => IASpecializationType >= 0;

	public int assemblerItemId
	{
		get
		{
			if (userPreference.recipeConfigs.ContainsKey(ID) && userPreference.recipeConfigs[ID].assemblerItemId > 0)
			{
				return userPreference.recipeConfigs[ID].assemblerItemId;
			}
			if (userPreference.globalAssemblerIdByType.ContainsKey(recipeNorm.type) && userPreference.globalAssemblerIdByType[recipeNorm.type] > 0)
			{
				return userPreference.globalAssemblerIdByType[recipeNorm.type];
			}
			if (CalcDB.assemblerListByType.ContainsKey(recipeNorm.type) && CalcDB.assemblerListByType[recipeNorm.type].Count > 0)
			{
				return CalcDB.assemblerListByType[recipeNorm.type][0].ID;
			}
			Debug.LogError("DSPCalculator get assemblerId Error. no such aseembler that could match the recipe.");
			return -1;
		}
	}

	public double assemblerCount
	{
		get
		{
			if (useIA)
			{
				return 1.0;
			}
			AssemblerData assemblerData = CalcDB.assemblerDict[assemblerItemId];
			double num = count / assemblerData.speed / 60.0;
			if (!isInc && incLevel >= 0 && incLevel < Cargo.accTableMilli.Length)
			{
				num /= 1.0 + Utils.GetAccMilli(incLevel, userPreference);
			}
			return num;
		}
	}

	public double bonusFactor
	{
		get
		{
			if (assemblerItemId == CalcDB.dfSmelterId && CompatManager.GB && !useIA)
			{
				return 2.0;
			}
			return 1.0;
		}
	}

	public double bonusInc
	{
		get
		{
			if (CompatManager.MMS && useIA)
			{
				int iASpecializationType = IASpecializationType;
				int specBuffLevel = GetSpecBuffLevel();
				if (specBuffLevel > 0)
				{
					switch (iASpecializationType)
					{
					case 3:
						return 0.25;
					case 4:
						return 0.25 * (double)specBuffLevel;
					case 5:
						return 0.25 * (double)specBuffLevel;
					}
				}
			}
			return 0.0;
		}
	}

	public double displayCount => count / 60.0;

	public RecipeInfo(NormalizedRecipe recipe, UserPreference preference)
	{
		ID = recipe.ID;
		recipeNorm = recipe;
		userPreference = preference;
		productIndices = new Dictionary<int, int>();
		resourceIndices = new Dictionary<int, int>();
		count = 0.0;
		for (int i = 0; i < recipe.products.Length; i++)
		{
			if (recipe.productCounts[i] > 0)
			{
				int key = recipe.products[i];
				productIndices[key] = i;
			}
		}
		for (int j = 0; j < recipe.resources.Length; j++)
		{
			if (recipe.resourceCounts[j] > 0)
			{
				int key2 = recipe.resources[j];
				resourceIndices[key2] = j;
			}
		}
	}

	public double AddCountByOutputNeed(int itemId, double needSpeed)
	{
		double num = CalcCountByOutputSpeed(itemId, needSpeed);
		count += num;
		return num;
	}

	public double CalcOutputDiracInc(int itemId)
	{
		if (userPreference.dirac && recipeNorm.type == 5 && recipeNorm.products[0] == 1122 && recipeNorm.products.Length > 1)
		{
			return 0.5;
		}
		return 0.0;
	}

	public double CalcCountByOutputSpeed(int itemId, double speed)
	{
		if (productIndices.ContainsKey(itemId))
		{
			if (userPreference.inferior && itemId == 1501 && recipeNorm.products[0] == 1501 && !useIA)
			{
				speed = speed * (double)recipeNorm.productCounts[0] / (double)(recipeNorm.productCounts[0] + 1);
			}
			int num = productIndices[itemId];
			double num2 = speed / (double)recipeNorm.productCounts[num] * recipeNorm.time;
			if (isInc && incLevel >= 0 && incLevel < Cargo.incTableMilli.Length)
			{
				return num2 / (1.0 + Utils.GetIncMilli(incLevel, userPreference) + CalcOutputDiracInc(itemId) + bonusInc) / bonusFactor;
			}
			return num2 / (1.0 + CalcOutputDiracInc(itemId) + bonusInc) / bonusFactor;
		}
		return 0.0;
	}

	public double GetOutputSpeedByChangedCount(int itemId, double changedCount)
	{
		if (productIndices.ContainsKey(itemId))
		{
			double num = 1.0 * bonusFactor;
			if (userPreference.inferior && itemId == 1501 && recipeNorm.products[0] == 1501 && !useIA)
			{
				num = num * (double)(recipeNorm.productCounts[0] + 1) / (double)recipeNorm.productCounts[0];
			}
			int num2 = productIndices[itemId];
			if (isInc && incLevel >= 0 && incLevel <= Cargo.incTableMilli.Length)
			{
				return num * changedCount * (double)recipeNorm.productCounts[num2] / recipeNorm.time * (1.0 + Utils.GetIncMilli(incLevel, userPreference) + CalcOutputDiracInc(itemId) + bonusInc);
			}
			return num * changedCount * (double)recipeNorm.productCounts[num2] / recipeNorm.time * (1.0 + CalcOutputDiracInc(itemId) + bonusInc);
		}
		Debug.LogWarning($"获取配方输出数量时，试图用非此配方{recipeNorm.oriProto.name}的产物{itemId}计算，先前路径可能存在逻辑错误。");
		return 0.0;
	}

	public double GetOutputSpeedOriProto(int index, double changedCount)
	{
		int num = recipeNorm.oriProto.Results[index];
		double num2 = 1.0 * bonusFactor;
		if (userPreference.inferior && num == 1501 && recipeNorm.oriProto.Results[0] == 1501 && !useIA)
		{
			num2 = num2 * (double)(recipeNorm.oriProto.ResultCounts[0] + 1) / (double)recipeNorm.oriProto.ResultCounts[0];
		}
		if (isInc && incLevel >= 0 && incLevel <= Cargo.incTableMilli.Length)
		{
			return num2 * changedCount * (double)recipeNorm.oriProto.ResultCounts[index] / recipeNorm.time * (1.0 + Utils.GetIncMilli(incLevel, userPreference) + CalcOutputDiracInc(num) + bonusInc);
		}
		return num2 * changedCount * (double)recipeNorm.oriProto.ResultCounts[index] / recipeNorm.time * (1.0 + CalcOutputDiracInc(num) + bonusInc);
	}

	public double GetInputSpeedByChangedCount(int itemId, double changedCount)
	{
		double num = 0.0;
		if (resourceIndices.ContainsKey(itemId))
		{
			int num2 = resourceIndices[itemId];
			num = changedCount * (double)recipeNorm.resourceCounts[num2] / recipeNorm.time;
		}
		else
		{
			Debug.LogWarning($"获取配方输入数量时，试图用非此配方{recipeNorm.oriProto.name}的原材料{itemId}计算，先前路径可能存在逻辑错误。");
		}
		if (userPreference.bluebuff && (recipeNorm.type == 4 || recipeNorm.type == 9 || recipeNorm.type == 10 || recipeNorm.type == 12 || useIA) && recipeNorm.resources.Length > 1 && recipeNorm.products[0] != 1803 && recipeNorm.products[0] != 6006 && recipeNorm.resources[0] == itemId)
		{
			double num3 = 0.0;
			num3 = ((!isInc || incLevel < 0 || incLevel > Cargo.incTableMilli.Length) ? (changedCount * (double)recipeNorm.oriProto.ResultCounts[0] / recipeNorm.time) : (changedCount * (double)recipeNorm.oriProto.ResultCounts[0] / recipeNorm.time * (1.0 + Utils.GetIncMilli(incLevel, userPreference) + bonusInc)));
			num -= num3;
		}
		bool energyBurst = userPreference.energyBurst;
		int num4 = -1;
		int num5 = recipeNorm.products[0];
		if (energyBurst)
		{
			if ((num5 >= 9488 && num5 <= 9490) || (num5 == 1503 && CompatManager.GB))
			{
				num4 = 2;
			}
			else if (num5 == 9491 || num5 == 9492 || num5 == 9510 || num5 == 1503)
			{
				num4 = 1;
			}
			if (num4 > 0 && num4 < recipeNorm.resources.Length && resourceIndices.ContainsKey(itemId) && num4 == resourceIndices[itemId])
			{
				double num6 = 0.0;
				num6 = ((!isInc || incLevel < 0 || incLevel > Cargo.incTableMilli.Length) ? (changedCount * (double)recipeNorm.oriProto.ResultCounts[0] / recipeNorm.time) : (changedCount * (double)recipeNorm.oriProto.ResultCounts[0] / recipeNorm.time * (1.0 + Utils.GetIncMilli(incLevel, userPreference) + bonusInc)));
				num -= 2.0 * num6;
			}
		}
		if (num < 0.0 && changedCount >= 0.0)
		{
			num = 0.0;
		}
		else if (num > 0.0 && changedCount < 0.0)
		{
			num = 0.0;
		}
		return num;
	}

	public double GetInputSpeedOriProto(int index, double changedCount)
	{
		int num = recipeNorm.oriProto.Items[index];
		double num2 = 0.0;
		num2 = changedCount * (double)recipeNorm.oriProto.ItemCounts[index] / recipeNorm.time;
		if (userPreference.bluebuff && (recipeNorm.type == 4 || recipeNorm.type == 9 || recipeNorm.type == 10 || recipeNorm.type == 12 || useIA) && recipeNorm.resources.Length > 1 && recipeNorm.products[0] != 1803 && recipeNorm.products[0] != 6006 && recipeNorm.resources[0] == num)
		{
			double num3 = 0.0;
			num3 = ((!isInc || incLevel < 0 || incLevel > Cargo.incTableMilli.Length) ? (changedCount * (double)recipeNorm.oriProto.ResultCounts[0] / recipeNorm.time) : (changedCount * (double)recipeNorm.oriProto.ResultCounts[0] / recipeNorm.time * (1.0 + Utils.GetIncMilli(incLevel, userPreference) + bonusInc)));
			num2 -= num3;
		}
		bool energyBurst = userPreference.energyBurst;
		int num4 = -1;
		int num5 = recipeNorm.products[0];
		if (energyBurst)
		{
			if ((num5 >= 9488 && num5 <= 9490) || (num5 == 1503 && CompatManager.GB))
			{
				num4 = 2;
			}
			else if (num5 == 9491 || num5 == 9492 || num5 == 9510 || num5 == 1503)
			{
				num4 = 1;
			}
			if (num4 > 0 && num4 < recipeNorm.resources.Length && resourceIndices.ContainsKey(num) && num4 == resourceIndices[num])
			{
				double num6 = 0.0;
				num6 = ((!isInc || incLevel < 0 || incLevel > Cargo.incTableMilli.Length) ? (changedCount * (double)recipeNorm.oriProto.ResultCounts[0] / recipeNorm.time) : (changedCount * (double)recipeNorm.oriProto.ResultCounts[0] / recipeNorm.time * (1.0 + Utils.GetIncMilli(incLevel, userPreference) + bonusInc)));
				num2 -= 2.0 * num6;
			}
		}
		if (num2 < 0.0 && changedCount >= 0.0)
		{
			Debug.LogWarning($"GetInputSpeedByChangedCount({num}, {changedCount})试图在changedCount非负时，返回负数");
			num2 = 0.0;
		}
		else if (num2 > 0.0 && changedCount < 0.0)
		{
			Debug.LogWarning($"GetInputSpeedByChangedCount({num}, {changedCount})试图在changedCount非正时，返回正数");
			num2 = 0.0;
		}
		if (num2 == 0.0)
		{
			num2 = 1E-05;
		}
		return num2;
	}

	public double GetOutputSpeedByItemId(int itemId)
	{
		return GetOutputSpeedByChangedCount(itemId, count);
	}

	public double GetTotalEnergyConsumption()
	{
		double num;
		if (useIA)
		{
			num = 0.0;
		}
		else
		{
			double num2 = 1.0;
			if (incLevel >= 0 && incLevel < Cargo.powerTableRatio.Length)
			{
				num2 = Utils.GetPowerRatio(incLevel, userPreference);
			}
			int num3 = (int)assemblerCount;
			double num4 = assemblerCount - (double)num3;
			double num5 = 0.0;
			if (num4 > 0.0010000000474974513)
			{
				num5 = 1.0 - num4;
			}
			AssemblerData assemblerData = CalcDB.assemblerDict[assemblerItemId];
			num = ((double)num3 + num4) * assemblerData.workEnergyW * num2 + num5 * assemblerData.idleEnergyW;
		}
		double existing = num;
		return RecipeUpdates.ExtraPower(this, existing);
	}

	public void GetProliferatorUsed(out int proliferatorId, out double proliferatorCount)
	{
		if (incLevel == 0 || !CalcDB.proliferatorAbilityToId.ContainsKey(incLevel))
		{
			proliferatorId = 0;
			proliferatorCount = 0.0;
		}
		else
		{
			proliferatorId = CalcDB.proliferatorAbilityToId[incLevel];
			int hpMax = LDB.items.Select(proliferatorId).HpMax;
			RecipeProto oriProto = recipeNorm.oriProto;
			double num = 0.0;
			for (int i = 0; i < oriProto.ItemCounts.Length; i++)
			{
				num += (double)oriProto.ItemCounts[i];
			}
			bool flag = userPreference.bluebuff && (recipeNorm.type == 4 || recipeNorm.type == 9 || recipeNorm.type == 10 || recipeNorm.type == 12 || useIA) && recipeNorm.resources.Length > 1 && recipeNorm.products[0] != 1803 && recipeNorm.products[0] != 6006;
			double num2 = 0.0;
			if (flag)
			{
				num2 = ((!isInc || incLevel < 0 || incLevel > Cargo.incTableMilli.Length) ? (num2 + (double)Math.Min(recipeNorm.oriProto.ResultCounts[0], recipeNorm.oriProto.ItemCounts[0])) : (num2 + Math.Min((double)recipeNorm.oriProto.ResultCounts[0] * (1.0 + Utils.GetIncMilli(incLevel, userPreference)), recipeNorm.oriProto.ItemCounts[0])));
			}
			bool energyBurst = userPreference.energyBurst;
			int num3 = -1;
			int num4 = recipeNorm.products[0];
			if (energyBurst)
			{
				if ((num4 >= 9488 && num4 <= 9490) || (num4 == 1503 && CompatManager.GB))
				{
					num3 = 2;
				}
				else if (num4 == 9491 || num4 == 9492 || num4 == 9510 || num4 == 1503)
				{
					num3 = 1;
				}
				if (num3 > 0 && num3 < recipeNorm.resources.Length)
				{
					double num5 = 0.0;
					num2 = ((!isInc || incLevel < 0 || incLevel > Cargo.incTableMilli.Length) ? (num2 + (double)Math.Min(2 * recipeNorm.oriProto.ResultCounts[0], recipeNorm.oriProto.ItemCounts[num3])) : (num2 + Math.Min((double)(2 * recipeNorm.oriProto.ResultCounts[0]) * (1.0 + Utils.GetIncMilli(incLevel, userPreference)), recipeNorm.oriProto.ItemCounts[num3])));
				}
			}
			proliferatorCount = 1.0 * count / recipeNorm.time * (num - num2) / (double)hpMax;
			if (IASpecializationType == 2 && GetSpecBuffLevel() > 0)
			{
				proliferatorId = 0;
				proliferatorCount = 0.0;
			}
		}
		proliferatorCount = RecipeUpdates.FractionatorSpray(this, proliferatorCount);
	}

	public int GetSpecBuffLevel()
	{
		if (CompatManager.MMS && IASpecializationType > 0)
		{
			int iASpecializationType = IASpecializationType;
			int result = 0;
			ERecipeType type = recipeNorm.oriProto.Type;
			if (iASpecializationType == 1 && type == ERecipeType.Smelt)
			{
				result = 1;
			}
			if (iASpecializationType == 2 && (type == ERecipeType.Chemical || type == ERecipeType.Refine || type == (ERecipeType)16 || recipeNorm.products.Contains(1141) || recipeNorm.products.Contains(1142) || recipeNorm.products.Contains(1143)))
			{
				result = 1;
			}
			if (iASpecializationType == 3)
			{
				bool flag = false;
				for (int i = 0; i < recipeNorm.resources.Length; i++)
				{
					if (recipeNorm.resources[i] == 1121 || recipeNorm.resources[i] == 1122)
					{
						flag = true;
						break;
					}
				}
				if (!flag)
				{
					for (int j = 0; j < recipeNorm.products.Length; j++)
					{
						if (recipeNorm.products[j] == 1121 || recipeNorm.products[j] == 1122)
						{
							flag = true;
							break;
						}
					}
				}
				if (flag)
				{
					result = 1;
				}
			}
			if (iASpecializationType == 4)
			{
				int num = 0;
				for (int k = 0; k < recipeNorm.products.Length; k++)
				{
					if (recipeNorm.products[k] == 1303 || recipeNorm.products[k] == 1305 || recipeNorm.products[k] == 9486)
					{
						num = 2;
						break;
					}
				}
				if (num <= 0)
				{
					for (int l = 0; l < recipeNorm.resources.Length; l++)
					{
						if (recipeNorm.resources[l] == 1303 || recipeNorm.resources[l] == 1305 || recipeNorm.resources[l] == 9486)
						{
							num = 1;
							break;
						}
					}
				}
				if (num > 0)
				{
					result = num;
				}
			}
			if (iASpecializationType == 5)
			{
				int num2 = 0;
				for (int m = 0; m < recipeNorm.products.Length; m++)
				{
					int id = recipeNorm.products[m];
					ItemProto itemProto = LDB.items.Select(id);
					if (itemProto.isAmmo)
					{
						num2 = 4;
						break;
					}
					if (itemProto.Type == EItemType.Defense || itemProto.Type == EItemType.Turret || itemProto.isCraft)
					{
						num2 = 2;
					}
				}
				result = num2;
			}
			return result;
		}
		return 0;
	}

	public long GetIAInputCount()
	{
		double num = 1.0;
		if (IASpecializationType == 1 && GetSpecBuffLevel() > 0)
		{
			num = 3.0;
		}
		else if (IASpecializationType == 2 && GetSpecBuffLevel() > 0)
		{
			num = 2.0;
		}
		return (long)Math.Ceiling(count / recipeNorm.time * (double)recipeNorm.oriProto.ResultCounts[0] / num);
	}
}
