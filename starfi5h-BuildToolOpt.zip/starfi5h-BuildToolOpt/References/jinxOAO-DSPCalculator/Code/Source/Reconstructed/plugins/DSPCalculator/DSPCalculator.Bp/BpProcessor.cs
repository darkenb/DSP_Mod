using System;
using System.Collections.Generic;
using System.Linq;
using DSPCalculator.Compatibility;
using DSPCalculator.Logic;
using UnityEngine;

namespace DSPCalculator.Bp;

public class BpProcessor : BpBuildingList
{
	public static bool enabled = true;

	public RecipeInfo recipeInfo;

	public bool prePocessed;

	public SolutionTree solution;

	public int supportAssemblerCount;

	public double bpCountToSatisfy;

	public List<BpCargoInfo> cargoInfoDescending;

	public List<BpCargoInfo> cargoInfoOrderByNorm;

	public List<BpCargoBeltPos> cargoBeltPoses;

	public bool doubleRow;

	public int cargoCount;

	public bool share3Belts;

	public int bpPrefabId;

	public List<int> insufficientSorterItems;

	public BlueprintData blueprintData;

	public BpProcessorGB processorGB;

	public Dictionary<int, BlueprintBuilding> inputBelts;

	public Dictionary<int, BlueprintBuilding> outputBelts;

	public bool canGenerate => !recipeInfo.useIA && ((BpDB.assemblerInfos.ContainsKey(recipeInfo.assemblerItemId) && cargoCount <= 6) || isGBMega || bpPrefabId > 0);

	public bool isGBMega => CompatManager.GB && BpDB.GBMegas.ContainsKey(recipeInfo.assemblerItemId) && cargoCount <= 6;

	public bool resourceGenCoater => (recipeInfo.incLevel > 0 && solution.userPreference.bpResourceCoater >= 0) || solution.userPreference.bpResourceCoater == 1;

	public bool productGenCoater => solution.userPreference.bpProductCoater;

	public bool genCoater => resourceGenCoater || productGenCoater;

	public bool PLSProvideProliferator => genCoater && solution.userPreference.bpStationProlifSlot;

	public int width => (blueprintData != null) ? blueprintData.areas[0].width : 0;

	public int height => (blueprintData != null) ? blueprintData.areas[0].height : 0;

	public bool onlyShare2Belts => share3Belts && cargoInfoOrderByNorm[5] == null;

	public BpProcessor(RecipeInfo recipeInfo, SolutionTree solution)
	{
		this.solution = solution;
		this.recipeInfo = recipeInfo;
		cargoCount = recipeInfo.recipeNorm.oriProto.Items.Length + recipeInfo.recipeNorm.oriProto.Results.Length;
		doubleRow = solution.userPreference.bpRowCount == 2 && cargoCount < 6;
		insufficientSorterItems = new List<int>();
		share3Belts = false;
		bpPrefabId = 0;
		prePocessed = false;
	}

	public BpProcessor(RecipeInfo recipeInfo, SolutionTree solution, int forceRowCount)
	{
		this.solution = solution;
		this.recipeInfo = recipeInfo;
		cargoCount = recipeInfo.recipeNorm.oriProto.Items.Length + recipeInfo.recipeNorm.oriProto.Results.Length;
		doubleRow = forceRowCount == 2 && cargoCount < 6;
		insufficientSorterItems = new List<int>();
		share3Belts = false;
		bpPrefabId = 0;
		prePocessed = false;
	}

	public void PreProcess()
	{
		if (prePocessed)
		{
			return;
		}
		prePocessed = true;
		if (isVanilla6006())
		{
			bpPrefabId = 1;
		}
		if (!canGenerate || bpPrefabId > 0)
		{
			return;
		}
		if (isGBMega)
		{
			processorGB = new BpProcessorGB(this);
			processorGB.PreProcess();
			return;
		}
		InitCargoInfos();
		cargoInfoOrderByNorm = new List<BpCargoInfo> { null, null, null, null, null, null };
		if (doubleRow)
		{
			if (cargoCount < 2)
			{
				Debug.LogError("出现异常，一个配方处理的货物种类小于2种");
				return;
			}
			cargoInfoOrderByNorm[0] = cargoInfoDescending[0];
			if (cargoCount == 2)
			{
				if (cargoInfoDescending[0].maxSorterDistance >= 2 && cargoInfoDescending[1].maxSorterDistance >= 2)
				{
					share3Belts = true;
					cargoInfoOrderByNorm[2] = cargoInfoDescending[1];
				}
				else
				{
					share3Belts = false;
					if (cargoInfoDescending[1].maxSupportAssemblerCount >= 2 * cargoInfoDescending[0].maxSupportAssemblerCount && cargoInfoDescending[1].maxSorterDistance >= 2)
					{
						cargoInfoOrderByNorm[2] = cargoInfoDescending[1];
					}
					else if ((double)cargoInfoDescending[1].maxSupportAssemblerCount >= recipeInfo.assemblerCount && solution.sortersAvailable.Last().grade >= 4)
					{
						cargoInfoOrderByNorm[2] = cargoInfoDescending[1];
					}
					else
					{
						cargoInfoOrderByNorm[1] = cargoInfoDescending[1];
					}
				}
			}
			else if (cargoCount == 3)
			{
				if (cargoInfoDescending[0].maxSorterDistance >= 2 && cargoInfoDescending[1].maxSorterDistance >= 3 && cargoInfoDescending[2].maxSorterDistance >= 3 && BpDB.assemblerInfos[recipeInfo.assemblerItemId].DragDistanceX >= 4)
				{
					share3Belts = true;
					cargoInfoOrderByNorm[0] = cargoInfoDescending[1];
					cargoInfoOrderByNorm[2] = cargoInfoDescending[0];
					cargoInfoOrderByNorm[5] = cargoInfoDescending[2];
				}
				else
				{
					share3Belts = false;
					cargoInfoOrderByNorm[1] = cargoInfoDescending[1];
					cargoInfoOrderByNorm[2] = cargoInfoDescending[2];
				}
			}
			else if (cargoCount == 4)
			{
				if (cargoInfoDescending[1].maxSorterDistance >= 2 && cargoInfoDescending[2].maxSorterDistance >= 3 && cargoInfoDescending[3].maxSorterDistance >= 3 && BpDB.assemblerInfos[recipeInfo.assemblerItemId].DragDistanceX >= 4)
				{
					share3Belts = true;
					cargoInfoOrderByNorm[0] = cargoInfoDescending[2];
					cargoInfoOrderByNorm[2] = cargoInfoDescending[1];
					cargoInfoOrderByNorm[5] = cargoInfoDescending[3];
					cargoInfoOrderByNorm[1] = cargoInfoDescending[0];
				}
				else
				{
					share3Belts = false;
					cargoInfoOrderByNorm[1] = cargoInfoDescending[1];
					cargoInfoOrderByNorm[2] = cargoInfoDescending[3];
					cargoInfoOrderByNorm[3] = cargoInfoDescending[2];
				}
			}
			else
			{
				if (cargoCount != 5)
				{
					Debug.LogError("不应出现的情况，确定使用双行却发现货物数量超过5");
					return;
				}
				if (cargoInfoDescending[1].maxSorterDistance >= 2 && cargoInfoDescending[2].maxSorterDistance >= 2 && cargoInfoDescending[3].maxSorterDistance >= 3 && cargoInfoDescending[4].maxSorterDistance >= 3 && BpDB.assemblerInfos[recipeInfo.assemblerItemId].DragDistanceX >= 4)
				{
					share3Belts = true;
					cargoInfoOrderByNorm[1] = cargoInfoDescending[0];
					cargoInfoOrderByNorm[3] = cargoInfoDescending[1];
					cargoInfoOrderByNorm[2] = cargoInfoDescending[2];
					cargoInfoOrderByNorm[0] = cargoInfoDescending[3];
					cargoInfoOrderByNorm[5] = cargoInfoDescending[4];
				}
				else
				{
					share3Belts = false;
					cargoInfoOrderByNorm[1] = cargoInfoDescending[1];
					if (cargoInfoDescending[3].maxSorterDistance >= 3)
					{
						cargoInfoOrderByNorm[2] = cargoInfoDescending[4];
						cargoInfoOrderByNorm[3] = cargoInfoDescending[2];
						cargoInfoOrderByNorm[4] = cargoInfoDescending[3];
					}
					else
					{
						cargoInfoOrderByNorm[2] = cargoInfoDescending[3];
						cargoInfoOrderByNorm[3] = cargoInfoDescending[2];
						cargoInfoOrderByNorm[4] = cargoInfoDescending[4];
					}
				}
			}
		}
		else
		{
			for (int i = 0; i < cargoInfoDescending.Count; i++)
			{
				cargoInfoOrderByNorm[i] = cargoInfoDescending[i];
			}
		}
		supportAssemblerCount = int.MaxValue;
		if (doubleRow)
		{
			for (int j = 0; j < cargoInfoOrderByNorm.Count; j++)
			{
				if (cargoInfoOrderByNorm[j] != null)
				{
					int num;
					switch (j)
					{
					case 0:
					case 5:
						num = (share3Belts ? 1 : 0);
						break;
					default:
						num = 0;
						break;
					case 2:
						num = 1;
						break;
					}
					bool flag = (byte)num != 0;
					supportAssemblerCount = (int)Math.Min(supportAssemblerCount, cargoInfoOrderByNorm[j].maxSupportAssemblerCount * (flag ? 1 : 2));
					if (supportAssemblerCount < 0)
					{
						supportAssemblerCount = int.MaxValue;
					}
				}
			}
		}
		else
		{
			for (int k = 0; k < cargoInfoDescending.Count; k++)
			{
				supportAssemblerCount = (int)Math.Min(supportAssemblerCount, cargoInfoDescending[k].maxSupportAssemblerCount);
				if (supportAssemblerCount < 0)
				{
					supportAssemblerCount = int.MaxValue;
				}
			}
		}
		if ((double)supportAssemblerCount > recipeInfo.assemblerCount)
		{
			supportAssemblerCount = (int)Math.Ceiling(recipeInfo.assemblerCount);
		}
		if (supportAssemblerCount <= 1 && doubleRow)
		{
			doubleRow = false;
		}
		bpCountToSatisfy = recipeInfo.assemblerCount / (double)supportAssemblerCount;
	}

	public void InitCargoInfos()
	{
		RecipeProto oriProto = recipeInfo.recipeNorm.oriProto;
		cargoInfoDescending = new List<BpCargoInfo>();
		bool flag = solution.sortersAvailable.Last().grade >= 4;
		for (int i = 0; i < oriProto.Results.Length; i++)
		{
			BpCargoInfo bpCargoInfo = new BpCargoInfo();
			bpCargoInfo.itemId = oriProto.Results[i];
			bpCargoInfo.index = i;
			bpCargoInfo.isResource = false;
			if (flag)
			{
				bpCargoInfo.beltSpeedRequiredPerAssembler = recipeInfo.GetOutputSpeedOriProto(i, recipeInfo.count) / recipeInfo.assemblerCount / (double)solution.userPreference.bpSorterMk4OutputStack;
			}
			else
			{
				bpCargoInfo.beltSpeedRequiredPerAssembler = recipeInfo.GetOutputSpeedOriProto(i, recipeInfo.count) / recipeInfo.assemblerCount;
			}
			bpCargoInfo.maxSupportAssemblerCount = (long)(solution.beltsAvailable.Last().speedPerMin / bpCargoInfo.beltSpeedRequiredPerAssembler);
			if (flag)
			{
				bpCargoInfo.maxSorterDistance = 3;
			}
			else
			{
				bpCargoInfo.maxSorterDistance = (int)(solution.sortersAvailable.Last().speedPerMin / bpCargoInfo.beltSpeedRequiredPerAssembler);
			}
			if (DSPCalculatorPlugin.developerMode)
			{
				Utils.logger.LogInfo($"item{Utils.GetItemName(bpCargoInfo.itemId)} spd per factory {bpCargoInfo.beltSpeedRequiredPerAssembler} maxC{bpCargoInfo.maxSupportAssemblerCount} sorter max distance{bpCargoInfo.maxSorterDistance}.");
			}
			cargoInfoDescending.Add(bpCargoInfo);
		}
		for (int j = 0; j < oriProto.Items.Length; j++)
		{
			BpCargoInfo bpCargoInfo2 = new BpCargoInfo();
			bpCargoInfo2.itemId = oriProto.Items[j];
			bpCargoInfo2.index = j;
			bpCargoInfo2.isResource = true;
			bpCargoInfo2.beltSpeedRequiredPerAssembler = recipeInfo.GetInputSpeedOriProto(j, recipeInfo.count) / recipeInfo.assemblerCount / (double)solution.userPreference.bpStack;
			bpCargoInfo2.maxSupportAssemblerCount = (long)(solution.beltsAvailable.Last().speedPerMin / bpCargoInfo2.beltSpeedRequiredPerAssembler);
			if (solution.sortersAvailable.Last().grade >= 4)
			{
				bpCargoInfo2.maxSorterDistance = 3;
			}
			else
			{
				bpCargoInfo2.maxSorterDistance = (int)(solution.sortersAvailable.Last().speedPerMin / bpCargoInfo2.beltSpeedRequiredPerAssembler);
			}
			if (DSPCalculatorPlugin.developerMode)
			{
				Utils.logger.LogInfo($"item{Utils.GetItemName(bpCargoInfo2.itemId)} spd per factory{bpCargoInfo2.beltSpeedRequiredPerAssembler} maxC{bpCargoInfo2.maxSupportAssemblerCount} sorter max distance{bpCargoInfo2.maxSorterDistance}.");
			}
			cargoInfoDescending.Add(bpCargoInfo2);
		}
		cargoInfoDescending = cargoInfoDescending.OrderByDescending((BpCargoInfo x) => x.beltSpeedRequiredPerAssembler).ToList();
	}

	public bool GenerateBlueprint(int genLevel)
	{
		if (bpPrefabId == 1)
		{
			blueprintData = BpBuilder.CreateEmpty();
			if (blueprintData.FromBase64String(BpPrefabs.universeMatrix) == BlueprintDataIOError.OK)
			{
				if (recipeInfo.assemblerItemId == 2901)
				{
					short modelIndex = (short)LDB.items.Select(2901).prefabDesc.modelIndex;
					int num = blueprintData.buildings.Length;
					for (int i = 0; i < num; i++)
					{
						if (blueprintData.buildings[i].itemId == 2902)
						{
							blueprintData.buildings[i].itemId = 2901;
							blueprintData.buildings[i].modelIndex = modelIndex;
						}
					}
				}
				return true;
			}
			return false;
		}
		if (!canGenerate || bpPrefabId > 0)
		{
			return false;
		}
		gridMap = new Dictionary<int, Dictionary<int, int>>();
		buildings = new List<BlueprintBuilding>();
		cargoBeltPoses = new List<BpCargoBeltPos> { null, null, null, null, null, null, null, null, null };
		blueprintData = BpBuilder.CreateEmpty();
		insufficientSorterItems = new List<int>();
		inputBelts = new Dictionary<int, BlueprintBuilding>();
		outputBelts = new Dictionary<int, BlueprintBuilding>();
		if (isGBMega)
		{
			if (processorGB != null)
			{
				return processorGB.GenerateBlueprints(genLevel);
			}
			return false;
		}
		bool isLab = LDB.items.Select(recipeInfo.assemblerItemId).prefabDesc.isLab;
		int num2 = solution.userPreference.labMaxLevel;
		if (num2 > supportAssemblerCount)
		{
			num2 = supportAssemblerCount;
		}
		int num3 = (int)Math.Ceiling((double)supportAssemblerCount * 1.0 / (double)num2);
		if (!isLab)
		{
			num2 = 1;
		}
		int num4 = (doubleRow ? ((int)Math.Ceiling((double)supportAssemblerCount * 1.0 / 2.0)) : supportAssemblerCount);
		int num5 = supportAssemblerCount - num4;
		if (isLab)
		{
			num4 = (doubleRow ? ((int)Math.Ceiling((double)num3 * 1.0 / 2.0)) : num3);
			num5 = num3 - num4;
		}
		int assemblerItemId = recipeInfo.assemblerItemId;
		BpAssemblerBuildingInfo bpAssemblerBuildingInfo = BpDB.assemblerInfos[assemblerItemId];
		List<int> list = new List<int>();
		List<int> list2 = new List<int>();
		bool flag = true;
		int num6 = 0;
		int y = 0;
		if (!isLab)
		{
			for (int j = 0; j < num4; j++)
			{
				list.Add(this.AddAssembler(assemblerItemId, recipeInfo.ID, num6 + bpAssemblerBuildingInfo.DragDistanceX * j, y, 0, bpAssemblerBuildingInfo.defaultYaw, recipeInfo.isInc));
			}
		}
		else
		{
			for (int k = 0; k < num4; k++)
			{
				if (k != num4 - 1)
				{
					list.Add(this.AddLab(assemblerItemId, recipeInfo.ID, num6 + bpAssemblerBuildingInfo.DragDistanceX * k, y, num2, recipeInfo.isInc));
				}
				else
				{
					list.Add(this.AddLab(assemblerItemId, recipeInfo.ID, num6 + bpAssemblerBuildingInfo.DragDistanceX * k, y, supportAssemblerCount - (num3 - 1) * num2, recipeInfo.isInc));
				}
			}
		}
		for (int l = 0; l < cargoInfoOrderByNorm.Count; l++)
		{
			BpCargoInfo bpCargoInfo = cargoInfoOrderByNorm[l];
			if (bpCargoInfo == null)
			{
				continue;
			}
			int num7 = ((l == 2 || ((l == 0 || l == 5) && share3Belts)) ? supportAssemblerCount : num4);
			int num8 = -1;
			if (solution.userPreference.bpBeltHighest)
			{
				num8 = solution.beltsAvailable.Last().itemId;
			}
			else
			{
				for (int m = 0; m < solution.beltsAvailable.Count; m++)
				{
					if (solution.beltsAvailable[m].Satisfy((double)num7 * bpCargoInfo.beltSpeedRequiredPerAssembler))
					{
						num8 = solution.beltsAvailable[m].itemId;
						break;
					}
				}
			}
			if (num8 < 0)
			{
				Utils.logger.LogError("没有找到满足的传送带，这种情况不应该发生");
				return false;
			}
			bpCargoInfo.useBeltItemId = num8;
			int num9 = -1;
			if (solution.userPreference.bpSorterHighest || (solution.sortersAvailable.Last().grade >= 4 && !bpCargoInfo.isResource))
			{
				num9 = solution.sortersAvailable.Last().itemId;
			}
			else
			{
				for (int n = 0; n < solution.sortersAvailable.Count; n++)
				{
					if (solution.sortersAvailable[n].Satisfy(bpCargoInfo.beltSpeedRequiredPerAssembler * (double)((!isLab) ? 1 : num2), l / 2 + 1))
					{
						num9 = solution.sortersAvailable[n].itemId;
						break;
					}
				}
			}
			if (num9 < 0)
			{
				num9 = BpDB.sortersAscending.Last().itemId;
				insufficientSorterItems.Add(bpCargoInfo.itemId);
			}
			bpCargoInfo.useSorterItemId = num9;
			if (solution.userPreference.bpSorterHighest || bpCargoInfo.isResource)
			{
				continue;
			}
			for (int num10 = 0; num10 < solution.sortersAvailable.Count && solution.sortersAvailable[num10].grade < 4; num10++)
			{
				if (!solution.sortersAvailable[num10].Satisfy(bpCargoInfo.beltSpeedRequiredPerAssembler * (double)solution.userPreference.bpSorterMk4OutputStack * (double)((!isLab) ? 1 : num2), l / 2 + 1))
				{
					continue;
				}
				bpCargoInfo.outMinSorterItemId = solution.sortersAvailable[num10].itemId;
				bpCargoInfo.firstNOutSorterNoMk4 = (int)(BpDB.beltInfos[bpCargoInfo.useBeltItemId].speedPerMin / (bpCargoInfo.beltSpeedRequiredPerAssembler * (double)solution.userPreference.bpSorterMk4OutputStack));
				if (!doubleRow)
				{
					break;
				}
				if (share3Belts)
				{
					if (l == 0 || l == 2 || l == 5)
					{
						bpCargoInfo.firstNOutSorterNoMk4 /= 2;
					}
				}
				else if (l == 2)
				{
					bpCargoInfo.firstNOutSorterNoMk4 /= 2;
				}
				break;
			}
		}
		if (genLevel >= 0)
		{
			int beltLeftX = GetBeltLeftX(bpAssemblerBuildingInfo);
			int num11 = bpAssemblerBuildingInfo.slotConnectBeltXPositions.Max() + 1;
			int num12 = (num4 - 1) * bpAssemblerBuildingInfo.DragDistanceX + num11;
			for (int num13 = 0; num13 < cargoInfoOrderByNorm.Count; num13++)
			{
				BpCargoInfo bpCargoInfo2 = cargoInfoOrderByNorm[num13];
				if (bpCargoInfo2 != null)
				{
					int cargoBeltY = GetCargoBeltY(num13, bpAssemblerBuildingInfo, isFirstAssemblerRow: true);
					if (bpCargoInfo2.isResource)
					{
						this.AddBelts(bpCargoInfo2.useBeltItemId, beltLeftX, cargoBeltY, 0f, num12, cargoBeltY, 0f, -1, -1, bpCargoInfo2.itemId);
						SetInputBelt(bpCargoInfo2.itemId, beltLeftX, cargoBeltY);
						SetOutputBelt(bpCargoInfo2.itemId, num12, cargoBeltY);
					}
					else
					{
						this.AddBelts(bpCargoInfo2.useBeltItemId, num12, cargoBeltY, 0f, beltLeftX, cargoBeltY, 0f, -1, -1, 0, bpCargoInfo2.itemId);
						SetInputBelt(bpCargoInfo2.itemId, num12, cargoBeltY);
						SetOutputBelt(bpCargoInfo2.itemId, beltLeftX, cargoBeltY);
					}
					cargoBeltPoses[BpDB.cargoInfoNormIndexToBeltPosIndexMap_FirstRow[num13]] = new BpCargoBeltPos(bpCargoInfo2, beltLeftX, cargoBeltY);
					if ((resourceGenCoater && bpCargoInfo2.isResource) || (productGenCoater && !bpCargoInfo2.isResource))
					{
						this.AddCoater(beltLeftX + BpDB.coaterOffsetX, cargoBeltY);
					}
				}
			}
			for (int num14 = 0; num14 < list.Count; num14++)
			{
				int assemblerIndex = list[num14];
				for (int num15 = 0; num15 < cargoInfoOrderByNorm.Count; num15++)
				{
					BpCargoInfo bpCargoInfo3 = cargoInfoOrderByNorm[num15];
					if (bpCargoInfo3 != null)
					{
						int slot = bpAssemblerBuildingInfo.cargoNormIndex2SlotMap_FirstRow[num15];
						if (!bpCargoInfo3.isResource && list.Count - num14 <= bpCargoInfo3.firstNOutSorterNoMk4 && bpCargoInfo3.outMinSorterItemId > 0)
						{
							this.AssemblerConnectToBelt(assemblerIndex, slot, bpCargoInfo3.outMinSorterItemId, 1 + num15 / 2, bpCargoInfo3.isResource, (!bpCargoInfo3.isResource) ? bpCargoInfo3.itemId : 0, bpCargoInfo3.isResource);
						}
						else
						{
							this.AssemblerConnectToBelt(assemblerIndex, slot, bpCargoInfo3.useSorterItemId, 1 + num15 / 2, bpCargoInfo3.isResource, (!bpCargoInfo3.isResource) ? bpCargoInfo3.itemId : 0, bpCargoInfo3.isResource);
						}
					}
				}
			}
		}
		if (doubleRow)
		{
			int num16 = 1;
			int assemblerY = GetAssemblerY(isFirstAssemblerRow: false, bpAssemblerBuildingInfo);
			if (!isLab)
			{
				for (int num17 = 0; num17 < num5; num17++)
				{
					list2.Add(this.AddAssembler(assemblerItemId, recipeInfo.ID, num16 + bpAssemblerBuildingInfo.DragDistanceX * num17, assemblerY, 0, bpAssemblerBuildingInfo.defaultYaw, recipeInfo.isInc));
				}
			}
			else
			{
				for (int num18 = 0; num18 < num5; num18++)
				{
					list2.Add(this.AddLab(assemblerItemId, recipeInfo.ID, num16 + bpAssemblerBuildingInfo.DragDistanceX * num18, assemblerY, num2, recipeInfo.isInc));
				}
			}
			if (genLevel >= 0)
			{
				int beltLeftX2 = GetBeltLeftX(bpAssemblerBuildingInfo);
				int num19 = bpAssemblerBuildingInfo.slotConnectBeltXPositions.Max() + 1;
				int num20 = (num5 - 1) * bpAssemblerBuildingInfo.DragDistanceX + num19;
				for (int num21 = 0; num21 < cargoInfoOrderByNorm.Count; num21++)
				{
					if (num21 == 2 || (share3Belts && (num21 == 0 || num21 == 5)))
					{
						continue;
					}
					BpCargoInfo bpCargoInfo4 = cargoInfoOrderByNorm[num21];
					if (bpCargoInfo4 == null)
					{
						continue;
					}
					int num22 = GetCargoBeltY(num21, bpAssemblerBuildingInfo, isFirstAssemblerRow: false);
					if (bpCargoInfo4.isResource)
					{
						this.AddBelts(bpCargoInfo4.useBeltItemId, beltLeftX2, num22, 0f, num20, num22, 0f, -1, -1, bpCargoInfo4.itemId);
					}
					else
					{
						this.AddBelts(bpCargoInfo4.useBeltItemId, num20, num22, 0f, beltLeftX2, num22, 0f, -1, -1, 0, bpCargoInfo4.itemId);
					}
					if (num21 == 1 && num22 < 8 && genLevel > 0)
					{
						if (bpCargoInfo4.isResource)
						{
							this.AddBelts(bpCargoInfo4.useBeltItemId, beltLeftX2, 8.1f, 0f, beltLeftX2, num22 + 1, 0f, -1, BpBuilder.GetBuilding(gridMap, beltLeftX2, num22));
						}
						else
						{
							this.AddBelts(bpCargoInfo4.useBeltItemId, beltLeftX2, (float)num22 + 1.1f, 0f, beltLeftX2, 8f, 0f, BpBuilder.GetBuilding(gridMap, beltLeftX2, num22));
						}
						num22 = 8;
					}
					if (num21 == 0 && cargoInfoOrderByNorm[2] == null)
					{
						cargoBeltPoses[4] = new BpCargoBeltPos(bpCargoInfo4, beltLeftX2, num22);
					}
					else if (num21 != 2)
					{
						cargoBeltPoses[BpDB.cargoInfoNormIndexToBeltPosIndexMap_SecondRow[num21]] = new BpCargoBeltPos(bpCargoInfo4, beltLeftX2, num22);
					}
					if ((resourceGenCoater && bpCargoInfo4.isResource) || (productGenCoater && !bpCargoInfo4.isResource))
					{
						this.AddCoater(beltLeftX2 + BpDB.coaterOffsetX, num22);
					}
				}
				for (int num23 = 0; num23 < cargoInfoOrderByNorm.Count; num23++)
				{
					BpCargoInfo bpCargoInfo5 = cargoInfoOrderByNorm[num23];
					if (bpCargoInfo5 == null)
					{
						continue;
					}
					bool isResource = bpCargoInfo5.isResource;
					int itemId = bpCargoInfo5.itemId;
					int num24 = bpCargoInfo5.useSorterItemId;
					int num25 = num23;
					if (share3Belts)
					{
						if (num23 == 0)
						{
							if (cargoInfoOrderByNorm[5] != null)
							{
								num25 = 5;
							}
							else if (cargoInfoOrderByNorm[2] != null)
							{
								num25 = 2;
							}
						}
						else if (num23 == 2 && cargoInfoOrderByNorm[5] == null)
						{
							num25 = 0;
						}
						else if (num23 == 5)
						{
							num25 = 0;
						}
						isResource = cargoInfoOrderByNorm[num25].isResource;
						itemId = cargoInfoOrderByNorm[num25].itemId;
						if (solution.userPreference.bpSorterHighest || (solution.sortersAvailable.Last().grade >= 4 && !isResource))
						{
							num24 = solution.sortersAvailable.Last().itemId;
						}
						else
						{
							int distance = num23 / 2 + 1;
							for (int num26 = 0; num26 < solution.sortersAvailable.Count; num26++)
							{
								if (solution.sortersAvailable[num26].Satisfy(cargoInfoOrderByNorm[num25].beltSpeedRequiredPerAssembler * (double)((!isLab) ? 1 : num2), distance))
								{
									num24 = solution.sortersAvailable[num26].itemId;
									break;
								}
							}
						}
						if (num24 < 0)
						{
							num24 = BpDB.sortersAscending.Last().itemId;
							if (!insufficientSorterItems.Contains(itemId))
							{
								insufficientSorterItems.Add(itemId);
							}
						}
					}
					int slot2 = bpAssemblerBuildingInfo.cargoNormIndex2SlotMap_SecondRow[num23];
					if (share3Belts && onlyShare2Belts)
					{
						switch (num23)
						{
						case 0:
							slot2 = bpAssemblerBuildingInfo.cargoNormIndex2SlotMap_SecondRow[2];
							break;
						case 2:
							slot2 = bpAssemblerBuildingInfo.cargoNormIndex2SlotMap_SecondRow[5];
							break;
						}
					}
					int num27 = -1;
					int num28 = -1;
					if (!solution.userPreference.bpSorterHighest && !isResource)
					{
						for (int num29 = 0; num29 < solution.sortersAvailable.Count && solution.sortersAvailable[num29].grade < 4; num29++)
						{
							if (!solution.sortersAvailable[num29].Satisfy(cargoInfoOrderByNorm[num25].beltSpeedRequiredPerAssembler * (double)solution.userPreference.bpSorterMk4OutputStack * (double)((!isLab) ? 1 : num2), num23 / 2 + 1))
							{
								continue;
							}
							num28 = solution.sortersAvailable[num29].itemId;
							num27 = (int)(BpDB.beltInfos[cargoInfoOrderByNorm[num25].useBeltItemId].speedPerMin / (cargoInfoOrderByNorm[num25].beltSpeedRequiredPerAssembler * (double)solution.userPreference.bpSorterMk4OutputStack));
							if (!doubleRow)
							{
								break;
							}
							if (share3Belts)
							{
								if (num25 == 0 || num25 == 2 || num25 == 5)
								{
									num27 /= 2;
								}
							}
							else if (num25 == 2)
							{
								num27 /= 2;
							}
							break;
						}
					}
					for (int num30 = 0; num30 < list2.Count; num30++)
					{
						int assemblerIndex2 = list2[num30];
						if (!isResource && list.Count - num30 <= num27 && num28 > 0)
						{
							this.AssemblerConnectToBelt(assemblerIndex2, slot2, num28, 1 + num23 / 2, isResource, (!isResource) ? itemId : 0, isResource);
						}
						else
						{
							this.AssemblerConnectToBelt(assemblerIndex2, slot2, num24, 1 + num23 / 2, isResource, (!isResource) ? itemId : 0, isResource);
						}
					}
				}
			}
		}
		if (genLevel > 0)
		{
			GenerateAndConnectPLS();
		}
		if (insufficientSorterItems.Count > 0)
		{
			UIRealtimeTip.Popup("分拣器科技不足警告".Translate());
		}
		PostProcess();
		return true;
	}

	public void GenerateAndConnectPLS()
	{
		PLSs = new List<int>();
		int num = cargoCount;
		if (PLSProvideProliferator && genCoater)
		{
			num++;
		}
		int assemblerItemId = recipeInfo.assemblerItemId;
		BpAssemblerBuildingInfo assemblerInfo = BpDB.assemblerInfos[assemblerItemId];
		GetPLSPos(0, assemblerInfo, out var x, out var y);
		this.AddPLS(x, y);
		GetPLSPos(1, assemblerInfo, out var x2, out var y2);
		if (num > BpDB.PLSMaxStorageKinds)
		{
			this.AddPLS(x2, y2);
		}
		List<int> list = new List<int>
		{
			x2 + 1,
			x,
			x + 1,
			0,
			0,
			0,
			x + 1,
			x,
			x2 + 1
		};
		List<int> list2 = new List<int> { 1, 0, 0, 0, 0, 0, 0, 0, 1 };
		List<int> list3 = new List<int> { 8, 7, 8, 9, 10, 11, 0, 1, 0 };
		if (cargoCount == 6)
		{
			list[0] = x2;
			list[1] = x2 + 1;
			list2[1] = 1;
			list3[0] = 7;
			list3[1] = 8;
		}
		bool flag = false;
		for (int i = 0; i < cargoBeltPoses.Count; i++)
		{
			BpCargoBeltPos bpCargoBeltPos = cargoBeltPoses[i];
			if (bpCargoBeltPos == null)
			{
				continue;
			}
			if (i <= 2 || i >= 6)
			{
				if (bpCargoBeltPos.cargoInfo.isResource)
				{
					this.AddBelts(bpCargoBeltPos.beltId, list[i], bpCargoBeltPos.y, 0f, bpCargoBeltPos.x - 1, bpCargoBeltPos.y, 0f, -1, BpBuilder.GetBuilding(gridMap, bpCargoBeltPos.x, bpCargoBeltPos.y));
				}
				else
				{
					this.AddBelts(bpCargoBeltPos.beltId, bpCargoBeltPos.x - 1, bpCargoBeltPos.y, 0f, list[i], bpCargoBeltPos.y, 0f, BpBuilder.GetBuilding(gridMap, bpCargoBeltPos.x, bpCargoBeltPos.y));
				}
				bpCargoBeltPos.x = list[i];
			}
			if (PLSs.Count > list2[i])
			{
				int pLSBuildingIndex = PLSs[list2[i]];
				if (!this.SetOrGetPLSStorage(pLSBuildingIndex, bpCargoBeltPos.cargoItemId, bpCargoBeltPos.isResource, out var index) && index >= 0)
				{
					flag = true;
				}
				if (index >= 0)
				{
					this.ConnectPLSToBelt(pLSBuildingIndex, list3[i], bpCargoBeltPos.isResource ? index : (-1), BpBuilder.GetBuilding(gridMap, bpCargoBeltPos.x, bpCargoBeltPos.y));
				}
			}
		}
		if (PLSProvideProliferator && genCoater)
		{
			int num2 = GetBeltLeftX(assemblerInfo) + BpDB.coaterOffsetX - 1;
			int num3 = 999;
			int num4 = -999;
			for (int j = 0; j < cargoBeltPoses.Count; j++)
			{
				BpCargoBeltPos bpCargoBeltPos2 = cargoBeltPoses[j];
				if (bpCargoBeltPos2 != null)
				{
					if (bpCargoBeltPos2.y < num3)
					{
						num3 = bpCargoBeltPos2.y;
					}
					if (((bpCargoBeltPos2.isResource && resourceGenCoater) || (!bpCargoBeltPos2.isResource && productGenCoater)) && bpCargoBeltPos2.y > num4)
					{
						num4 = bpCargoBeltPos2.y;
					}
				}
			}
			num3--;
			if (num3 > -2)
			{
				num3 = -2;
			}
			if (num4 > num3)
			{
				this.AddBelts(solution.beltsAvailable.Last().itemId, num2, num3, 0f, num2, num4, 1f);
			}
			int pLSSlot = 6;
			int num5 = 0;
			if (num > 4)
			{
				num5 = 1;
			}
			GetPLSPos(num5, assemblerInfo, out var x3, out var _);
			int num6 = x3 - 1;
			int itemId = 1143;
			this.AddBelts(solution.beltsAvailable.Last().itemId, num6, num3, 0f, num2 - 1, num3, 0f, -1, BpBuilder.GetBuilding(gridMap, num2, num3));
			if (resourceGenCoater && CalcDB.proliferatorAbilityToId.ContainsKey(recipeInfo.incLevel))
			{
				itemId = CalcDB.proliferatorAbilityToId[recipeInfo.incLevel];
			}
			int index2;
			bool flag2 = this.SetOrGetPLSStorage(PLSs[num5], itemId, isNeed: true, out index2);
			if (index2 >= 0)
			{
				this.ConnectPLSToBelt(PLSs[num5], pLSSlot, index2, BpBuilder.GetBuilding(gridMap, num6, num3));
			}
		}
		if (!flag)
		{
			return;
		}
		for (int k = 0; k < recipeInfo.recipeNorm.resourceCounts.Length; k++)
		{
			if (recipeInfo.recipeNorm.resourceCounts[k] > 0)
			{
				continue;
			}
			int num7 = recipeInfo.recipeNorm.resources[k];
			if (!recipeInfo.productIndices.ContainsKey(num7))
			{
				continue;
			}
			int num8 = recipeInfo.productIndices[num7];
			if (recipeInfo.recipeNorm.productCounts[num8] <= 0)
			{
				continue;
			}
			for (int l = 0; l < PLSs.Count; l++)
			{
				int index3 = PLSs[l];
				for (int m = 0; m < BpDB.PLSMaxStorageKinds; m++)
				{
					if (buildings[index3].parameters[m * 6] == num7)
					{
						buildings[index3].parameters[m * 6 + 1] = 1;
					}
				}
			}
		}
		for (int n = 0; n < recipeInfo.recipeNorm.productCounts.Length; n++)
		{
			if (recipeInfo.recipeNorm.productCounts[n] > 0)
			{
				continue;
			}
			int num9 = recipeInfo.recipeNorm.resources[n];
			if (!recipeInfo.resourceIndices.ContainsKey(num9))
			{
				continue;
			}
			int num10 = recipeInfo.resourceIndices[num9];
			if (recipeInfo.recipeNorm.resourceCounts[num10] < 0)
			{
				continue;
			}
			for (int num11 = 0; num11 < PLSs.Count; num11++)
			{
				int index4 = PLSs[num11];
				for (int num12 = 0; num12 < BpDB.PLSMaxStorageKinds; num12++)
				{
					if (buildings[index4].parameters[num12 * 6] == num9)
					{
						buildings[index4].parameters[num12 * 6 + 1] = 2;
					}
				}
			}
		}
	}

	public void PostProcess()
	{
		if (!recipeInfo.useIA)
		{
			float num = 0f;
			float num2 = 0f;
			float val = 0f;
			float num3 = 0f;
			float num4 = 0f;
			float val2 = 0f;
			if (buildings.Count > 0)
			{
				num = Math.Min(buildings[0].localOffset_x, buildings[0].localOffset_x2);
				num3 = Math.Max(buildings[0].localOffset_x, buildings[0].localOffset_x2);
				num2 = Math.Min(buildings[0].localOffset_y, buildings[0].localOffset_y2);
				num4 = Math.Max(buildings[0].localOffset_y, buildings[0].localOffset_y2);
				val = Math.Min(buildings[0].localOffset_z, buildings[0].localOffset_z2);
				val2 = Math.Max(buildings[0].localOffset_z, buildings[0].localOffset_z2);
			}
			for (int i = 1; i < buildings.Count; i++)
			{
				float val3 = Math.Min(buildings[i].localOffset_x, buildings[i].localOffset_x2);
				float val4 = Math.Max(buildings[i].localOffset_x, buildings[i].localOffset_x2);
				float val5 = Math.Min(buildings[i].localOffset_y, buildings[i].localOffset_y2);
				float val6 = Math.Max(buildings[i].localOffset_y, buildings[i].localOffset_y2);
				float val7 = Math.Min(buildings[i].localOffset_z, buildings[i].localOffset_z2);
				float val8 = Math.Max(buildings[i].localOffset_z, buildings[i].localOffset_z2);
				num = Math.Min(val3, num);
				num3 = Math.Max(val4, num3);
				num2 = Math.Min(val5, num2);
				num4 = Math.Max(val6, num4);
				val = Math.Min(val7, val);
				val2 = Math.Max(val8, val2);
			}
			for (int j = 0; j < buildings.Count; j++)
			{
				buildings[j].localOffset_x -= num;
				buildings[j].localOffset_x2 -= num;
				buildings[j].localOffset_y -= num2;
				buildings[j].localOffset_y2 -= num2;
			}
			blueprintData.dragBoxSize_x = (int)Math.Ceiling(num3 - num) + 1;
			blueprintData.dragBoxSize_y = (int)Math.Ceiling(num4 - num2) + 1;
			blueprintData.areas[0].width = blueprintData.dragBoxSize_x;
			blueprintData.areas[0].height = blueprintData.dragBoxSize_y;
			blueprintData.buildings = buildings.ToArray();
		}
	}

	public int GetAssemblerY(bool isFirstAssemblerRow, BpAssemblerBuildingInfo assemblerInfo)
	{
		if (isFirstAssemblerRow)
		{
			return 0;
		}
		int num = assemblerInfo.centerDistanceTop + assemblerInfo.centerDistanceBottom + 1;
		if (cargoInfoOrderByNorm[2] != null && (cargoInfoOrderByNorm[5] != null || !share3Belts))
		{
			num++;
		}
		return num;
	}

	public int GetCargoBeltY(int normIndex, BpAssemblerBuildingInfo assemblerInfo, bool isFirstAssemblerRow)
	{
		int assemblerY = GetAssemblerY(isFirstAssemblerRow, assemblerInfo);
		if (isFirstAssemblerRow)
		{
			switch (normIndex)
			{
			case 0:
				return assemblerY + assemblerInfo.centerDistanceTop;
			case 1:
				return assemblerY - assemblerInfo.centerDistanceBottom;
			case 2:
				return assemblerY + assemblerInfo.centerDistanceTop + 1;
			case 3:
				return assemblerY - assemblerInfo.centerDistanceBottom - 1;
			case 4:
				return assemblerY - assemblerInfo.centerDistanceBottom - 2;
			case 5:
				return assemblerY + assemblerInfo.centerDistanceTop + 2;
			}
		}
		else
		{
			switch (normIndex)
			{
			case 0:
				return assemblerY - assemblerInfo.centerDistanceBottom;
			case 1:
				return assemblerY + assemblerInfo.centerDistanceTop;
			case 2:
				return assemblerY - assemblerInfo.centerDistanceBottom - 1;
			case 3:
				return assemblerY + assemblerInfo.centerDistanceTop + 1;
			case 4:
				return assemblerY + assemblerInfo.centerDistanceTop + 2;
			}
		}
		Debug.LogError("cargoCount数量不符。");
		return 0;
	}

	public void GetPLSPos(int PLSListIndex, BpAssemblerBuildingInfo assemblerInfo, out int x, out int y)
	{
		x = -7 - assemblerInfo.hitboxExtendX - (genCoater ? BpDB.coaterBeltBackwardLen : 0) - PLSListIndex * BpDB.PLSDistance;
		y = GetCargoBeltY(2, assemblerInfo, isFirstAssemblerRow: true);
	}

	public int GetBeltLeftX(BpAssemblerBuildingInfo assemblerInfo)
	{
		int num = assemblerInfo.slotConnectBeltXPositions.Min() - 1;
		if (assemblerInfo.vanillaRecipeType == ERecipeType.Research && !genCoater)
		{
			num--;
		}
		int num2 = BpDB.coaterBeltBackwardLen;
		if (!genCoater)
		{
			num2 = 0;
		}
		return num - num2;
	}

	public bool isVanilla6006()
	{
		RecipeProto oriProto = recipeInfo.recipeNorm.oriProto;
		if (oriProto.Results.Length == 1 && oriProto.Items.Length == 6 && oriProto.Results[0] == 6006 && oriProto.ResultCounts[0] == 1)
		{
			int[] items = oriProto.Items;
			if (items[0] == 6001 && items[1] == 6002 && items[2] == 6003 && items[3] == 6004 && items[4] == 6005 && items[5] == 1122)
			{
				for (int i = 0; i < 6; i++)
				{
					if (oriProto.ItemCounts[i] != 1)
					{
						return false;
					}
				}
				return true;
			}
		}
		return false;
	}

	public bool SetInputBelt(int itemId, int x, int y)
	{
		if (inputBelts == null)
		{
			return false;
		}
		if (inputBelts.ContainsKey(itemId))
		{
			Utils.logger.LogWarning("物料" + LDB.items.Select(itemId).name + "的传送带入口端点被覆盖");
		}
		inputBelts[itemId] = buildings[BpBuilder.GetBuilding(gridMap, x, y)];
		return true;
	}

	public bool SetOutputBelt(int itemId, int x, int y)
	{
		if (outputBelts == null)
		{
			return false;
		}
		if (outputBelts.ContainsKey(itemId))
		{
			Utils.logger.LogWarning("物料" + LDB.items.Select(itemId).name + "的传送带出口端点被覆盖");
		}
		outputBelts[itemId] = buildings[BpBuilder.GetBuilding(gridMap, x, y)];
		return true;
	}
}
