using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Configuration;
using BepInEx.Logging;
using CommonAPI;
using DSPCalculator.Bp;
using DSPCalculator.Compatibility;
using DSPCalculator.Logic;
using DSPCalculator.UI;
using HarmonyLib;
using UnityEngine;

namespace DSPCalculator;

[BepInPlugin("com.GniMaerd.DSPCalculator", "DSPCalculator", "0.5.27")]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.LoShin.GenesisBook", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("Gnimaerd.DSP.plugin.MoreMegaStructure", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("com.ckcz123.DSP_Battle", BepInDependency.DependencyFlags.SoftDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry" })]
[CommonAPISubmoduleDependency(new string[] { "TabSystem" })]
[CommonAPISubmoduleDependency(new string[] { "LocalizationModule" })]
public class DSPCalculatorPlugin : BaseUnityPlugin
{
	public const string NAME = "DSPCalculator";

	public const string GUID = "com.GniMaerd.DSPCalculator";

	public const string VERSION = "0.5.25";

	public const int VERSIONINT = 512;

	public static bool developerMode;

	public const string GB_GUID = "org.LoShin.GenesisBook";

	public const string MMS_GUID = "Gnimaerd.DSP.plugin.MoreMegaStructure";

	public const string TCFV_GUID = "com.ckcz123.DSP_Battle";

	public static ConfigEntry<KeyCode> OpenWindowHotKey;

	public static ConfigEntry<KeyCode> SwitchWindowSizeHotKey;

	public static ConfigEntry<int> OpenWindowModifier;

	public static ConfigEntry<int> SwitchWindowModifier;

	public static ConfigEntry<bool> EditableTitle;

	public static ConfigEntry<bool> RoundUpAssemblerNum;

	public static ConfigEntry<bool> SingleWindow;

	public static ConfigEntry<int> MaxWindowsReservedAfterClose;

	public static ConfigEntry<bool> ClickToSwitchRecipeMode;

	public static ConfigEntry<bool> OnlyCountUnfinishedFacilities;

	public static ConfigEntry<string> DefaultNewWindowData;

	public static ManualLogSource logger;

	public static bool showMixBeltCheckbox;

	public void Awake()
	{
		logger = base.Logger;
		OpenWindowHotKey = base.Config.Bind("config", "OpenWindowHotKey", KeyCode.Q, "打开计算器窗口的快捷键。HotKey to open calculator window.");
		SwitchWindowSizeHotKey = base.Config.Bind("config", "SwitchWindowSizeHotKey", KeyCode.Tab, "将计算器窗口展开或缩小的快捷键。HotKey to fold or unfold calculator window.");
		OpenWindowModifier = base.Config.Bind("config", "OpenWindowHKModifier", 0, "byte shift = 1, ctrl = 2, alt = 4");
		SwitchWindowModifier = base.Config.Bind("config", "SwitchWindowHKModifier", 0, "byte shift = 1, ctrl = 2, alt = 4");
		EditableTitle = base.Config.Bind("config", "EditTitle", defaultValue: false, "将此项置为true可以使计算器的窗口标题可以被编辑。Set this to true will allow you to edit the calculator window's title in game.");
		RoundUpAssemblerNum = base.Config.Bind("config", "RoundUpAssemblerNum", defaultValue: true, "生产设施数量显示是否自动向上取整。Is the display of the number of production facilities automatically rounded up.");
		SingleWindow = base.Config.Bind("config", "SingleWindow", defaultValue: false, "单窗口模式启用时，打开和关闭窗口都将使用打开窗口的那个快捷键。这会使你无法开启多个窗口，除非你同时按住Ctrl+Shift+Alt。  When single window mode is enabled, both opening and closing calculator window will use the same shortcut key (i.e. the open the window hot key). But if you want to open multiple windows in this mode, you must hold down Ctrl+Shift+Alt at the same time.");
		MaxWindowsReservedAfterClose = base.Config.Bind("config", "MaxWindowsReservedAfterClose", 5, "最后被关闭的几个窗口可以仍在后台保留其计算结果和玩家设置，而不被销毁或重置。若设置为0，则所有关闭的窗口都不会被销毁（不推荐）。The last few closed windows can still retain their calculation results and player settings in the background without being destroyed or reset. If set to 0, all closed windows will not be destroyed (not recommended).");
		ClickToSwitchRecipeMode = base.Config.Bind("config", "ClickToSwitchRecipeMode", defaultValue: false, "切换配方选取的模式会使用“点击循环切换”而非“点击然后选取配方”的模式。The mode for switching recipe selection will use the \"click loop switch\" instead of the \"click and select recipe\" mode.");
		OnlyCountUnfinishedFacilities = base.Config.Bind("config", "OnlyCountUnfinishedFacilities", defaultValue: false, "如果设置为true，一旦你将某个物品产出勾选为已完成，其需求的生产设施将不再被计入右侧面板的生产设施需求总数。If set to true, once you check an item as finished, its required production facilities will no longer be included in the total production facility demand on the right panel.");
		DefaultNewWindowData = base.Config.Bind("config", "DefaultNewWindowData", "", "不要编辑此项内容，除非你知道你在做什么。Never Edit this unless you know what you are doing.");
		Harmony.CreateAndPatchAll(typeof(DSPCalculatorPlugin));
		Harmony.CreateAndPatchAll(typeof(RecipePickerPatcher));
		Harmony.CreateAndPatchAll(typeof(UIHotkeySettingPatcher));
		Harmony.CreateAndPatchAll(typeof(WindowsManager));
		if (TestPatchers.enabled)
		{
			Harmony.CreateAndPatchAll(typeof(TestPatchers));
		}
		Localizations.AddLocalizations();
		Localizations.AddPtBr();
		Localizations.LoadCustomTranslation();
		if (Chainloader.PluginInfos.ContainsKey("org.LoShin.GenesisBook"))
		{
			CompatManager.GB = true;
		}
		if (Chainloader.PluginInfos.ContainsKey("Gnimaerd.DSP.plugin.MoreMegaStructure"))
		{
			CompatManager.MMS = true;
		}
		if (Chainloader.PluginInfos.ContainsKey("com.ckcz123.DSP_Battle"))
		{
			CompatManager.TCFV = true;
		}
	}

	public void Start()
	{
		UIHotkeySettingPatcher.Init();
		WindowsManager.OnStart();
	}

	public void Update()
	{
		UIHotkeySettingPatcher.OnUpdate();
		WindowsManager.OnUpdate();
		UIPauseBarPatcher.OnUpdate();
		if (TestPatchers.enabled && Input.GetKeyDown(KeyCode.K))
		{
			TestPatchers.TestCreateExample();
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameData), "NewGame")]
	[HarmonyPatch(typeof(GameData), "Import")]
	public static void OnLoadGame()
	{
		WindowsManager.InitUIResolution();
		CalcDB.TryInit();
		BpDB.Init();
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(GameMain), "LateUpdate")]
	public static bool EscLogicBlocker()
	{
		if (WindowsManager.hasOpenedWindow)
		{
			bool flag = !VFInput._godModeMechaMove;
			bool flag2 = VFInput.escKey.onDown || VFInput.escape || VFInput.delayedEscape;
			if (flag && flag2)
			{
				WindowsManager.CloseTopWindow();
				return true;
			}
		}
		return true;
	}
}
