# starfi5h-BuildToolOpt

Merge old/new station stock and workers safely during replacement; scope the takeback guard and clear it in finally.

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.

[Review map](REVIEW_GUIDE.md) · [Related mods and code references](RELATED_MODS.md) · [Detailed changes](CHANGELOG.md) · [Build/review notes](BUILD.md) · [Assembly metadata](metadata.json)

Prepared for maintainer review on 15 October 2026. This is a local modified build, not an official upstream release, published package or pull request.

Installed plugin version(s): **1.1.10, 1.0.0**. Existing package manifest version: **1.1.8**. Manifest, plugin and assembly versions are separate; the original manifest is retained.

## Package layout

- `InstalledPackage/`: recorded installed files, subject to the explicit size exclusions in PACKAGING.md; not a complete installation package.
- `Source/Reconstructed/`: full projects reconstructed from the exact installed assemblies.
- `Source/EarlierWorkingSource/`, `PortedWorkingSource/`, `UpstreamSnapshot/`: source snapshots when available; provenance is recorded separately.
- `Evidence/`: development helpers, focused check sources and structured validation/installation records.
- `Diffs/`: source-port patches and normalized structural IL comparison.
- `Baselines/`: previous binary and its provenance for review, not an automatic rollback.

## Plugin identifiers and declared dependencies

- `starfi5h.plugin.BuildToolOpt` — BuildToolOpt 1.1.10; dependencies: none declared on this plugin.
- `starfi5h.plugin.BuildToolOpt.CAPIcompat` — BuildToolOptCAPIcompat 1.0.0; dependencies: dsp.common-api.CommonAPI | hard.

## Installed assembly hashes

| Recorded path | SHA-256 |
|---|---|
| `plugins/starfi5h-BuildToolOpt/BuildToolOpt.dll` | `2f63c60193390c18263f59791a21246ffcc7f345c17c1c01f2417a45b49dd85d` |

## Scope and limitations

Not every source project has been rebuilt. Historical compile/test evidence is limited to its recorded hashes. Headless/embedded-Mono checks do not establish real Unity UI, the user's world, all-mod startup, multiplayer or sustained-memory acceptance.

## Compact maintainer review package

Upload the prepared **`starfi5h-BuildToolOpt.zip`**. Full related-mod copies have been replaced with upstream links, exact versions/hashes and targeted source files under `References/`. See [RELATED_MODS.md](RELATED_MODS.md), [packaging scope and exclusions](PACKAGING.md), and [verification](STANDALONE_VERIFICATION.json). Do not re-ZIP the folder with the ZIP inside it.

All primary development code and recorded validation material are retained. This is a source-review package; external game/mod SDKs and any files explicitly excluded in PACKAGING.md are needed for a full build/runtime test. Historical test results do not establish live-game acceptance.
