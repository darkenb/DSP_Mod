# starfi5h-BuildToolOpt — detailed change report

Installed plugin version(s): **1.1.10, 1.0.0**. Merge old/new station stock and workers safely during replacement; scope the takeback guard and clear it in finally.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Station replacement without stock loss — 1.1.9/1.1.10

Use upstream source matching installed 1.1.8. Check the baseline DLL hash before and after building; retain assembly identity and both plugin GUIDs.

- Merge the old station's workers/warpers with stock added to the new station by other mods. Refund only the actual excess above capacity; do not overwrite and lose a refill that still fits. Subtract working workers when calculating capacity and retain the native 64-vessel limit.
- Scope the item-takeback guard to the specific station in the factory being replaced. Do not reopen an earlier Harmony veto, and clear replacement state in `finally` on exceptions.
- Handle a collision-collider array filled to its last entry without overflowing it.
- Do not register the old research-only advanced-miner Q-selection postfix: native 0.10.35.29104 already chooses based on inventory availability. Retain the setting key and other UI features.
- Preserve native blueprint path/length limits and the CommonAPI helper's incompatibility guard for BlueprintTweaks.

Version 1.1.10 adds `/unsafe+` native-access metadata, checked in game Mono without changing native game files. Independent checks cover stock merging, station/factory scope and finally cleanup. Full replacement with flying workers, blueprint UI and other mods remains live acceptance work; test helpers are not production dependencies.

## Recorded source commits

- `fdb6e3573d41f78b3443d0c6021211d48585c956`

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
