# Related mod references - starfi5h-BuildToolOpt

Full related-mod packages are intentionally omitted. Project URLs, versions, exact local assembly hashes and targeted source files are supplied under `References/`. Upstream HEAD may differ from the locally modified snapshot. Build/runtime dependencies remain external prerequisites.

The source links below point to files actually present in this ZIP. Original line numbers and short excerpts are retained. A shared native integration point does not imply a direct DLL dependency.

## CommonAPI-CommonAPI

[Project identity and versions](References/CommonAPI-CommonAPI/reference.json) | [Reference notes](References/CommonAPI-CommonAPI/README.md)

Upstream: https://github.com/kremnev8/CommonAPI

- **declared_hard_dependency**: Plugin-level dependency declaration; this may belong to an optional compatibility plugin.
- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Code in this mod

[Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/PluginCAPIcompat.cs](Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/PluginCAPIcompat.cs) - original line 10

```csharp

[BepInPlugin("starfi5h.plugin.BuildToolOpt.CAPIcompat", "BuildToolOptCAPIcompat", "1.0.0")]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInIncompatibility("org.kremnev8.plugin.BlueprintTweaks")]
[CommonAPISubmoduleDependency(new string[] { "PickerExtensionsSystem", "CustomKeyBindSystem", "LocalizationModule" })]
```

[Source/EarlierWorkingSource/PluginCAPIcompat.cs](Source/EarlierWorkingSource/PluginCAPIcompat.cs) - original line 13

```csharp
{
    [BepInPlugin(GUID, NAME, VERSION)]    
    [BepInDependency(CommonAPIPlugin.GUID)]
    [BepInIncompatibility("org.kremnev8.plugin.BlueprintTweaks")]
    [CommonAPISubmoduleDependency(nameof(PickerExtensionsSystem), nameof(CustomKeyBindSystem), nameof(LocalizationModule))]
```

[Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/UIBlueprintComponentItem_Patch.cs](Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/UIBlueprintComponentItem_Patch.cs) - original line 30

```csharp
		void OnClick(int itemId)
		{
			UIItemPickerExtension.Popup(new Vector2(-300f, 238f), (Action<ItemProto>)delegate(ItemProto proto)
			{
				if (proto != null)
```

[Source/EarlierWorkingSource/BPT/UIBlueprintComponentItem_Patch.cs](Source/EarlierWorkingSource/BPT/UIBlueprintComponentItem_Patch.cs) - original line 32

```csharp
            void OnClick(int itemId)
            {
                UIItemPickerExtension.Popup(new Vector2(-300, 238), proto =>
                {
                    if (proto == null) return;
```

### Code in the related reference

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 16

```csharp
namespace CommonAPI;

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs) - original line 14

```csharp
[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
{
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/PowerNetworkHandler.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/PowerNetworkHandler.cs) - original line 58

```csharp
	public override string GetComponentType()
	{
		return "dsp.common-api.CommonAPI:PowerNetworkHandler";
	}

```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 35

```csharp
    {
        public const string ID = "CommonAPI";
        public const string GUID = "dsp.common-api.CommonAPI";
        public const string DISPNAME = "DSP Common API";

```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/BaseSubmodule.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/BaseSubmodule.cs) - original line 18

```csharp
		{
			string name = GetType().Name;
			throw new InvalidOperationException(name + " is not loaded. Please use [CommonAPISubmoduleDependency(nameof(" + name + ")]");
		}
	}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPISubmoduleDependency.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPISubmoduleDependency.cs) - original line 6

```csharp

[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
public class CommonAPISubmoduleDependency : Attribute
{
	public string?[]? SubmoduleNames { get; }
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ConfigFileExtension.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ConfigFileExtension.cs) - original line 33

```csharp
				entry.SetSerializedValue(item.Value);
				list.Add(item.Key);
				CommonAPIPlugin.logger.LogInfo("Migrating config from " + oldSection + ":" + key + " to " + newSection + ":" + key);
			}
		}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/HarmonyRegisterExtension.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/HarmonyRegisterExtension.cs) - original line 31

```csharp
			else
			{
				CommonAPIPlugin.logger.LogInfo("Failed to patch: " + item.FullName + ".");
			}
		}
```

## CommonAPI-DSPModSave

[Project identity and versions](References/CommonAPI-DSPModSave/reference.json) | [Reference notes](References/CommonAPI-DSPModSave/README.md)

Upstream: https://github.com/kremnev8/DSP-Mods/tree/master/Mods/DSPModSave

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs) - original line 15

```csharp
namespace crecheng.DSPModSave;

[BepInPlugin("crecheng.DSPModSave", "DSP Mod Save", "1.2.3")]
public class DSPModSavePlugin : BaseUnityPlugin
{
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs) - original line 12

```csharp
	private static void EnterGame()
	{
		DSPModSavePlugin.logger.LogInfo("Enter New Game");
		foreach (ModSaveSettings value in DSPModSavePlugin.allModData.Values)
		{
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs) - original line 13

```csharp
		if (__result)
		{
			DSPModSavePlugin.OnSave(saveName);
		}
	}
```

[References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs](References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs) - original line 19

```csharp
static class Check
{
    static void Call(string method, params object[] args) {AccessTools.Method(typeof(DSPModSavePlugin), method).Invoke(null, args);}
    static int Main()
    {
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs) - original line 20

```csharp
{
    [BepInPlugin(MODGUID, MODNAME, VERSION)]
    public class DSPModSavePlugin : BaseUnityPlugin
    {
        public const string MODGUID = "crecheng.DSPModSave";
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs) - original line 12

```csharp
        static void EnterGame()
        {
            DSPModSavePlugin.logger.LogInfo("Enter New Game");
            foreach (var d in DSPModSavePlugin.allModData.Values)
            {
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs) - original line 14

```csharp
            if (!__result) return;

            DSPModSavePlugin.OnSave(saveName);
        }

```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 18

```csharp
[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
{
```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 31

```csharp
    [BepInPlugin(GUID, DISPNAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
    {
```

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist/UXAssist.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist/UXAssist.cs) - original line 24

```csharp

[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "CustomKeyBindSystem" })]
[BepInPlugin("org.soardev.uxassist", "UXAssist", "1.6.3")]
```

[References/soarqin-UXAssist/Code/Source/EarlierWorkingSource/UXAssist.cs](References/soarqin-UXAssist/Code/Source/EarlierWorkingSource/UXAssist.cs) - original line 26

```csharp

[BepInDependency(CommonAPIPlugin.GUID)]
[BepInDependency(DSPModSavePlugin.MODGUID)]
[CommonAPISubmoduleDependency(nameof(CustomKeyBindSystem))]
[BepInPlugin(PluginInfo.PLUGIN_GUID, PluginInfo.PLUGIN_NAME, PluginInfo.PLUGIN_VERSION)]
```

## IlldariFairlight-AutoLogisticsDroneSetup

[Project identity and versions](References/IlldariFairlight-AutoLogisticsDroneSetup/reference.json) | [Reference notes](References/IlldariFairlight-AutoLogisticsDroneSetup/README.md)

Upstream: https://github.com/AndrewLuebke/DSP-AutoLogisticsDroneSetup

- **fix_integration_context**: Station replacement merges workers supplied by initial auto-fill instead of overwriting them.

### Code in this mod

[Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/ReplaceStationLogic.cs](Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/ReplaceStationLogic.cs) - original line 101

```csharp
			}
		}
		stationComponent.idleDroneCount = 0;
		stationComponent.idleShipCount = 0;
		stationComponent.warperCount = 0;
```

[Source/EarlierWorkingSource/Replace/ReplaceStationLogic.cs](Source/EarlierWorkingSource/Replace/ReplaceStationLogic.cs) - original line 83

```csharp
				}
			}
			stationComponent.idleDroneCount = 0;
			stationComponent.idleShipCount = 0;
			stationComponent.warperCount = 0;
```

[Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/GalacticTransport_Patch.cs](Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/GalacticTransport_Patch.cs) - original line 87

```csharp
		for (int i = 1; i < planetTransport.stationCursor; i++)
		{
			StationComponent stationComponent = planetTransport.stationPool[i];
			if (stationComponent?.storage == null || !stationComponent.isStellar)
			{
```

[Source/EarlierWorkingSource/Optimization/GalacticTransport_Patch.cs](Source/EarlierWorkingSource/Optimization/GalacticTransport_Patch.cs) - original line 121

```csharp

		[HarmonyPrefix, HarmonyPriority(Priority.Low)]
		[HarmonyPatch(typeof(GalacticTransport), nameof(GalacticTransport.RemoveStationComponent))]
		static void RemoveILS_Prefix(ref bool __runOriginal, GalacticTransport __instance, int gid)
        {
```

### Code in the related reference

[References/IlldariFairlight-AutoLogisticsDroneSetup/Code/Source/Reconstructed/plugins/AutoLogisticsDroneSetup/DSP_Mods/AutoLogisticsDroneSetup.cs](References/IlldariFairlight-AutoLogisticsDroneSetup/Code/Source/Reconstructed/plugins/AutoLogisticsDroneSetup/DSP_Mods/AutoLogisticsDroneSetup.cs) - original line 120

```csharp
		if (station != null && desc != null && util != null)
		{
			int num = FillQuantity.Needed((station.workDroneDatas != null) ? station.workDroneDatas.Length : desc.stationMaxDroneCount, station.idleDroneCount, station.workDroneCount, desiredAmount);
			if (num > 0)
			{
```

[References/IlldariFairlight-AutoLogisticsDroneSetup/Code/Evidence/InitialPhase/check.cs](References/IlldariFairlight-AutoLogisticsDroneSetup/Code/Evidence/InitialPhase/check.cs) - original line 42

```csharp
        var util = Activator.CreateInstance(typeof(AutoLogisticsDroneSetup).Assembly.GetType("DSP_Mods.StorageUtility"), true);
        var desc = new PrefabDesc {stationMaxDroneCount = 10, stationMaxShipCount = 10, dispenserMaxCourierCount = 10};
        var station = new StationComponent {idleDroneCount = 3, workDroneCount = 2, workDroneDatas = new DroneData[10],
            idleShipCount = 2, workShipCount = 1, workShipDatas = new ShipData[10], droneAutoReplenish = true, shipAutoReplenish = true};
        Fill("AddDrones", station, desc, util, 8);
```

[References/IlldariFairlight-AutoLogisticsDroneSetup/Code/Source/EarlierWorkingSource/AutoLogisticsDroneSetup.cs](References/IlldariFairlight-AutoLogisticsDroneSetup/Code/Source/EarlierWorkingSource/AutoLogisticsDroneSetup.cs) - original line 114

```csharp
            if (station == null || desc == null || util == null) return;
            int capacity = station.workDroneDatas != null ? station.workDroneDatas.Length : desc.stationMaxDroneCount;
            int need = FillQuantity.Needed(capacity, station.idleDroneCount, station.workDroneCount, desiredAmount);
            if (need > 0) station.idleDroneCount += util.RemoveItems(Drone, need);
        }
```

[References/IlldariFairlight-AutoLogisticsDroneSetup/Code/Source/Reconstructed/plugins/AutoLogisticsDroneSetup/DSP_Mods/StorageUtility.cs](References/IlldariFairlight-AutoLogisticsDroneSetup/Code/Source/Reconstructed/plugins/AutoLogisticsDroneSetup/DSP_Mods/StorageUtility.cs) - original line 139

```csharp
				break;
			}
			StationComponent stationComponent = factory.transport.stationPool[i];
			if (stationComponent != null && stationComponent.id == i)
			{
```

## blacksnipebiu-Auxilaryfunction

[Project identity and versions](References/blacksnipebiu-Auxilaryfunction/reference.json) | [Reference notes](References/blacksnipebiu-Auxilaryfunction/README.md)

Upstream: https://github.com/blacksnipebiu/Auxilaryfunction

- **fix_integration_context**: Station replacement preserves workers/warpers already added by other station-fill callbacks.

### Code in this mod

[Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/ReplaceStationLogic.cs](Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/ReplaceStationLogic.cs) - original line 101

```csharp
			}
		}
		stationComponent.idleDroneCount = 0;
		stationComponent.idleShipCount = 0;
		stationComponent.warperCount = 0;
```

[Source/EarlierWorkingSource/Replace/ReplaceStationLogic.cs](Source/EarlierWorkingSource/Replace/ReplaceStationLogic.cs) - original line 83

```csharp
				}
			}
			stationComponent.idleDroneCount = 0;
			stationComponent.idleShipCount = 0;
			stationComponent.warperCount = 0;
```

[Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/GalacticTransport_Patch.cs](Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/GalacticTransport_Patch.cs) - original line 87

```csharp
		for (int i = 1; i < planetTransport.stationCursor; i++)
		{
			StationComponent stationComponent = planetTransport.stationPool[i];
			if (stationComponent?.storage == null || !stationComponent.isStellar)
			{
```

[Source/EarlierWorkingSource/Optimization/GalacticTransport_Patch.cs](Source/EarlierWorkingSource/Optimization/GalacticTransport_Patch.cs) - original line 121

```csharp

		[HarmonyPrefix, HarmonyPriority(Priority.Low)]
		[HarmonyPatch(typeof(GalacticTransport), nameof(GalacticTransport.RemoveStationComponent))]
		static void RemoveILS_Prefix(ref bool __runOriginal, GalacticTransport __instance, int gid)
        {
```

### Code in the related reference

[References/blacksnipebiu-Auxilaryfunction/Code/Source/PortedWorkingSource/Auxilaryfunction/AuxilaryfunctionPatch.cs](References/blacksnipebiu-Auxilaryfunction/Code/Source/PortedWorkingSource/Auxilaryfunction/AuxilaryfunctionPatch.cs) - original line 60

```csharp
            if (BuildTargetValues.IsConfigEnabled("填充飞机数量"))
            {
                __result.idleDroneCount += NativeInventory.Take(player, 5001, NativeInventory.Missing(__result.workDroneDatas?.Length ?? 0, __result.idleDroneCount, __result.workDroneCount, auto_supply_drone.Value), out _);
            }

```

[References/blacksnipebiu-Auxilaryfunction/Code/Source/PortedWorkingSource/Auxilaryfunction.Services/GUIDraw.cs](References/blacksnipebiu-Auxilaryfunction/Code/Source/PortedWorkingSource/Auxilaryfunction.Services/GUIDraw.cs) - original line 825

```csharp
				case 0:
					itemId = 5001;
					totalCount = stationComponent.idleDroneCount + stationComponent.workDroneCount;
					currentCount = stationComponent.idleDroneCount;
					break;
```

[References/blacksnipebiu-Auxilaryfunction/Code/Source/PortedWorkingSource/Auxilaryfunction.Services/LogisticsService.cs](References/blacksnipebiu-Auxilaryfunction/Code/Source/PortedWorkingSource/Auxilaryfunction.Services/LogisticsService.cs) - original line 41

```csharp
                int dronelimit = sc.workDroneDatas?.Length ?? 0;
                int tempdrone = autoDroneValue > dronelimit ? dronelimit : autoDroneValue;
                int needDroneNum = NativeInventory.Missing(dronelimit, sc.idleDroneCount, sc.workDroneCount, tempdrone);
                if (needDroneNum > 0)
                    sc.idleDroneCount += NativeInventory.Take(player, 5001, needDroneNum, out _);
```

[References/blacksnipebiu-Auxilaryfunction/Code/Source/Reconstructed/plugins/Auxilaryfunction/Auxilaryfunction/AuxilaryfunctionPatch.cs](References/blacksnipebiu-Auxilaryfunction/Code/Source/Reconstructed/plugins/Auxilaryfunction/Auxilaryfunction/AuxilaryfunctionPatch.cs) - original line 65

```csharp
			{
				StationComponent obj = __result;
				int idleDroneCount = obj.idleDroneCount;
				Player player = Auxilaryfunction.player;
				DroneData[] workDroneDatas = __result.workDroneDatas;
```

[References/blacksnipebiu-Auxilaryfunction/Code/Source/Reconstructed/plugins/Auxilaryfunction/Auxilaryfunction.Services/GUIDraw.cs](References/blacksnipebiu-Auxilaryfunction/Code/Source/Reconstructed/plugins/Auxilaryfunction/Auxilaryfunction.Services/GUIDraw.cs) - original line 820

```csharp
				case 0:
					itemId = 5001;
					totalCount = stationComponent.idleDroneCount + stationComponent.workDroneCount;
					currentCount = stationComponent.idleDroneCount;
					break;
```

[References/blacksnipebiu-Auxilaryfunction/Code/Source/Reconstructed/plugins/Auxilaryfunction/Auxilaryfunction.Services/LogisticsService.cs](References/blacksnipebiu-Auxilaryfunction/Code/Source/Reconstructed/plugins/Auxilaryfunction/Auxilaryfunction.Services/LogisticsService.cs) - original line 58

```csharp
				int num = ((workDroneDatas != null) ? workDroneDatas.Length : 0);
				int target = ((value2 > num) ? num : value2);
				int num2 = NativeInventory.Missing(num, stationComponent.idleDroneCount, stationComponent.workDroneCount, target);
				if (num2 > 0)
				{
```

[References/blacksnipebiu-Auxilaryfunction/Code/Source/EarlierWorkingSource/Patch/AuxilaryfunctionPatch.cs](References/blacksnipebiu-Auxilaryfunction/Code/Source/EarlierWorkingSource/Patch/AuxilaryfunctionPatch.cs) - original line 70

```csharp
            if (BuildTargetValues.IsConfigEnabled("填充飞机数量"))
            {
                __result.idleDroneCount += NativeInventory.Take(player, 5001, NativeInventory.Missing(__result.workDroneDatas?.Length ?? 0, __result.idleDroneCount, __result.workDroneCount, auto_supply_drone.Value), out _);
            }

```

[References/blacksnipebiu-Auxilaryfunction/Code/Source/EarlierWorkingSource/Services/GUIDraw.cs](References/blacksnipebiu-Auxilaryfunction/Code/Source/EarlierWorkingSource/Services/GUIDraw.cs) - original line 755

```csharp
                {
                    itemId = 5001;
                    totalCount = stationComponent.idleDroneCount + stationComponent.workDroneCount;
                    CurrentCount = stationComponent.idleDroneCount;
                }
```

## jinxOAO-DSPCalculator

[Project identity and versions](References/jinxOAO-DSPCalculator/reference.json) | [Reference notes](References/jinxOAO-DSPCalculator/README.md)

Upstream: https://github.com/jinxOAO/DSPCalculator

- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Code in this mod

[Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/Compatibility.cs](Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/Compatibility.cs) - original line 56

```csharp
	}

	public static class DSPCalculator_Patch
	{
		private class Warpper
```

[Source/EarlierWorkingSource/Compatibility.cs](Source/EarlierWorkingSource/Compatibility.cs) - original line 16

```csharp
            Nebula_Patch.Init();
            CheatEnabler_Patch.Init(harmony);
            DSPCalculator_Patch.Init(harmony); // Can't test it in debug mode due to type loading
        }

```

### Code in the related reference

[References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator/DSPCalculatorPlugin.cs](References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator/DSPCalculatorPlugin.cs) - original line 15

```csharp
namespace DSPCalculator;

[BepInPlugin("com.GniMaerd.DSPCalculator", "DSPCalculator", "0.5.27")]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.LoShin.GenesisBook", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator/Utils.cs](References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator/Utils.cs) - original line 10

```csharp
public static class Utils
{
	public static ManualLogSource logger => DSPCalculatorPlugin.logger;

	public static string KMG(double num)
```

[References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.Bp/BpProcessor.cs](References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.Bp/BpProcessor.cs) - original line 301

```csharp
				bpCargoInfo.maxSorterDistance = (int)(solution.sortersAvailable.Last().speedPerMin / bpCargoInfo.beltSpeedRequiredPerAssembler);
			}
			if (DSPCalculatorPlugin.developerMode)
			{
				Utils.logger.LogInfo($"item{Utils.GetItemName(bpCargoInfo.itemId)} spd per factory {bpCargoInfo.beltSpeedRequiredPerAssembler} maxC{bpCargoInfo.maxSupportAssemblerCount} sorter max distance{bpCargoInfo.maxSorterDistance}.");
```

[References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.Logic/RecipeInfo.cs](References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.Logic/RecipeInfo.cs) - original line 131

```csharp
				return CalcDB.assemblerListByType[recipeNorm.type][0].ID;
			}
			Debug.LogError("DSPCalculator get assemblerId Error. no such aseembler that could match the recipe.");
			return -1;
		}
```

[References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.Logic/SolutionTree.cs](References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.Logic/SolutionTree.cs) - original line 256

```csharp
						Debug.LogWarning($"cur的parent为0，这不正常，出现在itemId={itemId}");
					}
					if (DSPCalculatorPlugin.developerMode)
					{
						int itemId2 = itemNode.parents[0].itemId;
```

[References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.Logic/UserPreference.cs](References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.Logic/UserPreference.cs) - original line 159

```csharp
		customizeIncMilli = false;
		customizeAccMilli = false;
		roundUpAssemgblerNum = DSPCalculatorPlugin.RoundUpAssemblerNum.Value;
		solveProliferators = false;
		showMixBeltInfo = false;
```

[References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.UI/UICalcWindow.cs](References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.UI/UICalcWindow.cs) - original line 540

```csharp
		titleInputUIBtn.transitions = new UIButton.Transition[1] { transition };
		titleInputUIBtn.highlighted = false;
		if (DSPCalculatorPlugin.EditableTitle.Value)
		{
			gameObject3.SetActive(value: false);
```

[References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.UI/UIHotkeySettingPatcher.cs](References/jinxOAO-DSPCalculator/Code/Source/Reconstructed/plugins/DSPCalculator/DSPCalculator.UI/UIHotkeySettingPatcher.cs) - original line 87

```csharp
	public static bool CheckModifier(int type, bool shift, bool ctrl, bool alt)
	{
		int value = DSPCalculatorPlugin.OpenWindowModifier.Value;
		if (type == 2)
		{
```

## kremnev8-BlueprintTweaks

[Project identity and versions](References/kremnev8-BlueprintTweaks/reference.json) | [Reference notes](References/kremnev8-BlueprintTweaks/README.md)

Upstream: https://github.com/kremnev8/DSP-Mods/tree/master/Mods/BlueprintTweaks

- **fix_integration_context**: The existing CommonAPI helper incompatibility guard is retained when BlueprintTweaks is present.

### Code in this mod

[Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/PluginCAPIcompat.cs](Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/PluginCAPIcompat.cs) - original line 11

```csharp
[BepInPlugin("starfi5h.plugin.BuildToolOpt.CAPIcompat", "BuildToolOptCAPIcompat", "1.0.0")]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInIncompatibility("org.kremnev8.plugin.BlueprintTweaks")]
[CommonAPISubmoduleDependency(new string[] { "PickerExtensionsSystem", "CustomKeyBindSystem", "LocalizationModule" })]
public class PluginCAPIcompat : BaseUnityPlugin
```

[Source/EarlierWorkingSource/BPT/CameraFix_Patch.cs](Source/EarlierWorkingSource/BPT/CameraFix_Patch.cs) - original line 8

```csharp
namespace BuildToolOpt
{
    // Reference: https://github.com/limoka/DSP-Mods/blob/master/Mods/BlueprintTweaks/src/BlueprintTweaks/Camera/CameraFixPatch.cs
    // Original Author: limoka

```

[Source/EarlierWorkingSource/BPT/UIBlueprintComponentItem_Patch.cs](Source/EarlierWorkingSource/BPT/UIBlueprintComponentItem_Patch.cs) - original line 9

```csharp
namespace BuildToolOpt
{
    // Reference: https://github.com/limoka/DSP-Mods/blob/master/Mods/BlueprintTweaks/src/BlueprintTweaks/BPPanelChanges/UIBlueprintComponentItemPatch.cs
    // Original Author: limoka

```

[Source/EarlierWorkingSource/PluginCAPIcompat.cs](Source/EarlierWorkingSource/PluginCAPIcompat.cs) - original line 14

```csharp
    [BepInPlugin(GUID, NAME, VERSION)]    
    [BepInDependency(CommonAPIPlugin.GUID)]
    [BepInIncompatibility("org.kremnev8.plugin.BlueprintTweaks")]
    [CommonAPISubmoduleDependency(nameof(PickerExtensionsSystem), nameof(CustomKeyBindSystem), nameof(LocalizationModule))]
    public class PluginCAPIcompat : BaseUnityPlugin
```

### Code in the related reference

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/patchers/BlueprintTweaksPatcher/BlueprintTweaks/Preloader.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/patchers/BlueprintTweaksPatcher/BlueprintTweaks/Preloader.cs) - original line 17

```csharp
	public static void Initialize()
	{
		logSource = Logger.CreateLogSource("BlueprintTweaks Preloader");
	}

```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/BlueprintTweaksPlugin.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/BlueprintTweaksPlugin.cs) - original line 25

```csharp
namespace BlueprintTweaks;

[BepInPlugin("org.kremnev8.plugin.BlueprintTweaks", "Blueprint Tweaks", "1.6.14")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/BlueprintUtilsPatch2.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/BlueprintUtilsPatch2.cs) - original line 53

```csharp
	public static void Close()
	{
		if (BlueprintTweaksPlugin.resetFunctionsOnMenuExit.Value)
		{
			mirrorLat = false;
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/DragRemoveBuildTool.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/DragRemoveBuildTool.cs) - original line 448

```csharp
		if (prefabDesc.isStation)
		{
			return !BlueprintTweaksPlugin.excludeStations.Value;
		}
		if (prefabDesc.isInserter)
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/GridSnappingPatches.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/GridSnappingPatches.cs) - original line 161

```csharp
	public static void Close()
	{
		if (BlueprintTweaksPlugin.resetFunctionsOnMenuExit.Value)
		{
			isLockedLongitude = false;
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/PlayerAction_BuildPatch.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/PlayerAction_BuildPatch.cs) - original line 16

```csharp
		BuildTool[] array = new BuildTool[tools.Length + 1];
		tools.CopyTo(array, 0);
		BlueprintTweaksPlugin.tool = new DragRemoveBuildTool();
		array[^1] = BlueprintTweaksPlugin.tool;
		__instance.tools = array;
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/PlayerControllerPatch.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/PlayerControllerPatch.cs) - original line 52

```csharp
			return false;
		}
		if (BlueprintTweaksPlugin.genesisBookIsInstalled)
		{
			PlanetData localPlanet = __instance.gameData.localPlanet;
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/RemoveHelper.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/RemoveHelper.cs) - original line 25

```csharp
			if (!excludeStationOverride)
			{
				return BlueprintTweaksPlugin.excludeStations.Value;
			}
			return true;
```

## nebula-NebulaMultiplayerModApi

[Project identity and versions](References/nebula-NebulaMultiplayerModApi/reference.json) | [Reference notes](References/nebula-NebulaMultiplayerModApi/README.md)

Upstream: https://github.com/NebulaModTeam/nebula

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs) - original line 15

```csharp
[BepInPlugin("dsp.nebula-multiplayer-api", "NebulaMultiplayerModApi", "2.1.0.7")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class NebulaModAPI : BaseUnityPlugin
{
	public const string NEBULA_MODID = "dsp.nebula-multiplayer";
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs) - original line 5

```csharp
namespace NebulaAPI.DataStructures;

public static class CollectionExtensions
{
	public static Locker Lock(this ICollection collection)
```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs) - original line 13

```csharp

[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/BlueprintTweaksPlugin.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/BlueprintTweaksPlugin.cs) - original line 26

```csharp

[BepInPlugin("org.kremnev8.plugin.BlueprintTweaks", "Blueprint Tweaks", "1.6.14")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "CustomKeyBindSystem", "PickerExtensionsSystem", "LocalizationModule" })]
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.InstallCheck/InstallationChecker.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.InstallCheck/InstallationChecker.cs) - original line 35

```csharp
			ldbToolInstalled = true;
		}
		if (Chainloader.PluginInfos.ContainsKey("dsp.nebula-multiplayer-api"))
		{
			nebulaAPIInstalled = true;
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.InstallCheck/UIMainMenuPatch.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.InstallCheck/UIMainMenuPatch.cs) - original line 26

```csharp
				text += "  - Plugin \"LDB Tool\" is missing\n";
			}
			if (!InstallationChecker.nebulaAPIInstalled)
			{
				text += "  - Plugin \"Nebula Multiplayer Mod API\" is missing\n";
```

## soarqin-UXAssist

[Project identity and versions](References/soarqin-UXAssist/reference.json) | [Reference notes](References/soarqin-UXAssist/README.md)

Upstream: https://github.com/soarqin/DSP_Mods/tree/master/UXAssist

- **fix_integration_context**: Replacement and auto-fill share native station inventory and capacity; excess-only refunds must preserve new stock.

### Code in this mod

[Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/ReplaceStationLogic.cs](Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/ReplaceStationLogic.cs) - original line 101

```csharp
			}
		}
		stationComponent.idleDroneCount = 0;
		stationComponent.idleShipCount = 0;
		stationComponent.warperCount = 0;
```

[Source/EarlierWorkingSource/Replace/ReplaceStationLogic.cs](Source/EarlierWorkingSource/Replace/ReplaceStationLogic.cs) - original line 83

```csharp
				}
			}
			stationComponent.idleDroneCount = 0;
			stationComponent.idleShipCount = 0;
			stationComponent.warperCount = 0;
```

[Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/GalacticTransport_Patch.cs](Source/Reconstructed/plugins/BuildToolOpt/BuildToolOpt/GalacticTransport_Patch.cs) - original line 87

```csharp
		for (int i = 1; i < planetTransport.stationCursor; i++)
		{
			StationComponent stationComponent = planetTransport.stationPool[i];
			if (stationComponent?.storage == null || !stationComponent.isStellar)
			{
```

[Source/EarlierWorkingSource/Optimization/GalacticTransport_Patch.cs](Source/EarlierWorkingSource/Optimization/GalacticTransport_Patch.cs) - original line 121

```csharp

		[HarmonyPrefix, HarmonyPriority(Priority.Low)]
		[HarmonyPatch(typeof(GalacticTransport), nameof(GalacticTransport.RemoveStationComponent))]
		static void RemoveILS_Prefix(ref bool __runOriginal, GalacticTransport __instance, int gid)
        {
```

### Code in the related reference

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Functions/PlanetFunctions.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Functions/PlanetFunctions.cs) - original line 531

```csharp
							}
						}
						int num30 = stationComponent.idleDroneCount + stationComponent.workDroneCount;
						if (num30 > 0)
						{
```

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Patches.Logistics/LogisticsPatch.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Patches.Logistics/LogisticsPatch.cs) - original line 182

```csharp
		if (factory != null && GameMain.mainPlayer != null && GameMain.mainPlayer.factory == factory && station?.workDroneDatas != null)
		{
			int num = MissingWorkers(station.isStellar ? AutoConfigILSDroneCount.Value : AutoConfigPLSDroneCount.Value, station.workDroneDatas.Length, station.idleDroneCount, station.workDroneCount);
			if (num > 0)
			{
```

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Patches.Logistics/RealtimeLogisticsInfoPanel.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Patches.Logistics/RealtimeLogisticsInfoPanel.cs) - original line 471

```csharp
			case EStationTipLayout.PlanetaryLogistics:
			{
				int num5 = stationComponent.idleDroneCount + stationComponent.workDroneCount;
				int idleDroneCount = stationComponent.idleDroneCount;
				_carrierIdleCountText[0].text = idleDroneCount.ToString();
```

[References/soarqin-UXAssist/Code/Evidence/InitialPhase/check.cs](References/soarqin-UXAssist/Code/Evidence/InitialPhase/check.cs) - original line 53

```csharp
        var factory=Empty<PlanetFactory>(); var planet=Empty<PlanetData>(); planet.factory=factory;
        Set(planet,"factoryLoaded",true);Set(player,"planetData",planet);
        var station=new StationComponent {idleDroneCount=3,workDroneCount=2,workDroneDatas=new DroneData[10],
            idleShipCount=2,workShipCount=1,workShipDatas=new ShipData[6],droneAutoReplenish=true,shipAutoReplenish=true};
        var bot=new DispenserComponent {idleCourierCount=3,workCourierCount=2,workCourierDatas=new CourierData[20],courierAutoReplenish=true};
```

[References/soarqin-UXAssist/Code/Source/EarlierWorkingSource/Functions/PlanetFunctions.cs](References/soarqin-UXAssist/Code/Source/EarlierWorkingSource/Functions/PlanetFunctions.cs) - original line 445

```csharp
                        if (count > 0) AddReturnedItem(sc.storage[j].itemId, count, sc.storage[j].inc, returnedItems);
                    }
                    var droneCount = sc.idleDroneCount + sc.workDroneCount;
                    if (droneCount > 0) AddReturnedItem((int)Common.KnownItemId.Drone, droneCount, 0, returnedItems);
                    var shipCount = sc.idleShipCount + sc.workShipCount;
```

[References/soarqin-UXAssist/Code/Source/EarlierWorkingSource/Patches/Logistics/LogisticsPatch.cs](References/soarqin-UXAssist/Code/Source/EarlierWorkingSource/Patches/Logistics/LogisticsPatch.cs) - original line 138

```csharp
        if (factory == null || GameMain.mainPlayer == null || GameMain.mainPlayer.factory != factory || station?.workDroneDatas == null) return;
        var target = station.isStellar ? AutoConfigILSDroneCount.Value : AutoConfigPLSDroneCount.Value;
        var toFill = MissingWorkers(target, station.workDroneDatas.Length, station.idleDroneCount, station.workDroneCount);
        if (toFill > 0) station.idleDroneCount += GameMain.data.mainPlayer.package.TakeItem((int)KnownItemId.Drone, toFill, out _);
    }
```

[References/soarqin-UXAssist/Code/Source/EarlierWorkingSource/Patches/Logistics/RealtimeInfoPanelPatch.cs](References/soarqin-UXAssist/Code/Source/EarlierWorkingSource/Patches/Logistics/RealtimeInfoPanelPatch.cs) - original line 1105

```csharp
            {
                case EStationTipLayout.PlanetaryLogistics:
                    var totalCount = stationComponent.idleDroneCount + stationComponent.workDroneCount;
                    var currentCount = stationComponent.idleDroneCount;
                    _carrierIdleCountText[0].text = currentCount.ToString();
```

[References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Functions/FactoryFunctions.cs](References/soarqin-UXAssist/Code/Source/Reconstructed/plugins/UXAssist/UXAssist.Functions/FactoryFunctions.cs) - original line 165

```csharp
		}
		EntityData[] entityPool = factory.entityPool;
		StationComponent[] stationPool = factory.transport.stationPool;
		foreach (int item in list)
		{
```

## xiaoye97-LDBTool

[Project identity and versions](References/xiaoye97-LDBTool/reference.json) | [Reference notes](References/xiaoye97-LDBTool/README.md)

Upstream: https://github.com/xiaoye97/DSP_LDBTool

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs) - original line 11

```csharp
namespace xiaoye97;

public static class LDBTool
{
	public static Action PreAddDataAction;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs) - original line 11

```csharp
namespace xiaoye97;

[BepInPlugin("me.xiaoye97.plugin.Dyson.LDBTool", "LDBTool", "3.0.4")]
public class LDBToolPlugin : BaseUnityPlugin
{
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs) - original line 16

```csharp
	internal static void InitIndex()
	{
		LDBToolPlugin.logger.LogDebug("Generating Proto type list:");
		protoTypes = (from domainAssembly in AppDomain.CurrentDomain.GetAssemblies()
			from assemblyType in GetTypesSafe(domainAssembly)
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs) - original line 19

```csharp
		if (__instance.recipeExecuteData == null)
		{
			LDBToolPlugin.logger.LogWarning($"Importing assembler {__instance.recipeType}: Can't find recipeId {__instance.recipeId}");
			__instance.recipeId = 0;
			__instance.recipeType = ERecipeType.None;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs) - original line 12

```csharp
	private static void HistoryPatch(GameHistoryData __instance)
	{
		foreach (Proto item in LDBTool.TotalDict[ProtoIndex.GetIndex(typeof(RecipeProto))])
		{
			RecipeProto recipeProto = item as RecipeProto;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/UITip_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/UITip_Patch.cs) - original line 12

```csharp
	private static void ItemTipPatch(UIItemTip __instance, int itemId)
	{
		if (LDBToolPlugin.ShowProto.Value)
		{
			__instance.nameText.text += $" {itemId}";
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/VFPreload_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/VFPreload_Patch.cs) - original line 15

```csharp
	private static void VFPreloadPrePatch()
	{
		if (!LDBTool.Finshed)
		{
			LDBToolPlugin.logger.LogInfo("Pre Loading...");
```

[References/xiaoye97-LDBTool/Code/Evidence/InitialPhase/check.cs](References/xiaoye97-LDBTool/Code/Evidence/InitialPhase/check.cs) - original line 53

```csharp
            return null;
        };
        try { plugin = Assembly.LoadFrom(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "LDBTool.dll")); Run(); }
        catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }
    }
```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 17

```csharp

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/ProtoRegistry.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/ProtoRegistry.cs) - original line 81

```csharp
		spriteFileExtensions = new string[3] { ".jpg", ".png", ".tif" };
		audioClipFileExtensions = new string[4] { ".mp3", ".ogg", ".waw", ".aif" };
		LDBTool.PostAddDataAction = (Action)Delegate.Combine(LDBTool.PostAddDataAction, new Action(OnPostAdd));
		LDBTool.EditDataAction = (Action<Proto>)Delegate.Combine(LDBTool.EditDataAction, new Action<Proto>(EditProto));
	}
```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 30

```csharp
    /// </summary>
    [BepInPlugin(GUID, DISPNAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
```
