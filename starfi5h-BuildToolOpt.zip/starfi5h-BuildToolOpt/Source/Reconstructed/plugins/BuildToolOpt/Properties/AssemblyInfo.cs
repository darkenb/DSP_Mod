using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyTitle("starfi5h.plugin.BuildToolOpt")]
[assembly: AssemblyProduct("BuildToolOpt")]
[assembly: AssemblyVersion("1.1.8.0")]
[module: RefSafetyRules(11)]
