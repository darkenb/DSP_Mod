using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace BuildToolOpt;

internal static class GalacticTransport_Patch
{
	private struct StationPairInfo
	{
		public int gid;

		public HashSet<int> otherGIds;
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(GalacticTransport), "AddStation2StationRoute")]
	[HarmonyPatch(typeof(GalacticTransport), "RemoveStation2StationRoute", new Type[] { typeof(int) })]
	public static IEnumerable<CodeInstruction> S2S_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		return new CodeMatcher(instructions).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Call && ((MethodInfo)i.operand).Name == "RefreshTraffic")).Repeat(delegate(CodeMatcher matcher)
		{
			matcher.Advance(-1).RemoveInstructions(2).InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_1), new CodeInstruction(OpCodes.Ldarg_2), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(GalacticTransport_Patch), "RefreshTraffic_S2S")));
		}).InstructionEnumeration();
	}

	public static void RefreshTraffic_S2S(GalacticTransport galacticTransport, int gid0, int gid1)
	{
		galacticTransport.RefreshTraffic(gid0);
		galacticTransport.RefreshTraffic(gid1);
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(GalacticTransport), "AddAstro2AstroBan")]
	[HarmonyPatch(typeof(GalacticTransport), "AddAstro2AstroRoute")]
	[HarmonyPatch(typeof(GalacticTransport), "RemoveAstro2AstroBan")]
	[HarmonyPatch(typeof(GalacticTransport), "RemoveAstro2AstroRoute")]
	public static IEnumerable<CodeInstruction> A2A_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		return new CodeMatcher(instructions).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Call && ((MethodInfo)i.operand).Name == "RefreshTraffic")).Repeat(delegate(CodeMatcher matcher)
		{
			matcher.Advance(-2).SetAndAdvance(OpCodes.Nop, null).RemoveInstructions(2)
				.InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_1), new CodeInstruction(OpCodes.Ldarg_2), new CodeInstruction(OpCodes.Ldarg_3), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(GalacticTransport_Patch), "RefreshTraffic_A2A")));
		}).InstructionEnumeration();
	}

	public static void RefreshTraffic_A2A(int astroId0, int astroId1, int itemId)
	{
		RefreshTraffic_Astro(astroId0, itemId);
		RefreshTraffic_Astro(astroId1, itemId);
	}

	public static void RefreshTraffic_Astro(int astroId, int itemId)
	{
		if (astroId % 100 == 0)
		{
			StarData starData = GameMain.data.galaxy.StarById(astroId / 100);
			if (starData == null)
			{
				return;
			}
			PlanetData[] planets = starData.planets;
			foreach (PlanetData planetData in planets)
			{
				if (planetData?.factory != null)
				{
					RefreshTraffic_Planet(planetData.factory.transport, itemId);
				}
			}
		}
		else
		{
			PlanetData planetData2 = GameMain.data.galaxy.PlanetById(astroId);
			if (planetData2?.factory != null)
			{
				RefreshTraffic_Planet(planetData2.factory.transport, itemId);
			}
		}
	}

	public static void RefreshTraffic_Planet(PlanetTransport planetTransport, int itemId)
	{
		for (int i = 1; i < planetTransport.stationCursor; i++)
		{
			StationComponent stationComponent = planetTransport.stationPool[i];
			if (stationComponent?.storage == null || !stationComponent.isStellar)
			{
				continue;
			}
			bool flag = false;
			for (int j = 0; j < stationComponent.storage.Length; j++)
			{
				if (stationComponent.storage[j].itemId == itemId)
				{
					flag = true;
					break;
				}
			}
			if (flag)
			{
				GameMain.data.galacticTransport.RefreshTraffic(stationComponent.gid);
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPriority(200)]
	[HarmonyPatch(typeof(GalacticTransport), "RemoveStationComponent")]
	private static void RemoveILS_Prefix(ref bool __runOriginal, GalacticTransport __instance, int gid)
	{
		if (!__runOriginal)
		{
			return;
		}
		if (__instance.stationPool[gid] != null)
		{
			int[] remotePairOffsets = __instance.stationPool[gid].remotePairOffsets;
			int num = ((remotePairOffsets != null) ? remotePairOffsets[6] : 0);
			if (num > 0)
			{
				Plugin.Log.LogDebug($"Remove ILS[{gid}]: remote pair count = {num}");
				StationStore[] storage = __instance.stationPool[gid].storage;
				int num2 = ((storage != null) ? storage.Length : 0);
				for (int i = 0; i < num2; i++)
				{
					storage[i].remoteLogic = ELogisticStorage.None;
				}
				__instance.RefreshTraffic(gid);
			}
			__instance.stationPool[gid] = null;
			__instance.stationRecycle[__instance.stationRecycleCursor++] = gid;
		}
		__instance.RemoveStation2StationRoute(gid);
		if (__instance.OnStellarStationRemoved != null)
		{
			__instance.OnStellarStationRemoved();
		}
		__runOriginal = false;
	}

	[HarmonyPrefix]
	[HarmonyPriority(600)]
	[HarmonyPatch(typeof(PlanetTransport), "RemoveStationComponent")]
	private static void Guard_Prefix(PlanetTransport __instance, int id, ref StationPairInfo __state)
	{
		__state.gid = 0;
		if (__instance.stationPool[id] == null || __instance.stationPool[id].id == 0)
		{
			return;
		}
		StationComponent stationComponent = __instance.stationPool[id];
		int gid = stationComponent.gid;
		if (gid == 0 || stationComponent.remotePairOffsets == null || stationComponent.remotePairs == null || stationComponent.remotePairOffsets[6] == 0)
		{
			return;
		}
		__state.gid = gid;
		__state.otherGIds = new HashSet<int>();
		for (int i = 0; i < stationComponent.remotePairOffsets[6]; i++)
		{
			ref SupplyDemandPair reference = ref stationComponent.remotePairs[i];
			int num = ((reference.supplyId != stationComponent.gid) ? reference.supplyId : reference.demandId);
			if (num != 0)
			{
				__state.otherGIds.Add(num);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPriority(200)]
	[HarmonyPatch(typeof(PlanetTransport), "RemoveStationComponent")]
	private static void Guard_Postfix(ref StationPairInfo __state)
	{
		if (__state.gid == 0)
		{
			return;
		}
		GalacticTransport galacticTransport = GameMain.data.galacticTransport;
		int logisticShipCarries = GameMain.history.logisticShipCarries;
		HashSet<int> otherGIds = __state.otherGIds;
		int gid = __state.gid;
		Plugin.Log.LogDebug($"UpdateShipStatus gid={gid} count={__state.otherGIds.Count}");
		foreach (int item in otherGIds)
		{
			ClearStationRemotePairs(galacticTransport.stationPool[item], gid);
			UpdateShipStatus(galacticTransport.stationPool[item], galacticTransport, gid, logisticShipCarries);
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(GalacticTransport), "RefreshTraffic")]
	public static bool RefreshTraffic_Prefix(GalacticTransport __instance, int keyStationGId)
	{
		if (keyStationGId == 0)
		{
			return true;
		}
		if (keyStationGId > __instance.stationPool.Length || __instance.stationPool[keyStationGId] == null)
		{
			return true;
		}
		StationComponent stationComponent = __instance.stationPool[keyStationGId];
		int[] remotePairOffsets = stationComponent.remotePairOffsets;
		int num = ((remotePairOffsets != null) ? remotePairOffsets[6] : 0);
		Plugin.Log.LogDebug($"GalacticTransport.RefreshTraffic key gid = {keyStationGId} pair count = {num}");
		HashSet<int> hashSet = ClearOtherStationRemotePairs(__instance.stationPool, stationComponent);
		stationComponent.ClearRemotePairs();
		AddRemotePairs(stationComponent, __instance);
		int[] remotePairOffsets2 = stationComponent.remotePairOffsets;
		if (remotePairOffsets2 != null)
		{
			_ = remotePairOffsets2[6];
		}
		int logisticShipCarries = GameMain.history.logisticShipCarries;
		UpdateShipStatus(stationComponent, __instance, keyStationGId, logisticShipCarries);
		foreach (int item in hashSet)
		{
			UpdateShipStatus(__instance.stationPool[item], __instance, keyStationGId, logisticShipCarries);
		}
		__instance.remotePairCount = 0;
		for (int i = 1; i < __instance.stationCursor; i++)
		{
			if (__instance.stationPool[i] != null && __instance.stationPool[i].gid == i)
			{
				__instance.remotePairCount += __instance.stationPool[i].remotePairTotalCount;
			}
		}
		__instance.remotePairCount /= 2;
		return false;
	}

	public static HashSet<int> ClearOtherStationRemotePairs(StationComponent[] stationPool, StationComponent station)
	{
		HashSet<int> hashSet = new HashSet<int>();
		if (station.remotePairOffsets == null)
		{
			return hashSet;
		}
		if (station.remotePairs == null)
		{
			station.SetRemotePairCapacity(128);
		}
		int num = 0;
		for (int i = 0; i < station.remotePairOffsets[6]; i++)
		{
			ref SupplyDemandPair reference = ref station.remotePairs[i];
			int num2 = ((reference.supplyId != station.gid) ? reference.supplyId : reference.demandId);
			if (num2 != 0)
			{
				hashSet.Add(num2);
			}
			num++;
		}
		int num3 = 0;
		foreach (int item in hashSet)
		{
			num3 += ClearStationRemotePairs(stationPool[item], station.gid);
		}
		if (num3 != num)
		{
			Plugin.Log.LogWarning($"RemotePairs mismatch! local:{num} remote:{num3}");
		}
		return hashSet;
	}

	public static int ClearStationRemotePairs(StationComponent station, int keyStationGId)
	{
		int num = 0;
		int num2 = 6;
		for (int num3 = station.remotePairOffsets[6] - 1; num3 >= 0; num3--)
		{
			ref SupplyDemandPair reference = ref station.remotePairs[num3];
			if (reference.demandId == keyStationGId || reference.supplyId == keyStationGId)
			{
				while (num3 < station.remotePairOffsets[num2 - 1] && num2 != 1)
				{
					num2--;
				}
				if (num3 < station.remotePairOffsets[6] - 1)
				{
					Array.Copy(station.remotePairs, num3 + 1, station.remotePairs, num3, station.remotePairOffsets[6] - num3 - 1);
				}
				for (int i = num2; i <= 6; i++)
				{
					station.remotePairOffsets[i]--;
				}
				num++;
			}
		}
		return num;
	}

	public static void AddRemotePairs(StationComponent @this, GalacticTransport galacticTransport)
	{
		StationStore[] storage = @this.storage;
		int num = ((storage != null) ? storage.Length : 0);
		StationComponent[] stationPool = galacticTransport.stationPool;
		int stationCursor = galacticTransport.stationCursor;
		for (int i = 0; i < num; i++)
		{
			if (@this.storage[i].remoteLogic == ELogisticStorage.Supply)
			{
				int itemId = @this.storage[i].itemId;
				for (int j = 1; j < stationCursor; j++)
				{
					if (stationPool[j] == null || stationPool[j].gid != j || stationPool[j].planetId == @this.planetId)
					{
						continue;
					}
					StationStore[] storage2 = stationPool[j].storage;
					for (int k = 0; k < storage2.Length; k++)
					{
						if (itemId != storage2[k].itemId || storage2[k].remoteLogic != ELogisticStorage.Demand)
						{
							continue;
						}
						int planetId = @this.planetId;
						int planetId2 = stationPool[j].planetId;
						int astroId = planetId / 100 * 100;
						int astroId2 = planetId2 / 100 * 100;
						if (!galacticTransport.IsAstro2AstroBanExist(planetId, planetId2, itemId) && !galacticTransport.IsAstro2AstroBanExist(astroId, astroId2, itemId))
						{
							bool flag = stationPool[j].routePriority == ERemoteRoutePriority.Designated || @this.routePriority == ERemoteRoutePriority.Designated;
							if (!flag)
							{
								@this.AddRemotePair(@this.gid, i, j, k);
								stationPool[j].AddRemotePair(@this.gid, i, j, k);
							}
							bool flag2 = false;
							if (galacticTransport.IsStation2StationRouteExist(@this.gid, stationPool[j].gid))
							{
								@this.AddRouteRemotePair(@this.gid, i, j, k, 2);
								stationPool[j].AddRouteRemotePair(@this.gid, i, j, k, 2);
								flag2 = true;
							}
							if (galacticTransport.IsAstro2AstroRouteEnable(planetId, planetId2, itemId))
							{
								@this.AddRouteRemotePair(@this.gid, i, j, k, 3);
								stationPool[j].AddRouteRemotePair(@this.gid, i, j, k, 3);
								flag2 = true;
							}
							if (galacticTransport.IsAstro2AstroRouteEnable(astroId, astroId2, itemId))
							{
								@this.AddRouteRemotePair(@this.gid, i, j, k, 4);
								stationPool[j].AddRouteRemotePair(@this.gid, i, j, k, 4);
								flag2 = true;
							}
							if ((@this.remoteGroupMask & stationPool[j].remoteGroupMask) > 0)
							{
								@this.AddRouteRemotePair(@this.gid, i, j, k, 5);
								stationPool[j].AddRouteRemotePair(@this.gid, i, j, k, 5);
								flag2 = true;
							}
							if (!flag2 && !flag)
							{
								@this.AddRouteRemotePair(@this.gid, i, j, k, 6);
								stationPool[j].AddRouteRemotePair(@this.gid, i, j, k, 6);
							}
						}
					}
				}
			}
			else
			{
				if (@this.storage[i].remoteLogic != ELogisticStorage.Demand)
				{
					continue;
				}
				int itemId2 = @this.storage[i].itemId;
				for (int l = 1; l < stationCursor; l++)
				{
					if (stationPool[l] == null || stationPool[l].gid != l || stationPool[l].planetId == @this.planetId)
					{
						continue;
					}
					StationStore[] storage3 = stationPool[l].storage;
					for (int m = 0; m < storage3.Length; m++)
					{
						if (itemId2 != storage3[m].itemId || storage3[m].remoteLogic != ELogisticStorage.Supply)
						{
							continue;
						}
						int planetId3 = @this.planetId;
						int planetId4 = stationPool[l].planetId;
						int astroId3 = planetId3 / 100 * 100;
						int astroId4 = planetId4 / 100 * 100;
						if (!galacticTransport.IsAstro2AstroBanExist(planetId3, planetId4, itemId2) && !galacticTransport.IsAstro2AstroBanExist(astroId3, astroId4, itemId2))
						{
							bool flag3 = stationPool[l].routePriority == ERemoteRoutePriority.Designated || @this.routePriority == ERemoteRoutePriority.Designated;
							if (!flag3)
							{
								@this.AddRemotePair(l, m, @this.gid, i);
								stationPool[l].AddRemotePair(l, m, @this.gid, i);
							}
							bool flag4 = false;
							if (galacticTransport.IsStation2StationRouteExist(@this.gid, stationPool[l].gid))
							{
								@this.AddRouteRemotePair(l, m, @this.gid, i, 2);
								stationPool[l].AddRouteRemotePair(l, m, @this.gid, i, 2);
								flag4 = true;
							}
							if (galacticTransport.IsAstro2AstroRouteEnable(planetId3, planetId4, itemId2))
							{
								@this.AddRouteRemotePair(l, m, @this.gid, i, 3);
								stationPool[l].AddRouteRemotePair(l, m, @this.gid, i, 3);
								flag4 = true;
							}
							if (galacticTransport.IsAstro2AstroRouteEnable(astroId3, astroId4, itemId2))
							{
								@this.AddRouteRemotePair(l, m, @this.gid, i, 4);
								stationPool[l].AddRouteRemotePair(l, m, @this.gid, i, 4);
								flag4 = true;
							}
							if ((@this.remoteGroupMask & stationPool[l].remoteGroupMask) > 0)
							{
								@this.AddRouteRemotePair(l, m, @this.gid, i, 5);
								stationPool[l].AddRouteRemotePair(l, m, @this.gid, i, 5);
								flag4 = true;
							}
							if (!flag4 && !flag3)
							{
								@this.AddRouteRemotePair(l, m, @this.gid, i, 6);
								stationPool[l].AddRouteRemotePair(l, m, @this.gid, i, 6);
							}
						}
					}
				}
			}
		}
	}

	public static void UpdateShipStatus(StationComponent @this, GalacticTransport galacticTransport, int keyStationGId, int shipCarries)
	{
		StationComponent[] stationPool = galacticTransport.stationPool;
		if (keyStationGId <= 0)
		{
			return;
		}
		for (int i = 0; i < @this.workShipCount; i++)
		{
			StationComponent stationComponent = stationPool[@this.workShipDatas[i].otherGId];
			StationStore[] array = stationComponent?.storage;
			if (keyStationGId == @this.gid)
			{
				if (@this.workShipDatas[i].itemCount == 0 && @this.workShipDatas[i].direction > 0 && @this.workShipDatas[i].otherGId > 0)
				{
					int itemId = @this.workShipDatas[i].itemId;
					if (@this.HasRemoteDemand(itemId) == -1)
					{
						if (@this.workShipOrders[i].itemId > 0)
						{
							if (@this.storage[@this.workShipOrders[i].thisIndex].itemId == @this.workShipOrders[i].itemId)
							{
								StationStore[] storage = @this.storage;
								int thisIndex = @this.workShipOrders[i].thisIndex;
								storage[thisIndex].remoteOrder = storage[thisIndex].remoteOrder - @this.workShipOrders[i].thisOrdered;
							}
							if (array != null && array[@this.workShipOrders[i].otherIndex].itemId == @this.workShipOrders[i].itemId)
							{
								StationStore[] array2 = array;
								int otherIndex = @this.workShipOrders[i].otherIndex;
								array2[otherIndex].remoteOrder = array2[otherIndex].remoteOrder - @this.workShipOrders[i].otherOrdered;
							}
							@this.workShipOrders[i].ClearThis();
							@this.workShipOrders[i].ClearOther();
						}
						@this.workShipDatas[i].itemId = 0;
						for (int j = 0; j < @this.storage.Length; j++)
						{
							if (@this.storage[j].remoteLogic == ELogisticStorage.Demand)
							{
								int num = stationComponent.HasRemoteSupply(@this.storage[j].itemId, 1);
								if (num >= 0 && @this.storage[j].remoteDemandCount > 0)
								{
									@this.workShipDatas[i].itemId = @this.storage[j].itemId;
									@this.workShipDatas[i].direction = 1;
									@this.workShipOrders[i].itemId = @this.workShipDatas[i].itemId;
									@this.workShipOrders[i].otherStationGId = @this.workShipDatas[i].otherGId;
									@this.workShipOrders[i].thisIndex = j;
									@this.workShipOrders[i].otherIndex = num;
									@this.workShipOrders[i].thisOrdered = shipCarries;
									@this.workShipOrders[i].otherOrdered = -shipCarries;
									StationStore[] storage2 = @this.storage;
									int num2 = j;
									storage2[num2].remoteOrder = storage2[num2].remoteOrder + shipCarries;
									StationStore[] array3 = array;
									int num3 = num;
									array3[num3].remoteOrder = array3[num3].remoteOrder - shipCarries;
									break;
								}
							}
						}
						if (@this.workShipDatas[i].itemId == 0)
						{
							@this.workShipDatas[i].otherGId = 0;
							@this.workShipDatas[i].direction = -1;
							if (@this.workShipDatas[i].stage == -1)
							{
								@this.workShipDatas[i].pPosTemp = @this.shipDiskPos[@this.workShipDatas[i].shipIndex] + @this.shipDiskPos[@this.workShipDatas[i].shipIndex].normalized * 25f;
							}
						}
					}
				}
				if (@this.workShipDatas[i].itemCount != 0 && @this.workShipDatas[i].direction < 0)
				{
					int itemId2 = @this.workShipDatas[i].itemId;
					if (@this.HasRemoteDemand(itemId2) == -1 && @this.workShipOrders[i].itemId > 0)
					{
						if (@this.storage[@this.workShipOrders[i].thisIndex].itemId == @this.workShipOrders[i].itemId)
						{
							StationStore[] storage3 = @this.storage;
							int thisIndex2 = @this.workShipOrders[i].thisIndex;
							storage3[thisIndex2].remoteOrder = storage3[thisIndex2].remoteOrder - @this.workShipOrders[i].thisOrdered;
						}
						if (array != null && array[@this.workShipOrders[i].otherIndex].itemId == @this.workShipOrders[i].itemId)
						{
							StationStore[] array4 = array;
							int otherIndex2 = @this.workShipOrders[i].otherIndex;
							array4[otherIndex2].remoteOrder = array4[otherIndex2].remoteOrder - @this.workShipOrders[i].otherOrdered;
						}
						@this.workShipOrders[i].ClearThis();
						@this.workShipOrders[i].ClearOther();
						@this.workShipOrders[i].itemId = itemId2;
					}
				}
			}
			if (keyStationGId != @this.workShipDatas[i].otherGId)
			{
				continue;
			}
			if ((stationPool[@this.workShipDatas[i].otherGId] == null || stationPool[@this.workShipDatas[i].otherGId].gid == 0) && @this.workShipDatas[i].direction > 0)
			{
				if (@this.workShipOrders[i].itemId > 0)
				{
					if (@this.storage[@this.workShipOrders[i].thisIndex].itemId == @this.workShipOrders[i].itemId)
					{
						StationStore[] storage4 = @this.storage;
						int thisIndex3 = @this.workShipOrders[i].thisIndex;
						storage4[thisIndex3].remoteOrder = storage4[thisIndex3].remoteOrder - @this.workShipOrders[i].thisOrdered;
					}
					@this.workShipOrders[i].ClearThis();
					@this.workShipOrders[i].ClearOther();
				}
				@this.workShipDatas[i].otherGId = 0;
				@this.workShipDatas[i].direction = -1;
			}
			else if ((stationPool[@this.workShipDatas[i].otherGId] == null || stationPool[@this.workShipDatas[i].otherGId].gid == 0) && @this.workShipDatas[i].direction < 0)
			{
				@this.workShipDatas[i].otherGId = 0;
				@this.workShipDatas[i].direction = -1;
			}
			else if (@this.workShipDatas[i].itemCount > 0 && @this.workShipDatas[i].direction > 0 && @this.workShipDatas[i].otherGId > 0)
			{
				if (stationComponent.HasRemoteDemand(@this.workShipDatas[i].itemId, 0) != -1)
				{
					continue;
				}
				if (@this.workShipOrders[i].itemId > 0)
				{
					if (@this.storage[@this.workShipOrders[i].thisIndex].itemId == @this.workShipOrders[i].itemId)
					{
						StationStore[] storage5 = @this.storage;
						int thisIndex4 = @this.workShipOrders[i].thisIndex;
						storage5[thisIndex4].remoteOrder = storage5[thisIndex4].remoteOrder - @this.workShipOrders[i].thisOrdered;
					}
					if (array[@this.workShipOrders[i].otherIndex].itemId == @this.workShipOrders[i].itemId)
					{
						StationStore[] array5 = array;
						int otherIndex3 = @this.workShipOrders[i].otherIndex;
						array5[otherIndex3].remoteOrder = array5[otherIndex3].remoteOrder - @this.workShipOrders[i].otherOrdered;
					}
					@this.workShipOrders[i].ClearThis();
					@this.workShipOrders[i].ClearOther();
				}
				@this.workShipDatas[i].otherGId = 0;
				@this.workShipDatas[i].direction = -1;
			}
			else
			{
				if (@this.workShipDatas[i].itemCount != 0 || @this.workShipDatas[i].direction <= 0 || @this.workShipDatas[i].otherGId <= 0)
				{
					continue;
				}
				int itemId3 = @this.workShipDatas[i].itemId;
				if (stationComponent.HasRemoteSupply(itemId3) != -1)
				{
					continue;
				}
				if (@this.workShipOrders[i].itemId > 0)
				{
					if (@this.storage[@this.workShipOrders[i].thisIndex].itemId == @this.workShipOrders[i].itemId)
					{
						StationStore[] storage6 = @this.storage;
						int thisIndex5 = @this.workShipOrders[i].thisIndex;
						storage6[thisIndex5].remoteOrder = storage6[thisIndex5].remoteOrder - @this.workShipOrders[i].thisOrdered;
					}
					if (array[@this.workShipOrders[i].otherIndex].itemId == @this.workShipOrders[i].itemId)
					{
						StationStore[] array6 = array;
						int otherIndex4 = @this.workShipOrders[i].otherIndex;
						array6[otherIndex4].remoteOrder = array6[otherIndex4].remoteOrder - @this.workShipOrders[i].otherOrdered;
					}
					@this.workShipOrders[i].ClearThis();
					@this.workShipOrders[i].ClearOther();
				}
				@this.workShipDatas[i].itemId = 0;
				for (int k = 0; k < @this.storage.Length; k++)
				{
					if (@this.storage[k].remoteLogic == ELogisticStorage.Demand)
					{
						int num4 = stationComponent.HasRemoteSupply(@this.storage[k].itemId, 1);
						if (num4 >= 0 && @this.storage[k].remoteDemandCount > 0)
						{
							@this.workShipDatas[i].itemId = @this.storage[k].itemId;
							@this.workShipDatas[i].direction = 1;
							@this.workShipOrders[i].itemId = @this.workShipDatas[i].itemId;
							@this.workShipOrders[i].otherStationGId = @this.workShipDatas[i].otherGId;
							@this.workShipOrders[i].thisIndex = k;
							@this.workShipOrders[i].otherIndex = num4;
							@this.workShipOrders[i].thisOrdered = shipCarries;
							@this.workShipOrders[i].otherOrdered = -shipCarries;
							StationStore[] storage7 = @this.storage;
							int num5 = k;
							storage7[num5].remoteOrder = storage7[num5].remoteOrder + shipCarries;
							StationStore[] array7 = array;
							int num6 = num4;
							array7[num6].remoteOrder = array7[num6].remoteOrder - shipCarries;
							break;
						}
					}
				}
				if (@this.workShipDatas[i].itemId == 0)
				{
					@this.workShipDatas[i].otherGId = 0;
					@this.workShipDatas[i].direction = -1;
				}
			}
		}
	}
}
