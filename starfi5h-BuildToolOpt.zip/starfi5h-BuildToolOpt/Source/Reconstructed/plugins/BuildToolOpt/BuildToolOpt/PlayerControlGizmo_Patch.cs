using HarmonyLib;
using UnityEngine;

namespace BuildToolOpt;

internal class PlayerControlGizmo_Patch
{
	private static int inhandItemId;

	private static float sqrtRange0;

	private static float sqrtRange1;

	private static readonly CircleGizmo[] prebuildRangeGizmo = new CircleGizmo[2];

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlayerControlGizmo), "SetPrebuildTarget")]
	public static void SetPrebuildTarget_Postfix(bool enable, Vector3 pos)
	{
		if (enable && prebuildRangeGizmo[0] == null)
		{
			for (int i = 0; i < 2; i++)
			{
				prebuildRangeGizmo[i] = CircleGizmo.Create(1, Vector3.one, 0.1f);
				prebuildRangeGizmo[i].autoRefresh = true;
				prebuildRangeGizmo[i].multiplier = 1f;
				prebuildRangeGizmo[i].alphaMultiplier = 0.8f;
				prebuildRangeGizmo[i].fadeInScale = 1.3f;
				prebuildRangeGizmo[i].fadeInTime = 0.13f;
				prebuildRangeGizmo[i].fadeInFalloff = 0.5f;
				prebuildRangeGizmo[i].color = Configs.builtin.gizmoColors[8];
				prebuildRangeGizmo[i].Open();
			}
		}
		if (!enable && prebuildRangeGizmo[0] != null)
		{
			for (int j = 0; j < 2; j++)
			{
				prebuildRangeGizmo[j].Close();
				prebuildRangeGizmo[j] = null;
			}
			inhandItemId = 0;
			sqrtRange0 = (sqrtRange1 = 0f);
		}
		if (!enable || !(prebuildRangeGizmo[0] != null))
		{
			return;
		}
		if (GameMain.mainPlayer.inhandItemId != inhandItemId)
		{
			inhandItemId = GameMain.mainPlayer.inhandItemId;
			ItemProto itemProto = LDB.items.Select(inhandItemId);
			if (itemProto != null && itemProto.prefabDesc.isStation)
			{
				sqrtRange0 = 1066f;
				sqrtRange1 = 234f;
			}
			else
			{
				sqrtRange0 = 0f;
				sqrtRange1 = 0f;
				prebuildRangeGizmo[0].position = (prebuildRangeGizmo[1].position = Vector3.one);
				prebuildRangeGizmo[0].radius = (prebuildRangeGizmo[1].radius = 0.1f);
			}
		}
		if (GameMain.localPlanet != null)
		{
			if (sqrtRange0 > 0f)
			{
				float realRadius = GameMain.localPlanet.realRadius;
				float value = 1f - sqrtRange0 / (2f * realRadius * realRadius);
				value = Mathf.Clamp(value, -1f, 1f);
				float num = Mathf.Sqrt(1f - value * value);
				prebuildRangeGizmo[0].position = pos / realRadius * (realRadius * value);
				prebuildRangeGizmo[0].radius = realRadius * num;
			}
			if (sqrtRange1 > 0f)
			{
				float realRadius2 = GameMain.localPlanet.realRadius;
				float value2 = 1f - sqrtRange1 / (2f * realRadius2 * realRadius2);
				value2 = Mathf.Clamp(value2, -1f, 1f);
				float num2 = Mathf.Sqrt(1f - value2 * value2);
				prebuildRangeGizmo[1].position = pos / realRadius2 * (realRadius2 * value2);
				prebuildRangeGizmo[1].radius = realRadius2 * num2;
			}
		}
	}
}
