using System;
using System.Linq;
using CommonAPI.Systems;
using HarmonyLib;
using UnityEngine;

namespace BuildToolOpt;

public static class UIBlueprintComponentItem_Patch
{
	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIBlueprintComponentItem), "_OnRegEvent")]
	public static void AddEvent(UIBlueprintComponentItem __instance)
	{
		__instance.button.onClick += GetAction(__instance.inspector);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIBlueprintComponentItem), "_OnUnregEvent")]
	public static void RemoveEvent(UIBlueprintComponentItem __instance)
	{
		__instance.button.onClick -= GetAction(__instance.inspector);
	}

	public static Action<int> GetAction(UIBlueprintInspector inspector)
	{
		return OnClick;
		void OnClick(int itemId)
		{
			UIItemPickerExtension.Popup(new Vector2(-300f, 238f), (Action<ItemProto>)delegate(ItemProto proto)
			{
				if (proto != null)
				{
					SetBuildings(inspector, itemId, proto);
				}
			}, (Func<ItemProto, bool>)((ItemProto proto) => proto.Upgrades?.Contains(itemId) ?? false));
		}
	}

	public static void SetBuildings(UIBlueprintInspector inspector, int oldItemId, ItemProto newItem)
	{
		BlueprintBuilding[] buildings = inspector.blueprint.buildings;
		foreach (BlueprintBuilding blueprintBuilding in buildings)
		{
			if (blueprintBuilding.itemId == oldItemId)
			{
				blueprintBuilding.itemId = (short)newItem.ID;
				blueprintBuilding.modelIndex = (short)newItem.ModelIndex;
			}
		}
		if (inspector.usage == UIBlueprintInspector.EUsage.Browser || inspector.usage == UIBlueprintInspector.EUsage.Paste)
		{
			if (inspector.usage == UIBlueprintInspector.EUsage.Paste)
			{
				inspector.pasteBuildTool.ResetStates();
			}
		}
		else if (inspector.usage == UIBlueprintInspector.EUsage.Copy)
		{
			_ = inspector.copyBuildTool.active;
		}
		inspector.Refresh(forModify: true, refreshComponent: true, refreshCode: true);
	}
}
