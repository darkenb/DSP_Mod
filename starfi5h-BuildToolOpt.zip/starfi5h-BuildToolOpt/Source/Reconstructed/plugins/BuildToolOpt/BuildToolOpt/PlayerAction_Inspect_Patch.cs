using HarmonyLib;

namespace BuildToolOpt;

internal class PlayerAction_Inspect_Patch
{
	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlayerAction_Inspect), "GameTick")]
	private static void GameTick_Postfix(PlayerAction_Inspect __instance)
	{
		if (VFInput.miningMachineKey && VFInput.readyToBuild && __instance.player.inhandItemId == 2301 && GameMain.history.ItemUnlocked(2316))
		{
			__instance.player.SetHandItems(2316, 0);
		}
	}
}
