using BepInEx;
using CommonAPI;
using CommonAPI.Systems;
using CommonAPI.Systems.ModLocalization;
using HarmonyLib;

namespace BuildToolOpt;

[BepInPlugin("starfi5h.plugin.BuildToolOpt.CAPIcompat", "BuildToolOptCAPIcompat", "1.0.0")]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInIncompatibility("org.kremnev8.plugin.BlueprintTweaks")]
[CommonAPISubmoduleDependency(new string[] { "PickerExtensionsSystem", "CustomKeyBindSystem", "LocalizationModule" })]
public class PluginCAPIcompat : BaseUnityPlugin
{
	public const string GUID = "starfi5h.plugin.BuildToolOpt.CAPIcompat";

	public const string NAME = "BuildToolOptCAPIcompat";

	public const string VERSION = "1.0.0";

	public void Awake()
	{
		Harmony harmony = new Harmony("starfi5h.plugin.BuildToolOpt.CAPIcompat");
		harmony.PatchAll(typeof(CameraFix_Patch));
		harmony.PatchAll(typeof(UIBlueprintComponentItem_Patch));
		CustomKeyBindSystem.RegisterKeyBind<PressKeyBind>(new BuiltinKey
		{
			key = new CombineKey(106, 0, ECombineKeyAction.OnceClick, _noneKey: false),
			conflictGroup = 3071,
			name = "ToggleBPViewModeBTO",
			canOverride = true
		});
		LocalizationModule.RegisterTranslation("KEYToggleBPViewModeBTO", "(BuildToolOpt) Toggle Blueprint View Mode", "(BuildToolOpt) 切换蓝图模式视角", "");
	}

	public void Update()
	{
		if (!VFInput.inputing && GameMain.mainPlayer != null && GameMain.mainPlayer.controller.actionBuild.blueprintMode != EBlueprintMode.None && CustomKeyBindSystem.GetKeyBind("ToggleBPViewModeBTO").keyValue)
		{
			CameraFix_Patch.Enable = !CameraFix_Patch.Enable;
			base.Logger.LogDebug("Switch Blueprint Mode:" + CameraFix_Patch.Enable);
		}
	}
}
