using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;

namespace BuildToolOpt;

public class BuildTool_Inserter_Patch
{
	[HarmonyTranspiler]
	[HarmonyAfter(new string[] { "com.hetima.dsp.LongSorter" })]
	[HarmonyPatch(typeof(BuildTool_Inserter), "DeterminePreviews")]
	public static IEnumerable<CodeInstruction> DeterminePreviews_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(true, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(BuildTool_Inserter), "castObjectId")), new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch(OpCodes.Ble)).SetOpcodeAndAdvance(OpCodes.Beq);
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(BuildTool_Inserter), "startObjectId")), new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch(OpCodes.Ble));
			for (int i = 0; i < 6; i++)
			{
				codeMatcher.SetAndAdvance(OpCodes.Nop, null);
			}
			codeMatcher.RemoveInstructions(2).Insert(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(BuildTool_Inserter_Patch), "AddPrebuildBeltSlot")));
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(BuildTool), "ObjectIsBelt"))).Repeat(delegate(CodeMatcher matcher)
			{
				matcher.SetAndAdvance(OpCodes.Call, AccessTools.Method(typeof(BuildTool_Inserter_Patch), "ObjectIsBeltEntity"));
			});
			return codeMatcher.InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler BuildTool_Inserter.DeterminePreviews error");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	private static bool ObjectIsBeltEntity(BuildTool_Inserter @this, int objId)
	{
		if (objId <= 0)
		{
			return false;
		}
		return @this.factory.entityPool[objId].beltId > 0;
	}

	private static void AddPrebuildBeltSlot(BuildTool_Inserter @this)
	{
		if (@this.startObjectId < 0 && @this.ObjectIsBelt(@this.startObjectId))
		{
			Pose[] belt_slots = @this.belt_slots;
			BuildTool_Inserter.SlotPoint item = default(BuildTool_Inserter.SlotPoint);
			foreach (Pose pose in belt_slots)
			{
				item.objId = @this.startObjectId;
				ref PrebuildData reference = ref @this.factory.prebuildPool[-@this.startObjectId];
				item.pose = pose.GetTransformedBy(new Pose(reference.pos, reference.rot));
				item.slotIdx = -1;
				@this.startSlots.Add(item);
			}
		}
		if (@this.castObjectId < 0 && @this.ObjectIsBelt(@this.castObjectId))
		{
			Pose[] belt_slots = @this.belt_slots;
			BuildTool_Inserter.SlotPoint item2 = default(BuildTool_Inserter.SlotPoint);
			foreach (Pose pose2 in belt_slots)
			{
				item2.objId = @this.castObjectId;
				ref PrebuildData reference2 = ref @this.factory.prebuildPool[-@this.castObjectId];
				item2.pose = pose2.GetTransformedBy(new Pose(reference2.pos, reference2.rot));
				item2.slotIdx = -1;
				@this.endSlots.Add(item2);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(BuildTool_Inserter), "CheckBuildConditions")]
	public static void BuildTool_Inserter_CheckBuildConditions_Postfix(BuildTool_Inserter __instance, ref bool __result)
	{
		if (__result || __instance.buildPreviews.Count != 1)
		{
			return;
		}
		BuildPreview buildPreview = __instance.buildPreviews[0];
		if (buildPreview.condition == EBuildCondition.Collide && (buildPreview.inputObjId < 0 || buildPreview.outputObjId < 0))
		{
			__result = true;
			buildPreview.condition = EBuildCondition.Ok;
			__instance.actionBuild.model.cursorText = buildPreview.conditionText;
			__instance.actionBuild.model.cursorState = 0;
			if (!VFInput.onGUI)
			{
				UICursor.SetCursor(ECursor.Default);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(BuildTool_Inserter), "DeterminePreviews")]
	public static void PrebuildCorrection(BuildTool_Inserter __instance)
	{
		if (__instance.buildPreviews.Count != 1 || (__instance.startObjectId >= 0 && __instance.castObjectId >= 0))
		{
			return;
		}
		bool flag = __instance.startObjectId < 0 && __instance.ObjectIsBelt(__instance.startObjectId);
		bool flag2 = __instance.castObjectId < 0 && __instance.ObjectIsBelt(__instance.castObjectId);
		BuildPreview buildPreview = __instance.buildPreviews[0];
		if (buildPreview.condition == EBuildCondition.TooSkew)
		{
			if (flag && !flag2 && __instance.endSlots.Count > 0)
			{
				Vector3 position = __instance.startSlots[0].pose.position;
				List<BuildTool_Inserter.SlotPoint> endSlots = __instance.endSlots;
				int index = 0;
				float num = float.MaxValue;
				for (int i = 0; i < endSlots.Count; i++)
				{
					float num2 = Vector3.SqrMagnitude(endSlots[i].pose.position - position);
					if (num2 < num)
					{
						num = num2;
						index = i;
					}
				}
				buildPreview.lpos2 = endSlots[index].pose.position;
				buildPreview.lrot2 = endSlots[index].pose.rotation * Quaternion.Euler(0f, 180f, 0f);
				buildPreview.outputToSlot = endSlots[index].slotIdx;
				buildPreview.lrot = buildPreview.lrot2;
			}
			if (!flag && flag2 && __instance.startSlots.Count > 0)
			{
				Vector3 position2 = __instance.endSlots[0].pose.position;
				List<BuildTool_Inserter.SlotPoint> startSlots = __instance.startSlots;
				int index2 = 0;
				float num3 = float.MaxValue;
				for (int j = 0; j < startSlots.Count; j++)
				{
					float num4 = Vector3.SqrMagnitude(startSlots[j].pose.position - position2);
					float num5 = Vector3.Angle(position2 - startSlots[j].pose.position, startSlots[j].pose.forward);
					if (num4 < num3 && num5 < 40f)
					{
						num3 = num4;
						index2 = j;
					}
				}
				buildPreview.lpos = startSlots[index2].pose.position;
				buildPreview.lrot = startSlots[index2].pose.rotation;
				buildPreview.inputFromSlot = startSlots[index2].slotIdx;
				buildPreview.lrot2 = buildPreview.lrot;
			}
			_ = flag && flag2;
			buildPreview.condition = EBuildCondition.Ok;
		}
		if (buildPreview.condition == EBuildCondition.Ok)
		{
			UIInserterBuildTip inserterBuildTip = __instance.uiGame.inserterBuildTip;
			inserterBuildTip.direction = (buildPreview.lpos2 - buildPreview.lpos).normalized;
			inserterBuildTip.position = (buildPreview.lpos + buildPreview.lpos2) * 0.5f;
			inserterBuildTip.position1 = buildPreview.lpos;
			inserterBuildTip.position2 = buildPreview.lpos2;
			if (flag && !flag2)
			{
				inserterBuildTip.input = true;
				inserterBuildTip.output = false;
				inserterBuildTip.outputBelt = true;
				inserterBuildTip.inputBelt = false;
			}
			if (!flag && flag2)
			{
				inserterBuildTip.output = true;
				inserterBuildTip.input = false;
				inserterBuildTip.inputBelt = true;
				inserterBuildTip.outputBelt = false;
			}
		}
	}
}
