using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;

namespace BuildToolOpt;

internal class UIBlueprint_Patch
{
	[HarmonyPrefix]
	[HarmonyPatch(typeof(BlueprintData), "Clone")]
	public static bool BlueprintData_Clone(BlueprintData __instance, ref BlueprintData __result)
	{
		__result = new BlueprintData();
		__result.HeaderFromBase64String(__instance.headerStr);
		using (MemoryStream memoryStream = new MemoryStream())
		{
			using BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
			__instance.Export(binaryWriter);
			binaryWriter.Flush();
			memoryStream.Position = 0L;
			using BinaryReader r = new BinaryReader(memoryStream);
			__result.Import(r);
		}
		if (!__result.isValid)
		{
			Plugin.Log.LogWarning("BlueprintData Clone is invalid!");
			__result = null;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPriority(200)]
	[HarmonyPatch(typeof(UIBlueprintFileItem), "OnThisClick")]
	public static bool UIBlueprintFileItem_OnThisClick(UIBlueprintFileItem __instance)
	{
		if (__instance.time - __instance.lastClickTime < 0.5f * Time.timeScale)
		{
			VFAudio.Create("ui-click-0", null, Vector3.zero, play: true, 1, -1, -1L);
			__instance.browser.inspector._Close();
			__instance.browser.boolInspector._Close();
			__instance.lastClickTime = -1f;
			__instance.OnThisDoubleClick();
			return false;
		}
		return true;
	}

	[HarmonyTranspiler]
	[HarmonyPriority(200)]
	[HarmonyPatch(typeof(UIBlueprintInspector), "_OnOpen")]
	public static IEnumerable<CodeInstruction> UIBlueprintInspector_OnOpen(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			return new CodeMatcher(instructions).MatchForward(true, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch(OpCodes.Ldc_I4_1), new CodeMatch(OpCodes.Ldc_I4_1), new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Call && ((MethodInfo)i.operand).Name == "Refresh")).Advance(-2).SetOpcodeAndAdvance(OpCodes.Ldc_I4_0)
				.End()
				.Insert(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(UIBlueprint_Patch), "UpdateCodeFromFile")))
				.InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler UIBlueprintInspector._OnOpen fail!");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	private static void UpdateCodeFromFile(UIBlueprintInspector __instance)
	{
		__instance.shareLengthText.text = "";
		__instance.shareCodeText.text = "";
		string text = GameConfig.blueprintFolder + __instance.newPath + ".txt";
		if (!File.Exists(text))
		{
			return;
		}
		try
		{
			FileInfo fileInfo = new FileInfo(text);
			__instance.shareLengthText.text = string.Format("几字节".Translate(), fileInfo.Length);
			char[] array = new char[256];
			using (StreamReader streamReader = new StreamReader(text))
			{
				streamReader.ReadBlock(array, 0, array.Length);
			}
			__instance.shareCodeText.text = new string(array);
		}
		catch (Exception ex)
		{
			Plugin.Log.LogWarning("UIBlueprintInspector_OnOpen: " + ex);
		}
	}
}
