using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;

namespace BuildToolOpt;

public static class CameraFix_Patch
{
	public static bool Enable;

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(GameCamera), "Logic")]
	[HarmonyPatch(typeof(PlayerMove_Drift), "GameTick")]
	[HarmonyPatch(typeof(PlayerMove_Fly), "GameTick")]
	[HarmonyPatch(typeof(PlayerMove_Walk), "GameTick")]
	private static IEnumerable<CodeInstruction> ModeReplace(IEnumerable<CodeInstruction> instructions)
	{
		return new CodeMatcher(instructions).MatchForward(true, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(PlayerController), "actionBuild")), new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(PlayerAction_Build), "get_blueprintMode"))).Advance(1).InsertAndAdvance(Transpilers.EmitDelegate<Func<EBlueprintMode, EBlueprintMode>>((EBlueprintMode mode) => (!Enable) ? mode : EBlueprintMode.None))
			.InstructionEnumeration();
	}
}
