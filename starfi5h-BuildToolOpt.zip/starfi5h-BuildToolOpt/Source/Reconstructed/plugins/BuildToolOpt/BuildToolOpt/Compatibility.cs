using System;
using BepInEx.Bootstrap;
using DSPCalculator.Logic;
using DSPCalculator.UI;
using HarmonyLib;
using UnityEngine.UI;

namespace BuildToolOpt;

public class Compatibility
{
	public static class Nebula_Patch
	{
		public const string GUID = "dsp.nebula-multiplayer";

		public static void Init()
		{
			if (Chainloader.PluginInfos.TryGetValue("dsp.nebula-multiplayer", out var _))
			{
				Plugin.EnableReplaceStation = false;
				Plugin.EnableHologram = false;
				Plugin.EnableStationBuildOptimize = false;
				Plugin.Log.LogDebug("Nebula: Disable replace station and hologram function");
			}
		}
	}

	public static class CheatEnabler_Patch
	{
		public const string GUID = "org.soardev.cheatenabler";

		public static void Init(Harmony harmony)
		{
			if (!Chainloader.PluginInfos.TryGetValue("org.soardev.cheatenabler", out var value))
			{
				return;
			}
			try
			{
				Type type = value.Instance.GetType().Assembly.GetType("CheatEnabler.Patches.FactoryPatch");
				harmony.Patch(AccessTools.Method(type, "ArrivePlanet"), new HarmonyMethod(AccessTools.Method(typeof(CheatEnabler_Patch), "ArrivePlanet_Prefix")));
			}
			catch (Exception data)
			{
				Plugin.Log.LogWarning("CheatEnabler compatibility failed! Last working version: 2.4.0");
				Plugin.Log.LogWarning(data);
			}
		}

		internal static bool ArrivePlanet_Prefix()
		{
			return !ReplaceStationLogic.IsReplacing;
		}
	}

	public static class DSPCalculator_Patch
	{
		private class Warpper
		{
			[HarmonyPostfix]
			[HarmonyPatch(typeof(UIItemNode), MethodType.Constructor, new Type[]
			{
				typeof(ItemNode),
				typeof(UICalcWindow)
			})]
			public static void UIItemNode_Postfix(UIItemNode __instance)
			{
				if (!(__instance.assemblerIconObj == null))
				{
					__instance.assemblerIconObj.GetComponent<Button>().onClick.AddListener(delegate
					{
						OnAssemblerIconClick(__instance);
					});
				}
			}

			public static void OnAssemblerIconClick(UIItemNode @this)
			{
				if (VFInput.shift && VFInput.readyToBuild)
				{
					RecipeInfo mainRecipe = @this.itemNode.mainRecipe;
					if (mainRecipe != null)
					{
						int assemblerItemId = mainRecipe.assemblerItemId;
						int iD = mainRecipe.recipeNorm.oriProto.ID;
						bool flag = !mainRecipe.isInc || !mainRecipe.canInc;
						Plugin.Log.LogDebug($"SetHandBuilding protoId={assemblerItemId} recipeId={iD} forceAcc={flag}");
						SetHandBuilding(assemblerItemId, iD, flag);
					}
				}
			}

			public static void SetHandBuilding(int protoId, int recipeId, bool forceAccMode)
			{
				Player mainPlayer = GameMain.mainPlayer;
				if (mainPlayer == null || protoId <= 0)
				{
					return;
				}
				if (mainPlayer.inhandItemId > 0)
				{
					mainPlayer.SetHandItems(0, 0);
				}
				mainPlayer.SetHandItems(protoId, 0);
				mainPlayer.controller.cmd.type = ECommand.Build;
				VFInput.UseMouseLeft();
				BuildingParameters.template.SetEmpty();
				BuildingParameters.template.type = BuildingType.Other;
				BuildingParameters.template.itemId = protoId;
				BuildingParameters.template.modelIndex = LDB.items.Select(protoId).ModelIndex;
				if (recipeId > 0)
				{
					ERecipeType type = LDB.recipes.Select(recipeId).Type;
					if (type == ERecipeType.Research)
					{
						BuildingParameters.template.type = BuildingType.Lab;
						BuildingParameters.template.recipeId = recipeId;
						BuildingParameters.template.recipeType = type;
						BuildingParameters.template.mode0 = 1;
						BuildingParameters.template.mode1 = (forceAccMode ? 1 : 0);
						UIRealtimeTip.Popup(LDB.recipes.Select(recipeId).name + " " + (forceAccMode ? "加速生产".Translate() : "额外产出".Translate()), sound: false);
					}
					else
					{
						BuildingParameters.template.type = BuildingType.Assembler;
						BuildingParameters.template.recipeId = recipeId;
						BuildingParameters.template.recipeType = type;
						BuildingParameters.template.parameters = new int[1];
						BuildingParameters.template.parameters[0] = (forceAccMode ? 1 : 0);
						UIRealtimeTip.Popup(LDB.recipes.Select(recipeId).name + " " + (forceAccMode ? "加速生产".Translate() : "额外产出".Translate()), sound: false);
					}
				}
				mainPlayer.controller.actionBuild.NotifyTemplateChange();
			}
		}

		public const string GUID = "com.GniMaerd.DSPCalculator";

		public static void Init(Harmony harmony)
		{
			if (!Chainloader.PluginInfos.ContainsKey("com.GniMaerd.DSPCalculator"))
			{
				return;
			}
			try
			{
				harmony.PatchAll(typeof(Warpper));
			}
			catch (Exception data)
			{
				Plugin.Log.LogWarning("DSPCalculator compatibility failed! Last working version: 0.5.19");
				Plugin.Log.LogWarning(data);
			}
		}
	}

	public static void Init(Harmony harmony)
	{
		Nebula_Patch.Init();
		CheatEnabler_Patch.Init(harmony);
		DSPCalculator_Patch.Init(harmony);
	}
}
