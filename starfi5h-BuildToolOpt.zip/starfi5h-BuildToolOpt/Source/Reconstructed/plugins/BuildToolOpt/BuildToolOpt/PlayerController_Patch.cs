using HarmonyLib;
using UnityEngine;

namespace BuildToolOpt;

internal class PlayerController_Patch
{
	private static int clipboardLength;

	private static int hashCode;

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlayerController), "UpdateCommandState")]
	public static void UpdateCommandState_Prefix(PlayerController __instance)
	{
		if (!VFInput.readyToBuild || !VFInput._pasteBlueprintKey || !VFInput.inScreen || GameMain.history.blueprintLimit <= 0 || (__instance.actionBuild.blueprintMode == EBlueprintMode.Copy && !BlueprintData.IsNullOrEmpty(__instance.actionBuild.blueprintCopyTool.blueprint)))
		{
			return;
		}
		string systemCopyBuffer = GUIUtility.systemCopyBuffer;
		if (clipboardLength == systemCopyBuffer?.Length && hashCode == systemCopyBuffer?.GetHashCode())
		{
			return;
		}
		if (string.IsNullOrEmpty(systemCopyBuffer))
		{
			clipboardLength = 0;
			hashCode = 0;
			return;
		}
		clipboardLength = systemCopyBuffer.Length;
		hashCode = systemCopyBuffer.GetHashCode();
		BlueprintData blueprintData = new BlueprintData();
		blueprintData.FromBase64String(systemCopyBuffer);
		if (blueprintData.isValid)
		{
			__instance.actionBuild.blueprintClipboard = blueprintData;
			UIRealtimeTip.Popup($"Parse {clipboardLength:N0} from clipboard!", sound: false);
		}
	}
}
