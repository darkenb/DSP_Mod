using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace BuildToolOpt;

public static class RemoveGC_Patch
{
	[HarmonyTranspiler]
	[HarmonyPatch(typeof(BuildTool_Click), "CreatePrebuilds")]
	[HarmonyPatch(typeof(BuildTool_Path), "CreatePrebuilds")]
	[HarmonyPatch(typeof(BuildTool_Addon), "CreatePrebuilds")]
	[HarmonyPatch(typeof(BuildTool_Inserter), "CreatePrebuilds")]
	[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "CreatePrebuilds")]
	public static IEnumerable<CodeInstruction> RemoveGC_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions).End();
		for (int i = 0; i < 5; i++)
		{
			codeMatcher.Advance(-1);
			if (codeMatcher.Opcode == OpCodes.Call && ((MethodInfo)codeMatcher.Operand).Name == "Collect")
			{
				codeMatcher.SetOpcodeAndAdvance(OpCodes.Nop);
				break;
			}
		}
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(DSPGame), "EndGame")]
	public static void GCCollect()
	{
		GC.Collect();
	}
}
