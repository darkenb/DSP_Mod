using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace BuildToolOpt;

public class BuildTool_Patch
{
	public static int GetItemCountDummy(StorageComponent _, int itemId)
	{
		return 999;
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(UIBuildMenu), "OnChildButtonClick")]
	public static IEnumerable<CodeInstruction> OnBuildingButtonClick_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			return new CodeMatcher(instructions).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Callvirt && ((MethodInfo)i.operand).Name == "GetItemCount")).Repeat(delegate(CodeMatcher matcher)
			{
				matcher.SetAndAdvance(OpCodes.Call, AccessTools.Method(typeof(BuildTool_Patch), "GetItemCountDummy"));
			}).InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler UIBuildMenu.OnChildButtonClick error");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	[HarmonyTranspiler]
	[HarmonyAfter(new string[] { "dsp.nebula-multiplayer" })]
	[HarmonyPriority(200)]
	[HarmonyPatch(typeof(BuildTool_Click), "CheckBuildConditions")]
	[HarmonyPatch(typeof(BuildTool_Inserter), "CheckBuildConditions")]
	[HarmonyPatch(typeof(BuildTool_Addon), "CheckBuildConditions")]
	[HarmonyPatch(typeof(BuildTool_Path), "CheckBuildConditions")]
	public static IEnumerable<CodeInstruction> CheckBuildConditions_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(false, new CodeMatch(OpCodes.Ldc_I4_2), new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(BuildPreview), "condition")));
			if (codeMatcher.IsInvalid)
			{
				Plugin.Log.LogWarning("Can't find EBuildCondition.NotEnoughItem");
				return instructions;
			}
			codeMatcher.Advance(-1).SetAndAdvance(OpCodes.Nop, null).SetAndAdvance(OpCodes.Nop, null)
				.SetAndAdvance(OpCodes.Nop, null);
			if (codeMatcher.Opcode == OpCodes.Br)
			{
				codeMatcher.RemoveInstruction();
			}
			return codeMatcher.InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler BuildTool.CheckBuildConditions error");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	[HarmonyTranspiler]
	[HarmonyAfter(new string[] { "dsp.nebula-multiplayer" })]
	[HarmonyPriority(200)]
	[HarmonyPatch(typeof(BuildTool_Click), "CreatePrebuilds")]
	[HarmonyPatch(typeof(BuildTool_Inserter), "CreatePrebuilds")]
	[HarmonyPatch(typeof(BuildTool_Addon), "CreatePrebuilds")]
	[HarmonyPatch(typeof(BuildTool_Path), "CreatePrebuilds")]
	public static IEnumerable<CodeInstruction> CreatePrebuilds_Transpiler(IEnumerable<CodeInstruction> instructions, MethodBase __originalMethod)
	{
		try
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(true, new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(PlanetFactory), "AddPrebuildDataWithComponents")));
			if (!codeMatcher.IsInvalid)
			{
				List<CodeInstruction> list = codeMatcher.InstructionsInRange(codeMatcher.Pos - 4, codeMatcher.Pos + 2);
				switch (__originalMethod.DeclaringType.Name)
				{
				case "BuildTool_Click":
					ToLdloca(list[3]);
					list[4] = new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(BuildTool_Patch), "AddPrebuildData_Click"));
					break;
				case "BuildTool_Inserter":
					ToLdloca(list[3]);
					list[4] = new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(BuildTool_Patch), "AddPrebuildData_Inserter"));
					list.Insert(0, list[0]);
					break;
				case "BuildTool_Path":
					ToLdloca(list[3]);
					list[4] = new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(BuildTool_Patch), "AddPrebuildData_Addon"));
					list.Insert(0, list[0]);
					break;
				case "BuildTool_Addon":
					ToLdloca(list[3]);
					list[4] = new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(BuildTool_Patch), "AddPrebuildData_Path"));
					list.RemoveAt(2);
					list.Insert(0, list[0]);
					break;
				}
				codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(Assert), "CannotBeReached"))).Advance(1);
				do
				{
					codeMatcher.RemoveInstruction();
				}
				while (!(codeMatcher.Opcode == OpCodes.Call) || !(((MethodInfo)codeMatcher.Operand).Name == "Popup"));
				codeMatcher.RemoveInstruction();
				codeMatcher.Insert(list);
			}
			if (Plugin.EnableRemoveGC)
			{
				codeMatcher.End();
				for (int i = 0; i < 5; i++)
				{
					codeMatcher.Advance(-1);
					if (codeMatcher.Opcode == OpCodes.Call && ((MethodInfo)codeMatcher.Operand).Name == "Collect")
					{
						codeMatcher.SetOpcodeAndAdvance(OpCodes.Nop);
						break;
					}
				}
			}
			return codeMatcher.InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler CreatePrebuilds error");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	private static void ToLdloca(CodeInstruction code)
	{
		if (code.opcode == OpCodes.Ldloc_3)
		{
			code.operand = (sbyte)3;
		}
		else if (code.opcode == OpCodes.Ldloc_2)
		{
			code.operand = (sbyte)2;
		}
		else if (code.opcode == OpCodes.Ldloc_1)
		{
			code.operand = (sbyte)1;
		}
		else if (code.opcode == OpCodes.Ldloc_0)
		{
			code.operand = (sbyte)0;
		}
		code.opcode = OpCodes.Ldloca_S;
	}

	public static int AddPrebuildData_Click(PlanetFactory factory, ref PrebuildData prebuildData)
	{
		prebuildData.itemRequired = 1;
		return factory.AddPrebuildDataWithComponents(prebuildData);
	}

	public static int AddPrebuildData_Inserter(BuildPreview buildPreview, PlanetFactory factory, ref PrebuildData prebuildData)
	{
		if (buildPreview.coverObjId != 0)
		{
			return 0;
		}
		prebuildData.itemRequired = 1;
		return factory.AddPrebuildDataWithComponents(prebuildData);
	}

	public static int AddPrebuildData_Addon(BuildPreview buildPreview, PlanetFactory factory, ref PrebuildData prebuildData)
	{
		prebuildData.itemRequired = 1;
		int num = factory.AddPrebuildDataWithComponents(prebuildData);
		if (num != 0 && (buildPreview.desc.isSpraycoster || buildPreview.desc.isDispenser || buildPreview.desc.isTurret))
		{
			if (buildPreview.outputObjId != 0)
			{
				factory.WriteObjectConn(buildPreview.objId, buildPreview.outputFromSlot, isOutput: true, buildPreview.outputObjId, buildPreview.outputToSlot);
			}
			else if (buildPreview.output != null)
			{
				factory.WriteObjectConn(buildPreview.objId, buildPreview.outputFromSlot, isOutput: true, buildPreview.output.objId, buildPreview.outputToSlot);
			}
			if (buildPreview.inputObjId != 0)
			{
				factory.WriteObjectConn(buildPreview.objId, buildPreview.inputToSlot, isOutput: false, buildPreview.inputObjId, buildPreview.inputFromSlot);
				return num;
			}
			if (buildPreview.input != null)
			{
				factory.WriteObjectConn(buildPreview.objId, buildPreview.inputToSlot, isOutput: false, buildPreview.input.objId, buildPreview.inputFromSlot);
			}
		}
		return num;
	}

	public static int AddPrebuildData_Path(BuildPreview buildPreview, BuildTool_Path @this, ref PrebuildData prebuildData)
	{
		if (buildPreview.coverObjId != 0 && !buildPreview.willRemoveCover)
		{
			UIRealtimeTip.Popup("物品不足".Translate(), sound: true, 1);
			return 0;
		}
		prebuildData.itemRequired = 1;
		int result = 0;
		PlanetFactory factory = @this.factory;
		if (buildPreview.coverObjId == 0)
		{
			result = factory.AddPrebuildDataWithComponents(prebuildData);
		}
		else if (buildPreview.willRemoveCover)
		{
			int coverObjId = buildPreview.coverObjId;
			bool isOutput;
			if (ObjectIsBelt(factory, coverObjId))
			{
				for (int i = 0; i < 4; i++)
				{
					factory.ReadObjectConn(coverObjId, i, out isOutput, out var otherObjId, out var otherSlot);
					int num = otherObjId;
					if (num == 0 || !ObjectIsBelt(factory, num))
					{
						continue;
					}
					bool flag = false;
					for (int j = 0; j < 2; j++)
					{
						factory.ReadObjectConn(num, j, out isOutput, out otherObjId, out otherSlot);
						if (otherObjId != 0)
						{
							bool num2 = ObjectIsBelt(factory, otherObjId);
							bool flag2 = ObjectIsInserter(factory, otherObjId);
							if (!num2 && !flag2)
							{
								flag = true;
								break;
							}
						}
					}
					if (flag)
					{
						@this.tmp_links.Add(num);
					}
				}
			}
			if (buildPreview.coverObjId > 0)
			{
				Array.Copy(factory.entityConnPool, buildPreview.coverObjId * 16, @this.tmp_conn, 0, 16);
				for (int k = 0; k < 16; k++)
				{
					factory.ReadObjectConn(buildPreview.coverObjId, k, out isOutput, out var otherObjId2, out var otherSlot2);
					if (otherObjId2 > 0)
					{
						factory.ApplyEntityDisconnection(otherObjId2, buildPreview.coverObjId, otherSlot2, k);
					}
				}
				Array.Clear(@this.factory.entityConnPool, buildPreview.coverObjId * 16, 16);
			}
			else
			{
				Array.Copy(factory.prebuildConnPool, -buildPreview.coverObjId * 16, @this.tmp_conn, 0, 16);
				Array.Clear(factory.prebuildConnPool, -buildPreview.coverObjId * 16, 16);
			}
			result = factory.AddPrebuildDataWithComponents(prebuildData);
			if (buildPreview.objId > 0)
			{
				Array.Copy(@this.tmp_conn, 0, factory.entityConnPool, buildPreview.objId * 16, 16);
			}
			else
			{
				Array.Copy(@this.tmp_conn, 0, factory.prebuildConnPool, -buildPreview.objId * 16, 16);
			}
			factory.EnsureObjectConn(buildPreview.objId);
		}
		else
		{
			buildPreview.objId = buildPreview.coverObjId;
		}
		return result;
	}

	private static bool ObjectIsBelt(PlanetFactory factory, int objId)
	{
		if (objId == 0)
		{
			return false;
		}
		if (objId > 0)
		{
			return factory.entityPool[objId].beltId > 0;
		}
		return LDB.items.Select(factory.prebuildPool[-objId].protoId)?.prefabDesc.isBelt ?? false;
	}

	private static bool ObjectIsInserter(PlanetFactory factory, int objId)
	{
		if (objId == 0)
		{
			return false;
		}
		if (objId > 0)
		{
			return factory.entityPool[objId].inserterId > 0;
		}
		return LDB.items.Select(factory.prebuildPool[-objId].protoId)?.prefabDesc.isInserter ?? false;
	}
}
