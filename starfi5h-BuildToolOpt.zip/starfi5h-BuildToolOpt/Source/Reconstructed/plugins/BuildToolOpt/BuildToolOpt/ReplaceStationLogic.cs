using System;
using HarmonyLib;

namespace BuildToolOpt;

internal class ReplaceStationLogic
{
	private struct StationState
	{
		public long energy;

		public int warperCount;

		public int droneCount;

		public int shipCount;

		public StationStore[] storage;
	}

	private static int stationId;

	private static PlanetTransport replacingTransport;

	private static int replacingStationId;

	public static bool IsReplacing { get; private set; }

	[HarmonyPostfix]
	[HarmonyPatch(typeof(BuildTool_Click), "CheckBuildConditions")]
	public static void BuildTool_Click_CheckBuildConditions_Postfix(BuildTool_Click __instance, ref bool __result)
	{
		stationId = 0;
		if (__instance.buildPreviews.Count != 1)
		{
			return;
		}
		BuildPreview buildPreview = __instance.buildPreviews[0];
		if (!buildPreview.desc.isStation || buildPreview.condition != EBuildCondition.Collide || buildPreview.desc.isVeinCollector || buildPreview.desc.isCollectStation)
		{
			return;
		}
		int overlapStationEntityId = GetOverlapStationEntityId(__instance);
		if (overlapStationEntityId > 0)
		{
			ref EntityData reference = ref __instance.factory.entityPool[overlapStationEntityId];
			stationId = reference.stationId;
			buildPreview.lpos = reference.pos;
			buildPreview.lrot = reference.rot;
			buildPreview.condition = EBuildCondition.Ok;
			if (!VFInput.onGUI)
			{
				UICursor.SetCursor(ECursor.Default);
			}
			__result = true;
			EBuildCondition realStationCondition = GetRealStationCondition(__instance, buildPreview);
			__instance.actionBuild.model.cursorState = ((realStationCondition != EBuildCondition.Ok) ? (-1) : 0);
			__instance.actionBuild.model.cursorText = BuildPreview.GetConditionText(realStationCondition);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(BuildTool_Click), "ConfirmOperation")]
	public static void ConfirmOperation_Postfix(BuildTool_Click __instance, ref bool __result)
	{
		if (__result && stationId > 0)
		{
			ReplaceStation(__instance, stationId);
			__result = false;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlanetTransport), "TakeBackItems_Station")]
	public static void TakeBackItems_Station(PlanetTransport __instance, int stationId, ref bool __runOriginal)
	{
		if (!__runOriginal || !IsReplacing || __instance != replacingTransport || stationId != replacingStationId)
		{
			return;
		}
		__runOriginal = false;
		if (stationId == 0)
		{
			return;
		}
		StationComponent stationComponent = __instance.GetStationComponent(stationId);
		if (stationComponent == null || stationComponent.id != stationId)
		{
			return;
		}
		StationStore[] storage = stationComponent.storage;
		int num = ((storage != null) ? storage.Length : 0);
		for (int i = 0; i < num; i++)
		{
			if (stationComponent.storage[i].count > 0 && stationComponent.storage[i].itemId > 0)
			{
				stationComponent.storage[i].count = 0;
				stationComponent.storage[i].inc = 0;
			}
		}
		stationComponent.idleDroneCount = 0;
		stationComponent.idleShipCount = 0;
		stationComponent.warperCount = 0;
	}

	private static int GetOverlapStationEntityId(BuildTool_Click tool)
	{
		PlanetPhysics physics = tool.player.planetData.physics;
		for (int i = 0; i < BuildTool._tmp_cols.Length && BuildTool._tmp_cols[i] != null; i++)
		{
			if (physics.GetColliderData(BuildTool._tmp_cols[i], out var cd) && cd.objType == EObjectType.None && tool.factory.entityPool[cd.objId].stationId > 0)
			{
				return cd.objId;
			}
		}
		return 0;
	}

	private static EBuildCondition GetRealStationCondition(BuildTool_Click tool, BuildPreview buildPreview)
	{
		StationComponent[] stationPool = tool.factory.transport.stationPool;
		int stationCursor = tool.factory.transport.stationCursor;
		PrebuildData[] prebuildPool = tool.factory.prebuildPool;
		int prebuildCursor = tool.factory.prebuildCursor;
		EntityData[] entityPool = tool.factory.entityPool;
		float num = 225f;
		float num2 = 841f;
		for (int i = 1; i < stationCursor; i++)
		{
			if (i == stationId || stationPool[i] == null || stationPool[i].id != i)
			{
				continue;
			}
			float num3 = ((stationPool[i].isStellar || buildPreview.desc.isStellarStation) ? num2 : num);
			if ((entityPool[stationPool[i].entityId].pos - buildPreview.lpos).sqrMagnitude < num3)
			{
				if (stationPool[i].isVeinCollector)
				{
					return EBuildCondition.MK2MinerTooClose;
				}
				return EBuildCondition.TowerTooClose;
			}
		}
		for (int j = 1; j < prebuildCursor; j++)
		{
			if (prebuildPool[j].id != j)
			{
				continue;
			}
			ItemProto itemProto = LDB.items.Select(prebuildPool[j].protoId);
			if (itemProto == null || !itemProto.prefabDesc.isStation)
			{
				continue;
			}
			float num4 = ((itemProto.prefabDesc.isStellarStation || buildPreview.desc.isStellarStation) ? num2 : num);
			if (buildPreview.desc.isVeinCollector && itemProto.prefabDesc.isVeinCollector)
			{
				num4 = 0f;
			}
			if ((prebuildPool[j].pos - buildPreview.lpos).sqrMagnitude < num4)
			{
				if (itemProto.prefabDesc.isVeinCollector)
				{
					return EBuildCondition.MK2MinerTooClose;
				}
				return EBuildCondition.TowerTooClose;
			}
		}
		return EBuildCondition.Ok;
	}

	public static void ReplaceStation(BuildTool_Click tool, int stationId)
	{
		IsReplacing = true;
		try
		{
			replacingTransport = tool.factory.transport;
			replacingStationId = stationId;
			StationComponent stationComponent = tool.factory.transport.stationPool[stationId];
			BuildingParameters buildingParameters = default(BuildingParameters);
			buildingParameters.CopyFromFactoryObject(stationComponent.entityId, tool.factory);
			SlotData[] slots = stationComponent.slots;
			SaveState(stationComponent, out var state);
			tool.actionBuild.DoDismantleObject(stationComponent.entityId);
			tool.buildPreviews[0].parameters = buildingParameters.parameters;
			tool.buildPreviews[0].paramCount = buildingParameters.parameters.Length;
			tool.CreatePrebuilds();
			int objId = tool.buildPreviews[0].objId;
			ReconnectBelts(tool.factory, objId, slots);
			stationId = tool.factory.transport.stationCursor;
			if (tool.factory.transport.stationRecycleCursor > 0)
			{
				stationId = tool.factory.transport.stationRecycle[tool.factory.transport.stationRecycleCursor - 1];
			}
			tool.factory.BuildFinally(tool.player, -objId);
			LoadState(tool.factory.transport.stationPool[stationId], in state);
		}
		finally
		{
			IsReplacing = false;
			replacingTransport = null;
			replacingStationId = 0;
		}
	}

	private static void ReconnectBelts(PlanetFactory factory, int objId, SlotData[] slots)
	{
		for (int i = 0; i < slots.Length; i++)
		{
			if (slots[i].beltId > 0)
			{
				int entityId = factory.cargoTraffic.beltPool[slots[i].beltId].entityId;
				if (slots[i].dir == IODir.Output)
				{
					factory.WriteObjectConn(objId, i, isOutput: true, entityId, 1);
				}
				else
				{
					factory.WriteObjectConn(objId, i, isOutput: false, entityId, 0);
				}
			}
		}
	}

	private static void SaveState(StationComponent station, out StationState state)
	{
		state = default(StationState);
		state.energy = station.energy;
		state.warperCount = station.warperCount;
		state.droneCount = station.idleDroneCount + station.workDroneCount;
		state.shipCount = station.idleShipCount + station.workShipCount;
		state.storage = new StationStore[station.storage.Length];
		for (int i = 0; i < station.storage.Length; i++)
		{
			state.storage[i] = station.storage[i];
		}
	}

	private static void LoadState(StationComponent station, in StationState state)
	{
		station.energy = state.energy;
		station.warperCount = MergeStock(state.warperCount, station.warperCount, station.warperMaxCount, out var excess);
		RefundItem(1210, excess, 0, station.entityId);
		int droneCount = state.droneCount;
		int idleDroneCount = station.idleDroneCount;
		DroneData[] workDroneDatas = station.workDroneDatas;
		station.idleDroneCount = MergeStock(droneCount, idleDroneCount, Math.Max(0, ((workDroneDatas != null) ? workDroneDatas.Length : 0) - station.workDroneCount), out excess);
		RefundItem(5001, excess, 0, station.entityId);
		int shipCount = state.shipCount;
		int idleShipCount = station.idleShipCount;
		ShipData[] workShipDatas = station.workShipDatas;
		station.idleShipCount = MergeStock(shipCount, idleShipCount, Math.Max(0, Math.Min(64, (workShipDatas != null) ? workShipDatas.Length : 0) - station.workShipCount), out excess);
		RefundItem(5002, excess, 0, station.entityId);
		int num = Math.Min(station.storage.Length, state.storage.Length);
		for (int i = 0; i < num; i++)
		{
			station.storage[i].count = state.storage[i].count;
			station.storage[i].inc = state.storage[i].inc;
		}
		for (int j = num; j < state.storage.Length; j++)
		{
			StationStore stationStore = state.storage[j];
			RefundItem(stationStore.itemId, stationStore.count, stationStore.inc, station.entityId);
		}
	}

	private static int MergeStock(int saved, int added, int capacity, out int excess)
	{
		long num = (long)Math.Max(0, saved) + (long)Math.Max(0, added);
		int num2 = (int)Math.Min(num, Math.Max(0, capacity));
		excess = (int)Math.Min(2147483647L, num - num2);
		return num2;
	}

	private static void RefundItem(int itemId, int count, int inc, int objId)
	{
		if (count > 0)
		{
			GameMain.mainPlayer.TryAddItemToPackage(itemId, count, inc, throwTrash: true, objId);
			UIItemup.Up(itemId, count);
		}
	}
}
