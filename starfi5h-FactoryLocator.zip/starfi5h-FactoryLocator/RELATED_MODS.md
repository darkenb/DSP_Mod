# Related mod references - starfi5h-FactoryLocator

Full related-mod packages are intentionally omitted. Project URLs, versions, exact local assembly hashes and targeted source files are supplied under `References/`. Upstream HEAD may differ from the locally modified snapshot. Build/runtime dependencies remain external prerequisites.

The source links below point to files actually present in this ZIP. Original line numbers and short excerpts are retained. A shared native integration point does not imply a direct DLL dependency.

## CommonAPI-CommonAPI

[Project identity and versions](References/CommonAPI-CommonAPI/reference.json) | [Reference notes](References/CommonAPI-CommonAPI/README.md)

Upstream: https://github.com/kremnev8/CommonAPI

- **declared_hard_dependency**: Plugin-level dependency declaration; this may belong to an optional compatibility plugin.
- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Code in this mod

[Source/Reconstructed/plugins/FactoryLocator/FactoryLocator/Plugin.cs](Source/Reconstructed/plugins/FactoryLocator/FactoryLocator/Plugin.cs) - original line 16

```csharp

[BepInPlugin("starfi5h.plugin.FactoryLocator", "FactoryLocator", "1.3.15")]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "LocalizationModule", "CustomKeyBindSystem", "PickerExtensionsSystem" })]
public class Plugin : BaseUnityPlugin
```

[Source/EarlierWorkingSource/Plugin.cs](Source/EarlierWorkingSource/Plugin.cs) - original line 21

```csharp
{
    [BepInPlugin(GUID, NAME, VERSION)]
    [BepInDependency(CommonAPIPlugin.GUID)]
    [CommonAPISubmoduleDependency(nameof(LocalizationModule), 
        nameof(CustomKeyBindSystem), nameof(PickerExtensionsSystem))]
```

[Source/Reconstructed/plugins/FactoryLocator/FactoryLocator/MainLogic.cs](Source/Reconstructed/plugins/FactoryLocator/FactoryLocator/MainLogic.cs) - original line 128

```csharp
		RefreshBuilding(-1, state);
		UIentryCount.OnOpen(ESignalType.Item, filterIds);
		UIItemPickerExtension.Popup(windowPos, (Action<ItemProto>)OnBuildingPickReturn, (Func<ItemProto, bool>)((ItemProto itemProto) => filterIds.ContainsKey(itemProto.ID)));
		UIRoot.instance.uiGame.itemPicker.OnTypeButtonClick(2);
	}
```

[Source/EarlierWorkingSource/MainLogic.cs](Source/EarlierWorkingSource/MainLogic.cs) - original line 115

```csharp
            RefreshBuilding(-1, state);
            UIentryCount.OnOpen(ESignalType.Item, filterIds);
            UIItemPickerExtension.Popup(windowPos, OnBuildingPickReturn, itemProto => filterIds.ContainsKey(itemProto.ID));
            UIRoot.instance.uiGame.itemPicker.OnTypeButtonClick(2);
        }
```

### Code in the related reference

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 16

```csharp
namespace CommonAPI;

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs) - original line 14

```csharp
[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
{
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/PowerNetworkHandler.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/PowerNetworkHandler.cs) - original line 58

```csharp
	public override string GetComponentType()
	{
		return "dsp.common-api.CommonAPI:PowerNetworkHandler";
	}

```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 35

```csharp
    {
        public const string ID = "CommonAPI";
        public const string GUID = "dsp.common-api.CommonAPI";
        public const string DISPNAME = "DSP Common API";

```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/BaseSubmodule.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/BaseSubmodule.cs) - original line 18

```csharp
		{
			string name = GetType().Name;
			throw new InvalidOperationException(name + " is not loaded. Please use [CommonAPISubmoduleDependency(nameof(" + name + ")]");
		}
	}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPISubmoduleDependency.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPISubmoduleDependency.cs) - original line 6

```csharp

[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
public class CommonAPISubmoduleDependency : Attribute
{
	public string?[]? SubmoduleNames { get; }
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ConfigFileExtension.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ConfigFileExtension.cs) - original line 33

```csharp
				entry.SetSerializedValue(item.Value);
				list.Add(item.Key);
				CommonAPIPlugin.logger.LogInfo("Migrating config from " + oldSection + ":" + key + " to " + newSection + ":" + key);
			}
		}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/HarmonyRegisterExtension.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/HarmonyRegisterExtension.cs) - original line 31

```csharp
			else
			{
				CommonAPIPlugin.logger.LogInfo("Failed to patch: " + item.FullName + ".");
			}
		}
```

## CommonAPI-DSPModSave

[Project identity and versions](References/CommonAPI-DSPModSave/reference.json) | [Reference notes](References/CommonAPI-DSPModSave/README.md)

Upstream: https://github.com/kremnev8/DSP-Mods/tree/master/Mods/DSPModSave

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs) - original line 15

```csharp
namespace crecheng.DSPModSave;

[BepInPlugin("crecheng.DSPModSave", "DSP Mod Save", "1.2.3")]
public class DSPModSavePlugin : BaseUnityPlugin
{
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs) - original line 12

```csharp
	private static void EnterGame()
	{
		DSPModSavePlugin.logger.LogInfo("Enter New Game");
		foreach (ModSaveSettings value in DSPModSavePlugin.allModData.Values)
		{
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs) - original line 13

```csharp
		if (__result)
		{
			DSPModSavePlugin.OnSave(saveName);
		}
	}
```

[References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs](References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs) - original line 19

```csharp
static class Check
{
    static void Call(string method, params object[] args) {AccessTools.Method(typeof(DSPModSavePlugin), method).Invoke(null, args);}
    static int Main()
    {
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs) - original line 20

```csharp
{
    [BepInPlugin(MODGUID, MODNAME, VERSION)]
    public class DSPModSavePlugin : BaseUnityPlugin
    {
        public const string MODGUID = "crecheng.DSPModSave";
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs) - original line 12

```csharp
        static void EnterGame()
        {
            DSPModSavePlugin.logger.LogInfo("Enter New Game");
            foreach (var d in DSPModSavePlugin.allModData.Values)
            {
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs) - original line 14

```csharp
            if (!__result) return;

            DSPModSavePlugin.OnSave(saveName);
        }

```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 18

```csharp
[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
{
```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 31

```csharp
    [BepInPlugin(GUID, DISPNAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
    {
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 23

```csharp

[BepInPlugin("org.LoShin.GenesisBook", "GenesisBook", "3.2.6")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/ProjectGenesis.cs) - original line 40

```csharp
{
    [BepInPlugin(MODGUID, MODNAME, VERSION)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [BepInDependency(CommonAPIPlugin.GUID)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
```

## Galactic_Scale-GalacticScale

[Project identity and versions](References/Galactic_Scale-GalacticScale/reference.json) | [Reference notes](References/Galactic_Scale-GalacticScale/README.md)

Upstream: https://github.com/Touhma/DSP_Plugins

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/NebulaCompatibility.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/NebulaCompatibility.cs) - original line 20

```csharp
        {
            NebulaModAPI.RegisterPackets(Assembly.GetExecutingAssembly());
            GalacticScale.BCE.Console.Init();
            if (NebulaModAPI.NebulaIsInstalled)
            {
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/PluginInfo.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/PluginInfo.cs) - original line 6

```csharp
    {
        public const string PLUGIN_GUID = "dsp.galactic-scale.2";
        public const string PLUGIN_NAME = "GalacticScale";
        public const string PLUGIN_VERSION = "2.80.9";
    }
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Generators/Sol/Sol.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Generators/Sol/Sol.cs) - original line 276

```csharp
            stars.Clear();
            // GS2.Error("Test");
            //string path = Path.Combine(Path.Combine(Path.Combine(Path.Combine(Paths.BepInExRootPath, "plugins"), "GalacticScale"), "data"), "galaxy.json");
            var serializer = new fsSerializer();
            //string json = File.ReadAllText(path);
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Init.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Init.cs) - original line 16

```csharp
        private static readonly string AssemblyPath = Path.GetDirectoryName(Assembly.GetAssembly(typeof(GS2)).Location);
        private static readonly string OldDataDir = Path.Combine(AssemblyPath, "config");
        public static readonly string DataDir = Path.Combine(Paths.ConfigPath, "GalacticScale2");
        public static bool Failed = false;
        public static string updateMessage = "";
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/IO/Plugins.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/IO/Plugins.cs) - original line 44

```csharp
            foreach (var g in Generators)
            {
                Log("GalacticScale2|LoadPlugins|Loading Generator:" + g.Name);
                g.Init();
            }
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/IO/Save_Load.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/IO/Save_Load.cs) - original line 33

```csharp
            // var isVanilla = true;
            fsData data2 = null;
            var parseResult = fsResult.Fail("DSV contains no legacy GalacticScale settings.");
            try
            {
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Localization/GSLocalization.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Localization/GSLocalization.cs) - original line 46

```csharp
        {
            var entries = new Dictionary<string, string>(StringComparer.Ordinal);
            var name = $"GalacticScale.Translations.{language}.tsv";
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
            {
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/CosmicMessageManager/LateUpdate.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/CosmicMessageManager/LateUpdate.cs) - original line 21

```csharp
//  * 
//  * The original method assumes arrays are initialized and messageData is set,
//  * which may not be true during GalacticScale's extended initialization.
//  * 
//  * Changes from original:
```

### Dependency reference code

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GalacticScale.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GalacticScale.cs) - original line 17

```csharp
internal static class GalacticScale
{
	internal const string GUID = "dsp.galactic-scale.2";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.dsp.galactic-scale.2");
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/InstallationCheckPlugin.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/InstallationCheckPlugin.cs) - original line 15

```csharp
[BepInDependency("org.kremnev8.plugin.BlueprintTweaks", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("Gnimaerd.DSP.plugin.MoreMegaStructure", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.galactic-scale.2", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("930f5bae-66d2-4917-988b-162fe2456643", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("testpostpleaseignore.dsp.planet_vein_utilization", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Compatibility/GalacticScale.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Compatibility/GalacticScale.cs) - original line 21

```csharp
    internal static class GalacticScale
    {
        internal const string GUID = "dsp.galactic-scale.2";

        private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility." + GUID);
```

## HiddenCirno-GenesisBook

[Project identity and versions](References/HiddenCirno-GenesisBook/reference.json) | [Reference notes](References/HiddenCirno-GenesisBook/README.md)

Upstream: https://github.com/Awbugl/ProjectGenesis

- **fix_integration_context**: The search fix accepts live custom recipe IDs and components rather than a vanilla-only range.

### Code in this mod

[Source/Reconstructed/plugins/FactoryLocator/FactoryLocator/MainLogic.cs](Source/Reconstructed/plugins/FactoryLocator/FactoryLocator/MainLogic.cs) - original line 401

```csharp
	}

	public void RefreshAssemblers(int recipeId, int mode = 0)
	{
		filterIds.Clear();
```

[Source/Reconstructed/plugins/FactoryLocator/FactoryLocator/Plugin.cs](Source/Reconstructed/plugins/FactoryLocator/FactoryLocator/Plugin.cs) - original line 151

```csharp
	private static void InspectItemUnderMouse()
	{
		int num = Util.RecipeIdUnderMouse();
		if (num > 0)
		{
```

[Source/Reconstructed/plugins/FactoryLocator/FactoryLocator.UI/Util.cs](Source/Reconstructed/plugins/FactoryLocator/FactoryLocator.UI/Util.cs) - original line 114

```csharp
	}

	public static int RecipeIdUnderMouse()
	{
		if (UIRoot.instance.uiGame.replicator.active)
```

[Evidence/InitialPhase/check.cs](Evidence/InitialPhase/check.cs) - original line 17

```csharp
        AccessTools.Field(typeof(PlanetFactory), "factorySystem").SetValue(factory, system);
        system.assemblerCursor = 3; system.assemblerPool = new AssemblerComponent[3];
        system.assemblerPool[1] = new AssemblerComponent {id = 1, entityId = 1, recipeId = 9912};
        system.assemblerPool[2] = new AssemblerComponent {id = 2, entityId = 2, recipeId = 9912};
        system.labCursor = 1; system.labPool = new LabComponent[1];
```

[Source/EarlierWorkingSource/MainLogic.cs](Source/EarlierWorkingSource/MainLogic.cs) - original line 161

```csharp
            if (recipeProto == null) // Return by ESC
                return;
            int recipeId = recipeProto.ID;
            RefreshAssemblers(recipeId, state);
            WarningSystemPatch.AddWarningData(SignalId, SignalProtoSet.SignalId(ESignalType.Recipe, recipeId), planetIds, localPos);
```

[Source/EarlierWorkingSource/Plugin.cs](Source/EarlierWorkingSource/Plugin.cs) - original line 190

```csharp
        static void InspectItemUnderMouse()
        {
            int recipeId = Util.RecipeIdUnderMouse();
            if (recipeId > 0)
            {
```

[Source/EarlierWorkingSource/UI/Util.cs](Source/EarlierWorkingSource/UI/Util.cs) - original line 136

```csharp
        }

        public static int RecipeIdUnderMouse()
        {
            if (UIRoot.instance.uiGame.replicator.active)
```

### Code in the related reference

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/ChemicalRecipeFcolPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/ChemicalRecipeFcolPatches.cs) - original line 14

```csharp
public static class ChemicalRecipeFcolPatches
{
	private static readonly Dictionary<int, int> RecipeIdPos = new Dictionary<int, int>
	{
		{ 506, 431 },
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/InitialTechPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/InitialTechPatches.cs) - original line 61

```csharp
				for (i = 0; i < unlockRecipes.Length; i++)
				{
					int recipeId = unlockRecipes[i];
					__instance.history.UnlockRecipe(recipeId);
				}
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/MegaAssemblerPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/MegaAssemblerPatches.cs) - original line 161

```csharp
			}
			__instance.parameters[0] = (assemblerComponent.forceAccMode ? 1 : 0);
			__instance.recipeId = assemblerComponent.recipeId;
			__instance.recipeType = assemblerComponent.recipeType;
			SlotData[] slots = GetSlots(factory.planetId, objectId);
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/MultiProductionPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/MultiProductionPatches.cs) - original line 97

```csharp
		}
		AssemblerComponent assemblerComponent = __instance.factorySystem.assemblerPool[__instance.assemblerId];
		if (assemblerComponent.id != __instance.assemblerId || assemblerComponent.recipeId == 0)
		{
			return;
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/ProductOverflowPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/ProductOverflowPatches.cs) - original line 46

```csharp
			break;
		}
		EOverflowFlag eOverflowFlag = (EOverflowFlag)(LDB.recipes.Select(component.recipeId)?.Overflow ?? 0);
		if ((ProjectGenesis.ProductOverflowEntry.Value == 0 && eOverflowFlag != EOverflowFlag.None) || ProjectGenesis.ProductOverflowEntry.Value == 1)
		{
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/RecipeExtraPowerPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/RecipeExtraPowerPatches.cs) - original line 16

```csharp
	{
		ref PowerConsumerComponent reference = ref pcPool[__instance.pcId];
		int num = LDB.recipes.Select(__instance.recipeId)?.PowerFactor ?? 1;
		if (num < 2 || !__instance.replicating)
		{
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Compatibility/MoreMegaStructure.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Compatibility/MoreMegaStructure.cs) - original line 61

```csharp
            if (_finished) return;

            foreach (int recipeID in AddedRecipes)
            {
                RecipeProto recipeProto = LDB.recipes.Select(recipeID);
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Patches/Hooks/ChemicalRecipeFcol/ChemicalRecipeFcolPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Patches/Hooks/ChemicalRecipeFcol/ChemicalRecipeFcolPatches.cs) - original line 29

```csharp

            matcher.MatchForward(false,
                new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(AssemblerComponent), nameof(AssemblerComponent.recipeId))),
                new CodeMatch(OpCodes.Conv_R4),
                new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(AnimData), nameof(AnimData.working_length))));
```

## nebula-NebulaMultiplayerModApi

[Project identity and versions](References/nebula-NebulaMultiplayerModApi/reference.json) | [Reference notes](References/nebula-NebulaMultiplayerModApi/README.md)

Upstream: https://github.com/NebulaModTeam/nebula

- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Code in this mod

[Source/Reconstructed/plugins/FactoryLocator/FactoryLocator.Compat/NebulaCompat.cs](Source/Reconstructed/plugins/FactoryLocator/FactoryLocator.Compat/NebulaCompat.cs) - original line 72

```csharp
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Expected O, but got Unknown
		NebulaModAPI.MultiplayerSession.Network.SendPacket<WarningDataRequest>(new WarningDataRequest((WarningRequestEvent)0));
	}

```

[Source/EarlierWorkingSource/Compat/NebulaCompat.cs](Source/EarlierWorkingSource/Compat/NebulaCompat.cs) - original line 67

```csharp
        {
            // Request latest warning signal
            NebulaModAPI.MultiplayerSession.Network.SendPacket(new WarningDataRequest(WarningRequestEvent.Signal));
        }

```

### Code in the related reference

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs) - original line 15

```csharp
[BepInPlugin("dsp.nebula-multiplayer-api", "NebulaMultiplayerModApi", "2.1.0.7")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class NebulaModAPI : BaseUnityPlugin
{
	public const string NEBULA_MODID = "dsp.nebula-multiplayer";
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/ConcurrentPlayerCollection.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/ConcurrentPlayerCollection.cs) - original line 116

```csharp
	{
		List<IPlayerData> list = playerCollections[EConnectionStatus.Connected].Select((KeyValuePair<INebulaConnection, INebulaPlayer> p) => p.Value.Data).ToList();
		if (!NebulaModAPI.MultiplayerSession.IsDedicated)
		{
			list.Add(NebulaModAPI.MultiplayerSession.LocalPlayer.Data);
```

[References/nebula-NebulaMultiplayerModApi/Code/Evidence/InitialPhase/check.cs](References/nebula-NebulaMultiplayerModApi/Code/Evidence/InitialPhase/check.cs) - original line 9

```csharp
    static int Main()
    {
        NebulaModAPI.OnMultiplayerSessionChange(false);
        if (NebulaModAPI.IsMultiplayerActive || NebulaModAPI.MultiplayerSession != null) throw new Exception("Inactive API retained session");
        var value = new Float3(1, 2, 3);
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.GameState/IMultiplayerSession.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.GameState/IMultiplayerSession.cs) - original line 3

```csharp
namespace NebulaAPI.GameState;

public interface IMultiplayerSession
{
	INetworkProvider Network { get; set; }
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.GameState/INetworkProvider.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.GameState/INetworkProvider.cs) - original line 6

```csharp
namespace NebulaAPI.GameState;

public interface INetworkProvider : IDisposable
{
	INetPacketProcessor PacketProcessor { get; }
```

## xiaoye97-LDBTool

[Project identity and versions](References/xiaoye97-LDBTool/reference.json) | [Reference notes](References/xiaoye97-LDBTool/README.md)

Upstream: https://github.com/xiaoye97/DSP_LDBTool

- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Code in this mod

[Source/Reconstructed/plugins/FactoryLocator/FactoryLocator.Compat/BetterWarningIconsCompat.cs](Source/Reconstructed/plugins/FactoryLocator/FactoryLocator.Compat/BetterWarningIconsCompat.cs) - original line 17

```csharp
		if (Chainloader.PluginInfos.TryGetValue("dev.raptor.dsp.BetterWarningIcons", out var _))
		{
			LDBTool.PreAddProto((Proto)new SignalProto
			{
				ID = 531,
```

[Source/EarlierWorkingSource/Compat/BetterWarningIconsCompat.cs](Source/EarlierWorkingSource/Compat/BetterWarningIconsCompat.cs) - original line 29

```csharp
                description = "Building does not have sufficient inputs to work"
            };
            LDBTool.PreAddProto(proto);
        }

```

### Code in the related reference

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs) - original line 11

```csharp
namespace xiaoye97;

public static class LDBTool
{
	public static Action PreAddDataAction;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs) - original line 11

```csharp
namespace xiaoye97;

[BepInPlugin("me.xiaoye97.plugin.Dyson.LDBTool", "LDBTool", "3.0.4")]
public class LDBToolPlugin : BaseUnityPlugin
{
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs) - original line 16

```csharp
	internal static void InitIndex()
	{
		LDBToolPlugin.logger.LogDebug("Generating Proto type list:");
		protoTypes = (from domainAssembly in AppDomain.CurrentDomain.GetAssemblies()
			from assemblyType in GetTypesSafe(domainAssembly)
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs) - original line 19

```csharp
		if (__instance.recipeExecuteData == null)
		{
			LDBToolPlugin.logger.LogWarning($"Importing assembler {__instance.recipeType}: Can't find recipeId {__instance.recipeId}");
			__instance.recipeId = 0;
			__instance.recipeType = ERecipeType.None;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs) - original line 12

```csharp
	private static void HistoryPatch(GameHistoryData __instance)
	{
		foreach (Proto item in LDBTool.TotalDict[ProtoIndex.GetIndex(typeof(RecipeProto))])
		{
			RecipeProto recipeProto = item as RecipeProto;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/UITip_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/UITip_Patch.cs) - original line 12

```csharp
	private static void ItemTipPatch(UIItemTip __instance, int itemId)
	{
		if (LDBToolPlugin.ShowProto.Value)
		{
			__instance.nameText.text += $" {itemId}";
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/VFPreload_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/VFPreload_Patch.cs) - original line 15

```csharp
	private static void VFPreloadPrePatch()
	{
		if (!LDBTool.Finshed)
		{
			LDBToolPlugin.logger.LogInfo("Pre Loading...");
```

[References/xiaoye97-LDBTool/Code/Evidence/InitialPhase/check.cs](References/xiaoye97-LDBTool/Code/Evidence/InitialPhase/check.cs) - original line 53

```csharp
            return null;
        };
        try { plugin = Assembly.LoadFrom(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "LDBTool.dll")); Run(); }
        catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }
    }
```
