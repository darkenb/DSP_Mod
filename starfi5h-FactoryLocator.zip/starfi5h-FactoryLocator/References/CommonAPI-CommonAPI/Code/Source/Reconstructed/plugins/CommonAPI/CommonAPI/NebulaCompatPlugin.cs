using System;
using System.Collections.Generic;
using System.Reflection;
using BepInEx;
using CommonAPI.Nebula;
using CommonAPI.Systems;
using NebulaAPI;
using NebulaAPI.Interfaces;

namespace CommonAPI;

[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
{
	public const string ID = "common-api-nebula-compat";

	public const string GUID = "dsp.common-tools.common-api-nebula-compat";

	public const string NAME = "Common API Nebula Compatibility";

	public string Version => "1.6.8.0";

	private void Start()
	{
		if (CommonAPIPlugin.IsSubmoduleLoaded("PlanetExtensionSystem"))
		{
			NebulaModAPI.OnPlanetLoadRequest = (Action<int>)Delegate.Combine(NebulaModAPI.OnPlanetLoadRequest, (Action<int>)delegate(int planetId)
			{
				NebulaModAPI.MultiplayerSession.Network.SendPacket<PlanetSystemLoadRequest>(new PlanetSystemLoadRequest(planetId));
			});
		}
		if (CommonAPIPlugin.IsSubmoduleLoaded("StarExtensionSystem"))
		{
			NebulaModAPI.OnStarLoadRequest = (Action<int>)Delegate.Combine(NebulaModAPI.OnStarLoadRequest, (Action<int>)delegate(int starIndex)
			{
				NebulaModAPI.MultiplayerSession.Network.SendPacket<StarExtensionLoadRequest>(new StarExtensionLoadRequest(starIndex));
			});
		}
		NebulaModAPI.RegisterPackets(Assembly.GetExecutingAssembly());
		CommonAPIPlugin.onIntoOtherSave = CheckNebulaInIntoOtherSave;
		PlanetExtensionSystem.onInitNewPlanet = HandleNebulaPacket;
		base.Logger.LogInfo("Common API Nebula Compatibility ready!");
	}

	public static void CheckNebulaInIntoOtherSave()
	{
		if (!NebulaModAPI.IsMultiplayerActive || NebulaModAPI.MultiplayerSession.LocalPlayer.IsHost)
		{
			return;
		}
		foreach (KeyValuePair<string, Registry> registry in CommonAPIPlugin.registries)
		{
			registry.Value.InitUnitMigrationMap();
		}
	}

	public static void HandleNebulaPacket(PlanetData planet)
	{
		if (!NebulaModAPI.IsMultiplayerActive || NebulaModAPI.MultiplayerSession.LocalPlayer.IsHost || !PlanetExtensionSystem.pendingData.TryGetValue(planet.id, out var value))
		{
			return;
		}
		PlanetExtensionSystem.pendingData.Remove(planet.id);
		IReaderProvider binaryReader = NebulaModAPI.GetBinaryReader(value);
		try
		{
			for (int i = 1; i < PlanetExtensionSystem.registry.data.Count; i++)
			{
				PlanetExtensionSystem.extensions[i].GetExtension(planet.factory).Import(binaryReader.BinaryReader);
			}
		}
		finally
		{
			((IDisposable)binaryReader)?.Dispose();
		}
	}

	public bool CheckVersion(string hostVersion, string clientVersion)
	{
		return hostVersion.Equals(clientVersion);
	}
}
