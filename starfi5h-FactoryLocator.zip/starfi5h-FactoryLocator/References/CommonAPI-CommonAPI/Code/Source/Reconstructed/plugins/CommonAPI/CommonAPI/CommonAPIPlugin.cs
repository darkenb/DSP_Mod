using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using CommonAPI.ShotScene;
using CommonAPI.Systems;
using HarmonyLib;
using UnityEngine;
using crecheng.DSPModSave;

namespace CommonAPI;

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
{
	public const string ID = "CommonAPI";

	public const string GUID = "dsp.common-api.CommonAPI";

	public const string DISPNAME = "DSP Common API";

	public const string VERSION = "1.6.8.0";

	internal static Harmony harmony;

	internal static ICommonLogger logger;

	internal static ResourceData resource;

	internal static Action onIntoOtherSave;

	internal static SubmoduleHandler submoduleHandler;

	public static Dictionary<string, Registry> registries = new Dictionary<string, Registry>();

	public static readonly Version buildFor = GameVersionUtil.GetVersion(0, 10, 35, 29104);

	public static bool iconShotMenuEnabled;

	public static KeyCode openIconShotMenuButton;

	internal static ConfigEntry<string> forceLoaded;

	private void Awake()
	{
		logger = new LoggerWrapper(base.Logger);
		CommonLogger.SetLogger(logger);
		UnityThread.initUnityThread();
		iconShotMenuEnabled = base.Config.Bind("General", "enableIconShotMenu", defaultValue: false, "Is Icon shot menu enabled. It is useful for mod developers, because it allows to create consistent icons.").Value;
		openIconShotMenuButton = base.Config.Bind("General", "OpenIconShotMenuButton", KeyCode.F6, "Button used to open special Icon shot menu. It is useful for mod developers, because it allows to create consistent icons.").Value;
		harmony = new Harmony("dsp.common-api.CommonAPI");
		PluginScanner pluginScanner = new PluginScanner();
		submoduleHandler = new SubmoduleHandler(buildFor, base.Logger);
		submoduleHandler.LoadRequested(pluginScanner);
		pluginScanner.ScanPlugins();
		string directoryName = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
		resource = new ResourceData("CommonAPI", "CommonAPI", directoryName);
		resource.LoadAssetBundle("commonapi");
		LoadSaveOnLoad.Init();
		harmony.PatchAll(typeof(VFPreloadPatch));
		CheckModuleForceLoad();
		logger.LogInfo("Common API is initialized!");
	}

	private void Update()
	{
		if (iconShotMenuEnabled && DSPGame.MenuDemoLoaded && Input.GetKeyDown(openIconShotMenuButton))
		{
			GeneratorSceneController.LoadIconGeneratorScene();
		}
	}

	internal static void CheckIfUsedOnRightGameVersion()
	{
		Version gameVersion = GameConfig.gameVersion;
		if (!(buildFor == gameVersion))
		{
			logger.LogWarning("This version of CommonAPI was built for build id \"" + buildFor.ToFullString() + "\", you are running \"" + gameVersion.ToFullString() + "\".");
			logger.LogWarning("Should any problems arise, please check for a new version before reporting issues.");
		}
	}

	public static bool IsSubmoduleLoaded(string submodule)
	{
		return submoduleHandler.IsLoaded(submodule);
	}

	public static bool TryLoadModule(Type moduleType)
	{
		return submoduleHandler.RequestModuleLoad(moduleType);
	}

	internal static T GetModuleInstance<T>() where T : BaseSubmodule
	{
		return submoduleHandler.GetModuleInstance<T>();
	}

	public static void LoadModules(params Type[] moduleTypes)
	{
		LoadModules((IEnumerable<Type>)moduleTypes);
	}

	private void CheckModuleForceLoad()
	{
		List<Type> allSubmodules = submoduleHandler.allModules.Keys.ToList();
		string[] acceptableValues = allSubmodules.Select((Type type) => type.Name).AddItem("all").ToArray();
		forceLoaded = base.Config.Bind("Debug", "ForceModuleLoad", "", new ConfigDescription("Manually force certain modules to be loaded. Do not use unless you know what you are doing.", new AcceptableValueOptionsList(acceptableValues)));
		if (string.IsNullOrWhiteSpace(forceLoaded.Value))
		{
			return;
		}
		if (forceLoaded.Value == "all")
		{
			LoadModules(allSubmodules);
			return;
		}
		LoadModules(from name in forceLoaded.Value.Split(new char[1] { ',' })
			select allSubmodules.Find((Type type) => type.Name.Equals(name)));
	}

	private static void LoadModules(IEnumerable<Type> forceLoadTypes)
	{
		foreach (Type forceLoadType in forceLoadTypes)
		{
			if (!(forceLoadType == null))
			{
				TryLoadModule(forceLoadType);
			}
		}
	}

	public void Import(BinaryReader r)
	{
		int num = r.ReadInt32();
		while (r.ReadByte() != 0)
		{
			string key = r.ReadString();
			if (registries.ContainsKey(key))
			{
				r.ReadInt64();
				registries[key].Import(r);
			}
			else
			{
				long num2 = r.ReadInt64();
				r.ReadBytes((int)num2);
			}
		}
		StarExtensionSystem.InitOnLoad();
		StarExtensionSystem.Import(r);
		PlanetExtensionSystem.InitOnLoad();
		PlanetExtensionSystem.Import(r);
		if (num > 0)
		{
			ModProtoHistory.Import(r);
		}
	}

	public void Export(BinaryWriter w)
	{
		w.Write(1);
		foreach (KeyValuePair<string, Registry> registry in registries)
		{
			w.Write((byte)1);
			w.Write(registry.Key);
			MemoryStream memoryStream = new MemoryStream();
			BinaryWriter w2 = new BinaryWriter(memoryStream);
			registry.Value.Export(w2);
			w.Write(memoryStream.Length);
			w.Write(memoryStream.ToArray());
		}
		w.Write((byte)0);
		StarExtensionSystem.Export(w);
		PlanetExtensionSystem.Export(w);
		ModProtoHistory.Export(w);
	}

	public void IntoOtherSave()
	{
		onIntoOtherSave?.Invoke();
		StarExtensionSystem.InitOnLoad();
		PlanetExtensionSystem.InitOnLoad();
	}
}
