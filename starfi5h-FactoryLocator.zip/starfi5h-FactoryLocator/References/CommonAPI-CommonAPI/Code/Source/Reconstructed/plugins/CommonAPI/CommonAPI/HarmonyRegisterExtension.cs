using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using HarmonyLib;

namespace CommonAPI;

public static class HarmonyRegisterExtension
{
	public static IEnumerable<Type> GetTypesWithAttributeInAssembly<T>(Assembly assembly) where T : Attribute
	{
		return from t in assembly.GetTypes()
			where t.GetCustomAttributes(typeof(T), inherit: true).Length != 0
			select t;
	}

	public static void PatchAll(this Harmony harmony, string typeKey)
	{
		foreach (Type item in GetTypesWithAttributeInAssembly<RegisterPatch>(Assembly.GetCallingAssembly()))
		{
			if (item.IsClass)
			{
				if (item.GetCustomAttribute<RegisterPatch>().typeKey.Equals(typeKey))
				{
					harmony.PatchAll(item);
				}
			}
			else
			{
				CommonAPIPlugin.logger.LogInfo("Failed to patch: " + item.FullName + ".");
			}
		}
	}
}
