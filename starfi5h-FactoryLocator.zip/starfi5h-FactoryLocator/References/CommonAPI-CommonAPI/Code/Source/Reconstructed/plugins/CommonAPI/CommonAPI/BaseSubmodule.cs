using System;

namespace CommonAPI;

public abstract class BaseSubmodule
{
	public bool Loaded { get; internal set; }

	internal virtual Version Build => default(Version);

	internal virtual Type[] Dependencies => Type.EmptyTypes;

	internal void ThrowIfNotLoaded()
	{
		if (!Loaded)
		{
			string name = GetType().Name;
			throw new InvalidOperationException(name + " is not loaded. Please use [CommonAPISubmoduleDependency(nameof(" + name + ")]");
		}
	}

	internal virtual void SetHooks()
	{
	}

	internal virtual void Load()
	{
	}

	internal virtual void PostLoad()
	{
	}

	internal virtual void Unload()
	{
	}

	internal virtual void UnsetHooks()
	{
	}

	internal virtual bool LoadCheck()
	{
		return true;
	}

	internal virtual Type[] GetOptionalDependencies()
	{
		return Array.Empty<Type>();
	}
}
