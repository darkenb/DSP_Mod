using System;
using System.Collections.Generic;
using PowerNetworkStructures;
using UnityEngine;

namespace CommonAPI;

public class PowerNetworkHandler : NetworkHandler
{
	private PowerSystem system;

	public override NetworkHandler Prepare(PlanetFactory currentFactory)
	{
		if (factory == currentFactory)
		{
			return this;
		}
		base.Prepare(currentFactory);
		system = currentFactory.powerSystem;
		return this;
	}

	protected override void SetNodeNetwork(Node node, INetwork network)
	{
		system.nodePool[node.id].networkId = network.GetId();
	}

	public override INetwork GetNetwork(int nodeId)
	{
		int networkId = system.nodePool[nodeId].networkId;
		if (networkId == 0)
		{
			throw new ArgumentException("Zero Network id");
		}
		return new PowerNetworkWrapper(system.netPool[networkId]);
	}

	protected override void RemoveNetwork(INetwork network)
	{
		system.RemoveNetwork(network.GetId());
	}

	protected override bool CheckConnectionConditions(Node first, Node second, ref string message)
	{
		float num = first.connDistance2;
		float connDistance = second.connDistance2;
		if (num < connDistance)
		{
			num = connDistance;
		}
		float sqrMagnitude = (first.GetPoint() - second.GetPoint()).sqrMagnitude;
		message = "距离太远";
		return sqrMagnitude <= num;
	}

	public override string GetComponentType()
	{
		return "dsp.common-api.CommonAPI:PowerNetworkHandler";
	}

	public override bool IsRelatedTo(ItemProto proto)
	{
		return proto.prefabDesc.isPowerNode;
	}

	public override int GetNodeId(EntityData entity, Vector3 pos, Func<Node, bool> filter = null)
	{
		if (filter == null || filter(GetNodeWithId(entity.powerNodeId)))
		{
			return entity.powerNodeId;
		}
		return 0;
	}

	public override NodeBounds GetNodeBounds(PrefabDesc prefab, int nodeId)
	{
		return new NodeBounds
		{
			center = prefab.selectCenter,
			size = prefab.selectSize,
			nodePoint = prefab.powerPoint
		};
	}

	protected override void HandleNetworkMerge(INetwork first, INetwork second)
	{
		PowerNetwork data = ((PowerNetworkWrapper)first).data;
		PowerNetwork data2 = ((PowerNetworkWrapper)second).data;
		foreach (int consumer in data2.consumers)
		{
			system.consumerPool[consumer].networkId = first.GetId();
		}
		foreach (int generator in data2.generators)
		{
			system.genPool[generator].networkId = first.GetId();
		}
		foreach (int accumulator in data2.accumulators)
		{
			system.accPool[accumulator].networkId = first.GetId();
		}
		foreach (int exchanger in data2.exchangers)
		{
			system.excPool[exchanger].networkId = first.GetId();
		}
		Algorithms.ListSortedMerge(data.consumers, data2.consumers);
		Algorithms.ListSortedMerge(data.generators, data2.generators);
		Algorithms.ListSortedMerge(data.accumulators, data2.accumulators);
		Algorithms.ListSortedMerge(data.exchangers, data2.exchangers);
	}

	protected override void HandleNodeRemoval(INetwork network, Node node)
	{
		PowerNetwork data = ((PowerNetworkWrapper)network).data;
		foreach (int consumer in node.consumers)
		{
			data.consumers.Remove(consumer);
		}
		if (node.genId > 0)
		{
			data.generators.Remove(node.genId);
		}
		if (node.accId > 0)
		{
			data.accumulators.Remove(node.accId);
		}
		if (node.excId > 0)
		{
			data.exchangers.Remove(node.excId);
		}
	}

	protected override INetwork CreateNewNetworkWith(List<Node> nodes)
	{
		int num = system.NewNetwork();
		PowerNetwork powerNetwork = system.netPool[num];
		Algorithms.ListSortedMerge(powerNetwork.nodes, nodes);
		foreach (Node node in nodes)
		{
			system.nodePool[node.id].networkId = num;
			Algorithms.ListSortedMerge(powerNetwork.consumers, node.consumers);
			foreach (int consumer in node.consumers)
			{
				system.consumerPool[consumer].networkId = num;
			}
			if (node.genId > 0)
			{
				Algorithms.ListSortedAdd(powerNetwork.generators, node.genId);
				system.genPool[node.genId].networkId = num;
			}
			if (node.accId > 0)
			{
				Algorithms.ListSortedAdd(powerNetwork.accumulators, node.accId);
				system.accPool[node.accId].networkId = num;
			}
			if (node.excId > 0)
			{
				Algorithms.ListSortedAdd(powerNetwork.exchangers, node.excId);
				system.excPool[node.excId].networkId = num;
			}
		}
		return new PowerNetworkWrapper(powerNetwork);
	}

	public override void UpdateVisualComponents(Node target)
	{
		system.line_arragement_for_remove_node(target);
		system.line_arragement_for_add_node(target);
		factory.planet.factoryModel.RefreshPowerNodes();
	}
}
