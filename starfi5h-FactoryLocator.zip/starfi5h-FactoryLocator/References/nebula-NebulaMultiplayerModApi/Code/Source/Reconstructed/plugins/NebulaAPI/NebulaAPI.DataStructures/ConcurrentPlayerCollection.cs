using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using NebulaAPI.GameState;
using NebulaAPI.Networking;

namespace NebulaAPI.DataStructures;

public class ConcurrentPlayerCollection
{
	private class ReducedConcurrentDictionary<TKey, TValue> : ConcurrentDictionary<TKey, TValue>
	{
		public new ICollection<TKey> Keys
		{
			get
			{
				throw new InvalidOperationException("Accessing keys directly is not allowed.");
			}
		}

		public new ICollection<TValue> Values
		{
			get
			{
				throw new InvalidOperationException("Accessing keys directly is not allowed.");
			}
		}
	}

	private readonly Dictionary<EConnectionStatus, ReducedConcurrentDictionary<INebulaConnection, INebulaPlayer>> playerCollections = new Dictionary<EConnectionStatus, ReducedConcurrentDictionary<INebulaConnection, INebulaPlayer>>
	{
		{
			EConnectionStatus.Pending,
			new ReducedConcurrentDictionary<INebulaConnection, INebulaPlayer>()
		},
		{
			EConnectionStatus.Syncing,
			new ReducedConcurrentDictionary<INebulaConnection, INebulaPlayer>()
		},
		{
			EConnectionStatus.Connected,
			new ReducedConcurrentDictionary<INebulaConnection, INebulaPlayer>()
		}
	};

	public IReadOnlyDictionary<INebulaConnection, INebulaPlayer> Pending => playerCollections[EConnectionStatus.Pending];

	public IReadOnlyDictionary<INebulaConnection, INebulaPlayer> Syncing => playerCollections[EConnectionStatus.Syncing];

	public IReadOnlyDictionary<INebulaConnection, INebulaPlayer> Connected => playerCollections[EConnectionStatus.Connected];

	public bool TryAdd(INebulaConnection conn, INebulaPlayer newPlayer)
	{
		if (conn.ConnectionStatus == EConnectionStatus.Undefined)
		{
			throw new InvalidOperationException("Could not add a player of undefined connection status.");
		}
		return playerCollections[conn.ConnectionStatus].TryAdd(conn, newPlayer);
	}

	public bool TryRemove(INebulaConnection conn, out INebulaPlayer removedPlayer)
	{
		return playerCollections[conn.ConnectionStatus].TryRemove(conn, out removedPlayer);
	}

	public bool TryUpgrade(INebulaPlayer player, EConnectionStatus newStatus)
	{
		if (!playerCollections[player.Connection.ConnectionStatus].TryRemove(player.Connection, out var _))
		{
			return false;
		}
		if (!playerCollections[newStatus].TryAdd(player.Connection, player))
		{
			return true;
		}
		player.Connection.ConnectionStatus = newStatus;
		return true;
	}

	public INebulaPlayer Get(INebulaConnection conn, EConnectionStatus connectionStatus = EConnectionStatus.Connected)
	{
		playerCollections[connectionStatus].TryGetValue(conn, out var value);
		return value;
	}

	public INebulaPlayer Get(string username, EConnectionStatus connectionStatus = EConnectionStatus.Connected)
	{
		ReducedConcurrentDictionary<INebulaConnection, INebulaPlayer> reducedConcurrentDictionary = playerCollections[connectionStatus];
		foreach (KeyValuePair<INebulaConnection, INebulaPlayer> item in reducedConcurrentDictionary)
		{
			if (item.Value.Data.Username == username)
			{
				return item.Value;
			}
		}
		return null;
	}

	public INebulaPlayer Get(ushort playerId, EConnectionStatus connectionStatus = EConnectionStatus.Connected)
	{
		ReducedConcurrentDictionary<INebulaConnection, INebulaPlayer> reducedConcurrentDictionary = playerCollections[connectionStatus];
		foreach (KeyValuePair<INebulaConnection, INebulaPlayer> item in reducedConcurrentDictionary)
		{
			if (item.Value.Id == playerId)
			{
				return item.Value;
			}
		}
		return null;
	}

	public IEnumerable<IPlayerData> GetAllPlayerData()
	{
		List<IPlayerData> list = playerCollections[EConnectionStatus.Connected].Select((KeyValuePair<INebulaConnection, INebulaPlayer> p) => p.Value.Data).ToList();
		if (!NebulaModAPI.MultiplayerSession.IsDedicated)
		{
			list.Add(NebulaModAPI.MultiplayerSession.LocalPlayer.Data);
		}
		return list;
	}
}
