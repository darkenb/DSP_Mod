using System;
using NebulaAPI.Networking;

namespace NebulaAPI.GameState;

public interface INetworkProvider : IDisposable
{
	INetPacketProcessor PacketProcessor { get; }

	void SendPacket<T>(T packet) where T : class, new();

	void SendToMatching<T>(T packet, Predicate<INebulaPlayer> condition) where T : class, new();

	void SendPacketToLocalStar<T>(T packet) where T : class, new();

	void SendPacketToLocalPlanet<T>(T packet) where T : class, new();

	void SendPacketToPlanet<T>(T packet, int planetId) where T : class, new();

	void SendPacketToStar<T>(T packet, int starId) where T : class, new();

	void SendPacketExclude<T>(T packet, INebulaConnection exclude) where T : class, new();

	void SendPacketToStarExclude<T>(T packet, int starId, INebulaConnection exclude) where T : class, new();
}
