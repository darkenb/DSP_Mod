using System;
using NebulaAPI;
using NebulaAPI.DataStructures;

static class Check
{
    static int Main()
    {
        NebulaModAPI.OnMultiplayerSessionChange(false);
        if (NebulaModAPI.IsMultiplayerActive || NebulaModAPI.MultiplayerSession != null) throw new Exception("Inactive API retained session");
        var value = new Float3(1, 2, 3);
        if (value.x != 1 || value.y != 2 || value.z != 3) throw new Exception("Public value API changed");
        Console.WriteLine("PASS inactive Nebula API clears session and existing public Float3 contract is usable; full multiplayer not tested");
        return 0;
    }
}
