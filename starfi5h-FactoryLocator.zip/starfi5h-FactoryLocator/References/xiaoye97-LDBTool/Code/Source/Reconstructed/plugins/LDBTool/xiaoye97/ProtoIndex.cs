using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;

namespace xiaoye97;

public static class ProtoIndex
{
	private static Dictionary<Type, int> index = new Dictionary<Type, int>();

	private static Type[] protoTypes;

	internal static void InitIndex()
	{
		LDBToolPlugin.logger.LogDebug("Generating Proto type list:");
		protoTypes = (from domainAssembly in AppDomain.CurrentDomain.GetAssemblies()
			from assemblyType in GetTypesSafe(domainAssembly)
			where assemblyType != null && typeof(Proto).IsAssignableFrom(assemblyType) && assemblyType != typeof(Proto) && assemblyType.FullName != "StringProto"
			select assemblyType).ToArray();
		for (int num = 0; num < protoTypes.Length; num++)
		{
			index.Add(protoTypes[num], num);
			LDBToolPlugin.logger.LogDebug("Found Proto type: " + protoTypes[num].FullName);
		}
	}

	private static Type[] GetTypesSafe(Assembly assembly)
	{
		try
		{
			return assembly.GetTypes();
		}
		catch (ReflectionTypeLoadException ex)
		{
			return ex.Types;
		}
	}

	public static int GetProtosCount()
	{
		return index.Count;
	}

	public static int GetIndex(Proto proto)
	{
		return GetIndex(proto.GetType());
	}

	public static int GetIndex(Type type)
	{
		if (!typeof(Proto).IsAssignableFrom(type))
		{
			throw new ArgumentException("Can't get index because type " + type.FullName + " does not extend Proto type.");
		}
		if (index.ContainsKey(type))
		{
			return index[type];
		}
		throw new ArgumentException("Unknown Proto type: " + type.FullName);
	}

	public static Type GetProtoTypeAt(int num)
	{
		return protoTypes[num];
	}

	public static string GetProtoName(Proto proto)
	{
		return proto.GetType().Name.Replace("Proto", "");
	}

	public static string[] GetProtoNames()
	{
		return protoTypes.Select((Type type) => type.Name.Replace("Proto", "")).ToArray();
	}

	internal static Type[] GetAllProtoTypes()
	{
		return protoTypes;
	}
}
