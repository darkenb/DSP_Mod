using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BepInEx;
using BepInEx.Configuration;
using HarmonyLib;

namespace xiaoye97;

public static class LDBTool
{
	public static Action PreAddDataAction;

	public static Action PostAddDataAction;

	public static Action<Proto> EditDataAction;

	internal static bool Finshed;

	internal static List<List<Proto>> PreToAdd = new List<List<Proto>>();

	internal static List<List<Proto>> PostToAdd = new List<List<Proto>>();

	internal static List<List<Proto>> TotalDict = new List<List<Proto>>();

	private static List<Dictionary<string, ConfigEntry<int>>> IDDict = new List<Dictionary<string, ConfigEntry<int>>>();

	private static List<Dictionary<string, ConfigEntry<int>>> GridIndexDict = new List<Dictionary<string, ConfigEntry<int>>>();

	private static Dictionary<string, ConfigEntry<string>> ZHCNDict = new Dictionary<string, ConfigEntry<string>>();

	private static Dictionary<string, ConfigEntry<string>> ENUSDict = new Dictionary<string, ConfigEntry<string>>();

	private static Dictionary<string, ConfigEntry<string>> FRFRDict = new Dictionary<string, ConfigEntry<string>>();

	private static Dictionary<int, Dictionary<int, int>> BuildBarDict = new Dictionary<int, Dictionary<int, int>>();

	private static ConfigFile CustomID = new ConfigFile(Paths.ConfigPath + "/LDBTool/LDBTool.CustomID.cfg", saveOnInit: true);

	private static ConfigFile CustomGridIndex = new ConfigFile(Paths.ConfigPath + "/LDBTool/LDBTool.CustomGridIndex.cfg", saveOnInit: true);

	private static ConfigFile CustomStringZHCN = new ConfigFile(Paths.ConfigPath + "/LDBTool/LDBTool.CustomLocalization.ZHCN.cfg", saveOnInit: true);

	private static ConfigFile CustomStringENUS = new ConfigFile(Paths.ConfigPath + "/LDBTool/LDBTool.CustomLocalization.ENUS.cfg", saveOnInit: true);

	private static ConfigFile CustomStringFRFR = new ConfigFile(Paths.ConfigPath + "/LDBTool/LDBTool.CustomLocalization.FRFR.cfg", saveOnInit: true);

	public static void SetBuildBar(int category, int index, int itemId)
	{
		if (category < 1 || category > 12)
		{
			LDBToolPlugin.logger.LogWarning("SetBuildBar Fail. category must be between 1 and 12.");
		}
		else if (index < 1 || index > 12)
		{
			LDBToolPlugin.logger.LogWarning("SetBuildBar Fail. index must be between 1 and 12.");
		}
		else if (UIBuildMenu.staticLoaded && Finshed)
		{
			ItemProto itemProto = LDB.items.Select(itemId);
			if (itemProto != null)
			{
				UIBuildMenu.protos[category, index] = itemProto;
				LDBToolPlugin.logger.LogInfo($"Set build bar at {category},{index} ID:{itemProto.ID} name:{itemProto.Name.Translate()}");
			}
			else
			{
				LDBToolPlugin.logger.LogWarning($"SetBuildBar Fail. ItemProto with ID {itemId} not found.");
			}
		}
		else
		{
			if (!BuildBarDict.ContainsKey(category))
			{
				BuildBarDict.Add(category, new Dictionary<int, int>());
			}
			BuildBarDict[category][index] = itemId;
		}
	}

	public static void PreAddProto(Proto proto)
	{
		int index = ProtoIndex.GetIndex(proto.GetType());
		if (!PreToAdd[index].Contains(proto))
		{
			Bind(proto);
			PreToAdd[index].Add(proto);
			TotalDict[index].Add(proto);
		}
	}

	[Obsolete("Please use PreAddProto(Proto proto)")]
	public static void PreAddProto(ProtoType protoType, Proto proto)
	{
		if (protoType != ProtoType.String)
		{
			PreAddProto(proto);
		}
	}

	public static void PostAddProto(Proto proto)
	{
		int index = ProtoIndex.GetIndex(proto.GetType());
		if (!PostToAdd[index].Contains(proto))
		{
			Bind(proto);
			PostToAdd[index].Add(proto);
			TotalDict[index].Add(proto);
		}
	}

	[Obsolete("Please use PostAddProto(Proto proto)")]
	public static void PostAddProto(ProtoType protoType, Proto proto)
	{
		PostAddProto(proto);
	}

	internal static void Init()
	{
		for (int i = 0; i <= ProtoIndex.GetProtosCount(); i++)
		{
			PreToAdd.Add(new List<Proto>());
			PostToAdd.Add(new List<Proto>());
			TotalDict.Add(new List<Proto>());
			IDDict.Add(new Dictionary<string, ConfigEntry<int>>());
			GridIndexDict.Add(new Dictionary<string, ConfigEntry<int>>());
		}
	}

	internal static void SetBuildBar()
	{
		foreach (KeyValuePair<int, Dictionary<int, int>> item in BuildBarDict)
		{
			foreach (KeyValuePair<int, int> item2 in item.Value)
			{
				ItemProto itemProto = LDB.items.Select(item2.Value);
				if (itemProto != null)
				{
					UIBuildMenu.protos[item.Key, item2.Key] = itemProto;
					LDBToolPlugin.logger.LogInfo($" Set build bar at {item.Key},{item2.Key} ID:{itemProto.ID} name:{itemProto.Name.Translate()}");
				}
				else
				{
					LDBToolPlugin.logger.LogWarning($"SetBuildBar Fail. ItemProto with ID {item2.Value} not found.");
				}
			}
		}
	}

	private static void Bind(Proto proto)
	{
		IdBind(proto);
		GridIndexBind(proto);
	}

	private static void IdBind(Proto proto)
	{
		int index = ProtoIndex.GetIndex(proto);
		ConfigEntry<int> configEntry = CustomID.Bind(ProtoIndex.GetProtoName(proto), proto.Name, proto.ID);
		proto.ID = configEntry.Value;
		if (IDDict[index].ContainsKey(proto.Name))
		{
			LDBToolPlugin.logger.LogError($"[CustomID] ID:{proto.ID} Name:{proto.Name} There is a conflict, please check.");
		}
		else
		{
			IDDict[index].Add(proto.Name, configEntry);
		}
	}

	private static void GridIndexBind(Proto proto)
	{
		ConfigEntry<int> configEntry = null;
		if (proto is ItemProto itemProto)
		{
			configEntry = CustomGridIndex.Bind(ProtoIndex.GetProtoName(proto), itemProto.ID.ToString(), 0, $"Default Grid Index = {itemProto.GridIndex}\nItem Name = {itemProto.Name}");
			if (configEntry.Value != 0)
			{
				itemProto.GridIndex = configEntry.Value;
			}
		}
		else if (proto is RecipeProto recipeProto)
		{
			configEntry = CustomGridIndex.Bind(ProtoIndex.GetProtoName(proto), recipeProto.ID.ToString(), 0, $"Default Grid Index = {recipeProto.GridIndex}\nRecipe Name = {recipeProto.Name}");
			if (configEntry.Value != 0)
			{
				recipeProto.GridIndex = configEntry.Value;
			}
		}
		if (configEntry != null)
		{
			int index = ProtoIndex.GetIndex(proto);
			if (GridIndexDict[index].ContainsKey(proto.Name))
			{
				LDBToolPlugin.logger.LogError($"[CustomGridIndex] ID:{proto.ID} Name:{proto.Name} There is a conflict, please check.");
			}
			else
			{
				GridIndexDict[index].Add(proto.Name, configEntry);
			}
		}
	}

	internal static void AddProtos(List<List<Proto>> datas)
	{
		Type[] allProtoTypes = ProtoIndex.GetAllProtoTypes();
		for (int i = 0; i < allProtoTypes.Length; i++)
		{
			Type protoType = allProtoTypes[i];
			PropertyInfo propertyInfo = typeof(LDB).GetProperties().First((PropertyInfo property) => typeof(ProtoSet<>).MakeGenericType(protoType).IsAssignableFrom(property.PropertyType));
			MethodInfo methodInfo = typeof(LDBTool).GetMethod("AddProtosToSet", AccessTools.all).MakeGenericMethod(protoType);
			object value = propertyInfo.GetValue(null);
			methodInfo.Invoke(null, new object[2]
			{
				value,
				datas[i]
			});
		}
	}

	private static void AddProtosToSet<T>(ProtoSet<T> protoSet, List<Proto> protos) where T : Proto
	{
		T[] dataArray = protoSet.dataArray;
		protoSet.Init(dataArray.Length + protos.Count);
		for (int i = 0; i < dataArray.Length; i++)
		{
			protoSet.dataArray[i] = dataArray[i];
		}
		for (int j = 0; j < protos.Count; j++)
		{
			protoSet.dataArray[dataArray.Length + j] = protos[j] as T;
			if (protos[j] is ItemProto itemProto)
			{
				itemProto.index = dataArray.Length + j;
			}
			if (protos[j] is RecipeProto)
			{
				RecipeProto recipeProto = protos[j] as RecipeProto;
				if (recipeProto.preTech != null)
				{
					ArrayAddItem(ref recipeProto.preTech.UnlockRecipes, recipeProto.ID);
					ArrayAddItem(ref recipeProto.preTech.unlockRecipeArray, recipeProto);
				}
			}
			LDBToolPlugin.logger.LogInfo($"Add {protos[j].ID} {protos[j].Name.Translate()} to {protoSet.GetType().Name}.");
		}
		ProtoLookup.Rebuild(protoSet, delegate(string message)
		{
			LDBToolPlugin.logger.LogWarning(message);
		});
	}

	private static void ArrayAddItem<T>(ref T[] array, T item)
	{
		List<T> list = array.ToList();
		list.Add(item);
		array = list.ToArray();
	}
}
