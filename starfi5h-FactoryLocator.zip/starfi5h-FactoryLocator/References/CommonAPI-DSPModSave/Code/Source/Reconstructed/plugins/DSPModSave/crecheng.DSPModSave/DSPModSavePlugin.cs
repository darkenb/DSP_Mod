using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Logging;
using HarmonyLib;
using crecheng.DSPModSave.Patches;

namespace crecheng.DSPModSave;

[BepInPlugin("crecheng.DSPModSave", "DSP Mod Save", "1.2.3")]
public class DSPModSavePlugin : BaseUnityPlugin
{
	public const string MODGUID = "crecheng.DSPModSave";

	public const string MODNAME = "DSP Mod Save";

	public const string MODID = "DSPModSave";

	public const string VERSION = "1.2.3";

	public static ManualLogSource logger;

	internal static Dictionary<string, ModSaveSettings> allModData = new Dictionary<string, ModSaveSettings>();

	private const string saveExt = ".moddsv";

	private const string autoSaveTmp = "_autosave_tmp";

	private const string autoSave0 = "_autosave_0";

	private const string autoSave1 = "_autosave_1";

	private const string autoSave2 = "_autosave_2";

	private const string autoSave3 = "_autosave_3";

	private const string lastExit = "_lastexit_";

	public const int SAVE_FILE_VERSION = 1;

	private static string lastSavedPath;

	private static FileStream currentFileStream;

	private static Dictionary<string, ModSaveEntry> saveEntries = new Dictionary<string, ModSaveEntry>();

	private void Start()
	{
		logger = base.Logger;
		Harmony harmony = new Harmony("crecheng.DSPModSave");
		harmony.PatchAll(typeof(GameData_Patch));
		harmony.PatchAll(typeof(GameSave_Patch));
		Init();
		logger.LogInfo("DSP Mod Save is initialized!");
	}

	private void Init()
	{
		foreach (PluginInfo value in Chainloader.PluginInfos.Values)
		{
			RegisterModSaveHandler(value.Instance);
		}
	}

	public static void AddModSaveManually(BaseUnityPlugin mod)
	{
		RegisterModSaveHandler(mod);
	}

	public static void RemoveModSaveManually(BaseUnityPlugin mod)
	{
		if (mod is IModCanSave)
		{
			string gUID = mod.Info.Metadata.GUID;
			if (allModData.ContainsKey(gUID))
			{
				allModData.Remove(gUID);
			}
		}
	}

	private static void RegisterModSaveHandler(BaseUnityPlugin mod)
	{
		if (!(mod is IModCanSave mod2))
		{
			return;
		}
		string gUID = mod.Info.Metadata.GUID;
		if (!allModData.ContainsKey(gUID))
		{
			ModSaveSettingsAttribute customAttribute = mod.GetType().GetCustomAttribute<ModSaveSettingsAttribute>();
			LoadOrder loadOrder = LoadOrder.Postload;
			if (customAttribute != null)
			{
				loadOrder = customAttribute.LoadOrder;
			}
			allModData.Add(gUID, new ModSaveSettings
			{
				mod = mod2,
				loadOrder = loadOrder
			});
		}
	}

	internal static bool OnSave(string saveName)
	{
		lastSavedPath = null;
		if (DSPGame.Game == null)
		{
			logger.LogError("No game to save");
			return false;
		}
		if (allModData.Count == 0)
		{
			return true;
		}
		try
		{
			string savePath = GetSavePath(saveName);
			SaveToPath(savePath);
			lastSavedPath = savePath;
			return true;
		}
		catch (Exception ex)
		{
			logger.LogError(ex.Message);
			return false;
		}
	}

	internal static void OnAutoSave()
	{
		string text = GameConfig.gameSaveFolder + GameSave.AutoSaveTmp + ".moddsv";
		string text2 = GameConfig.gameSaveFolder + "_autosave_0.moddsv";
		string text3 = GameConfig.gameSaveFolder + "_autosave_1.moddsv";
		string text4 = GameConfig.gameSaveFolder + "_autosave_2.moddsv";
		string text5 = GameConfig.gameSaveFolder + "_autosave_3.moddsv";
		if (!(lastSavedPath != text) && File.Exists(text))
		{
			lastSavedPath = null;
			if (File.Exists(text5))
			{
				File.Delete(text5);
			}
			if (File.Exists(text4))
			{
				File.Move(text4, text5);
			}
			if (File.Exists(text3))
			{
				File.Move(text3, text4);
			}
			if (File.Exists(text2))
			{
				File.Move(text2, text3);
			}
			File.Move(text, text2);
		}
	}

	internal static void OnPreLoad(string saveName)
	{
		if (currentFileStream != null)
		{
			currentFileStream.Close();
			currentFileStream = null;
		}
		if (DSPGame.Game == null)
		{
			logger.LogError("No game to load");
			return;
		}
		string savePath = GetSavePath(saveName);
		if (!File.Exists(savePath))
		{
			logger.LogInfo(saveName + ": Game mod save not exist");
			{
				foreach (ModSaveSettings value in allModData.Values)
				{
					if (value.loadOrder == LoadOrder.Preload)
					{
						value.mod.IntoOtherSave();
					}
				}
				return;
			}
		}
		try
		{
			logger.LogInfo("Pre Load!");
			currentFileStream = new FileStream(savePath, FileMode.Open, FileAccess.Read);
			LoadData();
			CallImports(LoadOrder.Preload);
		}
		catch (Exception ex)
		{
			CloseLoad();
			logger.LogError(ex.Message);
			throw;
		}
	}

	internal static void OnPostLoad()
	{
		if (currentFileStream == null)
		{
			foreach (ModSaveSettings value in allModData.Values)
			{
				if (value.loadOrder == LoadOrder.Postload)
				{
					value.mod.IntoOtherSave();
				}
			}
			return;
		}
		logger.LogInfo("Post Load!");
		try
		{
			CallImports(LoadOrder.Postload);
		}
		catch (Exception ex)
		{
			logger.LogError(ex.Message);
			throw;
		}
		finally
		{
			CloseLoad();
		}
	}

	internal static void OnDeleteSave(string saveName)
	{
		string savePath = GetSavePath(saveName);
		if (File.Exists(savePath))
		{
			File.Delete(savePath);
		}
	}

	internal static void SaveData(FileStream fileStream)
	{
		using BinaryWriter binaryWriter = new BinaryWriter(fileStream, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false), leaveOpen: true);
		Dictionary<string, long> dictionary = new Dictionary<string, long>();
		binaryWriter.Write('M');
		binaryWriter.Write('O');
		binaryWriter.Write('D');
		binaryWriter.Write(1);
		binaryWriter.Write(0L);
		binaryWriter.Write(0L);
		binaryWriter.Write(0L);
		binaryWriter.Write(0L);
		binaryWriter.Write(0L);
		binaryWriter.Write(allModData.Count);
		foreach (KeyValuePair<string, ModSaveSettings> allModDatum in allModData)
		{
			binaryWriter.Write(allModDatum.Key);
			dictionary.Add(allModDatum.Key, fileStream.Position);
			binaryWriter.Write(0L);
			binaryWriter.Write(0L);
		}
		foreach (KeyValuePair<string, ModSaveSettings> allModDatum2 in allModData)
		{
			string key = allModDatum2.Key;
			if (!dictionary.ContainsKey(key))
			{
				continue;
			}
			long position = fileStream.Position;
			try
			{
				using MemoryStream memoryStream = new MemoryStream();
				using BinaryWriter w = new BinaryWriter(memoryStream);
				allModDatum2.Value.mod.Export(w);
				byte[] array = memoryStream.ToArray();
				fileStream.Write(array, 0, array.Length);
			}
			catch (Exception innerException)
			{
				throw new InvalidDataException("Mod data export failed: " + allModDatum2.Key, innerException);
			}
			long position2 = fileStream.Position;
			fileStream.Seek(dictionary[key], SeekOrigin.Begin);
			binaryWriter.Write(position);
			binaryWriter.Write(position2);
			fileStream.Seek(0L, SeekOrigin.End);
		}
	}

	internal static void LoadData()
	{
		using BinaryReader binaryReader = new BinaryReader(currentFileStream, new UTF8Encoding(encoderShouldEmitUTF8Identifier: false), leaveOpen: true);
		saveEntries.Clear();
		if (binaryReader.ReadChar() != 'M' || binaryReader.ReadChar() != 'O' || binaryReader.ReadChar() != 'D')
		{
			throw new InvalidDataException("Invalid mod save header");
		}
		if (binaryReader.ReadInt32() != 1)
		{
			throw new InvalidDataException("Unsupported mod save version");
		}
		for (int i = 0; i < 5; i++)
		{
			binaryReader.ReadInt64();
		}
		int num = binaryReader.ReadInt32();
		if (num < 0 || num > (currentFileStream.Length - currentFileStream.Position) / 17)
		{
			throw new InvalidDataException("Invalid mod entry count");
		}
		Dictionary<string, ModSaveEntry> dictionary = new Dictionary<string, ModSaveEntry>();
		for (int j = 0; j < num; j++)
		{
			string text = binaryReader.ReadString();
			long begin = binaryReader.ReadInt64();
			long end = binaryReader.ReadInt64();
			if (string.IsNullOrEmpty(text) || dictionary.ContainsKey(text))
			{
				throw new InvalidDataException("Duplicate/empty mod entry");
			}
			dictionary.Add(text, new ModSaveEntry(text, begin, end));
		}
		long position = currentFileStream.Position;
		foreach (ModSaveEntry value in dictionary.Values)
		{
			if (value.begin < position || value.end < value.begin || value.end > currentFileStream.Length || value.end - value.begin > int.MaxValue)
			{
				throw new InvalidDataException("Mod entry outside data region: " + value.name);
			}
		}
		long num2 = position;
		foreach (ModSaveEntry item in dictionary.Values.OrderBy((ModSaveEntry e) => e.begin))
		{
			if (item.begin < num2)
			{
				throw new InvalidDataException("Overlapping mod entries");
			}
			num2 = item.end;
		}
		saveEntries = dictionary;
	}

	private static string GetSavePath(string saveName)
	{
		saveName = (GameSave.AllowRecursive ? saveName.ValidPathedFileName() : saveName.ValidFileName());
		return GameConfig.gameSaveFolder + saveName + ".moddsv";
	}

	private static void SaveToPath(string path)
	{
		string text = path + ".tmp-" + Guid.NewGuid().ToString("N");
		try
		{
			using (FileStream fileStream = new FileStream(text, FileMode.CreateNew, FileAccess.Write, FileShare.None))
			{
				SaveData(fileStream);
				fileStream.Flush(flushToDisk: true);
			}
			if (File.Exists(path))
			{
				File.Replace(text, path, null, ignoreMetadataErrors: true);
			}
			else
			{
				File.Move(text, path);
			}
		}
		finally
		{
			if (File.Exists(text))
			{
				File.Delete(text);
			}
		}
	}

	internal static void CloseLoad()
	{
		currentFileStream?.Dispose();
		currentFileStream = null;
		saveEntries.Clear();
	}

	private static void CallImports(LoadOrder currentState)
	{
		foreach (KeyValuePair<string, ModSaveSettings> allModDatum in allModData)
		{
			if (allModDatum.Value.loadOrder != currentState)
			{
				continue;
			}
			if (!saveEntries.ContainsKey(allModDatum.Key))
			{
				allModDatum.Value.mod.IntoOtherSave();
				continue;
			}
			ModSaveEntry modSaveEntry = saveEntries[allModDatum.Key];
			currentFileStream.Seek(modSaveEntry.begin, SeekOrigin.Begin);
			byte[] array = new byte[modSaveEntry.end - modSaveEntry.begin];
			int num;
			for (int i = 0; i < array.Length; i += num)
			{
				num = currentFileStream.Read(array, i, array.Length - i);
				if (num == 0)
				{
					throw new EndOfStreamException();
				}
			}
			try
			{
				using MemoryStream input = new MemoryStream(array);
				using BinaryReader r = new BinaryReader(input);
				allModDatum.Value.mod.Import(r);
			}
			catch (Exception innerException)
			{
				throw new InvalidDataException("Mod data import failed: " + allModDatum.Key, innerException);
			}
		}
	}
}
