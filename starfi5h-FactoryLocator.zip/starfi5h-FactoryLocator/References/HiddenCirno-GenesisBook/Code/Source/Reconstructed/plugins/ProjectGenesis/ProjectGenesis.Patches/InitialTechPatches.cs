using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using ProjectGenesis.Utils;

namespace ProjectGenesis.Patches;

public static class InitialTechPatches
{
	internal static readonly List<int> InitialTechs = new List<int> { 1, 1900, 1415 };

	private static readonly List<int> BonusTechs = new List<int> { 1001, 1120, 1941, 1801, 1701, 1963 };

	[HarmonyPatch(typeof(GameData), "SetForNewGame")]
	[HarmonyPostfix]
	public static void SetForNewGame(GameData __instance)
	{
		if (DSPGame.LoadDemoIndex > 0 || DSPGame.IsMenuDemo)
		{
			return;
		}
		__instance.history.recipeUnlocked.Remove(5);
		foreach (int item in InitialTechs.Concat(BonusTechs))
		{
			if (!__instance.history.TechUnlocked(item))
			{
				__instance.history.UnlockTech(item);
			}
		}
	}

	[HarmonyPatch(typeof(GameData), "Import")]
	[HarmonyPostfix]
	public static void Import(GameData __instance)
	{
		if (DSPGame.LoadDemoIndex > 0 || DSPGame.IsMenuDemo)
		{
			return;
		}
		foreach (int item in InitialTechs.Concat(BonusTechs))
		{
			if (!__instance.history.TechUnlocked(item))
			{
				__instance.history.UnlockTech(item);
			}
		}
		foreach (KeyValuePair<int, TechState> techState in __instance.history.techStates)
		{
			KvpDeconstruct.Deconstruct(techState, out var i, out var value);
			int id = i;
			if (!value.unlocked)
			{
				continue;
			}
			TechProto techProto = LDB.techs.Select(id);
			if (techProto != null)
			{
				int[] unlockRecipes = techProto.UnlockRecipes;
				for (i = 0; i < unlockRecipes.Length; i++)
				{
					int recipeId = unlockRecipes[i];
					__instance.history.UnlockRecipe(recipeId);
				}
			}
		}
	}
}
