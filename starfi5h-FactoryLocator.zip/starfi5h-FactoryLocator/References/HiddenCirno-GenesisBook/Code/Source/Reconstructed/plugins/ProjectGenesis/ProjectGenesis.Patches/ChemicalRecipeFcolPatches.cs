using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection.Emit;
using HarmonyLib;
using ProjectGenesis.Utils;
using UnityEngine;

namespace ProjectGenesis.Patches;

public static class ChemicalRecipeFcolPatches
{
	private static readonly Dictionary<int, int> RecipeIdPos = new Dictionary<int, int>
	{
		{ 506, 431 },
		{ 509, 432 },
		{ 512, 433 },
		{ 550, 434 },
		{ 702, 435 },
		{ 703, 436 },
		{ 710, 437 },
		{ 716, 438 },
		{ 717, 439 },
		{ 720, 440 },
		{ 771, 441 },
		{ 772, 442 },
		{ 773, 443 },
		{ 801, 444 },
		{ 549, 445 },
		{ 108, 447 },
		{ 107, 448 },
		{ 34, 449 },
		{ 121, 450 },
		{ 401, 451 }
	};

	private static readonly Dictionary<int, Color32> ItemColors = new Dictionary<int, Color32>
	{
		{
			1117,
			new Color32(153, 163, 87, byte.MaxValue)
		},
		{
			7101,
			new Color32(244, 244, 244, byte.MaxValue)
		},
		{
			1114,
			new Color32(244, 244, 244, byte.MaxValue)
		},
		{
			7020,
			new Color32(58, 97, 164, byte.MaxValue)
		},
		{
			1014,
			new Color32(229, 153, byte.MaxValue, byte.MaxValue)
		},
		{
			1124,
			new Color32(121, 110, 114, byte.MaxValue)
		},
		{
			1123,
			new Color32(150, 161, 174, byte.MaxValue)
		},
		{
			6201,
			new Color32(54, 54, 54, byte.MaxValue)
		},
		{
			7708,
			new Color32(210, 190, 144, byte.MaxValue)
		},
		{
			7709,
			new Color32(21, 21, 21, byte.MaxValue)
		},
		{
			1000,
			new Color32(165, 198, 208, byte.MaxValue)
		},
		{
			1003,
			new Color32(55, 179, 114, byte.MaxValue)
		},
		{
			1004,
			new Color32(195, 220, 250, byte.MaxValue)
		},
		{
			1005,
			new Color32(137, 145, 165, byte.MaxValue)
		},
		{
			1143,
			new Color32(21, 175, 251, byte.MaxValue)
		}
	};

	private static readonly Dictionary<int, int[][]> InputIndexMap = new Dictionary<int, int[][]>
	{
		{
			1,
			new int[1][] { new int[5] { 8, 7, 5, 4, 3 } }
		},
		{
			2,
			new int[2][]
			{
				new int[3] { 8, 5, 4 },
				new int[2] { 7, 3 }
			}
		},
		{
			3,
			new int[3][]
			{
				new int[2] { 8, 5 },
				new int[2] { 7, 4 },
				new int[1] { 3 }
			}
		}
	};

	[HarmonyPatch(typeof(FactorySystem), "GameTick", new Type[]
	{
		typeof(long),
		typeof(bool)
	})]
	[HarmonyPatch(typeof(GameLogic), "_assembler_parallel")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> FactorySystem_GameTick_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(AssemblerComponent), "recipeType")));
		codeMatcher.Advance(1).SetInstructionAndAdvance(new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(ChemicalRecipeFcolPatches), "ChemicalRecipeTypePatch"))).SetOpcodeAndAdvance(OpCodes.Brfalse_S);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(AssemblerComponent), "recipeId")), new CodeMatch(OpCodes.Conv_R4), new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(AnimData), "working_length")));
		codeMatcher.Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(ChemicalRecipeFcolPatches), "ChemicalRecipeFcolPatch")));
		return codeMatcher.InstructionEnumeration();
	}

	private static bool ChemicalRecipeTypePatch(int recipeType)
	{
		if (recipeType != 2)
		{
			return recipeType == 16;
		}
		return true;
	}

	private static int ChemicalRecipeFcolPatch(int recipeId)
	{
		return RecipeIdPos.GetValueOrDefault(recipeId, recipeId);
	}

	internal static void SetChemicalRecipeFcol()
	{
		Texture texture = TextureHelper.GetTexture("化工厂渲染索引");
		int nameID = Shader.PropertyToID("_FluidTex");
		ref PrefabDesc prefabDesc = ref LDB.models.Select(64).prefabDesc;
		prefabDesc.lodMaterials[0][1].SetTexture(nameID, texture);
		prefabDesc.lodMaterials[1][1].SetTexture(nameID, texture);
		ref PrefabDesc prefabDesc2 = ref LDB.models.Select(376).prefabDesc;
		prefabDesc2.lodMaterials[0][1].SetTexture(nameID, texture);
		prefabDesc2.lodMaterials[1][1].SetTexture(nameID, texture);
	}

	private static Color32 GetItemColor(int itemId)
	{
		if (ItemColors.TryGetValue(itemId, out var value))
		{
			return value;
		}
		IconDescUtils.ModIconDesc value2;
		return IconDescUtils.IconDescs.TryGetValue(itemId, out value2) ? value2.Color : IconDescUtils.ExportIconDesc(itemId).faceColor;
	}

	private static void SetDefaultColors(Texture2D texture, int column)
	{
		Color[] colors = Enumerable.Repeat((Color)new Color32(165, 198, 208, byte.MaxValue), 16).ToArray();
		texture.SetPixels(column, 0, 1, 16, colors);
	}

	private static void ApplyColors(Texture2D texture, int column, Color32 color, int[] positions)
	{
		foreach (int y in positions)
		{
			texture.SetPixel(column, y, color);
		}
	}

	private static void ApplyRecipeColors(Texture2D texture, int column, RecipeProto proto)
	{
		ApplyColors(texture, column, GetItemColor(proto.Results[0]), new int[5] { 9, 6, 2, 1, 0 });
		if (InputIndexMap.TryGetValue(proto.Items.Length, out var value))
		{
			for (int i = 0; i < value.Length; i++)
			{
				ApplyColors(texture, column, GetItemColor(proto.Items[i]), value[i]);
			}
		}
	}

	internal static void GenerateRecipeTexture(string outputFilePath)
	{
		int[] array = new int[0];
		int[] array2 = array.Select((int i) => RecipeIdPos[i]).ToArray();
		Texture2D texture = TextureHelper.GetTexture("化工厂渲染索引");
		for (int num = 0; num < array.Length; num++)
		{
			int column = array2[num];
			SetDefaultColors(texture, column);
			RecipeProto recipeProto = LDB.recipes.Select(array[num]);
			if (recipeProto != null && (recipeProto.Type == ERecipeType.Chemical || recipeProto.Type == (ERecipeType)16))
			{
				ApplyRecipeColors(texture, column, recipeProto);
			}
		}
		texture.Apply();
		File.WriteAllBytes(outputFilePath, texture.EncodeToPNG());
	}
}
