using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using ProjectGenesis.Utils;

namespace ProjectGenesis.Patches;

public static class ProductOverflowPatches
{
	private static readonly FieldInfo AssemblerComponent_RecipeType_FieldInfo = AccessTools.Field(typeof(AssemblerComponent), "recipeType");

	[HarmonyPatch(typeof(AssemblerComponent), "InternalUpdate")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> AssemblerComponent_InternalUpdate_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(AssemblerComponent), "extraSpeed")));
		object operand = codeMatcher.Labels.First();
		codeMatcher.Start().MatchForward(false, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld, AssemblerComponent_RecipeType_FieldInfo), new CodeMatch(OpCodes.Ldc_I4_3));
		codeMatcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldarg_2), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(ProductOverflowPatches), "AssemblerComponent_InsertMethod")), new CodeInstruction(OpCodes.Brtrue_S, operand), new CodeInstruction(OpCodes.Ldc_I4_0), new CodeInstruction(OpCodes.Ret));
		return codeMatcher.InstructionEnumeration();
	}

	public static bool AssemblerComponent_InsertMethod(ref AssemblerComponent component, int[] productRegister)
	{
		RecipeExecuteData recipeExecuteData = component.recipeExecuteData;
		int num = recipeExecuteData.products.Length;
		int[] products = recipeExecuteData.products;
		int[] productCounts = recipeExecuteData.productCounts;
		int[] produced = component.produced;
		int num2;
		switch (component.recipeType)
		{
		case ERecipeType.Smelt:
		case (ERecipeType)11:
		case (ERecipeType)13:
		case (ERecipeType)19:
			num2 = 100;
			break;
		default:
			num2 = 20;
			break;
		}
		EOverflowFlag eOverflowFlag = (EOverflowFlag)(LDB.recipes.Select(component.recipeId)?.Overflow ?? 0);
		if ((ProjectGenesis.ProductOverflowEntry.Value == 0 && eOverflowFlag != EOverflowFlag.None) || ProjectGenesis.ProductOverflowEntry.Value == 1)
		{
			int num3 = 0;
			for (int i = 0; i < num; i++)
			{
				bool flag = IsProductAllowedToOverflow(i, eOverflowFlag);
				int num4 = productCounts[i] * num2;
				if (produced[i] >= num4)
				{
					if (!flag)
					{
						return false;
					}
					num3++;
				}
			}
			if (num3 == num)
			{
				return false;
			}
			for (int j = 0; j < num; j++)
			{
				int num5 = productCounts[j];
				int num6 = num5 * num2;
				if (IsProductAllowedToOverflow(j, eOverflowFlag) && produced[j] >= num6)
				{
					produced[j] = num6;
					continue;
				}
				produced[j] += num5;
				lock (productRegister)
				{
					productRegister[products[j]] += num5;
				}
			}
			return true;
		}
		for (int k = 0; k < num; k++)
		{
			if (produced[k] > productCounts[k] * num2)
			{
				return false;
			}
		}
		for (int l = 0; l < num; l++)
		{
			produced[l] += productCounts[l];
			lock (productRegister)
			{
				productRegister[products[l]] += productCounts[l];
			}
		}
		return true;
	}

	private static bool IsProductAllowedToOverflow(int productIndex, EOverflowFlag overflowFlag)
	{
		if ((overflowFlag & EOverflowFlag.All) == EOverflowFlag.All)
		{
			return true;
		}
		return productIndex switch
		{
			0 => (overflowFlag & EOverflowFlag.FirstProduct) == EOverflowFlag.FirstProduct, 
			1 => (overflowFlag & EOverflowFlag.SecondProduct) == EOverflowFlag.SecondProduct, 
			2 => (overflowFlag & EOverflowFlag.ThirdProduct) == EOverflowFlag.ThirdProduct, 
			3 => (overflowFlag & EOverflowFlag.FourthProduct) == EOverflowFlag.FourthProduct, 
			4 => (overflowFlag & EOverflowFlag.FifthProduct) == EOverflowFlag.FifthProduct, 
			_ => false, 
		};
	}
}
