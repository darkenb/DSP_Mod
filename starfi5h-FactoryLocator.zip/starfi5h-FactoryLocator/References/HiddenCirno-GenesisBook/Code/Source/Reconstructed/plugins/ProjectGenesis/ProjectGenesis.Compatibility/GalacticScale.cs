using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using BepInEx.Bootstrap;
using GalacticScale;
using HarmonyLib;
using PCGSharp;
using ProjectGenesis.Patches;
using UnityEngine;

namespace ProjectGenesis.Compatibility;

internal static class GalacticScale
{
	internal const string GUID = "dsp.galactic-scale.2";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.dsp.galactic-scale.2");

	internal static void Awake()
	{
		if (!Chainloader.PluginInfos.TryGetValue("dsp.galactic-scale.2", out var value))
		{
			return;
		}
		Assembly assembly = value.Instance.GetType().Assembly;
		foreach (FieldInfo declaredField in AccessTools.GetDeclaredFields(assembly.GetType("GalacticScale.Themes")))
		{
			GSThemeModify.ModifyTheme(ref AccessTools.StaticFieldRefAccess<GSTheme>(declaredField)());
		}
		GSVeinType.saneVeinTypes["Aluminum"] = EVeinType.Max;
		GSVeinType.saneVeinTypes["Radioactive"] = (EVeinType)16;
		GSVeinType.saneVeinTypes["Niobium"] = (EVeinType)17;
		GSVeinType.saneVeinTypes["Sulfur"] = (EVeinType)18;
		GSVeinType.saneVeinTypes["Salt"] = (EVeinType)19;
		GSVeinType.saneVeinTypes["Tholin"] = (EVeinType)20;
		GSVeinType.insaneVeinTypes[EVeinType.Max] = "Aluminum";
		GSVeinType.insaneVeinTypes[(EVeinType)16] = "Radioactive";
		GSVeinType.insaneVeinTypes[(EVeinType)17] = "Niobium";
		GSVeinType.insaneVeinTypes[(EVeinType)18] = "Sulfur";
		GSVeinType.insaneVeinTypes[(EVeinType)19] = "Salt";
		GSVeinType.insaneVeinTypes[(EVeinType)20] = "Tholin";
		HarmonyPatch.Patch(AccessTools.Method(assembly.GetType("GalacticScale.GS2"), "SetPlanetTheme"), null, new HarmonyMethod(typeof(GalacticScale), "SetPlanetTheme_Postfix"), new HarmonyMethod(typeof(GalacticScale), "SetPlanetTheme_Transpiler"));
		HarmonyPatch.Patch(AccessTools.Method(assembly.GetType("GalacticScale.GSTheme"), "ToProto"), null, new HarmonyMethod(typeof(GalacticScale), "GSTheme_ToProto_Postfix"));
		Type type = assembly.GetType("GalacticScale.VeinAlgorithms");
		if (type != null)
		{
			HarmonyPatch.Patch(AccessTools.Method(type, "DisableVeins"), null, null, new HarmonyMethod(typeof(GalacticScale), "DisableVeins_Transpiler"));
			HarmonyPatch.Patch(AccessTools.Method(type, "DistributeVeinTypes"), new HarmonyMethod(typeof(GalacticScale), "DistributeVeinTypes_Prefix"));
			HarmonyPatch.Patch(AccessTools.Method(type, "GenBirthPoints"), null, new HarmonyMethod(typeof(GalacticScale), "GenBirthPoints_Postfix"));
			HarmonyPatch.Patch(AccessTools.Method(type, "CalculateVectorsGS2"), null, new HarmonyMethod(typeof(GalacticScale), "CalculateVectorsGS2_Postfix"));
			HarmonyPatch.Patch(AccessTools.Method(type, "InitBirthVeinVectors"), new HarmonyMethod(typeof(GalacticScale), "InitBirthVeinVectors_Postfix"));
			HarmonyPatch.Patch(AccessTools.PropertyGetter(assembly.GetType("GalacticScale.GS2MainSettings"), "VeinTips"), null, null, new HarmonyMethod(typeof(GalacticScale), "GS2MainSettings_VeinTips_Getter_Transpiler"));
		}
		MethodInfo methodInfo = AccessTools.Method(assembly.GetType("GalacticScale.PatchOnUIPlanetDetail"), "OnPlanetDataSet7Prefix");
		if (methodInfo != null)
		{
			HarmonyPatch.Patch(methodInfo, null, null, new HarmonyMethod(typeof(GalacticScale), "OnPlanetDataSet_Transpiler"));
			HarmonyPatch.Patch(methodInfo, null, null, new HarmonyMethod(typeof(UIDetailPatches), "OnDataSet_ChangeHighlightWaterId_Transpiler"));
			HarmonyPatch.Patch(methodInfo, null, null, new HarmonyMethod(typeof(GalacticScale), "OnPlanetDataSet_ChangeVeinData_Transpiler"));
		}
		MethodInfo methodInfo2 = AccessTools.Method(assembly.GetType("GalacticScale.PatchOnUIStarDetail"), "OnStarDataSet2");
		if (methodInfo2 != null)
		{
			HarmonyPatch.Patch(methodInfo2, null, null, new HarmonyMethod(typeof(UIDetailPatches), "OnDataSet_ChangeHighlightWaterId_Transpiler"));
			HarmonyPatch.Patch(methodInfo2, null, null, new HarmonyMethod(typeof(UIDetailPatches), "UIStarDetail_OnStarDataSet_ActiveGasItems_Transpiler"));
			HarmonyPatch.Patch(methodInfo2, null, null, new HarmonyMethod(typeof(UIDetailPatches), "UIPlanetDetail_OnPlanetDataSet_FixCollectorSpeed_Transpiler"));
			HarmonyPatch.Patch(methodInfo2, null, null, new HarmonyMethod(typeof(GalacticScale), "OnStarDataSet_ChangeVeinData_Transpiler"));
		}
	}

	public static IEnumerable<CodeInstruction> SetPlanetTheme_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(PlanetData), "type")), new CodeMatch(OpCodes.Ldc_I4_5));
		codeMatcher.ThrowIfInvalid("GalacticScale gas-only theme guard not found");
		codeMatcher.SetAndAdvance(OpCodes.Ldc_I4_5, null);
		codeMatcher.SetAndAdvance(OpCodes.Nop, null);
		return codeMatcher.InstructionEnumeration();
	}

	public static void DistributeVeinTypes_Prefix(GSPlanet gsPlanet)
	{
		if (GSSettings.BirthPlanet != gsPlanet)
		{
			return;
		}
		GSVeinType val = GSVeinType.Generate((EVeinType)16, 1, 1, 0.6f, 0.6f, 6, 6, false);
		GSVeinType val2 = GSVeinType.Generate(EVeinType.Fireice, 1, 1, 0.6f, 0.6f, 6, 6, false);
		GSVeinType val3 = GSVeinType.Generate((EVeinType)18, 10, 10, 0.3f, 0.3f, 5, 5, false);
		List<EVeinType> list = ((IEnumerable<GSVeinType>)gsPlanet.veinSettings.VeinTypes).Select((GSVeinType veinType) => veinType.type).ToList();
		if (!list.Contains((EVeinType)16))
		{
			gsPlanet.veinSettings.VeinTypes.Add(val);
		}
		if (!list.Contains(EVeinType.Fireice))
		{
			gsPlanet.veinSettings.VeinTypes.Add(val2);
		}
		if (!list.Contains((EVeinType)18))
		{
			gsPlanet.veinSettings.VeinTypes.Add(val3);
		}
		for (int num = 0; num < ((List<GSVeinType>)(object)gsPlanet.veinSettings.VeinTypes).Count; num++)
		{
			switch (((List<GSVeinType>)(object)gsPlanet.veinSettings.VeinTypes)[num].type)
			{
			case (EVeinType)16:
				((List<GSVeinType>)(object)gsPlanet.veinSettings.VeinTypes)[num] = val;
				break;
			case EVeinType.Fireice:
				((List<GSVeinType>)(object)gsPlanet.veinSettings.VeinTypes)[num] = val2;
				break;
			case (EVeinType)18:
				((List<GSVeinType>)(object)gsPlanet.veinSettings.VeinTypes)[num] = val3;
				break;
			}
		}
	}

	public static void CalculateVectorsGS2_Postfix(GSPlanet gsPlanet, List<GSVeinDescriptor> __result)
	{
		//IL_0013: Unknown result type (might be due to invalid IL or missing references)
		//IL_0018: Unknown result type (might be due to invalid IL or missing references)
		//IL_001f: Unknown result type (might be due to invalid IL or missing references)
		//IL_0030: Unknown result type (might be due to invalid IL or missing references)
		//IL_0037: Unknown result type (might be due to invalid IL or missing references)
		//IL_003f: Unknown result type (might be due to invalid IL or missing references)
		//IL_004f: Expected O, but got Unknown
		if (gsPlanet.planetData.id == GSSettings.BirthPlanetId)
		{
			__result.Add(new GSVeinDescriptor
			{
				count = 6,
				position = gsPlanet.planetData.birthResourcePoint2,
				rare = false,
				type = EVeinType.Max,
				richness = 0.1f
			});
		}
	}

	public static void GenBirthPoints_Postfix(GSPlanet gsPlanet)
	{
		//IL_0005: Unknown result type (might be due to invalid IL or missing references)
		//IL_000b: Expected O, but got Unknown
		Random val = new Random(GSSettings.Seed);
		PlanetData planetData = gsPlanet.planetData;
		double num = 85.0 / planetData.orbitalPeriod + (double)planetData.orbitPhase / 360.0;
		int num2 = (int)(num + 0.1);
		double num3 = (num - (double)num2) * (Math.PI * 2.0);
		double num4 = 85.0 / planetData.rotationPeriod + (double)planetData.rotationPhase / 360.0;
		int num5 = (int)(num4 + 0.1);
		double num6 = (num4 - (double)num5) * 360.0;
		Vector3 position = Maths.QRotate(v: new Vector3((float)Math.Cos(num3) * planetData.orbitRadius, 0f, (float)Math.Sin(num3) * planetData.orbitRadius), q: planetData.runtimeOrbitRotation);
		Pose pose;
		if (planetData.orbitAroundPlanet != null)
		{
			pose = planetData.orbitAroundPlanet.PredictPose(85.0);
			position.x += pose.position.x;
			position.y += pose.position.y;
			position.z += pose.position.z;
		}
		pose = new Pose(position, planetData.runtimeSystemRotation * Quaternion.AngleAxis((float)num6, Vector3.down));
		Vector3 vector = Maths.QInvRotateLF(pose.rotation, planetData.star.uPosition - (VectorLF3)pose.position * 40000.0);
		vector.Normalize();
		Vector3 normalized = Vector3.Cross(vector, Vector3.up).normalized;
		Vector3 normalized2 = Vector3.Cross(normalized, vector).normalized;
		int num7 = 0;
		while (num7++ < 256)
		{
			float num8 = (float)(((Pcg)val).NextDouble() * 2.0 - 1.0) * 0.5f;
			float num9 = (float)(((Pcg)val).NextDouble() * 2.0 - 1.0) * 0.5f;
			Vector3 vector2 = vector + num8 * normalized + num9 * normalized2;
			vector2.Normalize();
			planetData.birthPoint = vector2 * (float)((double)planetData.realRadius + 0.20000000298023224 + 1.5800000429153442);
			normalized = Vector3.Cross(vector2, Vector3.up).normalized;
			normalized2 = Vector3.Cross(normalized, vector2).normalized;
			bool flag = false;
			for (int i = 0; i < 10; i++)
			{
				Vector2 v = new Vector2((float)(((Pcg)val).NextDouble() * 2.0 - 1.0), (float)(((Pcg)val).NextDouble() * 2.0 - 1.0)).normalized * 0.1f;
				Vector2 vector3 = AddVeinPatches.Rotate(v, 120f);
				float num10 = (float)(((Pcg)val).NextDouble() * 2.0 - 1.0) * 0.006f;
				float num11 = (float)(((Pcg)val).NextDouble() * 2.0 - 1.0) * 0.006f;
				vector3.x += num10;
				vector3.y += num11;
				Vector2 vector4 = AddVeinPatches.Rotate(v, 240f);
				float num12 = (float)(((Pcg)val).NextDouble() * 2.0 - 1.0) * 0.006f;
				float num13 = (float)(((Pcg)val).NextDouble() * 2.0 - 1.0) * 0.006f;
				vector4.x += num12;
				vector4.y += num13;
				Vector3 normalized3 = (vector2 + v.x * normalized + v.y * normalized2).normalized;
				Vector3 normalized4 = (vector2 + vector3.x * normalized + vector3.y * normalized2).normalized;
				Vector3 normalized5 = (vector2 + vector4.x * normalized + vector4.y * normalized2).normalized;
				planetData.birthResourcePoint0 = normalized3.normalized;
				planetData.birthResourcePoint1 = normalized4.normalized;
				planetData.birthResourcePoint2 = normalized5.normalized;
				float realRadius = planetData.realRadius;
				if ((double)planetData.data.QueryHeight(vector2) > (double)realRadius && (double)planetData.data.QueryHeight(normalized3) > (double)realRadius && (double)planetData.data.QueryHeight(normalized4) > (double)realRadius)
				{
					Vector3 vpos = normalized3 + normalized * 0.03f;
					Vector3 vpos2 = normalized3 - normalized * 0.03f;
					Vector3 vpos3 = normalized3 + normalized2 * 0.03f;
					Vector3 vpos4 = normalized3 - normalized2 * 0.03f;
					Vector3 vpos5 = normalized4 + normalized * 0.03f;
					Vector3 vpos6 = normalized4 - normalized * 0.03f;
					Vector3 vpos7 = normalized4 + normalized2 * 0.03f;
					Vector3 vpos8 = normalized4 - normalized2 * 0.03f;
					Vector3 vpos9 = normalized5 + normalized * 0.03f;
					Vector3 vpos10 = normalized5 - normalized * 0.03f;
					Vector3 vpos11 = normalized5 + normalized2 * 0.03f;
					Vector3 vpos12 = normalized5 - normalized2 * 0.03f;
					if ((double)planetData.data.QueryHeight(vpos) > (double)realRadius && (double)planetData.data.QueryHeight(vpos2) > (double)realRadius && (double)planetData.data.QueryHeight(vpos3) > (double)realRadius && (double)planetData.data.QueryHeight(vpos4) > (double)realRadius && (double)planetData.data.QueryHeight(vpos5) > (double)realRadius && (double)planetData.data.QueryHeight(vpos6) > (double)realRadius && (double)planetData.data.QueryHeight(vpos7) > (double)realRadius && (double)planetData.data.QueryHeight(vpos8) > (double)realRadius && (double)planetData.data.QueryHeight(vpos9) > (double)realRadius && (double)planetData.data.QueryHeight(vpos10) > (double)realRadius && (double)planetData.data.QueryHeight(vpos11) > (double)realRadius && (double)planetData.data.QueryHeight(vpos12) > (double)realRadius)
					{
						flag = true;
						break;
					}
				}
			}
			if (flag)
			{
				break;
			}
		}
	}

	public static void InitBirthVeinVectors_Postfix(GSPlanet gsPlanet)
	{
		PlanetData planetData = gsPlanet.planetData;
		gsPlanet.veinData.types[2] = EVeinType.Max;
		gsPlanet.veinData.vectors[2] = planetData.birthResourcePoint2;
		gsPlanet.veinData.count = 3;
	}

	public static void SetPlanetTheme_Postfix(PlanetData planet)
	{
		if (planet.type != EPlanetType.Gas)
		{
			planet.gasHeatValues = new float[planet.gasItems.Length];
			planet.gasTotalHeat = 0.0;
		}
	}

	public static void GSTheme_ToProto_Postfix(ThemeProto __result)
	{
		string name = __result.name;
		if (!(name == "SaltLake"))
		{
			if (name == "Gobi")
			{
				__result.oceanMat = LDB.themes.Select(22).oceanMat;
			}
		}
		else
		{
			__result.oceanMat = LDB.themes.Select(8).oceanMat;
		}
	}

	public static IEnumerable<CodeInstruction> GS2MainSettings_VeinTips_Getter_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldc_I4_S, (sbyte)15));
		codeMatcher.SetOperandAndAdvance((sbyte)21);
		return codeMatcher.InstructionEnumeration();
	}

	public static IEnumerable<CodeInstruction> DisableVeins_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldc_I4_S, (sbyte)16));
		int num = 22;
		codeMatcher.SetOperandAndAdvance(num);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldc_I4_S, (sbyte)16));
		codeMatcher.SetOperandAndAdvance(num);
		return codeMatcher.InstructionEnumeration();
	}

	public static IEnumerable<CodeInstruction> OnPlanetDataSet_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldstr, "实际采集速度")).MatchForward(true, new CodeMatch(OpCodes.Nop), new CodeMatch(OpCodes.Br)).SetInstruction(new CodeInstruction(OpCodes.Nop));
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(StationComponent), "collectionPerTick")));
		codeMatcher.Advance(-2).InsertAndAdvance(new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(UIDetailPatches), "GetMiningSpeedScale")));
		return codeMatcher.InstructionEnumeration();
	}

	public static IEnumerable<CodeInstruction> OnPlanetDataSet_ChangeVeinData_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldloc_S), new CodeMatch(OpCodes.Ldc_I4_6), new CodeMatch(OpCodes.Clt));
		object operand = codeMatcher.Operand;
		object operand2 = codeMatcher.Advance(5).Operand;
		object operand3 = codeMatcher.Advance(2).Labels.First();
		codeMatcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand), new CodeInstruction(OpCodes.Ldc_I4, 15), new CodeInstruction(OpCodes.Beq, operand3), new CodeInstruction(OpCodes.Ldc_I4, 14), new CodeInstruction(OpCodes.Stloc_S, operand), new CodeInstruction(OpCodes.Br, operand2));
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldloc_S), new CodeMatch(OpCodes.Ldc_I4_S, (sbyte)15), new CodeMatch(OpCodes.Clt));
		operand = codeMatcher.Operand;
		object operand4 = codeMatcher.Clone().MatchBack(false, new CodeMatch(OpCodes.Brfalse)).Operand;
		codeMatcher.Advance(2).InsertAndAdvance(new CodeInstruction(OpCodes.Beq, operand4), new CodeInstruction(OpCodes.Ldloc_S, operand), new CodeInstruction(OpCodes.Ldc_I4_S, (sbyte)21));
		return codeMatcher.InstructionEnumeration();
	}

	public static IEnumerable<CodeInstruction> OnStarDataSet_ChangeVeinData_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		return AddVeinPatches.OnStarDataSet_ChangeVeinData_Transpiler(instructions);
	}
}
