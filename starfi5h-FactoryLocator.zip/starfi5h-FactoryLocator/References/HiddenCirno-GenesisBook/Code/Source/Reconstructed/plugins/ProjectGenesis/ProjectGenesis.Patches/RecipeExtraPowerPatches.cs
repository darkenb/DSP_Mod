using System.Text;
using HarmonyLib;
using UnityEngine;

namespace ProjectGenesis.Patches;

public static class RecipeExtraPowerPatches
{
	private static readonly StringBuilder _sb = new StringBuilder("         ", 8);

	[HarmonyPatch(typeof(AssemblerComponent), "SetPCState")]
	[HarmonyPrefix]
	public static bool AssemblerComponent_SetPCState_Prefix(ref AssemblerComponent __instance, PowerConsumerComponent[] pcPool)
	{
		ref PowerConsumerComponent reference = ref pcPool[__instance.pcId];
		int num = LDB.recipes.Select(__instance.recipeId)?.PowerFactor ?? 1;
		if (num < 2 || !__instance.replicating)
		{
			return true;
		}
		reference.requiredEnergy = (__instance.replicating ? ((__instance.speedOverride * num / 2 + reference.workEnergyPerTick) * (1000 + __instance.extraPowerRatio) / 1000) : reference.idleEnergyPerTick);
		return false;
	}

	[HarmonyPatch(typeof(UIAssemblerWindow), "_OnUpdate")]
	[HarmonyPostfix]
	public static void UIAssemblerWindow_OnUpdate_Postfix(UIAssemblerWindow __instance)
	{
		if (__instance.powerIcon.color == Color.clear)
		{
			return;
		}
		AssemblerComponent assemblerComponent = __instance.factorySystem.assemblerPool[__instance.assemblerId];
		if (assemblerComponent.id == __instance.assemblerId)
		{
			int num = LDB.recipes.Select(assemblerComponent.recipeId)?.PowerFactor ?? 1;
			if (num >= 2 && assemblerComponent.replicating)
			{
				long valuel = assemblerComponent.speedOverride * num / 2 * (1000 + assemblerComponent.extraPowerRatio) / 100 * 6;
				StringBuilderUtility.WriteKMGPower(_sb, 7, valuel);
				__instance.stateText.text = "[+" + _sb.ToString().Trim() + " ]" + __instance.stateText.text;
			}
		}
	}
}
