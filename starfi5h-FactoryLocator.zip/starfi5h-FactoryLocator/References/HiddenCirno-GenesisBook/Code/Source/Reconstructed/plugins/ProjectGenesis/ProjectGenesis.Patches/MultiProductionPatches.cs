using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectGenesis.Patches;

internal static class MultiProductionPatches
{
	private static readonly List<Image> ReplicatorImages = new List<Image>();

	private static readonly List<Text> ReplicatorTexts = new List<Text>();

	private static readonly List<Image> AssemblerProductProgress = new List<Image>();

	private static readonly List<Image> AssemblerExtraProductProgress = new List<Image>();

	private static readonly List<Image> AssemblerProductIcon = new List<Image>();

	private static readonly List<Text> AssemblerProductCountText = new List<Text>();

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIReplicatorWindow), "OnSelectedRecipeChange")]
	public static void UIReplicatorWindow_OnSelectedRecipeChange(UIReplicatorWindow __instance)
	{
		RecipeProto selectedRecipe = UIRoot.instance.uiGame.replicator.selectedRecipe;
		if (selectedRecipe == null)
		{
			return;
		}
		int num = selectedRecipe.Results.Length;
		if (num <= 2)
		{
			ReplicatorImages.ForEach(delegate(Image image2)
			{
				image2.gameObject.SetActive(value: false);
			});
			ReplicatorTexts.ForEach(delegate(Text text2)
			{
				text2.gameObject.SetActive(value: false);
			});
			__instance.treeMainIcon1.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(25f, 0f);
			__instance.treeMainCountText1.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(1f, -11f);
			return;
		}
		if (ReplicatorImages.Count < num - 2)
		{
			for (int num2 = ReplicatorImages.Count; num2 < num - 2; num2++)
			{
				ReplicatorImages.Add(Object.Instantiate(__instance.treeMainIcon1, __instance.treeMainIcon1.transform.parent));
				ReplicatorTexts.Add(Object.Instantiate(__instance.treeMainCountText1, __instance.treeMainCountText1.transform.parent));
			}
		}
		for (int num3 = 0; num3 < ReplicatorImages.Count; num3++)
		{
			Image image = ReplicatorImages[num3];
			Text text = ReplicatorTexts[num3];
			if (num3 >= num - 2)
			{
				image.gameObject.SetActive(value: false);
				text.gameObject.SetActive(value: false);
				continue;
			}
			image.gameObject.SetActive(value: true);
			text.gameObject.SetActive(value: true);
			ItemProto itemProto = LDB.items.Select(selectedRecipe.Results[num3 + 2]);
			int num4 = selectedRecipe.ResultCounts[num3 + 2];
			UIButton component = image.gameObject.GetComponent<UIButton>();
			component.tips.itemId = itemProto?.ID ?? 0;
			component.tips.type = UIButton.ItemTipType.IgnoreIncPoint;
			image.sprite = itemProto?.iconSprite;
			text.gameObject.SetActive(num4 > 1);
			text.text = ((num4 > 1) ? ("x" + num4) : "");
			image.GetComponent<RectTransform>().anchoredPosition = new Vector2(-32 * (num - 1) + 64 * (num3 + 2), 0f);
			text.GetComponent<RectTransform>().anchoredPosition = new Vector2(-32 * (num - 1) + 64 * (num3 + 2) - 24, -11f);
		}
		__instance.treeMainBox.sizeDelta = new Vector2(64 * num, 64f);
		__instance.treeMainIcon0.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(-32 * (num - 1), 0f);
		__instance.treeMainIcon1.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(-32 * (num - 1) + 64, 0f);
		__instance.treeMainCountText0.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(-32 * (num - 1) - 24, -11f);
		__instance.treeMainCountText1.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(-32 * (num - 1) + 64 - 24, -11f);
		foreach (UIButton treeUp in UIRoot.instance.uiGame.replicator.treeUpList)
		{
			treeUp.gameObject.SetActive(value: false);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIAssemblerWindow), "_OnUpdate")]
	public static void UIAssemblerWindow_OnUpdate(UIAssemblerWindow __instance)
	{
		if (__instance.assemblerId == 0 || __instance.factory == null)
		{
			return;
		}
		AssemblerComponent assemblerComponent = __instance.factorySystem.assemblerPool[__instance.assemblerId];
		if (assemblerComponent.id != __instance.assemblerId || assemblerComponent.recipeId == 0)
		{
			return;
		}
		int[] products = assemblerComponent.recipeExecuteData.products;
		int num = products.Length;
		if (num <= 2)
		{
			AssemblerProductProgress.ForEach(delegate(Image image5)
			{
				image5.gameObject.SetActive(value: false);
			});
			AssemblerExtraProductProgress.ForEach(delegate(Image image5)
			{
				image5.gameObject.SetActive(value: false);
			});
			AssemblerProductIcon.ForEach(delegate(Image image5)
			{
				image5.gameObject.SetActive(value: false);
			});
			AssemblerProductCountText.ForEach(delegate(Text text2)
			{
				text2.gameObject.SetActive(value: false);
			});
			return;
		}
		if (AssemblerProductProgress.Count < num - 2)
		{
			for (int num2 = AssemblerProductProgress.Count; num2 < num - 2; num2++)
			{
				AssemblerProductProgress.Add(Object.Instantiate(__instance.productProgress1, __instance.productProgress1.transform.parent));
				AssemblerExtraProductProgress.Add(Object.Instantiate(__instance.extraProductProgress1, __instance.extraProductProgress1.transform.parent));
				AssemblerProductCountText.Add(Object.Instantiate(__instance.productCountText1, __instance.productCountText1.transform.parent));
				Image image = Object.Instantiate(__instance.productIcon1, __instance.productIcon1.transform.parent);
				UIAssemblerWindow instance = __instance;
				int index = num2 + 2;
				image.gameObject.GetComponent<UIButton>().button.onClick.AddListener(delegate
				{
					if (instance.assemblerId != 0 && instance.factory != null)
					{
						AssemblerComponent assemblerComponent2 = instance.factorySystem.assemblerPool[instance.assemblerId];
						int[] products2 = assemblerComponent2.recipeExecuteData.products;
						if (assemblerComponent2.id == instance.assemblerId && assemblerComponent2.recipeId != 0 && products2.Length >= index + 1 && assemblerComponent2.produced[index] > 0)
						{
							int num5 = instance.player.TryAddItemToPackage(products2[index], assemblerComponent2.produced[index], 0, throwTrash: false);
							assemblerComponent2.produced[index] = 0;
							if (num5 > 0)
							{
								UIItemup.Up(products2[index], num5);
							}
						}
					}
				});
				AssemblerProductIcon.Add(image);
			}
		}
		for (int num3 = 0; num3 < AssemblerProductProgress.Count; num3++)
		{
			Image image2 = AssemblerProductProgress[num3];
			Image image3 = AssemblerExtraProductProgress[num3];
			Image image4 = AssemblerProductIcon[num3];
			Text text = AssemblerProductCountText[num3];
			if (num3 >= num - 2)
			{
				image2.gameObject.SetActive(value: false);
				image3.gameObject.SetActive(value: false);
				image4.gameObject.SetActive(value: false);
				text.gameObject.SetActive(value: false);
				continue;
			}
			int num4 = num3 + 2;
			image4.sprite = LDB.items.Select(products[num4])?.iconSprite;
			UIButton component = image4.gameObject.GetComponent<UIButton>();
			component.tips.itemId = products[num4];
			component.tips.itemInc = 0;
			component.tips.itemCount = 0;
			component.tips.type = UIButton.ItemTipType.Item;
			component.tips.corner = 2;
			component.tips.delay = 0.2f;
			component.button.interactable = assemblerComponent.produced[num4] > 0;
			text.text = assemblerComponent.produced[num4].ToString();
			image2.fillAmount = __instance.productProgress1.fillAmount;
			image3.fillAmount = __instance.extraProductProgress1.fillAmount;
			Vector2 anchoredPosition = __instance.productProgress1.gameObject.GetComponent<RectTransform>().anchoredPosition;
			image2.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(anchoredPosition.x + (float)(64 * (num4 - 1)), anchoredPosition.y);
			anchoredPosition = __instance.extraProductProgress1.gameObject.GetComponent<RectTransform>().anchoredPosition;
			image3.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(anchoredPosition.x + (float)(64 * (num4 - 1)), anchoredPosition.y);
			anchoredPosition = __instance.productIcon1.gameObject.GetComponent<RectTransform>().anchoredPosition;
			image4.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(anchoredPosition.x + (float)(64 * (num4 - 1)), anchoredPosition.y);
			anchoredPosition = __instance.productCountText1.gameObject.GetComponent<RectTransform>().anchoredPosition;
			text.gameObject.GetComponent<RectTransform>().anchoredPosition = new Vector2(anchoredPosition.x + (float)(64 * (num4 - 1)), anchoredPosition.y);
			image2.gameObject.SetActive(value: true);
			image3.gameObject.SetActive(value: true);
			image4.gameObject.SetActive(value: true);
			text.gameObject.SetActive(value: true);
		}
		__instance.productGroup.sizeDelta = new Vector2(64 * num, 64f);
		__instance.speedGroup.anchoredPosition = new Vector2(64 * num + 16, __instance.speedGroup.anchoredPosition.y);
		__instance.servingGroup.anchoredPosition = new Vector2(64 * num + 96, __instance.servingGroup.anchoredPosition.y);
	}
}
