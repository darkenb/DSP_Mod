using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using ProjectGenesis.Compatibility;
using ProjectGenesis.Utils;

namespace ProjectGenesis.Patches;

internal static class MegaAssemblerPatches
{
	private static readonly FieldInfo PrefabDesc_assemblerRecipeType_Field = AccessTools.Field(typeof(PrefabDesc), "assemblerRecipeType");

	private static readonly MethodInfo MegaAssemblerPatches_ContainsRecipeTypeRevert_Method = AccessTools.Method(typeof(MegaAssemblerPatches), "ContainsRecipeTypeRevert");

	internal const int MegaAssemblerSpeed = 300000;

	private static readonly FieldInfo EntityData_StationId_Field = AccessTools.Field(typeof(EntityData), "stationId");

	private static readonly FieldInfo EntityData_AssemblerId_Field = AccessTools.Field(typeof(EntityData), "assemblerId");

	private static readonly FieldInfo PlanetFactory_EntityPool_Field = AccessTools.Field(typeof(PlanetFactory), "entityPool");

	private static readonly ConcurrentDictionary<(int, int), SlotData[]> Slotdata = new ConcurrentDictionary<(int, int), SlotData[]>();

	private static readonly FieldInfo UIBeltBuildTip_FilterItems_Field = AccessTools.Field(typeof(UIBeltBuildTip), "filterItems");

	private static readonly FieldInfo UISlotPicker_FilterItems_Field = AccessTools.Field(typeof(UISlotPicker), "filterItems");

	private static readonly FieldInfo UIBeltBuildTip_SelectedIndex_Field = AccessTools.Field(typeof(UIBeltBuildTip), "selectedIndex");

	private static readonly FieldInfo UISlotPicker_SelectedIndex_Field = AccessTools.Field(typeof(UISlotPicker), "selectedIndex");

	private static readonly FieldInfo UIBeltBuildTip_OutputEntityId_Field = AccessTools.Field(typeof(UIBeltBuildTip), "outputEntityId");

	private static readonly FieldInfo UISlotPicker_OutputEntityId_Field = AccessTools.Field(typeof(UISlotPicker), "outputEntityId");

	private static readonly FieldInfo UIBeltBuildTip_OutputSlotId_Field = AccessTools.Field(typeof(UIBeltBuildTip), "outputSlotId");

	private static readonly FieldInfo UISlotPicker_OutputSlotId_Field = AccessTools.Field(typeof(UISlotPicker), "outputSlotId");

	private static readonly MethodInfo MegaAssembler_SetOutputEntity_Patch_Method = AccessTools.Method(typeof(MegaAssemblerPatches), "SetOutputEntity_Patch");

	private static readonly MethodInfo MegaAssembler_SetFilterToEntity_Patch_Method = AccessTools.Method(typeof(MegaAssemblerPatches), "SetFilterToEntity_Patch");

	private static (int, int) LastSetId;

	private static int LastSlotId;

	private static int LastSelectedIndex;

	private static readonly FieldInfo IsStationField = AccessTools.Field(typeof(PrefabDesc), "isStation");

	private static readonly FieldInfo IsAssemblerField = AccessTools.Field(typeof(PrefabDesc), "isAssembler");

	[HarmonyPatch(typeof(BuildingParameters), "ApplyPrebuildParametersToEntity")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> BuildingParameters_ApplyPrebuildParametersToEntity_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, PrefabDesc_assemblerRecipeType_Field));
		codeMatcher.Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Call, MegaAssemblerPatches_ContainsRecipeTypeRevert_Method));
		codeMatcher.SetOpcodeAndAdvance(OpCodes.Brfalse);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(AssemblerComponent), "forceAccMode")));
		codeMatcher.Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldarg_3), new CodeInstruction(OpCodes.Ldarg, 5), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(MegaAssemblerPatches), "BuildingParameters_ApplyPrebuildParametersToEntity_Patch_Method")));
		return codeMatcher.InstructionEnumeration();
	}

	public static void BuildingParameters_ApplyPrebuildParametersToEntity_Patch_Method(int entityId, int[] parameters, PlanetFactory factory)
	{
		if (parameters != null && parameters.Length >= 2048)
		{
			SlotData[] slots = GetSlots(factory.planetId, entityId);
			for (int i = 0; i < slots.Length; i++)
			{
				slots[i].dir = (IODir)parameters[192 + i * 4];
				slots[i].storageIdx = parameters[192 + i * 4 + 1];
			}
			SyncSlotsData.Sync(factory.planetId, entityId, slots);
		}
	}

	[HarmonyPatch(typeof(BuildingParameters), "FromParamsArray")]
	[HarmonyPostfix]
	public static void BuildingParameters_FromParamsArray(ref BuildingParameters __instance, int[] _parameters)
	{
		if (__instance.type == BuildingType.Assembler && _parameters != null && _parameters.Length >= 2048)
		{
			if (__instance.parameters.Length < 2048)
			{
				Array.Resize(ref __instance.parameters, 2048);
			}
			Array.Copy(_parameters, __instance.parameters, 2048);
		}
	}

	[HarmonyPatch(typeof(BuildingParameters), "ToParamsArray")]
	[HarmonyPostfix]
	public static void BuildingParameters_ToParamsArray(ref BuildingParameters __instance, ref int[] _parameters, ref int _paramCount)
	{
		if (__instance.type != BuildingType.Assembler)
		{
			return;
		}
		if (__instance.parameters.Length >= 2048)
		{
			if (_parameters == null || _parameters.Length < 2048)
			{
				Array.Resize(ref _parameters, 2048);
			}
			Array.Copy(__instance.parameters, _parameters, 2048);
			_paramCount = _parameters.Length;
		}
		else
		{
			_paramCount = __instance.parameters.Length;
			if (_parameters == null || _parameters.Length < _paramCount)
			{
				Array.Resize(ref _parameters, _paramCount);
			}
		}
	}

	[HarmonyPatch(typeof(BuildingParameters), "CopyFromFactoryObject")]
	[HarmonyPatch(typeof(BuildingParameters), "CopyFromBuildPreview")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> BuildingParameters_CopyFromFactoryObject_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, PrefabDesc_assemblerRecipeType_Field));
		codeMatcher.Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Call, MegaAssemblerPatches_ContainsRecipeTypeRevert_Method));
		codeMatcher.SetOpcodeAndAdvance(OpCodes.Brtrue);
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(BuildingParameters), "CopyFromFactoryObject")]
	[HarmonyPostfix]
	public static void BuildingParameters_CopyFromFactoryObject(ref BuildingParameters __instance, int objectId, PlanetFactory factory, bool copyInserters)
	{
		if (__instance.type != BuildingType.Assembler || objectId <= 0 || factory.entityPool.Length <= objectId || factory.entityPool[objectId].id != objectId)
		{
			return;
		}
		int assemblerId = factory.entityPool[objectId].assemblerId;
		if (assemblerId <= 0 || factory.factorySystem.assemblerPool.Length <= assemblerId)
		{
			return;
		}
		AssemblerComponent assemblerComponent = factory.factorySystem.assemblerPool[assemblerId];
		if (assemblerComponent.id == assemblerId && assemblerComponent.speed >= 300000)
		{
			if (__instance.parameters == null || __instance.parameters.Length < 2048)
			{
				Array.Resize(ref __instance.parameters, 2048);
			}
			__instance.parameters[0] = (assemblerComponent.forceAccMode ? 1 : 0);
			__instance.recipeId = assemblerComponent.recipeId;
			__instance.recipeType = assemblerComponent.recipeType;
			SlotData[] slots = GetSlots(factory.planetId, objectId);
			for (int i = 0; i < slots.Length; i++)
			{
				__instance.parameters[192 + i * 4] = (int)slots[i].dir;
				__instance.parameters[192 + i * 4 + 1] = slots[i].storageIdx;
			}
			SyncSlotsData.Sync(factory.planetId, objectId, slots);
		}
	}

	[HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> BuildingParameters_PasteToFactoryObject_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, PrefabDesc_assemblerRecipeType_Field));
		codeMatcher.Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Call, MegaAssemblerPatches_ContainsRecipeTypeRevert_Method));
		codeMatcher.SetOpcodeAndAdvance(OpCodes.Brfalse);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, PrefabDesc_assemblerRecipeType_Field));
		codeMatcher.Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Call, MegaAssemblerPatches_ContainsRecipeTypeRevert_Method));
		codeMatcher.SetOpcodeAndAdvance(OpCodes.Brfalse);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, PrefabDesc_assemblerRecipeType_Field));
		codeMatcher.Advance(3).InsertAndAdvance(new CodeInstruction(OpCodes.Call, MegaAssemblerPatches_ContainsRecipeTypeRevert_Method));
		codeMatcher.SetOpcodeAndAdvance(OpCodes.Brfalse);
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(BuildingParameters), "CanPasteToFactoryObject")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> BuildingParameters_CanPasteToFactoryObject_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, PrefabDesc_assemblerRecipeType_Field));
		codeMatcher.Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Call, MegaAssemblerPatches_ContainsRecipeTypeRevert_Method));
		codeMatcher.SetOpcodeAndAdvance(OpCodes.Brfalse);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, PrefabDesc_assemblerRecipeType_Field));
		codeMatcher.Advance(3).InsertAndAdvance(new CodeInstruction(OpCodes.Call, MegaAssemblerPatches_ContainsRecipeTypeRevert_Method));
		codeMatcher.SetOpcodeAndAdvance(OpCodes.Brfalse);
		return codeMatcher.InstructionEnumeration();
	}

	internal static void Export(BinaryWriter w)
	{
		lock (Slotdata)
		{
			w.Write(Slotdata.Count);
			foreach (KeyValuePair<(int, int), SlotData[]> slotdatum in Slotdata)
			{
				w.Write(slotdatum.Key.Item1);
				w.Write(slotdatum.Key.Item2);
				w.Write(slotdatum.Value.Length);
				for (int i = 0; i < slotdatum.Value.Length; i++)
				{
					w.Write((int)slotdatum.Value[i].dir);
					w.Write(slotdatum.Value[i].beltId);
					w.Write(slotdatum.Value[i].storageIdx);
					w.Write(slotdatum.Value[i].counter);
				}
			}
		}
	}

	internal static void Import(BinaryReader r)
	{
		ReInitAll();
		int num = r.ReadInt32();
		for (int i = 0; i < num; i++)
		{
			int item = r.ReadInt32();
			int item2 = r.ReadInt32();
			int num2 = r.ReadInt32();
			SlotData[] array = new SlotData[num2];
			for (int j = 0; j < num2; j++)
			{
				array[j] = new SlotData
				{
					dir = (IODir)r.ReadInt32(),
					beltId = r.ReadInt32(),
					storageIdx = r.ReadInt32(),
					counter = r.ReadInt32()
				};
			}
			Slotdata.TryAdd((item, item2), array);
		}
	}

	internal static void IntoOtherSave()
	{
		ReInitAll();
	}

	private static void ReInitAll()
	{
		Slotdata.Clear();
	}

	internal static bool ContainsRecipeTypeRevert(ERecipeType recipetype, ERecipeType filter)
	{
		return ContainsRecipeType(filter, recipetype);
	}

	internal static bool ContainsRecipeType(ERecipeType filter, ERecipeType recipetype)
	{
		switch ((global::ProjectGenesis.Utils.ERecipeType)filter)
		{
		case global::ProjectGenesis.Utils.ERecipeType.所有化工:
			if (recipetype != ERecipeType.Chemical && recipetype != ERecipeType.Refine)
			{
				return recipetype == (ERecipeType)16;
			}
			return true;
		case global::ProjectGenesis.Utils.ERecipeType.所有熔炉:
			if (recipetype != ERecipeType.Smelt && recipetype != (ERecipeType)11)
			{
				return recipetype == (ERecipeType)13;
			}
			return true;
		case global::ProjectGenesis.Utils.ERecipeType.复合制造:
			if (recipetype != ERecipeType.Assemble)
			{
				return recipetype == (ERecipeType)9;
			}
			return true;
		case global::ProjectGenesis.Utils.ERecipeType.所有制造:
			if (recipetype != ERecipeType.Chemical && recipetype != ERecipeType.Refine && recipetype != ERecipeType.Assemble && recipetype != ERecipeType.Particle && recipetype != (ERecipeType)9 && recipetype != (ERecipeType)10 && recipetype != ERecipeType.Research)
			{
				return recipetype == (ERecipeType)16;
			}
			return true;
		default:
			return filter == recipetype;
		}
	}

	public static void GameTick_AssemblerComponent_InternalUpdate_Patch(PlanetFactory factory, ref AssemblerComponent component, float power)
	{
		if (component.speed < 300000)
		{
			return;
		}
		SlotData[] slots = GetSlots(factory.planetId, component.entityId);
		CargoTraffic cargoTraffic = factory.cargoTraffic;
		SignData[] entitySignPool = factory.entitySignPool;
		if (component.recipeId == 429)
		{
			if (!(power < 0.1f))
			{
				UpdateTrashInputSlots(ref component, power, factory, cargoTraffic, slots);
				int num = component.produced[0];
				if (num >= 800 && GameMain.mainPlayer != null)
				{
					GameMain.mainPlayer.sandCount += num;
					component.produced[0] = 0;
				}
			}
		}
		else
		{
			UpdateOutputSlots(ref component, cargoTraffic, slots, entitySignPool, GameMain.history.stationPilerLevel);
			UpdateInputSlots(ref component, cargoTraffic, slots, entitySignPool);
		}
	}

	private static void UpdateOutputSlots(ref AssemblerComponent __instance, CargoTraffic traffic, SlotData[] slotdata, SignData[] signPool, int maxPilerCount)
	{
		for (int i = 0; i < slotdata.Length; i++)
		{
			ref SlotData reference = ref slotdata[i];
			if (reference.dir == IODir.Output)
			{
				int beltId = reference.beltId;
				if (beltId <= 0)
				{
					continue;
				}
				BeltComponent beltComponent = traffic.beltPool[beltId];
				CargoPath cargoPath = traffic.GetCargoPath(beltComponent.segPathId);
				if (cargoPath == null)
				{
					continue;
				}
				int num = reference.storageIdx - 1;
				int num2 = 0;
				if (num >= 0)
				{
					RecipeExecuteData recipeExecuteData = __instance.recipeExecuteData;
					if (num < recipeExecuteData.products.Length)
					{
						num2 = recipeExecuteData.products[num];
						int num3 = __instance.produced[num];
						if (num2 > 0 && num3 > 0)
						{
							int num4 = ((num3 < maxPilerCount) ? num3 : maxPilerCount);
							if (cargoPath.TryInsertItemAtHeadAndFillBlank(num2, (byte)num4, 0))
							{
								__instance.produced[num] -= num4;
							}
						}
					}
					else
					{
						int num5 = num - recipeExecuteData.products.Length;
						if (num5 < recipeExecuteData.requires.Length)
						{
							num2 = recipeExecuteData.requires[num5];
							int num6 = __instance.served[num5];
							if (num2 > 0 && num6 > 0)
							{
								int num7 = ((num6 < maxPilerCount) ? num6 : maxPilerCount);
								int num8 = (int)((double)__instance.incServed[num5] * (double)num7 / (double)__instance.served[num5]);
								if (cargoPath.TryInsertItemAtHeadAndFillBlank(num2, (byte)num7, (byte)num8))
								{
									__instance.incServed[num5] -= num8;
									__instance.served[num5] -= num7;
								}
							}
						}
					}
				}
				if (num2 > 0)
				{
					int entityId = beltComponent.entityId;
					signPool[entityId].iconType = 1u;
					signPool[entityId].iconId0 = (uint)num2;
				}
			}
			else if (reference.dir != IODir.Input)
			{
				reference.beltId = 0;
				reference.counter = 0;
			}
		}
	}

	private static void UpdateTrashInputSlots(ref AssemblerComponent __instance, float power, PlanetFactory factory, CargoTraffic traffic, SlotData[] slotdata)
	{
		for (int i = 0; i < slotdata.Length; i++)
		{
			if (slotdata[i].dir == IODir.Input)
			{
				int beltId = slotdata[i].beltId;
				if (beltId <= 0)
				{
					continue;
				}
				BeltComponent beltComponent = traffic.beltPool[beltId];
				if (traffic.GetCargoPath(beltComponent.segPathId) == null)
				{
					continue;
				}
				byte stack;
				byte inc;
				int num = traffic.TryPickItemAtRear(beltId, 0, null, out stack, out inc);
				if (num <= 0)
				{
					continue;
				}
				ref int reference = ref __instance.produced[0];
				if (num == 1099)
				{
					reference += stack;
					continue;
				}
				FactoryProductionStat obj = GameMain.statistics.production.factoryStatPool[factory.index];
				int[] productRegister = obj.productRegister;
				int[] consumeRegister = obj.consumeRegister;
				lock (consumeRegister)
				{
					consumeRegister[num] += stack;
				}
				ItemProto itemProto = LDB.items.Select(num);
				if (MoreMegaStructure.Installed && MoreMegaStructure.FastAssembleItems.TryGetValue(num, out var value))
				{
					RecipeProto recipeProto = LDB.recipes.Select(value);
					int count;
					if (recipeProto.Results.Length == 1)
					{
						count = stack * 3 * recipeProto.ItemCounts[0] / recipeProto.ResultCounts[0] / 4;
					}
					else
					{
						int num2 = Array.IndexOf(recipeProto.Results, num);
						count = stack * 3 * recipeProto.ItemCounts[num2] / recipeProto.ResultCounts[num2] / recipeProto.Results.Length / 4;
					}
					TryAddItemToPackage(9500, ref count, productRegister);
					if (count <= 0)
					{
						continue;
					}
					count *= 400;
					reference += count;
					productRegister[1099] += count;
				}
				else if (itemProto.CanBuild)
				{
					RecipeProto recipeProto2 = itemProto.recipes.FirstOrDefault();
					if (recipeProto2 != null)
					{
						for (int j = 0; j < recipeProto2.Items.Length; j++)
						{
							int itemId = recipeProto2.Items[j];
							int count2 = recipeProto2.ItemCounts[j] * stack * 3 / 4;
							TryAddItemToPackage(itemId, ref count2, productRegister);
							if (count2 > 0)
							{
								count2 *= 40;
								reference += count2;
								productRegister[1099] += count2;
							}
						}
						continue;
					}
				}
				int num3 = (int)((float)(stack * 40) * power);
				reference += num3;
				productRegister[1099] += num3;
			}
			else if (slotdata[i].dir != IODir.Output)
			{
				slotdata[i].beltId = 0;
				slotdata[i].counter = 0;
			}
		}
	}

	private static void TryAddItemToPackage(int itemId, ref int count, int[] productRegister)
	{
		Player mainPlayer = GameMain.data.mainPlayer;
		if (itemId > 0 && count > 0)
		{
			int remainInc;
			int num = mainPlayer.package.AddItemStacked(itemId, count, 0, out remainInc);
			int num2 = count - num;
			if (num2 > 0 && mainPlayer.deliveryPackage.unlocked)
			{
				int num3 = mainPlayer.deliveryPackage.AddItem(itemId, num2, 0, out remainInc);
				num2 -= num3;
			}
			productRegister[itemId] += count - num2;
			count = num2;
		}
	}

	private static void UpdateInputSlots(ref AssemblerComponent __instance, CargoTraffic traffic, SlotData[] slotdata, SignData[] signPool)
	{
		for (int i = 0; i < slotdata.Length; i++)
		{
			if (slotdata[i].dir == IODir.Input)
			{
				int beltId = slotdata[i].beltId;
				if (beltId <= 0)
				{
					continue;
				}
				BeltComponent beltComponent = traffic.beltPool[beltId];
				CargoPath cargoPath = traffic.GetCargoPath(beltComponent.segPathId);
				if (cargoPath == null)
				{
					continue;
				}
				int needIdx;
				byte stack;
				byte inc;
				int num = cargoPath.TryPickItemAtRear(__instance.needs, out needIdx, out stack, out inc);
				RecipeExecuteData recipeExecuteData = __instance.recipeExecuteData;
				if (needIdx >= 0 && num > 0 && __instance.needs[needIdx] == num)
				{
					__instance.served[needIdx] += stack;
					__instance.incServed[needIdx] += inc;
					slotdata[i].storageIdx = recipeExecuteData.products.Length + needIdx + 1;
				}
				for (int j = 0; j < recipeExecuteData.products.Length; j++)
				{
					if (__instance.produced[j] < 50)
					{
						num = traffic.TryPickItemAtRear(beltId, recipeExecuteData.products[j], null, out stack, out var _);
						if (recipeExecuteData.products[j] == num)
						{
							__instance.produced[j] += stack;
							slotdata[i].storageIdx = j + 1;
							break;
						}
					}
				}
				if (num > 0)
				{
					int entityId = beltComponent.entityId;
					signPool[entityId].iconType = 1u;
					signPool[entityId].iconId0 = (uint)num;
				}
			}
			else if (slotdata[i].dir != IODir.Output)
			{
				slotdata[i].beltId = 0;
				slotdata[i].counter = 0;
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetFactory), "ApplyInsertTarget")]
	public static void PlanetFactory_ApplyInsertTarget(ref PlanetFactory __instance, int entityId, int insertTarget, int slotId, int offset)
	{
		if (entityId == 0)
		{
			return;
		}
		int assemblerId = __instance.entityPool[entityId].assemblerId;
		if (assemblerId <= 0)
		{
			return;
		}
		AssemblerComponent assemblerComponent = __instance.factorySystem.assemblerPool[assemblerId];
		if (assemblerComponent.id == assemblerId && assemblerComponent.speed >= 300000)
		{
			int beltId = __instance.entityPool[insertTarget].beltId;
			if (beltId > 0)
			{
				SlotData[] slots = GetSlots(__instance.planetId, entityId);
				slots[slotId].dir = IODir.Output;
				slots[slotId].beltId = beltId;
				slots[slotId].counter = 0;
				SyncSlotData.Sync(__instance.planetId, slotId, entityId, slots[slotId]);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetFactory), "ApplyPickTarget")]
	public static void PlanetFactory_ApplyPickTarget(ref PlanetFactory __instance, int entityId, int pickTarget, int slotId, int offset)
	{
		if (entityId == 0)
		{
			return;
		}
		int assemblerId = __instance.entityPool[entityId].assemblerId;
		if (assemblerId <= 0)
		{
			return;
		}
		AssemblerComponent assemblerComponent = __instance.factorySystem.assemblerPool[assemblerId];
		if (assemblerComponent.id == assemblerId && assemblerComponent.speed >= 300000)
		{
			int beltId = __instance.entityPool[pickTarget].beltId;
			if (beltId > 0)
			{
				SlotData[] slots = GetSlots(__instance.planetId, entityId);
				slots[slotId].dir = IODir.Input;
				slots[slotId].beltId = beltId;
				slots[slotId].storageIdx = 0;
				slots[slotId].counter = 0;
				SyncSlotData.Sync(__instance.planetId, slotId, entityId, slots[slotId]);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetFactory), "ApplyEntityDisconnection")]
	public static void PlanetFactory_ApplyEntityDisconnection(ref PlanetFactory __instance, int otherEntityId, int removingEntityId, int otherSlotId, int removingSlotId)
	{
		if (otherEntityId == 0)
		{
			return;
		}
		int assemblerId = __instance.entityPool[otherEntityId].assemblerId;
		if (assemblerId > 0)
		{
			AssemblerComponent assemblerComponent = __instance.factorySystem.assemblerPool[assemblerId];
			if (assemblerComponent.id == assemblerId && assemblerComponent.speed >= 300000 && __instance.entityPool[removingEntityId].beltId > 0)
			{
				SlotData[] slots = GetSlots(__instance.planetId, otherEntityId);
				slots[otherSlotId].dir = IODir.None;
				slots[otherSlotId].beltId = 0;
				slots[otherSlotId].counter = 0;
				SyncSlotData.Sync(__instance.planetId, otherSlotId, otherEntityId, slots[otherSlotId]);
			}
		}
	}

	[HarmonyPatch(typeof(PlanetFactory), "RemoveEntityWithComponents")]
	[HarmonyPrefix]
	[HarmonyPriority(700)]
	public static void PlanetFactory_RemoveEntityWithComponents(ref PlanetFactory __instance, int id)
	{
		if (id != 0)
		{
			EntityData entityData = __instance.entityPool[id];
			if (entityData.id != 0 && entityData.assemblerId != 0)
			{
				SetEmpty(__instance.planetId, id);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(FactorySystem), "NewAssemblerComponent")]
	public static void FactorySystem_NewAssemblerComponent(ref FactorySystem __instance, int entityId, int speed)
	{
		if (speed >= 300000)
		{
			__instance.factory.entityPool[entityId].stationId = 0;
		}
	}

	[HarmonyPatch(typeof(PlanetFactory), "Import")]
	[HarmonyPostfix]
	public static void PlanetFactory_Import(ref PlanetFactory __instance)
	{
		foreach (KeyValuePair<(int, int), SlotData[]> slotdatum in Slotdata)
		{
			KvpDeconstruct.Deconstruct(slotdatum, out var key, out var value);
			(int, int) tuple = key;
			int item = tuple.Item1;
			int item2 = tuple.Item2;
			SlotData[] array = value;
			if (item != __instance.planetId)
			{
				continue;
			}
			for (int i = 0; i < array.Length; i++)
			{
				__instance.ReadObjectConn(item2, i, out var _, out var otherObjId, out var _);
				if (otherObjId <= 0 || __instance.entityPool[otherObjId].beltId != array[i].beltId)
				{
					BeltComponent beltComponent = __instance.cargoTraffic.beltPool[array[i].beltId];
					ref SignData reference = ref __instance.entitySignPool[beltComponent.entityId];
					reference.iconType = 0u;
					reference.iconId0 = 0u;
					array[i] = default(SlotData);
				}
			}
		}
	}

	internal static void SyncSlots((int, int) id, SlotData[] slotDatas)
	{
		Slotdata[id] = slotDatas;
	}

	internal static void SyncSlot((int, int) id, int slotId, SlotData slotData)
	{
		lock (Slotdata)
		{
			if (Slotdata.TryGetValue(id, out var value))
			{
				value[slotId] = slotData;
				return;
			}
			value = new SlotData[12];
			value[slotId] = slotData;
			Slotdata[id] = value;
		}
	}

	private static SlotData[] GetSlots(int planetId, int entityId)
	{
		(int, int) key = (planetId, entityId);
		if (!Slotdata.ContainsKey(key) || Slotdata[key] == null)
		{
			Slotdata[key] = new SlotData[12];
		}
		return Slotdata[key];
	}

	private static void SetEmpty(int planetId, int entityId)
	{
		(int, int) key = (planetId, entityId);
		if (Slotdata.ContainsKey(key))
		{
			Slotdata[key] = new SlotData[12];
			SyncSlotsData.Sync(planetId, entityId, Slotdata[key]);
		}
	}

	public static void ExportPlanetData(int planetId, BinaryWriter w)
	{
		KeyValuePair<(int, int), SlotData[]>[] array = Slotdata.Where((KeyValuePair<(int, int), SlotData[]> pair) => pair.Key.Item1 == planetId).ToArray();
		w.Write(array.Length);
		w.Write(planetId);
		KeyValuePair<(int, int), SlotData[]>[] array2 = array;
		for (int num = 0; num < array2.Length; num++)
		{
			KeyValuePair<(int, int), SlotData[]> keyValuePair = array2[num];
			w.Write(keyValuePair.Key.Item2);
			w.Write(keyValuePair.Value.Length);
			for (int num2 = 0; num2 < keyValuePair.Value.Length; num2++)
			{
				w.Write((int)keyValuePair.Value[num2].dir);
				w.Write(keyValuePair.Value[num2].beltId);
				w.Write(keyValuePair.Value[num2].storageIdx);
				w.Write(keyValuePair.Value[num2].counter);
			}
		}
	}

	public static void ImportPlanetData(BinaryReader r)
	{
		int num = r.ReadInt32();
		int num2 = r.ReadInt32();
		PlanetFactory planetFactory = GameMain.galaxy.PlanetById(num2)?.factory;
		for (int i = 0; i < num; i++)
		{
			int num3 = r.ReadInt32();
			int num4 = r.ReadInt32();
			SlotData[] array = new SlotData[num4];
			for (int j = 0; j < num4; j++)
			{
				array[j] = new SlotData
				{
					dir = (IODir)r.ReadInt32(),
					beltId = r.ReadInt32(),
					storageIdx = r.ReadInt32(),
					counter = r.ReadInt32()
				};
				if (planetFactory != null)
				{
					planetFactory.ReadObjectConn(num3, j, out var _, out var otherObjId, out var _);
					if (otherObjId <= 0 || planetFactory.entityPool[otherObjId].beltId != array[j].beltId)
					{
						BeltComponent beltComponent = planetFactory.cargoTraffic.beltPool[array[j].beltId];
						ref SignData reference = ref planetFactory.entitySignPool[beltComponent.entityId];
						reference.iconType = 0u;
						reference.iconId0 = 0u;
						array[j] = default(SlotData);
					}
				}
			}
			Slotdata[(num2, num3)] = array;
		}
	}

	[HarmonyPatch(typeof(UIBeltBuildTip), "SetOutputEntity")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> UIBeltBuildTip_SetOutputEntity_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldloc_0), new CodeMatch(OpCodes.Ldfld, PlanetFactory_EntityPool_Field), new CodeMatch(OpCodes.Ldarg_1), new CodeMatch(OpCodes.Ldelem), new CodeMatch(OpCodes.Stloc_3));
		codeMatcher.Advance(1).CreateLabel(out var label);
		codeMatcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_3), new CodeInstruction(OpCodes.Ldfld, EntityData_AssemblerId_Field), new CodeInstruction(OpCodes.Ldc_I4_0), new CodeInstruction(OpCodes.Ble, label), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldloc_0), new CodeInstruction(OpCodes.Ldloc_3), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldflda, UIBeltBuildTip_FilterItems_Field), new CodeInstruction(OpCodes.Ldarg_1), new CodeInstruction(OpCodes.Ldarg_2), new CodeInstruction(OpCodes.Call, MegaAssembler_SetOutputEntity_Patch_Method), new CodeInstruction(OpCodes.Stfld, UIBeltBuildTip_SelectedIndex_Field));
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(UISlotPicker), "SetOutputEntity")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> UISlotPicker_SetOutputEntity_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldloc_0), new CodeMatch(OpCodes.Ldfld, PlanetFactory_EntityPool_Field), new CodeMatch(OpCodes.Ldarg_1), new CodeMatch(OpCodes.Ldelem), new CodeMatch(OpCodes.Stloc_1));
		codeMatcher.Advance(1).CreateLabel(out var label);
		codeMatcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_1), new CodeInstruction(OpCodes.Ldfld, EntityData_AssemblerId_Field), new CodeInstruction(OpCodes.Ldc_I4_0), new CodeInstruction(OpCodes.Ble, label), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldloc_0), new CodeInstruction(OpCodes.Ldloc_1), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldflda, UISlotPicker_FilterItems_Field), new CodeInstruction(OpCodes.Ldarg_1), new CodeInstruction(OpCodes.Ldarg_2), new CodeInstruction(OpCodes.Call, MegaAssembler_SetOutputEntity_Patch_Method), new CodeInstruction(OpCodes.Stfld, UISlotPicker_SelectedIndex_Field));
		return codeMatcher.InstructionEnumeration();
	}

	public static int SetOutputEntity_Patch(PlanetFactory factory, EntityData entityData, ref List<int> filterItems, int entityId, int slot)
	{
		AssemblerComponent assemblerComponent = factory.factorySystem.assemblerPool[entityData.assemblerId];
		if (assemblerComponent.speed < 300000)
		{
			return -1;
		}
		if (assemblerComponent.recipeId > 0)
		{
			RecipeExecuteData recipeExecuteData = assemblerComponent.recipeExecuteData;
			filterItems.AddRange(recipeExecuteData.products);
			filterItems.AddRange(recipeExecuteData.requires);
		}
		else
		{
			filterItems.AddRange(Enumerable.Repeat(0, 6));
		}
		entityData.stationId = 0;
		if (slot >= 0 && slot < 12)
		{
			return GetSlots(factory.planetId, entityId)[slot].storageIdx;
		}
		Assert.CannotBeReached();
		return -1;
	}

	[HarmonyPatch(typeof(UIBeltBuildTip), "SetFilterToEntity")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> UIBeltBuildTip_SetFilterToEntity_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldloc_0), new CodeMatch(OpCodes.Ldfld, PlanetFactory_EntityPool_Field), new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld, UIBeltBuildTip_OutputEntityId_Field), new CodeMatch(OpCodes.Ldelem), new CodeMatch(OpCodes.Stloc_1));
		codeMatcher.Advance(1).CreateLabel(out var label);
		codeMatcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_1), new CodeInstruction(OpCodes.Ldfld, EntityData_AssemblerId_Field), new CodeInstruction(OpCodes.Ldc_I4_0), new CodeInstruction(OpCodes.Ble, label), new CodeInstruction(OpCodes.Ldloc_0), new CodeInstruction(OpCodes.Ldloc_1), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, UIBeltBuildTip_OutputEntityId_Field), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, UIBeltBuildTip_OutputSlotId_Field), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, UIBeltBuildTip_SelectedIndex_Field), new CodeInstruction(OpCodes.Call, MegaAssembler_SetFilterToEntity_Patch_Method));
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(UISlotPicker), "SetFilterToEntity")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> UISlotPicker_SetFilterToEntity_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldloc_0), new CodeMatch(OpCodes.Ldfld, PlanetFactory_EntityPool_Field), new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld, UISlotPicker_OutputEntityId_Field), new CodeMatch(OpCodes.Ldelem), new CodeMatch(OpCodes.Stloc_1));
		codeMatcher.Advance(1).CreateLabel(out var label);
		codeMatcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_1), new CodeInstruction(OpCodes.Ldfld, EntityData_AssemblerId_Field), new CodeInstruction(OpCodes.Ldc_I4_0), new CodeInstruction(OpCodes.Ble, label), new CodeInstruction(OpCodes.Ldloc_0), new CodeInstruction(OpCodes.Ldloc_1), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, UISlotPicker_OutputEntityId_Field), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, UISlotPicker_OutputSlotId_Field), new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldfld, UISlotPicker_SelectedIndex_Field), new CodeInstruction(OpCodes.Call, MegaAssembler_SetFilterToEntity_Patch_Method));
		return codeMatcher.InstructionEnumeration();
	}

	public static void SetFilterToEntity_Patch(PlanetFactory factory, EntityData entityData, int outputEntityId, int outputSlotId, int selectedIndex)
	{
		if (factory.factorySystem.assemblerPool[entityData.assemblerId].speed >= 300000)
		{
			SlotData[] slots = GetSlots(factory.planetId, outputEntityId);
			slots[outputSlotId].storageIdx = selectedIndex;
			entityData.stationId = 0;
			if (!IsChangeCached((factory.planetId, outputEntityId), outputSlotId, selectedIndex))
			{
				SyncSlotData.Sync(factory.planetId, outputSlotId, outputEntityId, slots[outputSlotId]);
				CacheChange((factory.planetId, outputEntityId), outputSlotId, selectedIndex);
			}
		}
	}

	private static bool IsChangeCached((int, int) id, int slotId, int selectedIndex)
	{
		(int, int) lastSetId = LastSetId;
		(int, int) tuple = id;
		if (lastSetId.Item1 == tuple.Item1 && lastSetId.Item2 == tuple.Item2 && LastSlotId == slotId)
		{
			return LastSelectedIndex == selectedIndex;
		}
		return false;
	}

	private static void CacheChange((int, int) id, int slotId, int selectedIndex)
	{
		LastSetId = id;
		LastSlotId = slotId;
		LastSelectedIndex = selectedIndex;
	}

	[HarmonyPatch(typeof(UIRecipePicker), "RefreshIcons")]
	[HarmonyPriority(int.MaxValue)]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> UIRecipePicker_RefreshIcons(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(RecipeProto), "Type")), new CodeMatch(OpCodes.Bne_Un));
		codeMatcher.InsertAndAdvance(new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(MegaAssemblerPatches), "ContainsRecipeType")));
		codeMatcher.SetOpcodeAndAdvance(OpCodes.Brfalse);
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(BuildTool_Path), "CheckBuildConditions")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> BuildTool_Path_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldloc_S), new CodeMatch(OpCodes.Ldfld, IsStationField));
		CodeInstruction instruction = codeMatcher.Instruction;
		codeMatcher.Advance(2).InsertAndAdvance(new CodeInstruction(instruction), new CodeInstruction(OpCodes.Ldfld, IsAssemblerField), new CodeInstruction(OpCodes.Or));
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(BuildTool_Path), "DeterminePreviews")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> BuildTool_Path_DeterminePreviews_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldloc_2), new CodeMatch(OpCodes.Ldfld, IsStationField));
		CodeInstruction instruction = codeMatcher.Instruction;
		codeMatcher.Advance(2).InsertAndAdvance(new CodeInstruction(instruction), new CodeInstruction(OpCodes.Ldfld, IsAssemblerField), new CodeInstruction(OpCodes.Or));
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldloc_S), new CodeMatch(OpCodes.Ldfld, IsStationField));
		instruction = codeMatcher.Instruction;
		codeMatcher.Advance(2).InsertAndAdvance(new CodeInstruction(instruction), new CodeInstruction(OpCodes.Ldfld, IsAssemblerField), new CodeInstruction(OpCodes.Or));
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(UISlotPicker), "Determine")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> UISlotPicker_Determine_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, EntityData_StationId_Field), new CodeMatch(OpCodes.Stloc_S), new CodeMatch(OpCodes.Ldloc_S), new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch(OpCodes.Ble));
		List<CodeInstruction> instructions2 = codeMatcher.InstructionsWithOffsets(-5, -1);
		codeMatcher.Advance(1).InsertAndAdvance(instructions2).InsertAndAdvance(new CodeInstruction(OpCodes.Ldfld, EntityData_AssemblerId_Field))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Or));
		return codeMatcher.InstructionEnumeration();
	}
}
