using System.IO;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Logging;
using HarmonyLib;
using ProjectGenesis.Patches;
using ProjectGenesis.Utils;
using UnityEngine;

namespace ProjectGenesis.Compatibility;

[BepInPlugin("org.LoShin.GenesisBook.InstallationCheck", "GenesisBook.InstallationCheck", "3.2.6")]
[BepInDependency("org.kremnev8.plugin.BlueprintTweaks", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("Gnimaerd.DSP.plugin.MoreMegaStructure", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.galactic-scale.2", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("930f5bae-66d2-4917-988b-162fe2456643", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("testpostpleaseignore.dsp.planet_vein_utilization", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("com.hetima.dsp.FastTravelEnabler", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("org.kremnev8.plugin.GigaStationsUpdated", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("eirshy.dsp.LazyOutposting", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("org.weaponplus.plugins.Xiaokls", BepInDependency.DependencyFlags.SoftDependency)]
public class InstallationCheckPlugin : BaseUnityPlugin
{
	public const string MODGUID = "org.LoShin.GenesisBook.InstallationCheck";

	public const string MODNAME = "GenesisBook.InstallationCheck";

	public const string PreferBepinExVersion = "5.4.17";

	private static bool MessageShown;

	internal static bool PreloaderInstalled;

	internal static bool BepinExVersionMatch;

	internal static ManualLogSource logger;

	public void Awake()
	{
		logger = base.Logger;
		BepInEx.Logging.Logger.Listeners.Add(new HarmonyLogListener());
		BepinExVersionMatch = typeof(Paths).Assembly.GetName().Version.ToString(3) == "5.4.17";
		PreloaderInstalled = AccessTools.DeclaredField(typeof(PlanetData), "birthResourcePoint2") != null;
		new Harmony("org.LoShin.GenesisBook.InstallationCheck").Patch(AccessTools.Method(typeof(VFPreload), "InvokeOnLoadWorkEnded"), null, new HarmonyMethod(typeof(InstallationCheckPlugin), "OnMainMenuOpen")
		{
			priority = 0
		});
		AwakeCompatibilityPatchers();
	}

	public static void AwakeCompatibilityPatchers()
	{
		MoreMegaStructure.Awake();
		PlanetVeinUtilization.Awake();
		BlueprintTweaks.Awake();
		PlanetwideMining.Awake();
		FastTravelEnabler.Awake();
		GigaStationsUpdated.Awake();
		LazyOutposting.Awake();
		WeaponPlus.Awake();
		if (Chainloader.PluginInfos.ContainsKey("dsp.galactic-scale.2"))
		{
			GalacticScale.Awake();
		}
	}

	public static void OnMainMenuOpen()
	{
		if (!MessageShown)
		{
			MessageShown = true;
			string text = null;
			if (ProjectGenesis.ShowMessageBoxEntry.Value)
			{
				text = "GenesisBookLoadMessage";
			}
			if (!ProjectGenesis.LoadCompleted)
			{
				text = "ProjectGenesisNotLoaded";
			}
			if (!BepinExVersionMatch)
			{
				text = "BepinExVersionNotMatch";
			}
			if (!PreloaderInstalled)
			{
				text = "PreloaderNotInstalled";
			}
			if (!string.IsNullOrEmpty(text))
			{
				UIMessageBox.Show("GenesisBookLoadTitle".TranslateFromJson(), text.TranslateFromJson(), "确定".TranslateFromJson(), "跳转交流群".TranslateFromJson(), "跳转日志".TranslateFromJson(), 0, null, OpenBrowser, OpenLog);
			}
		}
	}

	public static void OpenBrowser()
	{
		Application.OpenURL("创世之书链接".TranslateFromJson());
	}

	public static void OpenLog()
	{
		Application.OpenURL(Path.Combine(ProjectGenesis.ModPath, "CHANGELOG.md"));
	}
}
