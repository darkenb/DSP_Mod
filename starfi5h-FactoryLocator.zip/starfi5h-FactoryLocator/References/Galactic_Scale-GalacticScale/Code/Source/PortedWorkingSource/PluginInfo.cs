namespace GalacticScale
{
    public static class PluginInfo
    {
        public const string PLUGIN_GUID = "dsp.galactic-scale.2";
        public const string PLUGIN_NAME = "GalacticScale";
        public const string PLUGIN_VERSION = "2.80.9";
    }
}
