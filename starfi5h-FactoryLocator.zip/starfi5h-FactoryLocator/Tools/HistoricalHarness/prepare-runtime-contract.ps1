param([string]$Output = (Join-Path ([IO.Path]::GetTempPath()) 'dsp-mod-fixes-20261001/runtime-contract'))
$ErrorActionPreference = 'Stop'
$plugins = Split-Path (Split-Path $PSScriptRoot -Parent) -Parent
$bep = Split-Path $plugins -Parent
$core = Join-Path $bep 'core'
$game = 'D:/Games/Dyson Sphere Program/DSPGAME_Data/Managed'
Add-Type -Path (Join-Path $core 'Mono.Cecil.dll')
Add-Type -Path (Join-Path $core 'Mono.Cecil.Rocks.dll')
Add-Type -TypeDefinition @'
using System;
using System.Reflection;
public static class RuntimeContractResolver {
    public static void Attach(Assembly cecil, string[] directories) {
        AppDomain.CurrentDomain.AssemblyResolve += (sender, args) => {
            var name = new AssemblyName(args.Name).Name;
            if (name == "Mono.Cecil") return cecil;
            foreach (var dir in directories) {
                var path = System.IO.Path.Combine(dir, name + ".dll");
                if (System.IO.File.Exists(path)) return Assembly.LoadFrom(path);
            }
            return null;
        };
    }
}
'@
$patcherFiles = @(Get-ChildItem -LiteralPath (Join-Path $bep 'patchers') -Recurse -Filter '*.dll' -File)
$directories = @($core, $game) + @($patcherFiles | ForEach-Object { $_.DirectoryName } | Select-Object -Unique)
[RuntimeContractResolver]::Attach([Mono.Cecil.AssemblyDefinition].Assembly, $directories)
$original = Join-Path $game 'Assembly-CSharp.dll'
$hash = (Get-FileHash -LiteralPath $original).Hash
$resolver = New-Object Mono.Cecil.DefaultAssemblyResolver
foreach ($dir in $directories) { $resolver.AddSearchDirectory($dir) }
$reader = New-Object Mono.Cecil.ReaderParameters
$reader.AssemblyResolver = $resolver
$assembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($original, $reader)
$changes = @()
try {
    foreach ($file in $patcherFiles) {
        $patcher = [Reflection.Assembly]::LoadFrom($file.FullName)
        foreach ($type in $patcher.GetTypes()) {
            $patch = $type.GetMethod('Patch', [Reflection.BindingFlags]'Public,Static')
            $targets = $type.GetProperty('TargetDLLs', [Reflection.BindingFlags]'Public,Static')
            if (-not $patch -or -not $targets -or 'Assembly-CSharp.dll' -notin $targets.GetValue($null, $null)) { continue }
            $initialize = $type.GetMethod('Initialize', [Reflection.BindingFlags]'Public,Static')
            if ($initialize) { $initialize.Invoke($null, @()) | Out-Null }
            $before = @{}
            foreach ($t in $assembly.MainModule.GetTypes()) { foreach ($f in $t.Fields) { $before[$f.FullName] = $true } }
            $patch.Invoke($null, @($assembly)) | Out-Null
            $after = @($assembly.MainModule.GetTypes() | ForEach-Object { $_.Fields | ForEach-Object FullName })
            $changes += [ordered]@{ file=$file.FullName; type=$type.FullName; sha256=(Get-FileHash -LiteralPath $file.FullName).Hash;
                added_fields=@($after | Where-Object { -not $before.ContainsKey($_) }) }
        }
    }
    [IO.Directory]::CreateDirectory($Output) | Out-Null
    $assembly.Write((Join-Path $Output 'Assembly-CSharp.dll'))
    # Access flags must match the actual game; no bulk publicizing in runtime checks.
    $native = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($original)
    try {
        $flags = [Collections.Generic.Dictionary[string,int]]::new([StringComparer]::Ordinal)
        foreach ($t in $native.MainModule.GetTypes()) {
            $flags['type:' + $t.FullName] = ([int]$t.Attributes -band 7)
            foreach ($f in $t.Fields) { $flags['field:' + $f.FullName] = ([int]$f.Attributes -band 7) }
            foreach ($m in $t.Methods) { $flags['method:' + $m.FullName] = ([int]$m.Attributes -band 7) }
        }
        foreach ($t in $assembly.MainModule.GetTypes()) {
            foreach ($entry in @(@{key='type:'+$t.FullName; value=[int]$t.Attributes}) + @($t.Fields | ForEach-Object { @{key='field:'+$_.FullName;value=[int]$_.Attributes} }) + @($t.Methods | ForEach-Object { @{key='method:'+$_.FullName;value=[int]$_.Attributes} })) {
                if ($flags.ContainsKey($entry.key) -and $flags[$entry.key] -ne ($entry.value -band 7)) { throw ('Preloader changed native access flags: ' + $entry.key) }
            }
        }
    } finally { $native.Dispose() }
} finally { $assembly.Dispose(); $resolver.Dispose() }
if ((Get-FileHash -LiteralPath $original).Hash -ne $hash) { throw 'Game DLL changed' }
[ordered]@{ game_sha256=$hash; reference=(Join-Path $Output 'Assembly-CSharp.dll'); native_access_flags_preserved=$true;
    patchers=$changes; finish_called=$false } | ConvertTo-Json -Depth 8 |
    Set-Content -LiteralPath (Join-Path $PSScriptRoot 'RUNTIME_CONTRACT.json') -Encoding UTF8
Write-Output ('PASS {0} installed preloaders applied once; native access flags preserved' -f $changes.Count)
