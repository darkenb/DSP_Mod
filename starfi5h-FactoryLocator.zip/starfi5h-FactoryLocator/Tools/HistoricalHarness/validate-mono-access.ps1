param([Parameter(Mandatory=$true)][string]$Built, [Parameter(Mandatory=$true)][string]$Core)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $Core 'Mono.Cecil.dll')
$assembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($Built)
try {
    $moduleFlag = @($assembly.MainModule.CustomAttributes | Where-Object { $_.AttributeType.FullName -eq 'System.Security.UnverifiableCodeAttribute' }).Count -gt 0
    $permission = $false
    foreach ($declaration in $assembly.SecurityDeclarations) {
        if ($declaration.Action -ne 'RequestMinimum') { continue }
        foreach ($attribute in $declaration.SecurityAttributes) {
            if ($attribute.AttributeType.FullName -ne 'System.Security.Permissions.SecurityPermissionAttribute') { continue }
            if (@($attribute.Properties | Where-Object { $_.Name -eq 'SkipVerification' -and $_.Argument.Value -eq $true }).Count) { $permission = $true }
        }
    }
    if (-not $moduleFlag -or -not $permission) { throw 'Publicized reference build is missing Mono access metadata; compile with /unsafe+' }
    Write-Output 'PASS Mono publicized-reference module and assembly verification metadata'
} finally { $assembly.Dispose() }
