param([Parameter(Mandatory=$true)][string]$Phase)
$ErrorActionPreference = 'Stop'
$workRoot = Split-Path $PSScriptRoot -Parent
$pluginRoot = Split-Path $workRoot -Parent
$core = Join-Path (Split-Path $pluginRoot -Parent) 'core'
$scan = Get-Content -LiteralPath (Join-Path $workRoot '_compat_audit_20261001/scan.ps1') -Raw
$code = [regex]::Match($scan, "(?s)@'\r?\n(.*?)\r?\n'@").Groups[1].Value
if (-not $code) { throw 'Audit scanner source not found' }
Add-Type -Path (Join-Path $core 'Mono.Cecil.dll')
Add-Type -ReferencedAssemblies (Join-Path $core 'Mono.Cecil.dll') -TypeDefinition $code
$phaseRoot = Join-Path $PSScriptRoot $Phase
$info = Get-Content -LiteralPath (Join-Path $phaseRoot 'phase.json') -Raw | ConvertFrom-Json
$tempRoot = Join-Path ([IO.Path]::GetTempPath()) ('dsp-mod-fixes-20261001/' + $Phase)
$dll = Join-Path $tempRoot ($info.assembly + '.dll')
$dirs = @('D:/Games/Dyson Sphere Program/DSPGAME_Data/Managed', $core, $tempRoot) + @(Get-ChildItem -LiteralPath $pluginRoot -Directory | Where-Object { Test-Path -LiteralPath (Join-Path $_.FullName 'manifest.json') } | ForEach-Object { $_.FullName })
if ($info.audit_reference_subdirectory) {
    $referenceRoot = Join-Path $tempRoot $info.audit_reference_subdirectory
    if (-not (Test-Path -LiteralPath (Join-Path $referenceRoot 'Assembly-CSharp.dll'))) { throw 'Prepared reference missing' }
    $dirs = @($referenceRoot) + $dirs
}
$result = [DspAudit]::Scan($dll, $dirs)
$rawProblemCount = $result.Problems.Count
if ($info.inactive_patch_verification_script) {
    & (Join-Path $phaseRoot $info.inactive_patch_verification_script) -Built $dll -Core $core -PhaseRoot $phaseRoot
    if (-not $?) { throw 'Inactive patch verification failed' }
    $proof = Get-Content -LiteralPath (Join-Path $phaseRoot 'inactive-patches.json') -Raw | ConvertFrom-Json
    $inactive = @()
    foreach ($problem in @($result.Problems)) {
        if ($problem.Kind -notlike 'patch_*') { continue }
        if ($problem.Member -notin $proof.members) { continue }
        if (@($problem.Callers | Where-Object { $_ -ne $proof.caller }).Count) { continue }
        $inactive += $problem
        [void]$result.Problems.Remove($problem)
    }
    if ($inactive.Count -ne $proof.members.Count) { throw 'Inactive finding set changed; review required' }
    $result | Add-Member -NotePropertyName InactiveProblems -NotePropertyValue $inactive
}
$result | Add-Member -NotePropertyName RawProblemCount -NotePropertyValue $rawProblemCount
$result | ConvertTo-Json -Depth 15 | Set-Content -LiteralPath (Join-Path $phaseRoot 'api-audit.json') -Encoding UTF8
Write-Output ('{0}: {1} references, {2} Harmony patches, {3} raw / {4} active API findings' -f $result.Name,$result.GameReferences,$result.Patches.Count,$rawProblemCount,$result.Problems.Count)
if ($result.Problems.Count -gt 0) {
    $result.Problems | ForEach-Object { Write-Output ($_.Kind + ': ' + $_.Member) }
    exit 1
}
