"""Compile a phase against installed game DLLs; keep loose output outside BepInEx."""
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import zipfile
import ctypes
import shutil

ROOT = Path(__file__).resolve().parent
PLUGINS = ROOT.parent.parent
GAME = Path('D:/Games/Dyson Sphere Program/DSPGAME_Data/Managed')
CORE = PLUGINS.parent / 'core'
OUTPUT = Path(tempfile.gettempdir()) / 'dsp-mod-fixes-20261001'
FRAMEWORK = Path('C:/Program Files (x86)/Reference Assemblies/Microsoft/Framework/.NETFramework/v4.7.2')
CSC = Path('C:/Program Files/dotnet/sdk/10.0.401/Roslyn/bincore/csc.dll')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def phase_sources(phase):
    return sorted(p for p in (phase / 'src').rglob('*.cs')
                  if not any(part.lower() in ('obj', 'bin') for part in p.relative_to(phase / 'src').parts[:-1]))

def compile_cs(sources, target, references, executable=False, extra_args=None):
    target.parent.mkdir(parents=True, exist_ok=True)
    # Publicized references require Mono's assembly verification metadata at runtime.
    # /unsafe+ emits it even when the source contains no pointer operations.
    args = ['dotnet', str(CSC), '/nologo', '/nostdlib+', '/langversion:latest', '/unsafe+', '/deterministic+', '/optimize+', '/debug:portable', '/target:' + ('exe' if executable else 'library'), '/out:' + str(target)]
    args += ['/reference:' + str(p) for p in references]
    args += extra_args or []
    args += [str(p) for p in sources]
    response = target.with_suffix('.rsp')
    response.write_text('\n'.join('"' + arg + '"' for arg in args[2:]), encoding='utf-8')
    result = subprocess.run(args[:2] + ['/noconfig', '@' + str(response)], capture_output=True, text=True, encoding='utf-8', errors='replace')
    if result.returncode:
        raise RuntimeError(result.stdout + result.stderr)
    return result.stdout + result.stderr

def references():
    refs = [p for p in FRAMEWORK.glob('*.dll') if p.name not in ('System.EnterpriseServices.Wrapper.dll', 'System.EnterpriseServices.Thunk.dll')]
    refs += list((FRAMEWORK / 'Facades').glob('*.dll'))
    refs += list(GAME.glob('UnityEngine*.dll')) + [GAME / 'Assembly-CSharp.dll', CORE / 'BepInEx.dll', CORE / '0Harmony.dll']
    return refs

def run_check(check, directories):
    """Catch CLR load errors before check entry and suppress Windows crash UI per process."""
    framework_refs = [p for p in FRAMEWORK.glob('*.dll') if p.name not in ('System.EnterpriseServices.Wrapper.dll', 'System.EnterpriseServices.Thunk.dll')]
    host = check.parent / 'TestHost.exe'
    compile_cs([ROOT / 'TestHost.cs'], host, framework_refs, executable=True)
    previous_mode = None
    if sys.platform == 'win32':
        kernel = ctypes.WinDLL('kernel32', use_last_error=True)
        kernel.SetErrorMode.argtypes = [ctypes.c_uint]
        kernel.SetErrorMode.restype = ctypes.c_uint
        previous_mode = kernel.SetErrorMode(0x0001 | 0x0002 | 0x8000)
    try:
        return subprocess.run([str(host), str(check)] + [str(p) for p in directories], capture_output=True,
                              text=True, encoding='utf-8', errors='replace', timeout=60,
                              creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == 'win32' else 0)
    finally:
        if previous_mode is not None:
            kernel.SetErrorMode(previous_mode)

def build(phase):
    phase = ROOT / phase
    info = json.loads((phase / 'phase.json').read_text(encoding='utf-8'))
    original = PLUGINS / info['folder'] / info.get('original_relative_path', info['assembly'] + '.dll')
    for path, key in ((original, 'expected_original_sha256'), (GAME / 'Assembly-CSharp.dll', 'expected_game_sha256')):
        if key in info and digest(path) != info[key]:
            raise RuntimeError('Baseline changed; revalidate findings before building: ' + str(path))
    target_dir = OUTPUT / phase.name
    target = target_dir / (info['assembly'] + '.dll')
    check_references = []
    for other_phase in info.get('check_reference_phases', []):
        other_info = json.loads((ROOT / other_phase / 'phase.json').read_text(encoding='utf-8'))
        other_target = OUTPUT / other_phase / (other_info['assembly'] + '.dll')
        if not other_target.exists():
            build(other_phase)
        check_references.append(other_target)
    phase_refs = references()
    phase_refs += check_references
    phase_refs += [PLUGINS / p for p in info.get('extra_reference_paths', [])]
    phase_refs += [GAME / p for p in info.get('game_reference_names', [])]
    if info.get('compilation_reference_phase'):
        reference_game = OUTPUT / info['compilation_reference_phase'] / 'reference/Assembly-CSharp.dll'
        if not reference_game.exists():
            raise RuntimeError('Prepared compilation reference missing: ' + str(reference_game))
        phase_refs = [p for p in phase_refs if p.name != 'Assembly-CSharp.dll'] + [reference_game]
    extra_args = info.get('compile_arguments', []) + ['/resource:' + str(phase / path) + ',' + name for path, name in info.get('embedded_resources', {}).items()]
    compilation_target = target.with_suffix('.patch-source.dll') if info.get('binary_patch_script') else target
    if info.get('reuse_original_binary'):
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(original, target)
        log = 'Existing ABI library retained byte for byte; no recompilation required.\n'
    else:
        log = compile_cs(phase_sources(phase), compilation_target, phase_refs, extra_args=extra_args)
    if info.get('binary_patch_script'):
        patched = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
                                  str(phase / info['binary_patch_script']), '-Original', str(original),
                                  '-Helper', str(compilation_target), '-Built', str(target), '-Core', str(CORE)],
                                 capture_output=True, text=True, encoding='utf-8', errors='replace')
        log += patched.stdout + patched.stderr
        if patched.returncode:
            raise RuntimeError('Binary patch preparation failed:\n' + log)
    if info.get('compilation_reference_phase'):
        mono_check = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
                                    str(ROOT / 'validate-mono-access.ps1'), '-Built', str(target), '-Core', str(CORE)],
                                   capture_output=True, text=True, encoding='utf-8', errors='replace')
        log += mono_check.stdout + mono_check.stderr
        if mono_check.returncode:
            raise RuntimeError('Mono access metadata validation failed:\n' + log)
    if (phase / 'check.cs').exists():
        test_game = GAME
        if (phase / 'check-prepare.ps1').exists():
            test_game = target_dir / 'headless'
            prepared = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(phase / 'check-prepare.ps1'), '-Game', str(GAME), '-Core', str(CORE), '-Output', str(test_game)], capture_output=True, text=True)
            log += prepared.stdout + prepared.stderr
            if prepared.returncode:
                (phase / 'build.log').write_text(log, encoding='utf-8')
                raise RuntimeError('Test reference preparation failed:\n' + log)
        check = target_dir / 'Check.exe'
        log += compile_cs([phase / 'check.cs'], check, phase_refs + [target] + check_references, executable=True)
        result = run_check(check, [test_game, CORE, GAME] + [p.parent for p in check_references]
                           + [(PLUGINS / p).parent for p in info.get('extra_reference_paths', [])])
        log += result.stdout + result.stderr
        if result.returncode:
            (phase / 'build.log').write_text(log, encoding='utf-8')
            raise RuntimeError('Phase check failed:\n' + log)
    assert (phase / 'Changelog.md').exists(), 'Each phase must finish with Changelog.md'
    audit = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File', str(ROOT / 'audit.ps1'), '-Phase', phase.name], capture_output=True, text=True)
    log += audit.stdout + audit.stderr
    if audit.returncode:
        (phase / 'build.log').write_text(log, encoding='utf-8')
        raise RuntimeError('Phase API audit failed:\n' + log)
    if info.get('validation_script'):
        validation = subprocess.run(['powershell.exe', '-NoProfile', '-ExecutionPolicy', 'Bypass', '-File',
                                     str(phase / info['validation_script']), '-Original', str(original),
                                     '-Built', str(target), '-Core', str(CORE), '-PhaseRoot', str(phase)],
                                    capture_output=True, text=True, encoding='utf-8', errors='replace')
        log += validation.stdout + validation.stderr
        if validation.returncode:
            (phase / 'build.log').write_text(log, encoding='utf-8')
            raise RuntimeError('Phase validation failed:\n' + log)
    manifest = json.loads((PLUGINS / info['folder'] / 'manifest.json').read_text(encoding='utf-8-sig'))
    manifest['version_number'] = info['version']
    for dependency in info.get('manifest_dependencies', []):
        if dependency not in manifest.setdefault('dependencies', []):
            manifest['dependencies'].append(dependency)
    (phase / 'manifest.json').write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
    provenance = dict(phase=info['phase'], folder=info['folder'], version=info['version'], assembly=info['assembly'], game_sha256=digest(GAME / 'Assembly-CSharp.dll'), output_sha256=digest(target), original_sha256=digest(original), loose_output=str(target), compiled=not info.get('reuse_original_binary', False), checks_passed=True, runtime_tested=False, installed=False, source_sha256={str(p.relative_to(phase)): digest(p) for p in phase_sources(phase)})
    provenance['original_relative_path'] = str(original.relative_to(PLUGINS))
    provenance['source_basis'] = info.get('source_basis', 'See Changelog.md')
    provenance['embedded_resource_sha256'] = {path: digest(phase / path) for path in info.get('embedded_resources', {})}
    api = json.loads((phase / 'api-audit.json').read_text(encoding='utf-8-sig'))
    provenance['api_reference_count'] = api['GameReferences']
    provenance['harmony_patch_count'] = len(api['Patches'])
    provenance['api_findings'] = len(api['Problems'])
    provenance['raw_api_findings'] = api.get('RawProblemCount', len(api['Problems']))
    provenance['inactive_api_findings'] = len(api.get('InactiveProblems', []))
    provenance['logic_check_executed'] = (phase / 'check.cs').exists()
    provenance['headless_test_reference'] = (phase / 'check-prepare.ps1').exists()
    provenance['validation_source_sha256'] = {name: digest(phase / name) for name in ('check.cs', 'check-prepare.ps1', 'prepare-reference.ps1', 'patch.ps1', 'validate.ps1', 'verify-inactive-patches.ps1') if (phase / name).exists()}
    if 'expected_original_sha256' in info and digest(original) != info['expected_original_sha256']:
        raise RuntimeError('Installed binary changed during build; package not produced')
    (phase / 'build-result.json').write_text(json.dumps(provenance, indent=2), encoding='utf-8')
    (phase / 'build.log').write_text(log, encoding='utf-8')
    archive = phase / (info['folder'] + '-' + info['version'] + '.zip')
    with zipfile.ZipFile(archive, 'w', compression=zipfile.ZIP_DEFLATED) as z:
        z.write(target, 'plugins/' + info['folder'] + '/' + target.name)
        z.write(phase / 'manifest.json', 'manifest.json')
        z.write(phase / 'Changelog.md', 'Changelog.md')
        z.write(phase / 'build-result.json', 'build-result.json')
        z.write(phase / 'api-audit.json', 'api-audit.json')
        z.write(phase / 'build.log', 'build.log')
        for name in info.get('package_resource_paths', []):
            z.write(PLUGINS / info['folder'] / name, 'plugins/' + info['folder'] + '/' + name)
        for name in ('README.md', 'icon.png', 'LICENSE', 'LICENSE.md', 'LICENSE.txt'):
            resource = phase / name
            if not resource.exists():
                resource = PLUGINS / info['folder'] / name
            if resource.exists():
                z.write(resource, name)
        for resource in phase_sources(phase):
            z.write(resource, str(resource.relative_to(phase)))
        for path in info.get('embedded_resources', {}):
            z.write(phase / path, path)
        for name in ('phase.json', 'check.cs', 'check-prepare.ps1', 'prepare-reference.ps1', 'patch.ps1', 'validate.ps1', 'validation.json', 'verify-inactive-patches.ps1', 'inactive-patches.json'):
            resource = phase / name
            if resource.exists():
                z.write(resource, name)
    archive.with_suffix('.zip.sha256').write_text(digest(archive) + '  ' + archive.name + '\n', encoding='ascii')
    print(json.dumps(provenance, indent=2))

if __name__ == '__main__':
    build(sys.argv[1])
