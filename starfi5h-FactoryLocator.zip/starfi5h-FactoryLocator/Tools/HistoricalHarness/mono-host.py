"""Run a headless managed check in the game's exact embedded Mono runtime."""
import ctypes
import os
from pathlib import Path
import sys

GAME = Path('D:/Games/Dyson Sphere Program')
runtime = GAME / 'MonoBleedingEdge'
ctypes.windll.kernel32.SetErrorMode(0x8003)
os.environ.pop('MONO_ENV_OPTIONS', None)
os.environ['MONO_PATH'] = os.pathsep.join(sys.argv[2:])
os.add_dll_directory(str(runtime / 'EmbedRuntime'))
mono = ctypes.CDLL(str(runtime / 'EmbedRuntime/mono-2.0-bdwgc.dll'))

def api(name, result, *args):
    fn = getattr(mono, name)
    fn.restype, fn.argtypes = result, args
    return fn

ptr = ctypes.c_void_p
api('mono_set_dirs', None, ctypes.c_char_p, ctypes.c_char_p)(
    str(GAME / 'DSPGAME_Data/Managed').encode(), str(runtime / 'etc').encode())
api('mono_config_parse', None, ctypes.c_char_p)(None)
domain = api('mono_jit_init_version', ptr, ctypes.c_char_p, ctypes.c_char_p)(b'CompatibilityCheck', b'v4.0.30319')
if not domain:
    raise RuntimeError('Mono domain initialization failed')
assembly = api('mono_domain_assembly_open', ptr, ptr, ctypes.c_char_p)(domain, str(Path(sys.argv[1]).resolve()).encode())
if not assembly:
    raise RuntimeError('Check assembly could not be loaded')
img = api('mono_assembly_get_image', ptr, ptr)(assembly)
klass = api('mono_class_from_name', ptr, ptr, ctypes.c_char_p, ctypes.c_char_p)(img, b'', b'Check')
method = api('mono_class_get_method_from_name', ptr, ptr, ctypes.c_char_p, ctypes.c_int)(klass, b'Main', 0)
if not method:
    raise RuntimeError('Check.Main() not found')
error = ptr()
answer = api('mono_runtime_invoke', ptr, ptr, ptr, ptr, ctypes.POINTER(ptr))(method, None, None, ctypes.byref(error))
if error.value:
    nested = ptr()
    message = api('mono_object_to_string', ptr, ptr, ctypes.POINTER(ptr))(error, ctypes.byref(nested))
    utf8 = api('mono_string_to_utf8', ptr, ptr)(message)
    print(ctypes.string_at(utf8).decode('utf-8', errors='replace'), flush=True)
    sys.exit(1)
if answer:
    value = api('mono_object_unbox', ptr, ptr)(answer)
    sys.exit(ctypes.cast(value, ctypes.POINTER(ctypes.c_int)).contents.value)
