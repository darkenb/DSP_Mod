using System;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;

// This entry point has no Unity, game, plugin or Harmony type references.
// Resolve dependencies before CLR loads the check's entry-point type.
internal static class TestHost
{
    [DllImport("kernel32.dll")]
    private static extern uint SetErrorMode(uint mode);
    private static int Main(string[] args)
    {
        SetErrorMode(0x0001 | 0x0002 | 0x8000);
        Console.OutputEncoding = new UTF8Encoding(false);
        Console.SetError(new StreamWriter(Console.OpenStandardError(), new UTF8Encoding(false)) { AutoFlush = true });
        try
        {
            if (args.Length == 0) throw new ArgumentException("Missing check assembly path");
            string checkPath = Path.GetFullPath(args[0]);
            string[] directories = new string[args.Length];
            directories[0] = Path.GetDirectoryName(checkPath);
            Array.Copy(args, 1, directories, 1, args.Length - 1);
            AppDomain.CurrentDomain.AssemblyResolve += (sender, ev) => {
                string filename = new AssemblyName(ev.Name).Name + ".dll";
                foreach (string directory in directories) {
                    string path = Path.Combine(directory, filename);
                    if (File.Exists(path)) return Assembly.LoadFrom(path);
                }
                return null;
            };
            string[] checkArgs = new string[args.Length - 1];
            Array.Copy(args, 1, checkArgs, 0, checkArgs.Length);
            Assembly check = Assembly.LoadFrom(checkPath);
            MethodInfo entry = check.EntryPoint;
            if (entry == null) throw new InvalidOperationException("Check assembly has no entry point");
            object result = entry.Invoke(null, entry.GetParameters().Length == 0 ? null : new object[] { checkArgs });
            return result is int ? (int)result : Environment.ExitCode;
        }
        catch (Exception error)
        {
            var invocation = error as TargetInvocationException;
            Console.Error.WriteLine("CHECK HOST FAILED: " + (invocation != null && invocation.InnerException != null ? invocation.InnerException : error));
            return 1;
        }
    }
}
