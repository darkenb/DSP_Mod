# starfi5h-FactoryLocator — detailed change report

Installed plugin version(s): **1.3.15**. Reject empty/deleted/out-of-range entities and invalid recipe components without hard-coding vanilla recipe limits.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Valid live search results — 1.3.14/1.3.15

Use the source matching installed 1.3.13 and retain its existing warning focus-line cleanup.

- Exclude native entity slot 0 from building results.
- Reject removed, out-of-pool and unassigned assembler/lab recipe records. Use actual live components and recipe IDs; do not impose a vanilla-ID limit on Genesis recipes.
- Permit safe factory-query preparation before the window exists.
- Search underwater oil through current vein groups, without duplicating native mineral generation. Preserve native mining warnings and station sorting.

Version 1.3.15 adds `/unsafe+` private-access metadata, checked in embedded Mono without modifying the game DLL. Native-data tests cover a live custom recipe, a deleted component and the empty entity slot. Real Genesis quantum factories, remote GS planets, focus-line rendering and LSTM/PlanetFinder UI coexistence remain unverified. NebulaModel is only the existing optional compatibility bridge's compile reference; a full Nebula implementation is not installed or bundled.

## Recorded source commits

- `3d77a1ebff3ed4d0b7c29aba4e1b9a6b61f7bea1`

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
