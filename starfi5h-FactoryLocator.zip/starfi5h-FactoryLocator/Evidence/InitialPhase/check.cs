using System;
using System.Collections.Generic;
using System.Runtime.Serialization;
using HarmonyLib;
using FactoryLocator;

static class Check
{
    static int Main()
    {
        var factory = (PlanetFactory)FormatterServices.GetUninitializedObject(typeof(PlanetFactory));
        factory.entityPool = new EntityData[4]; factory.entityCursor = 4;
        factory.entityPool[1] = new EntityData {id = 1, protoId = 9911};
        var system = (FactorySystem)FormatterServices.GetUninitializedObject(typeof(FactorySystem));
        AccessTools.Field(typeof(PlanetFactory), "factorySystem").SetValue(factory, system);
        system.assemblerCursor = 3; system.assemblerPool = new AssemblerComponent[3];
        system.assemblerPool[1] = new AssemblerComponent {id = 1, entityId = 1, recipeId = 9912};
        system.assemblerPool[2] = new AssemblerComponent {id = 2, entityId = 2, recipeId = 9912};
        system.labCursor = 1; system.labPool = new LabComponent[1];
        var logic = new MainLogic();
        ((List<PlanetFactory>)AccessTools.Field(typeof(MainLogic), "factories").GetValue(logic)).Add(factory);
        logic.RefreshBuilding(-1);
        var counts = (Dictionary<int,int>)AccessTools.Field(typeof(MainLogic), "filterIds").GetValue(logic);
        if (counts.Count != 1 || counts[9911] != 1) throw new Exception("Empty entity slot counted");
        logic.RefreshAssemblers(-1);
        if (counts.Count != 1 || counts[9912] != 1) throw new Exception("Special recipe missing or stale component counted");
        Console.WriteLine("PASS native entity zero omitted, live mod recipe counted once and removed component ignored");
        return 0;
    }
}
