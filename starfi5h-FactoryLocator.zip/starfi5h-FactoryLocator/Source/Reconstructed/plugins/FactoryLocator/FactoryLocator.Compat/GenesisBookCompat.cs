using System;
using BepInEx.Bootstrap;

namespace FactoryLocator.Compat;

public static class GenesisBookCompat
{
	private const string GUID = "org.LoShin.GenesisBook";

	public static void Init()
	{
		if (!Chainloader.PluginInfos.TryGetValue("org.LoShin.GenesisBook", out var _))
		{
			return;
		}
		try
		{
			UIentryCount.ItemCol = 17;
			UIentryCount.RecipeCol = 17;
			UIentryCount.SignalCol = 17;
			Log.Debug("GenesisBook compat - OK");
		}
		catch (Exception obj)
		{
			Log.Warn("GenesisBook compat fail! Last target version: 2.9.12");
			Log.Debug(obj);
		}
	}
}
