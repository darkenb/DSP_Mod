using System;
using BepInEx.Bootstrap;

namespace FactoryLocator.Compat;

public static class DSPMoreRecipesCompat
{
	private const string GUID = "Appun.DSP.plugin.MoreRecipes";

	public static void Init()
	{
		if (!Chainloader.PluginInfos.TryGetValue("Appun.DSP.plugin.MoreRecipes", out var _))
		{
			return;
		}
		try
		{
			UIentryCount.RecipeCol = 17;
			Log.Debug("DSPMoreRecipes compat - OK");
		}
		catch (Exception obj)
		{
			Log.Warn("DSPMoreRecipesCompat fail! Last target version: 1.0.3");
			Log.Debug(obj);
		}
	}
}
