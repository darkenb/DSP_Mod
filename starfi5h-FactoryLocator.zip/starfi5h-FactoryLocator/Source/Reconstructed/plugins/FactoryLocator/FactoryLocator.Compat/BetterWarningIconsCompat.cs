using System;
using BepInEx.Bootstrap;
using xiaoye97;

namespace FactoryLocator.Compat;

public static class BetterWarningIconsCompat
{
	private const string GUID = "dev.raptor.dsp.BetterWarningIcons";

	private const int InsufficientInputSignalId = 531;

	public static void Preload()
	{
		if (Chainloader.PluginInfos.TryGetValue("dev.raptor.dsp.BetterWarningIcons", out var _))
		{
			LDBTool.PreAddProto((Proto)new SignalProto
			{
				ID = 531,
				IconPath = "",
				Name = "Insufficient Input",
				GridIndex = 3601,
				description = "Building does not have sufficient inputs to work"
			});
		}
	}

	public static void Postload()
	{
		if (!Chainloader.PluginInfos.TryGetValue("dev.raptor.dsp.BetterWarningIcons", out var _))
		{
			return;
		}
		try
		{
			SetIcon();
		}
		catch (Exception obj)
		{
			Log.Warn("BetterWarningIcons compat fail! Last target version: 0.0.5");
			Log.Debug(obj);
		}
	}

	private static void SetIcon()
	{
		SignalProto signalProto = LDB.signals.Select(531);
		signalProto.Name = "Insufficient Input";
		signalProto.name = "Insufficient Input".Translate();
	}
}
