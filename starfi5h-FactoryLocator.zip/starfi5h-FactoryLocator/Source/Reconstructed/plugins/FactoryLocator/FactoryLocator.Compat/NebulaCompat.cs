using System;
using System.Reflection;
using System.Runtime.CompilerServices;
using BepInEx.Bootstrap;
using HarmonyLib;
using NebulaAPI;
using NebulaModel.Networking;
using NebulaModel.Packets.Warning;

namespace FactoryLocator.Compat;

public static class NebulaCompat
{
	private const string GUID = "dsp.nebula-multiplayer";

	private static bool isPatched;

	public static bool IsClient { get; private set; }

	public static bool SyncWarning { get; set; } = true;

	public static void Init()
	{
		if (!Chainloader.PluginInfos.TryGetValue("dsp.nebula-multiplayer", out var value))
		{
			return;
		}
		try
		{
			Patch();
			Log.Debug("Nebula compat - OK");
		}
		catch (Exception obj)
		{
			Log.Warn("Nebula hotfix patch fail! Current version: " + value.Metadata.Version);
			Log.Debug(obj);
		}
	}

	public static void OnOpen()
	{
		if (!IsClient)
		{
			return;
		}
		SyncWarning = false;
		WarningSystem warningSystem = GameMain.data.warningSystem;
		warningSystem.warningRecycleCursor = 0;
		for (int i = 1; i < warningSystem.warningCursor; i++)
		{
			if (warningSystem.warningPool[i].id != i)
			{
				warningSystem.warningRecycle[warningSystem.warningRecycleCursor++] = i;
			}
		}
	}

	public static void OnClose()
	{
		if (IsClient)
		{
			SyncWarning = true;
			SendUpdateRequest();
		}
	}

	[MethodImpl(MethodImplOptions.NoInlining)]
	public static void SendUpdateRequest()
	{
		//IL_000b: Unknown result type (might be due to invalid IL or missing references)
		//IL_0015: Expected O, but got Unknown
		NebulaModAPI.MultiplayerSession.Network.SendPacket<WarningDataRequest>(new WarningDataRequest((WarningRequestEvent)0));
	}

	public static void OnUpdate()
	{
		if (!IsClient)
		{
			return;
		}
		WarningSystem warningSystem = GameMain.data.warningSystem;
		Array.Clear(warningSystem.warningCounts, 0, warningSystem.warningCounts.Length);
		Array.Clear(warningSystem.warningSignals, 0, warningSystem.warningSignals.Length);
		warningSystem.warningSignalCount = 0;
		for (int i = 1; i < warningSystem.warningCursor; i++)
		{
			if (warningSystem.warningPool[i].id == i && warningSystem.warningPool[i].state > 0)
			{
				int signalId = warningSystem.warningPool[i].signalId;
				if (warningSystem.warningCounts[signalId] == 0)
				{
					warningSystem.warningSignals[warningSystem.warningSignalCount++] = signalId;
				}
				warningSystem.warningCounts[signalId]++;
			}
		}
		for (int j = 0; j < warningSystem.warningSignalCount - 1; j++)
		{
			for (int k = j + 1; k < warningSystem.warningSignalCount; k++)
			{
				if (warningSystem.warningSignals[j] > warningSystem.warningSignals[k])
				{
					int num = warningSystem.warningSignals[k];
					warningSystem.warningSignals[k] = warningSystem.warningSignals[j];
					warningSystem.warningSignals[j] = num;
				}
			}
		}
	}

	public static void Patch()
	{
		Type type = AccessTools.TypeByName("NebulaWorld.Multiplayer");
		Plugin.harmony.Patch(AccessTools.Method(type, "JoinGame"), new HarmonyMethod(typeof(NebulaCompat).GetMethod("BeforeJoinGame")));
		Plugin.harmony.Patch(AccessTools.Method(type, "LeaveGame"), new HarmonyMethod(typeof(NebulaCompat).GetMethod("BeforeLeaveGame")));
		type = AccessTools.TypeByName("NebulaPatcher.Patches.Dynamic.WarningSystem_Patch");
		MethodInfo methodInfo = AccessTools.Method(type, "CalcFocusDetail_Prefix");
		if (methodInfo != null)
		{
			Plugin.harmony.Patch(methodInfo, new HarmonyMethod(typeof(NebulaCompat).GetMethod("Guard")));
		}
	}

	public static void BeforeJoinGame()
	{
		if (!isPatched)
		{
			isPatched = true;
			try
			{
				foreach (Assembly item in AccessTools.AllAssemblies())
				{
					_ = item;
				}
				MethodInfo original = AccessTools.Method(AccessTools.TypeByName("NebulaNetwork.PacketProcessors.Warning.WarningDataProcessor"), "ProcessPacket", new Type[2]
				{
					typeof(WarningDataPacket),
					typeof(NebulaConnection)
				});
				Plugin.harmony.Patch(original, new HarmonyMethod(typeof(NebulaCompat).GetMethod("Guard")));
				original = AccessTools.Method(AccessTools.TypeByName("NebulaNetwork.PacketProcessors.Warning.WarningSignalProcessor"), "ProcessPacket", new Type[2]
				{
					typeof(WarningSignalPacket),
					typeof(NebulaConnection)
				});
				Plugin.harmony.Patch(original, new HarmonyMethod(typeof(NebulaCompat).GetMethod("Guard")));
				Log.Info("PacketProcessors patch success!");
			}
			catch (Exception obj)
			{
				Log.Warn("PacketProcessors patch fail!");
				Log.Warn(obj);
			}
		}
		IsClient = true;
	}

	public static void BeforeLeaveGame()
	{
		IsClient = false;
	}

	public static bool Guard()
	{
		return SyncWarning;
	}
}
