using UnityEngine;
using UnityEngine.UI;

namespace FactoryLocator.UI;

public class MyCheckBox : MonoBehaviour
{
	public UIButton uiButton;

	public Image checkImage;

	public RectTransform rectTrans;

	public Text labelText;

	public bool enable;

	public static MyCheckBox CreateCheckBox(bool startingState, string label = "", int fontSize = 17)
	{
		GameObject gameObject = Object.Instantiate(UIRoot.instance.uiGame.buildMenu.uxFacilityCheck.gameObject);
		gameObject.name = "my-checkbox";
		MyCheckBox myCheckBox = gameObject.AddComponent<MyCheckBox>();
		myCheckBox.enable = startingState;
		RectTransform rectTransform = (myCheckBox.rectTrans = gameObject.transform as RectTransform);
		rectTransform.anchorMax = Vector2.zero;
		rectTransform.anchorMin = Vector2.zero;
		rectTransform.anchoredPosition3D = new Vector3(0f, 0f, 0f);
		myCheckBox.uiButton = gameObject.GetComponent<UIButton>();
		myCheckBox.checkImage = gameObject.transform.Find("checked")?.GetComponent<Image>();
		Transform transform = gameObject.transform.Find("text");
		if (transform != null)
		{
			Object.DestroyImmediate(transform.GetComponent<Localizer>());
			myCheckBox.labelText = transform.GetComponent<Text>();
			myCheckBox.labelText.fontSize = fontSize;
			myCheckBox.SetLabelText(label);
		}
		myCheckBox.uiButton.onClick += myCheckBox.OnClick;
		myCheckBox.checkImage.enabled = myCheckBox.enable;
		return myCheckBox;
	}

	public void SetLabelText(string val)
	{
		if (labelText != null)
		{
			labelText.text = val;
		}
	}

	public void OnClick(int obj)
	{
		enable = !enable;
		checkImage.enabled = enable;
	}
}
