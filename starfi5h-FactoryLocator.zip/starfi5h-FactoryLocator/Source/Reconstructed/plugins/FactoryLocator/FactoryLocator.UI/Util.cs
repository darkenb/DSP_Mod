using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.Events;
using UnityEngine.UI;

namespace FactoryLocator.UI;

public class Util
{
	public static RectTransform NormalizeRectWithTopLeft(Component cmp, float left, float top, Transform parent = null)
	{
		RectTransform rectTransform = cmp.transform as RectTransform;
		if (parent != null)
		{
			rectTransform.SetParent(parent, worldPositionStays: false);
		}
		rectTransform.anchorMax = new Vector2(0f, 1f);
		rectTransform.anchorMin = new Vector2(0f, 1f);
		rectTransform.pivot = new Vector2(0f, 1f);
		rectTransform.anchoredPosition3D = new Vector3(left, 0f - top, 0f);
		return rectTransform;
	}

	public static RectTransform NormalizeRectWithMargin(Component cmp, float top, float left, float bottom, float right, Transform parent = null)
	{
		RectTransform rectTransform = cmp.transform as RectTransform;
		if (parent != null)
		{
			rectTransform.SetParent(parent, worldPositionStays: false);
		}
		rectTransform.anchoredPosition3D = Vector3.zero;
		rectTransform.localScale = Vector3.one;
		rectTransform.anchorMax = Vector2.one;
		rectTransform.anchorMin = Vector2.zero;
		rectTransform.pivot = new Vector2(0.5f, 0.5f);
		rectTransform.offsetMax = new Vector2(0f - right, 0f - top);
		rectTransform.offsetMin = new Vector2(left, bottom);
		return rectTransform;
	}

	public static Text CreateText(string label, int fontSize = 14, TextAnchor anchor = TextAnchor.MiddleLeft)
	{
		Text text = Object.Instantiate(UIRoot.instance.uiGame.assemblerWindow.stateText);
		text.gameObject.name = "txt_" + label;
		text.text = label;
		text.color = new Color(1f, 1f, 1f, 0.4f);
		text.alignment = anchor;
		text.fontSize = fontSize;
		return text;
	}

	public static UIButton CreateButton(string label, float width = 0f, float height = 0f)
	{
		UIButton uIButton = Object.Instantiate(UIRoot.instance.uiGame.dysonEditor.controlPanel.hierarchy.swarmPanel.orbitAddButton);
		uIButton.gameObject.name = "btn_" + label;
		if (uIButton.transitions.Length >= 1)
		{
			uIButton.transitions[0].normalColor = new Color(0.2392f, 0.6f, 0.9f, 0.078f);
		}
		Text component = uIButton.transform.Find("Text").GetComponent<Text>();
		component.text = label;
		component.fontSize = 17;
		Object.Destroy(uIButton.transform.Find("Text").GetComponent<Localizer>());
		RectTransform rectTransform = uIButton.transform as RectTransform;
		if (width == 0f || height == 0f)
		{
			rectTransform.sizeDelta = new Vector2(component.preferredWidth + 14f, 24f);
		}
		else
		{
			rectTransform.sizeDelta = new Vector2(width, height);
		}
		return uIButton;
	}

	public static void CreateSignalIcon(out UIButton iconButton, out Image iconImage)
	{
		GameObject gameObject = Object.Instantiate(UIRoot.instance.uiGame.beltWindow.iconTagButton.transform.gameObject);
		gameObject.name = "signal-button";
		gameObject.SetActive(value: true);
		RectTransform rectTransform = (RectTransform)gameObject.transform;
		for (int num = rectTransform.childCount - 1; num >= 0; num--)
		{
			Object.Destroy(rectTransform.GetChild(num).gameObject);
		}
		iconButton = rectTransform.GetComponent<UIButton>();
		iconButton.tips.tipTitle = "Signal Icon".Translate();
		iconButton.tips.tipText = "Select a signal to display.".Translate();
		iconImage = rectTransform.GetComponent<Image>();
	}

	public static UIComboBox CreateComboBox(UnityAction OnComboBoxIndexChange, float width, float height = 30f)
	{
		UIComboBox uIComboBox = Object.Instantiate(UIRoot.instance.uiGame.statWindow.productSortBox);
		uIComboBox.name = "FactoryLocator comboBox";
		Transform transform = uIComboBox.transform.Find("Dropdown List ScrollBox/Mask/Content Panel/");
		for (int num = transform.childCount - 1; num >= 0; num--)
		{
			if (transform.GetChild(num).name == "Item Button(Clone)")
			{
				Object.Destroy(transform.GetChild(num).gameObject);
			}
		}
		((RectTransform)uIComboBox.transform).sizeDelta = new Vector2(width, height);
		UIComboBox componentInChildren = uIComboBox.GetComponentInChildren<UIComboBox>();
		componentInChildren.onItemIndexChange.RemoveAllListeners();
		componentInChildren.itemIndex = 0;
		componentInChildren.m_Input.text = "";
		componentInChildren.onItemIndexChange.AddListener(OnComboBoxIndexChange);
		return componentInChildren;
	}

	public static int RecipeIdUnderMouse()
	{
		if (UIRoot.instance.uiGame.replicator.active)
		{
			UIReplicatorWindow replicator = UIRoot.instance.uiGame.replicator;
			if (replicator.mouseRecipeIndex >= 0)
			{
				RecipeProto recipeProto = replicator.recipeProtoArray[replicator.mouseRecipeIndex];
				if (recipeProto != null)
				{
					return recipeProto.ID;
				}
			}
		}
		return 0;
	}

	public static int ItemIdHintUnderMouse()
	{
		List<RaycastResult> list = new List<RaycastResult>();
		PointerEventData eventData = new PointerEventData(EventSystem.current)
		{
			position = Input.mousePosition
		};
		EventSystem.current.RaycastAll(eventData, list);
		foreach (RaycastResult item in list)
		{
			UIButton componentInParent = item.gameObject.GetComponentInParent<UIButton>();
			if ((object)componentInParent != null)
			{
				_ = componentInParent.tips;
				if (componentInParent.tips.itemId > 0)
				{
					return componentInParent.tips.itemId;
				}
			}
			UIStorageGrid componentInParent2 = item.gameObject.GetComponentInParent<UIStorageGrid>();
			if (componentInParent2 != null)
			{
				StorageComponent storage = componentInParent2.storage;
				int mouseOnX = componentInParent2.mouseOnX;
				int mouseOnY = componentInParent2.mouseOnY;
				if (mouseOnX >= 0 && mouseOnY >= 0 && storage != null)
				{
					int num = mouseOnX + mouseOnY * componentInParent2.colCount;
					return storage.grids[num].itemId;
				}
				return 0;
			}
			UIPlayerDeliveryPanel componentInParent3 = item.gameObject.GetComponentInParent<UIPlayerDeliveryPanel>();
			if (componentInParent3 != null && componentInParent3.hoverIndexAbsolute >= 0)
			{
				return componentInParent3.deliveryPackage.grids[componentInParent3.hoverIndexAbsolute].itemId;
			}
			UIProductEntry componentInParent4 = item.gameObject.GetComponentInParent<UIProductEntry>();
			if (componentInParent4 != null)
			{
				if (componentInParent4.productionStatWindow.isProductionTab)
				{
					return componentInParent4.entryData?.itemId ?? 0;
				}
				return 0;
			}
		}
		return 0;
	}
}
