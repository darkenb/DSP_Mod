using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace FactoryLocator.UI;

public static class MyWindowCtl
{
	public static List<ManualBehaviour> _windows = new List<ManualBehaviour>(2);

	internal static bool _created = false;

	public static T CreateWindow<T>(string name, string title = "") where T : Component
	{
		UIInserterWindow inserterWindow = UIRoot.instance.uiGame.inserterWindow;
		GameObject gameObject = Object.Instantiate(inserterWindow.gameObject, inserterWindow.transform.parent);
		gameObject.name = name;
		gameObject.SetActive(value: false);
		Object.Destroy(gameObject.GetComponent<UIInserterWindow>());
		ManualBehaviour manualBehaviour = gameObject.AddComponent<T>() as ManualBehaviour;
		for (int i = 0; i < gameObject.transform.childCount; i++)
		{
			GameObject gameObject2 = gameObject.transform.GetChild(i).gameObject;
			if (gameObject2.name == "panel-bg")
			{
				Button componentInChildren = gameObject2.GetComponentInChildren<Button>();
				if (componentInChildren != null)
				{
					componentInChildren.onClick.AddListener(manualBehaviour._Close);
				}
			}
			else if (gameObject2.name != "shadow" && gameObject2.name != "panel-bg")
			{
				Object.Destroy(gameObject2);
			}
		}
		SetTitle(manualBehaviour, title);
		manualBehaviour._Create();
		manualBehaviour._Init(manualBehaviour.data);
		_windows.Add(manualBehaviour);
		return manualBehaviour as T;
	}

	public static void SetTitle(ManualBehaviour win, string title)
	{
		Text titleText = GetTitleText(win);
		if ((bool)titleText)
		{
			titleText.text = title;
		}
	}

	public static Text GetTitleText(ManualBehaviour win)
	{
		return win.gameObject.transform.Find("panel-bg/title-text")?.gameObject.GetComponent<Text>();
	}

	public static RectTransform GetRectTransform(ManualBehaviour win)
	{
		return win.GetComponent<RectTransform>();
	}

	public static void OpenWindow(ManualBehaviour win)
	{
		win._Open();
		win.transform.SetAsLastSibling();
	}

	public static void CloseWindow(ManualBehaviour win)
	{
		win._Close();
	}
}
