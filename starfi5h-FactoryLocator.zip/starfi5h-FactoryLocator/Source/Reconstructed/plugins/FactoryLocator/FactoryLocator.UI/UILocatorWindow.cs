using System.Collections.Generic;
using System.Text;
using FactoryLocator.Compat;
using UnityEngine;
using UnityEngine.UI;

namespace FactoryLocator.UI;

public class UILocatorWindow : ManualBehaviour
{
	public RectTransform windowTrans;

	private RectTransform tab1;

	private Text nameText;

	private UIButton[] queryBtns;

	private UIButton clearAllBtn;

	private Text iconText;

	private UIButton iconBtn;

	private Image iconImage;

	private MyCheckBox warningCheckBox;

	private MyCheckBox autoclearCheckBox;

	private PlanetData veiwPlanet;

	private StarData veiwStar;

	private bool initialized;

	private UIButtonTip statusTip;

	private string statusText = "";

	private bool autoclear_enable = true;

	private int currentLanguageLCID;

	private static UIComboBox comboBox;

	private static List<int> networkIds;

	private static int queryingType;

	private static int buildingIndex;

	private static int veinIndex;

	private static int assemblerIndex;

	private static int warningIndex;

	private static int storageIndex;

	private static int stationIndex;

	public static UILocatorWindow CreateWindow()
	{
		return MyWindowCtl.CreateWindow<UILocatorWindow>("FactoryLocator Window", "Factory Locator");
	}

	public void OpenWindow()
	{
		MyWindowCtl.OpenWindow(this);
		if (windowTrans != null)
		{
			windowTrans.sizeDelta = new Vector2(260f, 290f);
		}
	}

	public override void _OnCreate()
	{
		windowTrans = MyWindowCtl.GetRectTransform(this);
		windowTrans.sizeDelta = new Vector2(260f, 290f);
		CreateUI();
	}

	public override void _OnDestroy()
	{
		if (comboBox != null)
		{
			Object.Destroy(comboBox.gameObject);
			comboBox = null;
			Log.Debug("_OnDestroy");
		}
	}

	internal void CreateUI()
	{
		RectTransform base_ = windowTrans;
		float y_ = 54f;
		float x_ = 36f;
		int tabIndex_ = 1;
		tab1 = AddTab("General");
		base_ = tab1;
		y_ = 0f;
		x_ = 0f;
		nameText = Util.CreateText("Name", 16, TextAnchor.MiddleCenter);
		nameText.rectTransform.sizeDelta = new Vector2(180f, 20f);
		AddElement(nameText.transform as RectTransform, 0f, 0f);
		x_ = 0f;
		queryBtns = new UIButton[6];
		queryBtns[0] = Util.CreateButton("Building", 90f, 24f);
		AddElement(queryBtns[0].transform as RectTransform, 0f, 30f);
		queryBtns[0].onClick += delegate
		{
			OnQueryClick(0);
		};
		queryBtns[1] = Util.CreateButton("Vein", 90f, 24f);
		AddElement(queryBtns[1].transform as RectTransform, 98f, 0f);
		queryBtns[1].onClick += delegate
		{
			OnQueryClick(1);
		};
		queryBtns[2] = Util.CreateButton("Recipe", 90f, 24f);
		AddElement(queryBtns[2].transform as RectTransform, -98f, 32f);
		queryBtns[2].onClick += delegate
		{
			OnQueryClick(2);
		};
		queryBtns[3] = Util.CreateButton("Warning", 90f, 24f);
		AddElement(queryBtns[3].transform as RectTransform, 98f, 0f);
		queryBtns[3].onClick += delegate
		{
			OnQueryClick(3);
		};
		queryBtns[4] = Util.CreateButton("Storage", 90f, 24f);
		AddElement(queryBtns[4].transform as RectTransform, -98f, 32f);
		queryBtns[4].onClick += delegate
		{
			OnQueryClick(4);
		};
		queryBtns[5] = Util.CreateButton("Station", 90f, 24f);
		AddElement(queryBtns[5].transform as RectTransform, 98f, 0f);
		queryBtns[5].onClick += delegate
		{
			OnQueryClick(5);
		};
		x_ = 0f;
		iconText = CreateTitleText("Signal Icon");
		AddElement(iconText.transform as RectTransform, -20f, 34f);
		Util.CreateSignalIcon(out iconBtn, out iconImage);
		AddElement(iconBtn.transform as RectTransform, 90f, -3f);
		iconBtn.onClick += OnIconBtnClick;
		clearAllBtn = Util.CreateButton("Clear All", 70f, 24f);
		AddElement(clearAllBtn.transform as RectTransform, 48f, 7f);
		clearAllBtn.onClick += delegate
		{
			WarningSystemPatch.ClearAll();
		};
		x_ = 0f;
		warningCheckBox = MyCheckBox.CreateCheckBox(WarningSystemPatch.Enable, "Display All Warning");
		AddElement(warningCheckBox.rectTrans, 0f, 30f);
		warningCheckBox.uiButton.onClick += OnWarningCheckboxClick;
		x_ = 0f;
		autoclearCheckBox = MyCheckBox.CreateCheckBox(autoclear_enable, "Auto Clear Query");
		AddElement(autoclearCheckBox.rectTrans, 0f, 26f);
		autoclearCheckBox.uiButton.onClick += OnAutoClearCheckoxClick;
		void AddElement(RectTransform rect_, float deltaX, float deltaY)
		{
			x_ += deltaX;
			y_ += deltaY;
			if (rect_ != null)
			{
				Util.NormalizeRectWithTopLeft(rect_, x_, y_, base_);
			}
		}
		RectTransform AddTab(string label)
		{
			GameObject obj = new GameObject();
			RectTransform rectTransform = obj.AddComponent<RectTransform>();
			Util.NormalizeRectWithMargin(rectTransform, 52f, 36f, 0f, 0f, windowTrans);
			obj.name = "tab-" + tabIndex_;
			return rectTransform;
		}
		Text CreateTitleText(string label_)
		{
			Text text = Object.Instantiate(MyWindowCtl.GetTitleText(this));
			text.gameObject.name = "label";
			text.text = label_;
			text.color = new Color(1f, 1f, 1f, 0.5f);
			(text.transform as RectTransform).sizeDelta = new Vector2(text.preferredWidth + 40f, 30f);
			return text;
		}
	}

	public override void _OnOpen()
	{
		if (!initialized)
		{
			OnSignalPickReturn(Plugin.config.SignalIconId.Value);
			if (!Plugin.config.AutoClearQuery.Value)
			{
				autoclearCheckBox.OnClick(0);
			}
			initialized = true;
		}
		SetText();
		SetViewingTarget();
		NebulaCompat.OnOpen();
	}

	public override void _OnClose()
	{
		if (statusTip != null)
		{
			Object.Destroy(statusTip.gameObject);
		}
		if (autoclear_enable)
		{
			WarningSystemPatch.ClearAll();
		}
		UIentryCount.OnClose();
		NebulaCompat.OnClose();
		comboBox?.gameObject.SetActive(value: false);
		Plugin.config.SignalIconId.Value = Plugin.mainLogic.SignalId;
		Plugin.config.AutoClearQuery.Value = autoclear_enable;
	}

	public void SetText()
	{
		if (currentLanguageLCID != Localization.CurrentLanguageLCID)
		{
			currentLanguageLCID = Localization.CurrentLanguageLCID;
			queryBtns[0].transform.Find("Text").GetComponent<Text>().text = "Building".Translate();
			queryBtns[1].transform.Find("Text").GetComponent<Text>().text = "Vein".Translate();
			queryBtns[2].transform.Find("Text").GetComponent<Text>().text = "Recipe".Translate();
			queryBtns[3].transform.Find("Text").GetComponent<Text>().text = "Warning".Translate();
			queryBtns[4].transform.Find("Text").GetComponent<Text>().text = "Storage".Translate();
			queryBtns[5].transform.Find("Text").GetComponent<Text>().text = "Station".Translate();
			iconText.text = "Signal Icon".Translate();
			clearAllBtn.transform.Find("Text").GetComponent<Text>().text = "Clear All".Translate();
			warningCheckBox.labelText.text = "Display All Warning".Translate();
			autoclearCheckBox.labelText.text = "Auto Clear Query".Translate();
		}
	}

	public void SetViewingTarget()
	{
		veiwStar = null;
		veiwPlanet = null;
		if (UIRoot.instance.uiGame.planetDetail.active)
		{
			veiwPlanet = UIRoot.instance.uiGame.planetDetail.planet;
		}
		else if (UIRoot.instance.uiGame.starDetail.active)
		{
			veiwStar = UIRoot.instance.uiGame.starDetail.star;
		}
		else
		{
			veiwPlanet = GameMain.localPlanet;
		}
		if (veiwStar != null)
		{
			nameText.text = veiwStar.displayName + "空格行星系".Translate();
		}
		else
		{
			nameText.text = veiwPlanet?.displayName ?? "外太空".Translate();
		}
		int num = Plugin.mainLogic.SetFactories(veiwStar, veiwPlanet);
		for (int i = 0; i < queryBtns.Length; i++)
		{
			queryBtns[i].button.enabled = num > 0;
		}
	}

	public void SetStatusTipText(float[] consumerRatio, int[] consumerCount)
	{
		StringBuilder stringBuilder = new StringBuilder();
		stringBuilder.AppendLine("Satisfaction - Consumer Count".Translate());
		for (int i = 0; i < consumerCount.Length; i++)
		{
			stringBuilder.AppendLine($"{consumerRatio[i],-3:P0} - {consumerCount[i]}");
		}
		statusText = stringBuilder.ToString();
		if (statusTip != null)
		{
			statusTip.subTextComp.text = statusText;
		}
	}

	public override void _OnUpdate()
	{
		if (UIRoot.instance.uiGame.starDetail.active)
		{
			if (UIRoot.instance.uiGame.starDetail.star != veiwStar)
			{
				SetViewingTarget();
			}
		}
		else if (UIRoot.instance.uiGame.planetDetail.active)
		{
			if (UIRoot.instance.uiGame.planetDetail.planet != veiwPlanet)
			{
				SetViewingTarget();
			}
		}
		else if (GameMain.localPlanet != veiwPlanet)
		{
			SetViewingTarget();
		}
		Transform transform = nameText.transform;
		if (RectTransformUtility.RectangleContainsScreenPoint((RectTransform)transform, Input.mousePosition, UIRoot.instance.overlayCanvas.worldCamera))
		{
			if (statusTip == null)
			{
				SetViewingTarget();
				statusTip = UIButtonTip.Create(topLevel: true, "Power Network Status".Translate(), statusText, 1, new Vector2(0f, -10f), 0, transform, "", "");
			}
		}
		else if (statusTip != null)
		{
			Object.Destroy(statusTip.gameObject);
			statusTip = null;
		}
		NebulaCompat.OnUpdate();
	}

	private void OnQueryClick(int queryType)
	{
		if (autoclear_enable)
		{
			WarningSystemPatch.ClearAll();
		}
		SetSubcategory(queryType);
		switch (queryType)
		{
		case 0:
			Plugin.mainLogic.PickBuilding(buildingIndex);
			break;
		case 1:
			Plugin.mainLogic.PickVein(veinIndex);
			break;
		case 2:
			Plugin.mainLogic.PickAssembler(assemblerIndex);
			break;
		case 3:
			Plugin.mainLogic.PickWarning(warningIndex);
			break;
		case 4:
			Plugin.mainLogic.PickStorage(storageIndex);
			break;
		case 5:
			Plugin.mainLogic.PickStation(stationIndex);
			break;
		}
	}

	public void SetPowerNetworkDropdownList(List<int> ids)
	{
		networkIds = ids;
	}

	public void SetSubcategory(int queryType)
	{
		if (comboBox == null)
		{
			comboBox = Util.CreateComboBox(OnComboBoxIndexChange, 200f);
		}
		switch (queryType)
		{
		case 2:
			Util.NormalizeRectWithTopLeft(comboBox, 153f, 7f, UIRoot.instance.uiGame.recipePicker.transform);
			break;
		case 3:
			Util.NormalizeRectWithTopLeft(comboBox, 153f, 7f, UIRoot.instance.uiGame.signalPicker.transform);
			break;
		default:
			Util.NormalizeRectWithTopLeft(comboBox, 153f, 7f, UIRoot.instance.uiGame.itemPicker.transform);
			break;
		}
		queryingType = queryType;
		comboBox.Items.Clear();
		comboBox.ItemsData.Clear();
		switch (queryType)
		{
		case 0:
		{
			buildingIndex = 0;
			if (networkIds == null)
			{
				comboBox.Items.Add("All".Translate());
				comboBox.ItemsData.Add(0);
				comboBox.itemIndex = 0;
				comboBox.gameObject.SetActive(value: false);
				return;
			}
			comboBox.Items.Add("All".Translate() + $" ({networkIds.Count})");
			comboBox.ItemsData.Add(0);
			for (int i = 0; i < networkIds.Count; i++)
			{
				comboBox.Items.Add("电网号".Translate() + networkIds[i]);
				comboBox.ItemsData.Add(i + 1);
			}
			comboBox.itemIndex = 0;
			break;
		}
		case 1:
			comboBox.Items.Add("All".Translate());
			comboBox.ItemsData.Add(0);
			comboBox.Items.Add("显示正在采集".Translate());
			comboBox.ItemsData.Add(1);
			comboBox.Items.Add("显示尚未采集".Translate());
			comboBox.ItemsData.Add(2);
			comboBox.itemIndex = veinIndex;
			break;
		case 2:
			comboBox.Items.Add("All".Translate());
			comboBox.ItemsData.Add(0);
			comboBox.Items.Add("额外产出".Translate());
			comboBox.ItemsData.Add(1);
			comboBox.Items.Add("加速生产".Translate());
			comboBox.ItemsData.Add(2);
			comboBox.Items.Add("缺少原材料".Translate());
			comboBox.ItemsData.Add(3);
			comboBox.Items.Add("产物堆积".Translate());
			comboBox.ItemsData.Add(4);
			comboBox.itemIndex = assemblerIndex;
			break;
		case 3:
			comboBox.Items.Add("All".Translate());
			comboBox.ItemsData.Add(0);
			comboBox.Items.Add("Recording Mode".Translate());
			comboBox.ItemsData.Add(1);
			comboBox.itemIndex = warningIndex;
			break;
		case 4:
			comboBox.Items.Add("All".Translate());
			comboBox.ItemsData.Add(0);
			comboBox.Items.Add("需求".Translate());
			comboBox.ItemsData.Add(1);
			comboBox.Items.Add("供应".Translate());
			comboBox.ItemsData.Add(2);
			comboBox.itemIndex = storageIndex;
			break;
		case 5:
			comboBox.Items.Add("All".Translate());
			comboBox.ItemsData.Add(0);
			comboBox.Items.Add("本地站点号".Translate());
			comboBox.ItemsData.Add(1);
			comboBox.Items.Add("星际站点号".Translate());
			comboBox.ItemsData.Add(2);
			comboBox.Items.Add("本地需求".Translate());
			comboBox.ItemsData.Add(3);
			comboBox.Items.Add("本地供应".Translate());
			comboBox.ItemsData.Add(4);
			comboBox.Items.Add("星际需求".Translate());
			comboBox.ItemsData.Add(5);
			comboBox.Items.Add("星际供应".Translate());
			comboBox.ItemsData.Add(6);
			comboBox.itemIndex = stationIndex;
			break;
		default:
			comboBox.gameObject.SetActive(value: false);
			return;
		}
		comboBox.gameObject.SetActive(value: true);
	}

	private void OnComboBoxIndexChange()
	{
		bool flag = UIRoot.instance.uiGame.itemPicker.active;
		bool flag2 = UIRoot.instance.uiGame.recipePicker.active;
		bool flag3 = UIRoot.instance.uiGame.signalPicker.active;
		switch (queryingType)
		{
		case 0:
			buildingIndex = comboBox.itemIndex;
			if (flag)
			{
				Plugin.mainLogic.OnBuildingPickReturn(null);
				UIItemPicker.Close();
				Plugin.mainLogic.PickBuilding(buildingIndex);
			}
			break;
		case 1:
			veinIndex = comboBox.itemIndex;
			if (flag)
			{
				Plugin.mainLogic.OnVeinPickReturn(null);
				UIItemPicker.Close();
				Plugin.mainLogic.PickVein(veinIndex);
			}
			break;
		case 2:
			assemblerIndex = comboBox.itemIndex;
			if (flag2)
			{
				Plugin.mainLogic.OnAssemblerPickReturn(null);
				UIRecipePicker.Close();
				Plugin.mainLogic.PickAssembler(assemblerIndex);
			}
			break;
		case 3:
			warningIndex = comboBox.itemIndex;
			if (flag3)
			{
				Plugin.mainLogic.OnWarningPickReturn(0);
				UISignalPicker.Close();
				Plugin.mainLogic.PickWarning(warningIndex);
			}
			break;
		case 4:
			storageIndex = comboBox.itemIndex;
			if (flag)
			{
				Plugin.mainLogic.OnStoragePickReturn(null);
				UIItemPicker.Close();
				Plugin.mainLogic.PickStorage(storageIndex);
			}
			break;
		case 5:
			stationIndex = comboBox.itemIndex;
			if (flag)
			{
				Plugin.mainLogic.OnStationPickReturn(null);
				UIItemPicker.Close();
				Plugin.mainLogic.PickStation(stationIndex);
			}
			break;
		}
	}

	private void OnIconBtnClick(int _)
	{
		UISignalPicker.Popup(new Vector2(-300f, 250f), OnSignalPickReturn);
	}

	private void OnSignalPickReturn(int signalId)
	{
		Sprite sprite = LDB.signals.IconSprite(signalId);
		if (sprite != null && signalId != 518)
		{
			Plugin.mainLogic.SignalId = signalId;
			iconImage.sprite = sprite;
		}
	}

	private void OnWarningCheckboxClick(int _)
	{
		WarningSystemPatch.Enable = !WarningSystemPatch.Enable;
	}

	private void OnAutoClearCheckoxClick(int _)
	{
		autoclear_enable = !autoclear_enable;
	}
}
