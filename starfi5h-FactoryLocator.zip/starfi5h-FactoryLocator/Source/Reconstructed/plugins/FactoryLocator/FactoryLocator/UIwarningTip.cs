using System.Collections.Generic;
using UnityEngine;

namespace FactoryLocator;

public class UIwarningTip
{
	private static UIButtonTip tip;

	public static void Create(UIWarningItemEntry itemEntry, int signalId)
	{
		if (tip != null)
		{
			Object.Destroy(tip.gameObject);
		}
		int detailId = itemEntry.detailId1;
		string title = ((detailId < 20000) ? LDB.ItemName(detailId) : LDB.RecipeName(detailId - 20000));
		string text = GetText(signalId, detailId);
		Transform transform = itemEntry.transform;
		tip = UIButtonTip.Create(topLevel: true, title, text, 2, new Vector2(0f, -10f), 0, transform, "", "");
	}

	public static void Destory()
	{
		if (tip != null)
		{
			Object.Destroy(tip.gameObject);
		}
		tip = null;
	}

	private static string GetText(int signalId, int detailId)
	{
		Dictionary<int, int> dictionary = new Dictionary<int, int>();
		WarningSystem warningSystem = GameMain.data.warningSystem;
		if (signalId > 0)
		{
			for (int i = 1; i < warningSystem.warningCursor; i++)
			{
				ref WarningData reference = ref warningSystem.warningPool[i];
				if (reference.id == i && reference.state > 0 && reference.signalId == signalId && reference.detailId1 == detailId)
				{
					if (dictionary.ContainsKey(reference.astroId))
					{
						int astroId = reference.astroId;
						int value = dictionary[astroId] + 1;
						dictionary[astroId] = value;
					}
					else
					{
						dictionary[reference.astroId] = 1;
					}
				}
			}
		}
		string text = "";
		foreach (KeyValuePair<int, int> item in dictionary)
		{
			PlanetData planetData = GameMain.galaxy.PlanetById(item.Key);
			if (planetData != null)
			{
				text = text + planetData.displayName + " (" + item.Value + ")\n";
			}
		}
		return text;
	}
}
