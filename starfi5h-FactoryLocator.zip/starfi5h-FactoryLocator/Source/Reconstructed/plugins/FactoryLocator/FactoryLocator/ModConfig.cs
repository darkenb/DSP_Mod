using BepInEx.Configuration;

namespace FactoryLocator;

public class ModConfig
{
	public ConfigEntry<int> SignalIconId { get; }

	public ConfigEntry<bool> AutoClearQuery { get; }

	public ConfigEntry<bool> RecordRecipeSignal { get; }

	public ModConfig(ConfigFile config)
	{
		SignalIconId = config.Bind("General", "SignalIconId", 401);
		AutoClearQuery = config.Bind("General", "AutoClearQuery", defaultValue: true);
		RecordRecipeSignal = config.Bind("Record", "RecordRecipeSignal", defaultValue: true);
	}
}
