using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace FactoryLocator;

public class WarningSystemPatch
{
	private const int INDEXUPPERBOND = -20000;

	private static int tmpSigalId = 0;

	private static int tick = 3;

	public static Action<WarningSystem, int> UnlinkWarningLine;

	private static int currentIndex = 0;

	public static bool Enable { get; set; } = true;

	[HarmonyPostfix]
	[HarmonyPatch(typeof(WarningSystem), "Import")]
	internal static void Import(WarningSystem __instance)
	{
		for (int i = 1; i < __instance.warningCursor; i++)
		{
			if (__instance.warningPool[i].factoryId <= -20000)
			{
				__instance.warningPool[i].detailId1 = -__instance.warningPool[i].factoryId + -20000;
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(WarningSystem), "GameTick")]
	internal static void GameTick()
	{
		Plugin.mainLogic.GameTick();
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIWarningWindow), "Determine")]
	internal static void Determine(ref bool open)
	{
		open &= Enable;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIWarningWindow), "_OnClose")]
	internal static void OnClose()
	{
		UIwarningTip.Destory();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIWarningWindow), "_OnLateUpdate")]
	internal static void OnLateUpdate(UIWarningWindow __instance)
	{
		if (tmpSigalId != 0)
		{
			__instance.selectedSignalId = tmpSigalId;
			if (--tick <= 0)
			{
				tmpSigalId = 0;
			}
		}
		if (!Input.GetKeyDown(KeyCode.Mouse0) && !Input.GetKeyDown(KeyCode.Mouse1))
		{
			return;
		}
		Camera worldCamera = UIRoot.instance.overlayCanvas.worldCamera;
		if (RectTransformUtility.RectangleContainsScreenPoint((RectTransform)__instance.itemGroup.transform, Input.mousePosition, worldCamera))
		{
			for (int i = 0; i < __instance.itemCount; i++)
			{
				if (!RectTransformUtility.RectangleContainsScreenPoint(__instance.itemEntries[i].rectTrans, Input.mousePosition, worldCamera))
				{
					continue;
				}
				if (Input.GetKeyDown(KeyCode.Mouse0))
				{
					if (VFInput.control)
					{
						SeekNextSignal(__instance.selectedSignalId, __instance.itemEntries[i].detailId1);
					}
					else
					{
						UIwarningTip.Create(__instance.itemEntries[i], __instance.selectedSignalId);
					}
				}
				else if (Input.GetKeyDown(KeyCode.Mouse1))
				{
					HideGroup(__instance.selectedSignalId, __instance.itemEntries[i].detailId1);
				}
				break;
			}
		}
		else
		{
			UIwarningTip.Destory();
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(PlanetFactory), "RemoveEntityWithComponents")]
	internal static void RemoveWarningByEntity(PlanetFactory __instance, int id)
	{
		int planetId = __instance.planetId;
		WarningSystem warningSystem = GameMain.data.warningSystem;
		for (int i = 1; i < warningSystem.warningCursor; i++)
		{
			ref WarningData reference = ref warningSystem.warningPool[i];
			if (reference.factoryId <= -20000 && reference.astroId == planetId && (reference.localPos - __instance.entityPool[id].pos).sqrMagnitude < 1f)
			{
				warningSystem.RemoveWarningData(i);
				Log.Debug($"Remove {i} on {planetId}");
			}
		}
	}

	public static void AddWarningData(int signalId, int detailId, List<int> planetIds, List<Vector3> localPos, List<int> detailIds = null)
	{
		if (planetIds.Count != localPos.Count || (detailIds != null && detailIds.Count != localPos.Count))
		{
			Log.Warn($"Length mismatch! planetIds:{planetIds.Count} pos:{localPos.Count}");
			return;
		}
		WarningSystem warningSystem = GameMain.data.warningSystem;
		int num = warningSystem.warningTotalCount + localPos.Count;
		int num2 = warningSystem.warningCapacity;
		while (num >= num2)
		{
			num2 *= 2;
		}
		if (num2 > warningSystem.warningCapacity)
		{
			warningSystem.SetWarningCapacity(num2);
		}
		for (int i = 0; i < localPos.Count; i++)
		{
			int num3 = warningSystem.warningCursor;
			if (warningSystem.warningRecycleCursor > 0)
			{
				num3 = warningSystem.warningRecycle[--warningSystem.warningRecycleCursor];
			}
			else
			{
				warningSystem.warningCursor++;
			}
			int num4 = detailIds?[i] ?? detailId;
			if (num4 < 0)
			{
				Log.Warn($"warningDetailId {num4} < 0");
				return;
			}
			ref WarningData reference = ref warningSystem.warningPool[num3];
			reference.id = num3;
			reference.state = 1;
			reference.signalId = signalId;
			reference.detailId1 = num4;
			reference.factoryId = -20000 - reference.detailId1;
			reference.astroId = planetIds[i];
			reference.localPos = localPos[i];
		}
		UIRoot.instance.uiGame.warningWindow.selectedSignalId = signalId;
		tmpSigalId = signalId;
		tick = 3;
		Log.Debug($"Add {localPos.Count}. Cursor = {warningSystem.warningCursor} RecycleCursor = {warningSystem.warningRecycleCursor} Capacity = {warningSystem.warningCapacity}");
	}

	public static void ClearAll()
	{
		int num = 0;
		WarningSystem warningSystem = GameMain.data.warningSystem;
		if (UnlinkWarningLine != null)
		{
			for (int num2 = warningSystem.warningCursor - 1; num2 > 0; num2--)
			{
				if (warningSystem.warningPool[num2].factoryId <= -20000)
				{
					UnlinkWarningLine(warningSystem, num2);
				}
			}
		}
		for (int num3 = warningSystem.warningCursor - 1; num3 > 0; num3--)
		{
			ref WarningData reference = ref warningSystem.warningPool[num3];
			if (reference.factoryId <= -20000)
			{
				reference.SetEmpty();
				if (num3 == warningSystem.warningCursor - 1)
				{
					warningSystem.warningCursor--;
				}
				else
				{
					warningSystem.warningRecycle[warningSystem.warningRecycleCursor++] = num3;
				}
				num++;
			}
			int num4 = warningSystem.warningCapacity;
			while (num4 / 2 > warningSystem.warningCursor)
			{
				num4 /= 2;
			}
			if (num4 != warningSystem.warningCapacity)
			{
				warningSystem.SetWarningCapacity(num4);
			}
		}
		if (num > 0)
		{
			Log.Debug($"Remove {num}. Cursor = {warningSystem.warningCursor} RecycleCursor = {warningSystem.warningRecycleCursor} Capacity = {warningSystem.warningCapacity}");
		}
	}

	public static void HideGroup(int signalId, int detailId)
	{
		WarningSystem warningSystem = GameMain.data.warningSystem;
		if (signalId <= 0)
		{
			return;
		}
		for (int i = 1; i < warningSystem.warningCursor; i++)
		{
			ref WarningData reference = ref warningSystem.warningPool[i];
			if (reference.id == i && reference.state > 0 && reference.signalId == signalId && reference.detailId1 == detailId && reference.factoryId <= -20000)
			{
				int factoryId = reference.factoryId;
				reference.SetEmpty();
				reference.factoryId = factoryId;
			}
		}
	}

	public static void SeekNextSignal(int signalId, int detailId)
	{
		int num = GameMain.localPlanet?.id ?? 0;
		WarningSystem warningSystem = GameMain.data.warningSystem;
		if (signalId <= 0 || detailId <= 0 || warningSystem.warningCursor <= 0 || num == 0)
		{
			return;
		}
		currentIndex %= warningSystem.warningCursor;
		int num2 = currentIndex;
		int num3 = 0;
		do
		{
			currentIndex = (currentIndex + 1) % warningSystem.warningCursor;
			ref WarningData reference = ref warningSystem.warningPool[currentIndex];
			if (reference.signalId == signalId && reference.detailId1 == detailId && reference.id == currentIndex && reference.state > 0 && reference.astroId == num)
			{
				Log.Debug($"SeekNextSignal[{currentIndex}]: ({signalId},{detailId}) {reference.localPos}");
				UIRoot.instance.uiGame.globemap.MoveToViewTargetTwoStep(reference.localPos, 200f);
				break;
			}
		}
		while (num3++ <= 999 && currentIndex != num2);
	}

	public static void Debug()
	{
		Log.Info(UIRoot.instance.uiGame.warningWindow.selectedSignalId);
		WarningSystem warningSystem = GameMain.data.warningSystem;
		for (int i = 1; i < warningSystem.warningCursor; i++)
		{
			ref WarningData reference = ref warningSystem.warningPool[i];
			if (reference.factoryId < -20000)
			{
				string text = $"[{i}] {reference.signalId} - {reference.factoryId}:";
				Vector3 localPos = reference.localPos;
				Log.Debug(text + localPos.ToString());
			}
		}
	}
}
