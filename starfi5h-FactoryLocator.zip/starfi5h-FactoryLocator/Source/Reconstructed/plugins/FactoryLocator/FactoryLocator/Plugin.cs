using System;
using System.Reflection;
using BepInEx;
using CommonAPI;
using CommonAPI.Systems;
using CommonAPI.Systems.ModLocalization;
using FactoryLocator.Compat;
using FactoryLocator.UI;
using HarmonyLib;
using UnityEngine;
using UnityEngine.EventSystems;

namespace FactoryLocator;

[BepInPlugin("starfi5h.plugin.FactoryLocator", "FactoryLocator", "1.3.15")]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "LocalizationModule", "CustomKeyBindSystem", "PickerExtensionsSystem" })]
public class Plugin : BaseUnityPlugin
{
	public const string GUID = "starfi5h.plugin.FactoryLocator";

	public const string NAME = "FactoryLocator";

	public const string VERSION = "1.3.15";

	public static UILocatorWindow mainWindow;

	public static MainLogic mainLogic;

	public static ModConfig config;

	public static Harmony harmony;

	public void Awake()
	{
		Log.LogSource = base.Logger;
		config = new ModConfig(base.Config);
		harmony = new Harmony("starfi5h.plugin.FactoryLocator");
		if (GameConfig.gameVersion < new Version(0, 10, 34))
		{
			Log.Error(string.Format("FactoryLocator v{0} only works on game 0.10.34+ \n Current Game Version: {1}", "1.3.15", GameConfig.gameVersion));
			return;
		}
		harmony.PatchAll(typeof(WarningSystemPatch));
		harmony.PatchAll(typeof(UIentryCount));
		MethodInfo methodInfo = AccessTools.Method(typeof(WarningSystem), "RemoveWarningLineOrder");
		if (methodInfo != null)
		{
			WarningSystemPatch.UnlinkWarningLine = (Action<WarningSystem, int>)Delegate.CreateDelegate(typeof(Action<WarningSystem, int>), methodInfo);
		}
		else
		{
			Log.Warn("WarningSystem.RemoveWarningLineOrder not found; skipping focus-line cleanup (older game build).");
		}
		harmony.PatchAll(typeof(Plugin));
		CustomKeyBindSystem.RegisterKeyBind<PressKeyBind>(new BuiltinKey
		{
			key = new CombineKey(102, 2, ECombineKeyAction.OnceClick, _noneKey: false),
			conflictGroup = 2052,
			name = "ShowFactoryLocator",
			canOverride = true
		});
		RegisterTranslation("KEYShowFactoryLocator", "Show Factory Locator Window", "打开FactoryLocator窗口");
		RegisterTranslation("Building", "Building", "建筑");
		RegisterTranslation("Vein", "Vein", "矿脉");
		RegisterTranslation("Recipe", "Recipe", "配方");
		RegisterTranslation("Warning", "Warning", "警报");
		RegisterTranslation("Storage", "Storage", "储物仓");
		RegisterTranslation("Station", "Station", "物流塔");
		RegisterTranslation("Signal Icon", "Signal Icon", "信号图标");
		RegisterTranslation("Clear All", "Clear All", "清空");
		RegisterTranslation("Display All Warning", "Display All Warning", "显示所有警报提示");
		RegisterTranslation("Auto Clear Query", "Auto Clear Query", "自动清除搜寻结果");
		RegisterTranslation("Power Network Status", "Power Network Status", "电网状态");
		RegisterTranslation("Satisfaction - Consumer Count", "Satisfaction - Consumer Count", "供电率 - 消耗者数量");
		RegisterTranslation("All", "All", "全部");
		RegisterTranslation("Recording Mode", "Recording Mode", "持续记录模式");
		BetterWarningIconsCompat.Preload();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	internal static void Init()
	{
		if (mainLogic == null)
		{
			Log.Debug("Initing...");
			mainLogic = new MainLogic
			{
				RecordRecipeSignal = config.RecordRecipeSignal.Value
			};
			mainWindow = UILocatorWindow.CreateWindow();
			NebulaCompat.Init();
			DSPMoreRecipesCompat.Init();
			GenesisBookCompat.Init();
			BetterWarningIconsCompat.Postload();
			try
			{
				AddUIWindowDrag(UIRoot.instance.uiGame.signalPicker.gameObject);
				AddUIWindowDrag(UIRoot.instance.uiGame.recipePicker.gameObject);
				AddUIWindowDrag(UIRoot.instance.uiGame.itemPicker.gameObject);
			}
			catch (Exception ex)
			{
				Log.Error("Error when adding UIWindowDrag\n" + ex);
			}
		}
	}

	private static void AddUIWindowDrag(GameObject gameObject)
	{
		GameObject gameObject2 = UnityEngine.Object.Instantiate(GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/FactoryLocator Window/panel-bg/drag-trigger"), gameObject.transform.Find("bg"));
		UIWindowDrag uIWindowDrag = gameObject.AddComponent<UIWindowDrag>();
		uIWindowDrag.dragTrigger = gameObject2.GetComponent<EventTrigger>();
		uIWindowDrag.screenRect = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows").GetComponent<RectTransform>();
		UnityEngine.Object.Destroy(gameObject2.GetComponent<UIBlockZone>());
	}

	private static void RegisterTranslation(string key, string enTrans, string cnTrans)
	{
		LocalizationModule.RegisterTranslation(key, enTrans, cnTrans, enTrans);
	}

	public void Update()
	{
		if (CustomKeyBindSystem.GetKeyBind("ShowFactoryLocator").keyValue)
		{
			if (!mainWindow.active)
			{
				mainWindow.OpenWindow();
				InspectItemUnderMouse();
			}
			else
			{
				mainWindow._Close();
			}
		}
		else if (mainWindow != null && mainWindow.active)
		{
			mainWindow._OnUpdate();
			if (VFInput.escape && !UIentryCount.Active)
			{
				VFInput.UseEscape();
				mainWindow._Close();
			}
		}
	}

	private static void InspectItemUnderMouse()
	{
		int num = Util.RecipeIdUnderMouse();
		if (num > 0)
		{
			Log.Debug("RecipeIdUnderMouse: " + num);
			mainLogic.OnAssemblerPickReturn(LDB.recipes.Select(num));
			return;
		}
		int num2 = Util.ItemIdHintUnderMouse();
		if (num2 > 0)
		{
			Log.Debug("ItemIdHintUnderMouse: " + num);
			mainLogic.OnStoragePickReturn(LDB.items.Select(num2));
			mainLogic.OnStationPickReturn(LDB.items.Select(num2));
		}
	}

	public void OnDestroy()
	{
		harmony.UnpatchSelf();
		if (mainWindow != null)
		{
			UnityEngine.Object.Destroy(mainWindow.gameObject);
			mainWindow = null;
		}
		UIentryCount.OnDestory();
	}
}
