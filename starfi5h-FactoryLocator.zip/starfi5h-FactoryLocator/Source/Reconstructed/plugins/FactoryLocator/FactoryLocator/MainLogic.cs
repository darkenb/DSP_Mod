using System;
using System.Collections.Generic;
using CommonAPI.Systems;
using FactoryLocator.UI;
using UnityEngine;

namespace FactoryLocator;

public class MainLogic
{
	private readonly List<PlanetFactory> factories = new List<PlanetFactory>();

	private readonly Dictionary<int, int> filterIds = new Dictionary<int, int>();

	private readonly Dictionary<int, Color> filterColors = new Dictionary<int, Color>();

	private readonly List<int> planetIds = new List<int>();

	private readonly List<Vector3> localPos = new List<Vector3>();

	private readonly List<int> detailIds = new List<int>();

	private int state;

	private readonly List<int> networkIds = new List<int>();

	private readonly HashSet<int> tmp_ids = new HashSet<int>();

	private bool isRecording;

	private readonly Dictionary<int, HashSet<long>> hashDict = new Dictionary<int, HashSet<long>>();

	private int tick;

	private Vector2 windowPos = new Vector2(-300f, 250f);

	private static readonly Color ORANGE = new Color(0.9906f, 0.5897f, 0.3691f, 0.7059f);

	private static readonly Color CYAN = new Color(0.2821f, 0.7455f, 1f, 0.7059f);

	private static readonly Color PINK = new Color(1f, 0.5f, 0.5f, 0.7059f);

	private const int SIGNAL_BPERROR = 404;

	private const int SIGNAL_NOSPRAY = 600;

	private const int SIGNAL_NOINPUTBELT = 601;

	private const int SIGNAL_NOOUTPUTBELT = 602;

	private const int SIGNAL_RR_CONTINUE = 503;

	private const int SIGNAL_RR_NOLENS = 508;

	public int SignalId { get; set; } = 401;

	public bool RecordRecipeSignal { get; set; } = true;

	public int SetFactories(StarData star, PlanetData planet)
	{
		state = 0;
		isRecording = false;
		factories.Clear();
		if (star != null)
		{
			PlanetData[] planets = star.planets;
			foreach (PlanetData planetData in planets)
			{
				if (planetData?.factory != null)
				{
					factories.Add(planetData.factory);
				}
			}
		}
		else if (planet?.factory != null)
		{
			factories.Add(planet.factory);
		}
		List<float> list = new List<float>();
		List<int> list2 = new List<int>();
		networkIds.Clear();
		foreach (PlanetFactory factory in factories)
		{
			if (factory.powerSystem == null)
			{
				continue;
			}
			for (int j = 1; j < factory.powerSystem.netCursor; j++)
			{
				PowerNetwork powerNetwork = factory.powerSystem.netPool[j];
				if (powerNetwork != null && powerNetwork.id == j)
				{
					list.Add((float)powerNetwork.consumerRatio);
					list2.Add(powerNetwork.consumers.Count);
					networkIds.Add(j);
				}
			}
		}
		UILocatorWindow mainWindow = Plugin.mainWindow;
		if ((object)mainWindow != null && mainWindow.active && Plugin.mainLogic == this)
		{
			Plugin.mainWindow.SetStatusTipText(list.ToArray(), list2.ToArray());
			Plugin.mainWindow.SetPowerNetworkDropdownList((factories.Count == 1) ? networkIds : null);
		}
		return factories.Count;
	}

	public void GameTick()
	{
		if (isRecording && UIRoot.instance.uiGame.signalPicker.active)
		{
			RecordAllSignal();
			if (tick++ > 30)
			{
				tick = 0;
				RecordToFilter();
				UIRoot.instance.uiGame.signalPicker.RefreshIcons();
				UIRoot.instance.uiGame.signalPicker.OnTypeButtonClick(UIRoot.instance.uiGame.signalPicker.currentType);
			}
		}
	}

	public void PickBuilding(int networkId)
	{
		state = networkId;
		RefreshBuilding(-1, state);
		UIentryCount.OnOpen(ESignalType.Item, filterIds);
		UIItemPickerExtension.Popup(windowPos, (Action<ItemProto>)OnBuildingPickReturn, (Func<ItemProto, bool>)((ItemProto itemProto) => filterIds.ContainsKey(itemProto.ID)));
		UIRoot.instance.uiGame.itemPicker.OnTypeButtonClick(2);
	}

	public void OnBuildingPickReturn(ItemProto itemProto)
	{
		windowPos = UIRoot.instance.uiGame.itemPicker.pickerTrans.anchoredPosition;
		if (itemProto != null)
		{
			int iD = itemProto.ID;
			RefreshBuilding(iD, state);
			WarningSystemPatch.AddWarningData(SignalId, iD, planetIds, localPos);
		}
	}

	public void PickVein(int mode)
	{
		state = mode;
		RefreshVein(-1, state);
		UIentryCount.OnOpen(ESignalType.Item, filterIds);
		UIItemPickerExtension.Popup(windowPos, (Action<ItemProto>)OnVeinPickReturn, true, (Func<ItemProto, bool>)((ItemProto itemProto) => filterIds.ContainsKey(itemProto.ID)));
		UIRoot.instance.uiGame.itemPicker.OnTypeButtonClick(1);
	}

	public void OnVeinPickReturn(ItemProto itemProto)
	{
		windowPos = UIRoot.instance.uiGame.itemPicker.pickerTrans.anchoredPosition;
		if (itemProto != null)
		{
			int iD = itemProto.ID;
			RefreshVein(iD, state);
			WarningSystemPatch.AddWarningData(SignalId, iD, planetIds, localPos);
		}
	}

	public void PickAssembler(int mode)
	{
		state = mode;
		RefreshAssemblers(-1, state);
		UIentryCount.OnOpen(ESignalType.Recipe, filterIds, filterColors);
		UIRecipePickerExtension.Popup(windowPos, (Action<RecipeProto>)OnAssemblerPickReturn, (Func<RecipeProto, bool>)((RecipeProto recipeProto) => filterIds.ContainsKey(recipeProto.ID)));
	}

	public void OnAssemblerPickReturn(RecipeProto recipeProto)
	{
		windowPos = UIRoot.instance.uiGame.recipePicker.pickerTrans.anchoredPosition;
		if (recipeProto != null)
		{
			int iD = recipeProto.ID;
			RefreshAssemblers(iD, state);
			WarningSystemPatch.AddWarningData(SignalId, SignalProtoSet.SignalId(ESignalType.Recipe, iD), planetIds, localPos);
		}
	}

	public void PickWarning(int mode)
	{
		state = mode;
		if (mode == 1)
		{
			isRecording = true;
			hashDict.Clear();
			Log.Debug("Start recording");
		}
		RefreshSignal(-1);
		UIentryCount.OnOpen(ESignalType.None, filterIds);
		UISignalPickerExtension.Popup(windowPos, (Action<int>)OnWarningPickReturn, (Func<int, bool>)((int signalId) => filterIds.ContainsKey(signalId)));
		UIRoot.instance.uiGame.signalPicker.OnTypeButtonClick(1);
	}

	public void OnWarningPickReturn(int signalId)
	{
		if (isRecording)
		{
			isRecording = false;
			Log.Debug("Stop recording");
		}
		windowPos = UIRoot.instance.uiGame.signalPicker.pickerTrans.anchoredPosition;
		if (signalId > 0)
		{
			if (state == 0)
			{
				RefreshSignal(signalId);
			}
			else if (state == 1)
			{
				RecordToResult(signalId);
				hashDict.Clear();
			}
			WarningSystemPatch.AddWarningData(SignalId, signalId, planetIds, localPos, detailIds);
		}
	}

	public void PickStorage(int mode)
	{
		state = mode;
		if (mode == 0)
		{
			RefreshStorage(-1);
		}
		else
		{
			RefreshDispenser(-1, state);
		}
		UIentryCount.OnOpen(ESignalType.Item, filterIds);
		UIItemPickerExtension.Popup(windowPos, (Action<ItemProto>)OnStoragePickReturn, (Func<ItemProto, bool>)((ItemProto itemProto) => filterIds.ContainsKey(itemProto.ID)));
	}

	public void OnStoragePickReturn(ItemProto itemProto)
	{
		windowPos = UIRoot.instance.uiGame.itemPicker.pickerTrans.anchoredPosition;
		if (itemProto != null)
		{
			int iD = itemProto.ID;
			if (state == 0)
			{
				RefreshStorage(iD);
			}
			else
			{
				RefreshDispenser(iD, state);
			}
			WarningSystemPatch.AddWarningData(SignalId, iD, planetIds, localPos);
		}
	}

	public void PickStation(int mode)
	{
		state = mode;
		RefreshStation(-1, state);
		UIentryCount.OnOpen(ESignalType.Item, filterIds);
		UIItemPickerExtension.Popup(windowPos, (Action<ItemProto>)OnStationPickReturn, (Func<ItemProto, bool>)((ItemProto itemProto) => filterIds.ContainsKey(itemProto.ID)));
	}

	public void OnStationPickReturn(ItemProto itemProto)
	{
		windowPos = UIRoot.instance.uiGame.itemPicker.pickerTrans.anchoredPosition;
		if (itemProto != null)
		{
			int iD = itemProto.ID;
			RefreshStation(iD, state);
			WarningSystemPatch.AddWarningData(SignalId, iD, planetIds, localPos);
		}
	}

	public void RefreshBuilding(int itemId, int comboIndex = 0)
	{
		filterIds.Clear();
		localPos.Clear();
		planetIds.Clear();
		foreach (PlanetFactory factory in factories)
		{
			for (int i = 1; i < factory.entityCursor; i++)
			{
				if (i != factory.entityPool[i].id)
				{
					continue;
				}
				ref EntityData reference = ref factory.entityPool[i];
				if (comboIndex != 0 && comboIndex <= networkIds.Count && networkIds[comboIndex - 1] != GetPowerNetworkId(factory, in reference))
				{
					continue;
				}
				if (itemId == -1)
				{
					int protoId = reference.protoId;
					if (filterIds.ContainsKey(protoId))
					{
						Dictionary<int, int> dictionary = filterIds;
						int key = protoId;
						int value = dictionary[key] + 1;
						dictionary[key] = value;
					}
					else
					{
						filterIds[protoId] = 1;
					}
				}
				else if (itemId == reference.protoId)
				{
					localPos.Add(reference.pos + reference.pos.normalized * 0.5f);
					planetIds.Add(factory.planetId);
				}
			}
		}
	}

	private static bool IsLiveEntity(PlanetFactory factory, int id)
	{
		if (id > 0 && id < factory.entityPool.Length)
		{
			return factory.entityPool[id].id == id;
		}
		return false;
	}

	public static int GetPowerNetworkId(PlanetFactory factory, in EntityData entity)
	{
		if (entity.powerConId > 0)
		{
			return factory.powerSystem.consumerPool[entity.powerConId].networkId;
		}
		if (entity.powerNodeId > 0)
		{
			return factory.powerSystem.nodePool[entity.powerNodeId].networkId;
		}
		if (entity.powerGenId > 0)
		{
			return factory.powerSystem.genPool[entity.powerGenId].networkId;
		}
		if (entity.powerExcId > 0)
		{
			return factory.powerSystem.excPool[entity.powerExcId].networkId;
		}
		if (entity.powerAccId > 0)
		{
			return factory.powerSystem.accPool[entity.powerAccId].networkId;
		}
		return 0;
	}

	public void RefreshVein(int itemId, int mode = 0)
	{
		filterIds.Clear();
		localPos.Clear();
		planetIds.Clear();
		EVeinType eVeinType = EVeinType.None;
		if (itemId > 0)
		{
			eVeinType = LDB.veins.GetVeinTypeByItemId(itemId);
		}
		foreach (PlanetFactory factory in factories)
		{
			if (mode != 0)
			{
				tmp_ids.Clear();
				for (int i = 1; i < factory.veinPool.Length; i++)
				{
					if (factory.veinPool[i].id == i && factory.veinPool[i].minerCount != 0)
					{
						tmp_ids.Add(factory.veinPool[i].groupIndex);
					}
				}
			}
			for (int j = 1; j < factory.veinGroups.Length; j++)
			{
				if (factory.veinGroups[j].type == EVeinType.None || (mode == 1 && !tmp_ids.Contains(j)) || (mode == 2 && tmp_ids.Contains(j)))
				{
					continue;
				}
				if (itemId == -1)
				{
					int num = ((factory.veinGroups[j].type != EVeinType.Oil) ? LDB.veins.Select((int)factory.veinGroups[j].type).MiningItem : 1007);
					if (filterIds.ContainsKey(num))
					{
						Dictionary<int, int> dictionary = filterIds;
						int key = num;
						int value = dictionary[key] + 1;
						dictionary[key] = value;
					}
					else
					{
						filterIds[num] = 1;
					}
				}
				else if (eVeinType == factory.veinGroups[j].type)
				{
					localPos.Add(factory.veinGroups[j].pos.normalized * (factory.planet.realRadius + 0.5f));
					planetIds.Add(factory.planetId);
				}
			}
		}
	}

	public void RefreshAssemblers(int recipeId, int mode = 0)
	{
		filterIds.Clear();
		filterColors.Clear();
		localPos.Clear();
		planetIds.Clear();
		foreach (PlanetFactory factory in factories)
		{
			for (int i = 1; i < factory.factorySystem.assemblerCursor; i++)
			{
				ref AssemblerComponent reference = ref factory.factorySystem.assemblerPool[i];
				if (i != reference.id || !IsLiveEntity(factory, reference.entityId) || reference.recipeId <= 0 || (mode >= 3 && mode != GetAssemblerWorkingStatus(in reference)))
				{
					continue;
				}
				RecipeExecuteData recipeExecuteData = reference.recipeExecuteData;
				if (recipeExecuteData != null && recipeExecuteData.productive && !reference.forceAccMode)
				{
					if (mode == 2)
					{
						continue;
					}
					if (filterColors.TryGetValue(reference.recipeId, out var value) && value != CYAN)
					{
						filterColors[reference.recipeId] = PINK;
					}
					else
					{
						filterColors[reference.recipeId] = CYAN;
					}
				}
				else
				{
					if (mode == 1)
					{
						continue;
					}
					if (filterColors.TryGetValue(reference.recipeId, out var value2) && value2 != ORANGE)
					{
						filterColors[reference.recipeId] = PINK;
					}
					else
					{
						filterColors[reference.recipeId] = ORANGE;
					}
				}
				if (recipeId == -1)
				{
					int recipeId2 = reference.recipeId;
					if (filterIds.ContainsKey(recipeId2))
					{
						Dictionary<int, int> dictionary = filterIds;
						int key = recipeId2;
						int value3 = dictionary[key] + 1;
						dictionary[key] = value3;
					}
					else
					{
						filterIds[recipeId2] = 1;
					}
				}
				else if (recipeId == reference.recipeId)
				{
					ref EntityData reference2 = ref factory.entityPool[reference.entityId];
					localPos.Add(reference2.pos + reference2.pos.normalized * 0.5f);
					planetIds.Add(factory.planetId);
				}
			}
			for (int j = 1; j < factory.factorySystem.labCursor; j++)
			{
				ref LabComponent reference3 = ref factory.factorySystem.labPool[j];
				if (j != reference3.id || !IsLiveEntity(factory, reference3.entityId) || reference3.recipeId <= 0 || (mode >= 3 && mode != GetLabWorkingStatus(in reference3)))
				{
					continue;
				}
				RecipeExecuteData recipeExecuteData2 = reference3.recipeExecuteData;
				if (recipeExecuteData2 != null && recipeExecuteData2.productive && !reference3.forceAccMode)
				{
					if (mode == 2)
					{
						continue;
					}
					if (filterColors.TryGetValue(reference3.recipeId, out var value4) && value4 != CYAN)
					{
						filterColors[reference3.recipeId] = PINK;
					}
					else
					{
						filterColors[reference3.recipeId] = CYAN;
					}
				}
				else
				{
					if (mode == 1)
					{
						continue;
					}
					if (filterColors.TryGetValue(reference3.recipeId, out var value5) && value5 != ORANGE)
					{
						filterColors[reference3.recipeId] = PINK;
					}
					else
					{
						filterColors[reference3.recipeId] = ORANGE;
					}
				}
				if (recipeId == -1)
				{
					int recipeId3 = reference3.recipeId;
					if (filterIds.ContainsKey(recipeId3))
					{
						Dictionary<int, int> dictionary2 = filterIds;
						int value3 = recipeId3;
						int key = dictionary2[value3] + 1;
						dictionary2[value3] = key;
					}
					else
					{
						filterIds[recipeId3] = 1;
					}
				}
				else if (recipeId == reference3.recipeId)
				{
					ref EntityData reference4 = ref factory.entityPool[reference3.entityId];
					localPos.Add(reference4.pos + reference4.pos.normalized * 0.5f);
					planetIds.Add(factory.planetId);
				}
			}
		}
	}

	public static int GetAssemblerWorkingStatus(in AssemblerComponent assembler)
	{
		if (assembler.replicating)
		{
			return 0;
		}
		if (assembler.recipeExecuteData == null)
		{
			return -1;
		}
		if (assembler.time >= assembler.recipeExecuteData.timeSpend)
		{
			return 4;
		}
		for (int i = 0; i < assembler.recipeExecuteData.requireCounts.Length; i++)
		{
			if (assembler.served[i] < assembler.recipeExecuteData.requireCounts[i])
			{
				return 3;
			}
		}
		return -1;
	}

	public static int GetLabWorkingStatus(in LabComponent lab)
	{
		if (lab.replicating)
		{
			return 0;
		}
		if (lab.recipeExecuteData == null)
		{
			return -1;
		}
		if (lab.time >= lab.recipeExecuteData.timeSpend)
		{
			return 4;
		}
		for (int i = 0; i < lab.recipeExecuteData.requireCounts.Length; i++)
		{
			if (lab.served[i] < lab.recipeExecuteData.requireCounts[i])
			{
				return 3;
			}
		}
		return -1;
	}

	public void RefreshSignal(int signalId)
	{
		filterIds.Clear();
		localPos.Clear();
		planetIds.Clear();
		detailIds.Clear();
		foreach (PlanetFactory factory in factories)
		{
			int entityCursor = factory.entityCursor;
			for (int i = 1; i < entityCursor; i++)
			{
				if (i != factory.entityPool[i].id)
				{
					continue;
				}
				if (signalId == -1)
				{
					if (factory.entitySignPool[i].signType != 0)
					{
						int num = (int)(factory.entitySignPool[i].signType + 500);
						if (filterIds.ContainsKey(num))
						{
							Dictionary<int, int> dictionary = filterIds;
							int key = num;
							int value = dictionary[key] + 1;
							dictionary[key] = value;
						}
						else
						{
							filterIds[num] = 1;
						}
					}
				}
				else if (signalId == (int)(factory.entitySignPool[i].signType + 500))
				{
					localPos.Add(factory.entityPool[i].pos + factory.entityPool[i].pos.normalized * 0.5f);
					detailIds.Add(factory.entityPool[i].protoId);
					planetIds.Add(factory.planetId);
				}
			}
			entityCursor = factory.cargoTraffic.spraycoaterCursor;
			for (int j = 1; j < entityCursor; j++)
			{
				ref SpraycoaterComponent reference = ref factory.cargoTraffic.spraycoaterPool[j];
				if (j != reference.id)
				{
					continue;
				}
				int num2 = 0;
				if (reference.incBeltId == 0)
				{
					num2 = 601;
				}
				else if (reference.cargoBeltId == 0)
				{
					num2 = 602;
				}
				else if (reference.incCount == 0)
				{
					num2 = 600;
				}
				if (num2 == 0)
				{
					continue;
				}
				if (signalId == -1)
				{
					if (filterIds.ContainsKey(num2))
					{
						Dictionary<int, int> dictionary2 = filterIds;
						int value = num2;
						int key = dictionary2[value] + 1;
						dictionary2[value] = key;
					}
					else
					{
						filterIds[num2] = 1;
					}
				}
				else if (signalId == num2)
				{
					ref EntityData reference2 = ref factory.entityPool[reference.entityId];
					localPos.Add(reference2.pos + reference2.pos.normalized * 0.5f);
					detailIds.Add(reference2.protoId);
					planetIds.Add(factory.planetId);
				}
			}
			entityCursor = factory.powerSystem.genCursor;
			for (int k = 1; k < entityCursor; k++)
			{
				ref PowerGeneratorComponent reference3 = ref factory.powerSystem.genPool[k];
				if (k != reference3.id || !reference3.gamma)
				{
					continue;
				}
				int num3 = 0;
				if (reference3.catalystPoint == 0)
				{
					num3 = 508;
				}
				else if (reference3.warmup < 0.999f)
				{
					num3 = 503;
				}
				if (num3 == 0)
				{
					continue;
				}
				if (signalId == -1)
				{
					if (filterIds.ContainsKey(num3))
					{
						Dictionary<int, int> dictionary3 = filterIds;
						int key = num3;
						int value = dictionary3[key] + 1;
						dictionary3[key] = value;
					}
					else
					{
						filterIds[num3] = 1;
					}
				}
				else if (signalId == num3)
				{
					ref EntityData reference4 = ref factory.entityPool[reference3.entityId];
					localPos.Add(reference4.pos + reference4.pos.normalized * 0.5f);
					detailIds.Add(reference4.protoId);
					planetIds.Add(factory.planetId);
				}
			}
		}
		if (factories.Count != 1 || factories[0] != GameMain.localPlanet?.factory)
		{
			return;
		}
		BuildTool_BlueprintPaste buildTool_BlueprintPaste = GameMain.mainPlayer?.controller?.actionBuild?.blueprintPasteTool;
		if (buildTool_BlueprintPaste == null)
		{
			return;
		}
		int id = GameMain.localPlanet.id;
		for (int l = 0; l < buildTool_BlueprintPaste.bpCursor; l++)
		{
			BuildPreview buildPreview = buildTool_BlueprintPaste.bpPool[l];
			if (buildPreview.condition == EBuildCondition.Ok || buildPreview.condition == EBuildCondition.NotEnoughItem)
			{
				continue;
			}
			int num4 = 404;
			if (signalId == -1)
			{
				if (filterIds.ContainsKey(num4))
				{
					Dictionary<int, int> dictionary4 = filterIds;
					int value = num4;
					int key = dictionary4[value] + 1;
					dictionary4[value] = key;
				}
				else
				{
					filterIds[num4] = 1;
				}
			}
			else if (signalId == num4)
			{
				localPos.Add(buildPreview.lpos);
				detailIds.Add(buildPreview.item?.ID ?? 0);
				planetIds.Add(id);
			}
		}
	}

	public void RecordAllSignal()
	{
		foreach (PlanetFactory factory in factories)
		{
			int entityCursor = factory.entityCursor;
			for (int i = 1; i < entityCursor; i++)
			{
				ref SignData reference = ref factory.entitySignPool[i];
				if (reference.signType == 0)
				{
					continue;
				}
				int key = (int)(reference.signType + 500);
				long value = ((long)factory.index << 32) | i;
				if (!TryAddHash(key, value) || reference.iconId0 == 0 || !RecordRecipeSignal || reference.iconType >= 3)
				{
					continue;
				}
				if (reference.iconType == 2)
				{
					int iconId = (int)reference.iconId0;
					RecipeProto recipeProto = LDB.recipes.Select(iconId);
					if (recipeProto != null)
					{
						if (recipeProto.hasIcon)
						{
							key = SignalProtoSet.SignalId(ESignalType.Recipe, iconId);
							TryAddHash(key, value);
						}
						else if (recipeProto.Results.Length != 0)
						{
							key = SignalProtoSet.SignalId(ESignalType.Item, recipeProto.Results[0]);
							TryAddHash(key, value);
						}
					}
				}
				else
				{
					key = SignalProtoSet.SignalId(ESignalType.Item, (int)reference.iconId0);
					TryAddHash(key, value);
				}
			}
			entityCursor = factory.cargoTraffic.spraycoaterCursor;
			for (int j = 1; j < entityCursor; j++)
			{
				ref SpraycoaterComponent reference2 = ref factory.cargoTraffic.spraycoaterPool[j];
				if (j == reference2.id)
				{
					int num = 0;
					if (reference2.incBeltId == 0)
					{
						num = 601;
					}
					else if (reference2.cargoBeltId == 0)
					{
						num = 602;
					}
					else if (reference2.incCount == 0)
					{
						num = 600;
					}
					if (num != 0)
					{
						long value2 = ((long)factory.index << 32) | reference2.entityId;
						TryAddHash(num, value2);
					}
				}
			}
		}
		bool TryAddHash(int key2, long item)
		{
			if (!hashDict.TryGetValue(key2, out var value3))
			{
				value3 = new HashSet<long>();
				hashDict.Add(key2, value3);
			}
			return value3.Add(item);
		}
	}

	public void RecordToFilter()
	{
		filterIds.Clear();
		foreach (KeyValuePair<int, HashSet<long>> item in hashDict)
		{
			filterIds[item.Key] = item.Value.Count;
		}
	}

	public void RecordToResult(int signalId)
	{
		localPos.Clear();
		planetIds.Clear();
		detailIds.Clear();
		if (!hashDict.TryGetValue(signalId, out var value))
		{
			return;
		}
		foreach (long item in value)
		{
			int num = (int)(item >> 32);
			int num2 = (int)(item & 0xFFFFFFFFu);
			PlanetFactory planetFactory = GameMain.data.factories[num];
			if (planetFactory != null && num2 < planetFactory.entityCursor)
			{
				ref EntityData reference = ref planetFactory.entityPool[num2];
				localPos.Add(reference.pos + reference.pos.normalized * 0.5f);
				detailIds.Add(reference.protoId);
				planetIds.Add(planetFactory.planetId);
			}
		}
	}

	public void RefreshStorage(int itemId)
	{
		filterIds.Clear();
		localPos.Clear();
		planetIds.Clear();
		foreach (PlanetFactory factory in factories)
		{
			for (int i = 1; i < factory.factoryStorage.storageCursor; i++)
			{
				StorageComponent storageComponent = factory.factoryStorage.storagePool[i];
				if (storageComponent == null || storageComponent.id != i)
				{
					continue;
				}
				if (itemId == -1)
				{
					for (int j = 0; j < storageComponent.size; j++)
					{
						if (storageComponent.grids[j].count > 0)
						{
							int itemId2 = storageComponent.grids[j].itemId;
							if (!filterIds.ContainsKey(itemId2))
							{
								filterIds[itemId2] = storageComponent.grids[j].count;
							}
							else
							{
								filterIds[itemId2] += storageComponent.grids[j].count;
							}
						}
					}
					continue;
				}
				bool flag = false;
				for (int k = 0; k < storageComponent.size; k++)
				{
					if (storageComponent.grids[k].itemId == itemId && storageComponent.grids[k].count > 0)
					{
						ref EntityData reference = ref factory.entityPool[storageComponent.entityId];
						localPos.Add(reference.pos + reference.pos.normalized * 0.5f);
						planetIds.Add(factory.planetId);
						flag = true;
					}
					if (flag)
					{
						break;
					}
				}
			}
			for (int l = 1; l < factory.factoryStorage.tankCursor; l++)
			{
				ref TankComponent reference2 = ref factory.factoryStorage.tankPool[l];
				if (reference2.id != l)
				{
					continue;
				}
				if (itemId == -1)
				{
					int fluidId = reference2.fluidId;
					if (filterIds.ContainsKey(fluidId))
					{
						filterIds[fluidId] += reference2.fluidCount;
					}
					else
					{
						filterIds[fluidId] = reference2.fluidCount;
					}
				}
				else if (itemId == reference2.fluidId)
				{
					ref EntityData reference3 = ref factory.entityPool[reference2.entityId];
					localPos.Add(reference3.pos + reference3.pos.normalized * 0.5f);
					planetIds.Add(factory.planetId);
				}
			}
		}
	}

	public void RefreshDispenser(int itemId, int mode = 0)
	{
		filterIds.Clear();
		localPos.Clear();
		planetIds.Clear();
		foreach (PlanetFactory factory in factories)
		{
			for (int i = 1; i < factory.transport.dispenserCursor; i++)
			{
				DispenserComponent dispenserComponent = factory.transport.dispenserPool[i];
				if (dispenserComponent == null || dispenserComponent.id != i || dispenserComponent.storage == null)
				{
					continue;
				}
				switch (mode)
				{
				case 1:
					if (dispenserComponent.storageMode != EStorageDeliveryMode.Demand)
					{
						continue;
					}
					break;
				case 2:
					if (dispenserComponent.storageMode != EStorageDeliveryMode.Supply)
					{
						continue;
					}
					break;
				}
				if (itemId == -1)
				{
					if (!filterIds.ContainsKey(dispenserComponent.filter))
					{
						filterIds[dispenserComponent.filter] = 0;
					}
					int num = 0;
					StorageComponent storageComponent = dispenserComponent.storage.topStorage;
					while (storageComponent != null)
					{
						for (int j = 0; j < storageComponent.size; j++)
						{
							if (storageComponent.grids[j].itemId <= 0)
							{
								continue;
							}
							int itemId2 = storageComponent.grids[j].itemId;
							if (itemId2 == dispenserComponent.filter)
							{
								if (!filterIds.ContainsKey(itemId2))
								{
									filterIds[itemId2] = storageComponent.grids[j].count;
								}
								else
								{
									filterIds[itemId2] += storageComponent.grids[j].count;
								}
							}
						}
						storageComponent = storageComponent.previousStorage;
						if (num++ > 50)
						{
							break;
						}
					}
				}
				else if (dispenserComponent.filter == itemId)
				{
					ref EntityData reference = ref factory.entityPool[dispenserComponent.entityId];
					localPos.Add(reference.pos + reference.pos.normalized * 0.5f);
					planetIds.Add(factory.planetId);
				}
			}
		}
	}

	public void RefreshStation(int itemId, int mode = 0)
	{
		filterIds.Clear();
		localPos.Clear();
		planetIds.Clear();
		foreach (PlanetFactory factory in factories)
		{
			for (int i = 1; i < factory.transport.stationCursor; i++)
			{
				StationComponent stationComponent = factory.transport.stationPool[i];
				if (stationComponent == null || stationComponent.id != i || stationComponent.storage == null)
				{
					continue;
				}
				switch (mode)
				{
				case 1:
					if (stationComponent.gid > 0)
					{
						continue;
					}
					break;
				case 2:
					if (stationComponent.gid <= 0)
					{
						continue;
					}
					break;
				}
				if (itemId == -1)
				{
					for (int j = 0; j < stationComponent.storage.Length; j++)
					{
						if (TestStationStore(in stationComponent.storage[j], mode))
						{
							int itemId2 = stationComponent.storage[j].itemId;
							if (filterIds.ContainsKey(itemId2))
							{
								filterIds[itemId2] += stationComponent.storage[j].count;
							}
							else
							{
								filterIds[itemId2] = stationComponent.storage[j].count;
							}
						}
					}
					continue;
				}
				bool flag = false;
				for (int k = 0; k < stationComponent.storage.Length; k++)
				{
					if (stationComponent.storage[k].itemId == itemId && TestStationStore(in stationComponent.storage[k], mode))
					{
						ref EntityData reference = ref factory.entityPool[stationComponent.entityId];
						localPos.Add(reference.pos + reference.pos.normalized * 0.5f);
						planetIds.Add(factory.planetId);
						flag = true;
					}
					if (flag)
					{
						break;
					}
				}
			}
		}
	}

	public static bool TestStationStore(in StationStore store, int mode)
	{
		return mode switch
		{
			3 => store.localLogic == ELogisticStorage.Demand, 
			4 => store.localLogic == ELogisticStorage.Supply, 
			5 => store.remoteLogic == ELogisticStorage.Demand, 
			6 => store.remoteLogic == ELogisticStorage.Supply, 
			_ => true, 
		};
	}
}
