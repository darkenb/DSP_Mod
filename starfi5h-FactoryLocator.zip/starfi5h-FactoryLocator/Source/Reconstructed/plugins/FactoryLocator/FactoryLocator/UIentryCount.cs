using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace FactoryLocator;

public class UIentryCount
{
	private static Dictionary<int, int> filterIds;

	private static Dictionary<int, Color> colorMap;

	private static Text[] countArray;

	private const int ARRAYLENGTH = 112;

	public static int ItemCol { get; set; } = 14;

	public static int RecipeCol { get; set; } = 14;

	public static int SignalCol { get; set; } = 14;

	public static bool Active { get; private set; }

	public static void OnOpen(ESignalType signalType, Dictionary<int, int> filters, Dictionary<int, Color> numberColors = null)
	{
		filterIds = filters;
		colorMap = numberColors;
		if (countArray == null)
		{
			countArray = new Text[112];
		}
		for (int i = 0; i < 112; i++)
		{
			Init(ref countArray[i], signalType, i);
		}
		Active = true;
		UIItemPicker.showAll = true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIItemPicker), "_OnClose")]
	[HarmonyPatch(typeof(UIRecipePicker), "_OnClose")]
	[HarmonyPatch(typeof(UISignalPicker), "_OnClose")]
	public static void OnClose()
	{
		if (Active && countArray != null)
		{
			Color color = UIRoot.instance.uiGame.warningWindow.itemPrefab.countText.color;
			for (int i = 0; i < 112; i++)
			{
				countArray[i].gameObject.SetActive(value: false);
				countArray[i].color = color;
			}
		}
		Active = false;
		colorMap = null;
	}

	public static void OnDestory()
	{
		if (countArray != null)
		{
			for (int i = 0; i < 112; i++)
			{
				UnityEngine.Object.DestroyImmediate(countArray[i]);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIItemPicker), "OnTypeButtonClick")]
	private static void OnTypeButtonClick1(UIItemPicker __instance)
	{
		if (Active && countArray != null)
		{
			for (int i = 0; i < 112; i++)
			{
				int protoId = __instance.protoArray[i]?.ID ?? (-1);
				SetNumber(countArray[i], protoId);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIRecipePicker), "OnTypeButtonClick")]
	private static void OnTypeButtonClick2(UIRecipePicker __instance)
	{
		if (Active && countArray != null)
		{
			for (int i = 0; i < 112; i++)
			{
				int protoId = __instance.protoArray[i]?.ID ?? (-1);
				SetNumber(countArray[i], protoId);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UISignalPicker), "OnTypeButtonClick")]
	private static void OnTypeButtonClick3(UISignalPicker __instance)
	{
		if (Active && countArray != null)
		{
			for (int i = 0; i < 112; i++)
			{
				int protoId = __instance.signalArray[i];
				SetNumber(countArray[i], protoId);
			}
		}
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(UISignalPicker), "_OnUpdate")]
	public static IEnumerable<CodeInstruction> UISignalPicker_OnUpdate_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			return new CodeMatcher(instructions).End().MatchBack(false, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Call && ((MethodInfo)i.operand).Name == "_Close")).SetAndAdvance(OpCodes.Nop, null)
				.SetAndAdvance(OpCodes.Nop, null)
				.InstructionEnumeration();
		}
		catch (Exception obj)
		{
			Log.Warn("Transpiler UISignalPicker._OnUpdate error");
			Log.Warn(obj);
			return instructions;
		}
	}

	public static void Init(ref Text text, ESignalType signalType, int index)
	{
		if (text == null)
		{
			text = UnityEngine.Object.Instantiate(UIRoot.instance.uiGame.warningWindow.itemPrefab.countText);
		}
		switch (signalType)
		{
		case ESignalType.Item:
			text.gameObject.transform.SetParent(UIRoot.instance.uiGame.itemPicker.iconImage.transform);
			break;
		case ESignalType.Recipe:
			text.gameObject.transform.SetParent(UIRoot.instance.uiGame.recipePicker.iconImage.transform);
			break;
		case ESignalType.None:
			text.gameObject.transform.SetParent(UIRoot.instance.uiGame.signalPicker.iconImage.transform);
			break;
		}
		text.gameObject.transform.localScale = Vector3.one;
		text.text = "";
		SetPosition(text, index, signalType);
	}

	private static void SetPosition(Text text, int hoveredIndex, ESignalType signalType)
	{
		int num = 14;
		switch (signalType)
		{
		case ESignalType.Item:
			num = ItemCol;
			break;
		case ESignalType.Recipe:
			num = RecipeCol;
			break;
		case ESignalType.None:
			num = SignalCol;
			break;
		}
		int num2 = hoveredIndex % num;
		int num3 = hoveredIndex / num;
		text.rectTransform.localPosition = new Vector2(num2 * 46 + 41, -num3 * 46 - 15);
	}

	private static void SetNumber(Text text, int protoId)
	{
		if (filterIds.TryGetValue(protoId, out var value))
		{
			text.gameObject.SetActive(value: true);
			if (value < 10000)
			{
				text.text = value.ToString();
			}
			else if (value < 10000000)
			{
				text.text = $"{(float)value / 1000f:F1}K";
			}
			else
			{
				text.text = $"{(float)value / 1000f / 1000f:F1}M";
			}
		}
		else
		{
			text.gameObject.SetActive(value: false);
		}
		if (colorMap != null && colorMap.TryGetValue(protoId, out var value2))
		{
			text.color = value2;
		}
	}
}
