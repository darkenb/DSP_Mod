using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyFileVersion("1.3.15")]
[assembly: AssemblyInformationalVersion("1.3.15")]
[assembly: AssemblyProduct("FactoryLocator")]
[assembly: AssemblyTitle("FactoryLocator")]
[assembly: AssemblyVersion("1.3.13.0")]
[module: RefSafetyRules(11)]
