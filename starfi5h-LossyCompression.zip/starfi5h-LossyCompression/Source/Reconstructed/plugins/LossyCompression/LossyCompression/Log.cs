using BepInEx.Logging;

namespace LossyCompression;

public static class Log
{
	public static ManualLogSource LogSource;

	public static void Error(object obj)
	{
		LogSource.LogError(obj);
	}

	public static void Warn(object obj)
	{
		LogSource.LogWarning(obj);
	}

	public static void Info(object obj)
	{
		LogSource.LogInfo(obj);
	}

	public static void Debug(object obj)
	{
		LogSource.LogDebug(obj);
	}
}
