using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Threading.Tasks;
using BepInEx;
using HarmonyLib;

namespace LossyCompression;

internal class DysonSwarmCompress
{
	public static readonly int EncodedVersion = 1;

	private const int DIVISION = 350;

	public static bool Enable { get; set; }

	public static bool IsMultithread { get; set; }

	public static void Export(BinaryWriter w)
	{
		if (!Enable)
		{
			w.Write(0);
			return;
		}
		HighStopwatch highStopwatch = new HighStopwatch();
		highStopwatch.Begin();
		long num = -w.BaseStream.Length;
		w.Write(EncodedVersion);
		w.Write(GameMain.data.dysonSpheres.Length);
		for (int i = 0; i < GameMain.data.dysonSpheres.Length; i++)
		{
			if (GameMain.data.dysonSpheres[i] != null)
			{
				w.Write(i);
				Encode(GameMain.data.dysonSpheres[i], w);
			}
			else
			{
				w.Write(-1);
			}
		}
		num += w.BaseStream.Length;
		PerformanceMonitor.dataLengths[1] += num;
		PerformanceMonitor.dataLengths[33] += num;
		PerformanceMonitor.dataLengths[34] += num;
		Log.Info($"Compress DysonSwarm: {num:N0} bytes {highStopwatch.duration}s");
	}

	public static void Import(BinaryReader r)
	{
		int num = r.ReadInt32();
		if (num == 0 || num != EncodedVersion)
		{
			return;
		}
		long num2 = -r.BaseStream.Length;
		HighStopwatch highStopwatch = new HighStopwatch();
		highStopwatch.Begin();
		int num3 = r.ReadInt32();
		Assert.True(num3 == GameMain.data.dysonSpheres.Length);
		for (int i = 0; i < num3; i++)
		{
			int num4 = r.ReadInt32();
			if (num4 != -1)
			{
				Decode(GameMain.data.dysonSpheres[num4], r, GameMain.gameTick);
			}
		}
		num2 += r.BaseStream.Length;
		PerformanceMonitor.dataLengths[1] += num2;
		PerformanceMonitor.dataLengths[33] += num2;
		PerformanceMonitor.dataLengths[37] += num2;
		Log.Info($"Decompress DysonSwarm: {num2:N0} bytes {highStopwatch.duration}s");
	}

	public static void Encode(DysonSphere dysonSphere, BinaryWriter w)
	{
		ExpiryOrder[] expiryOrder = dysonSphere.swarm.expiryOrder;
		long num = (long)(GameMain.history.solarSailLife * 60f / 350f);
		long gameTick = GameMain.gameTick;
		int[] array = new int[351];
		for (int i = 0; i < expiryOrder.Length; i++)
		{
			if (expiryOrder[i].index != 0 || expiryOrder[i].time != 0L)
			{
				int num2 = (int)((expiryOrder[i].time - gameTick) / num);
				if (num2 > 350)
				{
					num2 = 350;
				}
				else if (num2 < 0)
				{
					num2 = 0;
				}
				array[num2]++;
			}
		}
		int num3 = dysonSphere.swarm.absorbEnding - dysonSphere.swarm.absorbCursor;
		if (num3 < 0)
		{
			num3 += dysonSphere.swarm.sailCapacity;
		}
		w.Write(array.Length);
		for (int j = 0; j < array.Length; j++)
		{
			w.Write(array[j]);
		}
		w.Write(num3);
	}

	public static void Decode(DysonSphere dysonSphere, BinaryReader r, long time)
	{
		HighStopwatch highStopwatch = new HighStopwatch();
		DysonSwarm dysonSwarm = dysonSphere.swarm;
		long num = 0L;
		int[] array = new int[r.ReadInt32() + 1];
		for (int i = 0; i < array.Length; i++)
		{
			array[i] = r.ReadInt32();
			num += array[i];
		}
		if (num == 0L)
		{
			return;
		}
		RemoveSailsByOrbit_NoSync(dysonSwarm, -1);
		int num2;
		for (num2 = 512; num2 <= num; num2 *= 2)
		{
		}
		dysonSwarm.SetSailCapacity(num2);
		dysonSwarm.sailPoolForSave = new DysonSail[num2];
		List<int> activeOrbitIds = new List<int>();
		for (int j = 1; j < dysonSwarm.orbitCursor; j++)
		{
			if (dysonSwarm.orbits[j].id == j && dysonSwarm.orbits[j].enabled)
			{
				activeOrbitIds.Add(j);
			}
		}
		if (activeOrbitIds.Count == 0)
		{
			activeOrbitIds.Add(1);
		}
		dysonSwarm.sailCursor = 0;
		dysonSwarm.sailRecycleCursor = 0;
		dysonSwarm.expiryEnding = 0;
		dysonSwarm.expiryCursor = 0;
		long num3 = (long)(GameMain.history.solarSailLife * 60f);
		long num4 = (long)(GameMain.history.solarSailLife * 60f / 350f);
		for (int k = 0; k < array.Length; k++)
		{
			long num5 = num4 * (k + 1);
			if (num5 > num3)
			{
				num5 = num3;
			}
			long num6 = time + num5;
			for (int l = 0; l < array[k]; l++)
			{
				dysonSwarm.expiryOrder[dysonSwarm.expiryEnding].time = num6;
				dysonSwarm.expiryOrder[dysonSwarm.expiryEnding].index = dysonSwarm.sailCursor;
				dysonSwarm.sailInfos[dysonSwarm.sailCursor].kill = (uint)(num6 & 0xFFFFFFFFu);
				dysonSwarm.sailInfos[dysonSwarm.sailCursor].orbit = (uint)activeOrbitIds[dysonSwarm.sailCursor % activeOrbitIds.Count];
				dysonSwarm.expiryEnding++;
				dysonSwarm.sailCursor++;
			}
		}
		highStopwatch.Begin();
		if (!IsMultithread || dysonSwarm.sailCursor < 1000)
		{
			GenerateSails(dysonSwarm, 0, dysonSwarm.sailCursor, activeOrbitIds);
		}
		else
		{
			int processorCount = Environment.ProcessorCount;
			int num7 = dysonSwarm.sailCursor / processorCount;
			Task[] array2 = new Task[processorCount - 1];
			for (int m = 0; m < processorCount - 1; m++)
			{
				int startIndex = num7 * m;
				int endIndex = num7 * (m + 1);
				array2[m] = Task.Run(delegate
				{
					GenerateSails(dysonSwarm, startIndex, endIndex, activeOrbitIds);
				});
			}
			GenerateSails(dysonSwarm, num7 * (processorCount - 1), dysonSwarm.sailCursor, activeOrbitIds);
			Task.WaitAll(array2);
		}
		dysonSwarm.swarmBuffer.SetData(dysonSwarm.sailPoolForSave, 0, 0, dysonSwarm.sailCursor);
		dysonSwarm.swarmInfoBuffer.SetData(dysonSwarm.sailInfos, 0, 0, dysonSwarm.sailCursor);
		Log.Debug($"[{dysonSphere.starData.index,2}] Generate {dysonSwarm.sailCursor:N0} sails. Time:{highStopwatch.duration} s");
	}

	public static void GenerateSails(DysonSwarm dysonSwarm, int startIndex, int endIndex, List<int> activeOrbitIds)
	{
		int seed = dysonSwarm.autoConstructSeed + startIndex;
		int seed2 = dysonSwarm.randSeed + startIndex * 3;
		float gravity = dysonSwarm.dysonSphere.gravity;
		for (int i = startIndex; i < endIndex; i++)
		{
			int num = activeOrbitIds[i % activeOrbitIds.Count];
			ref SailOrbit reference = ref dysonSwarm.orbits[num];
			ref DysonSail reference2 = ref dysonSwarm.sailPoolForSave[i];
			VectorLF3 a = VectorLF3.Cross(reference.up, RandomTable.SphericNormal(ref seed, 1.0)).normalized * reference.radius;
			a += RandomTable.SphericNormal(ref seed2, 200.0);
			reference2.st = num;
			reference2.px = (float)a.x;
			reference2.py = (float)a.y;
			reference2.pz = (float)a.z;
			a = VectorLF3.Cross(a, reference.up).normalized * Math.Sqrt(gravity / reference.radius);
			a += RandomTable.SphericNormal(ref seed2, 0.6000000238418579);
			a += RandomTable.SphericNormal(ref seed2, 0.5);
			reference2.vx = (float)a.x;
			reference2.vy = (float)a.y;
			reference2.vz = (float)a.z;
			reference2.gs = 1f;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSwarm), "Export")]
	public static bool DysonSwarm_Export_Prefix(DysonSwarm __instance, BinaryWriter w)
	{
		if (!Enable)
		{
			return true;
		}
		if (ThreadingHelper.Instance.InvokeRequired)
		{
			return false;
		}
		int sailCapacity = __instance.sailCapacity;
		int sailCursor = __instance.sailCursor;
		int sailRecycleCursor = __instance.sailRecycleCursor;
		int expiryCursor = __instance.expiryCursor;
		int expiryEnding = __instance.expiryEnding;
		int absorbCursor = __instance.absorbCursor;
		int absorbEnding = __instance.absorbEnding;
		ExpiryOrder[] expiryOrder = __instance.expiryOrder;
		AbsorbOrder[] absorbOrder = __instance.absorbOrder;
		__instance.sailCapacity = 512;
		__instance.sailCursor = 0;
		__instance.sailRecycleCursor = 0;
		__instance.expiryCursor = 0;
		__instance.expiryEnding = 0;
		__instance.absorbCursor = 0;
		__instance.absorbEnding = 0;
		__instance.expiryOrder = Array.Empty<ExpiryOrder>();
		__instance.absorbOrder = Array.Empty<AbsorbOrder>();
		DysonSwarm_Export_NoGPU(__instance, w);
		__instance.sailCapacity = sailCapacity;
		__instance.sailCursor = sailCursor;
		__instance.sailRecycleCursor = sailRecycleCursor;
		__instance.expiryCursor = expiryCursor;
		__instance.expiryEnding = expiryEnding;
		__instance.absorbCursor = absorbCursor;
		__instance.absorbEnding = absorbEnding;
		__instance.expiryOrder = expiryOrder;
		__instance.absorbOrder = absorbOrder;
		return false;
	}

	[HarmonyReversePatch(HarmonyReversePatchType.Original)]
	[HarmonyPatch(typeof(DysonSwarm), "Export")]
	public static void DysonSwarm_Export_NoGPU(DysonSwarm __instance, BinaryWriter _)
	{
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(DysonNode), "Export")]
	private static IEnumerable<CodeInstruction> DysonNodeExport_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator iL)
	{
		try
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, iL).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Ldarg_0), new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Ldfld && ((FieldInfo)i.operand).Name == "cpOrdered"), new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Callvirt && ((MethodInfo)i.operand).Name == "Write"));
			codeMatcher.CreateLabelAt(codeMatcher.Pos, out var label).CreateLabelAt(codeMatcher.Pos + 2, out var label2);
			codeMatcher.Insert(new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(DysonSwarmCompress), "get_Enable")), new CodeInstruction(OpCodes.Brfalse_S, label), new CodeInstruction(OpCodes.Ldc_I4_0), new CodeInstruction(OpCodes.Br_S, label2));
			return codeMatcher.InstructionEnumeration();
		}
		catch (Exception obj)
		{
			Log.Error("DysonNodeExport_Transpiler error!");
			Log.Error(obj);
			Enable = false;
			return instructions;
		}
	}

	[HarmonyReversePatch(HarmonyReversePatchType.Original)]
	[HarmonyPatch(typeof(DysonSwarm), "RemoveSailsByOrbit")]
	public static void RemoveSailsByOrbit_NoSync(DysonSwarm __instance, int orbitId)
	{
	}
}
