using System;
using System.Collections.Generic;
using System.IO;
using HarmonyLib;
using UnityEngine;

namespace LossyCompression;

internal class CargoPathCompress
{
	public static readonly int EncodedVersion = 62;

	private static int version = 62;

	public static bool Enable { get; set; }

	public static bool CanEncode(CargoPath path)
	{
		if (path?.pointPos == null || path.bufferLength < 0 || path.bufferLength > path.pointPos.Length)
		{
			return false;
		}
		for (int i = 0; i < path.bufferLength; i++)
		{
			float x = path.pointPos[i].x;
			if (x > 9999f || float.IsNaN(x) || float.IsInfinity(x))
			{
				return false;
			}
		}
		return true;
	}

	public static void Encode(CargoPath cargoPath, BinaryWriter w)
	{
		w.Write(cargoPath.capacity);
		w.Write(cargoPath.bufferLength);
		int num = 0;
		Vector3 pos = Vector3.zero;
		Quaternion rot = Quaternion.identity;
		Quaternion b = Quaternion.Euler(180f, 0f, 0f);
		Vector3[] pointPos = cargoPath.pointPos;
		Quaternion[] pointRot = cargoPath.pointRot;
		for (int i = 0; i < cargoPath.bufferLength; i++)
		{
			if (Quaternion.Dot(pointRot[i], rot) > 0.9999619f && (double)Quaternion.Dot(pointRot[i], b) > 0.99984769515)
			{
				num++;
			}
			else
			{
				if (num > 0)
				{
					w.Write((float)num * 10000f);
					w.Write(pos.x);
					w.Write(pos.y);
					w.Write(pos.z);
					Utils.WriteCompressedRotation(w, in pos, in rot);
					num = 0;
				}
				w.Write(pointPos[i].x);
				w.Write(pointPos[i].y);
				w.Write(pointPos[i].z);
				Utils.WriteCompressedRotation(w, in pointPos[i], in pointRot[i]);
				b = pointRot[i];
			}
			pos = pointPos[i];
			rot = pointRot[i];
		}
		if (num > 0)
		{
			w.Write((float)num * 10000f);
			w.Write(pos.x);
			w.Write(pos.y);
			w.Write(pos.z);
			Utils.WriteCompressedRotation(w, in pos, in rot);
		}
	}

	public static void Decode(CargoPath cargoPath, BinaryReader r)
	{
		int num = r.ReadInt32();
		int num2 = r.ReadInt32();
		if (num < 0 || num2 < 0 || num2 > num)
		{
			throw new InvalidDataException("Invalid compressed cargo path dimensions.");
		}
		int num3 = 0;
		Vector3 pos = Vector3.zero;
		Quaternion quaternion = Quaternion.identity;
		Vector3[] array = new Vector3[num];
		Quaternion[] array2 = new Quaternion[num];
		int num4 = 0;
		Vector3 pos2 = default(Vector3);
		Quaternion b = default(Quaternion);
		while (num4 < num2)
		{
			float num5 = r.ReadSingle();
			if (num5 > 9999f)
			{
				double num6 = Math.Round((double)num5 / 10000.0);
				if (double.IsNaN(num6) || double.IsInfinity(num6) || num6 < 1.0 || num6 > (double)(num2 - num4) || num4 == 0)
				{
					throw new InvalidDataException("Invalid compressed cargo path run.");
				}
				int num7 = (int)num6;
				pos2.x = r.ReadSingle();
				pos2.y = r.ReadSingle();
				pos2.z = r.ReadSingle();
				if (version >= 62)
				{
					b = Utils.ReadCompressedRotation(r, in pos2);
				}
				else
				{
					b.x = r.ReadSingle();
					b.y = r.ReadSingle();
					b.z = r.ReadSingle();
					b.w = r.ReadSingle();
				}
				for (int i = 1; i <= num7; i++)
				{
					array[num4] = Vector3.Slerp(pos, pos2, (float)i / (float)num7);
					array2[num4] = Quaternion.Slerp(quaternion, b, (float)i / (float)num7);
					num4++;
				}
				num3 += num7 - 1;
			}
			else
			{
				pos.x = num5;
				pos.y = r.ReadSingle();
				pos.z = r.ReadSingle();
				if (version >= 62)
				{
					quaternion = Utils.ReadCompressedRotation(r, in pos);
				}
				else
				{
					quaternion.x = r.ReadSingle();
					quaternion.y = r.ReadSingle();
					quaternion.z = r.ReadSingle();
					quaternion.w = r.ReadSingle();
				}
				array[num4] = pos;
				array2[num4] = quaternion;
				num4++;
				_ = pos.sqrMagnitude;
				_ = 10000f;
			}
		}
		cargoPath.capacity = num;
		cargoPath.bufferLength = num2;
		cargoPath.pointPos = array;
		cargoPath.pointRot = array2;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(CargoPath), "Export")]
	public static bool CargoPath_Export(CargoPath __instance, BinaryWriter w)
	{
		if (!Enable || !CanEncode(__instance))
		{
			return true;
		}
		w.Write(EncodedVersion);
		w.Write(__instance.id);
		Encode(__instance, w);
		w.Write(__instance.chunkCapacity);
		w.Write(__instance.chunkCount);
		w.Write(__instance.updateLen);
		w.Write(__instance.closed);
		w.Write((__instance.outputPath != null) ? __instance.outputPath.id : 0);
		w.Write((__instance.outputPath == null) ? (-1) : __instance.outputIndex);
		w.Write(__instance.belts.Count);
		w.Write(__instance.inputPaths.Count);
		w.Write(__instance.buffer, 0, __instance.bufferLength);
		for (int i = 0; i < __instance.chunkCount; i++)
		{
			w.Write(__instance.chunks[i * 3]);
			w.Write(__instance.chunks[i * 3 + 1]);
			w.Write(__instance.chunks[i * 3 + 2]);
		}
		for (int j = 0; j < __instance.belts.Count; j++)
		{
			w.Write(__instance.belts[j]);
		}
		for (int k = 0; k < __instance.inputPaths.Count; k++)
		{
			w.Write(__instance.inputPaths[k]);
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(CargoPath), "Import")]
	public static bool CargoPathImport_Prefix(CargoPath __instance, BinaryReader r)
	{
		version = r.ReadInt32();
		if (version <= 60)
		{
			CargoPathImport(__instance, r);
			return false;
		}
		__instance.Free();
		__instance.id = r.ReadInt32();
		Decode(__instance, r);
		__instance.buffer = new byte[__instance.capacity];
		__instance.SetChunkCapacity(r.ReadInt32());
		__instance.chunkCount = r.ReadInt32();
		__instance.updateLen = r.ReadInt32();
		__instance.closed = r.ReadBoolean();
		__instance.outputPathIdForImport = r.ReadInt32();
		__instance.outputIndex = r.ReadInt32();
		int num = r.ReadInt32();
		int num2 = r.ReadInt32();
		r.BaseStream.Read(__instance.buffer, 0, __instance.bufferLength);
		for (int i = 0; i < __instance.chunkCount; i++)
		{
			__instance.chunks[i * 3] = r.ReadInt32();
			__instance.chunks[i * 3 + 1] = r.ReadInt32();
			__instance.chunks[i * 3 + 2] = r.ReadInt32();
		}
		__instance.belts = new List<int>();
		for (int j = 0; j < num; j++)
		{
			__instance.belts.Add(r.ReadInt32());
		}
		__instance.inputPaths = new List<int>();
		for (int k = 0; k < num2; k++)
		{
			__instance.inputPaths.Add(r.ReadInt32());
		}
		return false;
	}

	[HarmonyReversePatch(HarmonyReversePatchType.Original)]
	[HarmonyPatch(typeof(CargoPath), "Import")]
	public static void CargoPathImport(CargoPath __instance, BinaryReader r)
	{
	}
}
