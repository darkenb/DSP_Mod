using System.IO;
using UnityEngine;

namespace LossyCompression;

internal class Utils
{
	private const float FLOAT_PRECISION_MULT = 32000f;

	private static readonly Quaternion[] array = new Quaternion[4]
	{
		Quaternion.identity,
		Quaternion.Euler(0f, 90f, 0f),
		Quaternion.Euler(0f, 180f, 0f),
		Quaternion.Euler(0f, 270f, 0f)
	};

	public static bool WriteCompressedRotation(BinaryWriter writer, in Vector3 pos, in Quaternion rot)
	{
		Quaternion a = Quaternion.Inverse(Maths.SphericalRotation(pos, 0f)) * rot;
		for (int i = 0; i < 4; i++)
		{
			if ((double)Quaternion.Dot(a, array[i]) > 0.99984769515)
			{
				writer.Write((byte)(4 + i));
				return true;
			}
		}
		int num = 0;
		float num2 = float.MinValue;
		for (int j = 0; j < 4; j++)
		{
			float num3 = rot[j] * rot[j];
			if (num3 > num2)
			{
				num = j;
				num2 = num3;
			}
		}
		float num4 = ((rot[num] + 3.125E-05f >= 0f) ? 1f : (-1f));
		writer.Write((byte)num);
		for (int k = 0; k < 4; k++)
		{
			if (k != num)
			{
				writer.Write((short)(rot[k] * num4 * 32000f));
			}
		}
		return false;
	}

	public static Quaternion ReadCompressedRotation(BinaryReader reader, in Vector3 pos)
	{
		int num = reader.ReadByte();
		if (num >= 4 && num <= 8)
		{
			return Maths.SphericalRotation(pos, 0f) * array[num - 4];
		}
		float num2 = (float)reader.ReadInt16() / 32000f;
		float num3 = (float)reader.ReadInt16() / 32000f;
		float num4 = (float)reader.ReadInt16() / 32000f;
		float num5 = Mathf.Sqrt(1f - (num2 * num2 + num3 * num3 + num4 * num4));
		return num switch
		{
			0 => new Quaternion(num5, num2, num3, num4), 
			1 => new Quaternion(num2, num5, num3, num4), 
			2 => new Quaternion(num2, num3, num5, num4), 
			3 => new Quaternion(num2, num3, num4, num5), 
			_ => Quaternion.identity, 
		};
	}
}
