using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using System.Threading;
using BepInEx;
using HarmonyLib;
using UnityEngine;

namespace LossyCompression;

public static class LazyLoading
{
	private static readonly Dictionary<DysonSphere, int> dysonSphereMasks = new Dictionary<DysonSphere, int>();

	private static DysonSphere viewingSphere = null;

	private static int editorMask;

	private static int gameMask;

	private static readonly System.Random random = new System.Random();

	private static readonly AutoResetEvent autoEvent = new AutoResetEvent(initialState: false);

	private static readonly List<DysonNode> emptyNodes = new List<DysonNode>(0);

	private static readonly Dictionary<int, int> emptyNodeIndexMap = new Dictionary<int, int>(0);

	private static readonly List<DysonFrame> emptyFrames = new List<DysonFrame>(0);

	private static readonly List<VectorLF3> emptyPolygon = new List<VectorLF3>(0);

	private static int shellCount = 0;

	public static bool Enable { get; set; } = true;

	public static bool ReduceRAM { get; set; } = false;

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameMain), "End")]
	public static void Reset()
	{
		Log.Debug("Lazyload Reset. Clear masks: " + GameMain.isEnded);
		viewingSphere = null;
		if (GameMain.isEnded)
		{
			dysonSphereMasks.Clear();
		}
	}

	public static void Add(DysonSphere dysonSphere)
	{
		dysonSphereMasks[dysonSphere] = 0;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSphereSegmentRenderer), "DrawModels")]
	public static void DrawModels(DysonSphere ___dysonSphere)
	{
		if (___dysonSphere == viewingSphere && editorMask == ___dysonSphere.inEditorRenderMaskL && gameMask == ___dysonSphere.inGameRenderMaskL)
		{
			return;
		}
		viewingSphere = ___dysonSphere;
		editorMask = ___dysonSphere.inEditorRenderMaskL;
		gameMask = ___dysonSphere.inGameRenderMaskL;
		if (!dysonSphereMasks.TryGetValue(___dysonSphere, out var value))
		{
			return;
		}
		value |= editorMask | gameMask;
		if (value != dysonSphereMasks[___dysonSphere])
		{
			dysonSphereMasks[___dysonSphere] |= editorMask | gameMask;
			DysonShellCompress.GenerateModel(viewingSphere, dysonSphereMasks[___dysonSphere]);
			if (dysonSphereMasks[___dysonSphere] == -1)
			{
				dysonSphereMasks.Remove(___dysonSphere);
			}
			DysonShellCompress.FreeRAM();
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameData), "Export")]
	public static void AfterGameDataExport()
	{
		DysonShellCompress.FreeRAM();
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSphere), "Export")]
	public static void Export_Prefix(DysonSphere __instance)
	{
		if (DysonShellCompress.Enable || !dysonSphereMasks.ContainsKey(__instance))
		{
			return;
		}
		bool generateModel = !ReduceRAM;
		if (ThreadingHelper.Instance.InvokeRequired)
		{
			autoEvent.Reset();
			ThreadingHelper.Instance.StartSyncInvoke(delegate
			{
				DysonShellCompress.GenerateModel(__instance, -1, generateModel);
				autoEvent.Set();
			});
			autoEvent.WaitOne(-1);
		}
		else
		{
			DysonShellCompress.GenerateModel(__instance, -1, generateModel);
		}
		if (generateModel)
		{
			dysonSphereMasks.Remove(__instance);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(DysonSphere), "Export")]
	public static void Export_Postfix(DysonSphere __instance)
	{
		if (DysonShellCompress.Enable || !dysonSphereMasks.ContainsKey(__instance))
		{
			return;
		}
		if (ThreadingHelper.Instance.InvokeRequired)
		{
			autoEvent.Reset();
			ThreadingHelper.Instance.StartSyncInvoke(delegate
			{
				RemoveAllVerts(__instance);
				autoEvent.Set();
			});
			autoEvent.WaitOne(-1);
		}
		else
		{
			RemoveAllVerts(__instance);
		}
	}

	private static void RemoveAllVerts(DysonSphere dysonSphere)
	{
		if (dysonSphere == viewingSphere)
		{
			viewingSphere = null;
		}
		dysonSphereMasks[dysonSphere] = 0;
		int num = 0;
		for (int i = 1; i < dysonSphere.layersIdBased.Length; i++)
		{
			if (dysonSphere.layersIdBased[i] == null || dysonSphere.layersIdBased[i].id != i)
			{
				continue;
			}
			DysonSphereLayer dysonSphereLayer = dysonSphere.layersIdBased[i];
			for (int j = 1; j < dysonSphereLayer.shellCursor; j++)
			{
				if (dysonSphereLayer.shellPool[j] != null && dysonSphereLayer.shellPool[j].id == j)
				{
					RemoveVerts(dysonSphereLayer.shellPool[j]);
					num++;
				}
			}
		}
		Log.Debug($"ReduceRAM: Remove verts for {num} shells.");
		GC.Collect();
	}

	public static void RemoveVerts(DysonShell dysonShell)
	{
		int layerId = dysonShell.layerId;
		int id = dysonShell.id;
		int protoId = dysonShell.protoId;
		int randSeed = dysonShell.randSeed;
		Color32 color = dysonShell.color;
		int[] nodecps = dysonShell.nodecps;
		int[] vertsqOffset = dysonShell.vertsqOffset;
		int vertexCount = dysonShell.vertexCount;
		int cpPerVertex = dysonShell.cpPerVertex;
		List<DysonNode> nodes = dysonShell.nodes;
		Dictionary<int, int> nodeIndexMap = dysonShell.nodeIndexMap;
		List<DysonFrame> frames = dysonShell.frames;
		List<VectorLF3> polygon = dysonShell.polygon;
		dysonShell.nodes = emptyNodes;
		dysonShell.nodeIndexMap = emptyNodeIndexMap;
		dysonShell.frames = emptyFrames;
		dysonShell.polygon = emptyPolygon;
		dysonShell.SetEmpty();
		dysonShell.layerId = layerId;
		dysonShell.id = id;
		dysonShell.protoId = protoId;
		dysonShell.randSeed = randSeed;
		dysonShell.color = color;
		dysonShell.nodecps = nodecps;
		dysonShell.vertsqOffset = vertsqOffset;
		dysonShell.vertexCount = vertexCount;
		dysonShell.cpPerVertex = cpPerVertex;
		dysonShell.nodes = nodes;
		dysonShell.nodeIndexMap = nodeIndexMap;
		dysonShell.frames = frames;
		dysonShell.polygon = polygon;
	}

	public static void GenerateModelObjectsGuard(DysonShell dysonShell)
	{
		if (Enable)
		{
			RemoveVerts(dysonShell);
			shellCount++;
		}
		else
		{
			dysonShell.GenerateModelObjects();
		}
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(DysonShell), "Import")]
	public static IEnumerable<CodeInstruction> DysonShellImport_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator iL)
	{
		try
		{
			return new CodeMatcher(instructions, iL).End().MatchBack(true, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Call && ((MethodInfo)i.operand).Name == "GenerateModelObjects")).SetOperandAndAdvance(typeof(LazyLoading).GetMethod("GenerateModelObjectsGuard"))
				.InstructionEnumeration();
		}
		catch (Exception obj)
		{
			Log.Error("DysonShellImport_Transpiler error! Lazyload will not work on vanilla save");
			Log.Error(obj);
			return instructions;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(DysonSphere), "Import")]
	[HarmonyPriority(200)]
	private static void DysonSphereImportPostfix(DysonSphere __instance)
	{
		if (Enable && shellCount > 0)
		{
			Add(__instance);
			Log.Debug($"[{__instance.starData.index,2}] lazy load: skip {shellCount} shells.");
			shellCount = 0;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSphereLayer), "RemoveDysonShell")]
	public static bool RemoveDysonShell(DysonSphereLayer __instance, int shellId)
	{
		if (__instance.shellPool[shellId].id == 0 || __instance.shellPool[shellId].verts != null)
		{
			return true;
		}
		int num = (int)(GameMain.history.solarSailLife * 60f + 0.1f);
		long expiryTime = GameMain.gameTick + num;
		DysonShell dysonShell = __instance.shellPool[shellId];
		Vector3 zero = Vector3.zero;
		int num2 = 0;
		for (int i = 0; i < dysonShell.nodes.Count; i++)
		{
			zero += dysonShell.nodes[i].pos;
			num2 += dysonShell.nodecps[i] / 2;
		}
		zero /= (float)dysonShell.nodes.Count;
		int num3 = num2 / dysonShell.nodes.Count;
		int num4 = num2 % dysonShell.nodes.Count;
		int seed = shellId;
		for (int j = 0; j < dysonShell.nodes.Count; j++)
		{
			Vector3 pos = dysonShell.nodes[j].pos;
			Vector3 vector = ((j + 1 != dysonShell.nodes.Count) ? dysonShell.nodes[j + 1].pos : dysonShell.nodes[0].pos);
			int num5 = ((j + 1 != dysonShell.nodes.Count) ? num3 : (num3 + num4));
			for (int k = 0; k < num5; k++)
			{
				float num6 = (float)random.NextDouble();
				float num7 = (float)random.NextDouble();
				if (num6 + num7 > 1f)
				{
					num6 = 1f - num6;
					num7 = 1f - num7;
				}
				Vector3 vector2 = (1f - num6 - num7) * zero + num6 * pos + num7 * vector;
				vector2 = __instance.orbitRadius * vector2.normalized;
				Vector3 vector3 = __instance.currentRotation * (Vector3.Cross(vector2, Vector3.up) * __instance.orbitAngularSpeed * (MathF.PI / 180f));
				vector2 = __instance.currentRotation * vector2;
				vector3 += (Vector3)RandomTable.SphericNormal(ref seed, 1.2000000476837158);
				DysonSail ss = new DysonSail
				{
					px = vector2.x,
					py = vector2.y,
					pz = vector2.z,
					vx = vector3.x,
					vy = vector3.y,
					vz = vector3.z,
					gs = 1f
				};
				__instance.dysonSphere.swarm.AddSolarSail(ss, 30, expiryTime);
			}
		}
		foreach (DysonNode node in __instance.shellPool[shellId].nodes)
		{
			node.shells.Remove(__instance.shellPool[shellId]);
			node.RecalcCpReq();
		}
		__instance.shellPool[shellId].Free();
		__instance.shellPool[shellId] = null;
		__instance.shellRecycle[__instance.shellRecycleCursor++] = shellId;
		return false;
	}
}
