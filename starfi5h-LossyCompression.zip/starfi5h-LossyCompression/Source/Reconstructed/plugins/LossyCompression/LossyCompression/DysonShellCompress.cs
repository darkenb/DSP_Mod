using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Reflection.Emit;
using System.Threading;
using System.Threading.Tasks;
using HarmonyLib;
using UnityEngine;

namespace LossyCompression;

internal class DysonShellCompress
{
	public static readonly int EncodedVersion = 2;

	private static readonly Dictionary<int, Vector3>[] s_vmap = new Dictionary<int, Vector3>[3];

	private static readonly Dictionary<int, Vector3>[] s_outvmap = new Dictionary<int, Vector3>[3];

	private static readonly Dictionary<int, int>[] s_ivmap = new Dictionary<int, int>[3];

	private static int shellCapacity;

	private static int shellCursor;

	private static int shellRecycleCursor;

	public static bool Enable { get; set; }

	public static bool IsMultithread { get; set; }

	public static void Export(BinaryWriter w)
	{
		if (!Enable)
		{
			w.Write(0);
			return;
		}
		HighStopwatch highStopwatch = new HighStopwatch();
		highStopwatch.Begin();
		long num = -w.BaseStream.Length;
		w.Write(EncodedVersion);
		w.Write(GameMain.data.dysonSpheres.Length);
		for (int i = 0; i < GameMain.data.dysonSpheres.Length; i++)
		{
			if (GameMain.data.dysonSpheres[i] != null)
			{
				w.Write(i);
				Encode(GameMain.data.dysonSpheres[i], w);
			}
			else
			{
				w.Write(-1);
			}
		}
		num += w.BaseStream.Length;
		PerformanceMonitor.dataLengths[1] += num;
		PerformanceMonitor.dataLengths[33] += num;
		PerformanceMonitor.dataLengths[37] += num;
		Log.Info($"Compress DysonShell: {num:N0} bytes {highStopwatch.duration}s");
	}

	public static void Encode(DysonSphere dysonSphere, BinaryWriter w)
	{
		w.Write(dysonSphere.layersIdBased.Length);
		for (int i = 1; i < dysonSphere.layersIdBased.Length; i++)
		{
			if (dysonSphere.layersIdBased[i] != null && dysonSphere.layersIdBased[i].id == i)
			{
				DysonSphereLayer dysonSphereLayer = dysonSphere.layersIdBased[i];
				w.Write(i);
				w.Write(dysonSphereLayer.shellCapacity);
				w.Write(dysonSphereLayer.shellCursor);
				w.Write(dysonSphereLayer.shellRecycleCursor);
				int num = 0;
				for (int j = 1; j < dysonSphereLayer.shellCursor; j++)
				{
					if (dysonSphereLayer.shellPool[j] != null && dysonSphereLayer.shellPool[j].id == j)
					{
						DysonShell dysonShell = dysonSphereLayer.shellPool[j];
						w.Write(dysonShell.id);
						w.Write(dysonShell.protoId);
						w.Write(dysonShell.randSeed);
						w.Write(dysonShell.color.r);
						w.Write(dysonShell.color.g);
						w.Write(dysonShell.color.b);
						w.Write(dysonShell.color.a);
						w.Write(dysonShell.nodes.Count);
						for (int k = 0; k < dysonShell.nodes.Count; k++)
						{
							w.Write(dysonShell.nodes[k].id);
						}
						for (int l = 0; l < dysonShell.nodes.Count + 1; l++)
						{
							w.Write(dysonShell.nodecps[l]);
						}
						for (int m = 0; m < dysonShell.nodes.Count + 1; m++)
						{
							w.Write(dysonShell.vertsqOffset[m]);
						}
						w.Write(dysonShell.vertexCount);
						w.Write(dysonShell.cpPerVertex);
						num++;
					}
				}
				Assert.True(num == shellCursor - shellRecycleCursor - 1);
				for (int n = 0; n < dysonSphereLayer.shellRecycleCursor; n++)
				{
					w.Write(dysonSphereLayer.shellRecycle[n]);
				}
			}
			else
			{
				w.Write(0);
			}
		}
	}

	public static void Import(BinaryReader r)
	{
		int num = r.ReadInt32();
		if (num == 0 || (num != EncodedVersion && num != 1))
		{
			return;
		}
		long num2 = -r.BaseStream.Length;
		HighStopwatch highStopwatch = new HighStopwatch();
		highStopwatch.Begin();
		int num3 = r.ReadInt32();
		Assert.True(num3 == GameMain.data.dysonSpheres.Length);
		for (int i = 0; i < num3; i++)
		{
			int num4 = r.ReadInt32();
			if (num4 != -1)
			{
				Decode(GameMain.data.dysonSpheres[num4], r, num);
			}
		}
		num2 += r.BaseStream.Length;
		PerformanceMonitor.dataLengths[1] += num2;
		PerformanceMonitor.dataLengths[33] += num2;
		PerformanceMonitor.dataLengths[37] += num2;
		Log.Info($"Decompress DysonShell: {num2:N0} bytes {highStopwatch.duration}s");
		FreeRAM();
	}

	public static void Decode(DysonSphere dysonSphere, BinaryReader r, int version)
	{
		List<DysonShell> list = new List<DysonShell>();
		List<int> list2 = new List<int>(12);
		int num = r.ReadInt32();
		Assert.True(num == dysonSphere.layersIdBased.Length);
		for (int i = 1; i < num; i++)
		{
			int num2 = r.ReadInt32();
			if (num2 == 0)
			{
				continue;
			}
			DysonSphereLayer dysonSphereLayer = dysonSphere.layersIdBased[num2];
			dysonSphereLayer.shellCapacity = r.ReadInt32();
			dysonSphereLayer.shellCursor = r.ReadInt32();
			dysonSphereLayer.shellRecycleCursor = r.ReadInt32();
			dysonSphereLayer.shellPool = new DysonShell[dysonSphereLayer.shellCapacity];
			dysonSphereLayer.shellRecycle = new int[dysonSphereLayer.shellCapacity];
			int num3 = dysonSphereLayer.shellCursor - dysonSphereLayer.shellRecycleCursor - 1;
			for (int j = 1; j <= num3; j++)
			{
				DysonShell dysonShell = new DysonShell(dysonSphereLayer)
				{
					layerId = num2,
					id = r.ReadInt32(),
					protoId = r.ReadInt32(),
					randSeed = r.ReadInt32(),
					color = new Color32(r.ReadByte(), r.ReadByte(), r.ReadByte(), r.ReadByte())
				};
				list2.Clear();
				int num4 = r.ReadInt32();
				for (int k = 0; k < num4; k++)
				{
					list2.Add(r.ReadInt32());
				}
				dysonShell.nodecps = new int[num4 + 1];
				for (int l = 0; l < num4 + 1; l++)
				{
					dysonShell.nodecps[l] = r.ReadInt32();
				}
				if (version >= 2)
				{
					dysonShell.vertsqOffset = new int[num4 + 1];
					for (int m = 0; m < num4 + 1; m++)
					{
						dysonShell.vertsqOffset[m] = r.ReadInt32();
					}
					dysonShell.vertexCount = r.ReadInt32();
					dysonShell.cpPerVertex = r.ReadInt32();
				}
				for (int n = 0; n < num4; n++)
				{
					int num5 = list2[n];
					DysonNode dysonNode = dysonSphere.FindNode(dysonShell.layerId, num5);
					Assert.NotNull(dysonNode);
					if (dysonNode != null)
					{
						dysonShell.nodeIndexMap[num5] = dysonShell.nodes.Count;
						dysonShell.nodes.Add(dysonNode);
						if (!dysonNode.shells.Contains(dysonShell))
						{
							dysonNode.shells.Add(dysonShell);
						}
					}
				}
				for (int num6 = 0; num6 < num4; num6++)
				{
					int index = num6;
					int index2 = (num6 + 1) % num4;
					DysonFrame dysonFrame = DysonNode.FrameBetween(dysonShell.nodes[index], dysonShell.nodes[index2]);
					if (dysonFrame != null)
					{
						dysonShell.frames.Add(dysonFrame);
					}
				}
				DysonNode[] nodePool = dysonSphere.layersIdBased[dysonShell.layerId].nodePool;
				for (int num7 = 0; num7 < list2.Count; num7++)
				{
					DysonNode dysonNode2 = nodePool[list2[num7 % list2.Count]];
					DysonNode dysonNode3 = nodePool[list2[(num7 + 1) % list2.Count]];
					DysonFrame dysonFrame2 = DysonNode.FrameBetween(dysonNode2, dysonNode3);
					if (dysonFrame2 == null)
					{
						dysonFrame2 = new DysonFrame();
						dysonFrame2.nodeA = dysonNode2;
						dysonFrame2.nodeB = dysonNode3;
						dysonFrame2.euler = false;
						dysonFrame2.spMax = -1;
						dysonShell.frames.Add(dysonFrame2);
					}
					List<Vector3> segments = dysonFrame2.GetSegments();
					if (dysonNode2 == dysonFrame2.nodeA)
					{
						for (int num8 = 0; num8 < segments.Count - 1; num8++)
						{
							dysonShell.polygon.Add(segments[num8]);
						}
						continue;
					}
					for (int num9 = segments.Count - 1; num9 >= 1; num9--)
					{
						dysonShell.polygon.Add(segments[num9]);
					}
				}
				list.Add(dysonShell);
				dysonSphereLayer.shellPool[dysonShell.id] = dysonShell;
			}
			for (int num10 = 0; num10 < dysonSphereLayer.shellRecycleCursor; num10++)
			{
				dysonSphereLayer.shellRecycle[num10] = r.ReadInt32();
			}
		}
		if (list.Count <= 0)
		{
			return;
		}
		if (LazyLoading.Enable && version >= 2)
		{
			LazyLoading.Add(dysonSphere);
		}
		else
		{
			GenerateModel(dysonSphere, -1);
		}
		for (int num11 = 1; num11 < dysonSphere.layersIdBased.Length; num11++)
		{
			if (dysonSphere.layersIdBased[num11] == null || dysonSphere.layersIdBased[num11].id != num11)
			{
				continue;
			}
			DysonSphereLayer dysonSphereLayer2 = dysonSphere.layersIdBased[num11];
			for (int num12 = 1; num12 < dysonSphereLayer2.shellCursor; num12++)
			{
				if (dysonSphereLayer2.shellPool[num12] != null && dysonSphereLayer2.shellPool[num12].id == num12)
				{
					dysonSphereLayer2.shellPool[num12].frames.RemoveAll((DysonFrame frame) => !frame.euler && frame.spMax == -1);
				}
			}
			for (int num13 = 1; num13 < dysonSphereLayer2.nodeCursor; num13++)
			{
				if (dysonSphereLayer2.nodePool[num13] != null && dysonSphereLayer2.nodePool[num13].id == num13)
				{
					dysonSphereLayer2.nodePool[num13].RecalcCpReq();
				}
			}
		}
	}

	public static int GenerateModel(DysonSphere dysonSphere, int bitMask, bool generateModel = true)
	{
		HighStopwatch highStopwatch = new HighStopwatch();
		highStopwatch.Begin();
		List<DysonShell> list = new List<DysonShell>();
		for (int i = 1; i < dysonSphere.layersIdBased.Length; i++)
		{
			if ((bitMask & (1 << i)) <= 0 || dysonSphere.layersIdBased[i] == null || dysonSphere.layersIdBased[i].id != i)
			{
				continue;
			}
			DysonSphereLayer dysonSphereLayer = dysonSphere.layersIdBased[i];
			for (int j = 1; j < dysonSphereLayer.shellCursor; j++)
			{
				if (dysonSphereLayer.shellPool[j] != null && dysonSphereLayer.shellPool[j].id == j && dysonSphereLayer.shellPool[j].verts == null)
				{
					list.Add(dysonSphereLayer.shellPool[j]);
				}
			}
		}
		if (list.Count > 0)
		{
			highStopwatch.Begin();
			if (IsMultithread && list.Count > 8)
			{
				GenerateGeometryParallel(list);
			}
			else
			{
				foreach (DysonShell item in list)
				{
					item.GenerateGeometry();
				}
			}
			double duration = highStopwatch.duration;
			double num = 0.0;
			if (generateModel)
			{
				highStopwatch.Begin();
				foreach (DysonShell item2 in list)
				{
					item2.GenerateModelObjects();
				}
				num = highStopwatch.duration;
			}
			Log.Debug($"[{dysonSphere.starData.index,2}] Generated {list.Count,4} shells.  Time: {duration:F4} | {num:F4}");
		}
		return list.Count;
	}

	private static void GenerateGeometryParallel(List<DysonShell> dysonShells)
	{
		int currentIndex = dysonShells.Count;
		Task[] array = new Task[3];
		for (int i = 0; i < 3; i++)
		{
			if (s_vmap[i] == null)
			{
				s_vmap[i] = new Dictionary<int, Vector3>();
				s_outvmap[i] = new Dictionary<int, Vector3>();
				s_ivmap[i] = new Dictionary<int, int>();
			}
		}
		array[0] = Task.Run(delegate
		{
			while (true)
			{
				int num2 = Interlocked.Decrement(ref currentIndex);
				if (num2 < 0)
				{
					break;
				}
				GenerateGeometry0(dysonShells[num2]);
			}
		});
		array[1] = Task.Run(delegate
		{
			while (true)
			{
				int num2 = Interlocked.Decrement(ref currentIndex);
				if (num2 < 0)
				{
					break;
				}
				GenerateGeometry1(dysonShells[num2]);
			}
		});
		array[2] = Task.Run(delegate
		{
			while (true)
			{
				int num2 = Interlocked.Decrement(ref currentIndex);
				if (num2 < 0)
				{
					break;
				}
				GenerateGeometry2(dysonShells[num2]);
			}
		});
		while (true)
		{
			int num = Interlocked.Decrement(ref currentIndex);
			if (num < 0)
			{
				break;
			}
			dysonShells[num].GenerateGeometry();
		}
		Task.WaitAll(array);
	}

	public static void FreeRAM()
	{
		for (int i = 0; i < 3; i++)
		{
			if (s_vmap[i] == null)
			{
				s_vmap[i] = null;
				s_outvmap[i] = null;
				s_ivmap[i] = null;
			}
		}
	}

	[HarmonyReversePatch(HarmonyReversePatchType.Original)]
	[HarmonyPatch(typeof(DysonShell), "GenerateGeometry")]
	public static void GenerateGeometry0(DysonShell _)
	{
	}

	[HarmonyReversePatch(HarmonyReversePatchType.Original)]
	[HarmonyPatch(typeof(DysonShell), "GenerateGeometry")]
	public static void GenerateGeometry1(DysonShell _)
	{
	}

	[HarmonyReversePatch(HarmonyReversePatchType.Original)]
	[HarmonyPatch(typeof(DysonShell), "GenerateGeometry")]
	public static void GenerateGeometry2(DysonShell _)
	{
	}

	public static IEnumerable<CodeInstruction> ReplaceDictionary(IEnumerable<CodeInstruction> instructions, int index)
	{
		return new CodeMatcher(new CodeMatcher(new CodeMatcher(instructions).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Ldsfld && ((FieldInfo)i.operand).Name == "s_vmap")).Repeat(delegate(CodeMatcher matcher)
		{
			matcher.SetAndAdvance(OpCodes.Ldsfld, AccessTools.Field(typeof(DysonShellCompress), "s_vmap")).InsertAndAdvance(new CodeInstruction(OpCodes.Ldc_I4_S, index)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldelem_Ref));
		}).InstructionEnumeration()).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Ldsfld && ((FieldInfo)i.operand).Name == "s_outvmap")).Repeat(delegate(CodeMatcher matcher)
		{
			matcher.SetAndAdvance(OpCodes.Ldsfld, AccessTools.Field(typeof(DysonShellCompress), "s_outvmap")).InsertAndAdvance(new CodeInstruction(OpCodes.Ldc_I4_S, index)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldelem_Ref));
		}).InstructionEnumeration()).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Ldsfld && ((FieldInfo)i.operand).Name == "s_ivmap")).Repeat(delegate(CodeMatcher matcher)
		{
			matcher.SetAndAdvance(OpCodes.Ldsfld, AccessTools.Field(typeof(DysonShellCompress), "s_ivmap")).InsertAndAdvance(new CodeInstruction(OpCodes.Ldc_I4_S, index)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldelem_Ref));
		}).InstructionEnumeration();
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSphereLayer), "Export")]
	public static void DysonSphereLayer_Export_Prefix(DysonSphereLayer __instance)
	{
		if (Enable)
		{
			shellCapacity = __instance.shellCapacity;
			shellCursor = __instance.shellCursor;
			shellRecycleCursor = __instance.shellRecycleCursor;
			__instance.shellCapacity = 64;
			__instance.shellCursor = 1;
			__instance.shellRecycleCursor = 0;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(DysonSphereLayer), "Export")]
	public static void DysonSphereLayer_Export_Postfix(DysonSphereLayer __instance)
	{
		if (Enable)
		{
			__instance.shellCapacity = shellCapacity;
			__instance.shellCursor = shellCursor;
			__instance.shellRecycleCursor = shellRecycleCursor;
		}
	}
}
