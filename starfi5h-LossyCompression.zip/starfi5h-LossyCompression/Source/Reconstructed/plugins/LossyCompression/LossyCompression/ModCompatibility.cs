using System;
using System.Reflection;
using BepInEx.Bootstrap;
using HarmonyLib;
using NebulaAPI;
using NebulaAPI.Interfaces;
using NebulaAPI.Networking;
using NebulaAPI.Packets;

namespace LossyCompression;

public class ModCompatibility
{
	public static class SphereOpt
	{
		public const string GUID = "SphereOpt";

		public static void Init(Harmony _)
		{
			try
			{
				if (Chainloader.PluginInfos.TryGetValue("SphereOpt", out var _) && LazyLoading.Enable)
				{
					string text = "Lazy loading is disabled due to compat with SphereOpt.\n侦测到SphereOpt,已将延迟载入功能关闭";
					dialogMessage = dialogMessage + text + "\n";
					LazyLoading.Enable = false;
					Log.Debug("SphereOpt compatibility - OK");
				}
			}
			catch (Exception obj)
			{
				LogNotice("SphereOpt", "0.9.1");
				Log.Warn(obj);
			}
		}
	}

	public static class DSPOptimizations
	{
		public const string GUID = "com.Selsion.DSPOptimizations";

		public static void Init(Harmony harmony)
		{
			try
			{
				if (Chainloader.PluginInfos.TryGetValue("com.Selsion.DSPOptimizations", out var value))
				{
					AfeterImport = AccessTools.MethodDelegate<Action>(AccessTools.Method(value.Instance.GetType().Assembly.GetType("DSPOptimizations.DysonNodeOpt"), "InitSPAndCPCounts"));
					harmony.PatchAll(typeof(DSPOptimizations));
					Log.Debug("DSPOptimizations compatibility - OK");
				}
			}
			catch (Exception obj)
			{
				LogNotice("DSPOptimizations", "1.1.18");
				Log.Warn(obj);
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(DysonShell), "SetMaterialDynamicVars")]
		public static bool SetMaterialDynamicVars(DysonShell __instance)
		{
			if (__instance.nodeProgressArr != null)
			{
				int num = __instance.nodecps.Length - 1;
				for (int i = 0; i < num && i < 768; i++)
				{
					__instance.nodeProgressArr[i] = (float)((double)__instance.nodecps[i] / (double)((__instance.vertsqOffset[i + 1] - __instance.vertsqOffset[i]) * __instance.cpPerVertex));
				}
				if (__instance.nodecps.Length <= 768)
				{
					__instance.nodeProgressArr[num] = (float)((double)__instance.nodecps[num] / (double)__instance.vertsqOffset[num]);
				}
			}
			if (__instance.material != null)
			{
				__instance.material.SetFloat("_State", __instance.state);
				int value = (__instance.color.a << 24) | (__instance.color.b << 16) | (__instance.color.g << 8) | __instance.color.r;
				__instance.material.SetInt("_Color32Int", value);
				__instance.material.SetFloatArray("_NodeProgressArr", __instance.nodeProgressArr);
			}
			return false;
		}
	}

	public static class NebulaAPI
	{
		public const string GUID = "dsp.nebula-multiplayer-api";

		public static void Init(Harmony harmony)
		{
			try
			{
				if (Chainloader.PluginInfos.TryGetValue("dsp.nebula-multiplayer-api", out var _))
				{
					Patch(harmony);
					Log.Debug("Nebula compatibility - OK");
				}
			}
			catch (Exception obj)
			{
				LogNotice("Nebula", "0.9.17");
				Log.Warn(obj);
			}
		}

		private static void Patch(Harmony harmony)
		{
			if (NebulaModAPI.NebulaIsInstalled)
			{
				NebulaModAPI.RegisterPackets(Assembly.GetExecutingAssembly());
				MethodInfo original = AccessTools.Method(AccessTools.TypeByName("NebulaWorld.Universe.DysonSphereManager"), "RegisterPlayer");
				harmony.Patch(original, null, new HarmonyMethod(typeof(NebulaAPI), "DysonDataPostfix"));
				harmony.Patch(AccessTools.Method(typeof(DysonSwarm), "RemoveSailsByOrbit"), new HarmonyMethod(typeof(NebulaAPI), "RemoveSailsByOrbitPrefix"));
			}
		}

		public static void DysonDataPostfix(INebulaConnection conn, int starIndex)
		{
			conn.SendPacket<LC_DysonData>(new LC_DysonData(starIndex));
		}

		public static bool RemoveSailsByOrbitPrefix(int orbitId)
		{
			if (orbitId == 0 && (bool)AccessTools.Property(AccessTools.TypeByName("NebulaWorld.Multiplayer"), "IsDedicated")?.GetValue(null))
			{
				Log.Debug("Skip sails rearrange");
				return false;
			}
			return true;
		}
	}

	internal class LC_DysonData
	{
		public int StarIndex { get; set; }

		public int EnableFlags { get; set; }

		public byte[] Bytes { get; set; }

		public long GameTick { get; set; }

		public LC_DysonData()
		{
		}

		public LC_DysonData(int starIndex)
		{
			StarIndex = starIndex;
			EnableFlags = Plugin.GetEnables();
			DysonSphere dysonSphere = GameMain.data.dysonSpheres[starIndex];
			IWriterProvider binaryWriter = NebulaModAPI.GetBinaryWriter();
			try
			{
				if (DysonShellCompress.Enable)
				{
					DysonShellCompress.Encode(dysonSphere, binaryWriter.BinaryWriter);
				}
				if (DysonSwarmCompress.Enable)
				{
					DysonSwarmCompress.Encode(dysonSphere, binaryWriter.BinaryWriter);
				}
				Bytes = binaryWriter.CloseAndGetBytes();
			}
			finally
			{
				((IDisposable)binaryWriter)?.Dispose();
			}
			GameTick = GameMain.gameTick;
			Log.Debug($"Send compressed data {Bytes.Length:N0}");
			DysonShellCompress.FreeRAM();
		}
	}

	[RegisterPacketProcessor]
	internal class NC_ModSaveDataProcessor : BasePacketProcessor<LC_DysonData>
	{
		public override void ProcessPacket(LC_DysonData packet, INebulaConnection conn)
		{
			if (!base.IsClient)
			{
				return;
			}
			Log.Debug($"Recv compressed data {packet.Bytes.Length:N0}, flag {packet.EnableFlags}");
			DysonSphere dysonSphere = GameMain.data.dysonSpheres[packet.StarIndex];
			IReaderProvider binaryReader = NebulaModAPI.GetBinaryReader(packet.Bytes);
			try
			{
				if ((packet.EnableFlags & 2) != 0)
				{
					DysonShellCompress.Decode(dysonSphere, binaryReader.BinaryReader, DysonShellCompress.EncodedVersion);
				}
				if ((packet.EnableFlags & 4) != 0)
				{
					DysonSwarmCompress.Decode(dysonSphere, binaryReader.BinaryReader, packet.GameTick);
				}
			}
			finally
			{
				((IDisposable)binaryReader)?.Dispose();
			}
			DysonShellCompress.FreeRAM();
			AfeterImport?.Invoke();
			LazyLoading.Reset();
		}
	}

	public static Action AfeterImport;

	private static string dialogMessage = "";

	public static void Init(Harmony harmony)
	{
		SphereOpt.Init(harmony);
		DSPOptimizations.Init(harmony);
		NebulaAPI.Init(harmony);
		if (!string.IsNullOrEmpty(dialogMessage))
		{
			harmony.Patch(AccessTools.Method(typeof(VFPreload), "InvokeOnLoadWorkEnded"), null, new HarmonyMethod(AccessTools.Method(typeof(ModCompatibility), "ShowMessage")));
		}
	}

	private static void ShowMessage()
	{
		UIMessageBox.Show("Lossy Compression兼容性提示", dialogMessage, "确定".Translate(), 3);
	}

	private static void LogNotice(string modName, string lastWorkingVersion)
	{
		string text = modName + " compatibility failed!(兼容失效) Last working version: " + lastWorkingVersion;
		dialogMessage = dialogMessage + text + "\n";
		Log.Warn(text);
	}
}
