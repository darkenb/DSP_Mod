using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace LossyCompression;

internal class UIcontrol
{
	private static GameObject compressButton;

	private static Text compressButtonText;

	private static Image compressButtonColor;

	private static Color orange = new Color(1f, 0.5961f, 0.3804f, 0.7216f);

	private static Color grey = new Color(0.6196f, 0.6196f, 0.6196f, 0.7216f);

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIPerformancePanel), "_OnOpen")]
	public static void Init()
	{
		if (compressButton == null)
		{
			try
			{
				UIButton dataActiveButton = UIRoot.instance.uiGame.statWindow.performancePanelUI.dataActiveButton;
				compressButton = Object.Instantiate(dataActiveButton.gameObject, dataActiveButton.transform.parent);
				compressButton.name = "LossyCompression - ActiveButton";
				compressButton.transform.localPosition += new Vector3(120f, 0f);
				Object.Destroy(compressButton.GetComponent<UIButton>());
				Button component = compressButton.GetComponent<Button>();
				component.onClick.RemoveAllListeners();
				component.onClick.AddListener(OnCompressActiveButtonClick);
				Transform transform = compressButton.transform.Find("button-text");
				Object.Destroy(transform.GetComponent<Localizer>());
				compressButtonText = transform.GetComponent<Text>();
				compressButtonColor = compressButton.GetComponent<Image>();
				compressButtonText.text = "Compress - ON";
				compressButtonColor.color = orange;
				Log.Debug("UI component init");
			}
			catch
			{
				Log.Warn("UI component initial fail!");
			}
		}
	}

	public static void OnDestory()
	{
		if (compressButton != null)
		{
			Object.Destroy(compressButton);
			compressButtonText = null;
			compressButtonColor = null;
		}
	}

	public static void OnCompressActiveButtonClick()
	{
		Plugin.Enable = !Plugin.Enable;
		if (Plugin.Enable)
		{
			compressButtonText.text = "Compress - ON";
			compressButtonColor.color = orange;
		}
		else
		{
			compressButtonText.text = "Compress - OFF";
			compressButtonColor.color = grey;
		}
	}
}
