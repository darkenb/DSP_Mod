# starfi5h-LossyCompression

Fall back to native export for coordinate/marker collisions and reject malformed compressed runs before changing geometry.

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.

[Review map](REVIEW_GUIDE.md) · [Related mods and code references](RELATED_MODS.md) · [Detailed changes](CHANGELOG.md) · [Build/review notes](BUILD.md) · [Assembly metadata](metadata.json)

Prepared for maintainer review on 15 October 2026. This is a local modified build, not an official upstream release, published package or pull request.

Installed plugin version(s): **0.3.10**. Existing package manifest version: **0.3.8**. Manifest, plugin and assembly versions are separate; the original manifest is retained.

## Package layout

- `InstalledPackage/`: recorded installed files, subject to the explicit size exclusions in PACKAGING.md; not a complete installation package.
- `Source/Reconstructed/`: full projects reconstructed from the exact installed assemblies.
- `Source/EarlierWorkingSource/`, `PortedWorkingSource/`, `UpstreamSnapshot/`: source snapshots when available; provenance is recorded separately.
- `Evidence/`: development helpers, focused check sources and structured validation/installation records.
- `Diffs/`: source-port patches and normalized structural IL comparison.
- `Baselines/`: previous binary and its provenance for review, not an automatic rollback.

## Plugin identifiers and declared dependencies

- `starfi5h.plugin.LossyCompression` — LossyCompression 0.3.10; dependencies: crecheng.DSPModSave | hard; com.Selsion.DSPOptimizations | soft; dsp.nebula-multiplayer-api | soft.

## Installed assembly hashes

| Recorded path | SHA-256 |
|---|---|
| `plugins/starfi5h-LossyCompression/LossyCompression.dll` | `e6d8aea28ebb071bca292b4760621bbb3b6f14c879c251a0ed756f2d4ebb19ad` |

## Scope and limitations

Not every source project has been rebuilt. Historical compile/test evidence is limited to its recorded hashes. Headless/embedded-Mono checks do not establish real Unity UI, the user's world, all-mod startup, multiplayer or sustained-memory acceptance.

## Compact maintainer review package

Upload the prepared **`starfi5h-LossyCompression.zip`**. Full related-mod copies have been replaced with upstream links, exact versions/hashes and targeted source files under `References/`. See [RELATED_MODS.md](RELATED_MODS.md), [packaging scope and exclusions](PACKAGING.md), and [verification](STANDALONE_VERIFICATION.json). Do not re-ZIP the folder with the ZIP inside it.

All primary development code and recorded validation material are retained. This is a source-review package; external game/mod SDKs and any files explicitly excluded in PACKAGING.md are needed for a full build/runtime test. Historical test results do not establish live-game acceptance.
