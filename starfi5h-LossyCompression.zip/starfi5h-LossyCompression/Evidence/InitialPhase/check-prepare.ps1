param([string]$Game, [string]$Core, [string]$Output)
$ErrorActionPreference = 'Stop'
# The installed mod already accesses these private fields on Unity Mono.
# For desktop CLR tests publish visibility only; native method bodies remain intact.
Add-Type -Path (Join-Path $Core 'Mono.Cecil.dll')
$original = Join-Path $Game 'Assembly-CSharp.dll'
$hash = (Get-FileHash -LiteralPath $original).Hash
$resolver = New-Object Mono.Cecil.DefaultAssemblyResolver
$resolver.AddSearchDirectory($Game); $resolver.AddSearchDirectory($Core)
$reader = New-Object Mono.Cecil.ReaderParameters
$reader.AssemblyResolver = $resolver
$assembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($original, $reader)
try {
    function Publish-Type($type) {
        if ($type.IsNested) { $type.IsNestedPublic = $true } else { $type.IsPublic = $true }
        foreach ($field in $type.Fields) { if (-not ($type.Events | Where-Object Name -eq $field.Name)) { $field.IsPublic = $true } }
        foreach ($method in $type.Methods) { $method.IsPublic = $true }
        foreach ($nested in $type.NestedTypes) { Publish-Type $nested }
    }
    foreach ($type in $assembly.MainModule.Types) { Publish-Type $type }
    [IO.Directory]::CreateDirectory($Output) | Out-Null
    $assembly.Write((Join-Path $Output 'Assembly-CSharp.dll'))
} finally { $assembly.Dispose() }
if ((Get-FileHash -LiteralPath $original).Hash -ne $hash) { throw 'Original game changed' }
Write-Output 'Desktop test visibility published; native bodies and original game unchanged.'
