using System;
using System.IO;
using System.Linq;
using System.Collections.Generic;
using System.Reflection;
using System.Runtime.Serialization;
using HarmonyLib;
using LossyCompression;
using UnityEngine;
static class Check
{
    static T Empty<T>() => (T)FormatterServices.GetUninitializedObject(typeof(T));
    static Type Type(string name) => typeof(Plugin).Assembly.GetType("LossyCompression." + name);
    static object Call(Type type, string name, params object[] args) => AccessTools.Method(type, name).Invoke(null, args);
    static void Assert(bool value, string name) { if (!value) throw new Exception(name); Console.WriteLine("PASS " + name); }
    static byte[] EncodeShell(Type type, DysonSphere sphere)
    {
        var s = new MemoryStream(); Call(type, "Encode", sphere, new BinaryWriter(s)); return s.ToArray();
    }
    static int Main()
    {
        var cargoType = Type("CargoPathCompress"); cargoType.GetProperty("Enable").SetValue(null, true, null);
        var path = Empty<CargoPath>(); path.id = 7; path.capacity = 2; path.bufferLength = 2;
        path.pointPos = new[] {new Vector3(10000, 1, 2), new Vector3(10001, 3, 4)};
        path.pointRot = new[] {new Quaternion(0,0,0,1), new Quaternion(0,0,0,1)};
        path.buffer = new byte[] {17, 19}; path.belts = new List<int> {3}; path.inputPaths = new List<int> {5};
        path.chunks = new int[0];
        Assert(!(bool)Call(cargoType, "CanEncode", path), "large GalacticScale coordinate cannot collide with compressed run marker");
        var harmony = new Harmony("phase15.native.check"); harmony.PatchAll(cargoType);
        var stream = new MemoryStream(); var writer = new BinaryWriter(stream);
        Assert((bool)Call(cargoType, "CargoPath_Export", path, writer) && stream.Length == 0,
               "large-radius path delegates to native export before writing any compressed header");
        // Native v0 uses managed field reads; native v1 UnsafeIO requires Unity ECalls.
        writer.Write(0); writer.Write(7); writer.Write(2); writer.Write(2);
        writer.Write(0); writer.Write(0); writer.Write(0); writer.Write(false); writer.Write(0); writer.Write(-1);
        writer.Write(1); writer.Write(1); writer.Write(path.buffer);
        for (int i = 0; i < 2; i++) {
            writer.Write(path.pointPos[i].x); writer.Write(path.pointPos[i].y); writer.Write(path.pointPos[i].z);
            writer.Write(0f); writer.Write(0f); writer.Write(0f); writer.Write(1f);
        }
        writer.Write(3); writer.Write(5);
        stream.Position = 0; var restored = new CargoPath(null); restored.Import(new BinaryReader(stream));
        Assert(restored.id == 7 && restored.buffer.SequenceEqual(path.buffer) && restored.pointPos[1].x == 10001 && restored.belts[0] == 3 && restored.inputPaths[0] == 5,
               "actual native legacy reverse-import retains large geometry, cargo and topology");
        harmony.UnpatchSelf();
        path.pointPos[0].x = 9999; path.pointPos[1].x = -10001;
        Assert((bool)Call(cargoType, "CanEncode", path), "ordinary and negative large coordinates retain existing codec eligibility");
        var bad = new MemoryStream(); var w = new BinaryWriter(bad); w.Write(2); w.Write(3); bad.Position = 0;
        try { Call(cargoType, "Decode", path, new BinaryReader(bad)); throw new Exception("invalid dimensions accepted"); }
        catch (TargetInvocationException e) { Assert(e.InnerException is InvalidDataException, "invalid dimensions rejected before replacing native cargo arrays"); }
        bad = new MemoryStream(); w = new BinaryWriter(bad); w.Write(2); w.Write(2); w.Write(10000f); bad.Position = 0;
        try { Call(cargoType, "Decode", path, new BinaryReader(bad)); throw new Exception("unanchored run accepted"); }
        catch (TargetInvocationException e) { Assert(e.InnerException is InvalidDataException, "run without an initial point rejected before geometry mutation"); }
        var shell = Empty<DysonShell>(); shell.id = 1; shell.protoId = 2; shell.randSeed = 17;
        shell.nodes = new List<DysonNode> {new DysonNode {id = 1}, new DysonNode {id = 2}};
        shell.nodecps = new[] {7,11,18}; shell.vertsqOffset = new[] {0, 4, 9}; shell.vertexCount = 9; shell.cpPerVertex = 2;
        var layer = Empty<DysonSphereLayer>(); layer.id = 1; layer.shellPool = new[] {null,shell,null,null};
        layer.shellCapacity = 4; layer.shellCursor = 2; layer.shellRecycleCursor = 0;
        var sphere = Empty<DysonSphere>(); sphere.layersIdBased = new[] {null,layer};
        var original = Assembly.LoadFile(Path.GetFullPath("starfi5h-LossyCompression/LossyCompression.dll"));
        Assert(EncodeShell(Type("DysonShellCompress"),sphere).SequenceEqual(EncodeShell(original.GetType("LossyCompression.DysonShellCompress"),sphere)),
               "legacy shell codec bytes and native CP/vertex reconstruction data remain identical");
        return 0;
    }
}
