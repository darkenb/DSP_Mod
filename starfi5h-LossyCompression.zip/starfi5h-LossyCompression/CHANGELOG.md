# starfi5h-LossyCompression — detailed change report

Installed plugin version(s): **0.3.10**. Fall back to native export for coordinate/marker collisions and reject malformed compressed runs before changing geometry.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Codec bounds and native fallback — 0.3.9/0.3.10

Retain CargoPath version 62, shell version 2, swarm version 1 and mod-save format 1.

- On large modded planets, X coordinates above 9999 can collide with the compressed-run marker. Select native export before writing a compressed header for such paths; keep the existing codec for other paths.
- Reject negative/inconsistent capacities, runs without an initial point and runs exceeding the remaining length before changing geometry. Avoid overflowing by prematurely converting a large float run marker to int.
- Preserve DSPOptimizations' existing legacy restore and `AfeterImport` counter-update order; it does not produce new low-resolution exports. Do not migrate shell/node CP or swarm energy to another codec or interfere with native lens/scheduler behavior.
- Version 0.3.10 adds `/unsafe+` native-access metadata, tested in embedded Mono without changing the native game DLL.

Checks verified large-coordinate fallback, actual native legacy reverse-import preserving geometry/cargo/topology, malformed-input rejection and shell codec bytes identical to installed 0.3.8. The phase checked 139 API references, 23 Harmony targets and public ABI/GUID contracts. The desktop reference only opened visibility; native method bodies were retained.

Native v1 `UnsafeIO` and interpolation require Unity ECalls, so complete current CargoPath export/load, shell GPU/geometry and multiplayer were not marked passed on desktop. These remain game acceptance work.

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
