using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;

namespace SphereEditorTools;

public class EditOrbit
{
	public static bool EnableAnchorMode;

	public static float AuglarSpeed;

	private static DysonSphereLayer selectedLayer;

	public static bool Toggle(bool enable)
	{
		if (enable && selectedLayer != null)
		{
			if (!EnableAnchorMode)
			{
				AuglarSpeed = selectedLayer.orbitAngularSpeed;
			}
			selectedLayer.orbitAngularSpeed = 0f;
			EnableAnchorMode = true;
		}
		else
		{
			if (EnableAnchorMode && selectedLayer != null)
			{
				selectedLayer.orbitAngularSpeed = AuglarSpeed;
			}
			EnableAnchorMode = false;
		}
		return EnableAnchorMode;
	}

	public static void TrySetAngularSpeed(float angularSpeed)
	{
		if (selectedLayer != null && !float.IsNaN(angularSpeed) && !float.IsInfinity(angularSpeed) && (!(angularSpeed < 0f) || (!(selectedLayer.orbitRadius <= 0f) && selectedLayer.dysonSphere != null)))
		{
			if (angularSpeed < 0f)
			{
				AuglarSpeed = Mathf.Sqrt(selectedLayer.dysonSphere.gravity / selectedLayer.orbitRadius) / selectedLayer.orbitRadius * 57.29578f;
			}
			else
			{
				AuglarSpeed = angularSpeed;
			}
			Log.LogInfo($"Set angular speed of layer[{selectedLayer.id}]: {selectedLayer.orbitAngularSpeed} => {AuglarSpeed}");
			selectedLayer.orbitAngularSpeed = AuglarSpeed;
			UIWindow.SpeedInput = AuglarSpeed.ToString();
			EnableAnchorMode = false;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(DESelection), "NotifySelectionChange")]
	public static void DESelection_Postfix(DESelection __instance)
	{
		if (__instance.singleSelectedLayer == selectedLayer)
		{
			return;
		}
		if (EnableAnchorMode)
		{
			if (selectedLayer != null)
			{
				selectedLayer.orbitAngularSpeed = AuglarSpeed;
			}
			EnableAnchorMode = false;
		}
		if (__instance.singleSelectedLayer != null)
		{
			AuglarSpeed = __instance.singleSelectedLayer.orbitAngularSpeed;
			UIWindow.SpeedInput = AuglarSpeed.ToString();
		}
		selectedLayer = __instance.singleSelectedLayer;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DysonSphereLayer), "InitOrbitRotation")]
	public static bool InitOrbitRotation_Prefix(DysonSphereLayer __instance, Quaternion __1)
	{
		if (EnableAnchorMode && __instance == selectedLayer)
		{
			ChangeLayer(__instance, __1);
			return false;
		}
		return true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDysonEditor), "_OnClose")]
	[HarmonyPatch(typeof(GameMain), "End")]
	public static void Free()
	{
		Toggle(enable: false);
		selectedLayer = null;
	}

	public static void ConvertQuaternion(Quaternion rotation, out float inclination, out float longitude)
	{
		inclination = ((rotation.eulerAngles.z == 0f) ? 0f : (360f - rotation.eulerAngles.z));
		longitude = ((rotation.eulerAngles.y == 0f) ? 0f : (360f - rotation.eulerAngles.y));
	}

	public static void ChangeLayer(DysonSphereLayer layer, Quaternion rotation)
	{
		Quaternion orbitRotation = rotation;
		Quaternion orbitRotation2 = layer.orbitRotation;
		layer.orbitRotation = orbitRotation;
		rotation = orbitRotation2;
		ConvertQuaternion(rotation, out var inclination, out var longitude);
		Log.LogInfo($"Previous Layer[{layer.id}]: ({inclination},{longitude})");
		ConvertQuaternion(layer.orbitRotation, out inclination, out longitude);
		Log.LogInfo($" Current Layer[{layer.id}]: ({inclination},{longitude})");
		Quaternion currentRotation = layer.currentRotation;
		layer.currentAngle = 0f;
		layer.currentRotation = layer.orbitRotation * Quaternion.Euler(0f, 0f - layer.currentAngle, 0f);
		MoveStructure(layer, currentRotation);
	}

	public static void MoveStructure(DysonSphereLayer layer, Quaternion previousRotation)
	{
		DysonSphere dysonSphere = layer.dysonSphere;
		MoveNodes(layer, previousRotation);
		SyncNodeBuffer(layer);
		MoveFrames(layer);
		dysonSphere.CheckAutoNodes();
		for (int i = dysonSphere.autoNodeCount; i < 8; i++)
		{
			dysonSphere.PickAutoNode();
		}
		dysonSphere.modelRenderer.RebuildModels();
		MoveShells(layer);
	}

	public static void SyncNodeBuffer(DysonSphereLayer layer)
	{
		DysonSphere dysonSphere = layer.dysonSphere;
		for (int i = 0; i < layer.nodeCursor; i++)
		{
			DysonNode dysonNode = layer.nodePool[i];
			if (dysonNode != null && dysonNode.id == i)
			{
				dysonSphere.nrdPool[dysonNode.rid].pos = dysonNode.pos;
				dysonSphere.nrdPool[dysonNode.rid].angularVel = layer.orbitAngularSpeed;
			}
		}
		dysonSphere.nrdBuffer.SetData(dysonSphere.nrdPool);
	}

	public static void MoveNodes(DysonSphereLayer layer, Quaternion previousRotation)
	{
		for (int i = 0; i < layer.nodeCursor; i++)
		{
			DysonNode dysonNode = layer.nodePool[i];
			if (dysonNode != null && dysonNode.id == i && EnableAnchorMode)
			{
				dysonNode.pos = Quaternion.Inverse(layer.currentRotation) * previousRotation * dysonNode.pos;
			}
		}
	}

	public static void MoveFrames(DysonSphereLayer layer)
	{
		for (int i = 0; i < layer.frameCursor; i++)
		{
			DysonFrame dysonFrame = layer.framePool[i];
			if (dysonFrame != null && dysonFrame.id == i)
			{
				int spMax = dysonFrame.spMax;
				int spReqOrder = dysonFrame.nodeA.spReqOrder;
				int spReqOrder2 = dysonFrame.nodeB.spReqOrder;
				dysonFrame.spMax = dysonFrame.segCount * 10;
				dysonFrame.nodeA.RecalcSpReq();
				dysonFrame.nodeB.RecalcSpReq();
				Log.LogDebug($"Frame[{i}]: spMax {spMax}->{dysonFrame.spMax}; " + $"ReqSP nodeA[{dysonFrame.nodeA.id}]:{spReqOrder}->{dysonFrame.nodeA.spReqOrder}, nodeB[{dysonFrame.nodeB.id}]:{spReqOrder2}->{dysonFrame.nodeB.spReqOrder}");
				dysonFrame.segPoints = null;
			}
		}
	}

	public static void MoveShells(DysonSphereLayer layer)
	{
		List<int> list = new List<int>(6);
		List<int> list2 = new List<int>(6);
		for (int i = 0; i < layer.shellCursor; i++)
		{
			DysonShell dysonShell = layer.shellPool[i];
			if (dysonShell == null || i != dysonShell.id)
			{
				continue;
			}
			list.Clear();
			list2.Clear();
			for (int j = 0; j < dysonShell.nodes.Count; j++)
			{
				list.Add(dysonShell.nodes[j].id);
			}
			for (int k = 0; k < dysonShell.nodes.Count + 1; k++)
			{
				list2.Add(dysonShell.nodecps[k]);
				dysonShell.nodecps[k] = 0;
			}
			int vertexCount = dysonShell.vertexCount;
			int protoId = dysonShell.protoId;
			Color32 color = dysonShell.color;
			layer.RemoveDysonShell(dysonShell.id);
			int num = layer.NewDysonShell(protoId, list);
			dysonShell = layer.shellPool[num];
			dysonShell.color = color;
			for (int l = 0; l < dysonShell.nodes.Count; l++)
			{
				int num2 = list2[l];
				while (num2 > 0 && dysonShell.Construct(l))
				{
					num2--;
				}
				dysonShell.nodes[l].RecalcCpReq();
				dysonShell.nodecps[l] += num2;
			}
			Log.LogDebug($"Shell[{i}]:Vertex {vertexCount}->{dysonShell.vertexCount}; Total CP {list2[dysonShell.nodes.Count]}->{dysonShell.nodecps[dysonShell.nodes.Count]}");
			dysonShell.nodecps[dysonShell.nodes.Count] = list2[dysonShell.nodes.Count];
		}
	}
}
