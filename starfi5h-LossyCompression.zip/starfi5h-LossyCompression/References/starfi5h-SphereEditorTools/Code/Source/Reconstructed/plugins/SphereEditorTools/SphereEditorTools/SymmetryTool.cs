using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;

namespace SphereEditorTools;

internal class SymmetryTool : MonoBehaviour
{
	private static UIDysonEditor dysnoEditor;

	private static List<UIDysonBrush>[] brushes;

	private static int brushId;

	private static int mirrorMode;

	private static int rdialCount;

	private static bool overwrite;

	private static Vector3 dataPoint;

	private static float castRadius;

	private static bool resultSnap;

	private static Vector3 clickPoint;

	private static float castDist;

	private static Vector3 rayOrigin;

	private static Ray castRay;

	private static bool paint_gridMode;

	private static int paint_cast_type;

	private static int tick;

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDysonEditor), "_OnOpen")]
	public static void Init(UIDysonEditor __instance)
	{
		dysnoEditor = __instance;
		brushes = new List<UIDysonBrush>[dysnoEditor.brushes.Length];
		for (int i = 0; i < brushes.Length; i++)
		{
			brushes[i] = new List<UIDysonBrush> { null };
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDysonEditor), "_OnClose")]
	public static void Free()
	{
		if (brushes != null)
		{
			for (int i = 0; i < brushes.Length; i++)
			{
				foreach (UIDysonBrush item in brushes[i])
				{
					((ManualBehaviour)item)?._OnClose();
					if (item?.gameObject != null)
					{
						UnityEngine.Object.Destroy(item?.gameObject);
					}
				}
			}
			brushes = null;
		}
		Comm.SymmetricMode = false;
	}

	public static void ChangeParameters(int newMirrorMode, int newRadialCount)
	{
		int num = rdialCount * ((mirrorMode <= 0) ? 1 : 2);
		mirrorMode = newMirrorMode;
		rdialCount = newRadialCount;
		int num2 = rdialCount * ((mirrorMode <= 0) ? 1 : 2);
		while (brushes[2].Count < num2)
		{
			AddBrushes();
		}
		for (int i = 0; i < brushes.Length; i++)
		{
			if (brushes[i].Count >= num)
			{
				for (int j = num2; j < num; j++)
				{
					((ManualBehaviour)brushes[i][j])?._OnClose();
					brushes[i][j]?.gameObject.SetActive(value: false);
				}
			}
		}
	}

	private static void AddBrushes()
	{
		int num = 1;
		UIDysonBrush_Select uIDysonBrush_Select = (UIDysonBrush_Select)UnityEngine.Object.Instantiate(dysnoEditor.brushes[num], dysnoEditor.brushes[num].transform.parent);
		brushes[num].Add(uIDysonBrush_Select);
		foreach (Transform item in uIDysonBrush_Select.gameObject.transform)
		{
			UnityEngine.Object.Destroy(item.gameObject);
		}
		((ManualBehaviour)uIDysonBrush_Select)._OnInit();
		num = 2;
		UIDysonBrush_Node uIDysonBrush_Node = (UIDysonBrush_Node)UnityEngine.Object.Instantiate(dysnoEditor.brushes[num], dysnoEditor.brushes[num].transform.parent);
		brushes[num].Add(uIDysonBrush_Node);
		foreach (Transform item2 in uIDysonBrush_Node.gameObject.transform)
		{
			UnityEngine.Object.Destroy(item2.gameObject);
		}
		((ManualBehaviour)uIDysonBrush_Node)._OnInit();
		num = 3;
		UIDysonBrush_Frame uIDysonBrush_Frame = (UIDysonBrush_Frame)UnityEngine.Object.Instantiate(dysnoEditor.brushes[num], dysnoEditor.brushes[num].transform.parent);
		brushes[num].Add(uIDysonBrush_Frame);
		foreach (Transform item3 in uIDysonBrush_Frame.gameObject.transform)
		{
			UnityEngine.Object.Destroy(item3.gameObject);
		}
		((ManualBehaviour)uIDysonBrush_Frame)._OnInit();
		uIDysonBrush_Frame.isEuler = false;
		num = 4;
		uIDysonBrush_Frame = (UIDysonBrush_Frame)UnityEngine.Object.Instantiate(dysnoEditor.brushes[num], dysnoEditor.brushes[num].transform.parent);
		brushes[num].Add(uIDysonBrush_Frame);
		foreach (Transform item4 in uIDysonBrush_Frame.gameObject.transform)
		{
			UnityEngine.Object.Destroy(item4.gameObject);
		}
		((ManualBehaviour)uIDysonBrush_Frame)._OnInit();
		uIDysonBrush_Frame.isEuler = true;
		num = 5;
		UIDysonBrush_Shell uIDysonBrush_Shell = (UIDysonBrush_Shell)UnityEngine.Object.Instantiate(dysnoEditor.brushes[num], dysnoEditor.brushes[num].transform.parent);
		brushes[num].Add(uIDysonBrush_Shell);
		foreach (Transform item5 in uIDysonBrush_Shell.gameObject.transform)
		{
			UnityEngine.Object.Destroy(item5.gameObject);
		}
		((ManualBehaviour)uIDysonBrush_Shell)._OnInit();
		num = 6;
		UIDysonBrush_Paint uIDysonBrush_Paint = (UIDysonBrush_Paint)UnityEngine.Object.Instantiate(dysnoEditor.brushes[num], dysnoEditor.brushes[num].transform.parent);
		brushes[num].Add(uIDysonBrush_Paint);
		foreach (Transform item6 in uIDysonBrush_Paint.gameObject.transform)
		{
			UnityEngine.Object.Destroy(item6.gameObject);
		}
		((ManualBehaviour)uIDysonBrush_Paint)._OnInit();
		num = 7;
		UIDysonBrush_Remove uIDysonBrush_Remove = (UIDysonBrush_Remove)UnityEngine.Object.Instantiate(dysnoEditor.brushes[num], dysnoEditor.brushes[num].transform.parent);
		brushes[num].Add(uIDysonBrush_Remove);
		foreach (Transform item7 in uIDysonBrush_Remove.gameObject.transform)
		{
			UnityEngine.Object.Destroy(item7.gameObject);
		}
		((ManualBehaviour)uIDysonBrush_Remove)._OnInit();
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIDysonEditor), "UpdateBrushes")]
	public static void Brushes_Prepare()
	{
		if (rdialCount * ((mirrorMode <= 0) ? 1 : 2) <= 1 || brushId == (int)dysnoEditor.brushMode)
		{
			return;
		}
		foreach (UIDysonBrush item in brushes[brushId])
		{
			((ManualBehaviour)item)?._OnClose();
			item?.gameObject.SetActive(value: false);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIDysonEditor), "UpdateBrushes")]
	public static void Brushes_OnUpdate()
	{
		try
		{
			Brushes_Prepare();
			brushId = (int)dysnoEditor.brushMode;
			if (brushId == 6)
			{
				if (dysnoEditor.brush_paint.castNodeGizmo != null)
				{
					paint_cast_type = 1;
				}
				else if (dysnoEditor.brush_paint.castFrameGizmo != null)
				{
					paint_cast_type = 2;
				}
				else if (dysnoEditor.brush_paint.castShellGizmo != null)
				{
					paint_cast_type = 3;
				}
				else
				{
					paint_cast_type = 0;
				}
			}
			int num = rdialCount * ((mirrorMode <= 0) ? 1 : 2);
			if (num > 1)
			{
				if (Input.GetMouseButton(0))
				{
					foreach (UIDysonBrush item in brushes[brushId])
					{
						if (!(item != null))
						{
							continue;
						}
						switch (brushId)
						{
						case 1:
						{
							UIDysonBrush_Select obj = item as UIDysonBrush_Select;
							UIDysonBrush_Select uIDysonBrush_Select = dysnoEditor.brushes[brushId] as UIDysonBrush_Select;
							obj.selectedLayerId = uIDysonBrush_Select.selectedLayerId;
							break;
						}
						case 3:
						case 4:
							(item as UIDysonBrush_Frame).frameProtoId = dysnoEditor.frameProtoId;
							break;
						case 5:
							(item as UIDysonBrush_Shell).shellProtoId = dysnoEditor.shellProtoId;
							break;
						case 6:
						{
							UIDysonBrush_Paint uIDysonBrush_Paint = item as UIDysonBrush_Paint;
							if (dysnoEditor.brush_paint.pickColorMode)
							{
								return;
							}
							uIDysonBrush_Paint.paint = dysnoEditor.brush_paint.paint;
							uIDysonBrush_Paint.eraseMode = dysnoEditor.brush_paint.eraseMode;
							uIDysonBrush_Paint.size = dysnoEditor.brush_paint.size;
							break;
						}
						}
					}
				}
				DysonSphere viewDysonSphere = dysnoEditor.selection.viewDysonSphere;
				DysonSphereLayer singleSelectedLayer = dysnoEditor.selection.singleSelectedLayer;
				string brushError = dysnoEditor.controlPanel.toolbox.brushError;
				overwrite = true;
				Vector3 vector = dataPoint;
				Quaternion quaternion = Quaternion.identity;
				Ray ray = dysnoEditor.screenCamera.ScreenPointToRay(Input.mousePosition);
				paint_gridMode = dysnoEditor.brushMode == UIDysonEditor.EBrushMode.Paint && dysnoEditor.brush_paint.isGridMode;
				if (clickPoint != Vector3.zero)
				{
					castRadius = ray.origin.magnitude * 4000f / rayOrigin.magnitude;
					bool flag = Vector3.Dot(ray.direction, clickPoint) < 0f;
					for (int num2 = viewDysonSphere.layersSorted.Length - 1; num2 >= 0; num2--)
					{
						DysonSphereLayer dysonSphereLayer = viewDysonSphere.layersSorted[flag ? num2 : (viewDysonSphere.layersSorted.Length - 1 - num2)];
						if (dysonSphereLayer != null && Mathf.Abs(dysonSphereLayer.orbitRadius - castRadius) < 1f)
						{
							castRadius = 0f;
							quaternion = dysonSphereLayer.currentRotation;
							vector = Quaternion.Inverse(quaternion) * clickPoint;
							break;
						}
					}
				}
				if (brushes[brushId].Count >= num)
				{
					for (int i = 1; i < rdialCount; i++)
					{
						Quaternion quaternion2 = Quaternion.Euler(0f, 360f * (float)i / (float)rdialCount, 0f);
						dataPoint = quaternion2 * vector;
						clickPoint = quaternion * dataPoint;
						castRay = new Ray(quaternion2 * ray.origin, quaternion2 * ray.direction);
						brushes[brushId][i].SetDysonSphere(viewDysonSphere);
						brushes[brushId][i].layer = singleSelectedLayer;
						if (!brushes[brushId][i].active)
						{
							brushes[brushId][i]._Open();
							((ManualBehaviour)brushes[brushId][i])._OnOpen();
							brushes[brushId][i].gameObject.SetActive(value: true);
							brushes[brushId][i].active = true;
						}
						if (!brushes[brushId][i].gameObject.activeSelf)
						{
							brushes[brushId][i].gameObject.SetActive(value: true);
						}
						((ManualBehaviour)brushes[brushId][i])._OnUpdate();
					}
					if (mirrorMode > 0)
					{
						vector.y = 0f - vector.y;
						ray.origin = new Vector3(ray.origin.x, 0f - ray.origin.y, ray.origin.z);
						ray.direction = new Vector3(ray.direction.x, 0f - ray.direction.y, ray.direction.z);
						if (mirrorMode == 2)
						{
							vector.x = 0f - vector.x;
							vector.z = 0f - vector.z;
							ray.origin = new Vector3(0f - ray.origin.x, ray.origin.y, 0f - ray.origin.z);
							ray.direction = new Vector3(0f - ray.direction.x, ray.direction.y, 0f - ray.direction.z);
						}
						for (int j = rdialCount; j < 2 * rdialCount; j++)
						{
							Quaternion quaternion3 = Quaternion.Euler(0f, 360f * (float)j / (float)rdialCount, 0f);
							dataPoint = quaternion3 * vector;
							clickPoint = quaternion * dataPoint;
							castRay = new Ray(quaternion3 * ray.origin, quaternion3 * ray.direction);
							brushes[brushId][j].SetDysonSphere(viewDysonSphere);
							brushes[brushId][j].layer = singleSelectedLayer;
							if (!brushes[brushId][j].active)
							{
								brushes[brushId][j]._Open();
								((ManualBehaviour)brushes[brushId][j])._OnOpen();
								brushes[brushId][j].active = true;
							}
							if (!brushes[brushId][j].gameObject.activeSelf)
							{
								brushes[brushId][j].gameObject.SetActive(value: true);
							}
							((ManualBehaviour)brushes[brushId][j])._OnUpdate();
						}
					}
				}
				overwrite = false;
				dysnoEditor.controlPanel.toolbox.brushError = brushError;
				clickPoint = Vector3.zero;
				dataPoint = Vector3.zero;
			}
		}
		catch (Exception obj2)
		{
			Log.LogError(obj2);
			Comm.SetInfoString(Stringpool.SymmetricTool + " Error. The function is now disable", 120);
			ChangeParameters(0, 1);
		}
		tick = (tick + 1) % 600;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIDysonBrush_Node), "RecalcCollides")]
	public static void ForceUpdate(UIDysonBrush_Node __instance)
	{
		if (Input.GetMouseButtonDown(0))
		{
			__instance.lastCalcPos = Vector3.zero;
		}
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(UIDysonBrush_Node), "_OnUpdate")]
	[HarmonyPatch(typeof(UIDysonBrush_Frame), "_OnUpdate")]
	[HarmonyPatch(typeof(UIDysonBrush_Shell), "_OnUpdate")]
	[HarmonyPatch(typeof(UIDysonBrush_Select), "_OnUpdate")]
	[HarmonyPatch(typeof(UIDysonBrush_Remove), "_OnUpdate")]
	[HarmonyPatch(typeof(UIDysonBrush_Paint), "_OnUpdate")]
	public static IEnumerable<CodeInstruction> Transpiler_OnUpdate(IEnumerable<CodeInstruction> instructions)
	{
		List<CodeInstruction> list = instructions.ToList();
		List<CodeInstruction> list2 = new List<CodeInstruction>(list);
		try
		{
			MethodInfo method = typeof(UIDysonDrawingGrid).GetMethod("RaySnap", new Type[2]
			{
				typeof(Ray),
				typeof(Vector3).MakeByRefType()
			});
			MethodInfo method2 = typeof(UIDysonDrawingGrid).GetMethod("RaySnap", new Type[3]
			{
				typeof(Ray),
				typeof(Vector3).MakeByRefType(),
				typeof(int).MakeByRefType()
			});
			MethodInfo method3 = typeof(UIDysonDrawingGrid).GetMethod("RayCast");
			MethodInfo method4 = typeof(Phys).GetMethod("RayCastSphere", new Type[6]
			{
				typeof(Vector3),
				typeof(Vector3),
				typeof(float),
				typeof(Vector3),
				typeof(float),
				typeof(RCHCPU)
			});
			for (int i = 0; i < list.Count; i++)
			{
				if (list[i].operand is MethodInfo methodInfo)
				{
					if (list[i].opcode == OpCodes.Call && methodInfo == method4)
					{
						list[i].operand = typeof(SymmetryTool).GetMethod("Overwrite_RayCastSphere");
					}
					if (list[i].opcode == OpCodes.Callvirt && methodInfo == method)
					{
						list[i].opcode = OpCodes.Call;
						list[i].operand = typeof(SymmetryTool).GetMethod("Overwrite_RaySnap");
					}
					else if (list[i].opcode == OpCodes.Callvirt && methodInfo == method2)
					{
						list[i].opcode = OpCodes.Call;
						list[i].operand = typeof(SymmetryTool).GetMethod("Overwrite_RaySnap2");
					}
					else if (list[i].opcode == OpCodes.Callvirt && methodInfo == method3)
					{
						list[i].opcode = OpCodes.Call;
						list[i].operand = typeof(SymmetryTool).GetMethod("Overwrite_RayCast");
					}
				}
			}
		}
		catch (Exception obj)
		{
			Log.LogError(obj);
			list = list2;
			Log.LogWarning("Brush transpiler failed. Restore backup IL");
			SphereEditorTools.ErrorMessage += "SymmetryTool ";
		}
		return list.AsEnumerable();
	}

	public static bool Overwrite_RayCastSphere(Vector3 origin, Vector3 dir, float length, Vector3 center, float radius, out RCHCPU rch)
	{
		if (overwrite)
		{
			rch.point = Vector3.zero;
			rch.normal = Vector3.zero;
			if (origin == rayOrigin && (double)(center - clickPoint).sqrMagnitude < 1E-06)
			{
				rch.dist = castDist;
				return true;
			}
			rch.dist = 0f;
			return false;
		}
		bool num = Phys.RayCastSphere(origin, dir, length, center, radius, out rch);
		if (num)
		{
			rayOrigin = origin;
			clickPoint = center;
			castDist = rch.dist;
		}
		return num;
	}

	public static bool Overwrite_RayCast(UIDysonDrawingGrid uidysonDrawingGrid, Ray lookRay, Quaternion rotation, float radius, out Vector3 cast, bool front = true)
	{
		if (overwrite)
		{
			if (radius == castRadius)
			{
				cast = dataPoint;
				return true;
			}
			cast = Vector3.zero;
			return false;
		}
		bool num = uidysonDrawingGrid.RayCast(lookRay, rotation, radius, out cast, front);
		if (num)
		{
			castRadius = radius;
			dataPoint = cast;
		}
		return num;
	}

	public static bool Overwrite_RaySnap(UIDysonDrawingGrid uidysonDrawingGrid, Ray lookRay, out Vector3 snap)
	{
		if (overwrite)
		{
			snap = dataPoint;
			return resultSnap;
		}
		resultSnap = uidysonDrawingGrid.RaySnap(lookRay, out snap);
		dataPoint = snap;
		return resultSnap;
	}

	public static bool Overwrite_RaySnap2(UIDysonDrawingGrid uidysonDrawingGrid, Ray lookRay, out Vector3 snap, out int triIdx)
	{
		if (overwrite)
		{
			if (paint_gridMode)
			{
				return uidysonDrawingGrid.RaySnap(castRay, out snap, out triIdx);
			}
			snap = dataPoint;
			triIdx = 0;
			return resultSnap;
		}
		resultSnap = uidysonDrawingGrid.RaySnap(lookRay, out snap, out triIdx);
		dataPoint = snap;
		return resultSnap;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIDysonPaintingGrid), "RayCastAndHightlight")]
	public static void Overwrite_RayCastAndHightlight(ref Ray lookRay)
	{
		if (overwrite)
		{
			lookRay = castRay;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIDysonBrush_Shell), "AddNodeGizmo")]
	public static bool Overwrite_AddNodeGizmo()
	{
		return !overwrite;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIDysonPaintingGrid), "SetCursorCellsGraticule")]
	[HarmonyPatch(typeof(UIDysonPaintingGrid), "SetCursorCells")]
	public static bool Overwrite_Paint()
	{
		if (overwrite)
		{
			return Input.GetMouseButton(0);
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DESelection), "OnNodeClick")]
	public static bool Overwrite_OnNodeClick(DESelection __instance, DysonNode node)
	{
		if (!overwrite || node == null)
		{
			return true;
		}
		if (!__instance.selectedNodes.Contains(node))
		{
			__instance.AddNodeSelection(node);
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DESelection), "OnFrameClick")]
	public static bool Overwrite_OnFrameClick(DESelection __instance, DysonFrame frame)
	{
		if (!overwrite || frame == null)
		{
			return true;
		}
		if (!__instance.selectedFrames.Contains(frame))
		{
			__instance.AddFrameSelection(frame);
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(DESelection), "OnShellClick")]
	public static bool Overwrite_OnFrameClick(DESelection __instance, DysonShell shell)
	{
		if (!overwrite || shell == null)
		{
			return true;
		}
		if (!__instance.selectedShells.Contains(shell))
		{
			__instance.AddShellSelection(shell);
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIDysonBrush_Paint), "_OnUpdate")]
	public static bool UIDysonBrush_Paint_OnUpdate(UIDysonBrush_Paint __instance)
	{
		if (!overwrite)
		{
			return true;
		}
		__instance.size = ((__instance.size > __instance.maxPainterBrushSize) ? __instance.maxPainterBrushSize : __instance.size);
		UIDysonDrawingGrid[] drawingGrids = __instance.editor.drawingGrids;
		Camera screenCamera = __instance.editor.screenCamera;
		UIDysonPaintingGrid uIDysonPaintingGrid = __instance.editor.paintingGrids[__instance.layer.paintingGridMode];
		if (!RectTransformUtility.RectangleContainsScreenPoint(__instance.editor.controlPanel.inspector.selfRect, Input.mousePosition, __instance.editor.uiCamera) && !RectTransformUtility.RectangleContainsScreenPoint(__instance.editor.controlPanel.hierarchy.selfRect, Input.mousePosition, __instance.editor.uiCamera))
		{
			if (__instance.eraseMode)
			{
				UICursor.SetCursor(ECursor.DysonEraser);
			}
			else if (__instance.pickColorMode)
			{
				UICursor.SetCursor(ECursor.DysonEyedropper);
			}
			else
			{
				UICursor.SetCursor(ECursor.DysonPainter);
			}
		}
		if (!UIBlockZone.blocked && !UIDysonEditor.onGUIOperate)
		{
			int num = 0;
			int num2 = 0;
			int num3 = 0;
			int num4 = 0;
			if (__instance.layer != null)
			{
				int id = __instance.layer.id;
				Ray ray = screenCamera.ScreenPointToRay(Input.mousePosition);
				Ray ray2 = ray;
				ray2.origin /= (float)((double)__instance.layer.orbitRadius * 0.00025);
				if (paint_cast_type == 1)
				{
					for (int i = 1; i < __instance.layer.nodeCursor; i++)
					{
						if (__instance.layer.nodePool[i] != null && __instance.layer.nodePool[i].id == i && Vector3.SqrMagnitude(__instance.layer.nodePool[i].pos.normalized - dataPoint) < 0.001f)
						{
							num2 = i;
							num = id;
						}
					}
				}
				__instance._tmp_frame_list.Clear();
				__instance._tmp_shell_list.Clear();
				if (Overwrite_RayCast(drawingGrids[0], ray, __instance.layer.currentRotation, __instance.layer.orbitRadius, out var cast))
				{
					double num5 = 0.16099441051483154;
					for (int j = 1; j < __instance.layer.nodeCursor; j++)
					{
						DysonNode dysonNode = __instance.layer.nodePool[j];
						if (dysonNode == null || dysonNode.id != j || !((double)(__instance.layer.nodePool[j].pos.normalized - cast).sqrMagnitude < num5))
						{
							continue;
						}
						List<DysonFrame> frames = dysonNode.frames;
						for (int k = 0; k < frames.Count; k++)
						{
							if (!__instance._tmp_frame_list.Contains(frames[k]))
							{
								__instance._tmp_frame_list.Add(frames[k]);
							}
						}
						List<DysonShell> shells = dysonNode.shells;
						for (int l = 0; l < shells.Count; l++)
						{
							if (!__instance._tmp_shell_list.Contains(shells[l]))
							{
								__instance._tmp_shell_list.Add(shells[l]);
							}
						}
					}
					float num6 = 0.00028900002f;
					DysonFrame dysonFrame = null;
					DysonShell dysonShell = null;
					foreach (DysonFrame item in __instance._tmp_frame_list)
					{
						List<Vector3> segments = item.GetSegments();
						for (int m = 0; m < segments.Count - 1; m++)
						{
							Vector3 normalized = segments[m].normalized;
							Vector3 normalized2 = segments[m + 1].normalized;
							float num7 = UIDysonBrush_Paint.PointToSegmentSqr(normalized, normalized2, cast);
							if (num7 < num6)
							{
								num6 = num7;
								dysonFrame = item;
							}
						}
					}
					VectorLF3 vertex = cast * __instance.layer.orbitRadius;
					if (dysonFrame != null)
					{
						num3 = dysonFrame.id;
						num = id;
					}
					else
					{
						foreach (DysonShell item2 in __instance._tmp_shell_list)
						{
							if (item2.IsPointInShell(vertex))
							{
								dysonShell = item2;
								break;
							}
						}
						if (dysonShell != null)
						{
							num4 = dysonShell.id;
							num = id;
						}
					}
				}
				__instance._tmp_frame_list.Clear();
			}
			if (num > 0 && __instance.layer != null)
			{
				if (num2 > 0 && (__instance.targetFilter & 1) > 0)
				{
					DysonNode dysonNode2 = (__instance.castNodeGizmo = __instance.layer.nodePool[num2]);
					DysonNode dysonNode4 = dysonNode2;
					__instance.castFrameGizmo = null;
					__instance.castShellGizmo = null;
					if (__instance.pickColorMode)
					{
						return false;
					}
					if (Input.GetMouseButton(0))
					{
						dysonNode4.color = (__instance.eraseMode ? new Color32(0, 0, 0, 0) : __instance.paint);
						__instance.editor.selection.viewDysonSphere.UpdateColor(dysonNode4);
					}
				}
				else if (num3 > 0 && (__instance.targetFilter & 2) > 0)
				{
					__instance.castNodeGizmo = null;
					DysonFrame dysonFrame2 = (__instance.castFrameGizmo = __instance.layer.framePool[num3]);
					DysonFrame dysonFrame4 = dysonFrame2;
					__instance.castShellGizmo = null;
					if (__instance.pickColorMode)
					{
						return false;
					}
					if (Input.GetMouseButton(0))
					{
						dysonFrame4.color = (__instance.eraseMode ? new Color32(0, 0, 0, 0) : __instance.paint);
						__instance.editor.selection.viewDysonSphere.UpdateColor(dysonFrame4);
					}
				}
				else if (num4 > 0 && (__instance.targetFilter & 4) > 0)
				{
					__instance.castNodeGizmo = null;
					__instance.castFrameGizmo = null;
					DysonShell dysonShell2 = (__instance.castShellGizmo = __instance.layer.shellPool[num4]);
					DysonShell dysonShell4 = dysonShell2;
					if (__instance.pickColorMode)
					{
						return false;
					}
					if (Input.GetMouseButton(0))
					{
						dysonShell4.color = (__instance.eraseMode ? new Color32(0, 0, 0, 0) : __instance.paint);
					}
				}
				else
				{
					__instance.castNodeGizmo = null;
					__instance.castFrameGizmo = null;
					__instance.castShellGizmo = null;
				}
			}
			else
			{
				__instance.castNodeGizmo = null;
				__instance.castFrameGizmo = null;
				__instance.castShellGizmo = null;
			}
			if (__instance.isGridMode)
			{
				if (__instance.pickColorMode)
				{
					return false;
				}
				if (uIDysonPaintingGrid.RayCastAndHightlight(screenCamera.ScreenPointToRay(Input.mousePosition), __instance.size) && Input.GetMouseButton(0))
				{
					uIDysonPaintingGrid.PaintCells(__instance.eraseMode ? new Color32(0, 0, 0, 0) : __instance.paint);
				}
			}
			if (__instance.pickColorMode && Input.GetMouseButtonUp(0))
			{
				__instance.pickColorMode = false;
			}
			if (Input.GetMouseButtonDown(1))
			{
				if (!__instance.isGridMode)
				{
					__instance.editor.brushMode = UIDysonEditor.EBrushMode.Select;
					__instance._Close();
					return false;
				}
				__instance.paintingbox.SwitchPaintingGrid();
			}
			if (Input.GetKeyDown(KeyCode.E))
			{
				__instance.eraseMode = !__instance.eraseMode;
				return false;
			}
		}
		else
		{
			__instance.castNodeGizmo = null;
			__instance.castFrameGizmo = null;
			__instance.castShellGizmo = null;
			uIDysonPaintingGrid.ClearCursorCells();
		}
		return false;
	}
}
