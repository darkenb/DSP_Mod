using System.Collections.Generic;
using BepInEx.Logging;
using Mono.Cecil;
using Mono.Cecil.Rocks;

namespace DSPOptimizations;

public class Preloader
{
	public static ManualLogSource logSource;

	public static IEnumerable<string> TargetDLLs { get; } = new string[1] { "Assembly-CSharp.dll" };

	public static void Initialize()
	{
		logSource = Logger.CreateLogSource("DSPOptimizations Preloader");
	}

	private static TypeDefinition GetType(AssemblyDefinition assembly, string type)
	{
		TypeDefinition type2 = assembly.MainModule.GetType(type);
		if (type2 == null)
		{
			logSource.LogError("Preloader patch failed: unable to get type " + type);
		}
		return type2;
	}

	public static void Patch(AssemblyDefinition assembly)
	{
		TypeSystem typeSystem = assembly.MainModule.TypeSystem;
		GetType(assembly, "DysonShell")?.AddField("vertsqOffset_lowRes", typeSystem.Int32.MakeArrayType())?.AddField("radius_lowRes", typeSystem.Single)?.AddField("surfaceAreaUnitSphere", typeSystem.Single);
		GetType(assembly, "DysonSphereLayer")?.AddField("radius_lowRes", typeSystem.Single)?.AddField("surfaceAreaUnitSphere", typeSystem.Single)?.AddField("totalNodeSP", typeSystem.Int64)?.AddField("totalFrameSP", typeSystem.Int64)?.AddField("totalCP", typeSystem.Int64);
		GetType(assembly, "DysonSphereSegmentRenderer")?.AddField("layersDirtyMask", typeSystem.Int32.MakeArrayType());
		GetType(assembly, "PowerSystem")?.AddField("receiverCursor", typeSystem.Int32)?.AddField("receiverPool", typeSystem.Int32.MakeArrayType())?.AddField("chargerCursor", typeSystem.Int32)?.AddField("chargerPool", typeSystem.Int32.MakeArrayType())?.AddField("poleCursor", typeSystem.Int32)?.AddField("polePool", typeSystem.Int32.MakeArrayType())?.AddField("substationEnergyDemand", typeSystem.Int64);
		GetType(assembly, "AssemblerComponent")?.AddField("needsDirty", typeSystem.Boolean);
		GetType(assembly, "MonitorComponent")?.AddField("startIdx", typeSystem.Int32);
		logSource.LogInfo("Successfully ran preloader patch");
	}
}
