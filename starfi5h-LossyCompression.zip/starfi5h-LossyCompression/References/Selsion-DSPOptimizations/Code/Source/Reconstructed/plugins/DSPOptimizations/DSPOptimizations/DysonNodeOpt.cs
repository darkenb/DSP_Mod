using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;

namespace DSPOptimizations;

[RunPatches(typeof(Patch))]
[Optimization("DysonNodeOpt", "Optimizes the game logic for dyson nodes", false, new Type[] { })]
internal class DysonNodeOpt : OptimizationSet
{
	private class Patch
	{
		[HarmonyPostfix]
		[HarmonyAfter(new string[] { "crecheng.DSPModSave" })]
		[HarmonyPatch(typeof(GameData), "NewGame")]
		[HarmonyPatch(typeof(GameSave), "LoadCurrentGame")]
		public static void InitCounts()
		{
			InitSPAndCPCounts();
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonSphere), "UpdateProgress", new Type[] { typeof(DysonNode) })]
		public static void DysonSphere_UpdateProgress_Postfix1(DysonSphere __instance, DysonNode node)
		{
			lock (__instance)
			{
				DysonSphereLayer obj = __instance.layersIdBased[node.layerId];
				obj.totalNodeSP++;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonSphere), "UpdateProgress", new Type[] { typeof(DysonFrame) })]
		public static void DysonSphere_UpdateProgress_Postfix1(DysonSphere __instance, DysonFrame frame)
		{
			lock (__instance)
			{
				DysonSphereLayer obj = __instance.layersIdBased[frame.layerId];
				obj.totalFrameSP++;
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonShell), "Construct")]
		public static void DysonShell_Construct_Postfix(DysonShell __instance, bool __result)
		{
			if (__result)
			{
				DysonSphereLayer parentLayer = __instance.parentLayer;
				parentLayer.totalCP++;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(DysonSphereLayer), "RemoveDysonNode")]
		public static void DysonSphereLayer_RemoveDysonNode_Prefix(ref DysonSphereLayer __instance, int nodeId)
		{
			if (__instance.nodePool[nodeId].id != 0)
			{
				DysonSphereLayer obj = __instance;
				obj.totalNodeSP -= __instance.nodePool[nodeId].sp;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(DysonSphereLayer), "RemoveDysonFrame")]
		public static void DysonSphereLayer_RemoveDysonFrame_Prefix(ref DysonSphereLayer __instance, int frameId)
		{
			if (__instance.framePool[frameId].id != 0)
			{
				DysonSphereLayer obj = __instance;
				obj.totalFrameSP -= __instance.framePool[frameId].spA + __instance.framePool[frameId].spB;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(DysonSphereLayer), "RemoveDysonShell")]
		public static void DysonSphereLayer_RemoveDysonShell_Prefix(ref DysonSphereLayer __instance, int shellId)
		{
			if (__instance.shellPool[shellId].id != 0)
			{
				DysonSphereLayer obj = __instance;
				obj.totalCP -= __instance.shellPool[shellId].cellPoint;
			}
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(DysonSphere), "BeforeGameTick")]
		private static IEnumerable<CodeInstruction> SpherePowerPatch(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(DysonSphereLayer), "set_energyGenCurrentTick")), new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldarg_0));
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(DysonSphere), "energyGenCurrentTick"))).Advance(1);
			codeMatcher.CreateLabel(out var label);
			codeMatcher.Start().MatchForward(false, new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch(OpCodes.Conv_I8), new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(DysonSphereLayer), "set_energyGenCurrentTick"))).Advance(-1);
			OpCode opcode = codeMatcher.Opcode;
			object operand = codeMatcher.Operand;
			codeMatcher.Insert(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(opcode, operand), Transpilers.EmitDelegate<Action<DysonSphere, DysonSphereLayer>>(delegate(DysonSphere sphere, DysonSphereLayer layer)
			{
				layer.energyGenCurrentTick = layer.totalNodeSP * sphere.energyGenPerNode + layer.totalFrameSP * sphere.energyGenPerFrame + layer.totalCP * sphere.energyGenPerShell;
				sphere.energyGenCurrentTick += layer.energyGenCurrentTick;
			}), new CodeInstruction(OpCodes.Br, label)).CreateLabel(out var label2);
			codeMatcher.Start().MatchForward(true, new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(DysonSphereLayer), "get_grossRadius")), new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(DysonSphere), "grossRadius"))).Advance(1)
				.SetOperandAndAdvance(label2);
			return codeMatcher.InstructionEnumeration();
		}

		public static void UpdateColourPostfix(DysonSphere __instance, DysonNode node)
		{
			Color.RGBToHSV(node.color, out var H, out var S, out var V);
			__instance.nrdPool[node.rid].color = new Vector4(H, S, V, (int)node.color.a);
		}

		private static IEnumerable<CodeInstruction> SphereGameTickPatch(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(false, new CodeMatch((CodeInstruction x) => x.LoadsConstant()), new CodeMatch((CodeInstruction x) => x.LoadsConstant()), new CodeMatch(OpCodes.Conv_I8), new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(DeepProfiler), "EndSample"))).CreateLabel(out var label);
			codeMatcher.Start().MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(DysonSphere), "nrdPool"))).Advance(-6)
				.InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(DysonNodeOpt), "SailsVisible")), new CodeInstruction(OpCodes.Brfalse_S, label));
			return codeMatcher.InstructionEnumeration();
		}
	}

	public static void InitSPAndCPCounts()
	{
		DysonSphere[] dysonSpheres = GameMain.data.dysonSpheres;
		foreach (DysonSphere dysonSphere in dysonSpheres)
		{
			if (dysonSphere == null)
			{
				continue;
			}
			for (int j = 1; j < dysonSphere.layersIdBased.Length; j++)
			{
				DysonSphereLayer dysonSphereLayer = dysonSphere.layersIdBased[j];
				if (dysonSphereLayer == null || dysonSphereLayer.id != j)
				{
					continue;
				}
				dysonSphereLayer.totalNodeSP = 0L;
				dysonSphereLayer.totalFrameSP = 0L;
				dysonSphereLayer.totalCP = 0L;
				DysonNode[] nodePool = dysonSphereLayer.nodePool;
				for (int k = 1; k < dysonSphereLayer.nodeCursor; k++)
				{
					if (nodePool[k] != null && nodePool[k].id == k)
					{
						dysonSphereLayer.totalNodeSP += nodePool[k].sp;
					}
				}
				DysonFrame[] framePool = dysonSphereLayer.framePool;
				for (int l = 1; l < dysonSphereLayer.frameCursor; l++)
				{
					if (framePool[l] != null && framePool[l].id == l)
					{
						dysonSphereLayer.totalFrameSP += framePool[l].spA + framePool[l].spB;
					}
				}
				DysonShell[] shellPool = dysonSphereLayer.shellPool;
				for (int m = 1; m < dysonSphereLayer.shellCursor; m++)
				{
					if (shellPool[m] != null && shellPool[m].id == m)
					{
						dysonSphereLayer.totalCP += shellPool[m].cellPoint;
					}
				}
			}
		}
	}

	private static bool SailsVisible(DysonSphere sphere)
	{
		if (sphere?.swarm == null)
		{
			return false;
		}
		GameData data = GameMain.data;
		UIGame uiGame = UIRoot.instance.uiGame;
		UIDysonEditor dysonEditor = uiGame.dysonEditor;
		switch (DysonSphere.renderPlace)
		{
		case ERenderPlace.Universe:
			if (data.localStar == sphere.starData)
			{
				return sphere.inGameRenderMaskS != 0;
			}
			return false;
		case ERenderPlace.Starmap:
			if (!UIStarmap.isChangingToMilkyWay && uiGame.starmap.viewStarSystem == sphere.starData)
			{
				return sphere.inGameRenderMaskS != 0;
			}
			return false;
		case ERenderPlace.Dysonmap:
			if (dysonEditor.selection.viewDysonSphere == sphere)
			{
				return sphere.inEditorRenderMaskS != 0;
			}
			return false;
		default:
			return true;
		}
	}
}
