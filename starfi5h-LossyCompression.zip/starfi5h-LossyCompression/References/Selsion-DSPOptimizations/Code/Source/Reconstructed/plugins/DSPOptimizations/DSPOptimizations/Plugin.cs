using System.IO;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;
using crecheng.DSPModSave;

namespace DSPOptimizations;

[BepInPlugin("com.Selsion.DSPOptimizations", "DSPOptimizations", "1.1.21")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class Plugin : BaseUnityPlugin, IModCanSave
{
	public const string MOD_GUID = "com.Selsion.DSPOptimizations";

	public const string MOD_NAME = "DSPOptimizations";

	public const string MOD_VERSION = "1.1.21";

	private static Harmony harmony;

	public static ManualLogSource logger;

	internal void Awake()
	{
		logger = base.Logger;
		CommandManager.QueueInit();
		OptimizationSetManager.Init(this);
		harmony = new Harmony("com.Selsion.DSPOptimizations");
		PatchManager.Init(harmony);
		if (base.Config.Bind("General", "disableShadows", defaultValue: false, "Set to true to disable shadows.").Value)
		{
			QualitySettings.shadows = ShadowQuality.Disable;
		}
	}

	public void OnDestroy()
	{
		OptimizationSetManager.OnDestroy();
		CommandManager.OnDestroy();
		harmony?.UnpatchSelf();
	}

	void IModCanSave.Export(BinaryWriter w)
	{
		int value = 2;
		w.Write(value);
	}

	void IModCanSave.Import(BinaryReader r)
	{
		if (r.ReadInt32() == 1)
		{
			LowResShellsSaveManager.ImportWrapper(r);
		}
		LowResShellsLegacySupport.UpdateShells();
	}

	void IModCanSave.IntoOtherSave()
	{
		LowResShellsLegacySupport.UpdateShells();
		_ = DSPGame.IsMenuDemo;
	}
}
