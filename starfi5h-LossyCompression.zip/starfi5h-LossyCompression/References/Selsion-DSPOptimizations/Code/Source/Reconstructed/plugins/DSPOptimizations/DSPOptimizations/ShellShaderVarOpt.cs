using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;

namespace DSPOptimizations;

[RunPatches(typeof(Patch))]
[Optimization("ShellShaderVarOpt", "Improves fps when rendering dyson shells", false, new Type[] { })]
internal class ShellShaderVarOpt : OptimizationSet
{
	private class Patch
	{
		[HarmonyPatch(typeof(DysonShell), "GenerateModelObjects")]
		public static void ShellMatInitPostfix(DysonShell __instance)
		{
			__instance.material.SetFloat("_State", __instance.state);
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonSphere), "UpdateStates", new Type[]
		{
			typeof(DysonShell),
			typeof(uint),
			typeof(bool),
			typeof(bool)
		})]
		public static void UpdateStatePostfix(DysonShell shell)
		{
			shell.material?.SetFloat("_State", shell.state);
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonShell), "Construct")]
		public static void UpdateCPProgressPostfix(DysonShell __instance)
		{
			__instance.SetMaterialDynamicVars();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(DysonSphereSegmentRenderer), "DrawModels")]
		private static IEnumerable<CodeInstruction> RemoveShaderVarCall(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(DysonShell), "SetMaterialDynamicVars"))).Advance(-1).SetOpcodeAndAdvance(OpCodes.Nop)
				.SetOpcodeAndAdvance(OpCodes.Nop);
			return codeMatcher.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(DysonShell), "SetMaterialDynamicVars")]
		private static IEnumerable<CodeInstruction> RemoveSetFloatCall(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(Material), "SetFloat", new Type[2]
			{
				typeof(string),
				typeof(float)
			}))).Advance(-7).SetOpcodeAndAdvance(OpCodes.Nop)
				.RemoveInstructions(7);
			return codeMatcher.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(UIDEToolbox), "OnColorChange")]
		private static IEnumerable<CodeInstruction> UpdateShellColourPatch1(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(DysonShell), "color"))).Advance(-1).InsertAndAdvance(new CodeInstruction(OpCodes.Dup))
				.Advance(2)
				.InsertAndAdvance(new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(DysonShell), "SetMaterialDynamicVars")));
			return codeMatcher.InstructionEnumeration();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(UIDysonBrush_Paint), "_OnUpdate")]
		private static IEnumerable<CodeInstruction> UpdateShellColourPatch2(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(DysonShell), "color"))).Advance(-12);
			OpCode opcode = codeMatcher.Opcode;
			object operand = codeMatcher.Operand;
			codeMatcher.Advance(13).InsertAndAdvance(new CodeInstruction(opcode, operand), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(DysonShell), "SetMaterialDynamicVars")));
			return codeMatcher.InstructionEnumeration();
		}
	}
}
