using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;

namespace DSPOptimizations;

[RunPatches(typeof(Patch))]
internal class LowResShellsLegacySupport
{
	private class Patch
	{
		[HarmonyPrefix]
		[HarmonyPatch(typeof(GameData), "Import")]
		public static void ResetShellUpdateListPatch()
		{
			shellsToUpdate = new List<DysonShell>();
		}

		[HarmonyTranspiler]
		[HarmonyPatch(typeof(DysonShell), "Import")]
		private static IEnumerable<CodeInstruction> ShellUpdateTranspiler(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.Start();
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(DysonShell), "GenerateGeometry"))).MatchForward(false, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldnull), new CodeMatch(OpCodes.Stfld, AccessTools.Field(typeof(DysonShell), "vertsqOffset"))).RemoveInstructions(6)
				.MatchForward(false, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(DysonShell), "GenerateGeometry")))
				.InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0), Transpilers.EmitDelegate<Action<DysonShell>>(delegate(DysonShell shell)
				{
					shellsToUpdate.Add(shell);
				}), new CodeInstruction(OpCodes.Ret));
			return codeMatcher.InstructionEnumeration();
		}
	}

	private static List<DysonShell> shellsToUpdate;

	public static void UpdateShells()
	{
		if (shellsToUpdate == null)
		{
			return;
		}
		foreach (DysonShell item in shellsToUpdate)
		{
			double[] array = new double[item.nodes.Count];
			for (int i = 0; i < item.nodes.Count; i++)
			{
				array[i] = (double)item.nodecps[i] / (double)((item.vertsqOffset[i + 1] - item.vertsqOffset[i]) * 2);
			}
			item.vertsqOffset = null;
			item.nodecps = null;
			item.GenerateGeometry();
			int num = 0;
			item.nodecps = new int[item.nodes.Count + 1];
			for (int j = 0; j < item.nodes.Count; j++)
			{
				item.nodecps[j] = (int)(array[j] * (double)((item.vertsqOffset[j + 1] - item.vertsqOffset[j]) * item.cpPerVertex) + 0.1);
				num += item.nodecps[j];
			}
			item.nodecps[item.nodes.Count] = num;
			item.GenerateModelObjects();
		}
		shellsToUpdate = null;
	}
}
