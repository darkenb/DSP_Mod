using System;
using System.IO;
using HarmonyLib;

namespace DSPOptimizations;

public class LowResShellsSaveManager
{
	private class Patch
	{
		[HarmonyPostfix]
		[HarmonyPatch(typeof(GameSave), "LoadCurrentGame")]
		[HarmonyAfter(new string[] { "crecheng.DSPModSave" })]
		public static void DSPModSaveLoadingFix()
		{
			if (!DSPGame.IsMenuDemo)
			{
				if (!loaded)
				{
					Plugin.logger.LogWarning("The mod initialization was not called properly for this save, but will now be loaded. Are you using the correct version of DSPModSave?");
					IntoOtherSave();
				}
				loaded = false;
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(GameData), "Export")]
		[HarmonyPatch(typeof(GameData), "Import")]
		public static void ClearErrorCounts()
		{
			shellImportFailCount = 0;
			shellExportFailCount = 0;
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(GameData), "Export")]
		[HarmonyPatch(typeof(GameData), "Import")]
		public static void CheckForErrors()
		{
			if (shellExportFailCount > 0)
			{
				Plugin.logger.LogError($"{shellExportFailCount} shells had a null vertsqOffset_lowRes array");
				shellExportFailCount = 0;
			}
			if (shellImportFailCount > 0)
			{
				Plugin.logger.LogError($"{shellImportFailCount} shells required a full regen (includes vanilla cp counts)");
				shellImportFailCount = 0;
			}
		}
	}

	private static MemoryStream stream;

	public static bool loaded;

	private static int shellImportFailCount;

	private static int shellExportFailCount;

	public static void ExportWrapper(BinaryWriter w)
	{
		try
		{
			MemoryStream memoryStream = new MemoryStream();
			BinaryWriter binaryWriter = new BinaryWriter(memoryStream);
			Export(binaryWriter);
			binaryWriter.Flush();
			memoryStream.Position = 0L;
			stream = memoryStream;
			w.Write(1);
		}
		catch (Exception ex)
		{
			Plugin.logger.LogError("Failed to export current low res shells data to buffer. Error message: " + ex.InnerException);
			w.Write(-1);
		}
		if (stream == null)
		{
			w.Write(0);
			return;
		}
		w.Write((int)stream.Length);
		try
		{
			stream.WriteTo(w.BaseStream);
			Plugin.logger.LogDebug($"Wrote {stream.Length} bytes to disk for LowResShells");
		}
		catch
		{
			Plugin.logger.LogError("CRITICAL ERROR: Failed to write LowResShells export buffer to output stream");
			throw;
		}
	}

	public static void ImportWrapper(BinaryReader r)
	{
		r.ReadInt32();
		int num = r.ReadInt32();
		Plugin.logger.LogDebug($"LowResShells has {num} bytes to import");
		if (num > 0)
		{
			stream = new MemoryStream();
			stream.Write(r.ReadBytes(num), 0, num);
			stream.Position = 0L;
			try
			{
				Import(new BinaryReader(stream), num);
			}
			catch (EndOfStreamException)
			{
				Plugin.logger.LogError("Reached the end of the low res shells save data when reading. The data is likely either corrupt or invalid and will be ignored. New data will be generated.");
				IntoOtherSave();
			}
			catch (Exception ex2)
			{
				Plugin.logger.LogError("Unhandled exception when loading low res shells data. New data will be generated in place of the old data. Error message:\n" + ex2.InnerException);
				IntoOtherSave();
			}
		}
		else
		{
			stream = null;
			Plugin.logger.LogWarning("No low res shells save data exists. New data will be generated.");
			IntoOtherSave();
		}
		if (!loaded)
		{
			RecalcAllCpReq();
			loaded = true;
		}
	}

	public static void Export(BinaryWriter w)
	{
		int value = 1;
		w.Write(value);
		DysonSphere[] dysonSpheres = GameMain.data.dysonSpheres;
		int num = dysonSpheres.Length;
		w.Write(num);
		for (int i = 0; i < num; i++)
		{
			DysonSphere dysonSphere = dysonSpheres[i];
			if (dysonSphere != null)
			{
				w.Write(1);
				int num2 = dysonSphere.layersIdBased.Length;
				w.Write(num2);
				for (int j = 1; j < num2; j++)
				{
					DysonSphereLayer dysonSphereLayer = dysonSphere.layersIdBased[j];
					if (dysonSphereLayer != null && dysonSphereLayer.id == j)
					{
						w.Write(dysonSphereLayer.orbitRadius);
						w.Write(dysonSphereLayer.id);
						w.Write(dysonSphereLayer.radius_lowRes);
						w.Write(dysonSphereLayer.shellCursor);
						for (int k = 1; k < dysonSphereLayer.shellCursor; k++)
						{
							DysonShell dysonShell = dysonSphereLayer.shellPool[k];
							if (dysonShell != null && dysonShell.id == k)
							{
								w.Write(dysonShell.id);
								w.Write(dysonShell.radius_lowRes);
								w.Write(dysonShell.surfaceAreaUnitSphere);
								w.Write(dysonShell.vertsqOffset.Length);
								for (int l = 0; l < dysonShell.vertsqOffset.Length; l++)
								{
									w.Write(dysonShell.vertsqOffset[l]);
								}
								w.Write(dysonShell.vertsqOffset_lowRes.Length);
								for (int m = 0; m < dysonShell.vertsqOffset_lowRes.Length; m++)
								{
									w.Write(dysonShell.vertsqOffset_lowRes[m]);
								}
							}
							else
							{
								w.Write(0);
							}
						}
					}
					else
					{
						w.Write(-1f);
						w.Write(0);
					}
				}
			}
			else
			{
				w.Write(0);
			}
		}
	}

	public static void Import(BinaryReader r, int streamLength)
	{
		int num = r.ReadInt32();
		if (num == 1)
		{
			DysonSphere[] dysonSpheres = GameMain.data.dysonSpheres;
			int num2 = r.ReadInt32();
			for (int i = 0; i < num2; i++)
			{
				DysonSphere dysonSphere = dysonSpheres[i];
				int num3 = r.ReadInt32();
				if (dysonSphere != null && num3 == 1)
				{
					ImportSphere(r, dysonSphere);
				}
				else if (dysonSphere != null && num3 == 0)
				{
					ImportSphereGenerate(dysonSphere);
				}
				else if (dysonSphere == null && num3 == 1)
				{
					ImportSphereIgnore(r);
				}
			}
		}
		else
		{
			Plugin.logger.LogError($"Invalid shell save version: {num}. Shell save data will be discarded. New data will be generated.");
			r.ReadBytes(streamLength - 4);
			IntoOtherSave();
		}
	}

	private static void ImportSphere(BinaryReader r, DysonSphere sphere)
	{
		int num = r.ReadInt32();
		for (int i = 1; i < num; i++)
		{
			DysonSphereLayer dysonSphereLayer = sphere.layersIdBased[i];
			float num2 = r.ReadSingle();
			int num3 = r.ReadInt32();
			if (dysonSphereLayer != null && dysonSphereLayer.id == i && dysonSphereLayer.orbitRadius != num2)
			{
				if (num3 != 0)
				{
					ImportLayerIgnore(r);
				}
				ImportLayerGenerate(dysonSphereLayer);
			}
			if (dysonSphereLayer != null && dysonSphereLayer.id == i && num3 == i)
			{
				ImportLayer(r, dysonSphereLayer);
			}
			else if (dysonSphereLayer != null && dysonSphereLayer.id == i && num3 != i)
			{
				ImportLayerGenerate(dysonSphereLayer);
			}
			else if (num3 == i)
			{
				ImportLayerIgnore(r);
			}
		}
	}

	private static void ImportSphereIgnore(BinaryReader r)
	{
		int num = r.ReadInt32();
		for (int i = 1; i < num; i++)
		{
			r.ReadSingle();
			if (r.ReadInt32() == i)
			{
				ImportLayerIgnore(r);
			}
		}
	}

	private static void ImportSphereGenerate(DysonSphere sphere)
	{
		int num = sphere.layersIdBased.Length;
		for (int i = 1; i < num; i++)
		{
			DysonSphereLayer dysonSphereLayer = sphere.layersIdBased[i];
			if (dysonSphereLayer != null && dysonSphereLayer.id == i)
			{
				ImportLayerGenerate(dysonSphereLayer);
			}
		}
	}

	private static void ImportLayer(BinaryReader r, DysonSphereLayer layer)
	{
		layer.radius_lowRes = r.ReadSingle();
		if (layer.radius_lowRes <= 0f || layer.radius_lowRes > layer.orbitRadius)
		{
			layer.radius_lowRes = layer.orbitRadius;
		}
		int num = r.ReadInt32();
		int shellCursor = layer.shellCursor;
		int num2 = Math.Min(num, shellCursor);
		for (int i = 1; i < num2; i++)
		{
			DysonShell dysonShell = layer.shellPool[i];
			int num3 = r.ReadInt32();
			if (dysonShell != null && dysonShell.id == i && num3 == i)
			{
				ImportShell(r, dysonShell);
			}
			else if (dysonShell != null && dysonShell.id == i && num3 != i)
			{
				ImportShellGenerate(dysonShell);
			}
			else if (num3 == i)
			{
				ImportShellIgnore(r);
			}
		}
		if (num < shellCursor)
		{
			for (int j = num2; j < shellCursor; j++)
			{
				DysonShell dysonShell2 = layer.shellPool[j];
				if (dysonShell2 != null && dysonShell2.id == j)
				{
					ImportShellGenerate(dysonShell2);
				}
			}
		}
		else
		{
			if (shellCursor >= num)
			{
				return;
			}
			for (int k = num2; k < num; k++)
			{
				if (r.ReadInt32() == k)
				{
					ImportShellIgnore(r);
				}
			}
		}
	}

	private static void ImportLayerIgnore(BinaryReader r)
	{
		r.ReadSingle();
		int num = r.ReadInt32();
		for (int i = 1; i < num; i++)
		{
			if (r.ReadInt32() == i)
			{
				ImportShellIgnore(r);
			}
		}
	}

	private static void ImportLayerGenerate(DysonSphereLayer layer)
	{
		layer.radius_lowRes = layer.orbitRadius;
		int shellCursor = layer.shellCursor;
		for (int i = 1; i < shellCursor; i++)
		{
			DysonShell dysonShell = layer.shellPool[i];
			if (dysonShell != null && dysonShell.id == i)
			{
				ImportShellGenerate(dysonShell);
			}
		}
	}

	private static void ImportShell(BinaryReader r, DysonShell shell)
	{
		shell.radius_lowRes = r.ReadSingle();
		r.ReadSingle();
		int num = r.ReadInt32();
		int[] array = new int[num];
		for (int i = 0; i < num; i++)
		{
			array[i] = r.ReadInt32();
		}
		int num2 = r.ReadInt32();
		int[] array2 = new int[num2];
		for (int j = 0; j < num2; j++)
		{
			array2[j] = r.ReadInt32();
		}
		int num3 = shell.vertsqOffset.Length;
		bool flag = num == num3 && num2 == num3;
		if (flag)
		{
			for (int k = 0; k < num3; k++)
			{
				if (shell.vertsqOffset[k] != array2[k])
				{
					flag = false;
					break;
				}
			}
			if (array2[num3 - 1] > array[num3 - 1])
			{
				flag = false;
			}
		}
		if (flag)
		{
			shell.vertsqOffset_lowRes = array2;
			shell.vertsqOffset = array;
		}
		else
		{
			ImportShellGenerate(shell, overrideFlag: true);
		}
	}

	private static void ImportShellIgnore(BinaryReader r)
	{
		r.ReadSingle();
		r.ReadSingle();
		int num = r.ReadInt32();
		for (int i = 0; i < num; i++)
		{
			r.ReadInt32();
		}
		int num2 = r.ReadInt32();
		for (int j = 0; j < num2; j++)
		{
			r.ReadInt32();
		}
	}

	private static void ImportShellGenerate(DysonShell shell, bool overrideFlag = false)
	{
	}

	public static void IntoOtherSave()
	{
		Plugin.logger.LogWarning("Calling IntoOtherSave(). If this is your first time loading this save with LowResShells enabled, then ignore this warning.");
		DysonSphere[] array = GameMain.data?.dysonSpheres;
		if (array != null)
		{
			DysonSphere[] array2 = array;
			foreach (DysonSphere dysonSphere in array2)
			{
				if (dysonSphere != null)
				{
					ImportSphereGenerate(dysonSphere);
				}
			}
		}
		RecalcAllCpReq();
		loaded = true;
	}

	private static void RecalcAllCpReq()
	{
		DysonSphere[] dysonSpheres = GameMain.data.dysonSpheres;
		if (dysonSpheres == null)
		{
			return;
		}
		DysonSphere[] array = dysonSpheres;
		foreach (DysonSphere dysonSphere in array)
		{
			if (dysonSphere?.layersIdBased == null)
			{
				continue;
			}
			DysonSphereLayer[] layersIdBased = dysonSphere.layersIdBased;
			foreach (DysonSphereLayer dysonSphereLayer in layersIdBased)
			{
				if (dysonSphereLayer == null)
				{
					continue;
				}
				for (int k = 1; k < dysonSphereLayer.nodeCursor; k++)
				{
					if (dysonSphereLayer.nodePool[k] != null && dysonSphereLayer.nodePool[k].id == k)
					{
						dysonSphereLayer.nodePool[k].RecalcCpReq();
					}
				}
			}
		}
	}

	public static void SwapVertOffsetArrays(DysonShell shell)
	{
		int[] vertsqOffset = shell.vertsqOffset;
		shell.vertsqOffset = shell.vertsqOffset_lowRes;
		shell.vertsqOffset_lowRes = vertsqOffset;
	}
}
