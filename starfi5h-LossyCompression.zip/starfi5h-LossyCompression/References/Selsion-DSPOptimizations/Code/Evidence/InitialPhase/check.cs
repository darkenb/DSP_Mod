using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using HarmonyLib;
using DSPOptimizations;
static class Check
{
    static T Empty<T>() => (T)FormatterServices.GetUninitializedObject(typeof(T));
    static void Set(object target, string name, object value)
    {
        var field = AccessTools.Field(target.GetType(), name) ?? AccessTools.Field(target.GetType(), "<" + name + ">k__BackingField");
        if (field == null) throw new Exception("Missing fixture field " + target.GetType() + "." + name);
        field.SetValue(target, value);
    }
    static void Assert(bool value, string message) { if (!value) throw new Exception(message); Console.WriteLine("PASS " + message); }
    static bool SkipProfiler() => false;
    static int Main()
    {
        var assembly = typeof(Plugin).Assembly;
        string[] active = assembly.GetTypes().Where(t => t.GetCustomAttributes(false).Any(a => a.GetType().Name == "RunPatchesAttribute")).Select(t => t.Name).OrderBy(s => s).ToArray();
        Console.WriteLine("ACTIVE " + string.Join(", ", active));
        Assert(!active.Any(s => new[] {"StationStorageOpt", "ChargerOpt", "ReceiverOpt", "PCStateOpt", "EntityNeedsOpt"}.Contains(s)), "obsolete parallel station, power and assembler experiments remain inactive");
        var layer = Empty<DysonSphereLayer>(); layer.id = 1;
        var a = Empty<DysonNode>(); a.id = 1; a.sp = 7; a.layerId = 1;
        var b = Empty<DysonNode>(); b.id = 2; b.sp = 11; b.layerId = 1;
        var frame = Empty<DysonFrame>(); frame.id = 1; frame.spA = 3; frame.spB = 5; frame.nodeA = a; frame.nodeB = b;
        a.frames = new List<DysonFrame> {frame}; b.frames = new List<DysonFrame> {frame};
        layer.nodePool = new[] {null, a, b}; layer.nodeCursor = 3;
        layer.framePool = new[] {null, frame}; layer.frameCursor = 2;
        var shell = Empty<DysonShell>(); shell.id = 1; shell.nodecps = new[] {13};
        layer.shellPool = new[] {null, shell}; layer.shellCursor = 2;
        layer.totalNodeSP = 18; layer.totalFrameSP = 8; layer.totalCP = 13;
        var sphere = Empty<DysonSphere>(); sphere.layersSorted = new DysonSphereLayer[10]; sphere.layersSorted[0] = layer;
        sphere.energyGenPerNode = 17; sphere.energyGenPerFrame = 19; sphere.energyGenPerShell = 23; sphere.energyGenPerSail = 29;
        sphere.swarm = Empty<DysonSwarm>(); sphere.swarm.sailCursor = 2;
        var data = Empty<GameData>(); var sector = Empty<SpaceSector>(); Set(data, "spaceSector", sector);
        var hive = Empty<EnemyDFHiveSystem>();
        var gammaType = AccessTools.Field(typeof(EnemyDFHiveSystem), "gammas").FieldType;
        var gammas = FormatterServices.GetUninitializedObject(gammaType); Set(gammas, "cursor", 11); Set(gammas, "recycleCursor", 0); Set(hive, "gammas", gammas);
        sector.dfHives = new[] {hive}; sphere.gameData = data; sphere.starData = new StarData {index = 0};
        var profiler = new Harmony("phase14.profiler.environment");
        foreach (var method in typeof(DeepProfiler).GetMethods(BindingFlags.Public | BindingFlags.NonPublic | BindingFlags.Static))
            if (method.Name == "BeginSample" || method.Name == "EndSample")
                profiler.Patch(method, prefix: new HarmonyMethod(typeof(Check), "SkipProfiler"));
        sphere.needRecalculatePower = true; sphere.BeforeGameTick(1);
        long native = sphere.energyGenCurrentTick, original = sphere.energyGenOriginalCurrentTick;
        var patch = assembly.GetType("DSPOptimizations.DysonNodeOpt+Patch");
        var harmony = new Harmony("phase14.native.check");
        harmony.Patch(AccessTools.Method(typeof(DysonSphere), "BeforeGameTick"), transpiler: new HarmonyMethod(AccessTools.Method(patch, "SpherePowerPatch")));
        sphere.needRecalculatePower = true; sphere.BeforeGameTick(2);
        Assert(sphere.energyGenCurrentTick == native && sphere.energyGenOriginalCurrentTick == original,
               "actual optimized native Dyson energy equals vanilla including swarm and dark fog debuff");
        sphere.needRecalculatePower = false; sphere.energyReqCurrentTick = 123; sphere.BeforeGameTick(3);
        Assert(sphere.energyGenCurrentTick == native && sphere.energyReqCurrentTick == 0,
               "native power cache and demand reset remain intact");
        harmony.UnpatchSelf(); profiler.UnpatchSelf();
        var plugin = Empty<Plugin>(); var stream = new MemoryStream();
        ((crecheng.DSPModSave.IModCanSave)plugin).Export(new BinaryWriter(stream));
        Assert(stream.Length == 4 && BitConverter.ToInt32(stream.ToArray(), 0) == 2, "existing version-2 save bytes unchanged");
        return 0;
    }
}
