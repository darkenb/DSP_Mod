# Related mod references - starfi5h-LossyCompression

Full related-mod packages are intentionally omitted. Project URLs, versions, exact local assembly hashes and targeted source files are supplied under `References/`. Upstream HEAD may differ from the locally modified snapshot. Build/runtime dependencies remain external prerequisites.

The source links below point to files actually present in this ZIP. Original line numbers and short excerpts are retained. A shared native integration point does not imply a direct DLL dependency.

## CommonAPI-DSPModSave

[Project identity and versions](References/CommonAPI-DSPModSave/reference.json) | [Reference notes](References/CommonAPI-DSPModSave/README.md)

Upstream: https://github.com/kremnev8/DSP-Mods/tree/master/Mods/DSPModSave

- **declared_hard_dependency**: Plugin-level dependency declaration; this may belong to an optional compatibility plugin.
- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Code in this mod

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs) - original line 11

```csharp

[BepInPlugin("starfi5h.plugin.LossyCompression", "LossyCompression", "0.3.10")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("com.Selsion.DSPOptimizations", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
```

[Source/EarlierWorkingSource/Plugin.cs](Source/EarlierWorkingSource/Plugin.cs) - original line 12

```csharp
{
    [BepInPlugin(GUID, NAME, VERSION)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [BepInDependency(ModCompatibility.DSPOptimizations.GUID, BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency(ModCompatibility.NebulaAPI.GUID, BepInDependency.DependencyFlags.SoftDependency)]
```

### Code in the related reference

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs) - original line 15

```csharp
namespace crecheng.DSPModSave;

[BepInPlugin("crecheng.DSPModSave", "DSP Mod Save", "1.2.3")]
public class DSPModSavePlugin : BaseUnityPlugin
{
```

[References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs](References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs) - original line 25

```csharp
        string path = Path.Combine(root, "sample.moddsv");
        var sample = new SaveSample();
        var settingsType = typeof(DSPModSavePlugin).Assembly.GetType("crecheng.DSPModSave.ModSaveSettings");
        var settings = Activator.CreateInstance(settingsType, true);
        AccessTools.Field(settingsType, "mod").SetValue(settings, sample);
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs) - original line 22

```csharp
    public class DSPModSavePlugin : BaseUnityPlugin
    {
        public const string MODGUID = "crecheng.DSPModSave";
        public const string MODNAME = "DSP Mod Save";
        public const string MODID = "DSPModSave";
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs) - original line 12

```csharp
	private static void EnterGame()
	{
		DSPModSavePlugin.logger.LogInfo("Enter New Game");
		foreach (ModSaveSettings value in DSPModSavePlugin.allModData.Values)
		{
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs) - original line 13

```csharp
		if (__result)
		{
			DSPModSavePlugin.OnSave(saveName);
		}
	}
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs) - original line 12

```csharp
        static void EnterGame()
        {
            DSPModSavePlugin.logger.LogInfo("Enter New Game");
            foreach (var d in DSPModSavePlugin.allModData.Values)
            {
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs) - original line 14

```csharp
            if (!__result) return;

            DSPModSavePlugin.OnSave(saveName);
        }

```

## Galactic_Scale-GalacticScale

[Project identity and versions](References/Galactic_Scale-GalacticScale/reference.json) | [Reference notes](References/Galactic_Scale-GalacticScale/README.md)

Upstream: https://github.com/Touhma/DSP_Plugins

- **fix_integration_context**: The cargo codec fallback protects paths on enlarged modded planets from coordinate/run-marker collisions.

### Code in this mod

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/CargoPathCompress.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/CargoPathCompress.cs) - original line 26

```csharp
		{
			float x = path.pointPos[i].x;
			if (x > 9999f || float.IsNaN(x) || float.IsInfinity(x))
			{
				return false;
```

[Evidence/InitialPhase/check.cs](Evidence/InitialPhase/check.cs) - original line 46

```csharp
               "actual native legacy reverse-import retains large geometry, cargo and topology");
        harmony.UnpatchSelf();
        path.pointPos[0].x = 9999; path.pointPos[1].x = -10001;
        Assert((bool)Call(cargoType, "CanEncode", path), "ordinary and negative large coordinates retain existing codec eligibility");
        var bad = new MemoryStream(); var w = new BinaryWriter(bad); w.Write(2); w.Write(3); bad.Position = 0;
```

[Source/EarlierWorkingSource/CargoPathCompress.cs](Source/EarlierWorkingSource/CargoPathCompress.cs) - original line 26

```csharp
            {
                float x = path.pointPos[i].x;
                if (x > 9999f || float.IsNaN(x) || float.IsInfinity(x)) return false;
            }
            return true;
```

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs) - original line 39

```csharp
		ConfigEntry<bool> configEntry2 = base.Config.Bind("Advance", "LazyLoad", defaultValue: true, "Delay generation of shell model until viewing\n延迟载入戴森壳的模型");
		ConfigEntry<bool> configEntry3 = base.Config.Bind("Advance", "ReduceRAM", defaultValue: false, "Release models generated by lazy load for vanilla game save to reduce RAM usage.\n不保留延迟载入在保存原版存档时生成的模型。可减少内存占用");
		ConfigEntry<bool> configEntry4 = base.Config.Bind("Dependent", "CargoPath", defaultValue: false, "Lossy compress for belts & cargo (will change vanilla save)\n有损压缩传送带数据（将更改原档）");
		ConfigEntry<bool> configEntry5 = base.Config.Bind("Independent", "DysonShell", defaultValue: true, "Lossless compress for dyson shells\n无损压缩戴森壳面");
		ConfigEntry<bool> configEntry6 = base.Config.Bind("Independent", "DysonSwarm", defaultValue: true, "Lossy compress for dyson swarm\n有损压缩太阳帆");
```

[Source/EarlierWorkingSource/DebugPatch.cs](Source/EarlierWorkingSource/DebugPatch.cs) - original line 26

```csharp

                // cargo
                //TestCargoPath();
            }
            if (Input.GetKeyDown(KeyCode.F9))
```

[Source/EarlierWorkingSource/Plugin.cs](Source/EarlierWorkingSource/Plugin.cs) - original line 36

```csharp
            var LazyLoad = Config.Bind<bool>("Advance", "LazyLoad", true, "Delay generation of shell model until viewing\n延迟载入戴森壳的模型");
            var ReduceRAM = Config.Bind<bool>("Advance", "ReduceRAM", false, "Release models generated by lazy load for vanilla game save to reduce RAM usage.\n不保留延迟载入在保存原版存档时生成的模型。可减少内存占用");
            var CargoPath = Config.Bind<bool>("Dependent", "CargoPath", false, "Lossy compress for belts & cargo (will change vanilla save)\n有损压缩传送带数据（将更改原档）");
            var DysonShell = Config.Bind<bool>("Independent", "DysonShell", true, "Lossless compress for dyson shells\n无损压缩戴森壳面");
            var DysonSwarm = Config.Bind<bool>("Independent", "DysonSwarm", true, "Lossy compress for dyson swarm\n有损压缩太阳帆");
```

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/DysonSwarmCompress.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/DysonSwarmCompress.cs) - original line 210

```csharp
			ref SailOrbit reference = ref dysonSwarm.orbits[num];
			ref DysonSail reference2 = ref dysonSwarm.sailPoolForSave[i];
			VectorLF3 a = VectorLF3.Cross(reference.up, RandomTable.SphericNormal(ref seed, 1.0)).normalized * reference.radius;
			a += RandomTable.SphericNormal(ref seed2, 200.0);
			reference2.st = num;
```

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/LazyLoading.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/LazyLoading.cs) - original line 288

```csharp
				}
				Vector3 vector2 = (1f - num6 - num7) * zero + num6 * pos + num7 * vector;
				vector2 = __instance.orbitRadius * vector2.normalized;
				Vector3 vector3 = __instance.currentRotation * (Vector3.Cross(vector2, Vector3.up) * __instance.orbitAngularSpeed * (MathF.PI / 180f));
				vector2 = __instance.currentRotation * vector2;
```

### Code in the related reference

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Models/Themes/GSTheme.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Models/Themes/GSTheme.cs) - original line 883

```csharp
        //          //atmosMat.SetColor("_Color", Color.red);//: { r: 0.3443396, g: 0.734796, b: 1, a: 1}

        //          //atmosMat.SetColor("_Color0", Color.clear);//Outer atmosphere viewed from space : { r: 0.3899999, g: 0.488919, b: 1, a: 1}
        //          //atmosMat.SetColor("_Color1", Color.clear);//Closer... : { r: 0, g: 0.7073908, b: 1, a: 1}
        //          //atmosMat.SetColor("_Color2", Color.clear);//Closer...: { r: 0.2117646, g: 0.8043795, b: 0.9607843, a: 1}
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Models/Veges/VegeTypesDictionary.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Models/Veges/VegeTypesDictionary.cs) - original line 38

```csharp

            GS2.Warn("Vege ID for " + s + " not found");
            return 9999;
        }

```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/GameData/GetNearestStarPlanet.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/GameData/GetNearestStarPlanet.cs) - original line 19

```csharp
            }

            // double num = 3239999.9141693115;
            var num2 = 900.0;
            if (nearestStar != null)
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/GuideMissionStandardMode/CalculateCurve.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/GuideMissionStandardMode/CalculateCurve.cs) - original line 335

```csharp
            var num4 = (float)((360.0 - Vector3.Angle(-DirectionBetweenPlanets, DirectionBetweenStarAndPlanet)) * 0.400000005960464);
            var num5 = num4 + num4 * 0.400000005960464;
            var num6 = (float)(num4 * (Math.PI / 180.0) * MoonAvoidDistance * 0.349999994039536);
            var vectorLf3_3 = Maths.QRotateLF(Quaternion.AngleAxis(num4 * Sign, OrbitDirection), v);
            var vectorLf3_4 = vectorLf3_3.normalized * MoonAvoidDistance + uPositionOfFlyByPlanet - (VectorLF3)OrbitDirection * MoonAvoidDistance * 0.5 * Mathf.Clamp01(num4 / 120f);
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/Transpilers/DFRelayComponent/RelaySailLogic.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/Transpilers/DFRelayComponent/RelaySailLogic.cs) - original line 658

```csharp

// 	/* 0x00046A71 1107         */ IL_02E9: ldloc.s   V_7
// 	/* 0x00046A73 239A9999999999E93F */ IL_02EB: ldc.r8    0.8
// 	/* 0x00046A7C 5A           */ IL_02F4: mul
// 	/* 0x00046A7D 23000000000000F03F */ IL_02F5: ldc.r8    1
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/Transpilers/PlanetSizeTranspiler/DetermineCraftAstroIdTranspiler.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/Transpilers/PlanetSizeTranspiler/DetermineCraftAstroIdTranspiler.cs) - original line 21

```csharp
        // are byte-identical (0.10.34.28529); one transpiler serves both.
        //
        // ENTER site: `dist < 1619999.957...` where dist (loc.1) was written by
        // SpaceSector.GetNearestStar and loc.0 holds that StarData - replace
        // the constant with `ldloc.0; call GetCraftAstroEnterMeters`.
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/Transpilers/StationComponent/InternalTickRemote.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/Transpilers/StationComponent/InternalTickRemote.cs) - original line 1830

```csharp
// 		/* 0x0008FE0C 112D         */ IL_0ED0: ldloc.s   V_45
// 		/* 0x0008FE0E 6C           */ IL_0ED2: conv.r8
// 		/* 0x0008FE0F 239A9999999999E13F */ IL_0ED3: ldc.r8    0.55
// 		/* 0x0008FE18 5A           */ IL_0EDC: mul
// 		/* 0x0008FE19 58           */ IL_0EDD: add
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/Transpilers/TrashSystem/TrashSystemTranspiler.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/Transpilers/TrashSystem/TrashSystemTranspiler.cs) - original line 54

```csharp
                //    VectorLF3 vectorLF8 = vectorLF5 + vectorLF7;
                //    trash.uPos = this.astroPoses[i].uPos + normalized * (num6 + 0.005);
                //    trash.uVel = vectorLF7 * 0.3499999940395355 + vectorLF8 * 0.925000011920929 + vectorLF4;
                //    trash.lPos = vectorLF3; // Insert this line
                // }
```

## Selsion-DSPOptimizations

[Project identity and versions](References/Selsion-DSPOptimizations/reference.json) | [Reference notes](References/Selsion-DSPOptimizations/README.md)

Upstream: https://github.com/Selsion/DSPMods/tree/main/DSPOptimizations

- **declared_soft_dependency**: Plugin-level dependency declaration; this may belong to an optional compatibility plugin.
- **fix_integration_context**: Legacy low-resolution shell restore and after-import counter updates are part of the shared serialization path.

### Code in this mod

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/ModCompatibility.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/ModCompatibility.cs) - original line 40

```csharp
	public static class DSPOptimizations
	{
		public const string GUID = "com.Selsion.DSPOptimizations";

		public static void Init(Harmony harmony)
```

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs) - original line 12

```csharp
[BepInPlugin("starfi5h.plugin.LossyCompression", "LossyCompression", "0.3.10")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("com.Selsion.DSPOptimizations", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
public class Plugin : BaseUnityPlugin, IModCanSave
```

[Source/EarlierWorkingSource/ModCompatibility.cs](Source/EarlierWorkingSource/ModCompatibility.cs) - original line 71

```csharp
        public static class DSPOptimizations
        {
            public const string GUID = "com.Selsion.DSPOptimizations";

            public static void Init(Harmony harmony)
```

[Source/EarlierWorkingSource/Plugin.cs](Source/EarlierWorkingSource/Plugin.cs) - original line 151

```csharp
                DysonSwarmCompress.Import(r);

                if (ModCompatibility.AfeterImport != null)
                {
                    Log.Info("Processing compatibility process...");
```

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/DysonShellCompress.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/DysonShellCompress.cs) - original line 12

```csharp
namespace LossyCompression;

internal class DysonShellCompress
{
	public static readonly int EncodedVersion = 2;
```

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/LazyLoading.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/LazyLoading.cs) - original line 76

```csharp
		{
			dysonSphereMasks[___dysonSphere] |= editorMask | gameMask;
			DysonShellCompress.GenerateModel(viewingSphere, dysonSphereMasks[___dysonSphere]);
			if (dysonSphereMasks[___dysonSphere] == -1)
			{
```

[Evidence/InitialPhase/check.cs](Evidence/InitialPhase/check.cs) - original line 54

```csharp
        try { Call(cargoType, "Decode", path, new BinaryReader(bad)); throw new Exception("unanchored run accepted"); }
        catch (TargetInvocationException e) { Assert(e.InnerException is InvalidDataException, "run without an initial point rejected before geometry mutation"); }
        var shell = Empty<DysonShell>(); shell.id = 1; shell.protoId = 2; shell.randSeed = 17;
        shell.nodes = new List<DysonNode> {new DysonNode {id = 1}, new DysonNode {id = 2}};
        shell.nodecps = new[] {7,11,18}; shell.vertsqOffset = new[] {0, 4, 9}; shell.vertexCount = 9; shell.cpPerVertex = 2;
```

[Source/EarlierWorkingSource/DebugPatch.cs](Source/EarlierWorkingSource/DebugPatch.cs) - original line 17

```csharp
            if (Input.GetKeyDown(KeyCode.F8))
            {
                DysonShellCompress.IsMultithread = !DysonShellCompress.IsMultithread;
                Log.Info($"DysonShellCompress.IsMultithread: {DysonShellCompress.IsMultithread}");
            }
```

### Code in the related reference

[References/Selsion-DSPOptimizations/Code/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/Plugin.cs](References/Selsion-DSPOptimizations/Code/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/Plugin.cs) - original line 10

```csharp
namespace DSPOptimizations;

[BepInPlugin("com.Selsion.DSPOptimizations", "DSPOptimizations", "1.1.21")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class Plugin : BaseUnityPlugin, IModCanSave
```

[References/Selsion-DSPOptimizations/Code/Source/EarlierWorkingSource/Plugin.cs](References/Selsion-DSPOptimizations/Code/Source/EarlierWorkingSource/Plugin.cs) - original line 21

```csharp
    public class Plugin : BaseUnityPlugin, IModCanSave
    {
        public const string MOD_GUID = "com.Selsion.DSPOptimizations";
        public const string MOD_NAME = "DSPOptimizations";
        public const string MOD_VERSION = "1.1.21";
```

[References/Selsion-DSPOptimizations/Code/Source/Reconstructed/patchers/DSPOptimizationsPreloader/DSPOptimizations/Preloader.cs](References/Selsion-DSPOptimizations/Code/Source/Reconstructed/patchers/DSPOptimizationsPreloader/DSPOptimizations/Preloader.cs) - original line 32

```csharp
	{
		TypeSystem typeSystem = assembly.MainModule.TypeSystem;
		GetType(assembly, "DysonShell")?.AddField("vertsqOffset_lowRes", typeSystem.Int32.MakeArrayType())?.AddField("radius_lowRes", typeSystem.Single)?.AddField("surfaceAreaUnitSphere", typeSystem.Single);
		GetType(assembly, "DysonSphereLayer")?.AddField("radius_lowRes", typeSystem.Single)?.AddField("surfaceAreaUnitSphere", typeSystem.Single)?.AddField("totalNodeSP", typeSystem.Int64)?.AddField("totalFrameSP", typeSystem.Int64)?.AddField("totalCP", typeSystem.Int64);
		GetType(assembly, "DysonSphereSegmentRenderer")?.AddField("layersDirtyMask", typeSystem.Int32.MakeArrayType());
```

[References/Selsion-DSPOptimizations/Code/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/DysonNodeOpt.cs](References/Selsion-DSPOptimizations/Code/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/DysonNodeOpt.cs) - original line 47

```csharp

		[HarmonyPostfix]
		[HarmonyPatch(typeof(DysonShell), "Construct")]
		public static void DysonShell_Construct_Postfix(DysonShell __instance, bool __result)
		{
```

[References/Selsion-DSPOptimizations/Code/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/LowResShellsLegacySupport.cs](References/Selsion-DSPOptimizations/Code/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/LowResShellsLegacySupport.cs) - original line 17

```csharp
		public static void ResetShellUpdateListPatch()
		{
			shellsToUpdate = new List<DysonShell>();
		}

```

[References/Selsion-DSPOptimizations/Code/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/LowResShellsSaveManager.cs](References/Selsion-DSPOptimizations/Code/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/LowResShellsSaveManager.cs) - original line 161

```csharp
						for (int k = 1; k < dysonSphereLayer.shellCursor; k++)
						{
							DysonShell dysonShell = dysonSphereLayer.shellPool[k];
							if (dysonShell != null && dysonShell.id == k)
							{
```

[References/Selsion-DSPOptimizations/Code/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/ShellShaderVarOpt.cs](References/Selsion-DSPOptimizations/Code/Source/Reconstructed/plugins/DSPOptimizations/DSPOptimizations/ShellShaderVarOpt.cs) - original line 15

```csharp
	private class Patch
	{
		[HarmonyPatch(typeof(DysonShell), "GenerateModelObjects")]
		public static void ShellMatInitPostfix(DysonShell __instance)
		{
```

[References/Selsion-DSPOptimizations/Code/Evidence/InitialPhase/check.cs](References/Selsion-DSPOptimizations/Code/Evidence/InitialPhase/check.cs) - original line 33

```csharp
        layer.nodePool = new[] {null, a, b}; layer.nodeCursor = 3;
        layer.framePool = new[] {null, frame}; layer.frameCursor = 2;
        var shell = Empty<DysonShell>(); shell.id = 1; shell.nodecps = new[] {13};
        layer.shellPool = new[] {null, shell}; layer.shellCursor = 2;
        layer.totalNodeSP = 18; layer.totalFrameSP = 8; layer.totalCP = 13;
```

## nebula-NebulaMultiplayerModApi

[Project identity and versions](References/nebula-NebulaMultiplayerModApi/reference.json) | [Reference notes](References/nebula-NebulaMultiplayerModApi/README.md)

Upstream: https://github.com/NebulaModTeam/nebula

- **declared_soft_dependency**: Plugin-level dependency declaration; this may belong to an optional compatibility plugin.
- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Code in this mod

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/ModCompatibility.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/ModCompatibility.cs) - original line 89

```csharp
	public static class NebulaAPI
	{
		public const string GUID = "dsp.nebula-multiplayer-api";

		public static void Init(Harmony harmony)
```

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs) - original line 13

```csharp
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("com.Selsion.DSPOptimizations", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
public class Plugin : BaseUnityPlugin, IModCanSave
{
```

[Source/EarlierWorkingSource/ModCompatibility.cs](Source/EarlierWorkingSource/ModCompatibility.cs) - original line 128

```csharp
        public static class NebulaAPI
        {
            public const string GUID = "dsp.nebula-multiplayer-api";

            public static void Init(Harmony harmony)
```

[Source/EarlierWorkingSource/Plugin.cs](Source/EarlierWorkingSource/Plugin.cs) - original line 14

```csharp
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [BepInDependency(ModCompatibility.DSPOptimizations.GUID, BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency(ModCompatibility.NebulaAPI.GUID, BepInDependency.DependencyFlags.SoftDependency)]
    public class Plugin : BaseUnityPlugin, IModCanSave
    {
```

### Code in the related reference

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs) - original line 13

```csharp
namespace NebulaAPI;

[BepInPlugin("dsp.nebula-multiplayer-api", "NebulaMultiplayerModApi", "2.1.0.7")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class NebulaModAPI : BaseUnityPlugin
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/ConcurrentPlayerCollection.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/ConcurrentPlayerCollection.cs) - original line 116

```csharp
	{
		List<IPlayerData> list = playerCollections[EConnectionStatus.Connected].Select((KeyValuePair<INebulaConnection, INebulaPlayer> p) => p.Value.Data).ToList();
		if (!NebulaModAPI.MultiplayerSession.IsDedicated)
		{
			list.Add(NebulaModAPI.MultiplayerSession.LocalPlayer.Data);
```

[References/nebula-NebulaMultiplayerModApi/Code/Evidence/InitialPhase/check.cs](References/nebula-NebulaMultiplayerModApi/Code/Evidence/InitialPhase/check.cs) - original line 9

```csharp
    static int Main()
    {
        NebulaModAPI.OnMultiplayerSessionChange(false);
        if (NebulaModAPI.IsMultiplayerActive || NebulaModAPI.MultiplayerSession != null) throw new Exception("Inactive API retained session");
        var value = new Float3(1, 2, 3);
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.GameState/INebulaPlayer.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.GameState/INebulaPlayer.cs) - original line 7

```csharp
public interface INebulaPlayer
{
	INebulaConnection Connection { get; set; }

	IPlayerData Data { get; set; }
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.GameState/INetworkProvider.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.GameState/INetworkProvider.cs) - original line 22

```csharp
	void SendPacketToStar<T>(T packet, int starId) where T : class, new();

	void SendPacketExclude<T>(T packet, INebulaConnection exclude) where T : class, new();

	void SendPacketToStarExclude<T>(T packet, int starId, INebulaConnection exclude) where T : class, new();
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.Networking/INebulaConnection.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.Networking/INebulaConnection.cs) - original line 5

```csharp
namespace NebulaAPI.Networking;

public interface INebulaConnection : IEquatable<INebulaConnection>
{
	bool IsAlive { get; }
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.Packets/BasePacketProcessor.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.Packets/BasePacketProcessor.cs) - original line 16

```csharp
	}

	public abstract void ProcessPacket(T packet, INebulaConnection conn);
}
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.Interfaces/IWriterProvider.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.Interfaces/IWriterProvider.cs) - original line 6

```csharp
namespace NebulaAPI.Interfaces;

public interface IWriterProvider : IDisposable
{
	BinaryWriter BinaryWriter { get; }
```

## starfi5h-SphereEditorTools

[Project identity and versions](References/starfi5h-SphereEditorTools/reference.json) | [Reference notes](References/starfi5h-SphereEditorTools/README.md)

Upstream: https://github.com/starfi5h/DSP_Mod

- **fix_integration_context**: Shell rebuild/paint restoration retains native shell serialization consumed by the codec; live combined acceptance remains outstanding.

### Code in this mod

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/DysonShellCompress.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/DysonShellCompress.cs) - original line 12

```csharp
namespace LossyCompression;

internal class DysonShellCompress
{
	public static readonly int EncodedVersion = 2;
```

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/LazyLoading.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/LazyLoading.cs) - original line 76

```csharp
		{
			dysonSphereMasks[___dysonSphere] |= editorMask | gameMask;
			DysonShellCompress.GenerateModel(viewingSphere, dysonSphereMasks[___dysonSphere]);
			if (dysonSphereMasks[___dysonSphere] == -1)
			{
```

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/ModCompatibility.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/ModCompatibility.cs) - original line 61

```csharp

		[HarmonyPrefix]
		[HarmonyPatch(typeof(DysonShell), "SetMaterialDynamicVars")]
		public static bool SetMaterialDynamicVars(DysonShell __instance)
		{
```

[Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs](Source/Reconstructed/plugins/LossyCompression/LossyCompression/Plugin.cs) - original line 40

```csharp
		ConfigEntry<bool> configEntry3 = base.Config.Bind("Advance", "ReduceRAM", defaultValue: false, "Release models generated by lazy load for vanilla game save to reduce RAM usage.\n不保留延迟载入在保存原版存档时生成的模型。可减少内存占用");
		ConfigEntry<bool> configEntry4 = base.Config.Bind("Dependent", "CargoPath", defaultValue: false, "Lossy compress for belts & cargo (will change vanilla save)\n有损压缩传送带数据（将更改原档）");
		ConfigEntry<bool> configEntry5 = base.Config.Bind("Independent", "DysonShell", defaultValue: true, "Lossless compress for dyson shells\n无损压缩戴森壳面");
		ConfigEntry<bool> configEntry6 = base.Config.Bind("Independent", "DysonSwarm", defaultValue: true, "Lossy compress for dyson swarm\n有损压缩太阳帆");
		enableFlags += (configEntry4.Value ? 1 : 0);
```

[Evidence/InitialPhase/check.cs](Evidence/InitialPhase/check.cs) - original line 54

```csharp
        try { Call(cargoType, "Decode", path, new BinaryReader(bad)); throw new Exception("unanchored run accepted"); }
        catch (TargetInvocationException e) { Assert(e.InnerException is InvalidDataException, "run without an initial point rejected before geometry mutation"); }
        var shell = Empty<DysonShell>(); shell.id = 1; shell.protoId = 2; shell.randSeed = 17;
        shell.nodes = new List<DysonNode> {new DysonNode {id = 1}, new DysonNode {id = 2}};
        shell.nodecps = new[] {7,11,18}; shell.vertsqOffset = new[] {0, 4, 9}; shell.vertexCount = 9; shell.cpPerVertex = 2;
```

[Source/EarlierWorkingSource/DebugPatch.cs](Source/EarlierWorkingSource/DebugPatch.cs) - original line 17

```csharp
            if (Input.GetKeyDown(KeyCode.F8))
            {
                DysonShellCompress.IsMultithread = !DysonShellCompress.IsMultithread;
                Log.Info($"DysonShellCompress.IsMultithread: {DysonShellCompress.IsMultithread}");
            }
```

[Source/EarlierWorkingSource/DysonShellCompress.cs](Source/EarlierWorkingSource/DysonShellCompress.cs) - original line 12

```csharp
namespace LossyCompression
{
    class DysonShellCompress
    {
        // Remove all shell data in original, save the necessary data for reconstruction in .moddsv
```

[Source/EarlierWorkingSource/DysonSwarmCompress.cs](Source/EarlierWorkingSource/DysonSwarmCompress.cs) - original line 80

```csharp
                PerformanceMonitor.dataLengths[(int)ESaveDataEntry.Total] += datalen;
                PerformanceMonitor.dataLengths[(int)ESaveDataEntry.DysonSphere] += datalen;
                PerformanceMonitor.dataLengths[(int)ESaveDataEntry.DysonShell] += datalen;
                Log.Info($"Decompress DysonSwarm: {datalen:N0} bytes {stopWatch.duration}s");
            }
```

### Code in the related reference

[References/starfi5h-SphereEditorTools/Code/Source/Reconstructed/plugins/SphereEditorTools/SphereEditorTools/EditOrbit.cs](References/starfi5h-SphereEditorTools/Code/Source/Reconstructed/plugins/SphereEditorTools/SphereEditorTools/EditOrbit.cs) - original line 190

```csharp
		for (int i = 0; i < layer.shellCursor; i++)
		{
			DysonShell dysonShell = layer.shellPool[i];
			if (dysonShell == null || i != dysonShell.id)
			{
```

[References/starfi5h-SphereEditorTools/Code/Source/Reconstructed/plugins/SphereEditorTools/SphereEditorTools/SymmetryTool.cs](References/starfi5h-SphereEditorTools/Code/Source/Reconstructed/plugins/SphereEditorTools/SphereEditorTools/SymmetryTool.cs) - original line 559

```csharp
	[HarmonyPrefix]
	[HarmonyPatch(typeof(DESelection), "OnShellClick")]
	public static bool Overwrite_OnFrameClick(DESelection __instance, DysonShell shell)
	{
		if (!overwrite || shell == null)
```

[References/starfi5h-SphereEditorTools/Code/Source/EarlierWorkingSource/EditOrbit.cs](References/starfi5h-SphereEditorTools/Code/Source/EarlierWorkingSource/EditOrbit.cs) - original line 179

```csharp
            for (int sid = 0; sid < layer.shellCursor; sid++)
            {
                DysonShell shell = layer.shellPool[sid];
                if (shell == null || sid != shell.id)
                    continue;
```

[References/starfi5h-SphereEditorTools/Code/Source/EarlierWorkingSource/SymmetryTool.cs](References/starfi5h-SphereEditorTools/Code/Source/EarlierWorkingSource/SymmetryTool.cs) - original line 521

```csharp

        [HarmonyPrefix, HarmonyPatch(typeof(DESelection), "OnShellClick")]
        public static bool Overwrite_OnFrameClick(DESelection __instance, DysonShell shell)
        {
            if (!overwrite || shell == null)
```
