# Related mod references - starfi5h-StatsUITweaks

Full related-mod packages are intentionally omitted. Project URLs, versions, exact local assembly hashes and targeted source files are supplied under `References/`. Upstream HEAD may differ from the locally modified snapshot. Build/runtime dependencies remain external prerequisites.

The source links below point to files actually present in this ZIP. Original line numbers and short excerpts are retained. A shared native integration point does not imply a direct DLL dependency.

## CommonAPI-CommonAPI

[Project identity and versions](References/CommonAPI-CommonAPI/reference.json) | [Reference notes](References/CommonAPI-CommonAPI/README.md)

Upstream: https://github.com/kremnev8/CommonAPI

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/BaseSubmodule.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/BaseSubmodule.cs) - original line 18

```csharp
		{
			string name = GetType().Name;
			throw new InvalidOperationException(name + " is not loaded. Please use [CommonAPISubmoduleDependency(nameof(" + name + ")]");
		}
	}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 16

```csharp
namespace CommonAPI;

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPISubmoduleDependency.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPISubmoduleDependency.cs) - original line 6

```csharp

[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
public class CommonAPISubmoduleDependency : Attribute
{
	public string?[]? SubmoduleNames { get; }
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ConfigFileExtension.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ConfigFileExtension.cs) - original line 33

```csharp
				entry.SetSerializedValue(item.Value);
				list.Add(item.Key);
				CommonAPIPlugin.logger.LogInfo("Migrating config from " + oldSection + ":" + key + " to " + newSection + ":" + key);
			}
		}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/HarmonyRegisterExtension.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/HarmonyRegisterExtension.cs) - original line 31

```csharp
			else
			{
				CommonAPIPlugin.logger.LogInfo("Failed to patch: " + item.FullName + ".");
			}
		}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ItemProtoExtenstion.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ItemProtoExtenstion.cs) - original line 17

```csharp
			{
				RecipeProto recipeProto = LDB.recipes.Select(proto.maincraft.ID);
				CommonAPIPlugin.logger.LogInfo($"Changing recipe icon: {recipeProto != null}");
				recipeProto.IconPath = "";
				recipeProto._iconSprite = iconSprite;
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/LoadSaveOnLoad.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/LoadSaveOnLoad.cs) - original line 42

```csharp
		{
			DSPGame.LoadFile = saveName;
			CommonAPIPlugin.logger.LogInfo("Loading save " + saveName + " by default!");
		}
	}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs) - original line 14

```csharp
[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
{
```

### Dependency reference code

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 24

```csharp
[BepInPlugin("org.LoShin.GenesisBook", "GenesisBook", "3.2.6")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/TextureResourcesPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/TextureResourcesPatches.cs) - original line 15

```csharp
		typeof(Type)
	})]
	[HarmonyBefore(new string[] { "dsp.common-api.CommonAPI" })]
	[HarmonyPrefix]
	public static bool GetAssemblyManifestResource(ref string path, Type systemTypeInstance, ref UnityEngine.Object __result)
```

[References/HiddenCirno-GenesisBook/Code/Evidence/InitialPhase/check.cs](References/HiddenCirno-GenesisBook/Code/Evidence/InitialPhase/check.cs) - original line 56

```csharp
            Assert(result == mapping.Item2, "Item/building/drop/custom-tab page mapping");
        }
        Console.WriteLine("PASS: native Item/Building/Drop and CommonAPI custom-tab pick pages.");
    }
    static void SaveFixtures(string directory) {
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs) - original line 19

```csharp

[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
```

[References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs) - original line 19

```csharp

[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
```

[References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/MoreMegaStructure.cs) - original line 24

```csharp
{
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(CommonAPIPlugin.GUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [CommonAPISubmoduleDependency(nameof(ProtoRegistry), nameof(TabSystem), nameof(LocalizationModule))]
```

## CommonAPI-DSPModSave

[Project identity and versions](References/CommonAPI-DSPModSave/reference.json) | [Reference notes](References/CommonAPI-DSPModSave/README.md)

Upstream: https://github.com/kremnev8/DSP-Mods/tree/master/Mods/DSPModSave

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs) - original line 15

```csharp
namespace crecheng.DSPModSave;

[BepInPlugin("crecheng.DSPModSave", "DSP Mod Save", "1.2.3")]
public class DSPModSavePlugin : BaseUnityPlugin
{
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs) - original line 12

```csharp
	private static void EnterGame()
	{
		DSPModSavePlugin.logger.LogInfo("Enter New Game");
		foreach (ModSaveSettings value in DSPModSavePlugin.allModData.Values)
		{
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs) - original line 13

```csharp
		if (__result)
		{
			DSPModSavePlugin.OnSave(saveName);
		}
	}
```

[References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs](References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs) - original line 19

```csharp
static class Check
{
    static void Call(string method, params object[] args) {AccessTools.Method(typeof(DSPModSavePlugin), method).Invoke(null, args);}
    static int Main()
    {
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs) - original line 20

```csharp
{
    [BepInPlugin(MODGUID, MODNAME, VERSION)]
    public class DSPModSavePlugin : BaseUnityPlugin
    {
        public const string MODGUID = "crecheng.DSPModSave";
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs) - original line 12

```csharp
        static void EnterGame()
        {
            DSPModSavePlugin.logger.LogInfo("Enter New Game");
            foreach (var d in DSPModSavePlugin.allModData.Values)
            {
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs) - original line 14

```csharp
            if (!__result) return;

            DSPModSavePlugin.OnSave(saveName);
        }

```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 18

```csharp
[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
{
```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 31

```csharp
    [BepInPlugin(GUID, DISPNAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
    {
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 23

```csharp

[BepInPlugin("org.LoShin.GenesisBook", "GenesisBook", "3.2.6")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/ProjectGenesis.cs) - original line 40

```csharp
{
    [BepInPlugin(MODGUID, MODNAME, VERSION)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [BepInDependency(CommonAPIPlugin.GUID)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs) - original line 20

```csharp
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
[BepInDependency("starfi5h.plugin.ModFixerOne", BepInDependency.DependencyFlags.HardDependency)]
```

[References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs) - original line 20

```csharp
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
[BepInDependency("starfi5h.plugin.ModFixerOne", BepInDependency.DependencyFlags.HardDependency)]
```

[References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/MoreMegaStructure.cs) - original line 25

```csharp
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(CommonAPIPlugin.GUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [CommonAPISubmoduleDependency(nameof(ProtoRegistry), nameof(TabSystem), nameof(LocalizationModule))]
    [BepInDependency("starfi5h.plugin.ModFixerOne")]
```

## Galactic_Scale-GalacticScale

[Project identity and versions](References/Galactic_Scale-GalacticScale/reference.json) | [Reference notes](References/Galactic_Scale-GalacticScale/README.md)

Upstream: https://github.com/Touhma/DSP_Plugins

- **fix_integration_context**: The selection guards operate on extended/modded astro lists supplied by the galaxy mod.

### Code in this mod

[Source/PortedWorkingSource/StatsUITweaks/Plugin.cs](Source/PortedWorkingSource/StatsUITweaks/Plugin.cs) - original line 52

```csharp
	{
		Log = base.Logger;
		orderByNameConfig = base.Config.Bind("AstroBox", "OrderByName", defaultValue: true, "Order list by system name.\n以星系名称排序列表");
		dropDownCountConfig = base.Config.Bind("AstroBox", "DropDownCount", 15, "Number of items shown in drop-down list.\n下拉列表显示的个数");
		systemPrefixConfig = base.Config.Bind("AstroBox", "SystemPrefix", "<color=yellow>", "Prefix string of star system in the list\n星系名称前缀");
```

[Source/PortedWorkingSource/StatsUITweaks/StatsWindowPatch.cs](Source/PortedWorkingSource/StatsUITweaks/StatsWindowPatch.cs) - original line 655

```csharp
			if (ListWidthOffeset > 0)
			{
				Reposition(__instance.productAstroBox.transform, __instance.productTimeBox.transform);
				if (ListWidthOffeset > 40)
				{
```

[Source/PortedWorkingSource/StatsUITweaks/UIChartAstroItemProductionPatch.cs](Source/PortedWorkingSource/StatsUITweaks/UIChartAstroItemProductionPatch.cs) - original line 7

```csharp
namespace StatsUITweaks;

public class UIChartAstroItemProductionPatch
{
	private static double[] lvDivisors = new double[5] { 1.0, 10.0, 60.0, 600.0, 6000.0 };
```

[Source/PortedWorkingSource/StatsUITweaks/Utils.cs](Source/PortedWorkingSource/StatsUITweaks/Utils.cs) - original line 26

```csharp
	public static KeyCode HotkeyListDown = KeyCode.PageDown;

	private static readonly Dictionary<int, int> astroIndex = new Dictionary<int, int>();

	private static readonly List<(string, int)> systemList = new List<(string, int)>();
```

[Source/Reconstructed/plugins/StatsUITweaks/StatsUITweaks/Plugin.cs](Source/Reconstructed/plugins/StatsUITweaks/StatsUITweaks/Plugin.cs) - original line 52

```csharp
	{
		Log = base.Logger;
		orderByNameConfig = base.Config.Bind("AstroBox", "OrderByName", defaultValue: true, "Order list by system name.\n以星系名称排序列表");
		dropDownCountConfig = base.Config.Bind("AstroBox", "DropDownCount", 15, "Number of items shown in drop-down list.\n下拉列表显示的个数");
		systemPrefixConfig = base.Config.Bind("AstroBox", "SystemPrefix", "<color=yellow>", "Prefix string of star system in the list\n星系名称前缀");
```

[Source/Reconstructed/plugins/StatsUITweaks/StatsUITweaks/StatsWindowPatch.cs](Source/Reconstructed/plugins/StatsUITweaks/StatsUITweaks/StatsWindowPatch.cs) - original line 658

```csharp
			if (ListWidthOffeset > 0)
			{
				Reposition(__instance.productAstroBox.transform, __instance.productTimeBox.transform);
				if (ListWidthOffeset > 40)
				{
```

[Source/Reconstructed/plugins/StatsUITweaks/StatsUITweaks/UIChartAstroItemProductionPatch.cs](Source/Reconstructed/plugins/StatsUITweaks/StatsUITweaks/UIChartAstroItemProductionPatch.cs) - original line 7

```csharp
namespace StatsUITweaks;

public class UIChartAstroItemProductionPatch
{
	private static double[] lvDivisors = new double[5] { 1.0, 10.0, 60.0, 600.0, 6000.0 };
```

[Source/Reconstructed/plugins/StatsUITweaks/StatsUITweaks/Utils.cs](Source/Reconstructed/plugins/StatsUITweaks/StatsUITweaks/Utils.cs) - original line 26

```csharp
	public static KeyCode HotkeyListDown = KeyCode.PageDown;

	private static readonly Dictionary<int, int> astroIndex = new Dictionary<int, int>();

	private static readonly List<(string, int)> systemList = new List<(string, int)>();
```

### Code in the related reference

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Bootstrap.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Bootstrap.cs) - original line 77

```csharp
                harmony.PatchAll(typeof(UnitComponentTranspiler));
                harmony.PatchAll(typeof(CombatShipPathingTranspiler));
                harmony.PatchAll(typeof(DetermineCraftAstroIdTranspiler));
                harmony.PatchAll(typeof(LagFixTranspiler));
                // Environment.SetEnvironmentVariable("MONOMOD_DMD_DUMP", "");
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Galaxy Generation/InitializeAstroPoses.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Galaxy Generation/InitializeAstroPoses.cs) - original line 7

```csharp
    public static partial class GS2
    {
        public static void CreateStarPlanetsAstroPoses(Random random)
        {
            var highStopwatch = new HighStopwatch();
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Galaxy Generation/ProcessGalaxy.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Galaxy Generation/ProcessGalaxy.cs) - original line 109

```csharp
                }

                // Log("Initializing AstroPoses");
                CreateStarPlanetsAstroPoses(random);
                var bs = galaxy.stars[galaxy.birthStarId - 1];
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/-Debug/Debug.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/-Debug/Debug.cs) - original line 297

```csharp
 //        public static bool RocketGameTick(ref DysonSphere __instance, int _usedThreadCnt, int _curThreadIdx, int _minimumMissionCnt)
	// {
	// 	AstroData[] astrosData = __instance.starData.galaxy.astrosData;
	// 	double timefactor = 0.016666666666666666;
	// 	float orbitRadiusFactor = Mathf.Max(1f, (float)Math.Pow((double)__instance.defOrbitRadius / 40000.0 * 4.0, 0.4));
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/DysonSphere/RocketGameTick.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/DysonSphere/RocketGameTick.cs) - original line 22

```csharp
                if (__instance == null || __instance.starData == null) return true;

                AstroData[] astrosData = __instance.starData.galaxy.astrosData;
                if (astrosData == null) return true;
                double num = 1.0 / 60.0;
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/EnemyDFHiveSystem/BirthPlanetRelaySetting.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/EnemyDFHiveSystem/BirthPlanetRelaySetting.cs) - original line 11

```csharp
        public static bool CheckRelayCoLandingConditionForBirthPlanet(
            EnemyDFHiveSystem __instance,
            int _astroId,
            ref bool __result)
        {
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/EnemyDFHiveSystem/Import.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/EnemyDFHiveSystem/Import.cs) - original line 23

```csharp
                    //----------------------------------------------------------------------------------------------------
                    // Line 54-61
                    // this.hiveOrbitIndex = this.hiveAstroId - 1000000 - (this.starData.id - 1) * 8 - 1;
                    //----------------------------------------------------------------------------------------------------
                    // /* 0x0009B9B3 02           */ IL_002B: ldarg.0
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/GalaxyData/UpdatePoses.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/GalaxyData/UpdatePoses.cs) - original line 17

```csharp
        /// orbitAroundPlanet.runtimePositionNext (read) - Parallel per star, so if this worked before, it should work now.
        /// star.uPosition (read) - Parallel per star, so if this worked before, it should work now.
        /// galaxy.astrosData[id].uPos (write) - Multiple threads writing to astrosData simultaneously, but each planet is only writing to its own portion of the array.
        /// galaxy.astrosData[id].uRot (write) - Multiple threads writing to astrosData simultaneously, but each planet is only writing to its own portion of the array.
        /// galaxy.astrosData[id].uPosNext (write) - Multiple threads writing to astrosData simultaneously, but each planet is only writing to its own portion of the array.
```

## HiddenCirno-GenesisBook

[Project identity and versions](References/HiddenCirno-GenesisBook/reference.json) | [Reference notes](References/HiddenCirno-GenesisBook/README.md)

Upstream: https://github.com/Awbugl/ProjectGenesis

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 30

```csharp
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
[ModSaveSettings(/*Could not decode attribute arguments.*/)]
public class ProjectGenesis : BaseUnityPlugin, IModCanSave, IMultiplayerModWithSettings, IMultiplayerMod
{
	public const string MODGUID = "org.LoShin.GenesisBook";
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GalacticScale.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GalacticScale.cs) - original line 19

```csharp
	internal const string GUID = "dsp.galactic-scale.2";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.dsp.galactic-scale.2");

	internal static void Awake()
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GigaStationsUpdated.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GigaStationsUpdated.cs) - original line 15

```csharp
	internal const string GUID = "org.kremnev8.plugin.GigaStationsUpdated";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.org.kremnev8.plugin.GigaStationsUpdated");

	internal static void Awake()
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/InstallationCheckPlugin.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/InstallationCheckPlugin.cs) - original line 73

```csharp
			MessageShown = true;
			string text = null;
			if (ProjectGenesis.ShowMessageBoxEntry.Value)
			{
				text = "GenesisBookLoadMessage";
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/LazyOutposting.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/LazyOutposting.cs) - original line 14

```csharp
	internal const string GUID = "eirshy.dsp.LazyOutposting";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.eirshy.dsp.LazyOutposting");

	internal static void Awake()
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/MoreMegaStructure.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/MoreMegaStructure.cs) - original line 16

```csharp
	internal static readonly Dictionary<int, int> FastAssembleItems = new Dictionary<int, int>();

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.Gnimaerd.DSP.plugin.MoreMegaStructure");

	private static readonly int[] AddedRecipes = new int[57]
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/PlanetVeinUtilization.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/PlanetVeinUtilization.cs) - original line 13

```csharp
	internal const string GUID = "testpostpleaseignore.dsp.planet_vein_utilization";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.testpostpleaseignore.dsp.planet_vein_utilization");

	internal static void Awake()
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/WeaponPlus.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/WeaponPlus.cs) - original line 11

```csharp
	internal const string GUID = "org.weaponplus.plugins.Xiaokls";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.org.weaponplus.plugins.Xiaokls");

	internal static void Awake()
```

### Dependency reference code

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/GenesisCompatibilityPatch.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/GenesisCompatibilityPatch.cs) - original line 5

```csharp
namespace MoreMegaStructure;

[BepInDependency("org.LoShin.GenesisBook", BepInDependency.DependencyFlags.HardDependency)]
[BepInPlugin("Gnimaerd.DSP.plugin.MMSGCPatch", "MMSGCPatch", "1.0")]
public class GenesisCompatibilityPatch : BaseUnityPlugin
```

[References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/GenesisCompatibilityPatch.cs](References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/GenesisCompatibilityPatch.cs) - original line 5

```csharp
namespace MoreMegaStructure;

[BepInDependency("org.LoShin.GenesisBook", BepInDependency.DependencyFlags.HardDependency)]
[BepInPlugin("Gnimaerd.DSP.plugin.MMSGCPatch", "MMSGCPatch", "1.0")]
public class GenesisCompatibilityPatch : BaseUnityPlugin
```

[References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/MoreMegaStructure.cs) - original line 2316

```csharp

    /// 以下为创世之书特别适配用
    [BepInDependency("org.LoShin.GenesisBook")]
    [BepInPlugin("Gnimaerd.DSP.plugin.MMSGCPatch", "MMSGCPatch", "1.0")]
    public class GenesisCompatibilityPatch : BaseUnityPlugin
```

## jinxOAO-MoreMegaStructure

[Project identity and versions](References/jinxOAO-MoreMegaStructure/reference.json) | [Reference notes](References/jinxOAO-MoreMegaStructure/README.md)

Upstream: https://github.com/jinxOAO/DSPmod_MoreMegaStructures

- **fix_integration_context**: Virtual reference production is supplied through the native calculator; the UI must not calculate it a second time.

### Code in this mod

[Source/PortedWorkingSource/StatsUITweaks/RefProductSpeedPatch.cs](Source/PortedWorkingSource/StatsUITweaks/RefProductSpeedPatch.cs) - original line 17

```csharp
		if (forceInc || limit >= 0)
		{
			MethodInfo original = AccessTools.Method(typeof(ProductionExtraInfoCalculator), "CalculateFactory");
			MethodInfo original2 = AccessTools.Method(typeof(UIReferenceSpeedTip), "AddEntryDataWithFactory");
			if (forceInc)
```

[Source/Reconstructed/plugins/StatsUITweaks/StatsUITweaks/RefProductSpeedPatch.cs](Source/Reconstructed/plugins/StatsUITweaks/StatsUITweaks/RefProductSpeedPatch.cs) - original line 17

```csharp
		if (forceInc || limit >= 0)
		{
			MethodInfo original = AccessTools.Method(typeof(ProductionExtraInfoCalculator), "CalculateFactory");
			MethodInfo original2 = AccessTools.Method(typeof(UIReferenceSpeedTip), "AddEntryDataWithFactory");
			if (forceInc)
```

[Evidence/InitialPhase/check.cs](Evidence/InitialPhase/check.cs) - original line 16

```csharp
        AccessTools.Method(typeof(Plugin), "ClampConfiguration").Invoke(null, null);
        if (StatsWindowPatch.TimeSliderSlice != 1 || StatsWindowPatch.ListWidthOffeset != 239 || Utils.DropDownCount != 1) throw new Exception("Unsafe UI settings retained");
        foreach (var method in new[] {AccessTools.Method(typeof(ProductionExtraInfoCalculator), "CalculateFactory"), AccessTools.Method(typeof(UIReferenceSpeedTip), "AddEntryDataWithFactory")})
        {
            var generator = new DynamicMethod("native", typeof(void), Type.EmptyTypes).GetILGenerator();
```

[Source/EarlierWorkingSource/RefProductSpeedPatch.cs](Source/EarlierWorkingSource/RefProductSpeedPatch.cs) - original line 17

```csharp

            // 套用至每個呼叫FactoryProductionStat.AddRefProductSpeed的函式
            var target1 = AccessTools.Method(typeof(ProductionExtraInfoCalculator), nameof(ProductionExtraInfoCalculator.CalculateFactory));
            var target2 = AccessTools.Method(typeof(UIReferenceSpeedTip), nameof(UIReferenceSpeedTip.AddEntryDataWithFactory));

```

[Source/PortedWorkingSource/StatsUITweaks/Plugin.cs](Source/PortedWorkingSource/StatsUITweaks/Plugin.cs) - original line 88

```csharp
		}
		harmony.PatchAll(typeof(StatsWindowPatch.Entry_Patch));
		RefProductSpeedPatch.Init(harmony, configEntry.Value, configEntry2.Value);
		harmony.PatchAll(typeof(UIGamePatch));
		harmony.PatchAll(typeof(StatPlanPatch));
```

[Source/Reconstructed/plugins/StatsUITweaks/StatsUITweaks/Plugin.cs](Source/Reconstructed/plugins/StatsUITweaks/StatsUITweaks/Plugin.cs) - original line 88

```csharp
		}
		harmony.PatchAll(typeof(StatsWindowPatch.Entry_Patch));
		RefProductSpeedPatch.Init(harmony, configEntry.Value, configEntry2.Value);
		harmony.PatchAll(typeof(UIGamePatch));
		harmony.PatchAll(typeof(StatPlanPatch));
```

[Source/EarlierWorkingSource/Plugin.cs](Source/EarlierWorkingSource/Plugin.cs) - original line 82

```csharp
            harmony.PatchAll(typeof(StatsWindowPatch.Entry_Patch));

            RefProductSpeedPatch.Init(harmony, RefRateTweak.Value, RefRateMinerLimit.Value);
            harmony.PatchAll(typeof(UIGamePatch));

```

### Code in the related reference

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/StatisticsCalculatorBridge.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/StatisticsCalculatorBridge.cs) - original line 40

```csharp
        }

        public static bool CalculateFactoryPrefix(ProductionExtraInfoCalculator __instance, GameData gameData, PlanetFactory factory)
        {
            if (factory == null || factory.index < gameData.factories.Length) return true;
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/UIStatisticsPatcher.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/UIStatisticsPatcher.cs) - original line 1933

```csharp

        [HarmonyTranspiler]
        [HarmonyPatch(typeof(ProductionExtraInfoCalculator), "GameTick")]
        public static IEnumerable<CodeInstruction> CalculatorGameTickTranspiler(IEnumerable<CodeInstruction> instructions)
            => StatisticsCalculatorBridge.ReplaceFactoryLookup(instructions);
```

[References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/StatisticsCalculatorBridge.cs](References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/StatisticsCalculatorBridge.cs) - original line 50

```csharp
	}

	public static bool CalculateFactoryPrefix(ProductionExtraInfoCalculator __instance, GameData gameData, PlanetFactory factory)
	{
		if (factory == null || factory.index < gameData.factories.Length)
```

[References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/UIStatisticsPatcher.cs](References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/UIStatisticsPatcher.cs) - original line 1943

```csharp

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(ProductionExtraInfoCalculator), "GameTick")]
	public static IEnumerable<CodeInstruction> CalculatorGameTickTranspiler(IEnumerable<CodeInstruction> instructions)
	{
```

[References/jinxOAO-MoreMegaStructure/Code/Evidence/InitialPhase/check.cs](References/jinxOAO-MoreMegaStructure/Code/Evidence/InitialPhase/check.cs) - original line 30

```csharp
        return data;
    }
    static ProductionExtraInfoCalculator Calculator(GameData data)
    {
        var calculator = new ProductionExtraInfoCalculator();
```

[References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/StatisticsCalculatorBridge.cs](References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/StatisticsCalculatorBridge.cs) - original line 40

```csharp
        }

        public static bool CalculateFactoryPrefix(ProductionExtraInfoCalculator __instance, GameData gameData, PlanetFactory factory)
        {
            if (factory == null || factory.index < gameData.factories.Length) return true;
```

[References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/UIStatisticsPatcher.cs](References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/UIStatisticsPatcher.cs) - original line 1822

```csharp

        [HarmonyTranspiler]
        [HarmonyPatch(typeof(ProductionExtraInfoCalculator), "GameTick")]
        public static IEnumerable<CodeInstruction> CalculatorGameTickTranspiler(IEnumerable<CodeInstruction> instructions)
            => StatisticsCalculatorBridge.ReplaceFactoryLookup(instructions);
```

## nebula-NebulaMultiplayerModApi

[Project identity and versions](References/nebula-NebulaMultiplayerModApi/reference.json) | [Reference notes](References/nebula-NebulaMultiplayerModApi/README.md)

Upstream: https://github.com/NebulaModTeam/nebula

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs) - original line 15

```csharp
[BepInPlugin("dsp.nebula-multiplayer-api", "NebulaMultiplayerModApi", "2.1.0.7")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class NebulaModAPI : BaseUnityPlugin
{
	public const string NEBULA_MODID = "dsp.nebula-multiplayer";
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs) - original line 5

```csharp
namespace NebulaAPI.DataStructures;

public static class CollectionExtensions
{
	public static Locker Lock(this ICollection collection)
```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs) - original line 13

```csharp

[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Bootstrap.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Bootstrap.cs) - original line 20

```csharp
    [BepInPlugin("dsp.galactic-scale.2", "Galactic Scale 2 Plug-In", "2.80.9")]
    [BepInDependency("space.customizing.console", BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("lltcggie.DSP.plugin.PlanetwidePlanetaryShieldGenerator", BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("un1eagle.planetwideshield", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/GalacticScale/Bootstrap.cs](References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/GalacticScale/Bootstrap.cs) - original line 14

```csharp
[BepInPlugin("dsp.galactic-scale.2", "Galactic Scale 2 Plug-In", "2.80.9")]
[BepInDependency("space.customizing.console", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("lltcggie.DSP.plugin.PlanetwidePlanetaryShieldGenerator", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("un1eagle.planetwideshield", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/NebulaCompatibility/Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod.cs](References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/NebulaCompatibility/Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod.cs) - original line 13

```csharp

[BepInPlugin("dsp.galactic-scale.2.nebula", "Galactic Scale 2 Nebula Compatibility Plug-In", "1.0.0.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
public class Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod : BaseUnityPlugin, IMultiplayerModWithSettings, IMultiplayerMod
{
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 26

```csharp
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.LoShin.GenesisBook.InstallationCheck", BepInDependency.DependencyFlags.SoftDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
```

## starfi5h-ModFixerOne

[Project identity and versions](References/starfi5h-ModFixerOne/reference.json) | [Reference notes](References/starfi5h-ModFixerOne/README.md)

Upstream: https://github.com/starfi5h/DSP_Mod_Support

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/starfi5h-ModFixerOne/Code/Source/Reconstructed/patchers/ModFixerOnePreloader/ModFixerOne/Preloader.cs](References/starfi5h-ModFixerOne/Code/Source/Reconstructed/patchers/ModFixerOnePreloader/ModFixerOne/Preloader.cs) - original line 15

```csharp
public static class Preloader
{
	public static ManualLogSource logSource = Logger.CreateLogSource("ModFixerOne Preloader");

	public static IEnumerable<string> Guids;
```

[References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs](References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs) - original line 18

```csharp
			if (!IsVaild())
			{
				ErrorMessage = "Can't find injected fields or methods!\n Please make sure that ModFixerOnePreloader.dll is installed in BepInEx\\patchers.";
				Plugin.Log.LogWarning(ErrorMessage);
				harmony.PatchAll(typeof(Fixer_Patch));
```

[References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Plugin.cs](References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Plugin.cs) - original line 8

```csharp
namespace ModFixerOne;

[BepInPlugin("starfi5h.plugin.ModFixerOne", "ModFixerOne", "2.1.2")]
public class Plugin : BaseUnityPlugin
{
```

[References/starfi5h-ModFixerOne/Code/Evidence/InitialPhase/check.cs](References/starfi5h-ModFixerOne/Code/Evidence/InitialPhase/check.cs) - original line 19

```csharp
        try { resize.Invoke(null, unsafeShrink); } catch (TargetInvocationException e) { rejected = e.InnerException is System.IO.InvalidDataException; }
        if (!rejected || ((int[])unsafeShrink[0]).Length != 2 || ((int[])unsafeShrink[0])[1] != 9) throw new Exception("Occupied tail silently removed");
        ModFixerOne.Plugin.Log = new BepInEx.Logging.ManualLogSource("Import check");
        object[] removed = {new AssemblerComponent {recipeId = 9912, served = new[] {7}, incServed = new[] {21}}};
        rejected = false;
```

[References/starfi5h-ModFixerOne/Code/Source/EarlierWorkingSource/Fixer_Patch.cs](References/starfi5h-ModFixerOne/Code/Source/EarlierWorkingSource/Fixer_Patch.cs) - original line 28

```csharp
                if (!IsVaild())
                {
                    ErrorMessage = "Can't find injected fields or methods!\n Please make sure that ModFixerOnePreloader.dll is installed in BepInEx\\patchers.";
                    Plugin.Log.LogWarning(ErrorMessage);
                    harmony.PatchAll(typeof(Fixer_Patch));
```

[References/starfi5h-ModFixerOne/Code/Source/EarlierWorkingSource/Plugin.cs](References/starfi5h-ModFixerOne/Code/Source/EarlierWorkingSource/Plugin.cs) - original line 12

```csharp
    public class Plugin : BaseUnityPlugin
    {
        public const string GUID = "starfi5h.plugin.ModFixerOne";
        public const string NAME = "ModFixerOne";
        public const string VERSION = "2.1.2";
```

### Dependency reference code

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs) - original line 22

```csharp
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
[BepInDependency("starfi5h.plugin.ModFixerOne", BepInDependency.DependencyFlags.HardDependency)]
[BepInPlugin("Gnimaerd.DSP.plugin.MoreMegaStructure", "MoreMegaStructure", "2.0.2")]
public class MoreMegaStructure : BaseUnityPlugin, IModCanSave
```

[References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs) - original line 22

```csharp
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
[BepInDependency("starfi5h.plugin.ModFixerOne", BepInDependency.DependencyFlags.HardDependency)]
[BepInPlugin("Gnimaerd.DSP.plugin.MoreMegaStructure", "MoreMegaStructure", "2.0.2")]
public class MoreMegaStructure : BaseUnityPlugin, IModCanSave
```

[References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/EarlierWorkingSource/MoreMegaStructure.cs) - original line 27

```csharp
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [CommonAPISubmoduleDependency(nameof(ProtoRegistry), nameof(TabSystem), nameof(LocalizationModule))]
    [BepInDependency("starfi5h.plugin.ModFixerOne")]
    [BepInPlugin("Gnimaerd.DSP.plugin.MoreMegaStructure", "MoreMegaStructure", "1.9.6")]
    public class MoreMegaStructure : BaseUnityPlugin, IModCanSave
```

## xiaoye97-LDBTool

[Project identity and versions](References/xiaoye97-LDBTool/reference.json) | [Reference notes](References/xiaoye97-LDBTool/README.md)

Upstream: https://github.com/xiaoye97/DSP_LDBTool

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs) - original line 11

```csharp
namespace xiaoye97;

public static class LDBTool
{
	public static Action PreAddDataAction;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs) - original line 11

```csharp
namespace xiaoye97;

[BepInPlugin("me.xiaoye97.plugin.Dyson.LDBTool", "LDBTool", "3.0.4")]
public class LDBToolPlugin : BaseUnityPlugin
{
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs) - original line 16

```csharp
	internal static void InitIndex()
	{
		LDBToolPlugin.logger.LogDebug("Generating Proto type list:");
		protoTypes = (from domainAssembly in AppDomain.CurrentDomain.GetAssemblies()
			from assemblyType in GetTypesSafe(domainAssembly)
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs) - original line 19

```csharp
		if (__instance.recipeExecuteData == null)
		{
			LDBToolPlugin.logger.LogWarning($"Importing assembler {__instance.recipeType}: Can't find recipeId {__instance.recipeId}");
			__instance.recipeId = 0;
			__instance.recipeType = ERecipeType.None;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs) - original line 12

```csharp
	private static void HistoryPatch(GameHistoryData __instance)
	{
		foreach (Proto item in LDBTool.TotalDict[ProtoIndex.GetIndex(typeof(RecipeProto))])
		{
			RecipeProto recipeProto = item as RecipeProto;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/UITip_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/UITip_Patch.cs) - original line 12

```csharp
	private static void ItemTipPatch(UIItemTip __instance, int itemId)
	{
		if (LDBToolPlugin.ShowProto.Value)
		{
			__instance.nameText.text += $" {itemId}";
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/VFPreload_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/VFPreload_Patch.cs) - original line 15

```csharp
	private static void VFPreloadPrePatch()
	{
		if (!LDBTool.Finshed)
		{
			LDBToolPlugin.logger.LogInfo("Pre Loading...");
```

[References/xiaoye97-LDBTool/Code/Evidence/InitialPhase/check.cs](References/xiaoye97-LDBTool/Code/Evidence/InitialPhase/check.cs) - original line 53

```csharp
            return null;
        };
        try { plugin = Assembly.LoadFrom(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "LDBTool.dll")); Run(); }
        catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }
    }
```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 17

```csharp

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/ProtoRegistry.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/ProtoRegistry.cs) - original line 81

```csharp
		spriteFileExtensions = new string[3] { ".jpg", ".png", ".tif" };
		audioClipFileExtensions = new string[4] { ".mp3", ".ogg", ".waw", ".aif" };
		LDBTool.PostAddDataAction = (Action)Delegate.Combine(LDBTool.PostAddDataAction, new Action(OnPostAdd));
		LDBTool.EditDataAction = (Action<Proto>)Delegate.Combine(LDBTool.EditDataAction, new Action<Proto>(EditProto));
	}
```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 30

```csharp
    /// </summary>
    [BepInPlugin(GUID, DISPNAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 25

```csharp
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.LoShin.GenesisBook.InstallationCheck", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/MoreMegaStructure.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/MoreMegaStructure.cs) - original line 37

```csharp
			HarmonyPatch.Patch(AccessTools.Method(typeof(VFPreload), "InvokeOnLoadWorkEnded"), null, new HarmonyMethod(typeof(MoreMegaStructure), "LDBToolOnPostAddDataAction")
			{
				after = new string[1] { "me.xiaoye97.plugin.Dyson.LDBTool" }
			});
		}
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/DisableLDBToolCachePatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/DisableLDBToolCachePatches.cs) - original line 21

```csharp

	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	[HarmonyAfter(new string[] { "me.xiaoye97.plugin.Dyson.LDBTool" })]
	[HarmonyPostfix]
	public static void DeleteFiles()
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MoreMegaStructure.cs) - original line 18

```csharp
namespace MoreMegaStructure;

[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
```

[References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs](References/jinxOAO-MoreMegaStructure/Code/Source/Reconstructed/plugins/MoreMegaStructure/MoreMegaStructure/MoreMegaStructure.cs) - original line 18

```csharp
namespace MoreMegaStructure;

[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
```

[References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MMSProtos.cs](References/jinxOAO-MoreMegaStructure/Code/Source/PortedWorkingSource/MoreMegaStructure/MMSProtos.cs) - original line 423

```csharp
		LDB.items.Select(2316).recipes.Add(recipeProto26);
		LDB.items.Select(2306).recipes.Add(recipeProto27);
		LDBTool.PostAddProto((Proto)recipeProto13);
		LDBTool.PostAddProto((Proto)recipeProto10);
		LDBTool.PostAddProto((Proto)recipeProto15);
```

[References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne.Mods/LDBTool_Patch.cs](References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne.Mods/LDBTool_Patch.cs) - original line 43

```csharp
	public const string NAME = "LDBTool";

	public const string GUID = "me.xiaoye97.plugin.Dyson.LDBTool";

	public const string VERSION = "3.0.1";
```

[References/starfi5h-ModFixerOne/Code/Source/EarlierWorkingSource/Mods/LDBTool_Patch.cs](References/starfi5h-ModFixerOne/Code/Source/EarlierWorkingSource/Mods/LDBTool_Patch.cs) - original line 11

```csharp
    {
        public const string NAME = "LDBTool";
        public const string GUID = "me.xiaoye97.plugin.Dyson.LDBTool";
        public const string VERSION = "3.0.1";
        private static bool IsGameLoaded = false;
```

[References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs](References/starfi5h-ModFixerOne/Code/Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs) - original line 48

```csharp
			}
			harmony.PatchAll(typeof(Common_Patch));
			LDBTool_Patch.Init(harmony);
			if (ErrorMessage != "")
			{
```
