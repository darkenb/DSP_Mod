using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace StatsUITweaks;

public class RefProductSpeedPatch
{
	private static float minerLimit = 14400f;

	public static void Init(Harmony harmony, bool forceInc, int limit)
	{
		if (forceInc || limit >= 0)
		{
			MethodInfo original = AccessTools.Method(typeof(ProductionExtraInfoCalculator), "CalculateFactory");
			MethodInfo original2 = AccessTools.Method(typeof(UIReferenceSpeedTip), "AddEntryDataWithFactory");
			if (forceInc)
			{
				HarmonyMethod transpiler = new HarmonyMethod(AccessTools.Method(typeof(RefProductSpeedPatch), "IncUsed_Transpiler"));
				harmony.Patch(original, null, null, transpiler);
				harmony.Patch(original2, null, null, transpiler);
			}
			if (limit >= 0)
			{
				minerLimit = limit;
				HarmonyMethod transpiler2 = new HarmonyMethod(AccessTools.Method(typeof(RefProductSpeedPatch), "MinerLimit_Transpiler"));
				harmony.Patch(original, null, null, transpiler2);
				harmony.Patch(original2, null, null, transpiler2);
			}
		}
	}

	private static IEnumerable<CodeInstruction> IncUsed_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			return new CodeMatcher(instructions).MatchForward(false, new CodeMatch(OpCodes.Ldloc_S), new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Ldfld && ((FieldInfo)i.operand).Name == "incUsed")).Repeat(delegate(CodeMatcher matcher)
			{
				matcher.SetAndAdvance(OpCodes.Nop, null).SetAndAdvance(OpCodes.Ldc_I4_1, null);
			}).InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("RefProductSpeedPatch.IncUsed_Transpiler error!");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	private static IEnumerable<CodeInstruction> MinerLimit_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			MethodInfo operand = AccessTools.Method(typeof(Math), "Min", new Type[2]
			{
				typeof(float),
				typeof(float)
			});
			FieldInfo operand2 = AccessTools.Field(typeof(MinerComponent), "speed");
			FieldInfo operand3 = AccessTools.Field(typeof(VeinData), "oilSpeedMultiplier");
			FieldInfo operand4 = AccessTools.Field(typeof(RefProductSpeedPatch), "minerLimit");
			CodeMatcher codeMatcher = new CodeMatcher(instructions);
			codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldsfld, operand3), new CodeMatch(OpCodes.Conv_R8), new CodeMatch(OpCodes.Mul), new CodeMatch(OpCodes.Conv_R4), new CodeMatch(OpCodes.Stloc_S)).Insert(new CodeInstruction(OpCodes.Ldsfld, operand4), new CodeInstruction(OpCodes.Call, operand));
			codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldfld, operand2), new CodeMatch(OpCodes.Conv_R8), new CodeMatch(OpCodes.Mul), new CodeMatch(OpCodes.Conv_R4), new CodeMatch(OpCodes.Stloc_S)).Insert(new CodeInstruction(OpCodes.Ldsfld, operand4), new CodeInstruction(OpCodes.Call, operand));
			return codeMatcher.InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("RefProductSpeedPatch.MinerLimit_Transpiler error!");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}
}
