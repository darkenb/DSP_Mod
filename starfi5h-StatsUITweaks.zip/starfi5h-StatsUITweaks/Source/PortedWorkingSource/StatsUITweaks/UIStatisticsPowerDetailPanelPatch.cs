using System;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace StatsUITweaks;

public class UIStatisticsPowerDetailPanelPatch
{
	private static bool initialized;

	private static UIButton extendBtn;

	private static bool extended;

	private static float scrollHeight = 210f;

	private static float scrollY = 210f;

	private static GameObject sepline;

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIStatisticsPowerDetailPanel), "_OnOpen")]
	public static void Init(UIStatisticsPowerDetailPanel __instance)
	{
		if (initialized)
		{
			return;
		}
		try
		{
			GameObject gameObject = UnityEngine.Object.Instantiate(UIRoot.instance.uiGame.researchQueue.pauseButton.gameObject, __instance.transform);
			gameObject.name = "CustomStats_Extend";
			gameObject.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
			gameObject.transform.localPosition = new Vector3(420f, -420f, 0f);
			Image image = gameObject.transform.Find("icon")?.GetComponent<Image>();
			if (image != null)
			{
				UIStarmap starmap = UIRoot.instance.uiGame.starmap;
				image.sprite = starmap.cursorFunctionButton2.transform.Find("icon")?.GetComponent<Image>()?.sprite;
			}
			extendBtn = gameObject.GetComponent<UIButton>();
			extendBtn.tips.tipTitle = "Extend 扩展耗电设施";
			extendBtn.tips.tipText = "Click to extend power consumption detail";
			extendBtn.tips.corner = 8;
			extendBtn.onClick += OnFoldButtonClick;
			if (extendBtn.transitions != null)
			{
				extendBtn.transitions[0].highlightColorOverride = new Color(0.5f, 0.6f, 0.7f, 0.1f);
			}
			gameObject.SetActive(value: true);
			RectTransform obj = (RectTransform)__instance.conScrollContentRect.transform.parent.parent.transform;
			scrollHeight = obj.sizeDelta.y;
			scrollY = obj.localPosition.y;
			sepline = __instance.gameObject.transform.Find("table-panel/sep-line-0")?.gameObject;
			initialized = true;
			Plugin.Log.LogDebug("Create UIStatisticsPowerDetailPanel extend button");
		}
		catch (Exception data)
		{
			Plugin.Log.LogError("PerformancePanelPatch initial fail!");
			Plugin.Log.LogError(data);
		}
		Toggle(extended);
	}

	public static void OnDestroy()
	{
		Toggle(extendScroll: false);
		UnityEngine.Object.Destroy(extendBtn?.gameObject);
		initialized = false;
	}

	private static void OnFoldButtonClick(int obj)
	{
		extended = !extended;
		extendBtn.highlighted = extended;
		Toggle(extended);
	}

	private static void Toggle(bool extendScroll)
	{
		if (initialized)
		{
			UIStatisticsPowerDetailPanel powerDetailPanel = UIRoot.instance.uiGame.statWindow.powerDetailPanel;
			powerDetailPanel.genScrollContentRect.gameObject.SetActive(!extendScroll);
			sepline?.SetActive(!extendScroll);
			RectTransform obj = (RectTransform)powerDetailPanel.conScrollContentRect.transform.parent.parent.transform;
			obj.localPosition = new Vector3(obj.localPosition.x, extendScroll ? (scrollY + 50f) : scrollY, 0f);
			obj.sizeDelta = new Vector2(obj.sizeDelta.x, extendScroll ? (scrollHeight + 210f) : scrollHeight);
		}
	}
}
