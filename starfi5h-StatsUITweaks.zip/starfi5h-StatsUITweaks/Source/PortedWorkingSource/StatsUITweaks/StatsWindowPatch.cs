using System;
using System.Collections.Generic;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace StatsUITweaks;

public class StatsWindowPatch
{
	public class Entry_Patch
	{
		private struct Data
		{
			public long production;

			public long consumption;
		}

		private static float ratio = 1f;

		private static readonly Dictionary<long[], Data> dict = new Dictionary<long[], Data>();

		private static readonly string[] formatF = new string[11]
		{
			"F0", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9",
			"F10"
		};

		public static void OnSliderChange(float value)
		{
			if (value < 1f)
			{
				timerSlider.value = 1f;
				return;
			}
			ratio = value / timerSlider.maxValue;
			UIRoot.instance.uiGame.statWindow.ComputeDisplayEntriesDetail();
			if (ratio == 1f)
			{
				UIRoot.instance.uiGame.statWindow.ValueToTimeBox();
			}
			else
			{
				ChangeTimeBoxText(UIRoot.instance.uiGame.statWindow);
			}
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(UIStatisticsWindow), "ValueToTimeBox")]
		private static void ChangeTimeBoxText(UIStatisticsWindow __instance)
		{
			if (ratio != 1f && __instance.isStatisticsTab)
			{
				string text = $" ({100f * ratio:N0}%)";
				InputField input = UIRoot.instance.uiGame.statWindow.timeBox.m_Input;
				switch (__instance.timeLevel)
				{
				case 0:
					input.text = (int)(60f * ratio + 0.5f) + "空格秒".Translate() + text;
					break;
				case 1:
					input.text = (10f * ratio).ToString("F1") + "空格分钟".Translate() + text;
					break;
				case 2:
					input.text = (60f * ratio).ToString("F1") + "空格分钟".Translate() + text;
					break;
				case 3:
					input.text = (10f * ratio).ToString("F1") + "统计10小时".Translate().Replace("10", " ") + text;
					break;
				case 4:
					input.text = (100f * ratio).ToString("F1") + "统计100小时".Translate().Replace("100", " ") + text;
					break;
				case 5:
					input.text = "统计总计".Translate() + text;
					break;
				}
			}
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UIStatisticsWindow), "ComputeDisplayEntriesDetail")]
		private static void ClearData()
		{
			dict.Clear();
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UIStatisticsWindow), "ComputeFirstHalfDetailExceptLast", new Type[]
		{
			typeof(int),
			typeof(int),
			typeof(int),
			typeof(int[]),
			typeof(long[])
		})]
		private static bool ComputeFirstHalfDetail(int endCursor, int lvlen, int cur, int[] detail, long[] targetDetail)
		{
			if (ratio == 1f)
			{
				return true;
			}
			dict.TryGetValue(targetDetail, out var value);
			int num = (int)((float)lvlen * (1f - ratio) + 0.5f);
			int num2 = cur + num - 1;
			for (int i = 0; i < lvlen - num; i++)
			{
				if (++num2 > endCursor)
				{
					num2 -= lvlen;
				}
				long num3 = detail[num2];
				value.production += num3;
				int num4 = (int)((float)(i + 1) / ratio);
				for (int j = (int)((float)i / ratio); j < num4; j++)
				{
					targetDetail[j] += num3;
				}
			}
			dict[targetDetail] = value;
			return false;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UIStatisticsWindow), "ComputeFirstHalfDetail", new Type[]
		{
			typeof(int),
			typeof(int),
			typeof(int),
			typeof(long[]),
			typeof(long[])
		})]
		private static bool ComputeFirstHalfDetail(int endCursor, int lvlen, int cur, long[] detail, long[] targetDetail)
		{
			if (ratio == 1f)
			{
				return true;
			}
			dict.TryGetValue(targetDetail, out var value);
			int num = (int)((float)lvlen * (1f - ratio) + 0.5f);
			int num2 = cur + num - 1;
			for (int i = 0; i < lvlen - num; i++)
			{
				if (++num2 > endCursor)
				{
					num2 -= lvlen;
				}
				long num3 = detail[num2];
				value.production += num3;
				int num4 = (int)((float)(i + 1) / ratio);
				for (int j = (int)((float)i / ratio); j < num4; j++)
				{
					targetDetail[j] += num3;
				}
			}
			dict[targetDetail] = value;
			return false;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UIStatisticsWindow), "ComputeSecondHalfDetailExceptLast", new Type[]
		{
			typeof(int),
			typeof(int),
			typeof(int),
			typeof(int[]),
			typeof(long[])
		})]
		private static bool ComputeSecondHalfDetail(int endCursor, int lvlen, int cur, int[] detail, long[] targetDetail)
		{
			if (ratio == 1f)
			{
				return true;
			}
			dict.TryGetValue(targetDetail, out var value);
			int num = (int)((float)lvlen * (1f - ratio) + 0.5f);
			int num2 = cur + num - 1;
			for (int i = 0; i < lvlen - num; i++)
			{
				if (++num2 > endCursor)
				{
					num2 -= lvlen;
				}
				long num3 = detail[num2];
				value.consumption += num3;
				int num4 = (int)((float)(i + 1) / ratio);
				for (int j = (int)((float)i / ratio); j < num4; j++)
				{
					targetDetail[lvlen + j] += num3;
				}
			}
			dict[targetDetail] = value;
			return false;
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UIStatisticsWindow), "ComputeSecondHalfDetail", new Type[]
		{
			typeof(int),
			typeof(int),
			typeof(int),
			typeof(long[]),
			typeof(long[])
		})]
		private static bool ComputeSecondHalfDetail(int endCursor, int lvlen, int cur, long[] detail, long[] targetDetail)
		{
			if (ratio == 1f)
			{
				return true;
			}
			dict.TryGetValue(targetDetail, out var value);
			int num = (int)((float)lvlen * (1f - ratio) + 0.5f);
			int num2 = cur + num - 1;
			for (int i = 0; i < lvlen - num; i++)
			{
				if (++num2 > endCursor)
				{
					num2 -= lvlen;
				}
				long num3 = detail[num2];
				value.consumption += num3;
				int num4 = (int)((float)(i + 1) / ratio);
				for (int j = (int)((float)i / ratio); j < num4; j++)
				{
					targetDetail[lvlen + j] += num3;
				}
			}
			dict[targetDetail] = value;
			return false;
		}

		[HarmonyPostfix]
		[HarmonyAfter(new string[] { "Bottleneck" })]
		[HarmonyPriority(100)]
		[HarmonyPatch(typeof(UIProductEntry), "_OnUpdate")]
		private static void UIProductEntry_ShowInText(UIProductEntry __instance)
		{
			if (!__instance.productionStatWindow.isProductionTab)
			{
				return;
			}
			int timeLevel = __instance.productionStatWindow.timeLevel;
			if (timeLevel < 5)
			{
				Text productUnitLabel = __instance.productUnitLabel;
				string text = (__instance.consumeUnitLabel.text = (DisplayPerSecond ? "/ s" : "/ min"));
				productUnitLabel.text = text;
			}
			if (RateFontSize > 0)
			{
				Text productText = __instance.productText;
				int fontSize = (__instance.consumeText.fontSize = RateFontSize);
				productText.fontSize = fontSize;
				Text productRefSpeedText = __instance.productRefSpeedText;
				fontSize = (__instance.consumeRefSpeedText.fontSize = RateFontSize);
				productRefSpeedText.fontSize = fontSize;
			}
			__instance.statGraph.transform.localScale = (ExtendGraph ? new Vector3(2.5f, 1f, 1f) : Vector3.one);
			__instance.importText.transform.parent.gameObject.SetActive(!ExtendGraph);
			__instance.exportText.transform.parent.gameObject.SetActive(!ExtendGraph);
			__instance.importStorageCountText.transform.parent.gameObject.SetActive(!ExtendGraph);
			__instance.exportStorageCountText.transform.parent.gameObject.SetActive(!ExtendGraph);
			__instance.storageCountText.transform.parent.gameObject.SetActive(!ExtendGraph);
			__instance.trashCountText.transform.parent.gameObject.SetActive(!ExtendGraph);
			double num;
			double num2;
			if (ratio == 1f || !dict.TryGetValue(__instance.entryData.productDetail, out var value))
			{
				if (!DisplayPerSecond || timeLevel >= 5)
				{
					return;
				}
				num = __instance.entryData.production;
				num2 = __instance.entryData.consumption;
				if (num < 0.0)
				{
					num = 0.0 - num;
				}
				if (num2 < 0.0)
				{
					num2 = 0.0 - num2;
				}
				if (timeLevel < 5)
				{
					double num3 = __instance.lvDivisors[timeLevel];
					num /= num3;
					num2 /= num3;
					if (DisplayPerSecond)
					{
						num /= 60.0;
						num2 /= 60.0;
					}
				}
				__instance.productText.text = ToLevelString(num);
				__instance.consumeText.text = ToLevelString(num2);
				return;
			}
			num = value.production;
			num2 = value.consumption;
			if (timeLevel < 5)
			{
				num /= __instance.lvDivisors[timeLevel] * (double)ratio;
				num2 /= __instance.lvDivisors[timeLevel] * (double)ratio;
				if (DisplayPerSecond)
				{
					num /= 60.0;
					num2 /= 60.0;
				}
				__instance.productSpeedTip.description = ((num >= 1000.0) ? num.ToString("#,##0") : num.ToString("#,##0.#0"));
				__instance.consumeSpeedTip.description = ((num2 >= 1000.0) ? num2.ToString("#,##0") : num2.ToString("#,##0.#0"));
			}
			if (DisplayPerSecond)
			{
				__instance.productText.text = ToLevelString(num);
				__instance.consumeText.text = ToLevelString(num2);
			}
			else
			{
				__instance.productText.text = __instance.ToLevelString(num, timeLevel);
				__instance.consumeText.text = __instance.ToLevelString(num2, timeLevel);
			}
		}

		private static string ToLevelString(double value)
		{
			if (value == 0.0)
			{
				return "0";
			}
			string text = "";
			if (value >= 1000000.0)
			{
				value /= 1000000.0;
				text = " M";
			}
			else if (value >= 10000.0)
			{
				value /= 1000.0;
				text = " k";
			}
			int num = 0;
			if (value >= 1000.0)
			{
				num = 3;
			}
			else if (value >= 100.0)
			{
				num = 2;
			}
			else if (value >= 10.0)
			{
				num = 1;
			}
			num = SignificantDigits - num - 1;
			if (num < 0)
			{
				num = 0;
			}
			if (num >= formatF.Length)
			{
				num = formatF.Length - 1;
			}
			if (num > 0)
			{
				double num2 = 0.1;
				for (int i = 0; i < num; i++)
				{
					num2 *= 0.1;
				}
				if (value - (double)(int)value < num2)
				{
					return value.ToString("F1") + text;
				}
			}
			return value.ToString(formatF[num]) + text;
		}

		[HarmonyPostfix]
		[HarmonyAfter(new string[] { "Bottleneck" })]
		[HarmonyPriority(100)]
		[HarmonyPatch(typeof(UIKillEntry), "_OnUpdate")]
		private static void UIKillEntry_ShowInText(UIKillEntry __instance)
		{
			if (ratio == 1f || !dict.TryGetValue(__instance.entryData.detail, out var value))
			{
				return;
			}
			int timeLevel = __instance.productionStatWindow.timeLevel;
			double num = value.production;
			if (timeLevel < 5)
			{
				num /= __instance.lvDivisors[timeLevel] * (double)ratio;
				if (DisplayPerSecond)
				{
					num /= 60.0;
				}
			}
			__instance.killText.text = __instance.ToLevelString(num, timeLevel);
		}

		[HarmonyPostfix]
		[HarmonyPriority(100)]
		[HarmonyPatch(typeof(UIProductEntry), "RefreshStatGraphHover")]
		private static void RefreshStatGraphHover_Postfix(UIProductEntry __instance, float statGraphWidth)
		{
			if (ratio == 1f || __instance.mouseHoverStatGraphTip == null)
			{
				return;
			}
			Vector3 mousePosition = Input.mousePosition;
			RectTransform rectTransform = __instance.statGraph.rectTransform;
			if (!__instance.isPointerEnter || !UIRoot.ScreenPointIntoRect(mousePosition, rectTransform, out var rectPoint))
			{
				return;
			}
			rectPoint = new Vector2(rectTransform.rect.width + rectPoint.x, rectTransform.rect.height * 0.5f + rectPoint.y);
			if (!(rectPoint.x > 0f) || !(rectPoint.x < statGraphWidth) || !(rectPoint.y > 0f) || !(rectPoint.y < 100f) || !__instance.productionStatWindow.isProductionTab || !__instance.mouseHoverStatGraphTip.gameObject.activeSelf)
			{
				return;
			}
			string tipText = __instance.statGraphTipSetting.tipText;
			int num = tipText.IndexOf('\n', tipText.IndexOf('\n') + 1);
			if (num > 0)
			{
				int num2 = (int)(rectPoint.x / (float)(__instance.columnWidth + __instance.columnInterval));
				int num3 = (int)((statGraphWidth + (float)__instance.columnInterval) / (float)(__instance.columnWidth + __instance.columnInterval));
				long num4 = GameMain.gameTick - __instance.levelTick;
				int num5 = __instance.levelTick * __instance.columnDataCount;
				long num6 = num4 / num5 * num5 - (num3 - num2 - 1) * num5;
				if (num6 < 0)
				{
					num6 = 0L;
				}
				uint num7 = (uint)((float)num6 * (1f / 60f) * ratio);
				uint value = num7 / 3600;
				uint value2 = num7 / 60 % 60;
				uint value3 = num7 % 60;
				__instance.sb3.Clear();
				__instance.sb3.Append("00000:00:00");
				StringBuilderUtility.WriteUInt(__instance.sb3, 0, 5, value, 2);
				StringBuilderUtility.WriteUInt(__instance.sb3, 6, 2, value2, 2);
				StringBuilderUtility.WriteUInt(__instance.sb3, 9, 2, value3, 2);
				StringBuilderUtility.TrimStart(__instance.sb3);
				__instance.sb3.Insert(0, "起始时间冒号".Translate());
				float num8 = (float)(__instance.levelTick * __instance.columnDataCount) * ratio;
				uint num9 = (uint)(num8 * (1f / 60f));
				uint num10 = num9 / 3600;
				uint num11 = num9 / 60 % 60;
				uint num12 = num9 % 60;
				uint num13 = (uint)num8 % 60;
				__instance.sb3.Append("\n").Append("时间周期冒号".Translate());
				if (num10 != 0)
				{
					__instance.sb3.Append(num10).Append("h ");
				}
				if (num11 != 0)
				{
					__instance.sb3.Append(num11).Append("min ");
				}
				if (num12 != 0)
				{
					__instance.sb3.Append(num12).Append("s ");
				}
				if (num13 != 0)
				{
					__instance.sb3.Append(num13).Append("t");
				}
				tipText = __instance.sb3.ToString() + tipText.Substring(num, tipText.Length - num);
				__instance.statGraphTipSetting.tipText = tipText;
			}
			__instance.mouseHoverStatGraphTip.UpdateText(ref __instance.statGraphTipSetting, null, null);
		}

		[HarmonyPrefix]
		[HarmonyPatch(typeof(UIProductEntry), "ComputePeak")]
		private static bool ComputePeak(UIProductEntry __instance, int firstColumnDataCount, ref long __result)
		{
			if (!ExcludeTrafficPeak)
			{
				return true;
			}
			long[] productDetail = __instance.entryData.productDetail;
			long num = 0L;
			if (__instance.productionStatWindow.isProductionTab || __instance.productionStatWindow.isDysonTab)
			{
				long[] trafficDetail = __instance.entryData.trafficDetail;
				bool flag = !__instance.productionStatWindow.isProductionTab && false;
				long num2 = 0L;
				int num3 = (flag ? (trafficDetail.Length - 1) : 0);
				int num4 = (flag ? (trafficDetail.Length / 2 - 1) : 0);
				int num6;
				if (firstColumnDataCount > 0)
				{
					int num5 = productDetail.Length - 1;
					num6 = productDetail.Length - firstColumnDataCount;
					for (int num7 = num5; num7 >= num6; num7--)
					{
						num2 += productDetail[num7];
					}
					if (flag)
					{
						num2 += trafficDetail[num3--];
					}
					if (num2 > num)
					{
						num = num2;
					}
					num2 = 0L;
					int num8 = productDetail.Length / 2 - 1;
					num6 = productDetail.Length / 2 - firstColumnDataCount;
					for (int num9 = num8; num9 >= num6; num9--)
					{
						num2 += productDetail[num9];
					}
					if (flag)
					{
						num2 += trafficDetail[num4--];
					}
					if (num2 > num)
					{
						num = num2;
					}
					num2 = 0L;
				}
				int num10 = 0;
				int num11 = productDetail.Length - firstColumnDataCount - 1;
				num6 = productDetail.Length / 2;
				for (int num12 = num11; num12 >= num6; num12--)
				{
					num2 += productDetail[num12];
					num10++;
					if (num10 == __instance.columnDataCount)
					{
						num10 = 0;
						if (flag)
						{
							num2 += trafficDetail[num3--];
						}
						if (num2 > num)
						{
							num = num2;
						}
						num2 = 0L;
					}
				}
				num2 = 0L;
				num10 = 0;
				int num13 = productDetail.Length / 2 - firstColumnDataCount - 1;
				num6 = 0;
				for (int num14 = num13; num14 >= num6; num14--)
				{
					num2 += productDetail[num14];
					num10++;
					if (num10 == __instance.columnDataCount)
					{
						num10 = 0;
						if (flag)
						{
							num2 += trafficDetail[num4--];
						}
						if (num2 > num)
						{
							num = num2;
						}
						num2 = 0L;
					}
				}
			}
			else
			{
				int num15 = productDetail.Length;
				if (__instance.extraEntryData != null)
				{
					for (int i = 0; i < num15; i++)
					{
						long num16 = productDetail[i];
						for (int j = 0; j < __instance.extraEntryData.Length; j++)
						{
							num16 += __instance.extraEntryData[j].productDetail[i];
						}
						if (num16 > num)
						{
							num = num16;
						}
					}
				}
				else
				{
					for (int k = 0; k < num15; k++)
					{
						long num17 = productDetail[k];
						if (num17 > num)
						{
							num = num17;
						}
					}
				}
			}
			__result = num;
			return false;
		}
	}

	public static bool PreserveFilter = true;

	public static int SignificantDigits = 3;

	public static int TimeSliderSlice = 20;

	public static int ListWidthOffeset = 70;

	public static bool DisplayPerSecond = false;

	public static int RateFontSize = 26;

	public static bool ExtendGraph = false;

	public static bool ExcludeTrafficPeak = false;

	private static bool initialized;

	private static bool enable;

	private static GameObject perSecGo;

	private static Slider timerSlider;

	private static InputField filterInput;

	private static UIButton locateBtn;

	private static GameObject filterGo;

	private static GameObject extendGraphGo;

	private static string nameFilter;

	private static int rawMaterialFilter;

	private static int endProductFilter;

	private static string searchStr = "";

	public static void Init(UIStatisticsWindow __instance)
	{
		if (initialized)
		{
			return;
		}
		initialized = true;
		try
		{
			if (ListWidthOffeset > 0)
			{
				Reposition(__instance.productAstroBox.transform, __instance.productTimeBox.transform);
				if (ListWidthOffeset > 40)
				{
					((RectTransform)__instance.productSortBox.transform).sizeDelta = new Vector2(200f - (float)(ListWidthOffeset - 40), 30f);
					__instance.productSortBox.transform.localPosition = new Vector3(135f - (float)(ListWidthOffeset - 40), __instance.productSortBox.transform.localPosition.y);
				}
				Reposition(__instance.powerAstroBox.transform, __instance.powerTimeBox.transform);
				Reposition(__instance.researchAstroBox.transform, __instance.researchTimeBox.transform);
				Reposition(__instance.dysonAstroBox.transform, __instance.dysonTimeBox.transform);
				Reposition(__instance.killAstroBox.transform, __instance.killTimeBox.transform);
				if (ListWidthOffeset > 40)
				{
					((RectTransform)__instance.killSortBox.transform).sizeDelta = new Vector2(200f - (float)(ListWidthOffeset - 40), 30f);
					__instance.killSortBox.transform.localPosition = new Vector3(135f - (float)(ListWidthOffeset - 40), __instance.killSortBox.transform.localPosition.y);
				}
			}
			Utils.EnableRichText(__instance.productAstroBox);
			Utils.EnableRichText(__instance.powerAstroBox);
			Utils.EnableRichText(__instance.researchAstroBox);
			Utils.EnableRichText(__instance.dysonAstroBox);
			Utils.EnableRichText(__instance.killAstroBox);
			Slider slider = UIRoot.instance.uiGame.dysonEditor.controlPanel.inspector.layerInfo.slider0;
			GameObject original = GameObject.Find("UI Root/Overlay Canvas/In Game/Windows/Control Panel Window/filter-group/sub-group/search-filter");
			UIButton pauseButton = UIRoot.instance.uiGame.researchQueue.pauseButton;
			GameObject loadSandboxGroup = UIRoot.instance.loadGameWindow.loadSandboxGroup;
			if (GameConfig.gameVersion > new Version(0, 10, 33))
			{
				perSecGo = UnityEngine.Object.Instantiate(loadSandboxGroup, __instance.productNameInputField.transform);
				perSecGo.name = "perSecGo";
				perSecGo.transform.localPosition = new Vector3(20f, 10f, 0f);
				perSecGo.SetActive(value: true);
				UnityEngine.Object.Destroy(perSecGo.GetComponent<Localizer>());
				perSecGo.transform.Find("tips")?.gameObject.SetActive(value: false);
				Text component = perSecGo.GetComponent<Text>();
				component.fontSize = 12;
				component.text = "Display /s";
				Toggle toggle = perSecGo.GetComponentInChildren<UIToggle>().toggle;
				toggle.onValueChanged.AddListener(OnDisplayPerSecondToggleChange);
				GameObject gameObject = toggle.gameObject;
				gameObject.transform.localScale = new Vector3(0.6f, 0.6f);
				gameObject.transform.localPosition = new Vector3(-4f, 27f, 0f);
				extendGraphGo = UnityEngine.Object.Instantiate(loadSandboxGroup, __instance.productNameInputField.transform);
				extendGraphGo.name = "extendGraphGo";
				extendGraphGo.transform.localPosition = new Vector3(145f, 10f, 0f);
				extendGraphGo.SetActive(value: true);
				UnityEngine.Object.Destroy(extendGraphGo.GetComponent<Localizer>());
				extendGraphGo.transform.Find("tips")?.gameObject.SetActive(value: false);
				Text component2 = extendGraphGo.GetComponent<Text>();
				component2.fontSize = 12;
				component2.text = "Extend Graph";
				Toggle toggle2 = extendGraphGo.GetComponentInChildren<UIToggle>().toggle;
				toggle2.onValueChanged.AddListener(OnExtendGraphToggleChange);
				GameObject gameObject2 = toggle2.gameObject;
				gameObject2.transform.localScale = new Vector3(0.6f, 0.6f);
				gameObject2.transform.localPosition = new Vector3(-4f, 27f, 0f);
			}
			GameObject gameObject3 = UnityEngine.Object.Instantiate(slider.gameObject, __instance.productTimeBox.transform);
			gameObject3.name = "CustomStats_Ratio";
			gameObject3.transform.localPosition = new Vector3(3f, 8f, 0f);
			gameObject3.transform.localScale = new Vector3(1.6f, 1.3f, 0f);
			timerSlider = gameObject3.GetComponent<Slider>();
			timerSlider.minValue = 0f;
			timerSlider.maxValue = TimeSliderSlice;
			timerSlider.wholeNumbers = true;
			timerSlider.value = timerSlider.maxValue;
			timerSlider.onValueChanged.AddListener(Entry_Patch.OnSliderChange);
			gameObject3.SetActive(value: true);
			filterGo = UnityEngine.Object.Instantiate(original, __instance.productAstroBox.transform);
			filterGo.name = "CustomStats_Fliter";
			filterGo.transform.localPosition = new Vector3(0f, 20f, 0f);
			filterInput = filterGo.GetComponentInChildren<InputField>();
			filterInput.text = "";
			filterInput.onValueChanged.AddListener(OnInputValueChanged);
			filterGo.GetComponent<RectTransform>().sizeDelta = new Vector2(((RectTransform)__instance.productAstroBox.transform).sizeDelta.x, 28f);
			filterGo.SetActive(value: true);
			GameObject gameObject4 = UnityEngine.Object.Instantiate(pauseButton.gameObject, __instance.productAstroBox.transform);
			gameObject4.name = "CustomStats_Navi";
			gameObject4.transform.localScale = new Vector3(0.33f, 0.33f, 0.33f);
			gameObject4.transform.localPosition = new Vector3(2f, -6f, 0f);
			Image image = gameObject4.transform.Find("icon")?.GetComponent<Image>();
			if (image != null)
			{
				UIStarmap starmap = UIRoot.instance.uiGame.starmap;
				image.sprite = starmap.cursorFunctionButton3.transform.Find("icon")?.GetComponent<Image>()?.sprite;
			}
			locateBtn = gameObject4.GetComponent<UIButton>();
			locateBtn.tips.tipTitle = "Locate";
			locateBtn.tips.tipText = "Left click: Navigate to planet\nRight click: Show planet in starmap";
			locateBtn.onClick += OnLocateButtonClick;
			locateBtn.onRightClick += OnLocateButtonRightClick;
			gameObject4.SetActive(value: true);
			enable = true;
			if (__instance.astroBox != __instance.productAstroBox)
			{
				OnTabButtonClick(__instance);
			}
		}
		catch (Exception data)
		{
			Plugin.Log.LogError("UI component initial fail!");
			Plugin.Log.LogError(data);
		}
		static void Reposition(Transform astroBoxtTansform, Transform timeBoxTransform)
		{
			((RectTransform)astroBoxtTansform).sizeDelta = new Vector2(200f + (float)ListWidthOffeset, 30f);
			timeBoxTransform.localPosition = new Vector3(330 - ListWidthOffeset, timeBoxTransform.localPosition.y);
		}
	}

	public static void OnDestroy()
	{
		UnityEngine.Object.Destroy(perSecGo);
		UnityEngine.Object.Destroy(extendGraphGo);
		UnityEngine.Object.Destroy(timerSlider?.gameObject);
		UnityEngine.Object.Destroy(filterInput?.gameObject);
		UnityEngine.Object.Destroy(locateBtn?.gameObject);
		UnityEngine.Object.Destroy(filterGo);
		initialized = false;
	}

	private static void OnDisplayPerSecondToggleChange(bool value)
	{
		DisplayPerSecond = value;
	}

	private static void OnExtendGraphToggleChange(bool value)
	{
		ExtendGraph = value;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIStatisticsWindow), "_OnOpen")]
	private static void OnOpen_Postfix(UIStatisticsWindow __instance)
	{
		Init(__instance);
		if (PreserveFilter)
		{
			__instance.productNameInputField.text = nameFilter;
			__instance.rawMaterialFilter = rawMaterialFilter;
			__instance.endProductFilter = endProductFilter;
			__instance.RefreshFilterTag();
			__instance.ComputeDetailNextTick();
		}
		if (perSecGo != null)
		{
			perSecGo.transform.localPosition = new Vector3(20f, 10f, 0f);
		}
		if (extendGraphGo != null)
		{
			extendGraphGo.transform.localPosition = new Vector3(145f, 10f, 0f);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIStatisticsWindow), "_OnClose")]
	private static void OnClose_Postfix(UIStatisticsWindow __instance)
	{
		if (PreserveFilter)
		{
			nameFilter = __instance.nameFilter;
			rawMaterialFilter = __instance.rawMaterialFilter;
			endProductFilter = __instance.endProductFilter;
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIStatisticsWindow), "OnProductAstroBoxItemIndexChanged")]
	private static bool PreventClearingFilter()
	{
		return !PreserveFilter;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIStatisticsWindow), "OnTabButtonClick")]
	private static void OnTabButtonClick(UIStatisticsWindow __instance)
	{
		if (enable)
		{
			if (__instance.timeBox != null)
			{
				timerSlider.gameObject.transform.SetParent(__instance.timeBox.transform);
			}
			if (__instance.astroBox != null)
			{
				filterGo.transform.SetParent(__instance.astroBox.transform);
				locateBtn.gameObject.transform.SetParent(__instance.astroBox.transform);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIStatisticsWindow), "_OnUpdate")]
	private static void OnUpdate(UIStatisticsWindow __instance)
	{
		if (__instance.isStatisticsTab)
		{
			Utils.DetermineAstroBoxIndex(__instance.astroBox);
		}
	}

	private static void OnLocateButtonClick(int obj)
	{
		int astroFilter = UIRoot.instance.uiGame.statWindow.astroFilter;
		if (astroFilter > 0)
		{
			int indicatorAstroId = GameMain.mainPlayer.navigation.indicatorAstroId;
			GameMain.mainPlayer.navigation.indicatorAstroId = ((indicatorAstroId != astroFilter) ? astroFilter : 0);
		}
	}

	private static void OnLocateButtonRightClick(int obj)
	{
		int astroFilter = UIRoot.instance.uiGame.statWindow.astroFilter;
		if (astroFilter <= 0)
		{
			return;
		}
		UIRoot.instance.uiGame.OpenStarmap();
		int num = astroFilter / 100 - 1;
		int num2 = astroFilter % 100 - 1;
		UIStarmap starmap = UIRoot.instance.uiGame.starmap;
		if (num < 0 || num >= starmap.starUIs.Length)
		{
			return;
		}
		if (num2 >= 0)
		{
			PlanetData planetData = GameMain.galaxy.PlanetById(astroFilter);
			if (planetData != null)
			{
				starmap.focusPlanet = null;
				starmap.focusStar = starmap.starUIs[num];
				starmap.OnCursorFunction2Click(0);
				starmap.screenCameraController.SetViewTarget(planetData, null, null, null, VectorLF3.zero, (double)planetData.realRadius * 0.00025 * 6.0, (double)planetData.realRadius * 0.00025 * 16.0, lockRot: true, immediate: false);
			}
		}
		else
		{
			starmap.focusPlanet = null;
			starmap.focusStar = starmap.starUIs[num];
			starmap.OnCursorFunction2Click(0);
		}
	}

	private static void OnInputValueChanged(string value)
	{
		searchStr = value;
		UIRoot.instance.uiGame.statWindow.RefreshAstroBox();
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIStatisticsWindow), "ValueToAstroBox")]
	[HarmonyAfter(new string[] { "Bottleneck" })]
	private static void FilterList(UIStatisticsWindow __instance, ref int __state)
	{
		if (__instance.isStatisticsTab)
		{
			int startIndex = 1;
			int localStarAstroId = 0;
			if (!__instance.isDysonTab && __instance.gameData.localPlanet != null)
			{
				startIndex = 2;
			}
			if (__instance.gameData.localStar != null)
			{
				localStarAstroId = __instance.gameData.localStar.astroId;
			}
			Utils.UpdateAstroBox(__instance.astroBox, startIndex, localStarAstroId, searchStr);
			__state = __instance.astroBox.itemIndex;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIStatisticsWindow), "ValueToAstroBox")]
	private static void RestoreItemIndex(UIStatisticsWindow __instance, int __state)
	{
		if (!__instance.isStatisticsTab || __instance.astroBox == null)
		{
			return;
		}
		try
		{
			int count = __instance.astroBox.ItemsData.Count;
			if (__state != __instance.astroBox.itemIndex && __state >= 0 && __state < count && __instance.astroBox.itemIndex < count && __instance.astroBox.ItemsData[__state] == __instance.astroBox.ItemsData[__instance.astroBox.itemIndex])
			{
				__instance.astroBox.itemIndex = __state;
			}
		}
		catch (Exception)
		{
		}
		if (locateBtn == null)
		{
			return;
		}
		int astroFilter = __instance.astroFilter;
		if (astroFilter <= 0)
		{
			locateBtn.tips.tipTitle = "Locate";
			return;
		}
		string text = "astroId=" + astroFilter;
		PlanetData planetData = GameMain.galaxy.PlanetById(astroFilter);
		if (planetData?.factory != null)
		{
			text = text + " idx=" + planetData.factory.index;
		}
		locateBtn.tips.tipTitle = text;
	}
}
