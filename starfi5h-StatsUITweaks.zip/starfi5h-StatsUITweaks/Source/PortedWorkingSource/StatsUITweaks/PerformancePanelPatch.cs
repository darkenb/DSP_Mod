using System;
using HarmonyLib;
using UnityEngine;
using UnityEngine.UI;

namespace StatsUITweaks;

public class PerformancePanelPatch
{
	private static bool initialized;

	private static UIButton foldBtn;

	private static bool folded;

	private static float scrollHeight = 398f;

	private static float scrollY = 23.5f;

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIPerformancePanel), "_OnOpen")]
	public static void Init(UIPerformancePanel __instance)
	{
		if (initialized)
		{
			return;
		}
		try
		{
			GameObject gameObject = UnityEngine.Object.Instantiate(UIRoot.instance.uiGame.researchQueue.pauseButton.gameObject, __instance.transform);
			gameObject.name = "CustomStats_Fold";
			gameObject.transform.localScale = new Vector3(0.5f, 0.5f, 0.5f);
			gameObject.transform.localPosition = new Vector3(-550f, 390f, 0f);
			Image image = gameObject.transform.Find("icon")?.GetComponent<Image>();
			if (image != null)
			{
				UIStarmap starmap = UIRoot.instance.uiGame.starmap;
				image.sprite = starmap.cursorFunctionButton2.transform.Find("icon")?.GetComponent<Image>()?.sprite;
			}
			foldBtn = gameObject.GetComponent<UIButton>();
			foldBtn.tips.tipTitle = "Fold 折叠饼图";
			foldBtn.tips.tipText = "Click to fold/unfold pie chart";
			foldBtn.onClick += OnFoldButtonClick;
			if (foldBtn.transitions != null)
			{
				foldBtn.transitions[0].highlightColorOverride = new Color(0.5f, 0.6f, 0.7f, 0.1f);
			}
			gameObject.SetActive(value: true);
			scrollHeight = __instance.cpuScrollRect.viewport.sizeDelta.y;
			scrollY = __instance.cpuScrollRect.viewport.localPosition.y;
			initialized = true;
		}
		catch (Exception data)
		{
			Plugin.Log.LogError("PerformancePanelPatch initial fail!");
			Plugin.Log.LogError(data);
		}
		Toggle(folded);
	}

	public static void OnDestroy()
	{
		if (initialized)
		{
			Toggle(extendScroll: false);
			UnityEngine.Object.Destroy(foldBtn?.gameObject);
			initialized = false;
		}
	}

	private static void OnFoldButtonClick(int obj)
	{
		folded = !folded;
		foldBtn.highlighted = folded;
		Toggle(folded);
	}

	private static void Toggle(bool extendScroll)
	{
		if (initialized)
		{
			UIPerformancePanel performancePanelUI = UIRoot.instance.uiGame.statWindow.performancePanelUI;
			Adjust(performancePanelUI.cpuScrollRect.viewport, extendScroll);
			Adjust(performancePanelUI.gpuScrollRect.viewport, extendScroll);
			Adjust(performancePanelUI.dataScrollRect.viewport, extendScroll);
		}
	}

	private static void Adjust(RectTransform scrollRect, bool extendScroll)
	{
		foreach (Transform item in scrollRect.parent.parent)
		{
			item.gameObject.SetActive(!extendScroll);
		}
		scrollRect.parent.gameObject.SetActive(value: true);
		scrollRect.gameObject.SetActive(value: true);
		scrollRect.localPosition = new Vector3(scrollRect.localPosition.x, extendScroll ? (scrollY + 362f) : scrollY, 0f);
		scrollRect.sizeDelta = new Vector2(scrollRect.sizeDelta.x, extendScroll ? (scrollHeight + 372f) : scrollHeight);
	}
}
