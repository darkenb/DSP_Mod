using System;
using HarmonyLib;
using UnityEngine;

namespace StatsUITweaks;

public class UIChartAstroItemProductionPatch
{
	private static double[] lvDivisors = new double[5] { 1.0, 10.0, 60.0, 600.0, 6000.0 };

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIChartAstroItemProduction), "ShowInText")]
	public static void ShowInText_Postfix(UIChartAstroItemProduction __instance, int level)
	{
		if (__instance.presetIndex == 0)
		{
			if (__instance.chartData.displayTypeParams[0] == 5 && level != 5)
			{
				__instance.statPlan.GetItemsCyclicRefSpeed(out var productRefSpeed, out var _);
				__instance.consumeText.text = __instance.ToLevelString(productRefSpeed, level).TrimStart(Array.Empty<char>()) + "<color=#fff5><size=10>/min</size></color>";
				__instance.consumeText.color = ((productRefSpeed > 0f) ? __instance.productColor : __instance.zeroColor);
			}
		}
		else if (__instance.presetIndex == 1 && __instance.chartData.displayTypeParams[0] == 5 && __instance.statPlan.timeLevel != 5)
		{
			__instance.displayGo0.SetActive(value: true);
			__instance.displayGo1.SetActive(value: false);
			__instance.statPlan.CalculateProductionAndConsumption(out var production, out var consumption);
			double value = (double)production / lvDivisors[level];
			double value2 = (double)consumption / lvDivisors[level];
			__instance.statPlan.GetItemsCyclicRefSpeed(out var productRefSpeed2, out var consumeRefSpeed2);
			double value3 = productRefSpeed2;
			double value4 = consumeRefSpeed2;
			string text = __instance.ToLevelString(value, level).TrimStart(Array.Empty<char>());
			string text2 = __instance.ToLevelString(value2, level).TrimStart(Array.Empty<char>());
			string text3 = __instance.ToLevelString(value3, level).TrimStart(Array.Empty<char>());
			string text4 = __instance.ToLevelString(value4, level).TrimStart(Array.Empty<char>());
			__instance.productText.text = text + " / " + text3;
			__instance.consumeText.text = text2 + " / " + text4;
			__instance.productText.fontSize = 18;
			__instance.consumeText.fontSize = 18;
			__instance.productUnitLabel.text = "/ min";
			__instance.consumeUnitLabel.text = "/ min";
			__instance.productLabel.text = "生产/理论";
			__instance.consumeLabel.text = "消耗/理论";
			__instance.productText.rectTransform.anchoredPosition = new Vector2(-26f, 0f);
			__instance.consumeText.rectTransform.anchoredPosition = new Vector2(-26f, 0f);
			__instance.productText.color = ((production > 0) ? __instance.productColor : __instance.zeroColor);
			__instance.consumeText.color = ((consumption > 0) ? __instance.consumeColor : __instance.zeroColor);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIChartAstroItemProduction), "CreateLayoutMenu")]
	public static void CreateLayoutMenu_Postfix(UIChartAstroItemProduction __instance, UIPopupMenu __result)
	{
		if ((__instance.presetIndex == 0 || __instance.presetIndex == 1) && __instance.statPlan.timeLevel != 5 && !(__result == null))
		{
			string s = ((__instance.presetIndex == 0) ? "生产与理论速度" : "生产消耗与理论");
			UIPopupMenuButton uIPopupMenuButton = __result.AddMenuButton(s.Translate(), (__instance.chartData.displayTypeParams[0] == 5) ? 1 : (-1));
			uIPopupMenuButton.data = 5;
			uIPopupMenuButton.onMenuButtonClick = (Action<int>)Delegate.Combine(uIPopupMenuButton.onMenuButtonClick, new Action<int>(__instance.OnLayoutMenuButtonClick));
			uIPopupMenuButton.SetState(runtime: true);
			__result.SetState(runtime: true);
		}
	}
}
