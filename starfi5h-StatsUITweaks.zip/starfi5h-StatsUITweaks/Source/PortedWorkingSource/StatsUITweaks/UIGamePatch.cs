using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace StatsUITweaks;

public class UIGamePatch
{
	[HarmonyTranspiler]
	[HarmonyPatch(typeof(UIGame), "_OnUpdate")]
	public static IEnumerable<CodeInstruction> OnUpdate_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			return new CodeMatcher(instructions).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Call && ((MethodInfo)i.operand).Name == "ShutControlPanelWindow")).SetAndAdvance(OpCodes.Call, AccessTools.Method(typeof(UIGamePatch), "ShutControlPanelWindow")).InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler UIGame._OnUpdate error!");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}

	private static void ShutControlPanelWindow(UIGame uIGame)
	{
		uIGame.TogglePlayerInventory();
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(UIGame), "On_Shift_P_Switch")]
	public static IEnumerable<CodeInstruction> On_Shift_P_Switch_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			return new CodeMatcher(instructions).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Call && ((MethodInfo)i.operand).Name == "ShutAllFunctionWindow")).SetAndAdvance(OpCodes.Pop, null).InstructionEnumeration();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("Transpiler UIGame.On_Shift_P_Switch error!");
			Plugin.Log.LogWarning(data);
			return instructions;
		}
	}
}
