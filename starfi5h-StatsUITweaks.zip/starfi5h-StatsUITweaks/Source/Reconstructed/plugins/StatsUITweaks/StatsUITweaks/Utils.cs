using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

namespace StatsUITweaks;

public static class Utils
{
	public static bool OrderByName = true;

	public static int DropDownCount = 15;

	public static string PlanetPrefix = "ㅤ";

	public static string PlanetPostfix = "";

	public static string SystemPrefix = "<color=yellow>";

	public static string SystemPostfix = "</color>";

	public static KeyCode HotkeyListUp = KeyCode.PageUp;

	public static KeyCode HotkeyListDown = KeyCode.PageDown;

	private static readonly Dictionary<int, int> astroIndex = new Dictionary<int, int>();

	private static readonly List<(string, int)> systemList = new List<(string, int)>();

	private static readonly List<string> newItems = new List<string>();

	private static readonly List<int> newItemData = new List<int>();

	public static void DetermineAstroBoxIndex(UIComboBox astroBox)
	{
		if (astroBox == null || astroBox.ItemsData == null || astroBox.ItemsData.Count == 0)
		{
			return;
		}
		int num = Math.Max(0, Math.Min(astroBox.ItemsData.Count - 1, astroBox.itemIndex));
		int num2 = num;
		if (Input.GetKeyDown(HotkeyListUp))
		{
			if (VFInput.control)
			{
				int num3;
				do
				{
					num = ((num > 0) ? (num - 1) : (astroBox.ItemsData.Count - 1));
					num3 = astroBox.ItemsData[num];
				}
				while ((num3 % 100 != 0 || num3 <= 0) && num3 != -1 && num != num2);
				astroBox.itemIndex = num;
			}
			else
			{
				astroBox.itemIndex = ((num > 0) ? (num - 1) : (astroBox.ItemsData.Count - 1));
			}
		}
		else
		{
			if (!Input.GetKeyDown(HotkeyListDown))
			{
				return;
			}
			if (VFInput.control)
			{
				int num4;
				do
				{
					num = (num + 1) % astroBox.ItemsData.Count;
					num4 = astroBox.ItemsData[num];
				}
				while ((num4 % 100 != 0 || num4 <= 0) && num4 != -1 && num != num2);
				astroBox.itemIndex = num;
			}
			else
			{
				astroBox.itemIndex = (num + 1) % astroBox.ItemsData.Count;
			}
		}
	}

	public static void EnableRichText(UIComboBox uIComboBox)
	{
		uIComboBox.m_Text.supportRichText = true;
		uIComboBox.m_EmptyItemRes.supportRichText = true;
		uIComboBox.m_ListItemRes.GetComponentInChildren<Text>().supportRichText = true;
		foreach (Button itemButton in uIComboBox.ItemButtons)
		{
			itemButton.GetComponentInChildren<Text>().supportRichText = true;
		}
		uIComboBox.DropDownCount = DropDownCount;
	}

	public static void UpdateAstroBox(UIComboBox astroBox, int startIndex, int localStarAstroId, string searchStr = "")
	{
		if (astroBox.Items.Count <= startIndex)
		{
			return;
		}
		astroIndex.Clear();
		systemList.Clear();
		newItems.Clear();
		newItemData.Clear();
		bool flag = false;
		if (startIndex + 1 < astroBox.Items.Count && astroBox.Items[startIndex] == "统计当前星系".Translate())
		{
			startIndex++;
			flag = true;
		}
		for (int i = startIndex; i < astroBox.Items.Count; i++)
		{
			int num = astroBox.ItemsData[i];
			if (num % 100 == 0)
			{
				if (astroIndex.ContainsKey(num))
				{
					Plugin.Log.LogDebug($"[{num}] => {astroBox.Items[i]}");
					systemList[astroIndex[num]] = (astroBox.Items[i], num);
				}
				else
				{
					astroIndex[num] = systemList.Count;
					systemList.Add((astroBox.Items[i], astroBox.ItemsData[i]));
				}
			}
		}
		if (OrderByName)
		{
			systemList.Sort();
		}
		bool flag2 = !string.IsNullOrEmpty(searchStr);
		foreach (var system in systemList)
		{
			int num2 = system.Item2 / 100;
			for (int j = startIndex; j < astroBox.Items.Count; j++)
			{
				int num3 = astroBox.ItemsData[j];
				if (num3 / 100 != num2)
				{
					continue;
				}
				string text = astroBox.Items[j];
				bool flag3 = true;
				if (num3 % 100 != 0)
				{
					if (!text.StartsWith(PlanetPrefix) || !text.EndsWith(PlanetPostfix))
					{
						text = PlanetPrefix + text + PlanetPostfix;
					}
					if (flag2 && text.Length > PlanetPrefix.Length)
					{
						int num4 = text.IndexOf(searchStr, PlanetPrefix.Length, StringComparison.OrdinalIgnoreCase);
						flag3 = num4 >= 0 && num4 < text.Length - PlanetPostfix.Length;
					}
				}
				else
				{
					if (!text.StartsWith(SystemPrefix) || !text.EndsWith(SystemPostfix))
					{
						text = SystemPrefix + text + SystemPostfix;
					}
					if (flag2 && text.Length > SystemPrefix.Length)
					{
						int num5 = text.IndexOf(searchStr, SystemPrefix.Length, StringComparison.OrdinalIgnoreCase);
						flag3 = num5 >= 0 && num5 < text.Length - SystemPostfix.Length;
					}
				}
				if (flag3)
				{
					newItems.Add(text);
					newItemData.Add(astroBox.ItemsData[j]);
				}
			}
		}
		astroBox.Items.RemoveRange(startIndex, astroBox.Items.Count - startIndex);
		astroBox.ItemsData.RemoveRange(startIndex, astroBox.ItemsData.Count - startIndex);
		if (localStarAstroId != 0 && !flag)
		{
			astroBox.Items.Add("统计当前星系".Translate());
			astroBox.ItemsData.Add(localStarAstroId);
		}
		astroBox.Items.AddRange(newItems);
		astroBox.ItemsData.AddRange(newItemData);
	}
}
