using System;
using System.Linq;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;
using StatsUITweaks;

static class Check
{
    static int Main()
    {
        Plugin.Log = new BepInEx.Logging.ManualLogSource("Stats check");
        StatsWindowPatch.TimeSliderSlice = 0; StatsWindowPatch.ListWidthOffeset = int.MaxValue; Utils.DropDownCount = -3;
        AccessTools.Method(typeof(Plugin), "ClampConfiguration").Invoke(null, null);
        if (StatsWindowPatch.TimeSliderSlice != 1 || StatsWindowPatch.ListWidthOffeset != 239 || Utils.DropDownCount != 1) throw new Exception("Unsafe UI settings retained");
        foreach (var method in new[] {AccessTools.Method(typeof(ProductionExtraInfoCalculator), "CalculateFactory"), AccessTools.Method(typeof(UIReferenceSpeedTip), "AddEntryDataWithFactory")})
        {
            var generator = new DynamicMethod("native", typeof(void), Type.EmptyTypes).GetILGenerator();
            var input = PatchProcessor.GetOriginalInstructions(method, generator);
            var output = ((IEnumerable<CodeInstruction>)AccessTools.Method(typeof(RefProductSpeedPatch), "MinerLimit_Transpiler").Invoke(null, new object[] {input})).ToList();
            if (output.Count(i => i.LoadsField(AccessTools.Field(typeof(RefProductSpeedPatch), "minerLimit"))) != 2) throw new Exception("Native oil/water limit patterns no longer match " + method.Name);
        }
        Console.WriteLine("PASS nonzero slider/dropdown, positive neighboring sort width, both current native oil/water reference-limit IL targets");
        return 0;
    }
}
