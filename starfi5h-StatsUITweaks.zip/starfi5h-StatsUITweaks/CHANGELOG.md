# starfi5h-StatsUITweaks — detailed change report

Installed plugin version(s): **1.6.18**. Bound invalid settings and UI dimensions; guard empty/invalid astro selection loops while preserving removed upstream options.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Bounds and selection safety — historical 1.6.16/1.6.17

Retain the installed 1.6.15 adaptation for 0.10.35.29088. Do not reactivate the deliberately disabled old ControlPanel patch; native name/index sorting stays in use.

- Clamp time-slider divisions and dropdown count to at least 1.
- Bound list width so the adjacent native 200-pixel sort box cannot become zero/negative width.
- Avoid accumulated UI-height additions on repeated updates.
- Do not apply selection shortcuts to an empty astro list; clamp the current selection before traversing it.
- Do not recalculate MMS reference production already supplied through native statistics. Check current native proliferator and oil/water reference-limit IL targets.
- Native `UIGame.OnSandCountChanged` only displays sand type/panel text in that game; hiding a notification does not replace history progression and needs no extra data/event patch.
- Version 1.6.17 adds `/unsafe+` metadata with private access checked in embedded Mono.

## Port onto the updated mod — 1.6.18, 15 October

Carry the bounds/height/astro guards forward and ensure an invalid starting selection cannot loop forever. Preserve updated setting-change subscriptions. Do not bring back upstream-removed `TabSizeSwitch`, `HideLitterNotification` or `HideSoilNotification` options.

Checks cover invalid settings, native reference-limit instruction matches and focused CLR/Mono behavior on the candidate/installed build. Histogram/dashboard rendering, actual GS astro lists and MMS/UXAssist interaction still require game acceptance.

## Recorded source commits

- `3d77a1ebff3ed4d0b7c29aba4e1b9a6b61f7bea1`

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
