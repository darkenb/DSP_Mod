using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using BepInEx.Bootstrap;
using HarmonyLib;

namespace ProjectGenesis.Compatibility;

internal static class LazyOutposting
{
	internal const string GUID = "eirshy.dsp.LazyOutposting";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.eirshy.dsp.LazyOutposting");

	internal static void Awake()
	{
		if (Chainloader.PluginInfos.TryGetValue("eirshy.dsp.LazyOutposting", out var value))
		{
			Type type = value.Instance.GetType().Assembly.GetType("Eirshy.DSP.LazyOutposting.Components.DwarvenContract");
			Type nestedType = type.GetNestedType("DwarfMission", BindingFlags.Instance | BindingFlags.NonPublic);
			Type nestedType2 = nestedType.GetNestedType("EGear", BindingFlags.Instance | BindingFlags.NonPublic);
			HarmonyPatch.Patch(AccessTools.Constructor(nestedType, new Type[1] { nestedType2 }), null, null, new HarmonyMethod(typeof(LazyOutposting), "DwarfMission_Constructor_Transpiler"));
			HarmonyPatch.CreateReversePatcher(AccessTools.Method(type, "SetUp"), new HarmonyMethod(typeof(LazyOutposting), "SetUp_ReversePatch")).Patch();
			SetUp_ReversePatch();
		}
	}

	public static IEnumerable<CodeInstruction> DwarfMission_Constructor_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Stloc_2));
		codeMatcher.InsertAndAdvance(new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(LazyOutposting), "Patch_Method_validTargets")));
		return codeMatcher.InstructionEnumeration();
	}

	public static List<EVeinType> Patch_Method_validTargets(List<EVeinType> validTargets)
	{
		validTargets.Add(EVeinType.Max);
		return validTargets;
	}

	public static void SetUp_ReversePatch()
	{
		Transpiler(null);
		static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions);
			codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Call), new CodeMatch(OpCodes.Ldtoken));
			codeMatcher.RemoveInstructions(codeMatcher.Remaining - 1);
			return codeMatcher.InstructionEnumeration();
		}
	}
}
