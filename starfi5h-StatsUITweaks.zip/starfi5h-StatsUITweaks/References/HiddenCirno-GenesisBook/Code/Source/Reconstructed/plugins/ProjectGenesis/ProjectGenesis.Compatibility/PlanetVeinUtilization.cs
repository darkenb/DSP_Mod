using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using BepInEx.Bootstrap;
using HarmonyLib;

namespace ProjectGenesis.Compatibility;

internal static class PlanetVeinUtilization
{
	internal const string GUID = "testpostpleaseignore.dsp.planet_vein_utilization";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.testpostpleaseignore.dsp.planet_vein_utilization");

	internal static void Awake()
	{
		if (Chainloader.PluginInfos.TryGetValue("testpostpleaseignore.dsp.planet_vein_utilization", out var value))
		{
			Type type = value.Instance.GetType().Assembly.GetType("PlanetVeinUtilization.PlanetVeinUtilization");
			Type nestedType = type.GetNestedType("VeinTypeInfo");
			HarmonyPatch.Patch(AccessTools.Method(type, "UIPlanetDetail_RefreshDynamicProperties_Postfix"), null, null, new HarmonyMethod(typeof(PlanetVeinUtilization), "RefreshDynamicProperties_Postfix_Transpiler"));
			HarmonyPatch.Patch(AccessTools.Method(type, "UIStarDetail_RefreshDynamicProperties_Postfix"), null, null, new HarmonyMethod(typeof(PlanetVeinUtilization), "RefreshDynamicProperties_Postfix_Transpiler"));
			ref Array reference = ref AccessTools.StaticFieldRefAccess<Array>(type, "planetVeinCount");
			ref Array reference2 = ref AccessTools.StaticFieldRefAccess<Array>(type, "starVeinCount");
			sbyte b = 21;
			reference = Array.CreateInstance(nestedType, b);
			for (int i = 0; i < b; i++)
			{
				reference.SetValue(Activator.CreateInstance(nestedType, null), i);
			}
			reference2 = Array.CreateInstance(nestedType, b);
			for (int j = 0; j < b; j++)
			{
				reference2.SetValue(Activator.CreateInstance(nestedType, null), j);
			}
		}
	}

	public static IEnumerable<CodeInstruction> RefreshDynamicProperties_Postfix_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldloc_S), new CodeMatch(OpCodes.Ldc_I4_S, (sbyte)15));
		codeMatcher.SetOperandAndAdvance((sbyte)21);
		return codeMatcher.InstructionEnumeration();
	}
}
