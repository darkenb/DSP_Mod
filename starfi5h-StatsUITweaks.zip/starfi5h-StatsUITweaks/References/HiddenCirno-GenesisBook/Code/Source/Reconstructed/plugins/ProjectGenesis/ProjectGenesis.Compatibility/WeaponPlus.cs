using System;
using BepInEx.Bootstrap;
using HarmonyLib;

namespace ProjectGenesis.Compatibility;

internal static class WeaponPlus
{
	internal const string GUID = "org.weaponplus.plugins.Xiaokls";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.org.weaponplus.plugins.Xiaokls");

	internal static void Awake()
	{
		if (Chainloader.PluginInfos.TryGetValue("org.weaponplus.plugins.Xiaokls", out var value))
		{
			Type type = value.Instance.GetType().Assembly.GetType("DSP_WeaponPlus.Utils.WPAddItem");
			HarmonyPatch.Patch(AccessTools.Method(type, "AddDiyItem"), new HarmonyMethod(typeof(WeaponPlus), "AddDiyItem_Prefix"));
		}
	}

	public static void AddDiyItem_Prefix(int[] inputIds)
	{
		for (int i = 0; i < inputIds.Length; i++)
		{
			if (inputIds[i] == 1201)
			{
				inputIds[i] = 6203;
			}
		}
	}
}
