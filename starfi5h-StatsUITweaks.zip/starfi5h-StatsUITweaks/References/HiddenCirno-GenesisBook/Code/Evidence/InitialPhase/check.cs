using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Runtime.Serialization;
using HarmonyLib;

class Check
{
    static Assembly plugin;
    static void Assert(bool condition, string message) { if (!condition) throw new Exception(message); }
    static MethodInfo Patch(string type, string name) {
        return plugin.GetType("ProjectGenesis.Patches." + type, true).GetMethod(name, BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
    }
    static List<CodeInstruction> Transpile(MethodBase original, string type, string patchName) {
        var input = PatchProcessor.GetOriginalInstructions(original, out ILGenerator generator);
        var patch = Patch(type, patchName);
        object[] parameters = patch.GetParameters().Select(parameter => {
            if (parameter.ParameterType == typeof(IEnumerable<CodeInstruction>)) return (object)input;
            if (parameter.ParameterType == typeof(MethodBase)) return original;
            if (parameter.ParameterType == typeof(ILGenerator)) return generator;
            throw new Exception("Unsupported check parameter: " + parameter);
        }).ToArray();
        var output = ((IEnumerable<CodeInstruction>)patch.Invoke(null, parameters)).ToList();
        Assert(output.Count != 0, "Transpiler returned empty native method");
        Console.WriteLine("PASS: native IL match " + original.DeclaringType.Name + "." + original.Name + " / " + patchName);
        return output;
    }
    static void NativeFeatures() {
        MethodInfo gamma = AccessTools.Method(typeof(PowerGeneratorComponent), "GameTick_Gamma");
        var changed = Transpile(gamma, "GammaGeneratorPatches", "PowerGeneratorComponent_GameTick_Gamma_Transpiler");
        FieldInfo catalyst = AccessTools.Field(typeof(PowerGeneratorComponent), "catalystPoint");
        Assert(changed.Where((instruction, index) => index + 2 < changed.Count && instruction.opcode == OpCodes.Ldfld && Equals(instruction.operand, catalyst)
            && changed[index + 1].opcode == OpCodes.Ldc_I4_S && Equals(changed[index + 1].operand, (sbyte)10) && changed[index + 2].opcode == OpCodes.Sub).Any(), "Lens point cost integration missing");
        Transpile(AccessTools.Method(typeof(UIPowerGeneratorWindow), "_OnUpdate"), "GammaGeneratorPatches", "UIPowerGeneratorWindow_OnUpdate_Transpiler");
        foreach (Type type in new[] { typeof(PlanetAlgorithm), typeof(PlanetAlgorithm7), typeof(PlanetAlgorithm11), typeof(PlanetAlgorithm12), typeof(PlanetAlgorithm13) }) {
            var method = AccessTools.Method(type, "GenerateVeins");
            Transpile(method, "AddVeinPatches", "PlanetAlgorithm_GenerateVeins_ResizeVeinList_Transpiler");
            Transpile(method, "AddVeinPatches", "PlanetAlgorithm_GenerateVeins_RemoveVeinPositionBias_Transpiler");
            if (type != typeof(PlanetAlgorithm7)) {
                Transpile(method, "AddVeinPatches", "PlanetAlgorithm_GenerateVeins_RemoveHeightLimit_Transpiler");
                Transpile(method, "AddVeinPatches", "PlanetAlgorithm_InitialVeins_Transpiler");
            }
        }
        foreach (string name in new[] { "_OnUpdate", "OnBoxMouseDown", "RefreshWindow", "RefreshIcons", "TestMouseIndex", "SetMaterialProps" })
            Transpile(AccessTools.Method(typeof(UILootFilter), name), "UILootFilterPatches", "UILootFilter_currentTypeField_Transpiler");
        Transpile(AccessTools.Method(typeof(UILootFilter), "RefreshIcons"), "UILootFilterPatches", "UILootFilter_RefreshIcons_Page_Transpiler");
        var filter = (UILootFilter)FormatterServices.GetUninitializedObject(typeof(UILootFilter));
        foreach (var mapping in new[] { Tuple.Create(0, 1), Tuple.Create(1, 2), Tuple.Create(2, 2), Tuple.Create(3, 3), Tuple.Create(4, 4) }) {
            AccessTools.Field(typeof(UILootFilter), "currentType").SetValue(filter, mapping.Item1);
            int result = (int)Patch("UILootFilterPatches", "GetPickPage").Invoke(null, new object[] { filter });
            Assert(result == mapping.Item2, "Item/building/drop/custom-tab page mapping");
        }
        Console.WriteLine("PASS: native Item/Building/Drop and CommonAPI custom-tab pick pages.");
    }
    static void SaveFixtures(string directory) {
        Directory.CreateDirectory(directory);
        typeof(StorageComponent).GetField("staticLoaded", AccessTools.all).SetValue(null, true);
        var stackCounts = new int[12000]; stackCounts[1001] = 100;
        typeof(StorageComponent).GetField("itemStackCount", AccessTools.all).SetValue(null, stackCounts);
        // Real legacy serializers for nonempty assembler/focus/power state, in isolated processes.
        foreach (string name in new[] { "MegaAssemblerPatches", "PlanetFocusPatches", "GlobalPowerSupplyPatches" }) {
            using (var seed = new MemoryStream()) {
                using (var writer = new BinaryWriter(seed, System.Text.Encoding.UTF8, true)) {
                    writer.Write(1); writer.Write(101);
                    if (name == "MegaAssemblerPatches") {
                        writer.Write(7); writer.Write(1); writer.Write(1); writer.Write(12); writer.Write(3); writer.Write(45);
                    } else if (name == "PlanetFocusPatches") { writer.Write(2); writer.Write(6522); writer.Write(6528); }
                    else { writer.Write(2); writer.Write(12); writer.Write(15); }
                }
                seed.Position = 0;
                Patch(name, "Import").Invoke(null, new object[] { new BinaryReader(seed) });
                using (var output = new MemoryStream()) {
                    Patch(name, "Export").Invoke(null, new object[] { new BinaryWriter(output) });
                    Assert(seed.ToArray().SequenceEqual(output.ToArray()), "Serializer changed legacy " + name + " data");
                    string path = Path.Combine(directory, name + ".bin");
                    if (File.Exists(path)) Assert(File.ReadAllBytes(path).SequenceEqual(output.ToArray()), "3.2.3 to 3.2.4 save bytes differ: " + name);
                    else File.WriteAllBytes(path, output.ToArray());
                }
            }
            Console.WriteLine("PASS: legacy save import/export " + name);
        }
        using (var seed = new MemoryStream()) {
            using (var writer = new BinaryWriter(seed, System.Text.Encoding.UTF8, true)) {
                writer.Write(1); writer.Write(101); writer.Write(1); writer.Write(42); writer.Write(8);
                for (int index = 0; index < 10; index++) {
                    var storage = new StorageComponent(80);
                    storage.id = index + 1;
                    storage.grids[0].itemId = 1001;
                    storage.grids[0].count = index + 2;
                    storage.grids[0].inc = index + 1;
                    storage.grids[0].stackSize = 100;
                    storage.Export(writer);
                }
            }
            seed.Position = 0;
            Patch("QuantumStoragePatches", "Import").Invoke(null, new object[] { new BinaryReader(seed) });
            using (var output = new MemoryStream()) {
                Patch("QuantumStoragePatches", "Export").Invoke(null, new object[] { new BinaryWriter(output) });
                Assert(seed.ToArray().SequenceEqual(output.ToArray()), "Quantum storage item/inc save bytes changed");
                string path = Path.Combine(directory, "QuantumStoragePatches.bin");
                if (File.Exists(path)) Assert(File.ReadAllBytes(path).SequenceEqual(output.ToArray()), "Legacy quantum fixture changed");
                else File.WriteAllBytes(path, output.ToArray());
            }
        }
        Console.WriteLine("PASS: legacy quantum storage save, ten native storages, item counts and inc.");
        Patch("AdvancedLaserPatches", "IntoOtherSave").Invoke(null, null);
        using (var first = new MemoryStream()) {
            Patch("AdvancedLaserPatches", "Export").Invoke(null, new object[] { new BinaryWriter(first) });
            first.Position = 0;
            Patch("AdvancedLaserPatches", "Import").Invoke(null, new object[] { new BinaryReader(first) });
            using (var second = new MemoryStream()) {
                Patch("AdvancedLaserPatches", "Export").Invoke(null, new object[] { new BinaryWriter(second) });
                Assert(first.ToArray().SequenceEqual(second.ToArray()), "Advanced laser pool save changed");
                string path = Path.Combine(directory, "AdvancedLaserPatches.bin");
                if (File.Exists(path)) Assert(File.ReadAllBytes(path).SequenceEqual(second.ToArray()), "Legacy laser fixture changed");
                else File.WriteAllBytes(path, second.ToArray());
            }
        }
        Console.WriteLine("PASS: legacy advanced laser pool empty-state save round trip.");
    }
    static void GSCompatibility() {
        var gs = Assembly.Load("GalacticScale");
        var target = AccessTools.Method(gs.GetType("GalacticScale.PatchOnUIStarDetail"), "OnStarDataSet2");
        Assert(target != null, "Installed GS star panel target missing");
        var compatibility = plugin.GetType("ProjectGenesis.Compatibility.GalacticScale", true);
        var detail = plugin.GetType("ProjectGenesis.Patches.UIDetailPatches", true);
        var sequence = new[] {
            AccessTools.Method(detail, "OnDataSet_ChangeHighlightWaterId_Transpiler"),
            AccessTools.Method(detail, "UIStarDetail_OnStarDataSet_ActiveGasItems_Transpiler"),
            AccessTools.Method(detail, "UIPlanetDetail_OnPlanetDataSet_FixCollectorSpeed_Transpiler"),
            AccessTools.Method(compatibility, "OnStarDataSet_ChangeVeinData_Transpiler")
        };
        var harmony = new Harmony("test.genesis.gs.star.compatibility");
        try {
            foreach (var transpiler in sequence) harmony.Patch(target, transpiler: new HarmonyMethod(transpiler));
            var result = PatchProcessor.GetCurrentInstructions(target);
            Assert(result.Count(c => c.operand is MethodInfo m && m.Name == "OnStarDataSet_ChangeVeinData_HighlightPatches") == 2,
                "GS star highlight checks not replaced exactly twice");
            Assert(result.Count(c => c.operand is MethodInfo m && m.Name == "OnStarDataSet_ChangeVeinData_IndexPatches") == 1,
                "GS extended vein loop not remapped exactly once");
            Console.WriteLine("PASS installed GS " + gs.GetName().Version + " star panel: full four-transpiler registration chain, two highlights and extended vein loop");
        } finally { harmony.UnpatchSelf(); }
    }

    static bool BriefStringStub(ref string __result) { __result = "headless gas fixture"; return false; }
    static ThemeProtoSet fixtureThemes;
    static ItemProtoSet fixtureItems;
    static bool ThemesStub(ref ThemeProtoSet __result) { __result = fixtureThemes; return false; }
    static bool ItemsStub(ref ItemProtoSet __result) { __result = fixtureItems; return false; }
    static void SetField(object instance, string name, object value) { AccessTools.Field(instance.GetType(), name).SetValue(instance, value); }
    static void GasThemeCompatibility() {
        var gs = Assembly.Load("GalacticScale");
        var gs2 = gs.GetType("GalacticScale.GS2", true);
        var target = AccessTools.Method(gs2, "SetPlanetTheme");
        var compatibility = plugin.GetType("ProjectGenesis.Compatibility.GalacticScale", true);
        var transpiler = AccessTools.Method(compatibility, "SetPlanetTheme_Transpiler");
        var native = PatchProcessor.GetOriginalInstructions(target);
        var patched = ((IEnumerable<CodeInstruction>)transpiler.Invoke(null, new object[] { native.Select(i => new CodeInstruction(i)).ToList() })).ToList();
        int guard = native.FindIndex(i => i.LoadsField(AccessTools.Field(typeof(PlanetData), "type")) && native[native.IndexOf(i) + 1].LoadsConstant(5)) - 1;
        Assert(guard >= 0, "Gas-only guard missing");
        // An optimized build has only five guard instructions; the old ten-Nop patch erases GasItems.Length too.
        for (int i = guard; i < guard + 14; i++) Console.WriteLine("GAS IL " + i + " " + native[i] + " -> " + patched[i]);
        Assert(native.Count == patched.Count && native.Where((i, n) => n < guard || n > guard + 2)
            .All(i => { int n = native.IndexOf(i); return i.opcode == patched[n].opcode && Equals(i.operand, patched[n].operand); }),
            "Gas guard patch must preserve every instruction after the comparison, including GasItems.Length");

        string root = Path.Combine(Path.GetTempPath(), "genesis-gas-check-" + Guid.NewGuid());
        AccessTools.Method(typeof(BepInEx.Paths), "SetExecutablePath").Invoke(null, new object[] {
            Path.Combine(root, "DSPGAME.exe"), Path.Combine(root, "BepInEx"),
            "D:/Games/Dyson Sphere Program/DSPGAME_Data/Managed", new string[0] });
        var themeType = gs.GetType("GalacticScale.GSTheme", true);
        var gsPlanetType = gs.GetType("GalacticScale.GSPlanet", true);
        var library = Activator.CreateInstance(gs.GetType("GalacticScale.ThemeLibrary", true));
        var settings = gs.GetType("GalacticScale.GSSettings", true);
        AccessTools.Property(settings, "ThemeLibrary").SetValue(null, library, null);
        var proto = new ThemeProto { ID = 1, Name = "fixture" };
        var themes = (ThemeProtoSet)FormatterServices.GetUninitializedObject(typeof(ThemeProtoSet));
        SetField(themes, "dataArray", new[] { proto });
        SetField(themes, "dataIndices", new Dictionary<int, int> { [1] = 0 });
        AccessTools.Field(typeof(LDB), "_themes").SetValue(null, themes);
        var items = (ItemProtoSet)FormatterServices.GetUninitializedObject(typeof(ItemProtoSet));
        SetField(items, "dataArray", new[] { new ItemProto { ID = 1001, HeatValue = 10 }, new ItemProto { ID = 1002, HeatValue = 20 }, new ItemProto { ID = 1003, HeatValue = 30 } });
        SetField(items, "dataIndices", new Dictionary<int, int> { [1001] = 0, [1002] = 1, [1003] = 2 });
        AccessTools.Field(typeof(LDB), "_items").SetValue(null, items);
        fixtureThemes = themes; fixtureItems = items;
        var harmony = new Harmony("test.genesis.gs.gas.compatibility");
        try {
            harmony.Patch(AccessTools.PropertyGetter(typeof(PlanetData), "briefString"), prefix: new HarmonyMethod(typeof(Check), nameof(BriefStringStub)));
            harmony.Patch(AccessTools.PropertyGetter(typeof(LDB), "themes"), prefix: new HarmonyMethod(typeof(Check), nameof(ThemesStub)));
            harmony.Patch(AccessTools.PropertyGetter(typeof(LDB), "items"), prefix: new HarmonyMethod(typeof(Check), nameof(ItemsStub)));
            harmony.Patch(target, transpiler: new HarmonyMethod(transpiler), postfix: new HarmonyMethod(AccessTools.Method(compatibility, "SetPlanetTheme_Postfix")));
            foreach (EPlanetType planetType in new[] { EPlanetType.Gas, EPlanetType.Ocean, EPlanetType.Desert })
            foreach (int count in new[] { 0, 1, 2, 3 }) {
                var theme = FormatterServices.GetUninitializedObject(themeType);
                int[] ids = Enumerable.Range(1001, count).ToArray();
                float[] speeds = Enumerable.Range(1, count).Select(i => i * 0.2f).ToArray();
                foreach (var field in new Dictionary<string, object> { ["Name"] = "fixture", ["DisplayName"] = "fixture", ["added"] = true,
                    ["LDBThemeId"] = 1, ["PlanetType"] = planetType, ["GasItems"] = ids, ["GasSpeeds"] = speeds }) SetField(theme, field.Key, field.Value);
                library.GetType().GetProperty("Item").SetValue(library, theme, new object[] { "fixture" });
                var gsPlanet = FormatterServices.GetUninitializedObject(gsPlanetType);
                AccessTools.Property(gsPlanetType, "Theme").SetValue(gsPlanet, "fixture", null);
                AccessTools.Property(gsPlanetType, "Seed").SetValue(gsPlanet, 42, null);
                var planet = new PlanetData { star = new StarData { index = 0 } };
                target.Invoke(null, new object[] { planet, gsPlanet });
                Assert(planet.gasItems.SequenceEqual(ids) && planet.gasSpeeds.Length == count && planet.gasHeatValues.Length == count, "Gas item/speed/heat arrays changed");
                Assert(planet.gasSpeeds.All(v => v > 0), "Gas production must remain positive");
                if (planetType != EPlanetType.Gas) Assert(planet.gasTotalHeat == 0 && planet.gasHeatValues.All(v => v == 0), "Atmosphere must have zero heat");
                else Assert(count == 0 ? planet.gasTotalHeat == 0 : planet.gasTotalHeat > 0, "Gas giant total heat mismatch");
            }
            Console.WriteLine("PASS: actual GS SetPlanetTheme plus Genesis transpiler/postfix: gas, ocean, desert; 0/1/2/3 gases; IDs, production and heat preserved.");
        } finally { harmony.UnpatchSelf(); }
    }
    static void Main(string[] args) {
        try {
            string path = args.FirstOrDefault(arg => arg.EndsWith("ProjectGenesis.dll", StringComparison.OrdinalIgnoreCase))
                ?? Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ProjectGenesis.dll");
            plugin = Assembly.LoadFrom(path);
            if (args.Contains("--gas-only")) { GasThemeCompatibility(); return; }
            string fixtures = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "legacy-save-fixtures");
            SaveFixtures(fixtures);
            if (!args.Contains("--legacy")) { NativeFeatures(); GSCompatibility(); GasThemeCompatibility(); }
        } catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }
    }
}
