using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using HarmonyLib;
using MoreMegaStructure;

static class Check
{
    static int trash, player, end;
    static readonly List<int> seen = new List<int>();
    static void Assert(bool value, string name) { if (!value) throw new Exception(name); Console.WriteLine("PASS " + name); }
    static bool Trash() { trash++; return false; }
    static bool Player() { player++; return false; }
    static bool Factory(GameData gameData, PlanetFactory factory)
    { seen.Add(factory.index); return false; }
    static T Empty<T>() => (T)FormatterServices.GetUninitializedObject(typeof(T));
    static PlanetFactory RealFactory(int index)
    {
        var factory = new PlanetFactory(); AccessTools.Property(typeof(PlanetFactory), "index").SetValue(factory, index, null); return factory;
    }
    static GameData World()
    {
        var data = Empty<GameData>(); data.factories = new PlanetFactory[3];
        data.factories[0] = RealFactory(0); data.factories[1] = RealFactory(1);
        data.factoryCount = 2; data.galaxy = new GalaxyData {starCount = 2};
        return data;
    }
    static ProductionExtraInfoCalculator Calculator(GameData data)
    {
        var calculator = new ProductionExtraInfoCalculator();
        var production = new ProductionStatistics(); production.gameData = data; calculator.Init(production);
        calculator.onEndCalculate += d => end++;
        calculator.AddFactory(0); calculator.AddFactory(4); calculator.AddFactory(1); calculator.AddFactory(3);
        calculator.AddFactory(4); // duplicate requests stay native HashSet entries.
        return calculator;
    }
    static void Lifecycle()
    {
        var harmony = new Harmony("test.mms.calculator");
        var transpiler = new HarmonyMethod(typeof(StatisticsCalculatorBridge), "ReplaceFactoryLookup");
        harmony.Patch(AccessTools.Method(typeof(ProductionExtraInfoCalculator), "GameTick"), transpiler: transpiler);
        harmony.Patch(AccessTools.Method(typeof(ProductionExtraInfoCalculator), "CalculateImmediately"), transpiler: transpiler);
        harmony.Patch(AccessTools.Method(typeof(ProductionExtraInfoCalculator), "CalculateFactory"), prefix: new HarmonyMethod(typeof(Check), "Factory"));
        harmony.Patch(AccessTools.Method(typeof(ProductionExtraInfoCalculator), "CalculateTrashCount"), prefix: new HarmonyMethod(typeof(Check), "Trash"));
        harmony.Patch(AccessTools.Method(typeof(ProductionExtraInfoCalculator), "CalculatePlayerStorageCount"), prefix: new HarmonyMethod(typeof(Check), "Player"));
        try
        {
            var data = World();
            Assert(ReferenceEquals(StatisticsCalculatorBridge.Lookup(data, 1), data.factories[1]), "real factory identity preserved");
            Assert(StatisticsCalculatorBridge.Lookup(data, 4).index == 4 && data.factories.Length == 3, "virtual factory does not modify world array");
            var calculator = Calculator(data);
            for (int n = 0; n < 12 && end == 0; n++) calculator.GameTick();
            Assert(seen.OrderBy(i => i).SequenceEqual(new[] {0, 1, 3, 4}) && trash == 1 && player == 1 && end == 1 && !calculator.calculating,
                "native mixed tick calculation handles each factory once and completes lifecycle");
            seen.Clear(); trash = player = end = 0; calculator = Calculator(data); calculator.CalculateImmediately();
            Assert(seen.OrderBy(i => i).SequenceEqual(new[] {0, 1, 3, 4}) && trash == 1 && player == 1 && end == 1 && !calculator.calculating,
                "native immediate calculation supports virtual factories and completes lifecycle");
            seen.Clear(); calculator.GameTick();
            Assert(seen.Count == 0 && end == 1, "completed pending set is empty");
        }
        finally { harmony.UnpatchSelf(); }
    }
    static void Rates()
    {
        var data = World(); GameMain.data = data;
        data.dysonSpheres = new[] {new DysonSphere(), new DysonSphere()};
        data.dysonSpheres[0].energyGenCurrentTick = 20000;
        data.statistics = new GameStatData(); data.statistics.production = new ProductionStatistics();
        var pool = new FactoryProductionStat[5]; for (int i = 0; i < pool.Length; i++) {pool[i] = new FactoryProductionStat(); pool[i].Init();}
        data.statistics.production.factoryStatPool = pool;
        StarAssembly.recipeIds = new List<List<int>> { Enumerable.Repeat(0, 16).ToList() }; StarAssembly.recipeIds[0][15] = 1;
        StarAssembly.weights = new List<List<double>> {Enumerable.Repeat(0.0, 16).ToList()}; StarAssembly.weights[0][15] = 1;
        StarAssembly.timeSpend[0] = Enumerable.Repeat(1, 16).ToList();
        StarAssembly.productSpeedRequest = new List<List<int>> {Enumerable.Repeat(3600, 16).ToList()};
        StarAssembly.curSpecType = new List<int> {0}; StarAssembly.specBuffLevel[0] = Enumerable.Repeat(0, 16).ToList();
        StarAssembly.incProgress = new List<List<double>> {Enumerable.Repeat(0.0, 16).ToList()};
        StarAssembly.items[0] = Enumerable.Range(0, 16).Select(i => new List<int>()).ToList(); StarAssembly.items[0][15].Add(1001);
        StarAssembly.itemCounts[0] = Enumerable.Range(0, 16).Select(i => new List<int>()).ToList(); StarAssembly.itemCounts[0][15].Add(2);
        StarAssembly.products[0] = Enumerable.Range(0, 16).Select(i => new List<int>()).ToList(); StarAssembly.products[0][15].Add(1101);
        StarAssembly.productCounts[0] = Enumerable.Range(0, 16).Select(i => new List<int> {1}).ToList();
        UIStatisticsPatcher.MMSRefreshItemsCyclicRefSpeedWithFactory(0, 0);
        var stat = pool[4];
        Assert(stat.productPool[stat.productIndices[1001]].refConsumeSpeed == 7200 && stat.productPool[stat.productIndices[1101]].refProductSpeed == 3600,
            "last assembly recipe slot contributes native product and consume rates");
        UIStatisticsPatcher.MMSRefreshItemsCyclicRefSpeedWithFactory(0, 0);
        Assert(stat.productPool[stat.productIndices[1101]].refProductSpeed == 3600, "refresh does not double reference speed");
        UIStatisticsPatcher.MMSRefreshItemsCyclicRefSpeedWithFactory(0, 4);
        Assert(Math.Abs(stat.productPool[stat.productIndices[1101]].refProductSpeed - 3600 * (1 + Cargo.incTableMilli[4])) < 0.01,
            "native proliferator bonus included in assembly reference production");
        MoreMegaStructure.MoreMegaStructure.StarMegaStructureType = new int[2];
        var calculator = new ProductionExtraInfoCalculator(); calculator.Init(data.statistics.production);
        Assert(!StatisticsCalculatorBridge.CalculateFactoryPrefix(calculator, data, StatisticsCalculatorBridge.Lookup(data, 4))
            && stat.productPool[stat.productIndices[1101]].refProductSpeed == 0,
            "changed mega type clears stale virtual rates without running native planet calculation");
    }
    static int Main()
    {
        int patchCount = 0;
        foreach (var patch in typeof(UIStatisticsPatcher).GetMethods(BindingFlags.Static | BindingFlags.Public))
        {
            var attribute = patch.GetCustomAttributes(typeof(HarmonyPatch), false).Cast<HarmonyPatch>().FirstOrDefault();
            if (attribute == null) continue;
            var info = attribute.info;
            var target = AccessTools.Method(info.declaringType, info.methodName, info.argumentTypes);
            Assert(target != null && target.GetMethodBody() != null, "native statistics target " + info.declaringType.Name + "." + info.methodName);
            foreach (var argument in patch.GetParameters())
            {
                if (patch.IsDefined(typeof(HarmonyTranspiler), false)) continue;
                if (argument.Name.StartsWith("__")) continue;
                var original = target.GetParameters().FirstOrDefault(p => p.Name == argument.Name);
                Assert(original != null && ElementType(original.ParameterType) == ElementType(argument.ParameterType),
                    "native patch parameter " + patch.Name + "." + argument.Name);
            }
            patchCount++;
        }
        Assert(patchCount >= 20, "all active statistics patch signatures validated without Unity UI JIT");
        Lifecycle(); Rates();
        var applyAll = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(UIReceiverPatchers), "ApplyAll")).ToArray();
        Assert(applyAll.Any(i => i.LoadsConstant(2208)) && applyAll.Any(i => i.LoadsField(AccessTools.Field(typeof(EntityData), "protoId"))),
            "installed 1.9.4 synthesis filter preserved in compiled ApplyAll");
        Assert(!UIStatisticsPatcher.forceBanned, "ported statistics panel enabled by configured setting");
        return 0;
    }
    static Type ElementType(Type type) => type.IsByRef ? type.GetElementType() : type;
}
