using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace MoreMegaStructure;

public static class StatisticsCalculatorBridge
{
	public static PlanetFactory Lookup(GameData gameData, int factoryIndex)
	{
		if (factoryIndex >= 0 && factoryIndex < gameData.factories.Length)
		{
			return gameData.factories[factoryIndex];
		}
		if (factoryIndex < gameData.factories.Length || factoryIndex >= gameData.factories.Length + gameData.galaxy.starCount)
		{
			throw new ArgumentOutOfRangeException("factoryIndex");
		}
		PlanetFactory planetFactory = new PlanetFactory();
		AccessTools.Property(typeof(PlanetFactory), "index").SetValue(planetFactory, factoryIndex, null);
		return planetFactory;
	}

	public static IEnumerable<CodeInstruction> ReplaceFactoryLookup(IEnumerable<CodeInstruction> instructions)
	{
		List<CodeInstruction> list = new List<CodeInstruction>(instructions);
		FieldInfo field = AccessTools.Field(typeof(GameData), "factories");
		MethodInfo operand = AccessTools.Method(typeof(StatisticsCalculatorBridge), "Lookup");
		int num = 0;
		for (int i = 0; i + 2 < list.Count; i++)
		{
			if (list[i].LoadsField(field) && list[i + 1].IsLdloc() && !(list[i + 2].opcode != OpCodes.Ldelem_Ref))
			{
				list[i].opcode = OpCodes.Nop;
				list[i].operand = null;
				list[i + 2].opcode = OpCodes.Call;
				list[i + 2].operand = operand;
				num++;
			}
		}
		if (num != 1)
		{
			throw new InvalidOperationException("Production calculator factory lookup changed: " + num);
		}
		return list;
	}

	public static bool CalculateFactoryPrefix(ProductionExtraInfoCalculator __instance, GameData gameData, PlanetFactory factory)
	{
		if (factory == null || factory.index < gameData.factories.Length)
		{
			return true;
		}
		UIStatisticsPatcher.CalculateFactory_IA(ref __instance, gameData, factory.index);
		return false;
	}
}
