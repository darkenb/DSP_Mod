using BepInEx;

namespace MoreMegaStructure;

[BepInDependency("org.LoShin.GenesisBook", BepInDependency.DependencyFlags.HardDependency)]
[BepInPlugin("Gnimaerd.DSP.plugin.MMSGCPatch", "MMSGCPatch", "1.0")]
public class GenesisCompatibilityPatch : BaseUnityPlugin
{
	private void Awake()
	{
		if (!MoreMegaStructure.isBattleActive)
		{
			MoreMegaStructure.GenesisCompatibility = true;
		}
	}
}
