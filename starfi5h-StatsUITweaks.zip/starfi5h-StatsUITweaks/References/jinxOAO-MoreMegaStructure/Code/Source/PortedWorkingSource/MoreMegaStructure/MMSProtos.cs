using System.Collections.Generic;
using CommonAPI.Systems;
using CommonAPI.Systems.ModLocalization;
using HarmonyLib;
using UnityEngine;
using xiaoye97;

namespace MoreMegaStructure;

internal static class MMSProtos
{
	public class StringProto
	{
		public string Name { get; set; }

		public string ZHCN { get; set; }

		public string ENUS { get; set; }

		public void RegisterTranslation()
		{
			LocalizationModule.RegisterTranslation(Name, ENUS, ZHCN, "");
		}
	}

	public static int StarCannonTechId = 1918;

	public static int componentId = 9500;

	internal static void RefreshInitAll()
	{
		ItemProto.InitFluids();
		ItemProto.InitItemIds();
		ItemProto.InitFuelNeeds();
		ItemProto.InitItemIndices();
		ItemProto.InitMechaMaterials();
	}

	public static void ItemsDesc()
	{
	}

	internal static void AddNewItems()
	{
		int num = MoreMegaStructure.pagenum * 1000;
		int num2 = 0;
		bool flag = true;
		num = MoreMegaStructure.pagenum * 1000 + 100;
		num2 = -100;
		RecipeProto recipeProto = LDB.recipes.Select(51);
		RecipeProto recipeProto2 = MethedEx.Copy<RecipeProto>(recipeProto);
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto2.Type = (ERecipeType)10;
		}
		ItemProto itemProto = LDB.items.Select(1303);
		int num3 = 0;
		if (MoreMegaStructure.GenesisCompatibility)
		{
			num3 = -200;
		}
		ProtoRegistry.RegisterItem(9480, "引力发生装置".Translate(), "引力发生装置描述".Translate(), "Assets/MegaStructureTab/gravitygenerator", 101 + num + num2, 100, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0.2f, 0.9f, 0.3f)));
		ProtoRegistry.RegisterRecipe(num3 + 530, ERecipeType.Assemble, 180, new int[2] { 1107, 1127 }, new int[2] { 1, 1 }, new int[1] { 9480 }, new int[1] { 1 }, "引力发生装置描述", 1704, 101 + num + num2, "Assets/MegaStructureTab/gravitygenerator");
		ProtoRegistry.RegisterItem(9481, "位面约束环".Translate(), "位面约束环描述".Translate(), "Assets/MegaStructureTab/constrainring", 102 + num + num2, 100, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0.4f, 0.08f, 0.4f)));
		if (MoreMegaStructure.GenesisCompatibility)
		{
			ProtoRegistry.RegisterRecipe(num3 + 531, ERecipeType.Assemble, 180, new int[3] { 1205, 1119, 1126 }, new int[3] { 2, 1, 1 }, new int[1] { 9481 }, new int[1] { 2 }, "位面约束环描述", 1141, 102 + num + num2, "Assets/MegaStructureTab/constrainring");
		}
		else
		{
			ProtoRegistry.RegisterRecipe(num3 + 531, ERecipeType.Assemble, 180, new int[2] { 1205, 1304 }, new int[2] { 2, 1 }, new int[1] { 9481 }, new int[1] { 2 }, "位面约束环描述", 1141, 102 + num + num2, "Assets/MegaStructureTab/constrainring");
		}
		ProtoRegistry.RegisterItem(9482, "引力钻头".Translate(), "引力钻头描述".Translate(), "Assets/MegaStructureTab/gravitydrill2", 103 + num + num2, 50, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.black, new Color(0.3f, 0.9f, 0.3f)));
		ProtoRegistry.RegisterRecipe(num3 + 532, ERecipeType.Assemble, 180, new int[3] { 9480, 9481, 1209 }, new int[3] { 1, 1, 1 }, new int[1] { 9482 }, new int[1] { 1 }, "引力钻头描述", 1704, 103 + num + num2, "Assets/MegaStructureTab/gravitydrill2");
		ProtoRegistry.RegisterItem(9483, "隧穿激发装置".Translate(), "隧穿激发装置描述".Translate(), "Assets/MegaStructureTab/tunnelingexciter2", 104 + num + num2, 200, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0.2f, 0.1f, 0f)));
		ProtoRegistry.RegisterRecipe(num3 + 533, ERecipeType.Assemble, 360, new int[2] { 1303, 1014 }, new int[2] { 1, 2 }, new int[1] { 9483 }, new int[1] { 6 }, "隧穿激发装置描述", 1703, 104 + num + num2, "Assets/MegaStructureTab/tunnelingexciter2");
		ProtoRegistry.RegisterItem(9484, "谐振盘".Translate(), "谐振盘描述".Translate(), "Assets/MegaStructureTab/resonancedisc", 105 + num + num2, 200, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.gray, new Color(0.4f, 0.4f, 0.8f)));
		ProtoRegistry.RegisterRecipe(num3 + 534, ERecipeType.Assemble, 240, new int[3] { 9483, 1113, 1305 }, new int[3] { 3, 2, 1 }, new int[1] { 9484 }, new int[1] { 1 }, "谐振盘描述", 1303, 105 + num + num2, "Assets/MegaStructureTab/resonancedisc");
		IconToolNew.IconDesc defaultIconDesc = ProtoRegistry.GetDefaultIconDesc(Color.gray, new Color(0.6f, 0.6f, 0.9f));
		defaultIconDesc.solidAlpha = 0.1f;
		ProtoRegistry.RegisterItem(9485, "光子探针".Translate(), "光子探针描述".Translate(), "Assets/MegaStructureTab/photonprobeflipsmall", 106 + num + num2, 200, EItemType.Component, defaultIconDesc);
		ProtoRegistry.RegisterRecipe(num3 + 535, ERecipeType.Assemble, 240, new int[2] { 1404, 1208 }, new int[2] { 2, 1 }, new int[1] { 9485 }, new int[1] { 1 }, "光子探针描述", 1504, 106 + num + num2, "Assets/MegaStructureTab/photonprobeflipsmall");
		IconToolNew.IconDesc defaultIconDesc2 = ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0f, 0.7f, 1f));
		defaultIconDesc2.solidAlpha = 0f;
		ProtoRegistry.RegisterItem(9486, "量子计算机".Translate(), "量子计算机描述".Translate(), "Assets/MegaStructureTab/quantumcomputer3", 107 + num + num2, 200, EItemType.Component, defaultIconDesc2);
		ProtoRegistry.RegisterRecipe(num3 + 536, ERecipeType.Assemble, 720, new int[3] { 1305, 1402, 9483 }, new int[3] { 3, 2, 1 }, new int[1] { 9486 }, new int[1] { 1 }, "量子计算机描述", 1303, 107 + num + num2, "Assets/MegaStructureTab/quantumcomputer3");
		ProtoRegistry.RegisterItem(9487, "星际组装厂组件".Translate(), "星际组装厂组件描述".Translate(), "Assets/MegaStructureTab/iacomponent", 108 + num + num2, 200, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0.7f, 0.2f, 0.7f)));
		ProtoRegistry.RegisterRecipe(num3 + 537, ERecipeType.Assemble, 480, new int[3] { 1125, 2305, 1143 }, new int[3] { 3, 3, 1 }, new int[1] { 9487 }, new int[1] { 1 }, "星际组装厂组件描述", 1303, 108 + num + num2, "Assets/MegaStructureTab/iacomponent");
		RecipeProto recipeProto3 = LDB.recipes.Select(83);
		ItemProto itemProto2 = LDB.items.Select(1503);
		ProtoRegistry.RegisterItem(9488, "物质解压器运载火箭".Translate(), "物质解压器运载火箭描述".Translate(), "Assets/MegaStructureTab/rocketMatter", 201 + num, 20, EItemType.Product, ProtoRegistry.GetDefaultIconDesc(new Color(1f, 0.9f, 0.9f), new Color(0.7f, 0.2f, 0.2f)));
		RecipeProto recipeProto4 = ProtoRegistry.RegisterRecipe(num3 + 538, ERecipeType.Assemble, 480, new int[3] { 9482, 9484, 1802 }, new int[3] { 2, 1, 2 }, new int[1] { 9488 }, new int[1] { 1 }, "物质解压器运载火箭描述", 1522, 201 + num, "Assets/MegaStructureTab/rocketMatter");
		ProtoRegistry.RegisterItem(9489, "科学枢纽运载火箭".Translate(), "科学枢纽运载火箭描述".Translate(), "Assets/MegaStructureTab/rocketScience", 202 + num, 20, EItemType.Product, ProtoRegistry.GetDefaultIconDesc(new Color(1f, 1f, 0.9f), new Color(0.7f, 0.7f, 0.2f)));
		RecipeProto recipeProto5 = ProtoRegistry.RegisterRecipe(num3 + 539, ERecipeType.Assemble, 480, new int[3] { 9481, 9486, 1802 }, new int[3] { 3, 1, 2 }, new int[1] { 9489 }, new int[1] { 1 }, "科学枢纽运载火箭描述", 1522, 202 + num, "Assets/MegaStructureTab/rocketScience");
		ProtoRegistry.RegisterItem(9490, "谐振发射器运载火箭".Translate(), "谐振发射器运载火箭描述".Translate(), "Assets/MegaStructureTab/rocketWarp", 203 + num, 20, EItemType.Product, ProtoRegistry.GetDefaultIconDesc(new Color(0.9f, 1f, 0.9f), new Color(0.2f, 0.7f, 0.2f)));
		RecipeProto recipeProto6 = ProtoRegistry.RegisterRecipe(num3 + 540, ERecipeType.Assemble, 480, new int[3] { 9480, 9484, 1802 }, new int[3] { 1, 4, 2 }, new int[1] { 9490 }, new int[1] { 1 }, "谐振发射器运载火箭描述", 1522, 203 + num, "Assets/MegaStructureTab/rocketWarp");
		ProtoRegistry.RegisterItem(9491, "星际组装厂运载火箭".Translate(), "星际组装厂运载火箭描述".Translate(), "Assets/MegaStructureTab/rocketAssembly", 204 + num, 20, EItemType.Product, ProtoRegistry.GetDefaultIconDesc(new Color(0.9f, 0.9f, 1f), new Color(0.1f, 0.5f, 0.7f)));
		RecipeProto recipeProto7 = ProtoRegistry.RegisterRecipe(num3 + 541, ERecipeType.Assemble, 480, new int[2] { 9487, 1802 }, new int[2] { 2, 2 }, new int[1] { 9491 }, new int[1] { 1 }, "星际组装厂运载火箭描述", 1522, 204 + num, "Assets/MegaStructureTab/rocketAssembly");
		ProtoRegistry.RegisterItem(9492, "晶体重构器运载火箭".Translate(), "晶体重构器运载火箭描述".Translate(), "Assets/MegaStructureTab/rocketCrystal", 205 + num, 20, EItemType.Product, ProtoRegistry.GetDefaultIconDesc(new Color(1f, 0.9f, 1f), new Color(0.7f, 0.2f, 0.7f)));
		RecipeProto recipeProto8 = ProtoRegistry.RegisterRecipe(num3 + 542, ERecipeType.Assemble, 480, new int[3] { 9485, 1802, 1305 }, new int[3] { 1, 2, 2 }, new int[1] { 9492 }, new int[1] { 1 }, "晶体重构器运载火箭描述", 1522, 205 + num, "Assets/MegaStructureTab/rocketCrystal");
		ProtoRegistry.RegisterItem(9500, "多功能集成组件".Translate(), "多功能集成组件描述".Translate(), "Assets/MegaStructureTab/integratedcomponents", 109 + num + num2, 1000, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.white, Color.white));
		ProtoRegistry.RegisterRecipe(num3 + 550, ERecipeType.Assemble, 60, new int[1] { 9500 }, new int[1] { 1 }, new int[1] { 9500 }, new int[1] { 1 }, "多功能集成组件描述", 1203, 199 + num + num2, "Assets/MegaStructureTab/integratedcomponents");
		RecipeProto recipeProto9 = LDB.recipes.Select(47);
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto9.Type = (ERecipeType)10;
		}
		RecipeProto recipeProto10 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto10.ID = num3 + 551;
		recipeProto10.Name = "传送带 快速组装";
		recipeProto10.name = "传送带 快速组装".Translate();
		recipeProto10.Description = "快速组装描述";
		recipeProto10.description = "快速组装描述".Translate();
		recipeProto10.Items = new int[1] { 9500 };
		recipeProto10.ItemCounts = new int[1] { 1 };
		recipeProto10.Results = new int[1] { 2003 };
		recipeProto10.ResultCounts = new int[1] { 60 };
		recipeProto10.GridIndex = 401 + num;
		recipeProto10.TimeSpend = 6;
		Traverse.Create(recipeProto10).Field("_iconSprite").SetValue(MoreMegaStructure.iconQuickBelt);
		RecipeProto recipeProto11 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto11.ID = 552;
		recipeProto11.Name = "分拣器 快速组装";
		recipeProto11.name = "分拣器 快速组装".Translate();
		recipeProto11.Description = "快速组装描述";
		recipeProto11.description = "快速组装描述".Translate();
		recipeProto11.Items = new int[1] { 9500 };
		recipeProto11.ItemCounts = new int[1] { 1 };
		recipeProto11.Results = new int[1] { 2013 };
		recipeProto11.ResultCounts = new int[1] { 10 };
		recipeProto11.GridIndex = 402 + num;
		recipeProto11.TimeSpend = 6;
		Traverse.Create(recipeProto11).Field("_iconSprite").SetValue(MoreMegaStructure.iconQuickSorter);
		RecipeProto recipeProto12 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto12.ID = 553;
		recipeProto12.Name = "配电站 快速组装";
		recipeProto12.name = "配电站 快速组装".Translate();
		recipeProto12.Description = "快速组装描述";
		recipeProto12.description = "快速组装描述".Translate();
		recipeProto12.Items = new int[1] { 9500 };
		recipeProto12.ItemCounts = new int[1] { 1 };
		recipeProto12.Results = new int[1] { 2212 };
		recipeProto12.ResultCounts = new int[1] { 5 };
		recipeProto12.GridIndex = 403 + num;
		recipeProto12.TimeSpend = 6;
		Traverse.Create(recipeProto12).Field("_iconSprite").SetValue(MoreMegaStructure.iconQuickPower);
		RecipeProto recipeProto13 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto13.ID = 554;
		recipeProto13.Name = "制造台 快速组装";
		recipeProto13.name = "制造台 快速组装".Translate();
		recipeProto13.Description = "快速组装描述";
		recipeProto13.description = "快速组装描述".Translate();
		recipeProto13.Items = new int[1] { 9500 };
		recipeProto13.ItemCounts = new int[1] { 1 };
		recipeProto13.Results = new int[1] { 2305 };
		recipeProto13.ResultCounts = new int[1] { 1 };
		recipeProto13.GridIndex = 404 + num;
		recipeProto13.TimeSpend = 6;
		Traverse.Create(recipeProto13).Field("_iconSprite").SetValue(MoreMegaStructure.iconQuickAssembly);
		RecipeProto recipeProto14 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto14.ID = 555;
		recipeProto14.Name = "位面熔炉 快速组装";
		recipeProto14.name = "位面熔炉 快速组装".Translate();
		recipeProto14.Description = "快速组装描述";
		recipeProto14.description = "快速组装描述".Translate();
		recipeProto14.Items = new int[1] { 9500 };
		recipeProto14.ItemCounts = new int[1] { 1 };
		recipeProto14.Results = new int[1] { 2315 };
		recipeProto14.ResultCounts = new int[1] { 1 };
		recipeProto14.GridIndex = 405 + num;
		recipeProto14.TimeSpend = 6;
		Traverse.Create(recipeProto14).Field("_iconSprite").SetValue(MoreMegaStructure.iconQuickSmelter);
		RecipeProto recipeProto15 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto15.ID = 556;
		recipeProto15.Name = "化工厂 快速组装";
		recipeProto15.name = "化工厂 快速组装".Translate();
		recipeProto15.Description = "快速组装描述";
		recipeProto15.description = "快速组装描述".Translate();
		recipeProto15.Items = new int[1] { 9500 };
		recipeProto15.ItemCounts = new int[1] { 2 };
		recipeProto15.Results = new int[1] { 2317 };
		recipeProto15.ResultCounts = new int[1] { 1 };
		recipeProto15.GridIndex = 406 + num;
		recipeProto15.TimeSpend = 6;
		recipeProto15.preTech = LDB.techs.Select(1305);
		Traverse.Create(recipeProto15).Field("_iconSprite").SetValue(MoreMegaStructure.iconQuickChemical);
		RecipeProto recipeProto16 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto16.ID = 557;
		recipeProto16.Name = "精炼厂 快速组装";
		recipeProto16.name = "精炼厂 快速组装".Translate();
		recipeProto16.Description = "快速组装描述";
		recipeProto16.description = "快速组装描述".Translate();
		recipeProto16.Items = new int[1] { 9500 };
		recipeProto16.ItemCounts = new int[1] { 2 };
		recipeProto16.Results = new int[2] { 2307, 2308 };
		recipeProto16.ResultCounts = new int[2] { 1, 4 };
		recipeProto16.GridIndex = 407 + num;
		recipeProto16.TimeSpend = 6;
		Traverse.Create(recipeProto16).Field("_iconSprite").SetValue(MoreMegaStructure.iconQuickRefinery);
		RecipeProto recipeProto17 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto17.ID = 558;
		recipeProto17.Name = "对撞机 快速组装";
		recipeProto17.name = "对撞机 快速组装".Translate();
		recipeProto17.Description = "快速组装描述";
		recipeProto17.description = "快速组装描述".Translate();
		recipeProto17.Items = new int[1] { 9500 };
		recipeProto17.ItemCounts = new int[1] { 2 };
		recipeProto17.Results = new int[1] { 2310 };
		recipeProto17.ResultCounts = new int[1] { 1 };
		recipeProto17.GridIndex = 408 + num;
		recipeProto17.TimeSpend = 6;
		Traverse.Create(recipeProto17).Field("_iconSprite").SetValue(MoreMegaStructure.iconQuickCollider);
		RecipeProto recipeProto18 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto18.ID = 559;
		recipeProto18.Name = "研究站 快速组装";
		recipeProto18.name = "研究站 快速组装".Translate();
		recipeProto18.Description = "快速组装描述";
		recipeProto18.description = "快速组装描述".Translate();
		recipeProto18.Items = new int[1] { 9500 };
		recipeProto18.ItemCounts = new int[1] { 1 };
		recipeProto18.Results = new int[1] { 2901 };
		recipeProto18.ResultCounts = new int[1] { 2 };
		recipeProto18.GridIndex = 409 + num;
		recipeProto18.TimeSpend = 6;
		Traverse.Create(recipeProto18).Field("_iconSprite").SetValue(MoreMegaStructure.iconQuickLab);
		RecipeProto recipeProto19 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto19.ID = 560;
		recipeProto19.Name = "人造恒星 快速组装";
		recipeProto19.name = "人造恒星 快速组装".Translate();
		recipeProto19.Description = "快速组装描述";
		recipeProto19.description = "快速组装描述".Translate();
		recipeProto19.Items = new int[1] { 9500 };
		recipeProto19.ItemCounts = new int[1] { 5 };
		recipeProto19.Results = new int[1] { 2210 };
		recipeProto19.ResultCounts = new int[1] { 1 };
		recipeProto19.GridIndex = 410 + num;
		recipeProto19.TimeSpend = 6;
		recipeProto19.preTech = LDB.techs.Select(1144);
		Traverse.Create(recipeProto19).Field("_iconSprite").SetValue(MoreMegaStructure.iconQuickReactor);
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto19.ItemCounts = new int[1] { 20 };
			recipeProto19.Results = new int[1] { 6261 };
			Traverse.Create(recipeProto19).Field("_iconSprite").SetValue(Resources.Load<Sprite>("Assets/MegaStructureTab/Rreactor2"));
		}
		RecipeProto recipeProto20 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto20.ID = 561;
		recipeProto20.Name = "行星内物流 快速组装";
		recipeProto20.name = "行星内物流 快速组装".Translate();
		recipeProto20.Description = "快速组装描述";
		recipeProto20.description = "快速组装描述".Translate();
		recipeProto20.Items = new int[1] { 9500 };
		recipeProto20.ItemCounts = new int[1] { 3 };
		recipeProto20.Results = new int[2] { 2103, 5001 };
		recipeProto20.ResultCounts = new int[2] { 1, 30 };
		recipeProto20.GridIndex = 411 + num;
		recipeProto20.TimeSpend = 6;
		recipeProto20.preTech = LDB.techs.Select(1604);
		Traverse.Create(recipeProto20).Field("_iconSprite").SetValue(MoreMegaStructure.iconQuickPLog);
		RecipeProto recipeProto21 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto21.ID = 562;
		recipeProto21.Name = "星际物流 快速组装";
		recipeProto21.name = "星际物流 快速组装".Translate();
		recipeProto21.Description = "快速组装描述";
		recipeProto21.description = "快速组装描述".Translate();
		recipeProto21.Items = new int[1] { 9500 };
		recipeProto21.ItemCounts = new int[1] { 5 };
		recipeProto21.Results = new int[2] { 2104, 5002 };
		recipeProto21.ResultCounts = new int[2] { 1, 10 };
		recipeProto21.GridIndex = 412 + num;
		recipeProto21.TimeSpend = 6;
		recipeProto21.preTech = LDB.techs.Select(1605);
		Traverse.Create(recipeProto21).Field("_iconSprite").SetValue(MoreMegaStructure.iconQuickILog);
		RecipeProto recipeProto22 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto22.ID = 352;
		recipeProto22.Name = "集装分拣器 快速组装";
		recipeProto22.name = "集装分拣器 快速组装".Translate();
		recipeProto22.Description = "快速组装描述";
		recipeProto22.description = "快速组装描述".Translate();
		recipeProto22.Items = new int[1] { 9500 };
		recipeProto22.ItemCounts = new int[1] { 1 };
		recipeProto22.Results = new int[1] { 2014 };
		recipeProto22.ResultCounts = new int[1] { 4 };
		recipeProto22.GridIndex = 501 + num;
		recipeProto22.TimeSpend = 6;
		recipeProto22.preTech = LDB.techs.Select(1607);
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto22.preTech = LDB.techs.Select(1522);
		}
		Traverse.Create(recipeProto22).Field("_iconSprite").SetValue(Resources.Load<Sprite>("Assets/MegaStructureTab/Rsorter4"));
		RecipeProto recipeProto23 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto23.ID = 353;
		recipeProto23.Name = "制造台4 快速组装";
		recipeProto23.name = "制造台4 快速组装".Translate();
		recipeProto23.Description = "快速组装描述";
		recipeProto23.description = "快速组装描述".Translate();
		recipeProto23.Items = new int[1] { 9500 };
		recipeProto23.ItemCounts = new int[1] { 2 };
		recipeProto23.Results = new int[1] { 2318 };
		recipeProto23.ResultCounts = new int[1] { 1 };
		recipeProto23.GridIndex = 502 + num;
		recipeProto23.TimeSpend = 6;
		recipeProto23.preTech = LDB.techs.Select(1902);
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto23.preTech = LDB.techs.Select(1902);
		}
		Traverse.Create(recipeProto23).Field("_iconSprite").SetValue(Resources.Load<Sprite>("Assets/MegaStructureTab/Rassembly4"));
		RecipeProto recipeProto24 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto24.ID = 354;
		recipeProto24.Name = "熔炉3 快速组装";
		recipeProto24.name = "熔炉3 快速组装".Translate();
		recipeProto24.Description = "快速组装描述";
		recipeProto24.description = "快速组装描述".Translate();
		recipeProto24.Items = new int[1] { 9500 };
		recipeProto24.ItemCounts = new int[1] { 2 };
		recipeProto24.Results = new int[1] { 2319 };
		recipeProto24.ResultCounts = new int[1] { 1 };
		recipeProto24.GridIndex = 503 + num;
		recipeProto24.TimeSpend = 6;
		recipeProto24.preTech = LDB.techs.Select(1903);
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto24.preTech = LDB.techs.Select(1903);
		}
		Traverse.Create(recipeProto24).Field("_iconSprite").SetValue(Resources.Load<Sprite>("Assets/MegaStructureTab/Rsmelter3"));
		RecipeProto recipeProto25 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto25.ID = 355;
		recipeProto25.Name = "实验室2 快速组装";
		recipeProto25.name = "实验室2 快速组装".Translate();
		recipeProto25.Description = "快速组装描述";
		recipeProto25.description = "快速组装描述".Translate();
		recipeProto25.Items = new int[1] { 9500 };
		recipeProto25.ItemCounts = new int[1] { 1 };
		recipeProto25.Results = new int[1] { 2902 };
		recipeProto25.ResultCounts = new int[1] { 1 };
		recipeProto25.GridIndex = 504 + num;
		recipeProto25.TimeSpend = 6;
		recipeProto25.preTech = LDB.techs.Select(1901);
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto25.preTech = LDB.techs.Select(1901);
		}
		Traverse.Create(recipeProto25).Field("_iconSprite").SetValue(Resources.Load<Sprite>("Assets/MegaStructureTab/Rlab2"));
		RecipeProto recipeProto26 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto26.ID = 356;
		recipeProto26.Name = "大矿机 快速组装";
		recipeProto26.name = "大矿机 快速组装".Translate();
		recipeProto26.Description = "快速组装描述";
		recipeProto26.description = "快速组装描述".Translate();
		recipeProto26.Items = new int[1] { 9500 };
		recipeProto26.ItemCounts = new int[1] { 2 };
		recipeProto26.Results = new int[1] { 2316 };
		recipeProto26.ResultCounts = new int[1] { 1 };
		recipeProto26.GridIndex = 505 + num;
		recipeProto26.TimeSpend = 6;
		recipeProto26.preTech = LDB.techs.Select(1304);
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto26.preTech = LDB.techs.Select(1304);
		}
		Traverse.Create(recipeProto26).Field("_iconSprite").SetValue(Resources.Load<Sprite>("Assets/MegaStructureTab/Rmining2"));
		RecipeProto recipeProto27 = MethedEx.Copy<RecipeProto>(recipeProto9);
		recipeProto27.ID = 357;
		recipeProto27.Name = "抽水泵 快速组装";
		recipeProto27.name = "抽水泵 快速组装".Translate();
		recipeProto27.Description = "快速组装描述";
		recipeProto27.description = "快速组装描述".Translate();
		recipeProto27.Items = new int[1] { 9500 };
		recipeProto27.ItemCounts = new int[1] { 1 };
		recipeProto27.Results = new int[1] { 2306 };
		recipeProto27.ResultCounts = new int[1] { 5 };
		recipeProto27.GridIndex = 506 + num;
		recipeProto27.TimeSpend = 6;
		recipeProto27.preTech = LDB.techs.Select(1120);
		Traverse.Create(recipeProto27).Field("_iconSprite").SetValue(Resources.Load<Sprite>("Assets/MegaStructureTab/Rpump"));
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto27.preTech = LDB.techs.Select(1304);
			recipeProto27.Results = new int[1] { 6266 };
			recipeProto27.ResultCounts = new int[1] { 1 };
			Traverse.Create(recipeProto27).Field("_iconSprite").SetValue(Resources.Load<Sprite>("Assets/MegaStructureTab/Rpump2"));
		}
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto12.GridIndex = 9999;
			recipeProto14.GridIndex = 9999;
			recipeProto13.GridIndex = 9999;
			recipeProto15.GridIndex = 9999;
			recipeProto16.GridIndex = 9999;
			recipeProto17.GridIndex = 9999;
		}
		if (MoreMegaStructure.StarCannonOnly.Value)
		{
			recipeProto4.GridIndex = 9999;
			recipeProto5.GridIndex = 9999;
			recipeProto6.GridIndex = 9999;
			recipeProto7.GridIndex = 9999;
			recipeProto8.GridIndex = 9999;
		}
		LDB.items.Select(2003).recipes.Add(recipeProto10);
		LDB.items.Select(2013).recipes.Add(recipeProto11);
		LDB.items.Select(2305).recipes.Add(recipeProto13);
		LDB.items.Select(2315).recipes.Add(recipeProto14);
		LDB.items.Select(2317).recipes.Add(recipeProto15);
		LDB.items.Select(2212).recipes.Add(recipeProto12);
		LDB.items.Select(2308).recipes.Add(recipeProto16);
		LDB.items.Select(2307).recipes.Add(recipeProto16);
		LDB.items.Select(2310).recipes.Add(recipeProto17);
		LDB.items.Select(2901).recipes.Add(recipeProto18);
		LDB.items.Select(2210).recipes.Add(recipeProto19);
		LDB.items.Select(2103).recipes.Add(recipeProto20);
		LDB.items.Select(5001).recipes.Add(recipeProto20);
		LDB.items.Select(2104).recipes.Add(recipeProto21);
		LDB.items.Select(5002).recipes.Add(recipeProto21);
		LDB.items.Select(2014).recipes.Add(recipeProto22);
		LDB.items.Select(2318).recipes.Add(recipeProto23);
		LDB.items.Select(2319).recipes.Add(recipeProto24);
		LDB.items.Select(2902).recipes.Add(recipeProto25);
		LDB.items.Select(2316).recipes.Add(recipeProto26);
		LDB.items.Select(2306).recipes.Add(recipeProto27);
		LDBTool.PostAddProto((Proto)recipeProto13);
		LDBTool.PostAddProto((Proto)recipeProto10);
		LDBTool.PostAddProto((Proto)recipeProto15);
		LDBTool.PostAddProto((Proto)recipeProto17);
		LDBTool.PostAddProto((Proto)recipeProto21);
		LDBTool.PostAddProto((Proto)recipeProto18);
		LDBTool.PostAddProto((Proto)recipeProto20);
		LDBTool.PostAddProto((Proto)recipeProto12);
		LDBTool.PostAddProto((Proto)recipeProto19);
		LDBTool.PostAddProto((Proto)recipeProto16);
		LDBTool.PostAddProto((Proto)recipeProto14);
		LDBTool.PostAddProto((Proto)recipeProto11);
		LDBTool.PostAddProto((Proto)recipeProto22);
		LDBTool.PostAddProto((Proto)recipeProto23);
		LDBTool.PostAddProto((Proto)recipeProto24);
		LDBTool.PostAddProto((Proto)recipeProto25);
		LDBTool.PostAddProto((Proto)recipeProto26);
		LDBTool.PostAddProto((Proto)recipeProto27);
		bool flag2 = true;
	}

	public static void AddNewItems2()
	{
		int num = MoreMegaStructure.pagenum * 1000;
		int num2 = 0;
		int num3 = 0;
		if (MoreMegaStructure.GenesisCompatibility)
		{
			num2 = -200;
			num3 = -8;
		}
		ProtoRegistry.RegisterItem(9503, "力场发生器", "力场发生器描述", "Assets/MegaStructureTab/forceGen", 201 + num, 20, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0.2f, 0.7f, 0.7f)));
		ProtoRegistry.RegisterItem(9504, "复合态晶体", "复合态晶体描述", "Assets/MegaStructureTab/compoCrystal", 202 + num, 100, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0.2f, 0.7f, 0.7f)));
		ProtoRegistry.RegisterItem(9505, "电磁力抑制器", "电磁力抑制器描述", "Assets/MegaStructureTab/elemaginhibitor2", 203 + num, 50, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0.2f, 0.7f, 0.7f)));
		ProtoRegistry.RegisterItem(9506, "胶子发生器", "胶子发生器描述", "Assets/MegaStructureTab/gluonGen", 204 + num, 50, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0.2f, 0.7f, 0.7f)));
		ProtoRegistry.RegisterItem(9507, "强力过载装置", "强力过载装置描述", "Assets/MegaStructureTab/strIntOverloader", 205 + num, 20, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0.2f, 0.7f, 0.7f)));
		ProtoRegistry.RegisterItem(9508, "导流框架", "导流框架描述", "Assets/MegaStructureTab/starcannonframe", 206 + num, 20, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0.2f, 0.7f, 0.7f)));
		ProtoRegistry.RegisterItem(9509, "恒星炮组件", "恒星炮组件描述", "Assets/MegaStructureTab/starcannoncompo", 207 + num, 20, EItemType.Component, ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0.3f, 0.3f, 0.9f)));
		ProtoRegistry.RegisterItem(9510, "恒星炮运载火箭", "恒星炮运载火箭描述", "Assets/MegaStructureTab/rocketStarcannon", 306 + num, 20, EItemType.Product, ProtoRegistry.GetDefaultIconDesc(Color.white, new Color(0.3f, 0.9f, 0.9f)));
		ItemProto itemProto = ProtoRegistry.RegisterItem(9511, "水滴gm", "水滴描述gm", "Assets/MegaStructureTab/drop1", 707 + num, 10, EItemType.Product, ProtoRegistry.GetDefaultIconDesc(Color.white, Color.white));
		ProtoRegistry.RegisterRecipe(565 + num2, ERecipeType.Assemble, 240, new int[2] { 9480, 9484 }, new int[2] { 1, 2 }, new int[1] { 9503 }, new int[1] { 1 }, "力场发生器描述", StarCannonTechId, 201 + num, "Assets/MegaStructureTab/forceGen");
		RecipeProto recipeProto = ProtoRegistry.RegisterRecipe(566 + num2, ERecipeType.Particle, 600, new int[5] { 5203, 1126, 1124, 1118, 1120 }, new int[5] { 1, 1, 1, 1, 1 }, new int[1] { 9504 }, new int[1] { 1 }, "复合态晶体描述", 1919, 202 + num, "Assets/MegaStructureTab/compoCrystal");
		ProtoRegistry.RegisterRecipe(567 + num2, ERecipeType.Assemble, 360, new int[2] { 1305, 1205 }, new int[2] { 1, 2 }, new int[1] { 9505 }, new int[1] { 1 }, "电磁力抑制器描述", 1919, 203 + num, "Assets/MegaStructureTab/elemaginhibitor2");
		RecipeProto recipeProto2 = ProtoRegistry.RegisterRecipe(568 + num2, ERecipeType.Assemble, 360, new int[3] { 9483, 1402, 1122 }, new int[3] { 1, 1, 2 }, new int[1] { 9506 }, new int[1] { 1 }, "胶子发生器描述", 1919, 204 + num, "Assets/MegaStructureTab/gluonGen");
		RecipeProto recipeProto3 = ProtoRegistry.RegisterRecipe(569 + num2, ERecipeType.Assemble, 1200, new int[2] { 9506, 9486 }, new int[2] { 2, 2 }, new int[1] { 9507 }, new int[1] { 1 }, "强力过载装置描述", 1919, 205 + num, "Assets/MegaStructureTab/strIntOverloader");
		ProtoRegistry.RegisterRecipe(570 + num2, ERecipeType.Assemble, 180, new int[3] { 1125, 9481, 9503 }, new int[3] { 3, 2, 3 }, new int[1] { 9508 }, new int[1] { 1 }, "导流框架描述", StarCannonTechId, 206 + num, "Assets/MegaStructureTab/starcannonframe");
		ProtoRegistry.RegisterRecipe(571 + num2, ERecipeType.Assemble, 480, new int[2] { 1209, 9508 }, new int[2] { 3, 2 }, new int[1] { 9509 }, new int[1] { 1 }, "恒星炮组件描述", StarCannonTechId, 207 + num, "Assets/MegaStructureTab/starcannoncompo");
		ProtoRegistry.RegisterRecipe(572 + num2, ERecipeType.Assemble, 360, new int[3] { 9509, 1802, 1305 }, new int[3] { 2, 2, 2 }, new int[1] { 9510 }, new int[1] { 1 }, "恒星炮运载火箭描述", StarCannonTechId, 306 + num, "Assets/MegaStructureTab/rocketStarcannon");
		RecipeProto recipeProto4 = ProtoRegistry.RegisterRecipe(573 + num2, ERecipeType.Assemble, 3600, new int[3] { 9505, 9507, 9504 }, new int[3] { 20, 20, 100 }, new int[1] { 9511 }, new int[1] { 1 }, "水滴描述gm", 1919, 707 + num, "Assets/MegaStructureTab/drop1");
		TechProto techProto = ProtoRegistry.RegisterTech(StarCannonTechId, "尼科尔戴森光束", "尼科尔戴森光束描述", "尼科尔戴森光束结论", "Assets/MegaStructureTab/starcannontech", new int[0], new int[1] { 5201 }, new int[1] { 200 }, 36000L, new int[4]
		{
			570 + num2,
			571 + num2,
			572 + num2,
			565 + num2
		}, new Vector2(65 + num3, -3f));
		techProto.PreTechsImplicit = new int[1] { 1522 };
		techProto.IsHiddenTech = true;
		techProto.PreItem = new int[1] { 5201 };
		recipeProto.Handcraft = false;
		recipeProto2.Handcraft = false;
		recipeProto3.Handcraft = false;
		recipeProto4.Handcraft = false;
	}

	public static void EditOriRR(Proto proto)
	{
	}

	public static void AddGenesisRecipes()
	{
		if (MoreMegaStructure.GenesisCompatibility)
		{
			int num = MoreMegaStructure.pagenum * 1000 + 100;
			RecipeProto recipeProto = ProtoRegistry.RegisterRecipe(376, (ERecipeType)10, 6, new int[1] { 9500 }, new int[1] { 25 }, new int[1] { 6257 }, new int[1] { 1 }, "巨建快速组装描述", 1923, 403 + num, "Assets/MegaStructureTab/quick6257");
			RecipeProto recipeProto2 = ProtoRegistry.RegisterRecipe(377, (ERecipeType)10, 6, new int[1] { 9500 }, new int[1] { 25 }, new int[1] { 6258 }, new int[1] { 1 }, "巨建快速组装描述", 1924, 404 + num, "Assets/MegaStructureTab/quick6258");
			RecipeProto recipeProto3 = ProtoRegistry.RegisterRecipe(378, (ERecipeType)10, 6, new int[1] { 9500 }, new int[1] { 25 }, new int[1] { 6259 }, new int[1] { 1 }, "巨建快速组装描述", 1925, 405 + num, "Assets/MegaStructureTab/quick6259");
			RecipeProto recipeProto4 = ProtoRegistry.RegisterRecipe(379, (ERecipeType)10, 6, new int[1] { 9500 }, new int[1] { 25 }, new int[1] { 6260 }, new int[1] { 1 }, "巨建快速组装描述", 1926, 406 + num, "Assets/MegaStructureTab/quick6260");
			RecipeProto recipeProto5 = ProtoRegistry.RegisterRecipe(380, (ERecipeType)10, 6, new int[1] { 9500 }, new int[1] { 25 }, new int[1] { 6264 }, new int[1] { 1 }, "巨建快速组装描述", 1931, 407 + num, "Assets/MegaStructureTab/quick6264");
			RecipeProto recipeProto6 = ProtoRegistry.RegisterRecipe(381, (ERecipeType)10, 6, new int[1] { 9500 }, new int[1] { 25 }, new int[1] { 6265 }, new int[1] { 1 }, "巨建快速组装描述", 1927, 408 + num, "Assets/MegaStructureTab/quick6265");
			recipeProto._iconSprite = Resources.Load<Sprite>("Assets/MegaStructureTab/quick6257");
			recipeProto2._iconSprite = Resources.Load<Sprite>("Assets/MegaStructureTab/quick6258");
			recipeProto3._iconSprite = Resources.Load<Sprite>("Assets/MegaStructureTab/quick6259");
			recipeProto4._iconSprite = Resources.Load<Sprite>("Assets/MegaStructureTab/quick6260");
			recipeProto5._iconSprite = Resources.Load<Sprite>("Assets/MegaStructureTab/quick6264");
			recipeProto6._iconSprite = Resources.Load<Sprite>("Assets/MegaStructureTab/quick6265");
			LDBTool.PostAddProto((Proto)recipeProto);
			LDBTool.PostAddProto((Proto)recipeProto2);
			LDBTool.PostAddProto((Proto)recipeProto3);
			LDBTool.PostAddProto((Proto)recipeProto4);
			LDBTool.PostAddProto((Proto)recipeProto5);
			LDBTool.PostAddProto((Proto)recipeProto6);
		}
	}

	public static void AddReceivers()
	{
		int num = MoreMegaStructure.pagenum * 1000;
		bool flag = true;
		num = MoreMegaStructure.battlePagenum * 1000 + 100;
		int num2 = 0;
		if (MoreMegaStructure.GenesisCompatibility)
		{
			num2 = -200;
		}
		RecipeProto recipeProto = LDB.recipes.Select(41);
		ItemProto itemProto = LDB.items.Select(2208);
		ItemProto itemProto2 = LDB.items.Select(2104);
		RecipeProto recipeProto2 = MethedEx.Copy<RecipeProto>(recipeProto);
		ItemProto itemProto3 = MethedEx.Copy<ItemProto>(itemProto);
		recipeProto2.ID = num2 + 543;
		recipeProto2.Name = "星际组装厂生产机器图标专用";
		recipeProto2.name = "星际组装厂生产机器图标专用".Translate();
		recipeProto2.Description = "";
		recipeProto2.description = "";
		recipeProto2.Items = new int[4] { 1103, 1404, 1303, 9481 };
		recipeProto2.ItemCounts = new int[4] { 20, 10, 5, 2 };
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto2.Items = new int[4] { 1103, 1014, 1303, 9481 };
			recipeProto2.ItemCounts = new int[4] { 20, 20, 5, 2 };
		}
		recipeProto2.Results = new int[1] { 9493 };
		recipeProto2.ResultCounts = new int[1] { 1 };
		recipeProto2.GridIndex = 9901 + num;
		recipeProto2.TimeSpend = 480;
		Traverse.Create(recipeProto2).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverIron);
		recipeProto2.preTech = null;
		if (MoreMegaStructure.isBattleActive)
		{
			recipeProto2.preTech = LDB.techs.Select(1920);
		}
		itemProto3.ID = 9493;
		itemProto3.Name = "星际组装厂生产机器图标专用";
		itemProto3.name = "星际组装厂生产机器图标专用".Translate();
		itemProto3.Description = "";
		itemProto3.description = "".Translate();
		itemProto3.GridIndex = 9901 + num;
		itemProto3.HeatValue = 0L;
		itemProto3.prefabDesc = MethedEx.Copy<PrefabDesc>(itemProto.prefabDesc);
		itemProto3.prefabDesc.powerProductHeat = 6000000L;
		itemProto3.prefabDesc.powerProductId = 1101;
		itemProto3.handcraft = recipeProto2;
		itemProto3.handcrafts = new List<RecipeProto> { recipeProto2 };
		itemProto3.maincraft = recipeProto2;
		itemProto3.recipes = new List<RecipeProto> { recipeProto2 };
		itemProto3.Grade = 2;
		itemProto3.Upgrades = new int[9] { 2208, 9493, 9494, 9495, 9496, 9497, 9501, 9498, 9502 };
		itemProto3._iconSprite = Resources.Load<Sprite>("ui/textures/sprites/starmap/planets-icon");
		RecipeProto recipeProto3 = MethedEx.Copy<RecipeProto>(recipeProto);
		ItemProto itemProto4 = MethedEx.Copy<ItemProto>(itemProto);
		recipeProto3.ID = num2 + 544;
		recipeProto3.Name = "铜金属重构装置";
		recipeProto3.name = "铜金属重构装置".Translate();
		recipeProto3.Description = "接收重构装置描述";
		recipeProto3.description = "接收重构装置描述".Translate();
		recipeProto3.Items = new int[4] { 1103, 1404, 1303, 9481 };
		recipeProto3.ItemCounts = new int[4] { 20, 10, 5, 2 };
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto3.Items = new int[4] { 1103, 1014, 1303, 9481 };
			recipeProto3.ItemCounts = new int[4] { 20, 20, 5, 2 };
		}
		recipeProto3.Results = new int[1] { 9494 };
		recipeProto3.ResultCounts = new int[1] { 1 };
		recipeProto3.GridIndex = 9902 + num;
		recipeProto3.TimeSpend = 480;
		Traverse.Create(recipeProto3).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverCopper);
		recipeProto3.preTech = null;
		if (MoreMegaStructure.isBattleActive)
		{
			recipeProto3.preTech = LDB.techs.Select(1920);
		}
		itemProto4.ID = 9494;
		itemProto4.Name = "铜金属重构装置";
		itemProto4.name = "铜金属重构装置".Translate();
		itemProto4.Description = "接收重构装置描述";
		itemProto4.description = "接收重构装置描述".Translate();
		itemProto4.GridIndex = 9902 + num;
		itemProto4.HeatValue = 0L;
		itemProto4.prefabDesc = MethedEx.Copy<PrefabDesc>(itemProto.prefabDesc);
		itemProto4.prefabDesc.powerProductHeat = 6000000L;
		itemProto4.prefabDesc.powerProductId = 1104;
		itemProto4.handcraft = recipeProto3;
		itemProto4.handcrafts = new List<RecipeProto> { recipeProto3 };
		itemProto4.maincraft = recipeProto3;
		itemProto4.recipes = new List<RecipeProto> { recipeProto3 };
		itemProto4.Grade = 3;
		itemProto4.Upgrades = new int[9] { 2208, 9493, 9494, 9495, 9496, 9497, 9501, 9498, 9502 };
		Traverse.Create(itemProto4).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverCopper);
		RecipeProto recipeProto4 = MethedEx.Copy<RecipeProto>(recipeProto);
		ItemProto itemProto5 = MethedEx.Copy<ItemProto>(itemProto);
		recipeProto4.ID = num2 + 545;
		recipeProto4.Name = "高纯硅重构装置";
		recipeProto4.name = "高纯硅重构装置".Translate();
		recipeProto4.Description = "接收重构装置描述";
		recipeProto4.description = "接收重构装置描述".Translate();
		recipeProto4.Items = new int[4] { 1103, 1404, 1303, 9481 };
		recipeProto4.ItemCounts = new int[4] { 20, 10, 5, 2 };
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto4.Items = new int[4] { 1103, 1014, 1303, 9481 };
			recipeProto4.ItemCounts = new int[4] { 20, 20, 5, 2 };
		}
		recipeProto4.Results = new int[1] { 9495 };
		recipeProto4.ResultCounts = new int[1] { 1 };
		recipeProto4.GridIndex = 9903 + num;
		recipeProto4.TimeSpend = 480;
		Traverse.Create(recipeProto4).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverSilicon);
		recipeProto4.preTech = null;
		if (MoreMegaStructure.isBattleActive)
		{
			recipeProto4.preTech = LDB.techs.Select(1920);
		}
		itemProto5.ID = 9495;
		itemProto5.Name = "高纯硅重构装置";
		itemProto5.name = "高纯硅重构装置".Translate();
		itemProto5.Description = "接收重构装置描述";
		itemProto5.description = "接收重构装置描述".Translate();
		itemProto5.GridIndex = 9903 + num;
		itemProto5.HeatValue = 0L;
		itemProto5.prefabDesc = MethedEx.Copy<PrefabDesc>(itemProto.prefabDesc);
		itemProto5.prefabDesc.powerProductHeat = 6000000L;
		itemProto5.prefabDesc.powerProductId = 1105;
		itemProto5.handcraft = recipeProto4;
		itemProto5.handcrafts = new List<RecipeProto> { recipeProto4 };
		itemProto5.maincraft = recipeProto4;
		itemProto5.recipes = new List<RecipeProto> { recipeProto4 };
		itemProto5.Grade = 4;
		itemProto5.Upgrades = new int[9] { 2208, 9493, 9494, 9495, 9496, 9497, 9501, 9498, 9502 };
		Traverse.Create(itemProto5).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverSilicon);
		RecipeProto recipeProto5 = MethedEx.Copy<RecipeProto>(recipeProto);
		ItemProto itemProto6 = MethedEx.Copy<ItemProto>(itemProto);
		recipeProto5.ID = num2 + 546;
		recipeProto5.Name = "钛金属重构装置";
		recipeProto5.name = "钛金属重构装置".Translate();
		recipeProto5.Description = "接收重构装置描述";
		recipeProto5.description = "接收重构装置描述".Translate();
		recipeProto5.Items = new int[4] { 1103, 1404, 1303, 9481 };
		recipeProto5.ItemCounts = new int[4] { 20, 10, 5, 2 };
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto5.Items = new int[4] { 1103, 1014, 1303, 9481 };
			recipeProto5.ItemCounts = new int[4] { 20, 20, 5, 2 };
		}
		recipeProto5.Results = new int[1] { 9496 };
		recipeProto5.ResultCounts = new int[1] { 1 };
		recipeProto5.GridIndex = 9904 + num;
		recipeProto5.TimeSpend = 480;
		Traverse.Create(recipeProto5).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverTitanium);
		recipeProto5.preTech = null;
		if (MoreMegaStructure.isBattleActive)
		{
			recipeProto5.preTech = LDB.techs.Select(1920);
		}
		itemProto6.ID = 9496;
		itemProto6.Name = "钛金属重构装置";
		itemProto6.name = "钛金属重构装置".Translate();
		itemProto6.Description = "接收重构装置描述";
		itemProto6.description = "接收重构装置描述".Translate();
		itemProto6.GridIndex = 9904 + num;
		itemProto6.HeatValue = 0L;
		itemProto6.prefabDesc = MethedEx.Copy<PrefabDesc>(itemProto.prefabDesc);
		itemProto6.prefabDesc.powerProductHeat = 6000000L;
		itemProto6.prefabDesc.powerProductId = 1106;
		itemProto6.handcraft = recipeProto5;
		itemProto6.handcrafts = new List<RecipeProto> { recipeProto5 };
		itemProto6.maincraft = recipeProto5;
		itemProto6.recipes = new List<RecipeProto> { recipeProto5 };
		itemProto6.Grade = 5;
		itemProto6.Upgrades = new int[9] { 2208, 9493, 9494, 9495, 9496, 9497, 9501, 9498, 9502 };
		Traverse.Create(itemProto6).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverTitanium);
		RecipeProto recipeProto6 = MethedEx.Copy<RecipeProto>(recipeProto);
		ItemProto itemProto7 = MethedEx.Copy<ItemProto>(itemProto);
		recipeProto6.ID = num2 + 547;
		recipeProto6.Name = "单极磁石重构装置";
		recipeProto6.name = "单极磁石重构装置".Translate();
		recipeProto6.Description = "接收重构装置描述";
		recipeProto6.description = "接收重构装置描述".Translate();
		recipeProto6.Items = new int[4] { 1103, 1404, 1303, 9481 };
		recipeProto6.ItemCounts = new int[4] { 20, 10, 5, 2 };
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto6.Items = new int[4] { 1103, 1014, 1303, 9481 };
			recipeProto6.ItemCounts = new int[4] { 20, 20, 5, 2 };
		}
		recipeProto6.Results = new int[1] { 9497 };
		recipeProto6.ResultCounts = new int[1] { 1 };
		recipeProto6.GridIndex = 9905 + num;
		recipeProto6.TimeSpend = 480;
		Traverse.Create(recipeProto6).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverMagore);
		recipeProto6.preTech = null;
		if (MoreMegaStructure.isBattleActive)
		{
			recipeProto6.preTech = LDB.techs.Select(1920);
		}
		itemProto7.ID = 9497;
		itemProto7.Name = "单极磁石重构装置";
		itemProto7.name = "单极磁石重构装置".Translate();
		itemProto7.Description = "接收重构装置描述";
		itemProto7.description = "接收重构装置描述".Translate();
		itemProto7.GridIndex = 9905 + num;
		itemProto7.HeatValue = 0L;
		itemProto7.prefabDesc = MethedEx.Copy<PrefabDesc>(itemProto.prefabDesc);
		itemProto7.prefabDesc.powerProductHeat = 6000000L;
		itemProto7.prefabDesc.powerProductId = 1016;
		itemProto7.handcraft = recipeProto6;
		itemProto7.handcrafts = new List<RecipeProto> { recipeProto6 };
		itemProto7.maincraft = recipeProto6;
		itemProto7.recipes = new List<RecipeProto> { recipeProto6 };
		itemProto7.Grade = 6;
		itemProto7.Upgrades = new int[9] { 2208, 9493, 9494, 9495, 9496, 9497, 9501, 9498, 9502 };
		Traverse.Create(itemProto7).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverMagore);
		RecipeProto recipeProto7 = MethedEx.Copy<RecipeProto>(recipeProto);
		ItemProto itemProto8 = MethedEx.Copy<ItemProto>(itemProto);
		recipeProto7.ID = num2 + 563;
		recipeProto7.Name = "石墨提炼装置";
		recipeProto7.name = "石墨提炼装置".Translate();
		recipeProto7.Description = "接收重构装置描述";
		recipeProto7.description = "接收重构装置描述".Translate();
		recipeProto7.Items = new int[4] { 1103, 1404, 1303, 9481 };
		recipeProto7.ItemCounts = new int[4] { 20, 10, 5, 2 };
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto7.Items = new int[4] { 1103, 1014, 1303, 9481 };
			recipeProto7.ItemCounts = new int[4] { 20, 20, 5, 2 };
		}
		recipeProto7.Results = new int[1] { 9501 };
		recipeProto7.ResultCounts = new int[1] { 1 };
		recipeProto7.GridIndex = 9906 + num;
		recipeProto7.TimeSpend = 480;
		Traverse.Create(recipeProto7).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverCoal);
		recipeProto7.preTech = null;
		if (MoreMegaStructure.isBattleActive)
		{
			recipeProto7.preTech = LDB.techs.Select(1920);
		}
		itemProto8.ID = 9501;
		itemProto8.Name = "石墨提炼装置";
		itemProto8.name = "石墨提炼装置".Translate();
		itemProto8.Description = "接收重构装置描述";
		itemProto8.description = "接收重构装置描述".Translate();
		itemProto8.GridIndex = 9906 + num;
		itemProto8.HeatValue = 0L;
		itemProto8.prefabDesc = MethedEx.Copy<PrefabDesc>(itemProto.prefabDesc);
		itemProto8.prefabDesc.powerProductHeat = 12000000L;
		itemProto8.prefabDesc.powerProductId = 1109;
		itemProto8.handcraft = recipeProto7;
		itemProto8.handcrafts = new List<RecipeProto> { recipeProto7 };
		itemProto8.maincraft = recipeProto7;
		itemProto8.recipes = new List<RecipeProto> { recipeProto7 };
		itemProto8.Grade = 7;
		itemProto8.Upgrades = new int[9] { 2208, 9493, 9494, 9495, 9496, 9497, 9501, 9498, 9502 };
		Traverse.Create(itemProto8).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverCoal);
		RecipeProto recipeProto8 = MethedEx.Copy<RecipeProto>(recipeProto);
		ItemProto itemProto9 = MethedEx.Copy<ItemProto>(itemProto);
		recipeProto8.ID = num2 + 548;
		recipeProto8.Name = "晶体接收器";
		recipeProto8.name = "晶体接收器".Translate();
		recipeProto8.Description = "晶体接收器描述";
		recipeProto8.description = "晶体接收器描述".Translate();
		recipeProto8.Items = new int[4] { 1107, 1404, 1303, 1206 };
		recipeProto8.ItemCounts = new int[4] { 10, 10, 5, 5 };
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto8.Items = new int[3] { 1107, 1014, 1303 };
			recipeProto8.ItemCounts = new int[3] { 10, 20, 10 };
		}
		recipeProto8.Results = new int[1] { 9498 };
		recipeProto8.ResultCounts = new int[1] { 1 };
		recipeProto8.GridIndex = 9907 + num;
		recipeProto8.TimeSpend = 480;
		Traverse.Create(recipeProto8).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverCasimir);
		recipeProto8.preTech = null;
		if (MoreMegaStructure.isBattleActive)
		{
			recipeProto8.preTech = LDB.techs.Select(1923);
		}
		itemProto9.ID = 9498;
		itemProto9.Name = "晶体接收器";
		itemProto9.name = "晶体接收器".Translate();
		itemProto9.Description = "晶体接收器描述";
		itemProto9.description = "晶体接收器描述".Translate();
		itemProto9.GridIndex = 9907 + num;
		itemProto9.HeatValue = 0L;
		itemProto9.prefabDesc = MethedEx.Copy<PrefabDesc>(itemProto.prefabDesc);
		itemProto9.prefabDesc.powerProductHeat = 120000000L;
		itemProto9.prefabDesc.powerProductId = 1126;
		itemProto9.handcraft = recipeProto8;
		itemProto9.handcrafts = new List<RecipeProto> { recipeProto8 };
		itemProto9.maincraft = recipeProto8;
		itemProto9.recipes = new List<RecipeProto> { recipeProto8 };
		itemProto9.Grade = 8;
		itemProto9.Upgrades = new int[9] { 2208, 9493, 9494, 9495, 9496, 9497, 9501, 9498, 9502 };
		Traverse.Create(itemProto9).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverCasimir);
		RecipeProto recipeProto9 = MethedEx.Copy<RecipeProto>(recipeProto);
		ItemProto itemProto10 = MethedEx.Copy<ItemProto>(itemProto);
		recipeProto9.ID = num2 + 564;
		recipeProto9.Name = "光栅晶体接收器";
		recipeProto9.name = "光栅晶体接收器".Translate();
		recipeProto9.Description = "晶体接收器描述";
		recipeProto9.description = "晶体接收器描述".Translate();
		recipeProto9.Items = new int[4] { 1107, 1404, 1303, 1206 };
		recipeProto9.ItemCounts = new int[4] { 10, 10, 5, 5 };
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto9.Items = new int[3] { 1107, 1014, 1303 };
			recipeProto9.ItemCounts = new int[3] { 10, 20, 10 };
		}
		recipeProto9.Results = new int[1] { 9502 };
		recipeProto9.ResultCounts = new int[1] { 1 };
		recipeProto9.GridIndex = 9908 + num;
		recipeProto9.TimeSpend = 480;
		Traverse.Create(recipeProto9).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverGrating);
		recipeProto9.preTech = null;
		if (MoreMegaStructure.isBattleActive)
		{
			recipeProto9.preTech = LDB.techs.Select(1923);
		}
		itemProto10.ID = 9502;
		itemProto10.Name = "光栅晶体接收器";
		itemProto10.name = "光栅晶体接收器".Translate();
		itemProto10.Description = "晶体接收器描述";
		itemProto10.description = "晶体接收器描述".Translate();
		itemProto10.GridIndex = 9908 + num;
		itemProto10.HeatValue = 0L;
		itemProto10.prefabDesc = MethedEx.Copy<PrefabDesc>(itemProto.prefabDesc);
		itemProto10.prefabDesc.powerProductHeat = 12000000L;
		itemProto10.prefabDesc.powerProductId = 1014;
		itemProto10.handcraft = recipeProto9;
		itemProto10.handcrafts = new List<RecipeProto> { recipeProto9 };
		itemProto10.maincraft = recipeProto9;
		itemProto10.recipes = new List<RecipeProto> { recipeProto9 };
		itemProto10.Grade = 9;
		itemProto10.Upgrades = new int[9] { 2208, 9493, 9494, 9495, 9496, 9497, 9501, 9498, 9502 };
		Traverse.Create(itemProto10).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverGrating);
		RecipeProto recipeProto10 = MethedEx.Copy<RecipeProto>(recipeProto);
		ItemProto itemProto11 = MethedEx.Copy<ItemProto>(itemProto);
		recipeProto10.ID = num2 + 549;
		recipeProto10.Name = "组件集成装置";
		recipeProto10.name = "组件集成装置".Translate();
		recipeProto10.Description = "组件集成装置描述";
		recipeProto10.description = "组件集成装置描述".Translate();
		recipeProto10.Items = new int[4] { 1125, 1404, 1303, 1206 };
		recipeProto10.ItemCounts = new int[4] { 10, 10, 5, 5 };
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto10.Items = new int[3] { 1125, 1014, 1303 };
			recipeProto10.ItemCounts = new int[3] { 10, 20, 10 };
		}
		recipeProto10.Results = new int[1] { 9499 };
		recipeProto10.ResultCounts = new int[1] { 1 };
		recipeProto10.GridIndex = 9902 + num;
		recipeProto10.TimeSpend = 480;
		Traverse.Create(recipeProto10).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverIC);
		recipeProto10.preTech = null;
		if (MoreMegaStructure.isBattleActive)
		{
			recipeProto10.preTech = LDB.techs.Select(1922);
		}
		if (MoreMegaStructure.GenesisCompatibility)
		{
			recipeProto10.preTech = LDB.techs.Select(1504);
		}
		itemProto11.ID = 9499;
		itemProto11.Name = "组件集成装置";
		itemProto11.name = "组件集成装置".Translate();
		itemProto11.Description = "组件集成装置描述";
		itemProto11.description = "组件集成装置描述".Translate();
		itemProto11.GridIndex = 9902 + num;
		itemProto11.HeatValue = 0L;
		itemProto11.prefabDesc = MethedEx.Copy<PrefabDesc>(itemProto.prefabDesc);
		itemProto11.prefabDesc.powerProductHeat = MoreMegaStructure.multifunctionComponentHeat;
		itemProto11.prefabDesc.powerProductId = 9500;
		itemProto11.handcraft = recipeProto10;
		itemProto11.handcrafts = new List<RecipeProto> { recipeProto10 };
		itemProto11.maincraft = recipeProto10;
		itemProto11.recipes = new List<RecipeProto> { recipeProto10 };
		Traverse.Create(itemProto11).Field("_iconSprite").SetValue(MoreMegaStructure.iconReceiverIC);
		ItemProto itemProto12 = MethedEx.Copy<ItemProto>(itemProto2);
		itemProto12.ID = 9512;
		itemProto12.Name = "物资交换器";
		itemProto12.name = "物资交换器".Translate();
		itemProto12.Description = "物资交换器描述";
		itemProto12.description = "物资交换器描述".Translate();
		itemProto12.GridIndex = 309 + num;
		itemProto12.HeatValue = 0L;
		itemProto12.prefabDesc = MethedEx.Copy<PrefabDesc>(itemProto2.prefabDesc);
		itemProto12.BuildIndex = 609;
		LDBTool.PreAddProto((Proto)itemProto12);
		Traverse.Create(itemProto12).Field("_iconSprite").SetValue(Resources.Load<Sprite>("Assets/MegaStructureTab/exchangeLS"));
		RecipeProto recipeProto11 = (itemProto12.handcraft = ((!MoreMegaStructure.isBattleActive) ? ProtoRegistry.RegisterRecipe(575 + num2, ERecipeType.Assemble, 480, new int[2] { 2104, 2208 }, new int[2] { 1, 1 }, new int[1] { 9512 }, new int[1] { 1 }, "物资交换器描述", 1504, 309 + num, "物资交换器", "Assets/MegaStructureTab/exchangeLS") : ProtoRegistry.RegisterRecipe(575 + num2, ERecipeType.Assemble, 480, new int[2] { 2104, 2208 }, new int[2] { 1, 1 }, new int[1] { 9512 }, new int[1] { 1 }, "物资交换器描述", 1922, 309 + num, "物资交换器", "Assets/MegaStructureTab/exchangeLS")));
		itemProto12.handcrafts = new List<RecipeProto> { recipeProto11 };
		itemProto12.maincraft = recipeProto11;
		itemProto12.recipes = new List<RecipeProto> { recipeProto11 };
		LDBTool.SetBuildBar(6, 9, 9512);
		LDBTool.PostAddProto((Proto)itemProto3);
		LDBTool.PostAddProto((Proto)recipeProto2);
		LDBTool.PostAddProto((Proto)itemProto4);
		LDBTool.PostAddProto((Proto)recipeProto3);
		LDBTool.PostAddProto((Proto)itemProto5);
		LDBTool.PostAddProto((Proto)recipeProto4);
		LDBTool.PostAddProto((Proto)itemProto6);
		LDBTool.PostAddProto((Proto)recipeProto5);
		LDBTool.PostAddProto((Proto)itemProto7);
		LDBTool.PostAddProto((Proto)recipeProto6);
		LDBTool.PostAddProto((Proto)itemProto9);
		LDBTool.PostAddProto((Proto)recipeProto8);
		LDBTool.PostAddProto((Proto)itemProto11);
		LDBTool.PostAddProto((Proto)recipeProto10);
		LDBTool.PostAddProto((Proto)itemProto8);
		LDBTool.PostAddProto((Proto)recipeProto7);
		LDBTool.PostAddProto((Proto)itemProto10);
		LDBTool.PostAddProto((Proto)recipeProto9);
	}

	public static void AddTranslateUILabel()
	{
		StringProto stringProto = new StringProto();
		stringProto.Name = "巨构建筑";
		stringProto.ZHCN = "巨构建筑";
		stringProto.ENUS = "Megastructure";
		stringProto.RegisterTranslation();
		StringProto stringProto2 = new StringProto();
		stringProto2.Name = "规划巨构建筑类型";
		stringProto2.ZHCN = "规划巨构建筑类型";
		stringProto2.ENUS = "Plan Megastructure";
		stringProto2.RegisterTranslation();
		StringProto stringProto3 = new StringProto();
		stringProto3.Name = "自由组件";
		stringProto3.ZHCN = "自由组件";
		stringProto3.ENUS = "Floating components ";
		stringProto3.RegisterTranslation();
		StringProto stringProto4 = new StringProto();
		stringProto4.Name = "工作效率";
		stringProto4.ZHCN = "工作效率";
		stringProto4.ENUS = "Capacity";
		stringProto4.RegisterTranslation();
		StringProto stringProto5 = new StringProto();
		stringProto5.Name = "自由组件数量";
		stringProto5.ZHCN = "自由组件数量";
		stringProto5.ENUS = "Floating components in total";
		stringProto5.RegisterTranslation();
		StringProto stringProto6 = new StringProto();
		stringProto6.Name = "自由组件云";
		stringProto6.ZHCN = "自由组件云";
		stringProto6.ENUS = "Components Swarm";
		stringProto6.RegisterTranslation();
		StringProto stringProto7 = new StringProto();
		stringProto7.Name = "组件云蓝图";
		stringProto7.ZHCN = "组件云蓝图";
		stringProto7.ENUS = "Swarm Blueprint";
		stringProto7.RegisterTranslation();
		StringProto stringProto8 = new StringProto();
		stringProto8.Name = "锚定结构";
		stringProto8.ZHCN = "锚定结构";
		stringProto8.ENUS = "Anchored Structure";
		stringProto8.RegisterTranslation();
		StringProto stringProto9 = new StringProto();
		stringProto9.Name = "结构层级";
		stringProto9.ZHCN = "结构层级";
		stringProto9.ENUS = "Structure Layers";
		stringProto9.RegisterTranslation();
		StringProto stringProto10 = new StringProto();
		stringProto10.Name = "锚定结构蓝图";
		stringProto10.ZHCN = "锚定结构蓝图";
		stringProto10.ENUS = "Anchored Structure Blueprint";
		stringProto10.RegisterTranslation();
		StringProto stringProto11 = new StringProto();
		stringProto11.Name = "恒星功效系数";
		stringProto11.ZHCN = "恒星功效系数";
		stringProto11.ENUS = "Star Efficiency";
		stringProto11.RegisterTranslation();
		StringProto stringProto12 = new StringProto();
		stringProto12.Name = "最大工作效率";
		stringProto12.ZHCN = "最大工作效率";
		stringProto12.ENUS = "Capacity";
		stringProto12.RegisterTranslation();
		StringProto stringProto13 = new StringProto();
		stringProto13.Name = "巨构建筑蓝图";
		stringProto13.ZHCN = "巨构建筑蓝图";
		stringProto13.ENUS = "Structure Blueprint";
		stringProto13.RegisterTranslation();
		StringProto stringProto14 = new StringProto();
		stringProto14.Name = "自由组件寿命分布";
		stringProto14.ZHCN = "自由组件寿命分布";
		stringProto14.ENUS = "Life Distribution of Floating Components";
		stringProto14.RegisterTranslation();
		StringProto stringProto15 = new StringProto();
		stringProto15.Name = "自由组件状态统计";
		stringProto15.ZHCN = "自由组件状态统计";
		stringProto15.ENUS = "Floating Components Status Statistics";
		stringProto15.RegisterTranslation();
		StringProto stringProto16 = new StringProto();
		stringProto16.Name = "自由组件工作效率";
		stringProto16.ZHCN = "自由组件工作效率";
		stringProto16.ENUS = "Generation of Floating Components";
		stringProto16.RegisterTranslation();
		StringProto stringProto17 = new StringProto();
		stringProto17.Name = "锚定结构工作效率";
		stringProto17.ZHCN = "锚定结构工作效率";
		stringProto17.ENUS = "Generation of Anchored Structure";
		stringProto17.RegisterTranslation();
		StringProto stringProto18 = new StringProto();
		stringProto18.Name = "研究效率";
		stringProto18.ZHCN = "研究效率";
		stringProto18.ENUS = "Research Capacity";
		stringProto18.RegisterTranslation();
		StringProto stringProto19 = new StringProto();
		stringProto19.Name = "折跃场加速";
		stringProto19.ZHCN = "折跃场加速";
		stringProto19.ENUS = "Warp Acceleration";
		stringProto19.RegisterTranslation();
	}

	public static void AddTranslateStructureName()
	{
		StringProto stringProto = new StringProto();
		stringProto.Name = "规划";
		stringProto.ZHCN = "规划";
		stringProto.ENUS = "Plan ";
		stringProto.RegisterTranslation();
		StringProto stringProto2 = new StringProto();
		stringProto2.Name = "戴森球jinx";
		stringProto2.ZHCN = "戴森球";
		stringProto2.ENUS = "Dyson Sphere";
		stringProto2.RegisterTranslation();
		StringProto stringProto3 = new StringProto();
		stringProto3.Name = "物质解压器";
		stringProto3.ZHCN = "物质解压器";
		stringProto3.ENUS = "Matter Decompressor";
		stringProto3.RegisterTranslation();
		StringProto stringProto4 = new StringProto();
		stringProto4.Name = "科学枢纽";
		stringProto4.ZHCN = "科学枢纽";
		stringProto4.ENUS = "Science Nexus";
		stringProto4.RegisterTranslation();
		StringProto stringProto5 = new StringProto();
		stringProto5.Name = "折跃场广播阵列";
		stringProto5.ZHCN = "折跃场广播阵列";
		stringProto5.ENUS = "Warp Field Broadcast Array";
		stringProto5.RegisterTranslation();
		StringProto stringProto6 = new StringProto();
		stringProto6.Name = "星际组装厂";
		stringProto6.ZHCN = "星际组装厂";
		stringProto6.ENUS = "Interstellar Assembly";
		stringProto6.RegisterTranslation();
		StringProto stringProto7 = new StringProto();
		stringProto7.Name = "晶体重构器";
		stringProto7.ZHCN = "晶体重构器";
		stringProto7.ENUS = "Crystal Reconstructor";
		stringProto7.RegisterTranslation();
		StringProto stringProto8 = new StringProto();
		stringProto8.Name = "警告最多一个";
		stringProto8.ZHCN = "折跃场广播阵列最多建造一个，请检查星系:";
		stringProto8.ENUS = "You can only build one Wrapfield broadcast array, please check:";
		stringProto8.RegisterTranslation();
		StringProto stringProto9 = new StringProto();
		stringProto9.Name = "警告先拆除";
		stringProto9.ZHCN = "你必须先拆除所有锚定结构（节点）再规划不同的巨构建筑。";
		stringProto9.ENUS = "You have to remove all anchor structures (nodes) before planning different megastructures.";
		stringProto9.RegisterTranslation();
		StringProto stringProto10 = new StringProto();
		stringProto10.Name = "警告仅黑洞";
		stringProto10.ZHCN = "物质解压器只能在黑洞上建造。";
		stringProto10.ENUS = "Matter decompressors can only be built on black holes.";
		stringProto10.RegisterTranslation();
		StringProto stringProto11 = new StringProto();
		stringProto11.Name = "警告仅中子星白矮星";
		stringProto11.ZHCN = "晶体重构器只能在中子星或白矮星上建造。";
		stringProto11.ENUS = "Crystal reconstructors can only be built on neutron stars or white drawf.";
		stringProto11.RegisterTranslation();
		StringProto stringProto12 = new StringProto();
		stringProto12.Name = "当前";
		stringProto12.ZHCN = "当前";
		stringProto12.ENUS = "Currently";
		stringProto12.RegisterTranslation();
		StringProto stringProto13 = new StringProto();
		stringProto13.Name = "警告未知错误";
		stringProto13.ZHCN = "设置异常失败，请像mod作者反馈该问题。";
		stringProto13.ENUS = "The setting fails abnormally, please report this problem.";
		stringProto13.RegisterTranslation();
		StringProto stringProto14 = new StringProto();
		stringProto14.Name = "MegaStructures";
		stringProto14.ZHCN = "巨构";
		stringProto14.ENUS = "Megastructures";
		stringProto14.RegisterTranslation();
		StringProto stringProto15 = new StringProto();
		stringProto15.Name = "物质合成";
		stringProto15.ZHCN = "物质合成";
		stringProto15.ENUS = "Substance Generation";
		stringProto15.RegisterTranslation();
		StringProto stringProto16 = new StringProto();
		stringProto16.Name = "原矿模式";
		stringProto16.ZHCN = "原矿输出";
		stringProto16.ENUS = "Ore Generation";
		stringProto16.RegisterTranslation();
		StringProto stringProto17 = new StringProto();
		stringProto17.Name = "原矿模式提示";
		stringProto17.ZHCN = "在原矿输出模式下，产物将直接重构为原矿。";
		stringProto17.ENUS = "In Ore Generation mode, the receiver will receive product delivered by the megastructure and directly convert it into the raw ore.";
		stringProto17.RegisterTranslation();
		StringProto stringProto18 = new StringProto();
		stringProto18.Name = "恒星炮";
		stringProto18.ZHCN = "恒星炮";
		stringProto18.ENUS = "Star cannon";
		stringProto18.RegisterTranslation();
		StringProto stringProto19 = new StringProto();
		stringProto19.Name = "警告最多一个恒星炮";
		stringProto19.ZHCN = "恒星炮最多建造一个，请检查星系:";
		stringProto19.ENUS = "You can only build one Star cannon, please check:";
		stringProto19.RegisterTranslation();
	}

	public static void AddTranslateProtoNames1()
	{
		StringProto stringProto = new StringProto();
		stringProto.Name = "引力发生装置";
		stringProto.ZHCN = "引力发生装置";
		stringProto.ENUS = "Gravity generator";
		stringProto.RegisterTranslation();
		StringProto stringProto2 = new StringProto();
		stringProto2.Name = "引力发生装置描述";
		stringProto2.ZHCN = "引导临界光子轰击奇异物质即可激发引力波。恒星附近能够获取大量的临界光子，从而能够使引力发生装置高效地运行。";
		stringProto2.ENUS = "Gravitational waves can be excited by directing critical photons to hit strange matter. A large number of critical photons can be obtained near the star, allowing the gravitational generator to operate efficiently.";
		stringProto2.RegisterTranslation();
		StringProto stringProto3 = new StringProto();
		stringProto3.Name = "位面约束环";
		stringProto3.ZHCN = "位面约束环";
		stringProto3.ENUS = "Plane constraint ring";
		stringProto3.RegisterTranslation();
		StringProto stringProto4 = new StringProto();
		stringProto4.Name = "位面约束环描述";
		stringProto4.ZHCN = "位面约束环能够协同引力透镜引导并操纵引力，也是构建科学枢纽所需的恒星级粒子加速器的必要组件。";
		stringProto4.ENUS = "Plane constraint ring can guide and manipulate gravity with graviton lens, and it is also an essential component of the stellar-scale particle accelerators which are needed to build science nexus.";
		stringProto4.RegisterTranslation();
		StringProto stringProto5 = new StringProto();
		stringProto5.Name = "引力钻头";
		stringProto5.ZHCN = "引力钻头";
		stringProto5.ENUS = "Graviton drill";
		stringProto5.RegisterTranslation();
		StringProto stringProto6 = new StringProto();
		stringProto6.Name = "引力钻头描述";
		stringProto6.ZHCN = "借助黑洞本身的引力，引力钻头能够将物质从黑洞中取出，这还包括吸积盘中大量的单极磁石。借助谐振盘，黑洞原质将能够被解压并在星系内输送。";
		stringProto6.ENUS = "The graviton drill can pull matter out of the black hole using the gravity of the black hole itself, which also includes the unipolar magnets in the accretion disk. With the help of the resonant disc, the matter from the black hole will be able to be decompressed and transported within the galaxy.";
		stringProto6.RegisterTranslation();
		StringProto stringProto7 = new StringProto();
		stringProto7.Name = "隧穿激发装置";
		stringProto7.ZHCN = "隧穿激发装置";
		stringProto7.ENUS = "Tunneling exciter";
		stringProto7.RegisterTranslation();
		StringProto stringProto8 = new StringProto();
		stringProto8.Name = "隧穿激发装置描述";
		stringProto8.ZHCN = "隧穿激发装置可以完美地掌控量子隧穿效应，常被用来强化量子芯片的处理能力和纠错能力。通过量子隧穿效应还能够轻易突破弯曲空间的能量势垒，使得在任意远的空间打开裂口成为可能。";
		stringProto8.ENUS = "Tunneling exciters can perfectly control the quantum tunneling effect, and are often used to enhance the processing and error correction capabilities of quantum chips. The quantum tunneling effect can also easily break through the energy barrier of the curved space, making it possible to open the warp crack in any space far away.";
		stringProto8.RegisterTranslation();
		StringProto stringProto9 = new StringProto();
		stringProto9.Name = "谐振盘";
		stringProto9.ZHCN = "谐振盘";
		stringProto9.ENUS = "Resonant disc";
		stringProto9.RegisterTranslation();
		StringProto stringProto10 = new StringProto();
		stringProto10.Name = "谐振盘描述";
		stringProto10.ZHCN = "谐振盘仅通过恒星级别的能量就可以产生跨越恒星系的空间波动能量束。如果将谐振盘组成阵列，理论上可以形成覆盖全宇宙的折跃能量场。";
		stringProto10.ENUS = "The resonant disc can generate interstellar-scale space-wave energy beams from only stellar-scale energy. If the resonant discs are formed into an array, a warp field covering the entire universe can theoretically be formed.";
		stringProto10.RegisterTranslation();
		StringProto stringProto11 = new StringProto();
		stringProto11.Name = "光子探针";
		stringProto11.ZHCN = "光子探针";
		stringProto11.ENUS = "Photon probe";
		stringProto11.RegisterTranslation();
		StringProto stringProto12 = new StringProto();
		stringProto12.Name = "光子探针描述";
		stringProto12.ZHCN = "将临界光子变频后发射并引导晶体重构，发射的光子还能被回收。";
		stringProto12.ENUS = "The critical photons are frequency-converted and emitted, thereby guiding the crystal reconstruction. The photons can also be recovered.";
		stringProto12.RegisterTranslation();
		StringProto stringProto13 = new StringProto();
		stringProto13.Name = "量子计算机";
		stringProto13.ZHCN = "量子计算机";
		stringProto13.ENUS = "Quantum computer";
		stringProto13.RegisterTranslation();
		StringProto stringProto14 = new StringProto();
		stringProto14.Name = "量子计算机描述";
		stringProto14.ZHCN = "只要供给足够的能量，量子计算机的运算时钟能够无限逼近普朗克时间。通过量子比特协同，其潜在的单线程运算速率还能突破物理极限，并可以无限提升。现在，限制其计算速度的将只有能量输入水平。";
		stringProto14.ENUS = "As long as enough energy is supplied, the computing clock of a quantum computer can approach Planck time indefinitely. Through the cooperation of qubits, its potential single-threaded operation rate can also break through the physical limit and can be infinitely improved. Now, it will only be the level of energy input that will limit its computational speed.";
		stringProto14.RegisterTranslation();
		StringProto stringProto15 = new StringProto();
		stringProto15.Name = "星际组装厂组件";
		stringProto15.ZHCN = "星际组装厂组件";
		stringProto15.ENUS = "Interstellar assembly component";
		stringProto15.RegisterTranslation();
		StringProto stringProto16 = new StringProto();
		stringProto16.Name = "星际组装厂组件描述";
		stringProto16.ZHCN = "使用微型火箭将组件运载到恒星附近并构建星际组装厂的节点和框架。";
		stringProto16.ENUS = "Use a small carrier rocket to the planned Interstellar assembly to form the nodes and frames of Interstellar assembly.";
		stringProto16.RegisterTranslation();
		StringProto stringProto17 = new StringProto();
		stringProto17.Name = "物质解压器运载火箭";
		stringProto17.ZHCN = "物质解压器运载火箭";
		stringProto17.ENUS = "Matter decompressor carrier rocket";
		stringProto17.RegisterTranslation();
		StringProto stringProto18 = new StringProto();
		stringProto18.Name = "物质解压器运载火箭描述";
		stringProto18.ZHCN = "物质解压器相关组件的运载工具。";
		stringProto18.ENUS = "The delivery vehicle for the components of the Matter decompressor.";
		stringProto18.RegisterTranslation();
		StringProto stringProto19 = new StringProto();
		stringProto19.Name = "科学枢纽运载火箭";
		stringProto19.ZHCN = "科学枢纽运载火箭";
		stringProto19.ENUS = "Science nexus carrier rocket";
		stringProto19.RegisterTranslation();
		StringProto stringProto20 = new StringProto();
		stringProto20.Name = "科学枢纽运载火箭描述";
		stringProto20.ZHCN = "科学枢纽相关组件的运载工具。";
		stringProto20.ENUS = "The delivery vehicle for the components of the Science nexus.";
		stringProto20.RegisterTranslation();
	}

	public static void AddTranslateProtoNames2()
	{
		StringProto stringProto = new StringProto();
		stringProto.Name = "谐振发射器运载火箭";
		stringProto.ZHCN = "谐振发射器运载火箭";
		stringProto.ENUS = "Resonant generator carrier rocket";
		stringProto.RegisterTranslation();
		StringProto stringProto2 = new StringProto();
		stringProto2.Name = "谐振发射器运载火箭描述";
		stringProto2.ZHCN = "大量谐振发射器将组成阵列并向全星系广播折跃能量场。";
		stringProto2.ENUS = "A large number of resonant generators will form an array and broadcast the warp energy field to the entire galaxy.";
		stringProto2.RegisterTranslation();
		StringProto stringProto3 = new StringProto();
		stringProto3.Name = "星际组装厂运载火箭";
		stringProto3.ZHCN = "星际组装厂运载火箭";
		stringProto3.ENUS = "Interstellar assembly carrier rocket";
		stringProto3.RegisterTranslation();
		StringProto stringProto4 = new StringProto();
		stringProto4.Name = "星际组装厂运载火箭描述";
		stringProto4.ZHCN = "星际组装厂组件的运载工具。";
		stringProto4.ENUS = "The delivery vehicle of Interstellar assembly components.";
		stringProto4.RegisterTranslation();
		StringProto stringProto5 = new StringProto();
		stringProto5.Name = "晶体重构器运载火箭";
		stringProto5.ZHCN = "晶体重构器运载火箭";
		stringProto5.ENUS = "Crystal reconstructor carrier rocket";
		stringProto5.RegisterTranslation();
		StringProto stringProto6 = new StringProto();
		stringProto6.Name = "晶体重构器运载火箭描述";
		stringProto6.ZHCN = "晶体重构器相关组件的运载工具。";
		stringProto6.ENUS = "The delivery vehicle for the components of the Crystal reconstructor.";
		stringProto6.RegisterTranslation();
		StringProto stringProto7 = new StringProto();
		stringProto7.Name = "铁金属重构装置";
		stringProto7.ZHCN = "铁金属重构装置";
		stringProto7.ENUS = "Iron reconstruct receiver";
		stringProto7.RegisterTranslation();
		StringProto stringProto8 = new StringProto();
		stringProto8.Name = "铜金属重构装置";
		stringProto8.ZHCN = "铜金属重构装置";
		stringProto8.ENUS = "Copper reconstruct receiver";
		stringProto8.RegisterTranslation();
		StringProto stringProto9 = new StringProto();
		stringProto9.Name = "高纯硅重构装置";
		stringProto9.ZHCN = "高纯硅重构装置";
		stringProto9.ENUS = "Silicon reconstruct receiver";
		stringProto9.RegisterTranslation();
		StringProto stringProto10 = new StringProto();
		stringProto10.Name = "钛金属重构装置";
		stringProto10.ZHCN = "钛金属重构装置";
		stringProto10.ENUS = "Titanium reconstruct receiver";
		stringProto10.RegisterTranslation();
		StringProto stringProto11 = new StringProto();
		stringProto11.Name = "单极磁石重构装置";
		stringProto11.ZHCN = "单极磁石重构装置";
		stringProto11.ENUS = "Unipolar magnet receiver";
		stringProto11.RegisterTranslation();
		StringProto stringProto12 = new StringProto();
		stringProto12.Name = "接收重构装置描述";
		stringProto12.ZHCN = "从黑洞中解压出的亚稳态物质被接收后经过处理，重构为可直接使用的稳定材料。";
		stringProto12.ENUS = "The metastable matter decompressed from the black hole is received, processed, and reconstructed into stable material that can be used directly.";
		stringProto12.RegisterTranslation();
		StringProto stringProto13 = new StringProto();
		stringProto13.Name = "晶体接收器";
		stringProto13.ZHCN = "晶体接收器";
		stringProto13.ENUS = "Crystal receiver";
		stringProto13.RegisterTranslation();
		StringProto stringProto14 = new StringProto();
		stringProto14.Name = "晶体接收器描述";
		stringProto14.ZHCN = "从晶体重构器中合成的卡西米尔晶体前导微晶流将在此经过自发β衰变并形成完美的卡西米尔晶体。接收器也可以转而富集该过程的副产物——光栅石。";
		stringProto14.ENUS = "The Casimir crystal precursor crystallite flow synthesized from the Crystal reconstructor will undergo spontaneous β decay here and form perfect casimir crystals. The receivers can also in turn enrich for optical grating crystals, the by-product of the process.";
		stringProto14.RegisterTranslation();
		StringProto stringProto15 = new StringProto();
		stringProto15.Name = "组件集成装置";
		stringProto15.ZHCN = "组件集成装置";
		stringProto15.ENUS = "Component integration station";
		stringProto15.RegisterTranslation();
		StringProto stringProto16 = new StringProto();
		stringProto16.Name = "组件集成装置描述";
		stringProto16.ZHCN = "将星际组装厂的高集成配件进行预解压，形成可被快速组装的多功能集成组件。";
		stringProto16.ENUS = "Pre-decompress the high-integration parts from the Interstellar assembly, to form multi-functional integrated components that can be quickly assembled.";
		stringProto16.RegisterTranslation();
		StringProto stringProto17 = new StringProto();
		stringProto17.Name = "多功能集成组件";
		stringProto17.ZHCN = "多功能集成组件";
		stringProto17.ENUS = "Multi-functional integrated components";
		stringProto17.RegisterTranslation();
		StringProto stringProto18 = new StringProto();
		stringProto18.Name = "多功能集成组件描述";
		stringProto18.ZHCN = "超高集成度使其可以迅速地组装成多种生产建筑和物流组件，却仅占用极小的空间。";
		stringProto18.ENUS = "The high level of integration makes it possible to quickly assemble a variety of production building and logistics components, while occupying very little space.";
		stringProto18.RegisterTranslation();
		StringProto stringProto19 = new StringProto();
		stringProto19.Name = "光栅晶体接收器";
		stringProto19.ZHCN = "光栅晶体接收器";
		stringProto19.ENUS = "Optical crystal receiver";
		stringProto19.RegisterTranslation();
		StringProto stringProto20 = new StringProto();
		stringProto20.Name = "石墨提炼装置";
		stringProto20.ZHCN = "石墨提炼装置";
		stringProto20.ENUS = "Graphite extraction receiver";
		stringProto20.RegisterTranslation();
	}

	public static void AddTranslateProtoNames3()
	{
		StringProto stringProto = new StringProto();
		stringProto.Name = "传送带 快速组装";
		stringProto.ZHCN = "传送带 快速组装";
		stringProto.ENUS = "Conveyor belt - quick assembly";
		stringProto.RegisterTranslation();
		StringProto stringProto2 = new StringProto();
		stringProto2.Name = "分拣器 快速组装";
		stringProto2.ZHCN = "分拣器 快速组装";
		stringProto2.ENUS = "Sorter - quick assembly";
		stringProto2.RegisterTranslation();
		StringProto stringProto3 = new StringProto();
		stringProto3.Name = "配电站 快速组装";
		stringProto3.ZHCN = "配电站 快速组装";
		stringProto3.ENUS = "Substation - quick assembly";
		stringProto3.RegisterTranslation();
		StringProto stringProto4 = new StringProto();
		stringProto4.Name = "制造台 快速组装";
		stringProto4.ZHCN = "制造台 快速组装";
		stringProto4.ENUS = "Assembling machine - quick assembly";
		stringProto4.RegisterTranslation();
		StringProto stringProto5 = new StringProto();
		stringProto5.Name = "位面熔炉 快速组装";
		stringProto5.ZHCN = "位面熔炉 快速组装";
		stringProto5.ENUS = "Plane smelter - quick assembly";
		stringProto5.RegisterTranslation();
		StringProto stringProto6 = new StringProto();
		stringProto6.Name = "化工厂 快速组装";
		stringProto6.ZHCN = "化工厂 快速组装";
		stringProto6.ENUS = "Chemical plant - quick assembly";
		stringProto6.RegisterTranslation();
		StringProto stringProto7 = new StringProto();
		stringProto7.Name = "精炼厂 快速组装";
		stringProto7.ZHCN = "精炼厂 快速组装";
		stringProto7.ENUS = "Refinery - quick assembly";
		stringProto7.RegisterTranslation();
		StringProto stringProto8 = new StringProto();
		stringProto8.Name = "对撞机 快速组装";
		stringProto8.ZHCN = "对撞机 快速组装";
		stringProto8.ENUS = "Collider - quick assembly";
		stringProto8.RegisterTranslation();
		StringProto stringProto9 = new StringProto();
		stringProto9.Name = "研究站 快速组装";
		stringProto9.ZHCN = "研究站 快速组装";
		stringProto9.ENUS = "Lab - quick assembly";
		stringProto9.RegisterTranslation();
		StringProto stringProto10 = new StringProto();
		stringProto10.Name = "人造恒星 快速组装";
		stringProto10.ZHCN = "人造恒星 快速组装";
		stringProto10.ENUS = "Artificial star - quick assembly";
		stringProto10.RegisterTranslation();
		StringProto stringProto11 = new StringProto();
		stringProto11.Name = "行星内物流 快速组装";
		stringProto11.ZHCN = "行星内物流 快速组装";
		stringProto11.ENUS = "Planetary logistics - quick assembly";
		stringProto11.RegisterTranslation();
		StringProto stringProto12 = new StringProto();
		stringProto12.Name = "星际物流 快速组装";
		stringProto12.ZHCN = "星际物流 快速组装";
		stringProto12.ENUS = "Interstellar logistics - quick assembly";
		stringProto12.RegisterTranslation();
		StringProto stringProto13 = new StringProto();
		stringProto13.Name = "快速组装描述";
		stringProto13.ZHCN = "使用多功能集成组件快速递组装成目标物品。";
		stringProto13.ENUS = "Quickly assemble target items using multi-functional integrated components.";
		stringProto13.RegisterTranslation();
	}

	public static void AddTranslateProtoNames4()
	{
		LocalizationModule.RegisterTranslation("每秒伤害gm", "Base Damage", "基础伤害", "");
		LocalizationModule.RegisterTranslation("最大生产速度gm", "Production speed", "生产速度", "");
		LocalizationModule.RegisterTranslation("阶段", "stage", "阶段", "");
		LocalizationModule.RegisterTranslation("连续开火次数", "Aim targets", "射击目标数", "");
		LocalizationModule.RegisterTranslation("最大射程", "Maximum fire range", "最大射程", "");
		LocalizationModule.RegisterTranslation("伤害削减", "Damage reduction", "伤害削减", "");
		LocalizationModule.RegisterTranslation("当前能量水平", "Current capacity", "当前能量水平", "");
		LocalizationModule.RegisterTranslation("请拆除接收站", "Please remove all receivers", "请拆除本星系的接收站", "");
		LocalizationModule.RegisterTranslation("下一阶段所需能量水平", "Next stage required capacity", "下一阶段所需能量水平", "");
		LocalizationModule.RegisterTranslation("冷却及充能时间", "Charge duration", "充能时间", "");
		LocalizationModule.RegisterTranslation("修建进度", "\nProgress to\nnext stage", "修建进度", "");
		LocalizationModule.RegisterTranslation("最终阶段", "Final stage", "最终阶段", "");
		LocalizationModule.RegisterTranslation("节点总数（已规划）gm", "Nodes in total(Planned)", "节点总数（已规划）", "");
		LocalizationModule.RegisterTranslation("请求功率gm", "Requested power", "请求功率", "");
		LocalizationModule.RegisterTranslation("无限制gm", "Infinite", "无限制", "");
		LocalizationModule.RegisterTranslation("警告巨构科技未解锁", "You must unlock the Mission complete technology to unlock the science nexus", "你必须先解锁通关游戏才能解锁科学枢纽", "");
		LocalizationModule.RegisterTranslation("游戏提示mms", "Message", "游戏提示", "");
		LocalizationModule.RegisterTranslation("力场发生器", "Force field generator", "力场发生器", "");
		LocalizationModule.RegisterTranslation("力场发生器描述", "With the help of the gravity generator, the force field generator can multiply the gravitational force in a fixed resonance field and give it a highly controllable directivity. If the energy supply is sufficient, the force field generator is able to deflects or even reverses the direction of the force field, making it possible to encode the resonant frequency of the force field.", "借助引力发生装置，力场发生器可以将引力在固定的谐振场域成倍放大，并赋予其高度可控的指向性。如果能量供应足够，力场发生器快速偏折甚至掉转力场方向，这使得对力场谐振频率进行编码成为可能。", "");
		LocalizationModule.RegisterTranslation("复合态晶体", "Compound cyrstal", "复合态晶体", "");
		LocalizationModule.RegisterTranslation("复合态晶体描述", "This single-molecule crystal has a normal density like ordinary matter, but can be reshaped into a material with extremely high hardness under the constraints of strong interaction force, so this material is also called strong interaction material (SIM).", "这种单分子晶体像普通物质一样拥有正常的密度，但能够在强相互作用力的束缚下，被重塑为硬度极高的物质，因此这种物质又被称为强相互作用力材料（SIM）。", "");
		LocalizationModule.RegisterTranslation("电磁力抑制器", "Electromagnetic force suppressor", "电磁力抑制器", "");
		LocalizationModule.RegisterTranslation("电磁力抑制器描述", "By eliminating the electromagnetic force between atomic nucleus, it allows the range of the strong interaction force to overflow the nucleus and expand to atom scope, providing the conditions for precise control of the strong interaction force. The suppressed electromagnetic force can also be redirected to create a vacuum Valsex field vortex ring.", "通过消除原子核之间的电磁力，允许强相互作用力的范围溢出原子核，并扩展到原子大小，为精确控制强力提供了条件。被抑制的电磁力还可以被引导至特定方向用以产生真空瓦尔塞克斯电场涡环。", "");
		LocalizationModule.RegisterTranslation("胶子发生器", "Gluon generator", "胶子发生器", "");
		LocalizationModule.RegisterTranslation("胶子发生器描述", "Generate controllable gluons to limit or expand the strength and scope of the strong interaction. The gluon generator must be controlled by quantum computers, so as to precisely control the arrangement of atoms on the quantum scale.", "产生可控胶子，以此限制或扩大强相互作用力的强度和作用范围。胶子发生器必须在量子计算机的协助下才能提高控制的精准程度，从而在量子尺度上精确控制原子排布。", "");
		LocalizationModule.RegisterTranslation("强力过载装置", "Strong interaction overload device", "强力过载装置", "");
		LocalizationModule.RegisterTranslation("强力过载装置描述", "The SIO device can make the repulsive and the attractive force peak to coincide precisely at a specific point, so that any deviation of the nucleus will be pulled back by the strong interaction force. If electromagnetic interference is removed, the nucleus will be fully anchored.", "强力过载装置可以使强力的排斥力峰值和吸引力峰值在特定的点精准重合，因而原子核的任何偏离都会被强力拉回。如果剔除了电磁力干扰，原子核将被完全锚定。", "");
		LocalizationModule.RegisterTranslation("导流框架", "Flow guide frame", "导流框架", "");
		LocalizationModule.RegisterTranslation("导流框架描述", "Storing, directing and guiding the energy of stars in a specific direction, creating high power directional energy resonance.", "将恒星的能量存储并引导、集中至特定方向，创造极高功率的定向能量谐振。", "");
		LocalizationModule.RegisterTranslation("恒星炮组件", "Star cannon component", "恒星炮组件", "");
		LocalizationModule.RegisterTranslation("恒星炮组件描述", "The star cannon can store the energy of the star to stimulate another star's energy surge, guiding its own energy to attack the dark fog. The time for the star cannon to fire is limited, and it needs to be recharged after firing.", "恒星炮能够储存恒星的能量，用以激发另一个恒星的能量涌动，引导其自身的能量攻击其所在星系的黑雾巢穴。恒星炮每次开火的时间有限，开火后需要重新充能。", "");
		LocalizationModule.RegisterTranslation("恒星炮运载火箭", "Star cannon carrier rocket", "恒星炮运载火箭", "");
		LocalizationModule.RegisterTranslation("恒星炮运载火箭描述", "The delivery vehicle for the components of the Star cannon.", "恒星炮相关组件的运载工具。", "");
		LocalizationModule.RegisterTranslation("水滴gm", "Droplet", "水滴", "");
		LocalizationModule.RegisterTranslation("水滴描述gm", "Droplets can fight as Icarus' space fleet. It uses extremely solid surface to hit key structures. Precise control of the droplet's propulsion and steering requires powerful remote computing power, as well as a remote supply of Mecha energy to control it. If the launch them manually, they will use 10 times as much energy to attack all enemies in the entire star system, not just those within 1 AU. Although the damage efficiency of the droplet is limited by its attack mode, its structure of strongly interacting materials allows it to withstand unlimited damage. You neet to set the space fleet type to droplet type to use the droplet.", "水滴可以作为伊卡洛斯的空中舰队进行作战，并使用极其坚硬的表面撞击敌人的关键结构。精确地控制水滴的推进和转向需要强大的远端运算能力，且发射水滴和操控也需要机甲能量的远程供给。如果主动发射水滴，其还可以消耗10倍的能量来攻击整个星系内的敌人，而不仅仅是1AU以内的敌人。虽然水滴的输出效率受其攻击方式限制，但其由强相互作用力材料组成的结构可以使其承受无限的伤害。你需要将太空编队的类型设置为水滴编队，以此放入水滴。", "");
		LocalizationModule.RegisterTranslation("恒星炮设计说明题目", "Design Instructions", "恒星炮设计说明", "");
		LocalizationModule.RegisterTranslation("恒星炮设计说明文本", "1. When the star cannon fires, the rotation axes of all layers will overlap, and the north pole will point to the target, so please design the north pole of each layer's grid as the center of the muzzle;\n2. When the star cannon fires, 36 random  nodes on the 1st layer will emit a laser to the muzzle. For aesthetic reasons, please try to make the first layer only contain up to 36 nodes, and try to make them symmetrical to each other;\n3. The construction of the star cannon needs to go through multiple stages. And at the same time, the star cannon can increase its damage, max fire target count, and charging speed several times. After reaching the final stage, continue to build shells will continuously increase the damage;\n4. After built the star cannon, select a star system or a space dark fog hive in starmap mode, then launch the star cannon. Star cannon can NOT fire at its own star system.", "1.恒星炮开火时所有层级的旋转轴将重叠，并且让北极指向目标开火，为美观考虑，设计时请以各层网格自身的北极点为炮口中心；\n2.恒星炮开火时，第1层的随机36个节点将发射出激光指向炮口，为美观考虑，请尽量使得第1层只包含36个（或更少的）节点，并使其相互对称。\n3.恒星炮建造需要经过多个阶段，随着各建造阶段完成，恒星炮能数次提高伤害、同时射击的目标数和充能速度等属性。在达到最终阶段后，继续修建壳层可以不断提高伤害。\n4.建造恒星炮后，在星图模式中选择一个恒星系或太空黑雾巢穴进行开火。恒星炮无法向自身所在星系开火。", "");
		LocalizationModule.RegisterTranslation("恒星炮开火按钮文本", "Launch Star Cannon (R)", " 启动恒星炮 (R)", "");
		LocalizationModule.RegisterTranslation("恒星炮开火标题", "Launch Star Cannon", "启动恒星炮", "");
		LocalizationModule.RegisterTranslation("恒星炮开火描述", "Attack the space dark fog hive in the selected star system by the Star Cannon.", "使用恒星炮射击该星系内的太空黑雾巢穴。", "");
		LocalizationModule.RegisterTranslation("选中黑雾巢穴时的恒星炮开火描述", "Attack the selected dark fog hive in the selected star system by the Star Cannon. Then attack other hives in that star system.", "使用恒星炮向该黑雾巢穴开火，而后继续射击该星系的其他太空黑雾巢穴。", "");
		LocalizationModule.RegisterTranslation("优先射击按钮文本", "Prioritize attack (R)", " 优先射击 (R)", "");
		LocalizationModule.RegisterTranslation("优先射击标题", "Prioritize attack", "优先射击", "");
		LocalizationModule.RegisterTranslation("优先射击描述", "Star Cannon will turn to attack structures of this selected hive immediately.", "恒星炮将立刻开始转而攻击选中的黑雾巢穴结构。", "");
		LocalizationModule.RegisterTranslation("恒星炮未规划按钮文本", "Star Cannon not planned", "恒星炮未规划", "");
		LocalizationModule.RegisterTranslation("恒星炮建设中按钮文本", "Star Cannon Construction in Progress", "恒星炮建设中", "");
		LocalizationModule.RegisterTranslation("恒星炮正在瞄准按钮文本", "Aiming", "瞄准中", "");
		LocalizationModule.RegisterTranslation("恒星炮预热中按钮文本", "Guiding", "引导中", "");
		LocalizationModule.RegisterTranslation("恒星炮开火中按钮文本", "Firing", "开火中", "");
		LocalizationModule.RegisterTranslation("恒星炮冷却中按钮文本", "Cooling down", "冷却中", "");
		LocalizationModule.RegisterTranslation("恒星炮充能中按钮文本", "Charging", "充能中", "");
		LocalizationModule.RegisterTranslation("恒星炮已就绪", "Star Cannon is Ready", "恒星炮已就绪", "");
		LocalizationModule.RegisterTranslation("恒星炮正在瞄准", "Star Cannon Aiming", "恒星炮正在瞄准", "");
		LocalizationModule.RegisterTranslation("恒星炮预热中", "Star Cannon Guiding", "恒星炮引导中", "");
		LocalizationModule.RegisterTranslation("恒星炮开火中", "Star Cannon Firing", "恒星炮开火中", "");
		LocalizationModule.RegisterTranslation("恒星炮冷却中", "Star Cannon Cooling Down", "恒星炮冷却中", "");
		LocalizationModule.RegisterTranslation("恒星炮充能中", "Star Cannon Charging", "恒星炮充能中", "");
		LocalizationModule.RegisterTranslation("没有规划的恒星炮！", "Star Cannon not planned!", "没有规划的恒星炮！", "");
		LocalizationModule.RegisterTranslation("恒星炮尚未规划", "Star Cannon Not Planned", "恒星炮尚未规划", "");
		LocalizationModule.RegisterTranslation("恒星炮修建中警告", "Star cannon needs to be built to at least the first stage before it can fire!", "恒星炮需要至少修建至第一阶段才能够开火！", "");
		LocalizationModule.RegisterTranslation("恒星炮冷却中警告", "Unable to fire because the star cannon is cooling down.", "恒星炮正在冷却中，无法开火！", "");
		LocalizationModule.RegisterTranslation("恒星炮充能中警告", "Unable to fire because the star cannon is charging.", "恒星炮正在充能中，无法开火！", "");
		LocalizationModule.RegisterTranslation("目标无法定位警告", "Unable to locate any targets! Please check that you've visited that star system before, and that star system has surviving DF hive.", "无法定位任何目标！请确认至少进入过该星系一次，且该星系有存活的黑雾巢穴。", "");
		LocalizationModule.RegisterTranslation("恒星炮不能向自身所在星系开火！", "Star cannon cannot fire at its own star system!", "恒星炮无法向自身所在星系开火！", "");
		LocalizationModule.RegisterTranslation("无法更改目标星系警告", "Unable to change the target star system when firing.", "恒星炮正在开火时无法更换目标星系！", "");
		LocalizationModule.RegisterTranslation("恒星级武器检测警告", "Star level weapon activation detected!", "检测到恒星级武器启动！", "");
		LocalizationModule.RegisterTranslation("尼科尔戴森光束", "Nicoll-Dyson beam", "尼科尔-戴森光束", "");
		LocalizationModule.RegisterTranslation("尼科尔戴森光束描述", "Decoding a method to guide stellar energy from dark fog matrix, then use it to attack space dark fog hive.\nAfter built the star cannon, select a star system or a space dark fog hive in starmap mode, then launch the star cannon.\n<color=#FD965ECC>Warning:</color> This technology has been prohibited by the COSMO Technology Ethics Committee. <color=#FD965ECC>Please initiate such research manually.</color>", "从黑雾矩阵中解码引导恒星级能量的方法，并利用其攻击太空黑雾巢穴。\n建造恒星炮后，在星图模式中选择一个恒星系或太空黑雾巢穴进行开火。\n<color=#FD965ECC>警告：</color>该科技的相关技术已被COSMO技术伦理委员会禁用，<color=#FD965ECC>请手动研究。</color>", "");
		LocalizationModule.RegisterTranslation("尼科尔戴森光束结论", "You have unlocked the star cannon.", "你解锁了建造恒星炮的能力。", "");
		LocalizationModule.RegisterTranslation("先解锁恒星炮科技警告", "You have to unlocked the Nicoll-Dyson beam tech first.", "你需要先解锁尼科尔-戴森光束的科技。", "");
		LocalizationModule.RegisterTranslation("功能说明题目", "Function", "功能", "");
		LocalizationModule.RegisterTranslation("物质解压器功能文本", "Produce unipolar magnet and some basic resources such as iron ingot, which can be received by corresponding receivers.", "产出单极磁石和一些基础资源（例如铁块），可被对应的物质重构器接收。", "");
		LocalizationModule.RegisterTranslation("科学枢纽功能文本", "Upload hash points for research without requiring any matrix.", "无需矩阵即可上传hash点数进行研究。", "");
		LocalizationModule.RegisterTranslation("折跃场广播阵列功能文本", "Create a warp field centered on this megastructure. When any logistics vessels enters the warp field, it will <color=#FD965ECC>instantly pass through the warp field</color> at a speed of 250 ly/s. In addition, if a interstellar logistics vessel takes off in a warp field, its energy consumption will be reduced.\n<color=#FD965ECC>The radius of the warp field and the effect of reducing energy consumption depend on the energy level</color> of the megastructure. But the acceleration effect within the warp field is not affected by the megastructure energy.", "在以巨构为中心的一定半径内创建一个折跃场，任何物流船经过折跃场时，会以250ly/s的速度<color=#FD965ECC>瞬间穿过折跃场</color>。此外，若星际物流飞船起飞时处在折跃场内，其消耗的能量还会被降低。\n<color=#FD965ECC>折跃场半径</color>和<color=#FD965ECC>能耗降低效果</color>取决于<color=#FD965ECC>巨构能量水平</color>，折跃场内的加速效果不受能量水平影响。", "");
		LocalizationModule.RegisterTranslation("星际组装厂功能文本", "You can set up to 15 recipes, this megastructure will automatically obtain materials from the exchange logistic stations on the ground, produce products and transport them back to the ground. The production speed depends on the assignment of energy and the recipe's time cost. And you can use proliferator to get extra products without consuming extra energy, if the recipe allows extra production. In any cases, you can not choose the production speedup mode. Unused energy will automatically produce multi-functional integration components.\nIn addition to receive by the exchange logistic station, components can also be transmitted directly to the mecha (but only 10%efficiency). You can set this function in the mecha panel.", "可设定最多15个配方，从地表的物资交换站获取材料，生产产品并输送回物资交换站，生产速度取决于分配的能量水平。可以将原料喷涂增产剂来获取额外产出（如果配方允许），这不会占用额外能量，也不能切换为生产加速模式。未使用的能量会自动生产多功能集成组件。\n组件除了可以在物资交换站接收，还可以直接远程传输到机甲中（但只有10%效率）。你可以在机甲面板中设置此功能。", "");
		LocalizationModule.RegisterTranslation("晶体重构器功能文本", "Produce Casimir crystals and optical grating crystals, which can be received by corresponding receivers.", "产出卡西米尔晶体和光栅石，可被对应的接收器接收。", "");
		LocalizationModule.RegisterTranslation("远程折跃多功能组件限制", "Remote receive [Multifunc-Compo] Upper Limit", "远程输送多功能组件限制", "");
		LocalizationModule.RegisterTranslation("远程接收关闭gm", "Off", "关闭", "");
		LocalizationModule.RegisterTranslation("上限1000", "Max 1000", "上限1000", "");
		LocalizationModule.RegisterTranslation("上限2000", "Max 2000", "上限2000", "");
		LocalizationModule.RegisterTranslation("组件无限制", "No limit", "无限制", "");
		LocalizationModule.RegisterTranslation("已开启优先传输至机甲", "Remote-Teleport To Mecha Enabled", "已开启优先输送至机甲", "");
		LocalizationModule.RegisterTranslation("鼠标触碰左侧黄条以规划巨构", "Touch the left bar to plan the megastructure", "鼠标触碰左侧线条以规划巨构", "");
		LocalizationModule.RegisterTranslation("物资交换器", "Exchange Logistic Station", "物资交换物流站", "");
		LocalizationModule.RegisterTranslation("物资交换器描述", "Exchange Logistic Station can transport materials like Interstellar Logistics Station. In addition, the interstellar assembly also needs this building to obtain raw materials from the ground, or to transport the product to the ground.<color=#FD965ECC> If the fifth slot is set to proliferator, it will be automatically used to spray the entire exchange station's items.</color> This function only works when its star system has an interstellar assembly.", "物资交换物流站可以像星际物流站一样运输物资，除此之外，星际组装厂还需要此建筑来从地面获取原材料，或将产物输送至地表。<color=#FD965ECC>如果将第五个栏位设置成增产剂，它将自动被用于喷涂整个交换站的物资。</color>该效果只在该星系是星际组装厂时生效。", "");
		LocalizationModule.RegisterTranslation("理论最大速度", "max", "最大", "");
		LocalizationModule.RegisterTranslation("可承载速度", "capable", "可承载", "");
		LocalizationModule.RegisterTranslation("理想速度", "ideal", "理想速度", "");
		LocalizationModule.RegisterTranslation("受限理论最大速度", "<color=#ff1010c0>(limited)</color> max", "<color=#ff1010c0>(受限)</color>最大", "");
		LocalizationModule.RegisterTranslation("能量分配", "Energy Allocation", "能量分配", "");
		LocalizationModule.RegisterTranslation("剩余能量", "Residual Energy", "剩余能量", "");
		LocalizationModule.RegisterTranslation("警告巨构不支持恒星系数量大于100个", "Warning! This MegaStructure does not support the galaxy with more than 100 star systems. Please find a star system with StarIndex lower than 100, or try to edit config file to remove this restriction.", "警告！此巨构不支持恒星系数量大于100个！请寻找序号小于100的恒星系，或在config文件中修改设置来解除此限制。", "");
		LocalizationModule.RegisterTranslation("警告巨构不支持恒星系数量大于1200个", "Warning! This MegaStructure does not support the galaxy with more than 1200 star systems.  Please find another star system with StarIndex lower than 1200", "警告！此巨构不支持恒星系数量大于1200个！请寻找一个序号小于1200的恒星系。", "");
		LocalizationModule.RegisterTranslation("警告mms", "Warning", "警告", "");
		LocalizationModule.RegisterTranslation("我明白", "Understood", "我明白", "");
		LocalizationModule.RegisterTranslation("警告未开启大于1000星系支持", "[MoreMegaStructure]: Warning! You are loading a save which has more than 100 stars, but you\nhaven't enabled the \"Support 1000 Stars\" configuration yet.\nPlease enable that configuration setting in config file \nor please load a save with less than 100 stars.\nOtherwise, errors or mistakes may occur.", "[更多巨构]：警告！你正在加载一个超过100星系的存档，\n但你尚未开启“支持1000星系”的配置项，请在config文件中开启“Support1000Stars”配置项\n或者加载一个少于100星系的存档，\n否则，游戏可能会出现报错或异常问题。", "");
		LocalizationModule.RegisterTranslation("警告选择了重复的配方", "Please don't select repeated recipes.", "请不要选择重复的配方。", "");
		LocalizationModule.RegisterTranslation("主产物巨构内部仓储", "Internal Storage (Primary Product)", "主产物内部仓储", "");
		LocalizationModule.RegisterTranslation("巨构内部仓储", "Internal Storage", "内部仓储", "");
		LocalizationModule.RegisterTranslation("显示/隐藏星际组装厂配置", "Show/Hide Star Assembly Recipes", "显示/隐藏 星际组装厂配置", "");
		LocalizationModule.RegisterTranslation("配置最大生产速度限制", "Configure production speed limit", "配置生产速度限制", "");
		LocalizationModule.RegisterTranslation("最大生产速度限制", "Expected Speed (/min)", "目标生产速度(/min)", "");
		LocalizationModule.RegisterTranslation("最大生产速度限制题目", "Expected Speed", "目标生产速度", "");
		LocalizationModule.RegisterTranslation("最大生产速度限制描述", "When the energy of the interstellar assembly is sufficient to let all recipes' <color=#FD965ECC>basic production speed</color> achieve the expected speed, the excess energy will be used to make multifunctional integrated components. When the energy is insufficient, it will allocate energy according to the proportions of the requested speeds of each recipe, keeping their <color=#FD965ECC>basic production speeds' proportion</color> consistent with the expected speeds' proportion.\nNote that this setting only applies to the <color=#FD965ECC>basic production speed of the first product</color>, and <color=#FD965ECC>does not consider the effects of proliferator or specialization</color>. Therefore, the actual production speed may exceed the set value due to proliferator or specialization.", "当星际组装厂的能量足以使得所有配方的<color=#FD965ECC>基础生产速度</color>达到设定的目标生产速度需求时，多余的能量将被用于制造多功能集成组件。当星际组装厂能量不足时，将按照各配方的速度配比去分配能量，保持他们的基础速度比例与目标生产速度的比例一致。\n注意，此设置仅作用于<color=#FD965ECC>第一位置产物的基础生产速度</color>，<color=#FD965ECC>不会考虑增产或特化的影响</color>，因此实际产量可能会由于增产或特化超出设定值。", "");
		LocalizationModule.RegisterTranslation("星际组装厂逻辑更新警告", "Due to the updates to the More Megastructure, the energy allocation logic of the interstellar assembly has been changed. Please confirm the speed settings of each recipe in each interstellar assembly to prevent them from shutting down.", "由于更多巨构版本更新，星际组装厂的能量分配逻辑已重构，\n请确认每个星际组装厂的速度设置，以防星际组装厂停摆。", "");
		LocalizationModule.RegisterTranslation("加倍所有速度设置", "Double All Expected Spd.", "加倍所有速度设置", "");
		LocalizationModule.RegisterTranslation("减半所有速度设置", "Halve All Expected Spd.", "减半所有速度设置", "");
		LocalizationModule.RegisterTranslation("有过大数值警告", "The requested speed of recipe {0} is too high to double, please check.", "配方{0}的目标速度过大，无法加倍，请检查。", "");
		LocalizationModule.RegisterTranslation("组装厂槽位解锁于", "Locked. Unlock at {0}x speed", "已锁定，解锁于 {0}x 速度", "");
		LocalizationModule.RegisterTranslation("星际组装厂槽位未解锁警告", "This slot is locked!", "此栏位尚未解锁！", "");
		LocalizationModule.RegisterTranslation("警告巨构不支持此类配方", "Interstellar Assembly is not able to process this recipe.", "星际组装厂无法处理此配方。", "");
		LocalizationModule.RegisterTranslation("钨重构装置", "Tungsten Reconstructor", "钨重构装置", "");
		LocalizationModule.RegisterTranslation("巨建快速组装描述", "Quickly assemble constructions using multi-functional integrated components", "使用多功能集成组件快速递组装成目标巨建。", "");
		LocalizationModule.RegisterTranslation("折跃场半径", "Warp Field Radius", "折跃场半径", "");
		LocalizationModule.RegisterTranslation("折跃场内曲速速率", "Warp Speed In Warp Field", "折跃场内曲速速率", "");
		LocalizationModule.RegisterTranslation("折跃场内能量消耗", "Energy Cost In Warp Field", "折跃场内能量消耗", "");
		LocalizationModule.RegisterTranslation("折跃场已覆盖信息", "Covered By Warp Field From {0}\nLogistic Vessel Energy Consumption -{1:N0}% ", "已被来自{0}的折跃场覆盖\n物流船消耗 -{1:N0}% ", "");
		LocalizationModule.RegisterTranslation("折跃场未覆盖信息", "Warp Field Not Covered ", "折跃场未覆盖 ", "");
		LocalizationModule.RegisterTranslation("折跃场范围显示", "Warp Field Not Covered ", "折跃场范围显示", "");
		LocalizationModule.RegisterTranslation("折跃场范围显示描述", "Click to switch on/off the display of the warp field area in the starmap.", "点击以开启/关闭星图界面的折跃场范围显示。", "");
		LocalizationModule.RegisterTranslation("巨构状态", "Mega structure status", "巨构状态", "");
		LocalizationModule.RegisterTranslation("巨构类型不符", "type not match", "巨构不符", "");
		LocalizationModule.RegisterTranslation("模式错误", "wrong mode", "模式错误", "");
		LocalizationModule.RegisterTranslation("星际组装厂特化名称0", "Interstellar Assembly Specilization", "星际组装厂 - 特化", "");
		LocalizationModule.RegisterTranslation("星际组装厂特化名称1", "Stellar Forge", "恒星熔炉", "");
		LocalizationModule.RegisterTranslation("星际组装厂特化名称2", "Stellar reactor", "恒星反应釜", "");
		LocalizationModule.RegisterTranslation("星际组装厂特化名称3", "Ring-star Particle Accelerator", "星环粒子加速器", "");
		LocalizationModule.RegisterTranslation("星际组装厂特化名称4", "Hyper-precision Assembly", "超精密装配厂", "");
		LocalizationModule.RegisterTranslation("星际组装厂特化名称5", "Cybrex War Forge", "赛博勒克斯战争工厂", "");
		LocalizationModule.RegisterTranslation("特化0介绍标题", "Interstellar Assembly Specilization", "星际组装厂 - 特化", "");
		LocalizationModule.RegisterTranslation("特化1介绍标题", "Stellar Forge", "恒星熔炉", "");
		LocalizationModule.RegisterTranslation("特化2介绍标题", "Stellar Reactor", "恒星反应釜", "");
		LocalizationModule.RegisterTranslation("特化3介绍标题", "Ring-star Particle Accelerator", "星环粒子加速器", "");
		LocalizationModule.RegisterTranslation("特化4介绍标题", "Hyper-precision Assembly", "超精密装配厂", "");
		LocalizationModule.RegisterTranslation("特化5介绍标题", "Cybrex War Forge", "赛博勒克斯战争工厂", "");
		LocalizationModule.RegisterTranslation("特化0介绍内容", "\"Once certain specialization <color=#30bb30>requirements</color> are met, the specialization process of the Interstellar Assembly will begin. After <color=#30bb30>maintaining the requirements for 10-120 minutes</color>, the interstellar Assembly can be converted to this <color=#61d8ffc0>Specialization Mode</color>. The larger the current scale of the Interstellar Assembly, the longer the specialization process will take.\nDifferent specialization modes will provide different  <color=#61d8ffc0>bonus effects</color> on different recipes.\nOnce the specialization process is completed, you can <color=#30bb30>no longer maintain the specialization requirements</color>,<color=#30bb30><i>Unless you start meeting the requirements for a different specialization mode</i></color>, which will cause it to start converting to the new specialization.", "一旦满足某种特化的<color=#30bb30>要求</color>，星际组装厂的特化进程将开始，<color=#30bb30>保持要求10-120分钟</color>后可以将星际组装厂转化为该<color=#61d8ffc0>特化模式</color>。星际组装厂的当前规模越大，转化过程所需时间越长。\n不同的特化模式将对不同的配方提供<color=#61d8ffc0>加成效果</color>。\n一旦特化进程完成，你可以<color=#30bb30>不再保持特化的要求</color>，<color=#30bb30><i>除非你转而开始满足另一种不同特化的转化要求</i></color>，这将使你的星际组装厂向新的特化开始转变。", "");
		LocalizationModule.RegisterTranslation("特化1介绍内容", "Requirement: At least 5 <color=#30bb30>smelting</color> recipes are assigned, and no other types of recipes assigned. \n\nSpecialized effect: All <color=#30bb30>smelting</color> recipes have <color=#61d8ffc0>extra-output-enabled</color>, and <color=#61d8ffc0>production speed +200%</color>. But it cannot produce multi-functional integrated components. \n\n<color=#61d8ffc0>Extra-output-enabled</color>: After all raw materials of the recipe are sprayed with proliferators, this recipe will definitely gain the <color=#61d8ffc0>extra product</color> effect in the Interstellar Assembly, regardless of whether the recipe prohibits extra output effects. ", "要求：分配了至少5个<color=#30bb30>冶炼</color>配方，且无其他类型的配方。\n\n特化效果：所有<color=#30bb30>冶炼</color>配方<color=#61d8ffc0>允许增产</color>，且<color=#61d8ffc0>速度+200%</color>。但无法产出多功能集成组件。\n\n<color=#61d8ffc0>允许增产</color>：配方的原料喷涂增产剂后，在星际组装厂中生产的产物一定可以获得<color=#61d8ffc0>额外产出</color>效果，无论该配方是否禁止额外产出效果。", "");
		LocalizationModule.RegisterTranslation("特化2介绍内容", "Requirements: At least 3 <color=#30bb30>Chemical</color>, <color=#30bb30>Petroleum</color> or <color=#30bb30>Production Enhancer</color> recipes are assigned, and no other types of recipes assigned.\n\nSpecialized effect: raw materials and products for all <color=#30bb30>chemical</color>, <color=#30bb30>petroleum</color> and <color=#30bb30>proliferator</color> recipes will be automatically <color=#61d8ffc0>sprayed with proliferator for free</color>, and have <color=#61d8ffc0>extra-output-enabled</color>, besides, their <color=#61d8ffc0>production speed +100%</color>.\n\n<color=#61d8ffc0>Extra-output-enabled</color>: After all raw materials of the recipe are sprayed with proliferators, this recipe will definitely gain the <color=#61d8ffc0>extra product</color> effect in the Interstellar Assembly, regardless of whether the recipe prohibits extra output effects. ", "要求：分配了至少3个<color=#30bb30>化工</color>、<color=#30bb30>石油</color>或<color=#30bb30>增产剂</color>配方，且无其他类型的配方。\n\n特化效果：为所有<color=#30bb30>化工</color>、<color=#30bb30>石油</color>和<color=#30bb30>增产剂</color>配方的原料和产物<color=#61d8ffc0>免费喷涂增产剂</color>，并<color=#61d8ffc0>允许增产</color>，且他们的<color=#61d8ffc0>速度+100%</color>。\n\n<color=#61d8ffc0>允许增产</color>：配方的原料喷涂增产剂后，在星际组装厂中生产的产物一定可以获得<color=#61d8ffc0>额外产出</color>效果，无论该配方是否禁止额外产出效果。", "");
		LocalizationModule.RegisterTranslation("特化3介绍内容", "Requirements: At least 3 recipes <color=#30bb30><i>containing</i></color> <color=#30bb30>Antimatter</color> or <color=#30bb30>Deuterium</color> are assigned, and no other types of recipes assigned. \n\nSpecialization effects: All recipes <color=#30bb30><i>containing</i></color> <color=#30bb30>antimatter</color> or <color=#30bb30>deuterium</color> have <color=#61d8ffc0>extra-output-enabled</color> and gain <color=#61d8ffc0>+25% additional output</color>. \n\n<color=#30bb30><i>Containing</i></color> : The recipe requires specifying item as raw material inputs, or one of the products is that item.\n\n<color=#61d8ffc0>Extra-output-enabled</color>: After all raw materials of the recipe are sprayed with proliferators, this recipe will definitely gain the <color=#61d8ffc0>extra product</color> effect in the Interstellar Assembly, regardless of whether the recipe prohibits extra output effects.", "要求：分配了至少3个<color=#30bb30><i>包含</i></color><color=#30bb30>反物质</color>或<color=#30bb30>重氢</color>的配方，且没有不<color=#30bb30><i>包含</i></color>的配方。\n\n特化效果：所有<color=#30bb30><i>包含</i></color><color=#30bb30>反物质</color>或<color=#30bb30>重氢</color>的配方<color=#61d8ffc0>允许增产</color>，并获得<color=#61d8ffc0>+25%额外产出</color>。\n\n<color=#30bb30><i>包含</i></color>：配方需要指定物品作为原材料输入，或者产物之一指定物品。\n\n<color=#61d8ffc0>允许增产</color>：配方的原料喷涂增产剂后，在星际组装厂中生产的产物一定可以获得<color=#61d8ffc0>额外产出</color>效果，无论该配方是否禁止额外产出效果。", "");
		LocalizationModule.RegisterTranslation("特化4介绍内容", "Requirements: At least 5 recipes <color=#30bb30><i>containing</i></color> <color=#30bb30>processor</color>, <color=#30bb30>quantum chip</color> or <color=#30bb30>quantum computer</color> are assigned, and no other types of recipes assigned.\n\nSpecialized effects: All recipes that <color=#30bb30>use processors</color>, <color=#30bb30>quantum chips</color> or <color=#30bb30>quantum computers</color> as inputs have <color=#61d8ffc0>extra-output-enabled</color>, and gain <color=#61d8ffc0>+25% additional output</color>; \n<color=#30bb30>Production processor</color>, <color=#30bb30>Quantum chip</color> and <color=#30bb30>Quantum Computer</color>'s recipe itself will gain <color=#61d8ffc0>+50% additional output</color> instead.\n\n<color=#30bb30><i>Containing</i></color> : The recipe requires specifying item as raw material inputs, or one of the products is that item.\n\n<color=#61d8ffc0>Extra-output-enabled</color>: After all raw materials of the recipe are sprayed with proliferators, this recipe will definitely gain the <color=#61d8ffc0>extra product</color> effect in the Interstellar Assembly, regardless of whether the recipe prohibits extra output effects.", "要求：分配了至少5个<color=#30bb30><i>包含</i></color><color=#30bb30>处理器</color>或<color=#30bb30>量子芯片</color>或<color=#30bb30>量子计算机</color>的配方，且没有不<color=#30bb30><i>包含</i></color>的配方\n\n特化效果：所有<color=#30bb30>使用处理器</color>、<color=#30bb30>量子芯片</color>、<color=#30bb30>量子计算机</color>作为输入的配方<color=#61d8ffc0>允许增产</color>，并获得<color=#61d8ffc0>+25%额外产出</color>；\n<color=#30bb30>生产处理器</color>、<color=#30bb30>量子芯片</color>、<color=#30bb30>量子计算机</color>的配方则转而<color=#61d8ffc0>+50%额外产出</color>。\n\n<color=#30bb30><i>包含</i></color>：配方需要指定物品作为原材料输入，或者产物之一指定物品。\n\n<color=#61d8ffc0>允许增产</color>：配方的原料喷涂增产剂后，在星际组装厂中生产的产物一定可以获得<color=#61d8ffc0>额外产出</color>效果，无论该配方是否禁止额外产出效果。", "");
		LocalizationModule.RegisterTranslation("特化5介绍内容", "Requirements: At least 5 recipes that produce <color=#30bb30>combat drones</color>, <color=#30bb30>warships</color>, <color=#30bb30>ammo</color> or <color=#30bb30>defense facilities</color> are assigned, and no other types of recipes assigned.\n\nSpecialized effects: All recipes of <color=#30bb30>attack drones</color>, <color=#30bb30>warships</color> and <color=#30bb30>defense facilities</color> have <color=#61d8ffc0>extra-output-enabled</color> and gain <color=#61d8ffc0>+50% additional output</color>; the recipes of <color=#30bb30>ammo</color> gain <color=#61d8ffc0>+100% additional output</color> instead.\n\n<color=#61d8ffc0>Extra-output-enabled</color>: After all raw materials of the recipe are sprayed with proliferators, this recipe will definitely gain the <color=#61d8ffc0>extra product</color> effect in the Interstellar Assembly, regardless of whether the recipe prohibits extra output effects.", "要求：分配了至少5个<color=#30bb30>攻击型无人机</color>、<color=#30bb30>战舰</color>、<color=#30bb30>弹药</color>或<color=#30bb30>防御设施</color>的配方，且无其他类型的配方。\n\n特化效果：各类<color=#30bb30>攻击型无人机</color>、<color=#30bb30>战舰</color>和<color=#30bb30>防御设施</color>的配方<color=#61d8ffc0>允许增产</color>，并获得<color=#61d8ffc0>+50%额外产出</color>；<color=#30bb30>弹药</color>的配方则转而获得<color=#61d8ffc0>+100%额外产出</color>。\n\n<color=#61d8ffc0>允许增产</color>：配方的原料喷涂增产剂后，在星际组装厂中生产的产物一定可以获得<color=#61d8ffc0>额外产出</color>效果，无论该配方是否禁止额外产出效果。", "");
		LocalizationModule.RegisterTranslation("特化已激活", "Specialization Activated", "特化已激活", "");
		LocalizationModule.RegisterTranslation("特化即将被取代", "Specialization is about to be replaced", "特化即将被取代", "");
		LocalizationModule.RegisterTranslation("特化进程", "Specialize in progress {0}%", "特化进程 {0}%", "");
		LocalizationModule.RegisterTranslation("特化进程消退中", "Progress fading {0}%", "特化进程消退中 {0}%", "");
		LocalizationModule.RegisterTranslation("等待其他特化进程消退", "Stand by", "等待进程开始", "");
		LocalizationModule.RegisterTranslation("特化条件未满足", "Requirements not satisfied", "特化条件未满足", "");
		LocalizationModule.RegisterTranslation("应用到全部", "Apply to the whole planet", "应用到整个行星", "");
		LocalizationModule.RegisterTranslation("成功应用数量提示", "Successfully applied to {0} buildings.", "成功应用到{0}个建筑。", "");
		LocalizationModule.RegisterTranslation("mms自动喷涂", "Auto Spray", "自动喷涂", "");
		LocalizationModule.RegisterTranslation("玩家自行禁用了巨构警告", "Can't set megastructure type because you've disabled this megastructure type in config file.", "无法设置巨构类型，因为玩家在config文件中禁用了此巨构。", "");
		LocalizationModule.RegisterTranslation("组装厂速度规范化1标题", "Normalize to final speed (based on current state)", "规范化为最终速度(按当前状态)", "");
		LocalizationModule.RegisterTranslation("组装厂速度规范化1描述", "Calculate and modify the expected speed so that the final production speed, <color=#FD965ECC>considering the current specialization and proliferator effect</color>, is equal to the original input expected speed.\n<color=#FD965ECC>Note: This effect is only modified once when the button is clicked.</color> If there are changes in the specialization or proliferator effect later, it will not be recalculated and modified.", "计算并修改目标生产速度，使得考虑了<color=#FD965ECC>当前的特化和增产效果</color>后的生产速度等于原先输入的目标生产速度。\n<color=#FD965ECC>注意：此效果只在点击按钮时修改一次</color>，如果后续的特化或增产效果发生改变，不会自动重新计算并修改。", "");
		LocalizationModule.RegisterTranslation("组装厂速度规范化2标题", "Normalize to final speed (based on fully proliferated state)", "规范化为最终速度(按满级喷涂计)", "");
		LocalizationModule.RegisterTranslation("组装厂速度规范化2描述", "Calculate and modify the expected speed so that the final production speed, <color=#FD965ECC>considering the current specialization and full-level proliferator effect</color>, is equal to the original input expected speed.\n<color=#FD965ECC>Note: This effect is only modified once when the button is clicked.</color> If there are changes in the specialization or proliferator effect later, it will not be recalculated and modified.", "计算并修改目标生产速度，使得考虑了<color=#FD965ECC>当前的特化和满级增产效果</color>后的生产速度等于原先输入的目标生产速度。\n<color=#FD965ECC>注意：此效果只在点击按钮时修改一次</color>，如果后续的特化或增产效果发生改变，不会自动重新计算并修改。", "");
		LocalizationModule.RegisterTranslation("PF巨构总览", "MoreMegaStructure", "更多巨构", "");
		LocalizationModule.RegisterTranslation("PF主要逻辑", "MainLogic (MMS)", "主要逻辑（巨构）", "");
		LocalizationModule.RegisterTranslation("PF接收器", "Receivers", "接收器", "");
		LocalizationModule.RegisterTranslation("PF星际组装厂", "Interstellar Assembly", "星际组装厂", "");
		LocalizationModule.RegisterTranslation("PF货物生产", "Produce", "生产", "");
		LocalizationModule.RegisterTranslation("PF货物输送", "Cargo Transport", "货物输送", "");
		LocalizationModule.RegisterTranslation("PF恒星炮", "Star Cannon", "恒星炮", "");
		LocalizationModule.RegisterTranslation("PF攻击逻辑", "Attack Logic", "攻击逻辑", "");
		LocalizationModule.RegisterTranslation("PF寻敌逻辑", "Enemy Search", "寻敌逻辑", "");
		LocalizationModule.RegisterTranslation("PF绘制调用", "Render Call", "渲染调用", "");
		LocalizationModule.RegisterTranslation("PF折跃场", "Warp Array", "折跃场", "");
		LocalizationModule.RegisterTranslation("PF巨构数据统计", "Produce Statistics", "生产数据统计", "");
		LocalizationModule.RegisterTranslation("PF其他补丁", "Other Patch", "其他补丁", "");
	}

	internal static void ChangeReceiverRelatedStringProto()
	{
		StringProto stringProto = new StringProto();
		stringProto.Name = "光子生成";
		stringProto.ZHCN = "物质合成";
		stringProto.ENUS = "Substance Generation";
		stringProto.RegisterTranslation();
		StringProto stringProto2 = new StringProto();
		stringProto2.Name = "光子生成描述";
		stringProto2.ZHCN = "在物质合成模式下，接收站将允许接收巨构建筑的输出，并将其转换为对应物质。";
		stringProto2.ENUS = "In Substance Generation mode, the receiver will receive product delivered by the megastructure and convert it into the corresponding item.";
		stringProto2.RegisterTranslation();
		StringProto stringProto3 = new StringProto();
		stringProto3.Name = "戴森球统计页签";
		stringProto3.ZHCN = "巨构建筑";
		stringProto3.ENUS = "Megastructure";
		stringProto3.RegisterTranslation();
		StringProto stringProto4 = new StringProto();
		stringProto4.Name = "戴森球类";
		stringProto4.ZHCN = "巨构建筑 (8)";
		stringProto4.ENUS = "Megastructure (8)";
		stringProto4.RegisterTranslation();
		StringProto stringProto5 = new StringProto();
		stringProto5.Name = "戴森球面板提示";
		stringProto5.ZHCN = "打开巨构建筑面板，制定巨构建筑的建造规划。";
		stringProto5.ENUS = "Turn on the Megastructure editor, and make a build plan.";
		stringProto5.RegisterTranslation();
		StringProto stringProto6 = new StringProto();
		stringProto6.Name = "戴森球面板";
		stringProto6.ZHCN = "巨构建筑 (Y)";
		stringProto6.ENUS = "Megastructure (Y)";
		stringProto6.RegisterTranslation();
		StringProto stringProto7 = new StringProto();
		stringProto7.Name = "修建节点标题";
		stringProto7.ZHCN = "巨构节点";
		stringProto7.ENUS = "Megastructure Node";
		stringProto7.RegisterTranslation();
		StringProto stringProto8 = new StringProto();
		stringProto8.Name = "修建节点描述";
		stringProto8.ZHCN = "规划修建巨构建筑节点，点击该按钮可以选择节点的样式。";
		stringProto8.ENUS = "Plan and build the Megastructure Node, click this button to choose the node style.";
		stringProto8.RegisterTranslation();
		StringProto stringProto9 = new StringProto();
		stringProto9.Name = "修建壳面标题";
		stringProto9.ZHCN = "巨构壳面";
		stringProto9.ENUS = "Megastructure Shell";
		stringProto9.RegisterTranslation();
		StringProto stringProto10 = new StringProto();
		stringProto10.Name = "修建壳面描述";
		stringProto10.ZHCN = "若要规划一个巨构壳面，需要将相应的壳面用节点和框架规划成一个闭合的多边形。\n点击该按钮可以选择巨构壳面的样式进行修建规划。";
		stringProto10.ENUS = "In order to Plan a Megastructure Shell, it is necessary to plan the corresponding shell as a closed polygon with nodes and frames.\nClick this button to choose the Megastructure Shell style.";
		stringProto10.RegisterTranslation();
		StringProto stringProto11 = new StringProto();
		stringProto11.Name = "戴森球节点号";
		stringProto11.ZHCN = "巨构节点 # {0}-{1}";
		stringProto11.ENUS = "Structure Node # {0}-{1}";
		stringProto11.RegisterTranslation();
		StringProto stringProto12 = new StringProto();
		stringProto12.Name = "戴森球框架号";
		stringProto12.ZHCN = "巨构框架 # {0}-{1}";
		stringProto12.ENUS = "Structure Frame # {0}-{1}";
		stringProto12.RegisterTranslation();
		StringProto stringProto13 = new StringProto();
		stringProto13.Name = "戴森球壳面号";
		stringProto13.ZHCN = "巨构壳面 # {0}-{1}";
		stringProto13.ENUS = "Structure Shell # {0}-{1}";
		stringProto13.RegisterTranslation();
		StringProto stringProto14 = new StringProto();
		stringProto14.Name = "射线接收站";
		stringProto14.ZHCN = "射线重构站";
		stringProto14.ENUS = "Ray reconstructor";
		stringProto14.RegisterTranslation();
		StringProto stringProto15 = new StringProto();
		stringProto15.Name = "射线接收站描述";
		stringProto15.ZHCN = "接收巨构上传输回来的高能射线或粒子流，将其能量输出到电网或重构为对应物质。";
		stringProto15.ENUS = "Receive high-energy rays or particle streams transmitted back from the mega structure, output their energy to the power grid or reconstruct them into corresponding substances.";
		stringProto15.RegisterTranslation();
	}
}
