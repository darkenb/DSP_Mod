using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using HarmonyLib;
using UnityEngine;

namespace MoreMegaStructure;

public class UIStatisticsPatcher
{
	public const int starAssemblyRepresentativeItemId = 9493;

	public static bool enabled = true;

	public static bool forceBanned = false;

	public static long time0 = 0L;

	public static long time1 = 0L;

	public static long time2 = 0L;

	public static long time3 = 0L;

	public static long time4 = 0L;

	public static long time5 = 0L;

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIStatisticsWindow), "RefreshAstroBox")]
	public static bool RefreshAstroBoxPostPatch(ref UIStatisticsWindow __instance)
	{
		if (__instance == null)
		{
			return true;
		}
		MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
		MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.Statistics);
		UIStatisticsWindow uIStatisticsWindow = __instance;
		if (uIStatisticsWindow.isProductionTab)
		{
			List<string> items = uIStatisticsWindow.astroBox.Items;
			List<int> itemsData = uIStatisticsWindow.astroBox.ItemsData;
			items.Clear();
			itemsData.Clear();
			items.Add("统计全星系".Translate());
			itemsData.Add(-1);
			if (!uIStatisticsWindow.isDysonTab && uIStatisticsWindow.gameData.localPlanet != null)
			{
				items.Add("统计当前星球".Translate());
				itemsData.Add(0);
			}
			if (uIStatisticsWindow.isKillTab)
			{
				items.Add("统计玩家".Translate());
				itemsData.Add(-2);
			}
			int factoryCount = uIStatisticsWindow.gameData.factoryCount;
			for (int i = 0; i < factoryCount; i++)
			{
				int planetId = uIStatisticsWindow.gameData.factories[i].planetId;
				int num = planetId / 100;
				int num2 = planetId % 100;
				bool flag = false;
				bool flag2 = false;
				int j;
				for (j = 0; j < itemsData.Count; j++)
				{
					if (flag)
					{
						int num3 = itemsData[j] % 100;
						if (num3 >= num2 || num3 == 0)
						{
							if (num3 == num2)
							{
								flag2 = true;
							}
							break;
						}
					}
					else
					{
						flag = num == itemsData[j] / 100;
					}
				}
				if (flag2)
				{
					continue;
				}
				PlanetData planet = uIStatisticsWindow.gameData.factories[i].planet;
				string displayName = planet.displayName;
				if (flag)
				{
					if (!uIStatisticsWindow.isDysonTab)
					{
						itemsData.Insert(j, planetId);
						items.Insert(j, displayName);
					}
					continue;
				}
				string item = planet.star.displayName + "空格行星系".Translate();
				itemsData.Add(num * 100);
				items.Add(item);
				if (!uIStatisticsWindow.isDysonTab)
				{
					itemsData.Add(planetId);
					items.Add(displayName);
				}
			}
			InjectMegaAstroEntriesIntoList(items, itemsData, 4);
			uIStatisticsWindow.ValueToAstroBox();
			MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.Statistics);
			MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
			return false;
		}
		MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.Statistics);
		MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
		return true;
	}

	public static void InjectMegaAstroEntriesIntoList(List<string> items, List<int> itemsData, int megaType)
	{
		int num = -1;
		for (int i = 0; i < itemsData.Count; i++)
		{
			int num2 = itemsData[i] / 100;
			if (num != num2 && num != -1 && num <= 1200 && num > 0 && MoreMegaStructure.StarMegaStructureType[num - 1] == megaType)
			{
				itemsData.Insert(i, num * 100 + GameMain.galaxy.StarById(num).planetCount + 1);
				items.Insert(i, MMSPlanetById(num * 100 + GameMain.galaxy.StarById(num).planetCount + 1).displayName);
				i++;
			}
			if (i == itemsData.Count - 1)
			{
				num = num2;
				if (num > 0 && num <= 1200 && MoreMegaStructure.StarMegaStructureType[num - 1] == megaType)
				{
					itemsData.Add(num * 100 + GameMain.galaxy.StarById(num).planetCount + 1);
					items.Add(MMSPlanetById(num * 100 + GameMain.galaxy.StarById(num).planetCount + 1).displayName);
					break;
				}
			}
			num = num2;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIStatisticsWindow), "RefreshAstroBox")]
	public static void RefreshAstroBoxResearchPostPatch(ref UIStatisticsWindow __instance)
	{
		if (!enabled || __instance == null || !__instance.isResearchTab || __instance.astroBox == null)
		{
			return;
		}
		List<string> items = __instance.astroBox.Items;
		List<int> itemsData = __instance.astroBox.ItemsData;
		if (items == null || itemsData == null)
		{
			return;
		}
		try
		{
			InjectMegaAstroEntriesIntoList(items, itemsData, 2);
			__instance.ValueToAstroBox();
		}
		catch (Exception)
		{
		}
	}

	public static void RearrangeStatisticLists()
	{
		if (!enabled)
		{
			return;
		}
		if (GameMain.data.statistics.production.factoryStatPool.Length <= GameMain.data.factories.Length)
		{
			FactoryProductionStat[] factoryStatPool = GameMain.data.statistics.production.factoryStatPool;
			GameMain.data.statistics.production.factoryStatPool = new FactoryProductionStat[GameMain.data.factories.Length + GameMain.galaxy.starCount];
			int num = 0;
			for (num = 0; num < factoryStatPool.Length; num++)
			{
				GameMain.data.statistics.production.factoryStatPool[num] = factoryStatPool[num];
			}
			for (; num < GameMain.data.statistics.production.factoryStatPool.Length; num++)
			{
				GameMain.data.statistics.production.factoryStatPool[num] = new FactoryProductionStat();
				GameMain.data.statistics.production.factoryStatPool[num].Init();
			}
			return;
		}
		for (int i = GameMain.data.factories.Length; i < GameMain.data.statistics.production.factoryStatPool.Length; i++)
		{
			if (GameMain.data.statistics.production.factoryStatPool[i] == null)
			{
				GameMain.data.statistics.production.factoryStatPool[i] = new FactoryProductionStat();
				GameMain.data.statistics.production.factoryStatPool[i].Init();
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(TrafficStatistics), "Init")]
	public static void TrafficStatisticsInitPostPatch(ref TrafficStatistics __instance)
	{
		__instance.factoryTrafficPool = new AstroTrafficStat[__instance.gameData.factories.Length + GameMain.galaxy.starCount];
	}

	public static PlanetData MMSPlanetById(int planetId)
	{
		GalaxyData galaxy = GameMain.galaxy;
		PlanetData planetData = GameMain.galaxy.PlanetById(planetId);
		if (planetData == null)
		{
			try
			{
				int num = planetId / 100 - 1;
				if (num < 0 || num >= galaxy.stars.Length)
				{
					return null;
				}
				int num2 = planetId % 100 - 1;
				if (num2 >= galaxy.stars[num].planets.Length)
				{
					if (galaxy.stars[num] == null)
					{
						return null;
					}
					if (num2 >= galaxy.stars[num].planets.Length)
					{
						planetData = new PlanetData();
						planetData.factory = null;
						for (int i = num * 100 + 1; i < planetId; i++)
						{
							int num3 = i - num * 100 - 1;
							if (num3 >= 0 && num3 < galaxy.stars[num].planets.Length)
							{
								PlanetData planetData2 = galaxy.stars[num].planets[num3];
								if (planetData2 != null && planetData2.factory != null)
								{
									planetData.factory = planetData2.factory;
									break;
								}
							}
						}
						if (planetData.factory == null)
						{
							for (int j = 0; j < GameMain.data.factories.Length && j < GameMain.data.factoryCount; j++)
							{
								if (GameMain.data.factories[j] != null)
								{
									planetData.factory = GameMain.data.factories[j];
								}
							}
						}
						planetData.factoryIndex = GameMain.data.factories.Length + GameMain.galaxy.starCount - num - 1;
						planetData.overrideName = Utils.MegaNameByType(MoreMegaStructure.StarMegaStructureType[num]) + " " + GameMain.galaxy.StarById(num + 1).displayName;
						return planetData;
					}
				}
			}
			catch (Exception)
			{
			}
		}
		return planetData;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIStatisticsWindow), "DetermineProductEntryList")]
	public static bool ComputeDisplayEntriesPrePatch(ref UIStatisticsWindow __instance)
	{
		MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
		MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.Statistics);
		__instance.productEntryList.PrepareDisplayEntries(__instance.lastListCursor);
		Array.Clear(__instance.statGroup, 0, __instance.statGroupCursor);
		__instance.statGroupCursor = 0;
		if (__instance.astroFilter == -1)
		{
			int factoryCount = __instance.gameData.factoryCount;
			for (int i = 0; i < factoryCount; i++)
			{
				__instance.AddProductStatGroup(i);
			}
			for (int j = GameMain.data.factories.Length; j < GameMain.data.factories.Length + GameMain.galaxy.starCount; j++)
			{
				int num = GameMain.data.factories.Length + GameMain.galaxy.starCount - j - 1;
				if (num < 1200 && (MoreMegaStructure.StarMegaStructureType[num] == 4 || MoreMegaStructure.StarMegaStructureType[num] == 2))
				{
					__instance.AddProductStatGroup(j);
				}
			}
		}
		else if (__instance.gameData.localPlanet != null && __instance.astroFilter == 0)
		{
			__instance.AddProductStatGroup(__instance.gameData.localPlanet.factoryIndex);
			__instance.AddTrafficFactoryStatGroup(__instance.gameData.localPlanet.factoryIndex);
		}
		else if (__instance.astroFilter % 100 == 0)
		{
			int num2 = __instance.astroFilter / 100;
			StarData starData = ((__instance.astroFilter != 0) ? __instance.gameData.galaxy.StarById(num2) : __instance.gameData.localStar);
			if (starData != null)
			{
				for (int k = 0; k < starData.planetCount; k++)
				{
					if (starData.planets[k].factory != null)
					{
						__instance.AddProductStatGroup(starData.planets[k].factoryIndex);
					}
				}
				__instance.AddProductStatGroup(GameMain.data.factories.Length + GameMain.galaxy.starCount - num2);
				__instance.AddTrafficStarStatGroup(num2);
			}
			else
			{
				int factoryCount2 = __instance.gameData.factoryCount;
				for (int l = 0; l < factoryCount2; l++)
				{
					__instance.AddProductStatGroup(l);
				}
				for (int m = GameMain.data.factories.Length; m < GameMain.data.factories.Length + GameMain.galaxy.starCount; m++)
				{
					int num3 = GameMain.data.factories.Length + GameMain.galaxy.starCount - m - 1;
					if (num3 < 1200 && (MoreMegaStructure.StarMegaStructureType[num3] == 4 || MoreMegaStructure.StarMegaStructureType[num3] == 2))
					{
						__instance.AddProductStatGroup(m);
					}
				}
				int starCount = __instance.gameData.galaxy.starCount;
				for (int n = 1; n <= starCount; n++)
				{
					__instance.AddTrafficStarStatGroup(n);
				}
			}
		}
		else
		{
			int factoryIndex = MMSPlanetById(__instance.astroFilter).factoryIndex;
			__instance.AddProductStatGroup(factoryIndex);
			__instance.AddTrafficFactoryStatGroup(factoryIndex);
		}
		int num4 = __instance.timeLevel + 1;
		int num5 = num4 + 7;
		int num6 = num4;
		int num7 = num5;
		bool flag = __instance.isProductionTab || __instance.isDysonTab;
		for (int num8 = 0; num8 < __instance.statGroupCursor; num8++)
		{
			UIStatisticsWindow.UIStatGroup uIStatGroup = __instance.statGroup[num8];
			ProductStat[] productPool = uIStatGroup.productPool;
			PowerStat[] powerPool = uIStatGroup.powerPool;
			TrafficStat[] trafficPool = uIStatGroup.trafficPool;
			int num9 = ((!flag) ? 1 : (__instance.isDysonTab ? 4 : uIStatGroup.poolCursor));
			int[] itemIndices = uIStatGroup.itemIndices;
			for (int num10 = 1; num10 < num9; num10++)
			{
				if (__instance.isDysonTab)
				{
					int num11 = ((num10 >= 3) ? 11903 : ((num10 == 1) ? 11901 : 11902));
					int num12 = itemIndices[num11];
					if (num12 > 0)
					{
						long[] total = productPool[num12].total;
						__instance.productEntryList.Add(num11, total[num4], total[num5]);
					}
					else
					{
						__instance.productEntryList.Add(num11);
					}
					continue;
				}
				if (productPool != null)
				{
					ProductStat productStat = productPool[num10];
					int itemId = productStat.itemId;
					long[] total2 = productStat.total;
					__instance.productEntryList.Add(itemId, total2[num4], total2[num5]);
				}
				if (trafficPool != null)
				{
					TrafficStat trafficStat = trafficPool[num10];
					int itemId2 = trafficStat.itemId;
					long[] total3 = trafficStat.total;
					__instance.productEntryList.AddImportAndExport(itemId2, total3[num6], total3[num7]);
				}
			}
			if (powerPool == null)
			{
				continue;
			}
			if (__instance.isPowerTab)
			{
				if (uIStatGroup.factoryIndex < GameMain.data.factories.Length)
				{
					__instance.ComputePowerTab(powerPool, uIStatGroup.energyConsumption, uIStatGroup.factoryIndex);
				}
			}
			else if (__instance.isResearchTab)
			{
				__instance.ComputeResearchTab(powerPool, num4);
			}
		}
		__instance.lastListCursor = __instance.productEntryList.entryDatasCursor;
		if (__instance.isProductionTab)
		{
			__instance.productEntryList.SetEntriesFavorite(__instance.productionStat.favoriteIds);
			if (__instance.rawMaterialFilter > 0 || __instance.endProductFilter > 0)
			{
				bool flag2 = __instance.rawMaterialFilter == 0;
				bool flag3 = __instance.endProductFilter == 0;
				UIProductEntryData[] entryDatas = __instance.productEntryList.entryDatas;
				for (int num13 = 0; num13 < entryDatas.Length; num13++)
				{
					if (__instance.rawMaterialFilter == entryDatas[num13].itemId)
					{
						flag2 = true;
					}
					if (__instance.endProductFilter == entryDatas[num13].itemId)
					{
						flag3 = true;
					}
					if (flag2 && flag3)
					{
						break;
					}
				}
				if (!flag2)
				{
					__instance.rawMaterialFilter = 0;
					__instance.ComputeDetailNextTick();
				}
				if (!flag3)
				{
					__instance.endProductFilter = 0;
					__instance.ComputeDetailNextTick();
				}
			}
			__instance.productEntryList.FilterEntries(__instance.favoriteMask, __instance.rawMaterialFilter, __instance.endProductFilter, ref __instance.nameFilter);
			int max = __instance.productEntryList.entryDatasCursor - 1;
			if (__instance.sortMethod == 0)
			{
				__instance.productEntryList.QuickSortByItemIndex(__instance.productEntryList.entryDatas, 0, max);
			}
			else if (__instance.sortMethod == 1)
			{
				__instance.productEntryList.QuickSortByProductionDesc(__instance.productEntryList.entryDatas, 0, max);
			}
			else
			{
				__instance.productEntryList.QuickSortByProductionAsc(__instance.productEntryList.entryDatas, 0, max);
			}
		}
		__instance.productEntryList.RefreshDatasIndices(__instance.lastListCursor);
		MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.Statistics);
		MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
		return false;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(ProductionStatistics), "PrepareTick")]
	public static void ProductionStatisticsPrepareTickPostPatch(ref ProductionStatistics __instance)
	{
		MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
		MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.Statistics);
		int num = __instance.gameData.factories.Length + GameMain.galaxy.starCount;
		num = ((num < __instance.factoryStatPool.Length) ? num : __instance.factoryStatPool.Length);
		int num2 = GameMain.data.factories.Length + GameMain.galaxy.starCount - 1;
		for (int i = __instance.gameData.factories.Length; i < num; i++)
		{
			int num3 = num2 - i;
			if (MoreMegaStructure.StarMegaStructureType.Length > num3 && num3 >= 0 && (MoreMegaStructure.StarMegaStructureType[num3] == 4 || MoreMegaStructure.StarMegaStructureType[num3] == 2))
			{
				__instance.factoryStatPool[i].PrepareTick();
			}
		}
		MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.Statistics);
		MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(ProductionStatistics), "GameTick")]
	public static void ProductionStatisticsGameTickPostPatch(ref ProductionStatistics __instance, long time)
	{
		MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
		MMSCPU.BeginSampleSafe(ECpuWorkEntryExtended.Statistics);
		bool flag = true;
		int num = Math.Min(__instance.gameData.factories.Length + GameMain.galaxy.starCount, __instance.factoryStatPool.Length);
		int num2 = GameMain.data.factories.Length + GameMain.galaxy.starCount - 1;
		for (int i = __instance.gameData.factories.Length; i < num; i++)
		{
			int num3 = num2 - i;
			if (MoreMegaStructure.StarMegaStructureType.Length <= num3 || num3 < 0 || (MoreMegaStructure.StarMegaStructureType[num3] != 4 && MoreMegaStructure.StarMegaStructureType[num3] != 2))
			{
				continue;
			}
			__instance.factoryStatPool[i].GameTick(time);
			if (__instance.factoryStatPool[i].itemChanged && flag)
			{
				try
				{
					UIRoot.instance.uiGame.statWindow.OnItemChange();
				}
				catch (Exception)
				{
				}
				flag = false;
			}
		}
		MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.Statistics);
		MMSCPU.EndSampleSafe(ECpuWorkEntryExtended.MoreMegaStructure);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(ProductionStatistics), "PrepareTick_Parallel")]
	public static void ProductionStatisticsPrepareTickParallelPostPatch(ref ProductionStatistics __instance, int threadOrdinal)
	{
		if (threadOrdinal != 0)
		{
			return;
		}
		int num = Math.Min(__instance.gameData.factories.Length + GameMain.galaxy.starCount, __instance.factoryStatPool.Length);
		int num2 = __instance.gameData.factories.Length + GameMain.galaxy.starCount - 1;
		for (int i = __instance.gameData.factories.Length; i < num; i++)
		{
			int num3 = num2 - i;
			if (MoreMegaStructure.StarMegaStructureType.Length > num3 && num3 >= 0 && (MoreMegaStructure.StarMegaStructureType[num3] == 4 || MoreMegaStructure.StarMegaStructureType[num3] == 2))
			{
				__instance.factoryStatPool[i].PrepareTick();
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(ProductionStatistics), "GameTick_Parallel")]
	public static void ProductionStatisticsGameTickParallelPostPatch(ref ProductionStatistics __instance, long time, int threadOrdinal)
	{
		if (threadOrdinal != 0)
		{
			return;
		}
		int num = Math.Min(__instance.gameData.factories.Length + GameMain.galaxy.starCount, __instance.factoryStatPool.Length);
		int num2 = __instance.gameData.factories.Length + GameMain.galaxy.starCount - 1;
		for (int i = __instance.gameData.factories.Length; i < num; i++)
		{
			int num3 = num2 - i;
			if (MoreMegaStructure.StarMegaStructureType.Length > num3 && num3 >= 0 && (MoreMegaStructure.StarMegaStructureType[num3] == 4 || MoreMegaStructure.StarMegaStructureType[num3] == 2))
			{
				__instance.factoryStatPool[i].GameTick(time);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(ProductionStatistics), "RefreshItemsStorageCount")]
	public static void RefreshItemsStorageCountPostPatch(ref ProductionStatistics __instance, int astroFilter)
	{
		RefreshAllIAStorage();
	}

	public static void RefreshAllIAStorage()
	{
		if (GameMain.galaxy == null)
		{
			return;
		}
		int num = Math.Min(GameMain.galaxy.starCount, MoreMegaStructure.StarMegaStructureType.Length);
		for (int i = 0; i < num; i++)
		{
			if (MoreMegaStructure.StarMegaStructureType[i] == 4)
			{
				FillIAStorage(i);
			}
		}
	}

	public static void FillIAStorage(int starIndex)
	{
		if (starIndex < 0 || starIndex >= MoreMegaStructure.StarMegaStructureType.Length || MoreMegaStructure.StarMegaStructureType[starIndex] != 4 || !StarAssembly.productStorage.ContainsKey(starIndex) || GameMain.data == null || GameMain.data.statistics == null || GameMain.data.statistics.production == null)
		{
			return;
		}
		FactoryProductionStat[] factoryStatPool = GameMain.data.statistics.production.factoryStatPool;
		if (factoryStatPool == null)
		{
			return;
		}
		int num = StarIndex2FactoryIndex(starIndex);
		if (num < GameMain.data.factories.Length || num >= factoryStatPool.Length)
		{
			return;
		}
		FactoryProductionStat factoryProductionStat = factoryStatPool[num];
		if (factoryProductionStat == null)
		{
			return;
		}
		factoryProductionStat.ResetStorageCount();
		factoryProductionStat.ResetDetailedStorageCount();
		foreach (KeyValuePair<int, int> item in StarAssembly.productStorage[starIndex])
		{
			if (item.Value > 0)
			{
				factoryProductionStat.AddStorageCount(item.Key, item.Value);
				factoryProductionStat.AddDetailedStorageCount(item.Key, EDetailedStorageCountType.Other, item.Value);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIStorageCountTip), "Refresh")]
	public static void UIStorageCountTipRefreshPostPatch(ref UIStorageCountTip __instance)
	{
		if (!enabled || __instance == null)
		{
			return;
		}
		GameData data = GameMain.data;
		if (data == null || data.statistics == null || data.statistics.production == null || __instance.entryDatas == null || __instance.entries == null || __instance.entries.Length == 0)
		{
			return;
		}
		FactoryProductionStat[] factoryStatPool = data.statistics.production.factoryStatPool;
		if (factoryStatPool == null)
		{
			return;
		}
		int astroFilter = __instance.astroFilter;
		int itemId = __instance.itemId;
		long num = 0L;
		int num2 = Math.Min(data.galaxy.starCount, MoreMegaStructure.StarMegaStructureType.Length);
		for (int i = 0; i < num2; i++)
		{
			if (MoreMegaStructure.StarMegaStructureType[i] != 4 || (astroFilter != 0 && !((astroFilter % 100 != 0) ? (IsStarAssemblyAstroFilter(astroFilter) && i == astroFilter / 100 - 1) : (i == astroFilter / 100 - 1))))
			{
				continue;
			}
			int num3 = StarIndex2FactoryIndex(i);
			if (num3 < data.factories.Length || num3 >= factoryStatPool.Length)
			{
				continue;
			}
			FactoryProductionStat factoryProductionStat = factoryStatPool[num3];
			if (factoryProductionStat == null || factoryProductionStat.productIndices == null || factoryProductionStat.productPool == null || itemId < 0 || itemId >= factoryProductionStat.productIndices.Length)
			{
				continue;
			}
			int num4 = factoryProductionStat.productIndices[itemId];
			if (num4 <= 0 || num4 >= factoryProductionStat.productPool.Length)
			{
				continue;
			}
			long[] detailedStorageCounts = factoryProductionStat.productPool[num4].detailedStorageCounts;
			if (detailedStorageCounts == null)
			{
				continue;
			}
			for (int j = 0; j < __instance.entryDatas.Length && j < detailedStorageCounts.Length; j++)
			{
				if (detailedStorageCounts[j] != 0)
				{
					__instance.entryDatas[j] += detailedStorageCounts[j];
					num += detailedStorageCounts[j];
				}
			}
		}
		if (num == 0)
		{
			return;
		}
		GameHistoryData history = data.history;
		long num5 = 0L;
		float posY = __instance.entries[0].rectTrans.anchoredPosition.y;
		for (int k = 0; k < __instance.entries.Length; k++)
		{
			if ((k == 4 && __instance.entryDatas[k] == 0L) || (k == 1 && history != null && !history.logisticsSystemUnlocked && __instance.entryDatas[k] == 0))
			{
				__instance.entries[k].gameObject.SetActive(value: false);
				continue;
			}
			__instance.entries[k].Refresh(__instance.entryDatas[k], ref posY);
			num5 += __instance.entryDatas[k];
		}
		__instance.rectTrans.sizeDelta = new Vector2(276f, 0f - posY + 12f);
		__instance.totalCountText.text = num5.ToString("#,##0");
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIStatisticsWindow), "RefreshProductionExtraInfo")]
	public static bool RefreshProductionExtraInfoPrePatch(ref UIStatisticsWindow __instance)
	{
		if (!enabled)
		{
			return true;
		}
		if (__instance == null)
		{
			return true;
		}
		if (!__instance.isProductionTab || __instance.astroFilter < -1)
		{
			return true;
		}
		int astroFilter = __instance.astroFilter;
		if (astroFilter == -1 || astroFilter % 100 == 0)
		{
			try
			{
				RefreshAllIAStorage();
			}
			catch (Exception)
			{
			}
		}
		if (astroFilter != -1 && astroFilter % 100 != 0 && TryGetIAFactoryIndex(astroFilter, out var factoryIndex))
		{
			try
			{
				RefreshIARefSpeedAndStorage(FactoryIndex2StarIndex(factoryIndex));
			}
			catch (Exception)
			{
			}
			return false;
		}
		return true;
	}

	public static FactoryProductionStat GetIAFactoryStat(int starIndex)
	{
		if (starIndex < 0 || starIndex >= MoreMegaStructure.StarMegaStructureType.Length)
		{
			return null;
		}
		if (GameMain.data == null || GameMain.data.statistics == null || GameMain.data.statistics.production == null)
		{
			return null;
		}
		FactoryProductionStat[] factoryStatPool = GameMain.data.statistics.production.factoryStatPool;
		if (factoryStatPool == null)
		{
			return null;
		}
		int num = StarIndex2FactoryIndex(starIndex);
		if (num < GameMain.data.factories.Length || num >= factoryStatPool.Length)
		{
			return null;
		}
		return factoryStatPool[num];
	}

	public static void RefreshIARefSpeedAndStorage(int starIndex)
	{
		if (starIndex < 0 || starIndex >= MoreMegaStructure.StarMegaStructureType.Length || MoreMegaStructure.StarMegaStructureType[starIndex] != 4 || GetIAFactoryStat(starIndex) == null)
		{
			return;
		}
		int num = 0;
		try
		{
			GameHistoryData history = GameMain.data.history;
			int[] array = LDB.items.Select(2313)?.prefabDesc.incItemId;
			if (array != null && history != null)
			{
				for (int i = 0; i < array.Length; i++)
				{
					if (history.ItemUnlocked(array[i]))
					{
						ItemProto itemProto = LDB.items.Select(array[i]);
						if (itemProto != null && itemProto.Ability > num)
						{
							num = itemProto.Ability;
						}
					}
				}
			}
		}
		catch (Exception)
		{
		}
		MMSRefreshItemsCyclicRefSpeedWithFactory(starIndex, num);
		FillIAStorage(starIndex);
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(ProductionStatistics), "Init")]
	public static void ProductionStatisticsInitPostPatch(ref ProductionStatistics __instance)
	{
		if (!enabled || __instance == null || __instance.gameData == null)
		{
			return;
		}
		int num = __instance.gameData.factories.Length;
		int starCount = __instance.gameData.galaxy.starCount;
		if (__instance.factoryStatPool != null && __instance.factoryStatPool.Length > num)
		{
			return;
		}
		FactoryProductionStat[] factoryStatPool = __instance.factoryStatPool;
		__instance.factoryStatPool = new FactoryProductionStat[num + starCount];
		if (factoryStatPool != null)
		{
			for (int i = 0; i < factoryStatPool.Length && i < __instance.factoryStatPool.Length; i++)
			{
				__instance.factoryStatPool[i] = factoryStatPool[i];
			}
		}
		for (int j = num; j < __instance.factoryStatPool.Length; j++)
		{
			if (__instance.factoryStatPool[j] == null)
			{
				__instance.factoryStatPool[j] = new FactoryProductionStat();
				__instance.factoryStatPool[j].Init();
			}
		}
	}

	public static void MMSRefreshItemsCyclicRefSpeedWithFactory(int starIndex, int maxIncLevelByProliferatorUnlocked)
	{
		int num = GameMain.data.factories.Length + GameMain.galaxy.starCount - starIndex - 1;
		FactoryProductionStat factoryProductionStat = GameMain.data.statistics.production.factoryStatPool[num];
		factoryProductionStat.ResetRefSpeed();
		int count = StarAssembly.recipeIds[starIndex].Count;
		for (int i = 0; i < count; i++)
		{
			double redundantEnergy;
			if (i == 0)
			{
				GameMain.data.statistics.production.factoryStatPool[num].AddRefProductSpeed(9500, (float)StarAssembly.GetConsumeProduceSpeedRatio(starIndex, 0, out redundantEnergy) * 3600f);
			}
			else if (StarAssembly.recipeIds[starIndex][i] > 0)
			{
				float num2 = (float)(StarAssembly.GetConsumeProduceSpeedRatio(starIndex, i, out redundantEnergy) * 3600.0);
				int count2 = StarAssembly.items[starIndex][i].Count;
				for (int j = 0; j < count2; j++)
				{
					int itemId = StarAssembly.items[starIndex][i][j];
					GameMain.data.statistics.production.factoryStatPool[num].AddRefConsumeSpeed(itemId, num2 * (float)StarAssembly.itemCounts[starIndex][i][j]);
				}
				int count3 = StarAssembly.products[starIndex][i].Count;
				float num3 = num2 * (1f + StarAssembly.GetFullIncMilli(starIndex, i, maxIncLevelByProliferatorUnlocked));
				for (int k = 0; k < count3; k++)
				{
					int itemId2 = StarAssembly.products[starIndex][i][k];
					GameMain.data.statistics.production.factoryStatPool[num].AddRefProductSpeed(itemId2, num3 * (float)StarAssembly.productCounts[starIndex][i][k]);
				}
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIProductEntry), "UpdateExtraProductTexts")]
	public static bool UpdateExtraProductTextsPostPatch(ref UIProductEntry __instance)
	{
		if (!__instance.productionStatWindow.isProductionTab)
		{
			return false;
		}
		float num = 0f;
		float num2 = 0f;
		long num3 = 0L;
		long num4 = 0L;
		long num5 = 0L;
		long num6 = 0L;
		int itemId = __instance.entryData.itemId;
		int astroFilter = __instance.productionStatWindow.astroFilter;
		FactoryProductionStat[] factoryStatPool = __instance.productionStatWindow.productionStat.factoryStatPool;
		if (astroFilter == -1)
		{
			int factoryCount = __instance.gameData.factoryCount;
			for (int i = 0; i < factoryCount; i++)
			{
				int num7 = factoryStatPool[i].productIndices[itemId];
				if (num7 > 0)
				{
					num += factoryStatPool[i].productPool[num7].refProductSpeed;
					num2 += factoryStatPool[i].productPool[num7].refConsumeSpeed;
					num3 += factoryStatPool[i].productPool[num7].storageCount;
					num4 += factoryStatPool[i].productPool[num7].trashCount;
					num5 += factoryStatPool[i].productPool[num7].importStorageCount;
					num6 += factoryStatPool[i].productPool[num7].exportStorageCount;
				}
			}
			for (int j = GameMain.data.factories.Length; j < factoryStatPool.Length; j++)
			{
				int num8 = factoryStatPool[j].productIndices[itemId];
				if (num8 > 0)
				{
					num += factoryStatPool[j].productPool[num8].refProductSpeed;
					num2 += factoryStatPool[j].productPool[num8].refConsumeSpeed;
					num3 += factoryStatPool[j].productPool[num8].storageCount;
					num4 += factoryStatPool[j].productPool[num8].trashCount;
					num5 += factoryStatPool[j].productPool[num8].importStorageCount;
					num6 += factoryStatPool[j].productPool[num8].exportStorageCount;
				}
			}
		}
		else if (__instance.gameData.localPlanet != null && astroFilter == 0)
		{
			int factoryIndex = __instance.gameData.localPlanet.factoryIndex;
			int num9 = factoryStatPool[factoryIndex].productIndices[itemId];
			if (num9 > 0)
			{
				num += factoryStatPool[factoryIndex].productPool[num9].refProductSpeed;
				num2 += factoryStatPool[factoryIndex].productPool[num9].refConsumeSpeed;
				num3 += factoryStatPool[factoryIndex].productPool[num9].storageCount;
				num4 += factoryStatPool[factoryIndex].productPool[num9].trashCount;
				num5 += factoryStatPool[factoryIndex].productPool[num9].importStorageCount;
				num6 += factoryStatPool[factoryIndex].productPool[num9].exportStorageCount;
			}
		}
		else if (astroFilter % 100 == 0)
		{
			int starId = astroFilter / 100;
			StarData starData = ((astroFilter != 0) ? __instance.gameData.galaxy.StarById(starId) : __instance.gameData.localStar);
			if (starData != null)
			{
				for (int k = 0; k < starData.planetCount; k++)
				{
					if (starData.planets[k].factory != null)
					{
						int factoryIndex2 = starData.planets[k].factoryIndex;
						int num10 = factoryStatPool[factoryIndex2].productIndices[itemId];
						if (num10 > 0)
						{
							num += factoryStatPool[factoryIndex2].productPool[num10].refProductSpeed;
							num2 += factoryStatPool[factoryIndex2].productPool[num10].refConsumeSpeed;
							num3 += factoryStatPool[factoryIndex2].productPool[num10].storageCount;
							num4 += factoryStatPool[factoryIndex2].productPool[num10].trashCount;
							num5 += factoryStatPool[factoryIndex2].productPool[num10].importStorageCount;
							num6 += factoryStatPool[factoryIndex2].productPool[num10].exportStorageCount;
						}
					}
				}
				int num11 = GameMain.data.factories.Length + GameMain.galaxy.starCount - starData.id;
				int num12 = factoryStatPool[num11].productIndices[itemId];
				if (num12 > 0)
				{
					num += factoryStatPool[num11].productPool[num12].refProductSpeed;
					num2 += factoryStatPool[num11].productPool[num12].refConsumeSpeed;
					num3 += factoryStatPool[num11].productPool[num12].storageCount;
					num4 += factoryStatPool[num11].productPool[num12].trashCount;
					num5 += factoryStatPool[num11].productPool[num12].importStorageCount;
					num6 += factoryStatPool[num11].productPool[num12].exportStorageCount;
				}
			}
			else
			{
				int factoryCount2 = __instance.gameData.factoryCount;
				for (int l = 0; l < factoryCount2; l++)
				{
					int num13 = factoryStatPool[l].productIndices[itemId];
					if (num13 > 0)
					{
						num += factoryStatPool[l].productPool[num13].refProductSpeed;
						num2 += factoryStatPool[l].productPool[num13].refConsumeSpeed;
						num3 += factoryStatPool[l].productPool[num13].storageCount;
						num4 += factoryStatPool[l].productPool[num13].trashCount;
						num5 += factoryStatPool[l].productPool[num13].importStorageCount;
						num6 += factoryStatPool[l].productPool[num13].exportStorageCount;
					}
				}
				for (int m = GameMain.data.factories.Length; m < factoryStatPool.Length; m++)
				{
					int num14 = factoryStatPool[m].productIndices[itemId];
					if (num14 > 0)
					{
						num += factoryStatPool[m].productPool[num14].refProductSpeed;
						num2 += factoryStatPool[m].productPool[num14].refConsumeSpeed;
						num3 += factoryStatPool[m].productPool[num14].storageCount;
						num4 += factoryStatPool[m].productPool[num14].trashCount;
						num5 += factoryStatPool[m].productPool[num14].importStorageCount;
						num6 += factoryStatPool[m].productPool[num14].exportStorageCount;
					}
				}
			}
		}
		else
		{
			PlanetData planetData = __instance.gameData.galaxy.PlanetById(astroFilter);
			if (planetData != null && planetData.factory != null)
			{
				int factoryIndex3 = planetData.factoryIndex;
				int num15 = factoryStatPool[factoryIndex3].productIndices[itemId];
				if (num15 > 0)
				{
					num += factoryStatPool[factoryIndex3].productPool[num15].refProductSpeed;
					num2 += factoryStatPool[factoryIndex3].productPool[num15].refConsumeSpeed;
					num3 += factoryStatPool[factoryIndex3].productPool[num15].storageCount;
					num4 += factoryStatPool[factoryIndex3].productPool[num15].trashCount;
					num5 += factoryStatPool[factoryIndex3].productPool[num15].importStorageCount;
					num6 += factoryStatPool[factoryIndex3].productPool[num15].exportStorageCount;
				}
			}
			else
			{
				int num16 = astroFilter / 100 - 1;
				if (num16 >= 0 && num16 < GameMain.galaxy.stars.Length && num16 < MoreMegaStructure.StarMegaStructureType.Length && MoreMegaStructure.StarMegaStructureType[num16] == 4)
				{
					int num17 = astroFilter % 100 - 1;
					if (num17 >= 0 && num17 == GameMain.galaxy.stars[num16].planets.Length)
					{
						int num18 = GameMain.data.factories.Length + GameMain.galaxy.starCount - num16 - 1;
						int num19 = factoryStatPool[num18].productIndices[itemId];
						if (num19 > 0)
						{
							num += factoryStatPool[num18].productPool[num19].refProductSpeed;
							num2 += factoryStatPool[num18].productPool[num19].refConsumeSpeed;
							num3 += factoryStatPool[num18].productPool[num19].storageCount;
							num4 += factoryStatPool[num18].productPool[num19].trashCount;
							num5 += factoryStatPool[num18].productPool[num19].importStorageCount;
							num6 += factoryStatPool[num18].productPool[num19].exportStorageCount;
						}
					}
				}
			}
		}
		StringBuilderUtility.WriteKMG(__instance.sb1, 8, (long)(num + 0.5f), blank: true);
		StringBuilderUtility.WriteKMG(__instance.sb2, 8, (long)(num2 + 0.5f), blank: true);
		__instance.productRefSpeedText.text = __instance.sb1.ToString();
		__instance.consumeRefSpeedText.text = __instance.sb2.ToString();
		bool flag = false;
		__instance.storageCountText.text = (flag ? "正在计算中".Translate() : num3.ToString("#,##0"));
		__instance.storageCountText.fontSize = (flag ? 12 : 18);
		__instance.storageCountText.resizeTextForBestFit = !flag;
		__instance.trashCountText.text = num4.ToString("#,##0");
		__instance.importStorageCountText.text = num5.ToString("#,##0");
		__instance.exportStorageCountText.text = num6.ToString("#,##0");
		__instance.productRefSpeedText.color = (((long)(num + 0.5f) > 0) ? __instance.productColor : __instance.zeroColor);
		__instance.consumeRefSpeedText.color = (((long)(num2 + 0.5f) > 0) ? __instance.consumeColor : __instance.zeroColor);
		__instance.storageCountText.color = ((num3 > 0) ? __instance.storageCountColor : __instance.zeroColor);
		__instance.trashCountText.color = ((num4 > 0) ? __instance.storageCountColor : __instance.zeroColor);
		__instance.importStorageCountText.color = ((num5 > 0) ? __instance.productColor : __instance.zeroColor);
		__instance.exportStorageCountText.color = ((num6 > 0) ? __instance.consumeColor : __instance.zeroColor);
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIReferenceSpeedTip), "SetSubTip")]
	public static bool UIRefSpeedTipSetSubTipPrePatch(ref UIReferenceSpeedTip __instance, int _productionProtoId)
	{
		__instance.subTipRectTrans.gameObject.SetActive(value: true);
		__instance.productionProtoId = _productionProtoId;
		__instance.subTipPageIndex = 0;
		GameData data = GameMain.data;
		if (data == null)
		{
			return false;
		}
		Array.Clear(__instance.loadedEntryDatas, 0, __instance.loadedEntryDatas.Length);
		Array.Clear(__instance.loadedSubTipDatas, 0, __instance.loadedSubTipDatas.Length);
		GameHistoryData history = data.history;
		int[] array = LDB.items.Select(2313)?.prefabDesc.incItemId;
		int num = 0;
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				if (history.ItemUnlocked(array[i]))
				{
					ItemProto itemProto = LDB.items.Select(array[i]);
					if (itemProto != null && itemProto.Ability > num)
					{
						num = itemProto.Ability;
					}
				}
			}
		}
		float incMulti = 1f + (float)Cargo.incTableMilli[num];
		float accMulti = 1f + (float)Cargo.accTableMilli[num];
		int num2 = 1;
		if (history.TechUnlocked(1607))
		{
			num2 = 4;
		}
		int inserterStackOutput = history.inserterStackOutput;
		int stationPilerLevel = history.stationPilerLevel;
		if (inserterStackOutput > num2)
		{
			num2 = inserterStackOutput;
		}
		if (inserterStackOutput > num2)
		{
			num2 = stationPilerLevel;
		}
		if (__instance.astroFilter == 0)
		{
			for (int j = 0; j < GameMain.galaxy.starCount && j < MoreMegaStructure.StarMegaStructureType.Length; j++)
			{
				if (MoreMegaStructure.StarMegaStructureType[j] == 4)
				{
					MMSAddRefSpeedTipEntryData(ref __instance, j, num, __instance.productionProtoId);
				}
			}
			int factoryCount = data.factoryCount;
			for (int k = 0; k < factoryCount; k++)
			{
				__instance.AddEntryDataWithFactory(data.factories[k], incMulti, accMulti, num2, __instance.productionProtoId);
			}
		}
		else if (__instance.astroFilter % 100 == 0)
		{
			StarData starData = data.galaxy.StarById(__instance.astroFilter / 100);
			if (starData != null)
			{
				MMSAddRefSpeedTipEntryData(ref __instance, starData.index, num, __instance.productionProtoId);
				PlanetData[] planets = starData.planets;
				for (int l = 0; l < starData.planetCount; l++)
				{
					PlanetData planetData = planets[l];
					if (planetData != null && planetData.factory != null)
					{
						__instance.AddEntryDataWithFactory(data.factories[planetData.factoryIndex], incMulti, accMulti, num2, __instance.productionProtoId);
					}
				}
			}
			else
			{
				for (int m = 0; m < GameMain.galaxy.starCount && m < MoreMegaStructure.StarMegaStructureType.Length; m++)
				{
					if (MoreMegaStructure.StarMegaStructureType[m] == 4)
					{
						MMSAddRefSpeedTipEntryData(ref __instance, m, num, __instance.productionProtoId);
					}
				}
				int factoryCount2 = data.factoryCount;
				for (int n = 0; n < factoryCount2; n++)
				{
					__instance.AddEntryDataWithFactory(data.factories[n], incMulti, accMulti, num2, __instance.productionProtoId);
				}
			}
		}
		else
		{
			PlanetData planetData2 = data.galaxy.PlanetById(__instance.astroFilter);
			if (planetData2 != null && planetData2.factory != null)
			{
				__instance.AddEntryDataWithFactory(planetData2.factory, incMulti, accMulti, num2, __instance.productionProtoId);
			}
			else if (IsStarAssemblyAstroFilter(__instance.astroFilter))
			{
				MMSAddRefSpeedTipEntryData(ref __instance, __instance.astroFilter / 100 - 1, num, __instance.productionProtoId);
			}
		}
		__instance.RefreshSubEntries();
		__instance.subTipRectTrans.anchoredPosition = new Vector2(0f, 0f);
		__instance.subTipRectTrans.SetParent(UIRoot.instance.itemReferenceSpeedTipTransform, worldPositionStays: true);
		Rect rect = UIRoot.instance.itemReferenceSpeedTipTransform.rect;
		float num3 = Mathf.RoundToInt(rect.width);
		float num4 = Mathf.RoundToInt(rect.height);
		Vector2 anchoredPosition = __instance.subTipRectTrans.anchoredPosition;
		float num5 = __instance.subTipRectTrans.anchorMin.x * num3 + anchoredPosition.x;
		float num6 = __instance.subTipRectTrans.anchorMin.y * num4 + anchoredPosition.y;
		Rect rect2 = __instance.subTipRectTrans.rect;
		rect2.x += num5;
		rect2.y += num6;
		Vector2 zero = Vector2.zero;
		if (rect2.xMin < 0f)
		{
			zero.x -= rect2.xMin;
		}
		if (rect2.yMin < 0f)
		{
			zero.y -= rect2.yMin;
		}
		if (rect2.xMax > num3)
		{
			zero.x -= rect2.xMax - num3;
		}
		if (rect2.yMax > num4)
		{
			zero.y -= rect2.yMax - num4;
		}
		Vector2 vector = anchoredPosition + zero;
		vector = new Vector2(Mathf.Round(vector.x), Mathf.Round(vector.y));
		__instance.subTipRectTrans.anchoredPosition = vector;
		__instance.subTipRectTrans.SetParent(__instance.rectTrans, worldPositionStays: true);
		return false;
	}

	public static void MMSAddRefSpeedTipEntryData(ref UIReferenceSpeedTip _this, int starIndex, int maxIncLevelByProliferatorUnlocked, int productionIdMask = 9493)
	{
		int itemId = _this.itemId;
		ItemProto itemProto = LDB.items.Select(itemId);
		if (itemProto == null)
		{
			return;
		}
		int astroId = DefineStarAssemblyAstroId(starIndex);
		bool flag = _this.itemCycle == UIReferenceSpeedTip.EItemCycle.Production;
		bool flag2 = _this.itemCycle == UIReferenceSpeedTip.EItemCycle.Consumption;
		FactoryProductionStat factoryProductionStat = GameMain.data.statistics.production.factoryStatPool[GameMain.data.factories.Length + GameMain.galaxy.starCount - 1 - starIndex];
		if (flag)
		{
			factoryProductionStat.ResetRefProductSpeed(itemId);
		}
		if (flag2)
		{
			factoryProductionStat.ResetRefConsumeSpeed(itemId);
		}
		int count = StarAssembly.recipeIds[starIndex].Count;
		for (int i = 0; i < count; i++)
		{
			double redundantEnergy;
			if (i == 0 && itemId == 9500)
			{
				if (flag)
				{
					float num = (float)(StarAssembly.GetConsumeProduceSpeedRatio(starIndex, i, out redundantEnergy) * 3600.0);
					float num2 = num;
					if (productionIdMask == 9493)
					{
						_this.AddSubTipEntryData(astroId, num2, useInc2Inc: false, useInc2Acc: false, outNetwork: false);
					}
					_this.AddEntryData(9493, num2, useInc2Inc: false, useInc2Acc: false, outNetwork: false);
					factoryProductionStat.AddRefProductSpeed(itemId, num2);
				}
			}
			else
			{
				if (StarAssembly.recipeIds[starIndex][i] <= 0)
				{
					continue;
				}
				float num3 = (float)(StarAssembly.GetConsumeProduceSpeedRatio(starIndex, i, out redundantEnergy) * 3600.0);
				if (flag2)
				{
					for (int j = 0; j < StarAssembly.items[starIndex][i].Count; j++)
					{
						if (StarAssembly.items[starIndex][i][j] == itemId)
						{
							float num4 = num3 * (float)StarAssembly.itemCounts[starIndex][i][j];
							if (productionIdMask == 9493)
							{
								_this.AddSubTipEntryData(astroId, num4, useInc2Inc: false, useInc2Acc: false, outNetwork: false);
							}
							_this.AddEntryData(9493, num4, useInc2Inc: false, useInc2Acc: false, outNetwork: false);
							factoryProductionStat.AddRefConsumeSpeed(itemId, num4);
						}
					}
				}
				else
				{
					if (!flag)
					{
						continue;
					}
					for (int k = 0; k < StarAssembly.products[starIndex][i].Count; k++)
					{
						if (StarAssembly.products[starIndex][i][k] == itemId)
						{
							float num5 = num3 * (1f + StarAssembly.GetFullIncMilli(starIndex, i, maxIncLevelByProliferatorUnlocked)) * (float)StarAssembly.productCounts[starIndex][i][k];
							if (productionIdMask == 9493)
							{
								_this.AddSubTipEntryData(astroId, num5, useInc2Inc: false, useInc2Acc: false, outNetwork: false);
							}
							_this.AddEntryData(9493, num5, useInc2Inc: false, useInc2Acc: false, outNetwork: false);
							factoryProductionStat.AddRefProductSpeed(itemId, num5);
						}
					}
				}
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIReferenceSpeedTip), "RefreshSubEntries")]
	public static bool UIRefSpeedTipRefreshSubEntriesPrePatch(ref UIReferenceSpeedTip __instance)
	{
		GameData data = GameMain.data;
		if (data == null)
		{
			return false;
		}
		ref RefSpeedTipEntryData reference = ref __instance.loadedEntryDatas[__instance.productionProtoId];
		float entryTotalSpeed = reference.useInc2IncSpeed + reference.useInc2AccSpeed + reference.normalSpeed;
		int num = 0;
		int num2 = __instance.subTipPageIndex * 8;
		int num3 = (__instance.subTipPageIndex + 1) * 8 - 1;
		int num4 = -1;
		GalaxyData galaxy = data.galaxy;
		StarData[] stars = galaxy.stars;
		int num5 = (int)__instance.subTipEntryPrefab.rectTrans.anchoredPosition.y;
		for (int i = 0; i < galaxy.starCount; i++)
		{
			if (stars[i] == null)
			{
				continue;
			}
			bool flag = __instance.productionProtoId == 9493;
			bool flag2 = __instance.astroFilter == 0;
			bool flag3 = __instance.astroFilter % 100 == 0 && i == __instance.astroFilter / 100 - 1;
			bool flag4 = IsStarAssemblyAstroFilter(__instance.astroFilter) && i == __instance.astroFilter / 100 - 1;
			bool flag5 = i < MoreMegaStructure.StarMegaStructureType.Length && MoreMegaStructure.StarMegaStructureType[i] == 4;
			int num6 = DefineStarAssemblyAstroId(i);
			bool flag6 = __instance.loadedSubTipDatas != null && num6 >= 0 && num6 < __instance.loadedSubTipDatas.Length && __instance.loadedSubTipDatas[num6].astroId == num6;
			if (flag && flag5 && flag6 && (flag2 || flag3 || flag4))
			{
				num4++;
				if (num4 >= num2 && num4 <= num3)
				{
					int num7 = DefineStarAssemblyAstroId(i);
					if (num >= __instance.subTipEntries.Count)
					{
						UIReferenceSpeedSubTipEntry item = UnityEngine.Object.Instantiate(__instance.subTipEntryPrefab, __instance.subTipEntryPrefab.rectTrans.parent);
						__instance.subTipEntries.Add(item);
					}
					ref RefSpeedSubTipEntryData reference2 = ref __instance.loadedSubTipDatas[num7];
					__instance.subTipEntries[num].gameObject.SetActive(value: true);
					__instance.subTipEntries[num].entryData = reference2;
					__instance.subTipEntries[num].productionProtoId = __instance.productionProtoId;
					__instance.subTipEntries[num].entryTotalSpeed = entryTotalSpeed;
					__instance.subTipEntries[num].Refresh();
					__instance.subTipEntries[num].rectTrans.anchoredPosition = new Vector2(__instance.subTipEntryPrefab.rectTrans.anchoredPosition.x, num5);
					num5 -= __instance.subTipEntries[num].entryHeight;
					num++;
				}
			}
			PlanetData[] planets = stars[i].planets;
			for (int j = 0; j < stars[i].planetCount; j++)
			{
				PlanetData planetData = planets[j];
				if (planetData == null || planetData.factory == null || __instance.loadedSubTipDatas[planetData.astroId].astroId != planetData.astroId)
				{
					continue;
				}
				num4++;
				if (num4 >= num2 && num4 <= num3)
				{
					if (num >= __instance.subTipEntries.Count)
					{
						UIReferenceSpeedSubTipEntry item2 = UnityEngine.Object.Instantiate(__instance.subTipEntryPrefab, __instance.subTipEntryPrefab.rectTrans.parent);
						__instance.subTipEntries.Add(item2);
					}
					ref RefSpeedSubTipEntryData reference3 = ref __instance.loadedSubTipDatas[planetData.astroId];
					__instance.subTipEntries[num].gameObject.SetActive(value: true);
					__instance.subTipEntries[num].entryData = reference3;
					__instance.subTipEntries[num].productionProtoId = __instance.productionProtoId;
					__instance.subTipEntries[num].entryTotalSpeed = entryTotalSpeed;
					__instance.subTipEntries[num].Refresh();
					__instance.subTipEntries[num].rectTrans.anchoredPosition = new Vector2(__instance.subTipEntryPrefab.rectTrans.anchoredPosition.x, num5);
					num5 -= __instance.subTipEntries[num].entryHeight;
					num++;
				}
			}
		}
		for (int k = num; k < __instance.subTipEntries.Count; k++)
		{
			__instance.subTipEntries[k].gameObject.SetActive(value: false);
		}
		bool flag7 = num4 + 1 > 8;
		if (flag7)
		{
			__instance.previousPageBtn.gameObject.SetActive(value: true);
			__instance.nextPageBtn.gameObject.SetActive(value: true);
			__instance.previousPageBtn.button.interactable = __instance.subTipPageIndex > 0;
			__instance.nextPageBtn.button.interactable = __instance.subTipPageIndex < num4 / 8;
		}
		else
		{
			__instance.previousPageBtn.gameObject.SetActive(value: false);
			__instance.nextPageBtn.gameObject.SetActive(value: false);
		}
		for (int l = 0; l < __instance.activeEntryCount; l++)
		{
			__instance.entries[l].entryData = __instance.loadedEntryDatas[__instance.entries[l].entryData.productionProtoId];
			__instance.entries[l].Refresh();
		}
		__instance.subTipRectTrans.sizeDelta = new Vector2(__instance.subTipRectTrans.sizeDelta.x, flag7 ? (0f - (float)num5 + 40f) : (0f - (float)num5 + 10f));
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIReferenceSpeedTip), "SetTip")]
	public static bool UIReferenceSpeedTipSetTipPostPatch(ref UIReferenceSpeedTip __instance, int _itemId, int _astroFilter, UIReferenceSpeedTip.EItemCycle _itemCycle, Transform _parent)
	{
		if (__instance.itemId == _itemId && __instance.astroFilter == _astroFilter && __instance.itemCycle == _itemCycle)
		{
			return false;
		}
		__instance.itemId = _itemId;
		__instance.astroFilter = _astroFilter;
		__instance.itemCycle = _itemCycle;
		__instance.rectTrans.SetParent(_parent, worldPositionStays: true);
		RectTransform rectTrans = __instance.rectTrans;
		RectTransform rectTrans2 = __instance.rectTrans;
		Vector2 anchorMax = (rectTrans2.anchorMin = new Vector2(1f, 0.5f));
		rectTrans.anchorMax = anchorMax;
		__instance.rectTrans.pivot = new Vector2(0f, 0.5f);
		RectTransform rectTrans3 = __instance.rectTrans;
		rectTrans3.anchoredPosition = default(Vector2);
		GameData data = GameMain.data;
		if (data != null)
		{
			Array.Clear(__instance.loadedEntryDatas, 0, __instance.loadedEntryDatas.Length);
			GameHistoryData history = data.history;
			int[] array = LDB.items.Select(2313)?.prefabDesc.incItemId;
			int num = 0;
			if (array != null)
			{
				for (int i = 0; i < array.Length; i++)
				{
					if (history.ItemUnlocked(array[i]))
					{
						ItemProto itemProto = LDB.items.Select(array[i]);
						if (itemProto != null && itemProto.Ability > num)
						{
							num = itemProto.Ability;
						}
					}
				}
			}
			float incMulti = 1f + (float)Cargo.incTableMilli[num];
			float accMulti = 1f + (float)Cargo.accTableMilli[num];
			int num2 = 1;
			if (history.TechUnlocked(1607))
			{
				num2 = 4;
			}
			int inserterStackOutput = history.inserterStackOutput;
			int stationPilerLevel = history.stationPilerLevel;
			if (inserterStackOutput > num2)
			{
				num2 = inserterStackOutput;
			}
			if (inserterStackOutput > num2)
			{
				num2 = stationPilerLevel;
			}
			if (__instance.astroFilter == 0)
			{
				for (int j = 0; j < GameMain.galaxy.starCount && j < MoreMegaStructure.StarMegaStructureType.Length; j++)
				{
					if (MoreMegaStructure.StarMegaStructureType[j] == 4)
					{
						MMSAddRefSpeedTipEntryData(ref __instance, j, num);
					}
				}
				int factoryCount = data.factoryCount;
				for (int k = 0; k < factoryCount; k++)
				{
					__instance.AddEntryDataWithFactory(data.factories[k], incMulti, accMulti, num2, 0);
				}
			}
			else if (__instance.astroFilter % 100 == 0)
			{
				StarData starData = data.galaxy.StarById(__instance.astroFilter / 100);
				if (starData != null)
				{
					MMSAddRefSpeedTipEntryData(ref __instance, starData.index, num);
					PlanetData[] planets = starData.planets;
					for (int l = 0; l < starData.planetCount; l++)
					{
						PlanetData planetData = planets[l];
						if (planetData != null && planetData.factory != null)
						{
							__instance.AddEntryDataWithFactory(data.factories[planetData.factoryIndex], incMulti, accMulti, num2, 0);
						}
					}
				}
				else
				{
					for (int m = 0; m < GameMain.galaxy.starCount && m < MoreMegaStructure.StarMegaStructureType.Length; m++)
					{
						if (MoreMegaStructure.StarMegaStructureType[m] == 4)
						{
							MMSAddRefSpeedTipEntryData(ref __instance, m, num);
						}
					}
					int factoryCount2 = data.factoryCount;
					for (int n = 0; n < factoryCount2; n++)
					{
						__instance.AddEntryDataWithFactory(data.factories[n], incMulti, accMulti, num2, 0);
					}
				}
			}
			else
			{
				PlanetData planetData2 = data.galaxy.PlanetById(__instance.astroFilter);
				if (planetData2 != null && planetData2.factory != null)
				{
					__instance.AddEntryDataWithFactory(planetData2.factory, incMulti, accMulti, num2, 0);
				}
				else if (IsStarAssemblyAstroFilter(__instance.astroFilter))
				{
					MMSAddRefSpeedTipEntryData(ref __instance, __instance.astroFilter / 100 - 1, num);
				}
			}
		}
		ItemProto[] dataArray = LDB.items.dataArray;
		__instance.activeEntryCount = 0;
		float num3 = 0f;
		int num4 = (int)__instance.entryPrefab.rectTrans.anchoredPosition.y;
		int num5 = (int)(__instance.entryPrefab.rectTrans.rect.width + 0.5f);
		for (int num6 = 0; num6 < dataArray.Length; num6++)
		{
			if (__instance.loadedEntryDatas[dataArray[num6].ID].productionProtoId != 0)
			{
				if (__instance.activeEntryCount >= __instance.entries.Count)
				{
					UIReferenceSpeedTipEntry item = UnityEngine.Object.Instantiate(__instance.entryPrefab, __instance.entryPrefab.rectTrans.parent);
					__instance.entries.Add(item);
				}
				ref RefSpeedTipEntryData reference = ref __instance.loadedEntryDatas[dataArray[num6].ID];
				__instance.entries[__instance.activeEntryCount].gameObject.SetActive(value: true);
				__instance.entries[__instance.activeEntryCount].entryData = reference;
				__instance.entries[__instance.activeEntryCount].Refresh();
				__instance.entries[__instance.activeEntryCount].rectTrans.anchoredPosition = new Vector2(__instance.entryPrefab.rectTrans.anchoredPosition.x, num4);
				num4 -= __instance.entries[__instance.activeEntryCount].entryHeight;
				if (num5 < __instance.entries[__instance.activeEntryCount].entryWidth)
				{
					num5 = __instance.entries[__instance.activeEntryCount].entryWidth;
				}
				num3 += reference.normalSpeed + reference.useInc2IncSpeed + reference.useInc2AccSpeed + reference.outNetworkSpeed;
				__instance.activeEntryCount++;
			}
		}
		for (int num7 = __instance.activeEntryCount; num7 < __instance.entries.Count; num7++)
		{
			__instance.entries[num7].gameObject.SetActive(value: false);
		}
		if (__instance.activeEntryCount == 0)
		{
			__instance.zeroCountTipText.gameObject.SetActive(value: true);
			if (__instance.itemCycle == UIReferenceSpeedTip.EItemCycle.Production)
			{
				__instance.zeroCountTipText.text = "参考速率无生产设施".Translate();
			}
			else if (__instance.itemCycle == UIReferenceSpeedTip.EItemCycle.Consumption)
			{
				__instance.zeroCountTipText.text = "参考速率无消耗设施".Translate();
			}
			num4 -= (int)(__instance.zeroCountTipText.rectTransform.rect.height + 0.5f);
		}
		else
		{
			__instance.zeroCountTipText.gameObject.SetActive(value: false);
		}
		__instance.totalSpeedText.text = ((long)(num3 + 0.5f)).ToString("#,##0") + " / min";
		if (__instance.itemCycle == UIReferenceSpeedTip.EItemCycle.Production)
		{
			__instance.totalSpeedLabel.color = __instance.productColor;
			__instance.totalSpeedText.color = __instance.productColor;
		}
		else if (__instance.itemCycle == UIReferenceSpeedTip.EItemCycle.Consumption)
		{
			__instance.totalSpeedLabel.color = __instance.consumeColor;
			__instance.totalSpeedText.color = __instance.consumeColor;
		}
		else
		{
			__instance.totalSpeedLabel.color = Color.white;
			__instance.totalSpeedText.color = Color.white;
		}
		__instance.rectTrans.SetParent(UIRoot.instance.itemReferenceSpeedTipTransform, worldPositionStays: true);
		__instance.rectTrans.sizeDelta = new Vector2((float)num5 + 20f, 0f - (float)num4 + 2f);
		Rect rect = UIRoot.instance.itemReferenceSpeedTipTransform.rect;
		float num8 = Mathf.RoundToInt(rect.width);
		float num9 = Mathf.RoundToInt(rect.height);
		Vector2 anchoredPosition = __instance.rectTrans.anchoredPosition;
		float num10 = __instance.rectTrans.anchorMin.x * num8 + anchoredPosition.x;
		float num11 = __instance.rectTrans.anchorMin.y * num9 + anchoredPosition.y;
		Rect rect2 = __instance.rectTrans.rect;
		rect2.x += num10;
		rect2.y += num11;
		Vector2 zero = Vector2.zero;
		if (rect2.xMin < 0f)
		{
			zero.x -= rect2.xMin;
		}
		if (rect2.yMin < 0f)
		{
			zero.y -= rect2.yMin;
		}
		if (rect2.xMax > num8)
		{
			zero.x -= rect2.xMax - num8;
		}
		if (rect2.yMax > num9)
		{
			zero.y -= rect2.yMax - num9;
		}
		Vector2 vector2 = anchoredPosition + zero;
		vector2 = new Vector2(Mathf.Round(vector2.x), Mathf.Round(vector2.y));
		__instance.rectTrans.anchoredPosition = vector2;
		return false;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIReferenceSpeedSubTipEntry), "Refresh")]
	public static void UIReferenceSpeedSubTipEntryIconAndNamePostPacth(ref UIReferenceSpeedSubTipEntry __instance)
	{
		if (__instance.productionProtoId == 9493)
		{
			int starId = __instance.entryData.astroId / 100;
			if (GameMain.galaxy.StarById(starId) != null)
			{
				string text = "星际组装厂".Translate() + " " + GameMain.galaxy.StarById(starId).displayName;
				__instance.planetNameText.text = text;
			}
		}
	}

	public static bool IsStarAssemblyAstroFilter(int astroFilter)
	{
		int num = astroFilter / 100 - 1;
		if (num >= 0 && num < GameMain.galaxy.stars.Length && num < MoreMegaStructure.StarMegaStructureType.Length && MoreMegaStructure.StarMegaStructureType[num] == 4)
		{
			int num2 = astroFilter % 100 - 1;
			if (num2 >= 0 && num2 == GameMain.galaxy.stars[num].planets.Length)
			{
				return true;
			}
		}
		return false;
	}

	public static int DefineStarAssemblyAstroId(int starIndex)
	{
		if (starIndex < 0 || starIndex >= GameMain.galaxy.stars.Length || starIndex >= MoreMegaStructure.StarMegaStructureType.Length)
		{
			return 100;
		}
		return (starIndex + 1) * 100 + GameMain.galaxy.stars[starIndex].planetCount + 1;
	}

	public static bool TryGetIAFactoryIndex(int astroFilter, out int factoryIndex)
	{
		if (astroFilter % 100 != 0)
		{
			int num = astroFilter / 100;
			if (GameMain.galaxy.StarById(num) != null)
			{
				int num2 = astroFilter % 100;
				if (num2 == GameMain.galaxy.StarById(num).planetCount + 1)
				{
					factoryIndex = GameMain.data.factories.Length + GameMain.galaxy.starCount - num;
					return true;
				}
			}
		}
		factoryIndex = -1;
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(AstroItemProductionStatPlan), "CalculateFactoryStatGroup")]
	public static bool CalculateFactoryStatGroupPrefix(ref AstroItemProductionStatPlan __instance)
	{
		if (TryGetIAFactoryIndex(__instance.astroFilter, out var factoryIndex))
		{
			Array.Clear(__instance.statFactoryIndices, 0, __instance.statFactoriesCursor);
			__instance.statFactoriesCursor = 0;
			__instance.AddFactoryStatGroup(factoryIndex);
			return false;
		}
		return true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(AstroItemProductionStatPlan), "CalculateFactoryStatGroup")]
	public static void CalculateFactoryStatGroupPostfix(ref AstroItemProductionStatPlan __instance)
	{
		if (__instance.astroFilter == 0)
		{
			if (__instance.gameData.localPlanet == null && __instance.gameData.localStar != null)
			{
				int index = __instance.gameData.localStar.index;
				__instance.AddFactoryStatGroup(StarIndex2FactoryIndex(index));
			}
		}
		else if (__instance.astroFilter % 100 == 0)
		{
			int num = __instance.astroFilter / 100 - 1;
			if (num >= 0)
			{
				__instance.AddFactoryStatGroup(StarIndex2FactoryIndex(num));
			}
		}
		else
		{
			if (__instance.astroFilter != -1 && (__instance.astroFilter != 0 || __instance.gameData.localStar != null || __instance.gameData.localPlanet != null))
			{
				return;
			}
			for (int i = 0; i < GameMain.galaxy.starCount && i < MoreMegaStructure.StarMegaStructureType.Length; i++)
			{
				if (MoreMegaStructure.StarMegaStructureType[i] == 4)
				{
					__instance.AddFactoryStatGroup(StarIndex2FactoryIndex(i));
				}
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(AstroItemProductionStatPlan), "CalculateExtraInfo")]
	public static bool CalculateExtraInfoPrefix(ref AstroItemProductionStatPlan __instance)
	{
		if (TryGetIAFactoryIndex(__instance.astroFilter, out var factoryIndex))
		{
			__instance.gameData.statistics.production.extraInfoCalculator.AddFactory(factoryIndex);
			return false;
		}
		return true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(AstroItemProductionStatPlan), "CalculateExtraInfo")]
	public static void CalculateExtraInfoPostfix(ref AstroItemProductionStatPlan __instance)
	{
		if (__instance.astroFilter == 0)
		{
			if (__instance.gameData.localPlanet == null && __instance.gameData.localStar != null)
			{
				int index = __instance.gameData.localStar.index;
				__instance.gameData.statistics.production.extraInfoCalculator.AddFactory(StarIndex2FactoryIndex(index));
			}
		}
		else if (__instance.astroFilter % 100 == 0)
		{
			int num = __instance.astroFilter / 100 - 1;
			if (num >= 0)
			{
				__instance.gameData.statistics.production.extraInfoCalculator.AddFactory(StarIndex2FactoryIndex(num));
			}
		}
		else
		{
			if (__instance.astroFilter != -1 && (__instance.astroFilter != 0 || __instance.gameData.localStar != null || __instance.gameData.localPlanet != null))
			{
				return;
			}
			for (int i = 0; i < GameMain.galaxy.starCount && i < MoreMegaStructure.StarMegaStructureType.Length; i++)
			{
				if (MoreMegaStructure.StarMegaStructureType[i] == 4)
				{
					__instance.gameData.statistics.production.extraInfoCalculator.AddFactory(StarIndex2FactoryIndex(i));
				}
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(AstroItemProductionStatPlan), "CalculateImportAndExport")]
	public static bool CalculateImportAndExportPrefix(ref AstroItemProductionStatPlan __instance, out long import, out long export)
	{
		import = 0L;
		export = 0L;
		if (TryGetIAFactoryIndex(__instance.astroFilter, out var _))
		{
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(AstroItemProductionStatPlan), "CalculateTrafficDetail")]
	public static bool CalculateTrafficDetailPrefix(ref AstroItemProductionStatPlan __instance)
	{
		if (TryGetIAFactoryIndex(__instance.astroFilter, out var _))
		{
			Array.Clear(__instance.trafficDetail, 0, __instance.trafficDetail.Length);
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(AstroItemProductionStatPlan), "GetGalacticTransportStorageCount")]
	public static bool GetGalacticTransportStorageCountPrefix(ref AstroItemProductionStatPlan __instance, out long importStorageCount, out long exportStorageCount)
	{
		importStorageCount = 0L;
		exportStorageCount = 0L;
		if (TryGetIAFactoryIndex(__instance.astroFilter, out var factoryIndex))
		{
			FactoryProductionStat[] factoryStatPool = __instance.gameData.statistics.production.factoryStatPool;
			int num = factoryStatPool[factoryIndex].productIndices[__instance.itemId];
			if (num > 0)
			{
				importStorageCount += factoryStatPool[factoryIndex].productPool[num].importStorageCount;
				exportStorageCount += factoryStatPool[factoryIndex].productPool[num].exportStorageCount;
			}
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(AstroItemProductionStatPlan), "GetItemsCyclicRefSpeed")]
	public static bool GetItemsCyclicRefSpeedPrefix(ref AstroItemProductionStatPlan __instance, out float productRefSpeed, out float consumeRefSpeed)
	{
		productRefSpeed = 0f;
		consumeRefSpeed = 0f;
		if (TryGetIAFactoryIndex(__instance.astroFilter, out var factoryIndex))
		{
			FactoryProductionStat[] factoryStatPool = __instance.gameData.statistics.production.factoryStatPool;
			int num = factoryStatPool[factoryIndex].productIndices[__instance.itemId];
			if (num > 0)
			{
				productRefSpeed += factoryStatPool[factoryIndex].productPool[num].refProductSpeed;
				consumeRefSpeed += factoryStatPool[factoryIndex].productPool[num].refConsumeSpeed;
			}
			return false;
		}
		return true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(AstroItemProductionStatPlan), "GetItemsCyclicRefSpeed")]
	public static void GetItemsCyclicRefSpeedPostfix(ref AstroItemProductionStatPlan __instance, ref float productRefSpeed, ref float consumeRefSpeed)
	{
		FactoryProductionStat[] factoryStatPool = __instance.gameData.statistics.production.factoryStatPool;
		if (__instance.astroFilter == 0)
		{
			if (__instance.gameData.localPlanet == null && __instance.gameData.localStar != null)
			{
				int index = __instance.gameData.localStar.index;
				int num = StarIndex2FactoryIndex(index);
				int num2 = factoryStatPool[num].productIndices[__instance.itemId];
				if (num2 > 0)
				{
					productRefSpeed += factoryStatPool[num].productPool[num2].refProductSpeed;
					consumeRefSpeed += factoryStatPool[num].productPool[num2].refConsumeSpeed;
				}
			}
		}
		else if (__instance.astroFilter % 100 == 0)
		{
			int num3 = __instance.astroFilter / 100 - 1;
			if (num3 >= 0)
			{
				int num4 = StarIndex2FactoryIndex(num3);
				int num5 = factoryStatPool[num4].productIndices[__instance.itemId];
				if (num5 > 0)
				{
					productRefSpeed += factoryStatPool[num4].productPool[num5].refProductSpeed;
					consumeRefSpeed += factoryStatPool[num4].productPool[num5].refConsumeSpeed;
				}
			}
		}
		else
		{
			if (__instance.astroFilter != -1 && (__instance.astroFilter != 0 || __instance.gameData.localStar != null || __instance.gameData.localPlanet != null))
			{
				return;
			}
			for (int i = 0; i < GameMain.galaxy.starCount && i < MoreMegaStructure.StarMegaStructureType.Length; i++)
			{
				if (MoreMegaStructure.StarMegaStructureType[i] == 4)
				{
					int num6 = StarIndex2FactoryIndex(i);
					int num7 = factoryStatPool[num6].productIndices[__instance.itemId];
					if (num7 > 0)
					{
						productRefSpeed += factoryStatPool[num6].productPool[num7].refProductSpeed;
						consumeRefSpeed += factoryStatPool[num6].productPool[num7].refConsumeSpeed;
					}
				}
			}
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(AstroItemProductionStatPlan), "GetItemsStorageGroupCount")]
	public static bool GetItemsStorageGroupCountPrefix(ref AstroItemProductionStatPlan __instance, out long storageCount, out long trashCount)
	{
		storageCount = 0L;
		trashCount = 0L;
		if (TryGetIAFactoryIndex(__instance.astroFilter, out var factoryIndex))
		{
			FactoryProductionStat[] factoryStatPool = __instance.gameData.statistics.production.factoryStatPool;
			int num = factoryStatPool[factoryIndex].productIndices[__instance.itemId];
			if (num > 0)
			{
				storageCount += factoryStatPool[factoryIndex].productPool[num].storageCount;
				trashCount += factoryStatPool[factoryIndex].productPool[num].trashCount;
			}
			if (__instance.gameData.localPlanet != null && !__instance.gameData.mainPlayer.sailing)
			{
				storageCount += __instance.gameData.statistics.production.playerStorageCounts[__instance.itemId];
			}
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIChartAstroItemProduction), "SetTipFormatString")]
	public static bool SetTipFormatStringPrefix(ref UIChartAstroItemProduction __instance)
	{
		if (TryGetIAFactoryIndex(__instance.statPlan.astroFilter, out var _))
		{
			if (__instance.titleTip != null && __instance.statPlan != null)
			{
				string text = "";
				text = text + $"#{__instance.statPlan.id} " + __instance.statPlan.displayName + ";";
				GameData gameData = __instance.statPlan.gameData;
				int astroFilter = __instance.statPlan.astroFilter;
				StarData starData = gameData.galaxy.StarById(astroFilter / 100);
				text = text + "星际组装厂".Translate() + starData.displayName + ";";
				switch (__instance.statPlan.timeLevel)
				{
				case 0:
					text += "统计1分钟".Translate();
					break;
				case 1:
					text += "统计10分钟".Translate();
					break;
				case 2:
					text += "统计1小时".Translate();
					break;
				case 3:
					text += "统计10小时".Translate();
					break;
				case 4:
					text += "统计100小时".Translate();
					break;
				case 5:
					text += "统计总计".Translate();
					break;
				}
				__instance.titleTip.tipTextFormatString = text;
			}
			return false;
		}
		return true;
	}

        [HarmonyTranspiler]
        [HarmonyPatch(typeof(ProductionExtraInfoCalculator), "GameTick")]
        public static IEnumerable<CodeInstruction> CalculatorGameTickTranspiler(IEnumerable<CodeInstruction> instructions)
            => StatisticsCalculatorBridge.ReplaceFactoryLookup(instructions);

        [HarmonyTranspiler]
        [HarmonyPatch(typeof(ProductionExtraInfoCalculator), "CalculateImmediately")]
        public static IEnumerable<CodeInstruction> CalculatorImmediateTranspiler(IEnumerable<CodeInstruction> instructions)
            => StatisticsCalculatorBridge.ReplaceFactoryLookup(instructions);

        [HarmonyPrefix]
        [HarmonyPatch(typeof(ProductionExtraInfoCalculator), "CalculateFactory")]
        public static bool CalculatorFactoryPrefix(ProductionExtraInfoCalculator __instance, GameData gameData, PlanetFactory factory)
            => StatisticsCalculatorBridge.CalculateFactoryPrefix(__instance, gameData, factory);

        // Legacy public helper retained, no longer bypasses calculator lifecycle.
        public static bool ProductionExtraInfoCalculator_GameTick_Prefix(ref ProductionExtraInfoCalculator __instance) => true;



	public static void CalculateFactory_IA(ref ProductionExtraInfoCalculator __instance, GameData gameData, int factoryIndex)
	{
		FactoryProductionStat factoryProductionStat = __instance.productionStatistics.factoryStatPool[factoryIndex];
		factoryProductionStat.ResetRefSpeed();
		factoryProductionStat.ResetStorageCount();
		factoryProductionStat.ResetDetailedStorageCount();
		factoryProductionStat.ResetTransportStorageCount();
        int starIndex = FactoryIndex2StarIndex(factoryIndex);
        if (starIndex < 0 || starIndex >= MoreMegaStructure.StarMegaStructureType.Length
            || MoreMegaStructure.StarMegaStructureType[starIndex] != 4
            || gameData.dysonSpheres == null || starIndex >= gameData.dysonSpheres.Length
            || gameData.dysonSpheres[starIndex] == null) return;
		GameHistoryData history = gameData.history;
		int[] array = LDB.items.Select(2313)?.prefabDesc.incItemId;
		int num = 0;
		if (array != null)
		{
			for (int i = 0; i < array.Length; i++)
			{
				if (history.ItemUnlocked(array[i]))
				{
					ItemProto itemProto = LDB.items.Select(array[i]);
					if (itemProto != null && itemProto.Ability > num)
					{
						num = itemProto.Ability;
					}
				}
			}
		}
		MMSRefreshItemsCyclicRefSpeedWithFactory(FactoryIndex2StarIndex(factoryIndex), num);
		FillIAStorage(FactoryIndex2StarIndex(factoryIndex));
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(AstroItemProductionStatPlan), "CalculateTrafficDetail")]
	public static void CalculateTrafficDetailPostfix(ref AstroItemProductionStatPlan __instance, ref long[] __result)
	{
		if (__result == null)
		{
			__result = new long[120];
		}
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(AstroStorageStatPlan), "CalculateExtraInfo")]
	public static bool CalculateExtraInfoPrefix(ref AstroStorageStatPlan __instance)
	{
		if (TryGetIAFactoryIndex(__instance.astroFilter, out var _))
		{
			int starIndex = __instance.astroFilter / 100 - 1;
			__instance.gameData.statistics.production.extraInfoCalculator.AddFactory(StarIndex2FactoryIndex(starIndex));
			return false;
		}
		return true;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIChartAstroStorage), "SetTipFormatString")]
	public static bool SetTipFormatString_Storage_Prefix(ref UIChartAstroStorage __instance)
	{
		if (TryGetIAFactoryIndex(__instance.statPlan.astroFilter, out var _))
		{
			if (__instance.titleTip != null && __instance.statPlan != null)
			{
				string text = "";
				text = text + $"#{__instance.statPlan.id} " + __instance.statPlan.displayName + ";";
				GameData gameData = __instance.statPlan.gameData;
				int astroFilter = __instance.statPlan.astroFilter;
				StarData starData = gameData.galaxy.StarById(astroFilter / 100);
				text = text + "星际组装厂".Translate() + starData.displayName + ";";
				__instance.titleTip.tipTextFormatString = text;
			}
			return false;
		}
		return true;
	}

	public static void Export(BinaryWriter w)
	{
		RearrangeStatisticLists();
		FactoryProductionStat[] factoryStatPool = GameMain.statistics.production.factoryStatPool;
		int num = GameMain.data.factories.Length;
		int num2 = ((factoryStatPool != null) ? (factoryStatPool.Length - num) : 0);
		if (num2 < 0)
		{
			num2 = 0;
		}
		w.Write(0);
		w.Write(num2);
		for (int i = num; i < num + num2; i++)
		{
			FactoryProductionStat factoryProductionStat = factoryStatPool[i];
			if (factoryProductionStat == null)
			{
				factoryProductionStat = new FactoryProductionStat();
				factoryProductionStat.Init();
				factoryStatPool[i] = factoryProductionStat;
			}
			factoryProductionStat.Export(w.BaseStream, w);
		}
	}

	public static void Import(BinaryReader r)
	{
		RearrangeStatisticLists();
		if (MoreMegaStructure.savedModVersion < 200)
		{
			return;
		}
		try
		{
			r.ReadInt32();
			int num = r.ReadInt32();
			FactoryProductionStat[] factoryStatPool = GameMain.statistics.production.factoryStatPool;
			int num2 = GameMain.data.factories.Length;
			int num3 = Math.Min(factoryStatPool.Length, num2 + num);
			for (int i = num2; i < num3; i++)
			{
				if (factoryStatPool[i] == null)
				{
					factoryStatPool[i] = new FactoryProductionStat();
					factoryStatPool[i].Init();
				}
				factoryStatPool[i].Import(r.BaseStream, r);
			}
		}
		catch (Exception)
		{
		}
	}

	public static void IntoOtherSave()
	{
		RearrangeStatisticLists();
	}

	public static int FactoryIndex2StarIndex(int factoryIndex)
	{
		return GameMain.data.factories.Length + GameMain.galaxy.starCount - factoryIndex - 1;
	}

	public static int StarIndex2FactoryIndex(int starIndex)
	{
		return GameMain.data.factories.Length + GameMain.galaxy.starCount - starIndex - 1;
	}
}
