using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace MoreMegaStructure
{
    // Virtual assembly factories belong to statistics only, never GameData.factories.
    public static class StatisticsCalculatorBridge
    {
        public static PlanetFactory Lookup(GameData gameData, int factoryIndex)
        {
            if (factoryIndex >= 0 && factoryIndex < gameData.factories.Length) return gameData.factories[factoryIndex];
            if (factoryIndex < gameData.factories.Length || factoryIndex >= gameData.factories.Length + gameData.galaxy.starCount)
                throw new ArgumentOutOfRangeException(nameof(factoryIndex));
            var proxy = new PlanetFactory();
            AccessTools.Property(typeof(PlanetFactory), "index").SetValue(proxy, factoryIndex, null);
            return proxy;
        }

        public static IEnumerable<CodeInstruction> ReplaceFactoryLookup(IEnumerable<CodeInstruction> instructions)
        {
            var code = new List<CodeInstruction>(instructions);
            FieldInfo factories = AccessTools.Field(typeof(GameData), nameof(GameData.factories));
            MethodInfo lookup = AccessTools.Method(typeof(StatisticsCalculatorBridge), nameof(Lookup));
            int replacements = 0;
            for (int i = 0; i + 2 < code.Count; i++)
            {
                if (!code[i].LoadsField(factories) || !code[i + 1].IsLdloc() || code[i + 2].opcode != OpCodes.Ldelem_Ref) continue;
                // Keep branch labels and exception boundaries at their existing positions.
                code[i].opcode = OpCodes.Nop; code[i].operand = null;
                code[i + 2].opcode = OpCodes.Call; code[i + 2].operand = lookup;
                replacements++;
            }
            if (replacements != 1) throw new InvalidOperationException("Production calculator factory lookup changed: " + replacements);
            return code;
        }

        public static bool CalculateFactoryPrefix(ProductionExtraInfoCalculator __instance, GameData gameData, PlanetFactory factory)
        {
            if (factory == null || factory.index < gameData.factories.Length) return true;
            UIStatisticsPatcher.CalculateFactory_IA(ref __instance, gameData, factory.index);
            return false;
        }
    }
}
