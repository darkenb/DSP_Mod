# Compact review package

The prepared ZIP is below **10,000,000 bytes**. Upload the existing `starfi5h-StatsUITweaks.zip`; do not ZIP the folder again with that archive inside it. The outer ZIP is excluded from its own payload and from `PACKAGE_SHA256SUMS.txt`.

All primary development code, focused changes, source comparisons and recorded checks are preserved. Full related-mod copies are replaced by project URLs, versions, exact local assembly identities and targeted source under `References/`. Read [RELATED_MODS.md](RELATED_MODS.md) and [RELATIONSHIPS.json](RELATIONSHIPS.json). Upstream HEAD may differ from these local snapshots.

## Primary files omitted for the size limit

- No primary mod resource or binary was omitted.

File sizes, hashes and preservation checks are in [PACKAGING.json](PACKAGING.json). Missing binary assets/resources must be restored from the matching original package before a full build or installation; do not execute a partial InstalledPackage as a complete mod installation. Reconstructed code still describes the captured DLL even when a large binary resource or DLL is omitted. The full original folder and the former ZIP are retained separately for the sender.

No mod was rebuilt, installed or live-game tested for this packaging operation. Historical scripts need their documented SDK, resources and machine-path adaptations.
