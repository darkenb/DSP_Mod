namespace ProjectGenesis.Patches;

public static class NegentropySmelterPatches
{
	public static void GameTick_AssemblerComponent_InternalUpdate_Patch(PlanetFactory factory, ref AssemblerComponent component, float power)
	{
		if (factory.entityPool[component.entityId].protoId == 2319 && component.replicating)
		{
			RecipeExecuteData recipeExecuteData = component.recipeExecuteData;
			component.extraTime += (int)(power * (float)component.extraSpeed) + (int)(power * (float)component.speedOverride * (float)recipeExecuteData.extraTimeSpend / (float)recipeExecuteData.timeSpend);
		}
	}
}
