using System;
using System.Collections.Generic;
using HarmonyLib;

namespace ProjectGenesis.Patches;

public static class InitialRecipePatches
{
	private static Dictionary<int, RecipeExecuteData> _originRecipeExecuteData;

	private static Dictionary<int, RecipeExecuteData> _modifiedRecipeExecuteData;

	private static bool _originInitialized;

	private static bool _modifiedInitialized;

	[HarmonyPatch(typeof(GameMain), "Start")]
	[HarmonyPrefix]
	public static void SetRecipeForGame()
	{
		if (DSPGame.LoadDemoIndex > 0 || DSPGame.IsMenuDemo)
		{
			if (_originInitialized)
			{
				RecipeProto.recipeExecuteData = _originRecipeExecuteData;
				return;
			}
			_originRecipeExecuteData = RecipeProto.recipeExecuteData ?? throw new ArgumentNullException();
			_originInitialized = true;
		}
		else if (_modifiedInitialized)
		{
			RecipeProto.recipeExecuteData = _modifiedRecipeExecuteData;
		}
		else
		{
			RecipeProto.InitRecipeItems();
			_modifiedRecipeExecuteData = RecipeProto.recipeExecuteData;
			_modifiedInitialized = true;
		}
	}
}
