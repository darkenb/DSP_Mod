using CommonAPI;
using HarmonyLib;

namespace BlueprintTweaks.PasteLocked;

[RegisterPatch("PasteLocked")]
public static class UIAssemblerWindow_Patch
{
	[HarmonyPatch(typeof(UIAssemblerWindow), "_OnUpdate")]
	[HarmonyPostfix]
	public static void OnUIUpdate(UIAssemblerWindow __instance)
	{
		if (__instance.assemblerId != 0 && __instance.factory != null && !__instance.factorySystem.assemblerPool[__instance.assemblerId].recipeIsLocked)
		{
			__instance.stateText.text = "recipeLockedWarn".Translate();
			__instance.stateText.color = __instance.workStoppedColor;
		}
	}
}
