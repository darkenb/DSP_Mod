using CommonAPI;
using HarmonyLib;

namespace BlueprintTweaks.PasteLocked;

[RegisterPatch("PasteLocked")]
public static class UILabWindow_Patch
{
	[HarmonyPatch(typeof(UILabWindow), "_OnUpdate")]
	[HarmonyPostfix]
	public static void OnUIUpdate(UILabWindow __instance)
	{
		if (__instance.labId != 0 && __instance.factory != null && !__instance.factorySystem.labPool[__instance.labId].recipeIsLocked)
		{
			__instance.stateText.text = "recipeLockedWarn".Translate();
			__instance.stateText.color = __instance.workStoppedColor;
		}
	}
}
