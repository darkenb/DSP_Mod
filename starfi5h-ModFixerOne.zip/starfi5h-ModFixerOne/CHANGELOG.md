# starfi5h-ModFixerOne — detailed change report

Installed plugin version(s): **2.1.2**. Resize imported buffers without losing count/inc; fail explicitly when shrinking/removing a recipe would discard occupied stock.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Import without silent buffer loss — 2.1.2

Use source matching installed 2.1.1. Retain native callbacks, serializer, plugin GUID and assembly identity.

- Resize assembler recipe buffers without clearing existing count/inc. Safe growth and shrinking an empty tail retain values.
- If shrinking would drop occupied buffers, or a removed recipe still has stock, stop import with an explicit error. Do not guess replacement item IDs, convert materials or overwrite a save with silently lost data. The old recipe/mod must be restored in that case.
- Mark post-LDB preload complete only after every initialization call succeeds.
- Keep native recipe/lens/vegetation data on current LDB/RecipeExecuteData paths; add no empty callback that replaces CommonAPI/Genesis/BlueprintTweaks injections.

Tests cover growth, empty/occupied tail shrinking and removed-recipe protection. Real save import and startup order remain unverified live.

## Separate preloader proposal: not installed

The installed preloader can generate duplicate members if applied twice to the same assembly. A separate idempotency proposal preserves compatible existing members and binds GameTick once. Two-application tests passed on disposable actual Assembly-CSharp, CoreModule and UI copies.

The proposal is under `Proposals/ModFixerOnePreloader-idempotent.zip`; its verification is `Evidence/InitialPhase/preloader-validation.json`. It was not installed. `InstalledPackage/patchers` and reconstructed preloader source represent the actual installed loader, whose single-application behavior remains. Do not mistake the proposal for the installed binary or apply it to native game files directly.

## Recorded source commits

- `3d77a1ebff3ed4d0b7c29aba4e1b9a6b61f7bea1`

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
