using System;
using System.IO;
using System.Linq;
using Mono.Cecil;
using ModFixerOne;

static class Check
{
    static string Contract(AssemblyDefinition assembly)
    {
        return string.Join("\n", assembly.MainModule.Types.SelectMany(t => new[] {"T " + t.FullName}.Concat(t.Fields.Select(f => "F " + f.FullName)).Concat(t.Methods.Select(m => "M " + m.FullName))))
            + string.Join("\n", assembly.MainModule.ExportedTypes.Select(t => "E " + t.FullName));
    }
    static int Main()
    {
        string game = "D:/Games/Dyson Sphere Program/DSPGAME_Data/Managed";
        Environment.CurrentDirectory = "D:/Games/Dyson Sphere Program";
        foreach (string name in Preloader.TargetDLLs)
        {
            using (var assembly = AssemblyDefinition.ReadAssembly(Path.Combine(game, name)))
            {
                Preloader.Patch(assembly);
                string first = Contract(assembly);
                var logic = assembly.MainModule.GetType("GameLogic");
                int calls = logic == null ? 0 : logic.Methods.Single(m => m.Name == "LogicFrame").Body.Instructions.Count(i => i.Operand is MethodReference method && method.DeclaringType.FullName == "GameData" && method.Name == "GameTick");
                if (name == "Assembly-CSharp.dll" && calls != 1) throw new Exception("Legacy callback count != 1");
                Preloader.Patch(assembly);
                if (first != Contract(assembly)) throw new Exception("Repeated preloader duplicates members: " + name);
                Console.WriteLine("PASS " + name + " repeated patch contract unchanged; GameTick calls=" + calls);
            }
        }
        return 0;
    }
}
