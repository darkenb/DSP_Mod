using System;
using System.Reflection;
using HarmonyLib;
using ModFixerOne.Mods;

static class Check
{
    static int Main()
    {
        var resize = AccessTools.Method(typeof(LDBTool_Patch), "ResizeBuffer");
        object[] grow = {new[] {7, 9}, 4}; resize.Invoke(null, grow);
        var result = (int[])grow[0];
        if (result.Length != 4 || result[0] != 7 || result[1] != 9) throw new Exception("Grow lost stock");
        object[] shrink = {new[] {7, 0}, 1}; resize.Invoke(null, shrink);
        if (((int[])shrink[0])[0] != 7) throw new Exception("Safe shrink lost stock");
        object[] unsafeShrink = {new[] {7, 9}, 1}; bool rejected = false;
        try { resize.Invoke(null, unsafeShrink); } catch (TargetInvocationException e) { rejected = e.InnerException is System.IO.InvalidDataException; }
        if (!rejected || ((int[])unsafeShrink[0]).Length != 2 || ((int[])unsafeShrink[0])[1] != 9) throw new Exception("Occupied tail silently removed");
        ModFixerOne.Plugin.Log = new BepInEx.Logging.ManualLogSource("Import check");
        object[] removed = {new AssemblerComponent {recipeId = 9912, served = new[] {7}, incServed = new[] {21}}};
        rejected = false;
        try { AccessTools.Method(typeof(LDBTool_Patch), "ValidateAndFixRecipeData").Invoke(null, removed); } catch (TargetInvocationException e) {rejected = e.InnerException is System.IO.InvalidDataException;}
        if (!rejected) throw new Exception("Removed recipe discarded stock");
        Console.WriteLine("PASS grow and safe shrink preserve stock, occupied tail and missing recipe rejected before data loss");
        return 0;
    }
}
