import sys
import hashlib
import json
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))
import build

phase = Path(__file__).resolve().parent
output = build.OUTPUT / phase.name / 'preloader'
original = build.PLUGINS.parent / 'patchers/starfi5h-ModFixerOne/ModFixerOnePreloader.dll'
target = output / original.name
refs = build.references() + [build.CORE / 'Mono.Cecil.dll']
build.compile_cs(sorted((phase / 'preloader-src').glob('*.cs')), target, refs)
check = output / 'Check.exe'
build.compile_cs([phase / 'preloader-check.cs'], check, refs + [target], executable=True)
new = build.run_check(check, [output, build.CORE, build.GAME])
if new.returncode:
    raise RuntimeError(new.stdout + new.stderr)
old_check = output / 'old-test/Check.exe'
build.compile_cs([phase / 'preloader-check.cs'], old_check, refs + [target], executable=True)
old = build.run_check(old_check, [original.parent, build.CORE, build.GAME])
if old.returncode == 0:
    raise RuntimeError('Original preloader already idempotent; revalidate correction')
if 'Repeated preloader duplicates members: Assembly-CSharp.dll' not in old.stderr:
    raise RuntimeError('Original test failed for an unexpected reason: ' + old.stderr)
result = dict(original_sha256=build.digest(original), built_sha256=build.digest(target), original_repeat_failed=True,
              corrected_repeat_passed=True, corrected_check=new.stdout, original_check=old.stderr,
              output=str(target), installed=False, install_target=str(original),
              installation_note='Outside writable workspace; staged package only. Current loader applies installed preloader once.',
              source_sha256={str(p.relative_to(phase)):build.digest(p) for p in sorted((phase/'preloader-src').glob('*.cs'))})
(phase/'preloader-validation.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
archive=phase/'ModFixerOnePreloader-idempotent.zip'
with zipfile.ZipFile(archive,'w',zipfile.ZIP_DEFLATED) as z:
    z.write(target,'patchers/starfi5h-ModFixerOne/ModFixerOnePreloader.dll')
    for p in sorted((phase/'preloader-src').glob('*.cs')): z.write(p,str(p.relative_to(phase)))
    for name in ('preloader-check.cs','build-preloader.py','preloader-validation.json'): z.write(phase/name,name)
archive.with_suffix('.zip.sha256').write_text(build.digest(archive)+'  '+archive.name+'\n',encoding='ascii')
print(new.stdout)
print('Original repeat failure reproduced; corrected preloader staged. Installed preloader unchanged.')
