using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Logging;
using HarmonyLib;
using Mono.Cecil;

namespace ModFixerOne;

public static class Preloader
{
	public static ManualLogSource logSource = Logger.CreateLogSource("ModFixerOne Preloader");

	public static IEnumerable<string> Guids;

	public static IEnumerable<string> TargetDLLs { get; } = new string[3] { "Assembly-CSharp.dll", "UnityEngine.CoreModule.dll", "UnityEngine.UI.dll" };

	public static void Patch(AssemblyDefinition assembly)
	{
		try
		{
			if (assembly.Name.Name == "Assembly-CSharp")
			{
				ModifyMainGame(assembly);
			}
			else if (assembly.Name.Name == "UnityEngine.CoreModule")
			{
				TypeForwardInput(assembly);
			}
			else if (assembly.Name.Name == "UnityEngine.UI")
			{
				RestoreMissingUI(assembly);
			}
			else
			{
				logSource.LogWarning("Unexpect assembly: " + assembly.Name.Name);
			}
		}
		catch (Exception data)
		{
			logSource.LogError("Error when patching assembly " + assembly.Name.Name);
			logSource.LogError(data);
		}
	}

	public static void Finish()
	{
		RemoveProcessFiler();
	}

	private static void TypeForwardInput(AssemblyDefinition assembly)
	{
		if (!File.Exists(Path.Combine(Directory.GetCurrentDirectory(), "DSPGAME_Data", "Managed", "UnityEngine.InputLegacyModule.dll")))
		{
			logSource.LogInfo("Skip type forward due to UnityEngine.InputLegacyModule doesn't exist");
			return;
		}
		ModuleDefinition mainModule = assembly.MainModule;
		AssemblyNameReference targetAssemblyRef = new AssemblyNameReference("UnityEngine.InputLegacyModule", new Version(0, 0, 0, 0));
		if (!mainModule.AssemblyReferences.Any((AssemblyNameReference ar) => ar.Name == targetAssemblyRef.Name))
		{
			mainModule.AssemblyReferences.Add(targetAssemblyRef);
		}
		ExportedType item = new ExportedType("UnityEngine", "Input", mainModule, targetAssemblyRef)
		{
			Attributes = (TypeAttributes.Public | TypeAttributes.Forwarder)
		};
		mainModule.ExportedTypes.Add(item);
		logSource.LogInfo("Type forward for UnityEngine.Input: UnityEngine.CoreModule => UnityEngine.InputLegacyModule");
	}

	private static void ModifyMainGame(AssemblyDefinition assembly)
	{
		try
		{
			assembly.MainModule.GetType("StationComponent").AddFied("name", assembly.MainModule.TypeSystem.String);
			logSource.LogDebug("string StationComponent.name");
			Injection.RefreshTraffic(assembly);
			logSource.LogDebug("void PlanetTransport.RefreshTraffic(int)");
			TypeDefinition enumType = Injection.Language(assembly);
			logSource.LogDebug("enum Language { zhCN, enUS, frFR, Max }");
			logSource.LogDebug("public static Language Localization.get_language()");
			Injection.StringTranslate(assembly, enumType);
			logSource.LogDebug("public static string StringTranslate.Translate(this string s)");
			Injection.StringProto(assembly);
			logSource.LogDebug("public StringProto");
			if (Injection.GameDataGameTick(assembly))
			{
				logSource.LogDebug("void GameData.GameTick(long)");
			}
		}
		catch (Exception data)
		{
			logSource.LogError("Error when patching!");
			logSource.LogError(data);
		}
	}

	private static void RestoreMissingUI(AssemblyDefinition assembly)
	{
		try
		{
			if (Injection.InputFieldReadOnly(assembly))
			{
				logSource.LogDebug("void InputField.readOnly");
			}
		}
		catch (Exception data)
		{
			logSource.LogError("Error when patching UnityEngine.UI.dll!");
			logSource.LogError(data);
		}
	}

	private static void RemoveProcessFiler()
	{
		try
		{
			Harmony harmony = new Harmony("ModFixerOnePreloader");
			harmony.Patch(AccessTools.Method(typeof(TypeLoader), "FindPluginTypes").MakeGenericMethod(typeof(PluginInfo)), null, new HarmonyMethod(AccessTools.Method(typeof(Preloader), "PostFindPluginTypes")));
			harmony.Patch(AccessTools.Method(typeof(Utility), "TopologicalSort").MakeGenericMethod(typeof(string)), null, new HarmonyMethod(AccessTools.Method(typeof(Preloader), "PostTopologicalSort")));
		}
		catch (Exception data)
		{
			logSource.LogError("Remove process filter & change load order fail!");
			logSource.LogError(data);
		}
	}

	private static void PostFindPluginTypes(Dictionary<string, List<PluginInfo>> __result)
	{
		try
		{
			int num = 0;
			foreach (List<PluginInfo> value in __result.Values)
			{
				foreach (PluginInfo item in value)
				{
					if (item.Processes.Any())
					{
						AccessTools.Property(typeof(PluginInfo), "Processes").SetValue(item, new List<BepInProcess>());
						num++;
					}
				}
			}
			logSource.LogDebug($"Remove process filter from {num} plugins.");
		}
		catch (Exception data)
		{
			logSource.LogWarning("Can't remove process filter!");
			logSource.LogWarning(data);
		}
	}

	private static void PostTopologicalSort(ref IEnumerable<string> __result)
	{
		IEnumerable<string> enumerable = __result.Where((string item) => item != "starfi5h.plugin.ModFixerOne");
		if (enumerable.Count() != __result.Count())
		{
			__result = new string[1] { "starfi5h.plugin.ModFixerOne" }.Concat(enumerable);
			logSource.LogDebug("Move ModFixerOne to first plugin to load.");
		}
		Guids = __result;
	}
}
