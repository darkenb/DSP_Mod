using System;
using System.Linq;
using Mono.Cecil;
using Mono.Cecil.Cil;

namespace ModFixerOne;

public static class Injection
{
	public static void AddFied(this TypeDefinition typeDefinition, string fieldName, TypeReference fieldType)
	{
		FieldDefinition item = new FieldDefinition(fieldName, FieldAttributes.Public, fieldType);
		typeDefinition.Fields.Add(item);
	}

	public static MethodDefinition AddMethod(this TypeDefinition typeDefinition, string methodName, TypeReference returnType, TypeReference[] parmeterTypes)
	{
		MethodDefinition methodDefinition = new MethodDefinition(methodName, MethodAttributes.Public, returnType);
		foreach (TypeReference parameterType in parmeterTypes)
		{
			methodDefinition.Parameters.Add(new ParameterDefinition(parameterType));
		}
		typeDefinition.Methods.Add(methodDefinition);
		return methodDefinition;
	}

	internal static void RefreshTraffic(AssemblyDefinition assembly)
	{
		ILProcessor iLProcessor = assembly.MainModule.GetType("PlanetTransport").AddMethod("RefreshTraffic", assembly.MainModule.TypeSystem.Void, new TypeReference[1] { assembly.MainModule.TypeSystem.Int32 }).Body.GetILProcessor();
		iLProcessor.Emit(OpCodes.Ldarg_0);
		iLProcessor.Emit(OpCodes.Ldarg_1);
		iLProcessor.Emit(method: assembly.MainModule.Types.First((TypeDefinition t) => t.FullName == "PlanetTransport").Methods.First((MethodDefinition m) => m.Name == "RefreshStationTraffic"), opcode: OpCodes.Call);
		iLProcessor.Emit(OpCodes.Ret);
	}

	internal static TypeDefinition Language(AssemblyDefinition assembly)
	{
		TypeDefinition typeDefinition = new TypeDefinition("", "Language", TypeAttributes.Public | TypeAttributes.Sealed, assembly.MainModule.ImportReference(typeof(Enum)));
		FieldAttributes attributes = FieldAttributes.Public | FieldAttributes.Static | FieldAttributes.Literal | FieldAttributes.HasDefault;
		typeDefinition.Fields.Add(new FieldDefinition("value__", FieldAttributes.Public | FieldAttributes.SpecialName | FieldAttributes.RTSpecialName, assembly.MainModule.TypeSystem.Int32));
		typeDefinition.Fields.Add(new FieldDefinition("zhCN", attributes, typeDefinition)
		{
			Constant = 0
		});
		typeDefinition.Fields.Add(new FieldDefinition("enUS", attributes, typeDefinition)
		{
			Constant = 1
		});
		typeDefinition.Fields.Add(new FieldDefinition("frFR", attributes, typeDefinition)
		{
			Constant = 2
		});
		typeDefinition.Fields.Add(new FieldDefinition("Max", attributes, typeDefinition)
		{
			Constant = 3
		});
		assembly.MainModule.Types.Add(typeDefinition);
		TypeDefinition typeDefinition2 = assembly.MainModule.Types.First((TypeDefinition t) => t.FullName == "Localization");
		FieldDefinition fieldDefinition = new FieldDefinition("lang", FieldAttributes.Public | FieldAttributes.Static, typeDefinition);
		typeDefinition2.Fields.Add(fieldDefinition);
		MethodDefinition methodDefinition = new MethodDefinition("get_language", MethodAttributes.Public | MethodAttributes.Static, typeDefinition);
		ILProcessor iLProcessor = methodDefinition.Body.GetILProcessor();
		iLProcessor.Emit(OpCodes.Ldsfld, fieldDefinition);
		iLProcessor.Emit(OpCodes.Ret);
		typeDefinition2.Methods.Add(methodDefinition);
		return typeDefinition;
	}

	internal static void StringTranslate(AssemblyDefinition assembly, TypeDefinition enumType)
	{
		TypeDefinition typeDefinition = new TypeDefinition("", "StringTranslate", TypeAttributes.Public, assembly.MainModule.TypeSystem.Object);
		assembly.MainModule.Types.Add(typeDefinition);
		MethodDefinition methodDefinition = new MethodDefinition("Translate", MethodAttributes.Public | MethodAttributes.Static, assembly.MainModule.TypeSystem.String);
		methodDefinition.Parameters.Add(new ParameterDefinition("s", ParameterAttributes.None, assembly.MainModule.TypeSystem.String));
		typeDefinition.Methods.Add(methodDefinition);
		ILProcessor iLProcessor = methodDefinition.Body.GetILProcessor();
		iLProcessor.Emit(OpCodes.Ldarg_0);
		iLProcessor.Emit(method: assembly.MainModule.Types.First((TypeDefinition t) => t.FullName == "Localization").Methods.First((MethodDefinition m) => m.Name == "Translate"), opcode: OpCodes.Call);
		iLProcessor.Emit(OpCodes.Ret);
		methodDefinition = new MethodDefinition("Translate", MethodAttributes.Public | MethodAttributes.Static, assembly.MainModule.TypeSystem.String);
		methodDefinition.Parameters.Add(new ParameterDefinition("s", ParameterAttributes.None, assembly.MainModule.TypeSystem.String));
		methodDefinition.Parameters.Add(new ParameterDefinition("_", ParameterAttributes.None, enumType));
		typeDefinition.Methods.Add(methodDefinition);
		ILProcessor iLProcessor2 = methodDefinition.Body.GetILProcessor();
		iLProcessor2.Emit(OpCodes.Ldarg_0);
		iLProcessor2.Emit(method: assembly.MainModule.Types.First((TypeDefinition t) => t.FullName == "Localization").Methods.First((MethodDefinition m) => m.Name == "Translate"), opcode: OpCodes.Call);
		iLProcessor2.Emit(OpCodes.Ret);
	}

	internal static void StringProto(AssemblyDefinition assembly)
	{
		TypeDefinition typeDefinition = assembly.MainModule.Types.First((TypeDefinition t) => t.FullName == "Proto");
		TypeDefinition typeDefinition2 = new TypeDefinition("", "StringProto", TypeAttributes.Public, assembly.MainModule.TypeSystem.Object)
		{
			BaseType = typeDefinition
		};
		CustomAttribute item = new CustomAttribute(assembly.MainModule.ImportReference(typeof(SerializableAttribute).GetConstructor(Type.EmptyTypes)));
		typeDefinition2.CustomAttributes.Add(item);
		MethodDefinition methodDefinition = new MethodDefinition(".ctor", MethodAttributes.Public | MethodAttributes.SpecialName | MethodAttributes.RTSpecialName, assembly.MainModule.TypeSystem.Void);
		ILProcessor iLProcessor = methodDefinition.Body.GetILProcessor();
		iLProcessor.Emit(OpCodes.Ldarg_0);
		iLProcessor.Emit(OpCodes.Call, assembly.MainModule.ImportReference(typeDefinition.Methods.First((MethodDefinition m) => m.Name == ".ctor")));
		iLProcessor.Emit(OpCodes.Ret);
		typeDefinition2.Methods.Add(methodDefinition);
		assembly.MainModule.Types.Add(typeDefinition2);
		typeDefinition2.AddFied("ZHCN", assembly.MainModule.TypeSystem.String);
		typeDefinition2.AddFied("ENUS", assembly.MainModule.TypeSystem.String);
		typeDefinition2.AddFied("FRFR", assembly.MainModule.TypeSystem.String);
	}

	internal static bool GameDataGameTick(AssemblyDefinition assembly)
	{
		TypeDefinition type = assembly.MainModule.GetType("GameData");
		if (type.Methods.FirstOrDefault((MethodDefinition m) => m.Name == "GameTick") != null)
		{
			return false;
		}
		MethodDefinition methodDefinition = type.AddMethod("GameTick", assembly.MainModule.TypeSystem.Void, new TypeReference[1] { assembly.MainModule.TypeSystem.Int64 });
		if (methodDefinition.Parameters.Count > 0)
		{
			methodDefinition.Parameters[0].Name = "time";
		}
		ILProcessor iLProcessor = methodDefinition.Body.GetILProcessor();
		iLProcessor.Emit(OpCodes.Ret);
		type = assembly.MainModule.GetType("GameLogic");
		FieldDefinition fieldDefinition = type.Fields.FirstOrDefault((FieldDefinition f) => f.Name == "data");
		FieldDefinition fieldDefinition2 = type.Fields.FirstOrDefault((FieldDefinition f) => f.Name == "timei");
		MethodDefinition methodDefinition2 = type.Methods.FirstOrDefault((MethodDefinition m) => m.Name == "LogicFrame");
		if (fieldDefinition == null || fieldDefinition2 == null || methodDefinition2 == null)
		{
			return false;
		}
		iLProcessor = methodDefinition2.Body.GetILProcessor();
		Instruction[] array = new Instruction[5]
		{
			iLProcessor.Create(OpCodes.Ldarg_0),
			iLProcessor.Create(OpCodes.Ldfld, fieldDefinition),
			iLProcessor.Create(OpCodes.Ldarg_0),
			iLProcessor.Create(OpCodes.Ldfld, fieldDefinition2),
			iLProcessor.Create(OpCodes.Callvirt, methodDefinition)
		};
		foreach (Instruction instruction in array)
		{
			Instruction target = methodDefinition2.Body.Instructions.Last();
			iLProcessor.InsertBefore(target, instruction);
		}
		return true;
	}

	internal static bool InputFieldReadOnly(AssemblyDefinition assembly)
	{
		ModuleDefinition mainModule = assembly.MainModule;
		TypeDefinition typeDefinition = mainModule.Types.FirstOrDefault((TypeDefinition t) => t.Name == "InputField");
		if (typeDefinition == null)
		{
			Console.WriteLine("Class 'InputField' not found.");
			return false;
		}
		if (typeDefinition.Properties.Any((PropertyDefinition p) => p.Name == "readOnly"))
		{
			Console.WriteLine("Property 'readOnly' already exists.");
			return false;
		}
		FieldDefinition fieldDefinition = typeDefinition.Fields.FirstOrDefault((FieldDefinition f) => f.Name == "m_ReadOnly");
		if (fieldDefinition == null)
		{
			Console.WriteLine("Field 'm_ReadOnly' not found. Cannot create property wrapper.");
			return false;
		}
		TypeReference boolean = mainModule.TypeSystem.Boolean;
		TypeReference returnType = mainModule.TypeSystem.Void;
		PropertyDefinition propertyDefinition = new PropertyDefinition("readOnly", PropertyAttributes.None, boolean);
		MethodAttributes attributes = MethodAttributes.Public | MethodAttributes.HideBySig | MethodAttributes.SpecialName;
		MethodDefinition methodDefinition = new MethodDefinition("get_readOnly", attributes, boolean);
		ILProcessor iLProcessor = methodDefinition.Body.GetILProcessor();
		iLProcessor.Emit(OpCodes.Ldarg_0);
		iLProcessor.Emit(OpCodes.Ldfld, fieldDefinition);
		iLProcessor.Emit(OpCodes.Ret);
		MethodDefinition methodDefinition2 = new MethodDefinition("set_readOnly", attributes, returnType);
		methodDefinition2.Parameters.Add(new ParameterDefinition("value", ParameterAttributes.None, boolean));
		ILProcessor iLProcessor2 = methodDefinition2.Body.GetILProcessor();
		iLProcessor2.Emit(OpCodes.Ldarg_0);
		iLProcessor2.Emit(OpCodes.Ldarg_1);
		iLProcessor2.Emit(OpCodes.Stfld, fieldDefinition);
		iLProcessor2.Emit(OpCodes.Ret);
		propertyDefinition.GetMethod = methodDefinition;
		propertyDefinition.SetMethod = methodDefinition2;
		typeDefinition.Methods.Add(methodDefinition);
		typeDefinition.Methods.Add(methodDefinition2);
		typeDefinition.Properties.Add(propertyDefinition);
		Console.WriteLine("Successfully injected property 'readOnly' into 'InputField'.");
		return true;
	}
}
