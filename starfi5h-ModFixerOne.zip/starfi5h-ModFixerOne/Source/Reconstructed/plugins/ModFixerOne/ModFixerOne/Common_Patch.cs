using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using HarmonyLib;

namespace ModFixerOne;

public static class Common_Patch
{
	[HarmonyPostfix]
	[HarmonyPatch(typeof(GameData), "Import")]
	public static void CheckAferImport()
	{
		if (GameMain.history.constructionDroneMovement > 4)
		{
			Plugin.Log.LogWarning($"Drone Task Points fix: {GameMain.history.constructionDroneMovement} => 4");
			GameMain.history.constructionDroneMovement = 4;
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(Localization), "NotifyLanguageChange")]
	public static void SwitchLanguage()
	{
		try
		{
			FieldInfo fieldInfo = AccessTools.Field(typeof(Localization), "lang");
			if (fieldInfo != null)
			{
				object value = Enum.ToObject(fieldInfo.FieldType, (!Localization.isZHCN) ? 1 : 0);
				fieldInfo.SetValue(null, value);
			}
		}
		catch (Exception data)
		{
			Plugin.Log.LogError(data);
		}
	}

	public static IEnumerable<CodeInstruction> UIInventory_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		try
		{
			return new CodeMatcher(instructions).MatchForward(false, new CodeMatch((CodeInstruction i) => i.opcode == OpCodes.Ldfld && ((FieldInfo)i.operand).Name == "inventory")).Repeat(delegate(CodeMatcher matcher)
			{
				matcher.SetAndAdvance(OpCodes.Ldfld, AccessTools.Field(typeof(UIGame), "inventoryWindow"));
			}).InstructionEnumeration();
		}
		catch (Exception ex)
		{
			Plugin.Log.LogWarning("UIInventory_Transpiler fail!\n" + ex);
			return instructions;
		}
	}
}
