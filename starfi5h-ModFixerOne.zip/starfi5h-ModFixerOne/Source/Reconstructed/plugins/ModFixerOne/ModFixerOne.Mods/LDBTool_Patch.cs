using System;
using System.Collections.Generic;
using System.IO;
using BepInEx.Bootstrap;
using HarmonyLib;
using xiaoye97;

namespace ModFixerOne.Mods;

public static class LDBTool_Patch
{
	private class Warper
	{
		[HarmonyPrefix]
		[HarmonyPatch(typeof(LDBTool), "PreAddProto", new Type[]
		{
			typeof(ProtoType),
			typeof(Proto)
		})]
		private static bool PreAddProto_Guard(ProtoType protoType)
		{
			//IL_0000: Unknown result type (might be due to invalid IL or missing references)
			//IL_0002: Invalid comparison between Unknown and I4
			return (int)protoType != 7;
		}

		[HarmonyPostfix]
		[HarmonyPatch(typeof(ProtoIndex), "GetAllProtoTypes")]
		private static void GetAllProtoTypes(ref Type[] __result)
		{
			if (__result[__result.Length - 1].FullName == "StringProto")
			{
				Plugin.Log.LogDebug("Remove StringProto from LDBTool ProtoTypes array");
				Type[] array = new Type[__result.Length - 1];
				Array.Copy(__result, array, array.Length);
				__result = array;
			}
		}
	}

	public const string NAME = "LDBTool";

	public const string GUID = "me.xiaoye97.plugin.Dyson.LDBTool";

	public const string VERSION = "3.0.1";

	private static bool IsGameLoaded;

	public static void Init(Harmony harmony)
	{
		if (!Chainloader.PluginInfos.TryGetValue("me.xiaoye97.plugin.Dyson.LDBTool", out var _))
		{
			return;
		}
		try
		{
			harmony.PatchAll(typeof(Warper));
			if (!(GameConfig.gameVersion < new Version(0, 10, 34)))
			{
				harmony.PatchAll(typeof(LDBTool_Patch));
			}
			Plugin.Log.LogInfo("LDBTool - OK");
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning("LDBTool - Fail! Last target version: 3.0.1");
			Fixer_Patch.ErrorMessage += "\nLDBTool (last target version: 3.0.1)";
			Plugin.Log.LogDebug(data);
		}
	}

	[HarmonyPostfix]
	[HarmonyAfter(new string[] { "me.xiaoye97.plugin.Dyson.LDBTool" })]
	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	private static void PreloadAndInitAll()
	{
		if (IsGameLoaded)
		{
			return;
		}
		Plugin.Log.LogInfo("PreloadAndInitAll");
		try
		{
			ItemProto.InitFuelNeeds();
			ItemProto.InitConstructableItems();
			ItemProto.InitItemIds();
			ItemProto.InitItemIndices();
			InitRecipeItems();
			SignalProtoSet.InitSignalKeyIdPairs();
			IsGameLoaded = true;
		}
		catch (Exception ex)
		{
			Plugin.Log.LogError("Error in PreloadAndInitAll\n" + ex.ToString());
			Fixer_Patch.ErrorMessage = Fixer_Patch.ErrorMessage + "Error in PreloadAndInitAll\n" + ex.ToString();
		}
	}

	private static void InitRecipeItems()
	{
		RecipeProto.recipeExecuteData = new Dictionary<int, RecipeExecuteData>();
		RecipeProto[] dataArray = LDB.recipes.dataArray;
		for (int i = 0; i < dataArray.Length; i++)
		{
			RecipeExecuteData value = new RecipeExecuteData(dataArray[i].Items, dataArray[i].ItemCounts, dataArray[i].Results, dataArray[i].ResultCounts, dataArray[i].TimeSpend * 10000, dataArray[i].TimeSpend * 100000, dataArray[i].productive);
			if (!RecipeProto.recipeExecuteData.ContainsKey(dataArray[i].ID))
			{
				RecipeProto.recipeExecuteData.Add(dataArray[i].ID, value);
			}
			else
			{
				Plugin.Log.LogWarning($"Duplicate RecipeId:{dataArray[i].ID} Name:{dataArray[i].Name}");
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPriority(600)]
	[HarmonyPatch(typeof(AssemblerComponent), "Import")]
	private static void ValidateAndFixRecipeData(ref AssemblerComponent __instance)
	{
		if (__instance.recipeId <= 0)
		{
			return;
		}
		if (__instance.recipeExecuteData == null)
		{
			if (HasStock(__instance.served) || HasStock(__instance.incServed) || HasStock(__instance.produced))
			{
				throw new InvalidDataException("Removed recipe has stored items: " + __instance.recipeId);
			}
			Plugin.Log.LogWarning($"Importing assembler {__instance.recipeType}: Can't find recipeId {__instance.recipeId}");
			__instance.recipeId = 0;
			__instance.recipeType = ERecipeType.None;
			__instance.recipeExecuteData = null;
			__instance.served = null;
			__instance.incServed = null;
			__instance.needs = null;
			__instance.produced = null;
			return;
		}
		int[] served = __instance.served;
		if (((served != null) ? served.Length : 0) == __instance.recipeExecuteData.requireCounts.Length)
		{
			int[] incServed = __instance.incServed;
			if (((incServed != null) ? incServed.Length : 0) == __instance.recipeExecuteData.requireCounts.Length)
			{
				goto IL_0140;
			}
		}
		Plugin.Log.LogWarning($"Importing assembler {__instance.recipeType}: requireCounts mismatch");
		ResizeBuffer(ref __instance.served, __instance.recipeExecuteData.requireCounts.Length);
		ResizeBuffer(ref __instance.incServed, __instance.recipeExecuteData.requireCounts.Length);
		goto IL_0140;
		IL_0140:
		int[] produced = __instance.produced;
		if (((produced != null) ? produced.Length : 0) != __instance.recipeExecuteData.productCounts.Length)
		{
			Plugin.Log.LogWarning($"Importing assembler {__instance.recipeType}: productCounts mismatch");
			ResizeBuffer(ref __instance.produced, __instance.recipeExecuteData.productCounts.Length);
		}
	}

	private static bool HasStock(int[] buffer)
	{
		if (buffer != null)
		{
			for (int i = 0; i < buffer.Length; i++)
			{
				if (buffer[i] != 0)
				{
					return true;
				}
			}
		}
		return false;
	}

	private static void ResizeBuffer(ref int[] buffer, int length)
	{
		if (buffer != null)
		{
			for (int i = length; i < buffer.Length; i++)
			{
				if (buffer[i] != 0)
				{
					throw new InvalidDataException("Recipe buffer shrink would remove stored items; restore the original recipe before loading.");
				}
			}
		}
		Array.Resize(ref buffer, length);
	}
}
