using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyVersion("2.1.1.0")]
[module: RefSafetyRules(11)]
