# Related mod references - starfi5h-ModFixerOne

Full related-mod packages are intentionally omitted. Project URLs, versions, exact local assembly hashes and targeted source files are supplied under `References/`. Upstream HEAD may differ from the locally modified snapshot. Build/runtime dependencies remain external prerequisites.

The source links below point to files actually present in this ZIP. Original line numbers and short excerpts are retained. A shared native integration point does not imply a direct DLL dependency.

## CommonAPI-CommonAPI

[Project identity and versions](References/CommonAPI-CommonAPI/reference.json) | [Reference notes](References/CommonAPI-CommonAPI/README.md)

Upstream: https://github.com/kremnev8/CommonAPI

- **fix_integration_context**: Post-LDB initialization must retain the CommonAPI preloader fields/callback contract.

### Code in this mod

[Source/Reconstructed/plugins/ModFixerOne/ModFixerOne.Mods/LDBTool_Patch.cs](Source/Reconstructed/plugins/ModFixerOne/ModFixerOne.Mods/LDBTool_Patch.cs) - original line 101

```csharp
	private static void InitRecipeItems()
	{
		RecipeProto.recipeExecuteData = new Dictionary<int, RecipeExecuteData>();
		RecipeProto[] dataArray = LDB.recipes.dataArray;
		for (int i = 0; i < dataArray.Length; i++)
```

[Source/EarlierWorkingSource/Mods/LDBTool_Patch.cs](Source/EarlierWorkingSource/Mods/LDBTool_Patch.cs) - original line 65

```csharp
        {
            // 為了避免Recipe同樣id衝突的情況發生, 在這裡使用修改後的函式
            RecipeProto.recipeExecuteData = new Dictionary<int, RecipeExecuteData>();
            RecipeProto[] dataArray = LDB.recipes.dataArray;
            for (int i = 0; i < dataArray.Length; i++)
```

[Source/Reconstructed/patchers/ModFixerOnePreloader/ModFixerOne/Preloader.cs](Source/Reconstructed/patchers/ModFixerOnePreloader/ModFixerOne/Preloader.cs) - original line 13

```csharp
namespace ModFixerOne;

public static class Preloader
{
	public static ManualLogSource logSource = Logger.CreateLogSource("ModFixerOne Preloader");
```

[Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs](Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs) - original line 18

```csharp
			if (!IsVaild())
			{
				ErrorMessage = "Can't find injected fields or methods!\n Please make sure that ModFixerOnePreloader.dll is installed in BepInEx\\patchers.";
				Plugin.Log.LogWarning(ErrorMessage);
				harmony.PatchAll(typeof(Fixer_Patch));
```

[Evidence/InitialPhase/preloader-check.cs](Evidence/InitialPhase/preloader-check.cs) - original line 18

```csharp
        string game = "D:/Games/Dyson Sphere Program/DSPGAME_Data/Managed";
        Environment.CurrentDirectory = "D:/Games/Dyson Sphere Program";
        foreach (string name in Preloader.TargetDLLs)
        {
            using (var assembly = AssemblyDefinition.ReadAssembly(Path.Combine(game, name)))
```

[Source/EarlierWorkingSource/Fixer_Patch.cs](Source/EarlierWorkingSource/Fixer_Patch.cs) - original line 28

```csharp
                if (!IsVaild())
                {
                    ErrorMessage = "Can't find injected fields or methods!\n Please make sure that ModFixerOnePreloader.dll is installed in BepInEx\\patchers.";
                    Plugin.Log.LogWarning(ErrorMessage);
                    harmony.PatchAll(typeof(Fixer_Patch));
```

### Code in the related reference

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/patchers/CommonAPIPreloader/CommonAPI/Preloader.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/patchers/CommonAPIPreloader/CommonAPI/Preloader.cs) - original line 9

```csharp
namespace CommonAPI;

public static class Preloader
{
	public static ManualLogSource logSource;
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 65

```csharp
		resource.LoadAssetBundle("commonapi");
		LoadSaveOnLoad.Init();
		harmony.PatchAll(typeof(VFPreloadPatch));
		CheckModuleForceLoad();
		logger.LogInfo("Common API is initialized!");
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/VFPreloadPatch.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/VFPreloadPatch.cs) - original line 6

```csharp

[HarmonyPatch]
public static class VFPreloadPatch
{
	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.ShotScene/RuntimeIconGenerator.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.ShotScene/RuntimeIconGenerator.cs) - original line 27

```csharp
	public float animPower = 1f;

	public bool preload;

	public bool loaded;
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/PickerExtensionsSystem.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/PickerExtensionsSystem.cs) - original line 49

```csharp
				for (int k = 0; k <= 10; k++)
				{
					LDB.signals.Select(j * 100 + k)?.Preload();
				}
			}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/ProtoRegistry.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/ProtoRegistry.cs) - original line 114

```csharp
			foreach (KeyValuePair<int, ModelProto> model in models)
			{
				model.Value.Preload();
				PrefabDesc prefabDesc = model.Value.prefabDesc;
				EnsureModelCapacity(ref LDB.models.modelArray, model.Value.ID);
```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 77

```csharp

            LoadSaveOnLoad.Init();
            harmony.PatchAll(typeof(VFPreloadPatch));
            
            CheckModuleForceLoad();
```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/Systems/PickerExtensionSystem/PickerExtensionsSystem.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/Systems/PickerExtensionSystem/PickerExtensionsSystem.cs) - original line 54

```csharp
                    {
                        SignalProto proto = LDB.signals.Select(i*100+j);
                        proto?.Preload();
                    }
                }
```

## CommonAPI-DSPModSave

[Project identity and versions](References/CommonAPI-DSPModSave/reference.json) | [Reference notes](References/CommonAPI-DSPModSave/README.md)

Upstream: https://github.com/kremnev8/DSP-Mods/tree/master/Mods/DSPModSave

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs) - original line 15

```csharp
namespace crecheng.DSPModSave;

[BepInPlugin("crecheng.DSPModSave", "DSP Mod Save", "1.2.3")]
public class DSPModSavePlugin : BaseUnityPlugin
{
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs) - original line 12

```csharp
	private static void EnterGame()
	{
		DSPModSavePlugin.logger.LogInfo("Enter New Game");
		foreach (ModSaveSettings value in DSPModSavePlugin.allModData.Values)
		{
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs) - original line 13

```csharp
		if (__result)
		{
			DSPModSavePlugin.OnSave(saveName);
		}
	}
```

[References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs](References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs) - original line 19

```csharp
static class Check
{
    static void Call(string method, params object[] args) {AccessTools.Method(typeof(DSPModSavePlugin), method).Invoke(null, args);}
    static int Main()
    {
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs) - original line 20

```csharp
{
    [BepInPlugin(MODGUID, MODNAME, VERSION)]
    public class DSPModSavePlugin : BaseUnityPlugin
    {
        public const string MODGUID = "crecheng.DSPModSave";
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs) - original line 12

```csharp
        static void EnterGame()
        {
            DSPModSavePlugin.logger.LogInfo("Enter New Game");
            foreach (var d in DSPModSavePlugin.allModData.Values)
            {
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs) - original line 14

```csharp
            if (!__result) return;

            DSPModSavePlugin.OnSave(saveName);
        }

```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 18

```csharp
[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
{
```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 31

```csharp
    [BepInPlugin(GUID, DISPNAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
    {
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 23

```csharp

[BepInPlugin("org.LoShin.GenesisBook", "GenesisBook", "3.2.6")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/ProjectGenesis.cs) - original line 40

```csharp
{
    [BepInPlugin(MODGUID, MODNAME, VERSION)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [BepInDependency(CommonAPIPlugin.GUID)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
```

## Galactic_Scale-GalacticScale

[Project identity and versions](References/Galactic_Scale-GalacticScale/reference.json) | [Reference notes](References/Galactic_Scale-GalacticScale/README.md)

Upstream: https://github.com/Touhma/DSP_Plugins

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/NebulaCompatibility.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/NebulaCompatibility.cs) - original line 20

```csharp
        {
            NebulaModAPI.RegisterPackets(Assembly.GetExecutingAssembly());
            GalacticScale.BCE.Console.Init();
            if (NebulaModAPI.NebulaIsInstalled)
            {
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/PluginInfo.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/PluginInfo.cs) - original line 6

```csharp
    {
        public const string PLUGIN_GUID = "dsp.galactic-scale.2";
        public const string PLUGIN_NAME = "GalacticScale";
        public const string PLUGIN_VERSION = "2.80.9";
    }
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Generators/Sol/Sol.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Generators/Sol/Sol.cs) - original line 276

```csharp
            stars.Clear();
            // GS2.Error("Test");
            //string path = Path.Combine(Path.Combine(Path.Combine(Path.Combine(Paths.BepInExRootPath, "plugins"), "GalacticScale"), "data"), "galaxy.json");
            var serializer = new fsSerializer();
            //string json = File.ReadAllText(path);
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Init.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Init.cs) - original line 16

```csharp
        private static readonly string AssemblyPath = Path.GetDirectoryName(Assembly.GetAssembly(typeof(GS2)).Location);
        private static readonly string OldDataDir = Path.Combine(AssemblyPath, "config");
        public static readonly string DataDir = Path.Combine(Paths.ConfigPath, "GalacticScale2");
        public static bool Failed = false;
        public static string updateMessage = "";
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/IO/Plugins.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/IO/Plugins.cs) - original line 44

```csharp
            foreach (var g in Generators)
            {
                Log("GalacticScale2|LoadPlugins|Loading Generator:" + g.Name);
                g.Init();
            }
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/IO/Save_Load.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/IO/Save_Load.cs) - original line 33

```csharp
            // var isVanilla = true;
            fsData data2 = null;
            var parseResult = fsResult.Fail("DSV contains no legacy GalacticScale settings.");
            try
            {
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Localization/GSLocalization.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Localization/GSLocalization.cs) - original line 46

```csharp
        {
            var entries = new Dictionary<string, string>(StringComparer.Ordinal);
            var name = $"GalacticScale.Translations.{language}.tsv";
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
            {
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/CosmicMessageManager/LateUpdate.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/CosmicMessageManager/LateUpdate.cs) - original line 21

```csharp
//  * 
//  * The original method assumes arrays are initialized and messageData is set,
//  * which may not be true during GalacticScale's extended initialization.
//  * 
//  * Changes from original:
```

### Dependency reference code

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GalacticScale.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GalacticScale.cs) - original line 17

```csharp
internal static class GalacticScale
{
	internal const string GUID = "dsp.galactic-scale.2";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.dsp.galactic-scale.2");
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/InstallationCheckPlugin.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/InstallationCheckPlugin.cs) - original line 15

```csharp
[BepInDependency("org.kremnev8.plugin.BlueprintTweaks", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("Gnimaerd.DSP.plugin.MoreMegaStructure", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.galactic-scale.2", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("930f5bae-66d2-4917-988b-162fe2456643", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("testpostpleaseignore.dsp.planet_vein_utilization", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Compatibility/GalacticScale.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Compatibility/GalacticScale.cs) - original line 21

```csharp
    internal static class GalacticScale
    {
        internal const string GUID = "dsp.galactic-scale.2";

        private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility." + GUID);
```

## HiddenCirno-GenesisBook

[Project identity and versions](References/HiddenCirno-GenesisBook/reference.json) | [Reference notes](References/HiddenCirno-GenesisBook/README.md)

Upstream: https://github.com/Awbugl/ProjectGenesis

- **fix_integration_context**: Safe assembler import and post-LDB initialization preserve Genesis recipe buffers and preloader additions.

### Code in this mod

[Source/Reconstructed/plugins/ModFixerOne/ModFixerOne.Mods/LDBTool_Patch.cs](Source/Reconstructed/plugins/ModFixerOne/ModFixerOne.Mods/LDBTool_Patch.cs) - original line 101

```csharp
	private static void InitRecipeItems()
	{
		RecipeProto.recipeExecuteData = new Dictionary<int, RecipeExecuteData>();
		RecipeProto[] dataArray = LDB.recipes.dataArray;
		for (int i = 0; i < dataArray.Length; i++)
```

[Source/EarlierWorkingSource/Mods/LDBTool_Patch.cs](Source/EarlierWorkingSource/Mods/LDBTool_Patch.cs) - original line 65

```csharp
        {
            // 為了避免Recipe同樣id衝突的情況發生, 在這裡使用修改後的函式
            RecipeProto.recipeExecuteData = new Dictionary<int, RecipeExecuteData>();
            RecipeProto[] dataArray = LDB.recipes.dataArray;
            for (int i = 0; i < dataArray.Length; i++)
```

[Evidence/InitialPhase/check.cs](Evidence/InitialPhase/check.cs) - original line 20

```csharp
        if (!rejected || ((int[])unsafeShrink[0]).Length != 2 || ((int[])unsafeShrink[0])[1] != 9) throw new Exception("Occupied tail silently removed");
        ModFixerOne.Plugin.Log = new BepInEx.Logging.ManualLogSource("Import check");
        object[] removed = {new AssemblerComponent {recipeId = 9912, served = new[] {7}, incServed = new[] {21}}};
        rejected = false;
        try { AccessTools.Method(typeof(LDBTool_Patch), "ValidateAndFixRecipeData").Invoke(null, removed); } catch (TargetInvocationException e) {rejected = e.InnerException is System.IO.InvalidDataException;}
```

[Source/Reconstructed/patchers/ModFixerOnePreloader/ModFixerOne/Preloader.cs](Source/Reconstructed/patchers/ModFixerOnePreloader/ModFixerOne/Preloader.cs) - original line 13

```csharp
namespace ModFixerOne;

public static class Preloader
{
	public static ManualLogSource logSource = Logger.CreateLogSource("ModFixerOne Preloader");
```

[Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs](Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs) - original line 18

```csharp
			if (!IsVaild())
			{
				ErrorMessage = "Can't find injected fields or methods!\n Please make sure that ModFixerOnePreloader.dll is installed in BepInEx\\patchers.";
				Plugin.Log.LogWarning(ErrorMessage);
				harmony.PatchAll(typeof(Fixer_Patch));
```

[Evidence/InitialPhase/preloader-check.cs](Evidence/InitialPhase/preloader-check.cs) - original line 18

```csharp
        string game = "D:/Games/Dyson Sphere Program/DSPGAME_Data/Managed";
        Environment.CurrentDirectory = "D:/Games/Dyson Sphere Program";
        foreach (string name in Preloader.TargetDLLs)
        {
            using (var assembly = AssemblyDefinition.ReadAssembly(Path.Combine(game, name)))
```

[Source/EarlierWorkingSource/Fixer_Patch.cs](Source/EarlierWorkingSource/Fixer_Patch.cs) - original line 28

```csharp
                if (!IsVaild())
                {
                    ErrorMessage = "Can't find injected fields or methods!\n Please make sure that ModFixerOnePreloader.dll is installed in BepInEx\\patchers.";
                    Plugin.Log.LogWarning(ErrorMessage);
                    harmony.PatchAll(typeof(Fixer_Patch));
```

### Code in the related reference

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/InitialRecipePatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/InitialRecipePatches.cs) - original line 9

```csharp
public static class InitialRecipePatches
{
	private static Dictionary<int, RecipeExecuteData> _originRecipeExecuteData;

	private static Dictionary<int, RecipeExecuteData> _modifiedRecipeExecuteData;
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/MegaAssemblerPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/MegaAssemblerPatches.cs) - original line 348

```csharp
				if (num >= 0)
				{
					RecipeExecuteData recipeExecuteData = __instance.recipeExecuteData;
					if (num < recipeExecuteData.products.Length)
					{
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/MultiProductionPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/MultiProductionPatches.cs) - original line 101

```csharp
			return;
		}
		int[] products = assemblerComponent.recipeExecuteData.products;
		int num = products.Length;
		if (num <= 2)
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/NegentropySmelterPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/NegentropySmelterPatches.cs) - original line 9

```csharp
		if (factory.entityPool[component.entityId].protoId == 2319 && component.replicating)
		{
			RecipeExecuteData recipeExecuteData = component.recipeExecuteData;
			component.extraTime += (int)(power * (float)component.extraSpeed) + (int)(power * (float)component.speedOverride * (float)recipeExecuteData.extraTimeSpend / (float)recipeExecuteData.timeSpend);
		}
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/ProductOverflowPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/ProductOverflowPatches.cs) - original line 28

```csharp
	public static bool AssemblerComponent_InsertMethod(ref AssemblerComponent component, int[] productRegister)
	{
		RecipeExecuteData recipeExecuteData = component.recipeExecuteData;
		int num = recipeExecuteData.products.Length;
		int[] products = recipeExecuteData.products;
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Patches/Hooks/InitialRecipePatches.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Patches/Hooks/InitialRecipePatches.cs) - original line 11

```csharp
    public static class InitialRecipePatches
    {
        private static Dictionary<int, RecipeExecuteData> _originRecipeExecuteData, _modifiedRecipeExecuteData;
        private static bool _originInitialized, _modifiedInitialized;

```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Patches/Hooks/MegaAssembler/MegaAssemblerPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Patches/Hooks/MegaAssembler/MegaAssemblerPatches.cs) - original line 74

```csharp
                    if (index2 >= 0)
                    {
                        RecipeExecuteData executeData = __instance.recipeExecuteData;

                        if (index2 < executeData.products.Length)
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Patches/Hooks/MegaAssembler/SetFilterPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Patches/Hooks/MegaAssembler/SetFilterPatches.cs) - original line 96

```csharp
            if (assemblerComponent.recipeId > 0)
            {
                RecipeExecuteData executeData = assemblerComponent.recipeExecuteData;
                filterItems.AddRange(executeData.products);
                filterItems.AddRange(executeData.requires);
```

## kremnev8-BlueprintTweaks

[Project identity and versions](References/kremnev8-BlueprintTweaks/reference.json) | [Reference notes](References/kremnev8-BlueprintTweaks/README.md)

Upstream: https://github.com/kremnev8/DSP-Mods/tree/master/Mods/BlueprintTweaks

- **fix_integration_context**: The preloader assessment preserves existing blueprint-added members rather than duplicating or replacing them.

### Code in this mod

[Source/Reconstructed/patchers/ModFixerOnePreloader/ModFixerOne/Preloader.cs](Source/Reconstructed/patchers/ModFixerOnePreloader/ModFixerOne/Preloader.cs) - original line 13

```csharp
namespace ModFixerOne;

public static class Preloader
{
	public static ManualLogSource logSource = Logger.CreateLogSource("ModFixerOne Preloader");
```

[Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs](Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs) - original line 18

```csharp
			if (!IsVaild())
			{
				ErrorMessage = "Can't find injected fields or methods!\n Please make sure that ModFixerOnePreloader.dll is installed in BepInEx\\patchers.";
				Plugin.Log.LogWarning(ErrorMessage);
				harmony.PatchAll(typeof(Fixer_Patch));
```

[Evidence/InitialPhase/preloader-check.cs](Evidence/InitialPhase/preloader-check.cs) - original line 18

```csharp
        string game = "D:/Games/Dyson Sphere Program/DSPGAME_Data/Managed";
        Environment.CurrentDirectory = "D:/Games/Dyson Sphere Program";
        foreach (string name in Preloader.TargetDLLs)
        {
            using (var assembly = AssemblyDefinition.ReadAssembly(Path.Combine(game, name)))
```

[Source/EarlierWorkingSource/Fixer_Patch.cs](Source/EarlierWorkingSource/Fixer_Patch.cs) - original line 28

```csharp
                if (!IsVaild())
                {
                    ErrorMessage = "Can't find injected fields or methods!\n Please make sure that ModFixerOnePreloader.dll is installed in BepInEx\\patchers.";
                    Plugin.Log.LogWarning(ErrorMessage);
                    harmony.PatchAll(typeof(Fixer_Patch));
```

### Code in the related reference

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/patchers/BlueprintTweaksPatcher/BlueprintTweaks/Preloader.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/patchers/BlueprintTweaksPatcher/BlueprintTweaks/Preloader.cs) - original line 48

```csharp
			typeDefinition.Fields.Add(new FieldDefinition("anchorType", FieldAttributes.Public, mainModule.ImportReference(typeof(int))));
			typeDefinition.Fields.Add(new FieldDefinition("autoReformMode", FieldAttributes.Public, mainModule.ImportReference(typeof(int))));
			typeDefinition2.Fields.Add(new FieldDefinition("recipeIsLocked", FieldAttributes.Public, mainModule.ImportReference(typeof(bool))));
			typeDefinition3.Fields.Add(new FieldDefinition("recipeIsLocked", FieldAttributes.Public, mainModule.ImportReference(typeof(bool))));
			logSource.LogInfo("Preloader patching is successful!");
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.PasteLocked/AssemblerComponent_Patch.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.PasteLocked/AssemblerComponent_Patch.cs) - original line 13

```csharp
	public static bool CheckAssemblerRecipe(ref AssemblerComponent __instance)
	{
		if (!__instance.recipeIsLocked)
		{
			__instance.recipeIsLocked = GameMain.history.RecipeUnlocked(__instance.recipeId);
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.PasteLocked/LabComponent_Patch.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.PasteLocked/LabComponent_Patch.cs) - original line 13

```csharp
	public static bool CheckAssemblerRecipe(ref LabComponent __instance)
	{
		if (!__instance.recipeIsLocked)
		{
			__instance.recipeIsLocked = GameMain.history.RecipeUnlocked(__instance.recipeId);
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.PasteLocked/UIAssemblerWindow_Patch.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.PasteLocked/UIAssemblerWindow_Patch.cs) - original line 13

```csharp
	public static void OnUIUpdate(UIAssemblerWindow __instance)
	{
		if (__instance.assemblerId != 0 && __instance.factory != null && !__instance.factorySystem.assemblerPool[__instance.assemblerId].recipeIsLocked)
		{
			__instance.stateText.text = "recipeLockedWarn".Translate();
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.PasteLocked/UILabWindow_Patch.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.PasteLocked/UILabWindow_Patch.cs) - original line 13

```csharp
	public static void OnUIUpdate(UILabWindow __instance)
	{
		if (__instance.labId != 0 && __instance.factory != null && !__instance.factorySystem.labPool[__instance.labId].recipeIsLocked)
		{
			__instance.stateText.text = "recipeLockedWarn".Translate();
```

[References/kremnev8-BlueprintTweaks/Code/Source/EarlierWorkingSource/PasteLocked/AssemblerComponent_Patch.cs](References/kremnev8-BlueprintTweaks/Code/Source/EarlierWorkingSource/PasteLocked/AssemblerComponent_Patch.cs) - original line 13

```csharp
        public static bool CheckAssemblerRecipe(ref AssemblerComponent __instance)
        {
            if (!__instance.recipeIsLocked)
            {
                __instance.recipeIsLocked = GameMain.history.RecipeUnlocked(__instance.recipeId);
```

[References/kremnev8-BlueprintTweaks/Code/Source/EarlierWorkingSource/PasteLocked/LabComponent_Patch.cs](References/kremnev8-BlueprintTweaks/Code/Source/EarlierWorkingSource/PasteLocked/LabComponent_Patch.cs) - original line 13

```csharp
        public static bool CheckAssemblerRecipe(ref LabComponent __instance)
        {
            if (!__instance.recipeIsLocked)
            {
                __instance.recipeIsLocked = GameMain.history.RecipeUnlocked(__instance.recipeId);
```

[References/kremnev8-BlueprintTweaks/Code/Source/EarlierWorkingSource/PasteLocked/UIAssemblerWindow_Patch.cs](References/kremnev8-BlueprintTweaks/Code/Source/EarlierWorkingSource/PasteLocked/UIAssemblerWindow_Patch.cs) - original line 20

```csharp
            AssemblerComponent assemblerComponent = __instance.factorySystem.assemblerPool[__instance.assemblerId];

            if (!assemblerComponent.recipeIsLocked)
            {
                __instance.stateText.text = "recipeLockedWarn".Translate();
```

## nebula-NebulaMultiplayerModApi

[Project identity and versions](References/nebula-NebulaMultiplayerModApi/reference.json) | [Reference notes](References/nebula-NebulaMultiplayerModApi/README.md)

Upstream: https://github.com/NebulaModTeam/nebula

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs) - original line 15

```csharp
[BepInPlugin("dsp.nebula-multiplayer-api", "NebulaMultiplayerModApi", "2.1.0.7")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class NebulaModAPI : BaseUnityPlugin
{
	public const string NEBULA_MODID = "dsp.nebula-multiplayer";
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs) - original line 5

```csharp
namespace NebulaAPI.DataStructures;

public static class CollectionExtensions
{
	public static Locker Lock(this ICollection collection)
```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs) - original line 13

```csharp

[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Bootstrap.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Bootstrap.cs) - original line 20

```csharp
    [BepInPlugin("dsp.galactic-scale.2", "Galactic Scale 2 Plug-In", "2.80.9")]
    [BepInDependency("space.customizing.console", BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("lltcggie.DSP.plugin.PlanetwidePlanetaryShieldGenerator", BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("un1eagle.planetwideshield", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/GalacticScale/Bootstrap.cs](References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/GalacticScale/Bootstrap.cs) - original line 14

```csharp
[BepInPlugin("dsp.galactic-scale.2", "Galactic Scale 2 Plug-In", "2.80.9")]
[BepInDependency("space.customizing.console", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("lltcggie.DSP.plugin.PlanetwidePlanetaryShieldGenerator", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("un1eagle.planetwideshield", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/NebulaCompatibility/Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod.cs](References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/NebulaCompatibility/Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod.cs) - original line 13

```csharp

[BepInPlugin("dsp.galactic-scale.2.nebula", "Galactic Scale 2 Nebula Compatibility Plug-In", "1.0.0.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
public class Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod : BaseUnityPlugin, IMultiplayerModWithSettings, IMultiplayerMod
{
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 26

```csharp
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.LoShin.GenesisBook.InstallationCheck", BepInDependency.DependencyFlags.SoftDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/BlueprintTweaksPlugin.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/BlueprintTweaksPlugin.cs) - original line 26

```csharp

[BepInPlugin("org.kremnev8.plugin.BlueprintTweaks", "Blueprint Tweaks", "1.6.14")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "CustomKeyBindSystem", "PickerExtensionsSystem", "LocalizationModule" })]
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.InstallCheck/InstallationChecker.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.InstallCheck/InstallationChecker.cs) - original line 35

```csharp
			ldbToolInstalled = true;
		}
		if (Chainloader.PluginInfos.ContainsKey("dsp.nebula-multiplayer-api"))
		{
			nebulaAPIInstalled = true;
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.InstallCheck/UIMainMenuPatch.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.InstallCheck/UIMainMenuPatch.cs) - original line 26

```csharp
				text += "  - Plugin \"LDB Tool\" is missing\n";
			}
			if (!InstallationChecker.nebulaAPIInstalled)
			{
				text += "  - Plugin \"Nebula Multiplayer Mod API\" is missing\n";
```

## xiaoye97-LDBTool

[Project identity and versions](References/xiaoye97-LDBTool/reference.json) | [Reference notes](References/xiaoye97-LDBTool/README.md)

Upstream: https://github.com/xiaoye97/DSP_LDBTool

- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Code in this mod

[Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs](Source/Reconstructed/plugins/ModFixerOne/ModFixerOne/Fixer_Patch.cs) - original line 48

```csharp
			}
			harmony.PatchAll(typeof(Common_Patch));
			LDBTool_Patch.Init(harmony);
			if (ErrorMessage != "")
			{
```

[Source/Reconstructed/plugins/ModFixerOne/ModFixerOne.Mods/LDBTool_Patch.cs](Source/Reconstructed/plugins/ModFixerOne/ModFixerOne.Mods/LDBTool_Patch.cs) - original line 10

```csharp
namespace ModFixerOne.Mods;

public static class LDBTool_Patch
{
	private class Warper
```

[Evidence/InitialPhase/check.cs](Evidence/InitialPhase/check.cs) - original line 10

```csharp
    static int Main()
    {
        var resize = AccessTools.Method(typeof(LDBTool_Patch), "ResizeBuffer");
        object[] grow = {new[] {7, 9}, 4}; resize.Invoke(null, grow);
        var result = (int[])grow[0];
```

[Source/EarlierWorkingSource/Fixer_Patch.cs](Source/EarlierWorkingSource/Fixer_Patch.cs) - original line 62

```csharp

                harmony.PatchAll(typeof(Common_Patch));
                LDBTool_Patch.Init(harmony);
                if (ErrorMessage != "")
                {
```

[Source/EarlierWorkingSource/Mods/LDBTool_Patch.cs](Source/EarlierWorkingSource/Mods/LDBTool_Patch.cs) - original line 8

```csharp
namespace ModFixerOne.Mods
{
    public static class LDBTool_Patch
    {
        public const string NAME = "LDBTool";
```

### Code in the related reference

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs) - original line 11

```csharp
namespace xiaoye97;

public static class LDBTool
{
	public static Action PreAddDataAction;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs) - original line 11

```csharp
namespace xiaoye97;

[BepInPlugin("me.xiaoye97.plugin.Dyson.LDBTool", "LDBTool", "3.0.4")]
public class LDBToolPlugin : BaseUnityPlugin
{
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs) - original line 16

```csharp
	internal static void InitIndex()
	{
		LDBToolPlugin.logger.LogDebug("Generating Proto type list:");
		protoTypes = (from domainAssembly in AppDomain.CurrentDomain.GetAssemblies()
			from assemblyType in GetTypesSafe(domainAssembly)
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs) - original line 19

```csharp
		if (__instance.recipeExecuteData == null)
		{
			LDBToolPlugin.logger.LogWarning($"Importing assembler {__instance.recipeType}: Can't find recipeId {__instance.recipeId}");
			__instance.recipeId = 0;
			__instance.recipeType = ERecipeType.None;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs) - original line 12

```csharp
	private static void HistoryPatch(GameHistoryData __instance)
	{
		foreach (Proto item in LDBTool.TotalDict[ProtoIndex.GetIndex(typeof(RecipeProto))])
		{
			RecipeProto recipeProto = item as RecipeProto;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/UITip_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/UITip_Patch.cs) - original line 12

```csharp
	private static void ItemTipPatch(UIItemTip __instance, int itemId)
	{
		if (LDBToolPlugin.ShowProto.Value)
		{
			__instance.nameText.text += $" {itemId}";
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/VFPreload_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/VFPreload_Patch.cs) - original line 15

```csharp
	private static void VFPreloadPrePatch()
	{
		if (!LDBTool.Finshed)
		{
			LDBToolPlugin.logger.LogInfo("Pre Loading...");
```

[References/xiaoye97-LDBTool/Code/Evidence/InitialPhase/check.cs](References/xiaoye97-LDBTool/Code/Evidence/InitialPhase/check.cs) - original line 53

```csharp
            return null;
        };
        try { plugin = Assembly.LoadFrom(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "LDBTool.dll")); Run(); }
        catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }
    }
```
