using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Runtime.Serialization;
using HarmonyLib;
using LogisticsBotsTweaks;

static class Check
{
    static T Empty<T>() => (T)FormatterServices.GetUninitializedObject(typeof(T));
    static Type Patch(string name) => typeof(Plugin).Assembly.GetType("LogisticsBotsTweaks." + name);
    static object Call(Type type, string name, params object[] args) => type.GetMethod(name).Invoke(null, args);
    static void Set(object target, string name, object value)
    {
        var field = AccessTools.Field(target.GetType(), name) ?? AccessTools.Field(target.GetType(), "<" + name + ">k__BackingField");
        if (field != null) field.SetValue(target, value); else AccessTools.Property(target.GetType(), name).SetValue(target, value, null);
    }
    static void Assert(bool value, string name) { if (!value) throw new Exception(name); Console.WriteLine("PASS " + name); }
    static int Main()
    {
        var bot = Patch("Patch_LogisticsBot"); var distributor = Patch("Patch_Distributor");
        var config = Empty<Configs>(); var mode = Empty<ModeConfig>(); mode.logisticCourierSpeed = 20; Set(config, "m_freeMode", mode);
        AccessTools.Field(typeof(Configs), "instance").SetValue(null, config);
        var data = Empty<GameData>(); var player = new Player(); Set(data, "mainPlayer", player); Set(player, "mecha", new Mecha()); GameMain.data = data;
        var history = Empty<GameHistoryData>(); history.logisticCourierSpeed = 20; history.logisticCourierSpeedScale = 1.5f;
        bot.GetField("logisticsBotSpeedScale").SetValue(null, 2f);
        Call(bot, "LogisticCourierSpeedModified", history);
        Assert(history.logisticCourierSpeedModified == 60 && history.logisticCourierSpeedScale == 1.5f, "native research scale and configured base speed compose correctly");
        history.UnlockTechFunction(34, 0.2, 1); Call(bot, "LogisticCourierSpeedModified", history);
        Assert(Math.Abs(history.logisticCourierSpeedModified - 68) < 0.001, "actual native courier research adds to separate scale");
        Call(bot, "LogisticCourierSpeedModified", history); Call(bot, "LogisticCourierSpeedModified", history);
        Assert(Math.Abs(history.logisticCourierSpeedModified - 68) < 0.001, "repeated load/unlock adjustment does not compound speed");
        distributor.GetField("dispenserMaxCourierCount").SetValue(null, 20);
        var component = new DispenserComponent {workCourierDatas = new CourierData[10], orders = new DeliveryLogisticOrder[10], holdupPackage = new DispenserStore[20], idleCourierCount = 3, workCourierCount = 2};
        component.workCourierDatas[1].itemId = 1001; component.holdupPackage[1].itemId = 1002; component.holdupPackage[1].count = 7;
        Call(distributor, "Expand", component);
        Assert(component.workCourierDatas.Length == 20 && component.orders.Length == 20 && component.holdupPackage.Length == 40
            && component.workCourierDatas[1].itemId == 1001 && component.holdupPackage[1].count == 7,
            "native courier and holdup data preserved across aligned expansion");
        var first = component.workCourierDatas; Call(distributor, "Expand", component);
        Assert(ReferenceEquals(first, component.workCourierDatas), "repeated expansion is idempotent");
        component.courierAutoReplenish = true; component.holdupItemCount = 2;
        var saved = new MemoryStream(); component.Export(new BinaryWriter(saved)); saved.Position = 0;
        distributor.GetField("dispenserMaxCourierCount").SetValue(null, 30);
        var importPatch = new Harmony("test.bots.native.import");
        importPatch.Patch(AccessTools.Method(typeof(DispenserComponent), "Import"), postfix: new HarmonyMethod(distributor.GetMethod("Import")));
        DispenserComponent loaded;
        try { loaded = new DispenserComponent(); loaded.Import(new BinaryReader(saved)); }
        finally { importPatch.UnpatchSelf(); }
        Assert(loaded.workCourierDatas.Length == 30 && loaded.orders.Length == 30 && loaded.holdupPackage.Length == 60
            && loaded.workCourierDatas[1].itemId == 1001 && loaded.holdupPackage[1].count == 7 && loaded.courierAutoReplenish,
            "actual native save import expands arrays and preserves cargo and new auto replenish flag");
        var autoQuantity = typeof(DSP_Mods.AutoLogisticsDroneSetup).Assembly.GetType("DSP_Mods.FillQuantity").GetMethod("Needed");
        Assert((int)autoQuantity.Invoke(null, new object[] {loaded.workCourierDatas.Length, loaded.idleCourierCount, loaded.workCourierCount, -1}) == 25,
            "phase10 filling agrees with phase11 imported capacity and existing workers");
        var window = Empty<UIDispenserWindow>(); window.factory = Empty<PlanetFactory>(); window.factory.transport = Empty<PlanetTransport>();
        window.factory.transport.dispenserPool = new[] {null, component}; Set(window, "_dispenserId", 1);
        Assert((int)Call(distributor, "EffectiveUICapacity", 30, window) == 30, "UI cannot shrink higher native prefab capacity");
        distributor.GetField("dispenserMaxCourierCount").SetValue(null, 10);
        Assert((int)Call(distributor, "EffectiveUICapacity", 10, window) == 20, "UI preserves expanded imported runtime capacity");
        foreach (var name in new[] {"OnCourierIconClick", "OnDispenserIdChange"})
        {
            var original = PatchProcessor.GetOriginalInstructions(AccessTools.Method(typeof(UIDispenserWindow), name));
            var patched = ((IEnumerable<CodeInstruction>)Call(distributor, name + "_Transpiler", original)).ToArray();
            if (name == "OnCourierIconClick") Assert(patched.Count(i => i.Calls(distributor.GetMethod("EffectiveUICapacity"))) == 1, "native courier UI capacity IL matched once");
            else Assert(patched.Count(i => i.LoadsField(distributor.GetField("maxChargePowerScale"))) == 1, "native charge slider IL anchored to correct field once");
        }
        return 0;
    }
}
