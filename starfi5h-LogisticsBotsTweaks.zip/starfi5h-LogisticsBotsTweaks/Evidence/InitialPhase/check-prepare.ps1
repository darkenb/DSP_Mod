param([string]$Game, [string]$Core, [string]$Output)
$ErrorActionPreference = 'Stop'
Add-Type -Path (Join-Path $Core 'Mono.Cecil.dll')
$source = Join-Path $Game 'Assembly-CSharp.dll'
$originalHash = (Get-FileHash -LiteralPath $source).Hash
$resolver = New-Object Mono.Cecil.DefaultAssemblyResolver
$resolver.AddSearchDirectory($Game)
$resolver.AddSearchDirectory($Core)
$parameters = New-Object Mono.Cecil.ReaderParameters
$parameters.AssemblyResolver = $resolver
$assembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly($source, $parameters)
New-Item -ItemType Directory -Force -Path $Output | Out-Null
$boundaryNames = @()
$nativeBodies = @{}
foreach ($type in $assembly.MainModule.Types) {
    foreach ($method in $type.Methods) {
        if ($method.HasBody) { $nativeBodies[$method.FullName] = ($method.Body.Instructions | ForEach-Object ToString) -join "`n" }
    }
}
try {
    # Replace only environment boundaries in a disposable TEST reference. This
    # permits Harmony to compile the endpoints on desktop CLR without Unity ECalls.
    # All forge/task/storage/history methods are untouched.
    $boundaries = @(,@('Configs', 'get_freeMode'))
    foreach ($entry in $boundaries) {
        $type = $assembly.MainModule.Types | Where-Object FullName -eq $entry[0]
        $method = @($type.Methods | Where-Object Name -eq $entry[1])
        if ($method.Count -ne 1) { throw "Ambiguous/missing test endpoint $($entry -join '::')" }
        $boundaryNames += $method[0].FullName
        $body = New-Object Mono.Cecil.Cil.MethodBody($method[0])
        $method[0].Body = $body
        $il = $body.GetILProcessor()
        $instanceField = $type.Fields | Where-Object Name -eq 'instance'
        $modeField = $type.Fields | Where-Object Name -eq 'm_freeMode'
        $il.Append($il.Create([Mono.Cecil.Cil.OpCodes]::Ldsfld, [Mono.Cecil.FieldReference]$instanceField))
        $il.Append($il.Create([Mono.Cecil.Cil.OpCodes]::Ldfld, [Mono.Cecil.FieldReference]$modeField))
        $il.Append($il.Create([Mono.Cecil.Cil.OpCodes]::Ret))
        Write-Output ('TEST boundary sink: ' + ($entry -join '::'))
    }
    $assembly.Write((Join-Path $Output 'Assembly-CSharp.dll'))
} finally { $assembly.Dispose(); $resolver.Dispose() }
$testAssembly = [Mono.Cecil.AssemblyDefinition]::ReadAssembly((Join-Path $Output 'Assembly-CSharp.dll'))
try {
    $checked = 0
    foreach ($type in $testAssembly.MainModule.Types) {
        foreach ($method in $type.Methods) {
            if (!$method.HasBody -or $method.FullName -in $boundaryNames) { continue }
            $body = ($method.Body.Instructions | ForEach-Object ToString) -join "`n"
            if ($body -ne $nativeBodies[$method.FullName]) { throw "Unexpected test IL change: $($method.FullName)" }
            $checked++
        }
    }
    Write-Output "Verified $checked top-level method bodies unchanged; only one Configs Unity-object boundary replaced."
} finally { $testAssembly.Dispose() }
if ((Get-FileHash -LiteralPath $source).Hash -ne $originalHash) { throw 'Original game reference changed' }
Write-Output 'Native history upgrade/getter and logistics IL unchanged; original game DLL untouched.'
