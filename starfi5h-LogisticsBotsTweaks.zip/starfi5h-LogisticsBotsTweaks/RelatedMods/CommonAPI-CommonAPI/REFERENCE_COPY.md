# Related-mod reference copy

Copied for review of `starfi5h-LogisticsBotsTweaks`. It contains this related mod's own installed files, sources, explanation and evidence, with no recursively nested RelatedMods directory. The receiving package's `../../RELATED_MODS.md` is the relationship index. Do not install this entire handoff tree as one plugin package.
