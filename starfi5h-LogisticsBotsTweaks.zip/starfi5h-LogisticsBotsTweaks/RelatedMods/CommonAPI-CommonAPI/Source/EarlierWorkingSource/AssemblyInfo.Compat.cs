using System.Reflection;
[assembly: AssemblyVersion("1.6.7.0")]
[assembly: AssemblyFileVersion("1.6.8.0")]
[assembly: AssemblyInformationalVersion("1.6.8-compat+87e5135e5325fc0d02b98ceb91347e406022618b")]
internal static class ThisAssembly
{
    public const string AssemblyVersion = "1.6.8.0";
}
