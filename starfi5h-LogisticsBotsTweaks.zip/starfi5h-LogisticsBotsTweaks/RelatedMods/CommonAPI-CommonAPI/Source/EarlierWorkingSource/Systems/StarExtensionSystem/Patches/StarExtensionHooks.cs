using System;
using CommonAPI.Systems;
using HarmonyLib;

namespace CommonAPI.Patches
{
    [HarmonyPatch]
    public static class StarExtensionHooks
    {
        public static void DrawCall(GameData __instance, int frame) { StarExtensionSystem.DrawUpdate(); }
        public static void PowerTickMultithread(DysonSphere __instance, int _usedThreadCnt, int _curThreadIdx) { StarExtensionSystem.UpdateMultithread(__instance.starData, _usedThreadCnt, _curThreadIdx, 12); }
        [HarmonyPatch(typeof(GameLogic), "Draw")]
        [HarmonyPostfix]
        public static void DrawCall() { StarExtensionSystem.DrawUpdate(); }

        [HarmonyPatch(typeof(GameLogic), "OnGameLogicFrame")]
        [HarmonyFinalizer]
        public static Exception UpdateFrame(Exception __exception, GameLogic __instance, int iTask,
            int threadOrdinal, int threadCount, GalaxyData ___galaxy)
        {
            if (iTask != (int)EGameLogicTask.DysonSphereRocket) return __exception;
            try {
                ExtensionTickDispatch.Synchronize(__instance, threadOrdinal, threadCount, () => {
                    if (___galaxy == null || ___galaxy.stars == null) return;
                    foreach (var star in ___galaxy.stars) {
                        if (star == null) continue;
                        for (int j = 1; j < StarExtensionSystem.extensions.Count; j++) {
                            var storage = StarExtensionSystem.extensions[j];
                            if (storage == null) continue;
                            ExtensionTickDispatch.Run(storage.GetSystem(star), 2, threadOrdinal, threadCount, 12);
                        }
                    }
                });
            } catch (Exception callbackError) {
                return __exception == null ? callbackError : new AggregateException(__exception, callbackError);
            }
            return __exception;
        }
    }
}
