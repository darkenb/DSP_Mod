using System;
using System.Collections.Generic;
using System.IO;

namespace CommonAPI;

public static class EntityDataExtensions
{
	public static Dictionary<string, IPropertySerializer> propertySerializers = new Dictionary<string, IPropertySerializer>();

	public static void DefineProperty(string key, IPropertySerializer serializer)
	{
		if (propertySerializers.ContainsKey(key))
		{
			propertySerializers[key] = serializer;
		}
		else
		{
			propertySerializers.Add(key, serializer);
		}
	}

	public static bool HasProperty(this ref EntityData desc, string name)
	{
		if (desc.customData == null)
		{
			desc.customData = new Dictionary<string, object>();
		}
		return desc.customData.ContainsKey(name);
	}

	public static void SetProperty<T>(this ref EntityData desc, string name, T value)
	{
		if (!propertySerializers.ContainsKey(name) || propertySerializers[name] == null)
		{
			throw new ArgumentException("Can't set property " + name + " of type " + value.GetType().FullName + " because serializer for it was not defined!");
		}
		Type targetType = propertySerializers[name].GetTargetType();
		if (targetType != value.GetType())
		{
			throw new ArgumentException("Can't set property " + name + " of type " + value.GetType().FullName + " because serializer defined for " + name + " is for type " + targetType.FullName + "!");
		}
		if (desc.customData == null)
		{
			desc.customData = new Dictionary<string, object>();
		}
		if (desc.customData.ContainsKey(name))
		{
			desc.customData[name] = value;
		}
		else
		{
			desc.customData.Add(name, value);
		}
	}

	public static T GetProperty<T>(this ref EntityData desc, string name)
	{
		if (desc.customData == null)
		{
			desc.customData = new Dictionary<string, object>();
		}
		if (desc.customData.ContainsKey(name))
		{
			return (T)desc.customData[name];
		}
		return default(T);
	}

	public static T GetOrAddProperty<T>(this ref EntityData desc, string name) where T : new()
	{
		if (desc.customData == null)
		{
			desc.customData = new Dictionary<string, object>();
		}
		if (desc.customData.ContainsKey(name))
		{
			return (T)desc.customData[name];
		}
		T val = new T();
		desc.customData.Add(name, val);
		return val;
	}

	public static void ExportData(ref EntityData data, BinaryWriter w)
	{
		if (data.customData != null)
		{
			w.Write((byte)data.customData.Count);
			{
				foreach (KeyValuePair<string, object> customDatum in data.customData)
				{
					w.Write(customDatum.Key);
					propertySerializers[customDatum.Key].Export(customDatum.Value, w);
				}
				return;
			}
		}
		w.Write((byte)0);
	}

	public static void ImportData(ref EntityData data, BinaryReader r)
	{
		int num = r.ReadByte();
		for (int i = 0; i < num; i++)
		{
			string text = r.ReadString();
			object value = propertySerializers[text].Import(r);
			data.SetProperty(text, value);
		}
	}
}
