namespace CommonAPI.Systems;

public static class RecipeExtensions
{
	public static bool BelongsToType(this RecipeProto proto, int typeId)
	{
		AssemblerRecipeSystem.Instance.ThrowIfNotLoaded();
		if (typeId >= AssemblerRecipeSystem.recipeTypeLists.Count)
		{
			return false;
		}
		return AssemblerRecipeSystem.recipeTypeLists[typeId].BinarySearch(proto.ID) >= 0;
	}
}
