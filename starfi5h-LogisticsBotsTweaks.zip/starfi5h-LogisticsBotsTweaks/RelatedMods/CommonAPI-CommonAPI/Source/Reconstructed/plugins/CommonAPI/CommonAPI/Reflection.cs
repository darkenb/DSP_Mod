using System;
using System.Collections;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using Mono.Cecil.Cil;
using MonoMod.Utils;

namespace CommonAPI;

public static class Reflection
{
	private delegate T GetDelegate<out T>(object instance);

	private delegate void SetDelegate<in T>(object instance, T value);

	private delegate void SetDelegateRef<TInstance, in TValue>(ref TInstance instance, TValue value) where TInstance : struct;

	private delegate T GetDelegateRef<TInstance, out T>(ref TInstance instance) where TInstance : struct;

	private const BindingFlags AllFlags = BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic;

	private static readonly ConcurrentDictionary<(Type T, string name), FieldInfo> FieldCache = new ConcurrentDictionary<(Type, string), FieldInfo>();

	private static readonly ConcurrentDictionary<FieldInfo, Delegate> FieldGetDelegateCache = new ConcurrentDictionary<FieldInfo, Delegate>();

	private static readonly ConcurrentDictionary<FieldInfo, Delegate> FieldSetDelegateCache = new ConcurrentDictionary<FieldInfo, Delegate>();

	private static readonly ConcurrentDictionary<(Type T, string name), PropertyInfo> PropertyCache = new ConcurrentDictionary<(Type, string), PropertyInfo>();

	private static readonly ConcurrentDictionary<PropertyInfo, Delegate> PropertyGetDelegateCache = new ConcurrentDictionary<PropertyInfo, Delegate>();

	private static readonly ConcurrentDictionary<PropertyInfo, Delegate> PropertySetDelegateCache = new ConcurrentDictionary<PropertyInfo, Delegate>();

	private static readonly ConcurrentDictionary<(Type T, string name), MethodInfo> MethodCache = new ConcurrentDictionary<(Type, string), MethodInfo>();

	private static readonly ConcurrentDictionary<(Type T, string name, Type[] argumentTypes), MethodInfo> OverloadedMethodCache = new ConcurrentDictionary<(Type, string, Type[]), MethodInfo>();

	private static readonly ConcurrentDictionary<MethodInfo, FastReflectionDelegate> DelegateCache = new ConcurrentDictionary<MethodInfo, FastReflectionDelegate>();

	private static readonly ConcurrentDictionary<(Type T, Type[] argumentTypes), ConstructorInfo> ConstructorCache = new ConcurrentDictionary<(Type, Type[]), ConstructorInfo>();

	private static readonly ConcurrentDictionary<(Type T, string name), Type> NestedTypeCache = new ConcurrentDictionary<(Type, string), Type>();

	private static TValue GetOrAddOnNull<TKey, TValue>(this ConcurrentDictionary<TKey, TValue> dict, TKey key, Func<TKey, TValue> factory)
	{
		if (dict.TryGetValue(key, out TValue value) && value != null)
		{
			return value;
		}
		return dict[key] = factory(key);
	}

	public static FieldInfo GetFieldCached<T>(string? name)
	{
		return typeof(T).GetFieldCached(name);
	}

	public static FieldInfo GetFieldCached(this Type? T, string? name)
	{
		return FieldCache.GetOrAddOnNull<(Type, string), FieldInfo>((T, name), ((Type T, string name) x) => x.T.GetFieldFull(x.name) ?? throw new Exception("Could not find FieldInfo on " + T.FullName + " with the name " + name));
	}

	public static TReturn GetFieldValue<TReturn>(this object? instance, string? fieldName)
	{
		return instance.GetType().GetFieldCached(fieldName).GetFieldGetDelegate<TReturn>()(instance);
	}

	public static TReturn GetFieldValue<TReturn>(this Type? staticType, string? fieldName)
	{
		return staticType.GetFieldCached(fieldName).GetFieldGetDelegate<TReturn>()(null);
	}

	public static void SetFieldValue<TValue>(this object? instance, string? fieldName, TValue value)
	{
		instance.GetType().GetFieldCached(fieldName).GetFieldSetDelegate<TValue>()(instance, value);
	}

	public static void SetFieldValue<TValue>(this Type? staticType, string? fieldName, TValue value)
	{
		staticType.GetFieldCached(fieldName).GetFieldSetDelegate<TValue>()(null, value);
	}

	public static void SetStructFieldValue<TInstance, TValue>(this ref TInstance instance, string? fieldName, TValue value) where TInstance : struct
	{
		typeof(TInstance).GetFieldCached(fieldName).GetFieldSetDelegateRef<TInstance, TValue>()(ref instance, value);
	}

	private static FieldInfo GetFieldFull(this Type T, string name)
	{
		while (T != null)
		{
			FieldInfo field = T.GetField(name, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
			if (field != null)
			{
				return field;
			}
			T = T.BaseType;
		}
		return null;
	}

	private static T GetMemberFull<T>(this Type type, string name) where T : MemberInfo
	{
		while (type != null)
		{
			MemberInfo[] member = type.GetMember(name, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
			if (member != null)
			{
				return (T)member.First();
			}
			type = type.BaseType;
		}
		return null;
	}

	private static GetDelegate<TReturn> GetFieldGetDelegate<TReturn>(this FieldInfo field)
	{
		return FieldGetDelegateCache.GetOrAdd(field, (FieldInfo x) => x.CreateGetDelegate<TReturn>()).CastDelegate<GetDelegate<TReturn>>();
	}

	private static SetDelegate<TValue> GetFieldSetDelegate<TValue>(this FieldInfo field)
	{
		return FieldSetDelegateCache.GetOrAdd(field, (FieldInfo x) => x.CreateSetDelegate<TValue>()).CastDelegate<SetDelegate<TValue>>();
	}

	private static SetDelegateRef<TInstance, TValue> GetFieldSetDelegateRef<TInstance, TValue>(this FieldInfo field) where TInstance : struct
	{
		return FieldSetDelegateCache.GetOrAdd(field, (FieldInfo x) => x.CreateSetDelegateRef<TInstance, TValue>()).CastDelegate<SetDelegateRef<TInstance, TValue>>();
	}

	public static PropertyInfo GetPropertyCached<T>(string? name)
	{
		return typeof(T).GetPropertyCached(name);
	}

	public static PropertyInfo GetPropertyCached(this Type? T, string? name)
	{
		return PropertyCache.GetOrAddOnNull<(Type, string), PropertyInfo>((T, name), ((Type T, string name) x) => x.T.GetProperty(x.name, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic));
	}

	public static TReturn GetPropertyValue<TReturn>(this object? instance, string? propName)
	{
		return instance.GetType().GetPropertyCached(propName).GetPropertyGetDelegate<TReturn>()(instance);
	}

	public static TReturn GetPropertyValue<TReturn>(this Type? staticType, string? propName)
	{
		return staticType.GetPropertyCached(propName).GetPropertyGetDelegate<TReturn>()(null);
	}

	public static void SetPropertyValue<TValue>(this object? instance, string? propName, TValue value)
	{
		PropertyInfo propertyCached = instance.GetType().GetPropertyCached(propName);
		if ((object)propertyCached != null)
		{
			propertyCached.GetPropertySetDelegate<TValue>()(instance, value);
		}
	}

	public static void SetPropertyValue<TValue>(this Type? staticType, string? propName, TValue value)
	{
		PropertyInfo propertyCached = staticType.GetPropertyCached(propName);
		if ((object)propertyCached != null)
		{
			propertyCached.GetPropertySetDelegate<TValue>()(null, value);
		}
	}

	public static void SetStructPropertyValue<TInstance, TValue>(this ref TInstance instance, string? propName, TValue value) where TInstance : struct
	{
		typeof(TInstance).GetPropertyCached(propName).GetPropertySetDelegateRef<TInstance, TValue>()(ref instance, value);
	}

	public static TValue GetStructPropertyValue<TInstance, TValue>(this ref TInstance instance, string? propName) where TInstance : struct
	{
		return typeof(TInstance).GetPropertyCached(propName).GetPropertyGetDelegateRef<TInstance, TValue>()(ref instance);
	}

	public static MethodInfo GetPropertyGetter(this Type type, string nameOfProperty)
	{
		return type.GetProperty(nameOfProperty, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic).GetGetMethod(nonPublic: true);
	}

	public static MethodInfo GetPropertySetter(this Type type, string nameOfProperty)
	{
		return type.GetProperty(nameOfProperty, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic).GetSetMethod(nonPublic: true);
	}

	private static GetDelegate<TReturn> GetPropertyGetDelegate<TReturn>(this PropertyInfo property)
	{
		return PropertyGetDelegateCache.GetOrAdd(property, (PropertyInfo prop) => prop.CreateGetDelegate<TReturn>()).CastDelegate<GetDelegate<TReturn>>();
	}

	private static GetDelegateRef<TInstance, TReturn> GetPropertyGetDelegateRef<TInstance, TReturn>(this PropertyInfo property) where TInstance : struct
	{
		return PropertyGetDelegateCache.GetOrAdd(property, (PropertyInfo prop) => prop.CreateGetDelegate<TInstance, TReturn>()).CastDelegate<GetDelegateRef<TInstance, TReturn>>();
	}

	private static SetDelegate<TValue> GetPropertySetDelegate<TValue>(this PropertyInfo property)
	{
		return PropertySetDelegateCache.GetOrAdd(property, (PropertyInfo prop) => prop.CreateSetDelegate<TValue>()).CastDelegate<SetDelegate<TValue>>();
	}

	private static SetDelegateRef<TInstance, TValue> GetPropertySetDelegateRef<TInstance, TValue>(this PropertyInfo property) where TInstance : struct
	{
		return PropertySetDelegateCache.GetOrAdd(property, (PropertyInfo prop) => prop.CreateSetDelegateRef<TInstance, TValue>()).CastDelegate<SetDelegateRef<TInstance, TValue>>();
	}

	public static MethodInfo GetMethodCached<T>(string? name)
	{
		return typeof(T).GetMethodCached(name);
	}

	public static MethodInfo GetMethodCached(this Type? T, string? name)
	{
		return MethodCache.GetOrAddOnNull<(Type, string), MethodInfo>((T, name), ((Type T, string name) x) => x.T.GetMethod(x.name, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic) ?? throw new Exception("Could not find MethodInfo on " + T.FullName + " with the name " + name));
	}

	public static MethodInfo GetMethodWithConstructedGenericParameter(this Type? T, string? name, Type? genericTypeDefinition)
	{
		return T.GetMethods().First(delegate(MethodInfo method)
		{
			if (method.Name != name)
			{
				return false;
			}
			Type parameterType = method.GetParameters().First().ParameterType;
			if (!parameterType.IsConstructedGenericType)
			{
				return false;
			}
			Type type = parameterType.GetGenericArguments().First();
			return parameterType == genericTypeDefinition.MakeGenericType(type);
		});
	}

	public static MethodInfo GetMethodCached<T>(string? name, Type?[]? argumentTypes)
	{
		return typeof(T).GetMethodCached(name, argumentTypes);
	}

	public static MethodInfo GetMethodCached(this Type? T, string? name, Type?[]? argumentTypes)
	{
		return OverloadedMethodCache.GetOrAddOnNull<(Type, string, Type[]), MethodInfo>((T, name, argumentTypes), ((Type T, string name, Type[] argumentTypes) x) => x.T.GetMethod(x.name, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic, null, x.argumentTypes, null) ?? throw new Exception("Could not find MethodInfo on " + T.FullName + " with the name " + name + " and arguments: " + string.Join(",", argumentTypes.Select((Type a) => a.FullName))));
	}

	public static TReturn InvokeMethod<TReturn>(this object? instance, string? methodName)
	{
		return instance.InvokeMethod<TReturn>(methodName, null);
	}

	public static TReturn InvokeMethod<TReturn>(this Type? staticType, string? methodName)
	{
		return staticType.InvokeMethod<TReturn>(methodName, null);
	}

	public static void InvokeMethod(this object? instance, string? methodName)
	{
		instance.InvokeMethod<object>(methodName);
	}

	public static void InvokeMethod(this Type? staticType, string? methodName)
	{
		staticType.InvokeMethod<object>(methodName);
	}

	public static TReturn InvokeMethod<TReturn>(this object? instance, string? methodName, params object[] methodParams)
	{
		return (TReturn)(((methodParams == null) ? instance.GetType().GetMethodCached(methodName) : instance.GetType().GetMethodCached(methodName, methodParams.Select((object x) => x.GetType()).ToArray())) ?? throw new Exception($"Could not find method on type {instance.GetType()} with the name of {methodName} with the arguments specified.")).GetMethodDelegateCached()(instance, methodParams);
	}

	public static TReturn InvokeMethod<TReturn>(this Type? staticType, string? methodName, params object[] methodParams)
	{
		return (TReturn)(((methodParams == null) ? staticType.GetMethodCached(methodName) : staticType.GetMethodCached(methodName, methodParams.Select((object x) => x.GetType()).ToArray())) ?? throw new Exception($"Could not find method on type {staticType} with the name of {methodName} with the arguments specified.")).GetMethodDelegateCached()(null, methodParams);
	}

	public static void InvokeMethod(this object? instance, string? methodName, params object?[]? methodParams)
	{
		instance.InvokeMethod<object>(methodName, methodParams);
	}

	public static void InvokeMethod(this Type? staticType, string? methodName, params object?[]? methodParams)
	{
		staticType.InvokeMethod<object>(methodName, methodParams);
	}

	private static FastReflectionDelegate GetMethodDelegateCached(this MethodInfo methodInfo)
	{
		return DelegateCache.GetOrAdd(methodInfo, (MethodInfo method) => method.GenerateCallDelegate());
	}

	public static ConstructorInfo GetConstructorCached<T>(Type?[]? argumentTypes)
	{
		return typeof(T).GetConstructorCached(argumentTypes);
	}

	public static ConstructorInfo GetConstructorCached(this Type? T, Type?[]? argumentTypes)
	{
		return ConstructorCache.GetOrAddOnNull<(Type, Type[]), ConstructorInfo>((T, argumentTypes), ((Type T, Type[] argumentTypes) x) => x.T.GetConstructor(x.argumentTypes) ?? throw new Exception("Could not find ConstructorInfo on " + T.FullName + " with the arguments " + string.Join(",", argumentTypes.Select((Type a) => a.FullName))));
	}

	public static Type GetNestedType<T>(string? name)
	{
		return typeof(T).GetNestedTypeCached(name);
	}

	public static Type GetNestedTypeCached<T>(string? name)
	{
		return typeof(T).GetNestedTypeCached(name);
	}

	public static Type GetNestedTypeCached(this Type? T, string? name)
	{
		return NestedTypeCache.GetOrAddOnNull<(Type, string), Type>((T, name), ((Type T, string name) x) => x.T.GetNestedType(x.name, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic) ?? throw new Exception("Could not find nested Type on " + T.FullName + " with the name " + name));
	}

	public static object Instantiate(this Type? type)
	{
		return Activator.CreateInstance(type, nonPublic: true);
	}

	public static object Instantiate(this Type? type, params object?[]? constructorArguments)
	{
		return type.GetConstructorCached(constructorArguments.Select((object x) => x.GetType()).ToArray()).Invoke(constructorArguments);
	}

	public static object InstantiateGeneric<TClass>(this Type? typeArgument)
	{
		return typeof(TClass).MakeGenericType(typeArgument).Instantiate();
	}

	public static object InstantiateGeneric<TClass>(this Type?[]? typeArgument)
	{
		return typeof(TClass).MakeGenericType(typeArgument).Instantiate();
	}

	public static IList InstantiateList(this Type? type)
	{
		return (IList)typeof(List<>).MakeGenericType(type).Instantiate();
	}

	private static GetDelegate<TReturn> CreateGetDelegate<TReturn>(this FieldInfo field)
	{
		if (field == null)
		{
			throw new ArgumentException("Field cannot be null.", "field");
		}
		if (!typeof(TReturn).IsAssignableFrom(field.FieldType))
		{
			throw new Exception($"Field type {field.FieldType} does not match the requested type {typeof(TReturn)}.");
		}
		using DynamicMethodDefinition dynamicMethodDefinition = new DynamicMethodDefinition($"{field} Getter", typeof(TReturn), new Type[1] { typeof(object) });
		ILProcessor iLProcessor = dynamicMethodDefinition.GetILProcessor();
		if (!field.IsStatic)
		{
			iLProcessor.Emit(OpCodes.Ldarg_0);
			if (field.DeclaringType.GetTypeInfo().IsValueType)
			{
				iLProcessor.Emit(OpCodes.Unbox_Any, field.DeclaringType);
			}
		}
		iLProcessor.Emit((!field.IsStatic) ? OpCodes.Ldfld : OpCodes.Ldsfld, field);
		iLProcessor.Emit(OpCodes.Ret);
		return (GetDelegate<TReturn>)dynamicMethodDefinition.Generate().CreateDelegate(typeof(GetDelegate<TReturn>));
	}

	private static SetDelegate<TValue> CreateSetDelegate<TValue>(this FieldInfo field)
	{
		if (field == null)
		{
			throw new ArgumentException("Field cannot be null.", "field");
		}
		if (!field.FieldType.IsAssignableFrom(typeof(TValue)))
		{
			throw new Exception($"Value type type {typeof(TValue)} does not match the requested type {field.FieldType}.");
		}
		using DynamicMethodDefinition dynamicMethodDefinition = new DynamicMethodDefinition($"{field} Setter", typeof(void), new Type[2]
		{
			typeof(object),
			typeof(TValue)
		});
		ILProcessor iLProcessor = dynamicMethodDefinition.GetILProcessor();
		if (!field.IsStatic)
		{
			iLProcessor.Emit(OpCodes.Ldarg_0);
		}
		iLProcessor.Emit(OpCodes.Ldarg_1);
		iLProcessor.Emit((!field.IsStatic) ? OpCodes.Stfld : OpCodes.Stsfld, field);
		iLProcessor.Emit(OpCodes.Ret);
		return (SetDelegate<TValue>)dynamicMethodDefinition.Generate().CreateDelegate(typeof(SetDelegate<TValue>));
	}

	private static SetDelegateRef<TInstance, TValue> CreateSetDelegateRef<TInstance, TValue>(this FieldInfo field) where TInstance : struct
	{
		if (field == null)
		{
			throw new ArgumentException("Field cannot be null.", "field");
		}
		if (field.FieldType != typeof(TValue))
		{
			throw new Exception($"Value type type {typeof(TValue)} does not match the requested type {field.FieldType}.");
		}
		using DynamicMethodDefinition dynamicMethodDefinition = new DynamicMethodDefinition($"{field} SetterByRef", typeof(void), new Type[2]
		{
			typeof(TInstance).MakeByRefType(),
			typeof(TValue)
		});
		ILProcessor iLProcessor = dynamicMethodDefinition.GetILProcessor();
		if (!field.IsStatic)
		{
			iLProcessor.Emit(OpCodes.Ldarg_0);
		}
		iLProcessor.Emit(OpCodes.Ldarg_1);
		iLProcessor.Emit((!field.IsStatic) ? OpCodes.Stfld : OpCodes.Stsfld, field);
		iLProcessor.Emit(OpCodes.Ret);
		return (SetDelegateRef<TInstance, TValue>)dynamicMethodDefinition.Generate().CreateDelegate(typeof(SetDelegateRef<TInstance, TValue>));
	}

	private static GetDelegate<TReturn> CreateGetDelegate<TReturn>(this PropertyInfo property)
	{
		if (property == null)
		{
			throw new ArgumentException("Property cannot be null.", "property");
		}
		if (!typeof(TReturn).IsAssignableFrom(property.PropertyType))
		{
			throw new Exception($"Field type {property.PropertyType} does not match the requested type {typeof(TReturn)}.");
		}
		using DynamicMethodDefinition dynamicMethodDefinition = new DynamicMethodDefinition($"{property} Getter", typeof(TReturn), new Type[1] { typeof(object) });
		ILProcessor iLProcessor = dynamicMethodDefinition.GetILProcessor();
		MethodInfo getMethod = property.GetGetMethod(nonPublic: true);
		if (!getMethod.IsStatic)
		{
			iLProcessor.Emit(OpCodes.Ldarg_0);
		}
		iLProcessor.Emit(OpCodes.Call, getMethod);
		iLProcessor.Emit(OpCodes.Ret);
		return (GetDelegate<TReturn>)dynamicMethodDefinition.Generate().CreateDelegate(typeof(GetDelegate<TReturn>));
	}

	private static GetDelegateRef<TInstance, TReturn> CreateGetDelegate<TInstance, TReturn>(this PropertyInfo property) where TInstance : struct
	{
		if (property == null)
		{
			throw new ArgumentException("Property cannot be null.", "property");
		}
		if (!typeof(TReturn).IsAssignableFrom(property.PropertyType))
		{
			throw new Exception($"Field type {property.PropertyType} does not match the requested type {typeof(TReturn)}.");
		}
		using DynamicMethodDefinition dynamicMethodDefinition = new DynamicMethodDefinition($"{property} Getter", typeof(TReturn), new Type[1] { typeof(TInstance).MakeByRefType() });
		ILProcessor iLProcessor = dynamicMethodDefinition.GetILProcessor();
		MethodInfo getMethod = property.GetGetMethod(nonPublic: true);
		if (!getMethod.IsStatic)
		{
			iLProcessor.Emit(OpCodes.Ldarg_0);
		}
		iLProcessor.Emit(OpCodes.Call, getMethod);
		iLProcessor.Emit(OpCodes.Ret);
		return (GetDelegateRef<TInstance, TReturn>)dynamicMethodDefinition.Generate().CreateDelegate(typeof(GetDelegateRef<TInstance, TReturn>));
	}

	private static SetDelegate<TValue> CreateSetDelegate<TValue>(this PropertyInfo property)
	{
		if (property == null)
		{
			throw new ArgumentException("Property cannot be null.", "property");
		}
		if (!property.PropertyType.IsAssignableFrom(typeof(TValue)))
		{
			throw new Exception($"Value type type {typeof(TValue)} does not match the requested type {property.PropertyType}.");
		}
		using DynamicMethodDefinition dynamicMethodDefinition = new DynamicMethodDefinition($"{property} Setter", typeof(void), new Type[2]
		{
			typeof(object),
			typeof(TValue)
		});
		ILProcessor iLProcessor = dynamicMethodDefinition.GetILProcessor();
		MethodInfo setMethod = property.GetSetMethod(nonPublic: true);
		if (!setMethod.IsStatic)
		{
			iLProcessor.Emit(OpCodes.Ldarg_0);
		}
		iLProcessor.Emit(OpCodes.Ldarg_1);
		iLProcessor.Emit(OpCodes.Call, setMethod);
		iLProcessor.Emit(OpCodes.Ret);
		return (SetDelegate<TValue>)dynamicMethodDefinition.Generate().CreateDelegate(typeof(SetDelegate<TValue>));
	}

	private static SetDelegateRef<TInstance, TValue> CreateSetDelegateRef<TInstance, TValue>(this PropertyInfo property) where TInstance : struct
	{
		if (property == null)
		{
			throw new ArgumentException("Property cannot be null.", "property");
		}
		if (!property.PropertyType.IsAssignableFrom(typeof(TValue)))
		{
			throw new Exception($"Value type type {typeof(TValue)} does not match the requested type {property.PropertyType}.");
		}
		using DynamicMethodDefinition dynamicMethodDefinition = new DynamicMethodDefinition($"{property} SetterByRef", typeof(void), new Type[2]
		{
			typeof(TInstance).MakeByRefType(),
			typeof(TValue)
		});
		ILProcessor iLProcessor = dynamicMethodDefinition.GetILProcessor();
		MethodInfo setMethod = property.GetSetMethod(nonPublic: true);
		if (!setMethod.IsStatic)
		{
			iLProcessor.Emit(OpCodes.Ldarg_0);
		}
		iLProcessor.Emit(OpCodes.Ldarg_1);
		iLProcessor.Emit(OpCodes.Call, setMethod);
		iLProcessor.Emit(OpCodes.Ret);
		return (SetDelegateRef<TInstance, TValue>)dynamicMethodDefinition.Generate().CreateDelegate(typeof(SetDelegateRef<TInstance, TValue>));
	}

	private static FastReflectionDelegate GenerateCallDelegate(this MethodInfo method)
	{
		if (method == null)
		{
			throw new ArgumentException("Method cannot be null.", "method");
		}
		using DynamicMethodDefinition dynamicMethodDefinition = new DynamicMethodDefinition("CallDelegate<" + method.Name + ">", typeof(object), new Type[2]
		{
			typeof(object),
			typeof(object[])
		});
		ILProcessor iLProcessor = dynamicMethodDefinition.GetILProcessor();
		ParameterInfo[] parameters = method.GetParameters();
		if (!method.IsStatic)
		{
			iLProcessor.Emit(OpCodes.Ldarg_0);
			if (method.DeclaringType.GetTypeInfo().IsValueType)
			{
				iLProcessor.Emit(OpCodes.Unbox_Any, method.DeclaringType);
			}
		}
		for (int i = 0; i < parameters.Length; i++)
		{
			Type type = parameters[i].ParameterType;
			bool isByRef = type.IsByRef;
			if (isByRef)
			{
				type = type.GetElementType();
			}
			bool isValueType = type.GetTypeInfo().IsValueType;
			if (isByRef && isValueType)
			{
				iLProcessor.Emit(OpCodes.Ldarg_1);
				iLProcessor.EmitFast_Ldc_I4(i);
			}
			iLProcessor.Emit(OpCodes.Ldarg_1);
			iLProcessor.EmitFast_Ldc_I4(i);
			if (isByRef && !isValueType)
			{
				iLProcessor.Emit(OpCodes.Ldelema, typeof(object));
				continue;
			}
			iLProcessor.Emit(OpCodes.Ldelem_Ref);
			if (isValueType)
			{
				iLProcessor.Emit((!isByRef) ? OpCodes.Unbox_Any : OpCodes.Unbox, type);
			}
		}
		if (method.IsFinal || !method.IsVirtual)
		{
			iLProcessor.Emit(OpCodes.Call, method);
		}
		else
		{
			iLProcessor.Emit(OpCodes.Callvirt, method);
		}
		Type type2 = (method.IsConstructor ? method.DeclaringType : method.ReturnType);
		if (type2 != typeof(void))
		{
			if (type2.GetTypeInfo().IsValueType)
			{
				iLProcessor.Emit(OpCodes.Box, type2);
			}
		}
		else
		{
			iLProcessor.Emit(OpCodes.Ldnull);
		}
		iLProcessor.Emit(OpCodes.Ret);
		return (FastReflectionDelegate)dynamicMethodDefinition.Generate().CreateDelegate(typeof(FastReflectionDelegate));
	}

	public static void EmitFast_Ldc_I4(this ILProcessor? il, int value)
	{
		switch (value)
		{
		case -1:
			il.Emit(OpCodes.Ldc_I4_M1);
			return;
		case 0:
			il.Emit(OpCodes.Ldc_I4_0);
			return;
		case 1:
			il.Emit(OpCodes.Ldc_I4_1);
			return;
		case 2:
			il.Emit(OpCodes.Ldc_I4_2);
			return;
		case 3:
			il.Emit(OpCodes.Ldc_I4_3);
			return;
		case 4:
			il.Emit(OpCodes.Ldc_I4_4);
			return;
		case 5:
			il.Emit(OpCodes.Ldc_I4_5);
			return;
		case 6:
			il.Emit(OpCodes.Ldc_I4_6);
			return;
		case 7:
			il.Emit(OpCodes.Ldc_I4_7);
			return;
		case 8:
			il.Emit(OpCodes.Ldc_I4_8);
			return;
		}
		if (value > -129 && value < 128)
		{
			il.Emit(OpCodes.Ldc_I4_S, (sbyte)value);
		}
		else
		{
			il.Emit(OpCodes.Ldc_I4, value);
		}
	}

	public static byte ReadLocalIndex(OpCode opCode, object? operand)
	{
		if (opCode == OpCodes.Ldloc_0 || opCode == OpCodes.Stloc_0)
		{
			return 0;
		}
		if (opCode == OpCodes.Ldloc_1 || opCode == OpCodes.Stloc_1)
		{
			return 1;
		}
		if (opCode == OpCodes.Ldloc_2 || opCode == OpCodes.Stloc_2)
		{
			return 2;
		}
		if (opCode == OpCodes.Ldloc_3 || opCode == OpCodes.Stloc_3)
		{
			return 3;
		}
		if (opCode == OpCodes.Ldloc_S || opCode == OpCodes.Stloc_S)
		{
			return (byte)operand;
		}
		throw new Exception($"Could not read index for opcode and operand: {opCode} - {operand}");
	}

	public static FieldInfo GetNestedField(Type type, string fieldName)
	{
		Type[] nestedTypes = type.GetNestedTypes(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
		for (int i = 0; i < nestedTypes.Length; i++)
		{
			FieldInfo field = nestedTypes[i].GetField(fieldName, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
			if (field != null)
			{
				return field;
			}
		}
		return null;
	}

	public static MethodInfo GetNestedMethod(Type type, string methodName)
	{
		Type[] nestedTypes = type.GetNestedTypes(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
		for (int i = 0; i < nestedTypes.Length; i++)
		{
			MethodInfo method = nestedTypes[i].GetMethod(methodName, BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
			if (method != null)
			{
				return method;
			}
		}
		return null;
	}

	public static MethodInfo GetGenericMethod(Type type, string name, Type[] parameters)
	{
		MethodInfo[] methods = type.GetMethods(BindingFlags.DeclaredOnly | BindingFlags.Instance | BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);
		foreach (MethodInfo methodInfo in methods)
		{
			if (!(methodInfo.Name == name))
			{
				continue;
			}
			ParameterInfo[] parameters2 = methodInfo.GetParameters();
			if (parameters2.Length != parameters.Length)
			{
				continue;
			}
			bool flag = true;
			for (int j = 0; j < parameters.Length; j++)
			{
				if (parameters2[j].ParameterType.Name != parameters[j].Name)
				{
					flag = false;
					break;
				}
			}
			if (flag)
			{
				return methodInfo;
			}
		}
		return null;
	}
}
