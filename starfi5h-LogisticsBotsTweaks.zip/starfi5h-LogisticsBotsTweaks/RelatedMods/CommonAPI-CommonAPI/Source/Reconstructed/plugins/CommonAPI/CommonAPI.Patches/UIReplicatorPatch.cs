using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using CommonAPI.Systems;
using HarmonyLib;
using UnityEngine;

namespace CommonAPI.Patches;

[HarmonyPatch]
public static class UIReplicatorPatch
{
	private static List<UITabButton> tabs;

	[HarmonyPatch(typeof(UIReplicatorWindow), "_OnCreate")]
	[HarmonyPostfix]
	public static void Create(UIReplicatorWindow __instance)
	{
		TabData[] allTabs = TabSystem.GetAllTabs();
		tabs = new List<UITabButton>(allTabs.Length - 3);
		TabData[] array = allTabs;
		foreach (TabData tabData in array)
		{
			if (tabData != null)
			{
				GameObject gameObject = UnityEngine.Object.Instantiate(TabSystem.GetTabPrefab(), __instance.recipeGroup, worldPositionStays: false);
				((RectTransform)gameObject.transform).anchoredPosition = new Vector2(70 * tabData.tabIndex - 95, 50f);
				UITabButton component = gameObject.GetComponent<UITabButton>();
				Sprite newIcon = Resources.Load<Sprite>(tabData.tabIconPath);
				component.Init(newIcon, tabData.tabName, tabData.tabIndex, (Action<int>)__instance.OnTypeButtonClick);
				tabs.Add(component);
			}
		}
	}

	[HarmonyPatch(typeof(UIReplicatorWindow), "SetSelectedRecipe")]
	[HarmonyTranspiler]
	private static IEnumerable<CodeInstruction> AddNewProperty(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(false, new CodeMatch(OpCodes.Ldloc_0), new CodeMatch(OpCodes.Ldc_I4_1)).Advance(2);
		Label label = (Label)codeMatcher.Operand;
		codeMatcher.Advance(-1).InsertAndAdvance(Transpilers.EmitDelegate<Func<int, bool>>((int type) => type >= 3 && type < TabSystem.tabsRegistry.data.Count)).InsertAndAdvance(new CodeInstruction(OpCodes.Brtrue_S, label))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_0));
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(UIReplicatorWindow), "OnTypeButtonClick")]
	[HarmonyPostfix]
	public static void OnTypeClicked(int type)
	{
		foreach (UITabButton tab in tabs)
		{
			tab.TabSelected(type);
		}
	}
}
