using System;
using System.Collections.Generic;

namespace CommonAPI;

public static class TopologicalSortExtension
{
	public class CyclicDependencyException : Exception
	{
		public CyclicDependencyException()
			: base("Cyclic dependency found")
		{
		}
	}

	public static IEnumerable<T> TopologicalSort<T>(this IEnumerable<T> source, Func<T, IEnumerable<T>> dependencies, Action<T, T> circularDepHandler)
	{
		List<T> list = new List<T>();
		HashSet<T> visited = new HashSet<T>();
		foreach (T item in source)
		{
			Visit(item, visited, list, dependencies, circularDepHandler);
		}
		return list;
	}

	public static IEnumerable<T> GetDependants<T>(this T source, Func<T, IEnumerable<T>> dependencies, Action<T, T> circularDepHandler)
	{
		List<T> list = new List<T>();
		HashSet<T> visited = new HashSet<T>();
		Visit(source, visited, list, dependencies, circularDepHandler);
		return list;
	}

	private static void Visit<T>(T item, HashSet<T> visited, List<T> sorted, Func<T, IEnumerable<T>> dependencies, Action<T, T> circularDepHandler)
	{
		if (!visited.Contains(item))
		{
			visited.Add(item);
			T arg = default(T);
			try
			{
				foreach (T item2 in dependencies(item))
				{
					Visit(arg = item2, visited, sorted, dependencies, circularDepHandler);
				}
				sorted.Add(item);
				return;
			}
			catch (CyclicDependencyException)
			{
				circularDepHandler(item, arg);
				return;
			}
		}
		if (!sorted.Contains(item))
		{
			throw new CyclicDependencyException();
		}
	}
}
