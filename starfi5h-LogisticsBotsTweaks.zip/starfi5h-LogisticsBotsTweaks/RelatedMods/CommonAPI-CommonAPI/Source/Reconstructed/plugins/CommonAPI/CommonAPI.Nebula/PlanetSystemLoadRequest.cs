namespace CommonAPI.Nebula;

public class PlanetSystemLoadRequest
{
	public int planetID { get; set; }

	public PlanetSystemLoadRequest()
	{
	}

	public PlanetSystemLoadRequest(int planetID)
	{
		this.planetID = planetID;
	}
}
