using System;
using System.Collections.Generic;
using System.IO;
using CommonAPI.Patches;

namespace CommonAPI.Systems;

public class PlanetExtensionSystem : BaseSubmodule
{
	public static List<PlanetExtensionStorage> extensions = new List<PlanetExtensionStorage>();

	public static TypeRegistry<IPlanetExtension, PlanetExtensionStorage> registry = new TypeRegistry<IPlanetExtension, PlanetExtensionStorage>();

	internal static Dictionary<int, byte[]> pendingData = new Dictionary<int, byte[]>();

	internal static Action<PlanetData> onInitNewPlanet;

	internal static PlanetExtensionSystem Instance => CommonAPIPlugin.GetModuleInstance<PlanetExtensionSystem>();

	internal override void SetHooks()
	{
		CommonAPIPlugin.harmony.PatchAll(typeof(PlanetExtensionHooks));
	}

	internal override void Load()
	{
		CommonAPIPlugin.registries.Add("CommonAPI:PlanetExtensionRegistry", registry);
	}

	public static void InitOnLoad()
	{
		if (Instance.Loaded)
		{
			CommonAPIPlugin.logger.LogInfo("Loading planet extension system");
			GameData data = GameMain.data;
			extensions.Clear();
			extensions.Capacity = registry.data.Count + 1;
			extensions.Add(null);
			for (int i = 1; i < registry.data.Count; i++)
			{
				PlanetExtensionStorage planetExtensionStorage = new PlanetExtensionStorage();
				planetExtensionStorage.InitOnLoad(data, i);
				extensions.Add(planetExtensionStorage);
			}
		}
	}

	public static void InitNewPlanet(PlanetData planet)
	{
		for (int i = 1; i < registry.data.Count; i++)
		{
			extensions[i].InitNewPlanet(planet);
		}
		onInitNewPlanet?.Invoke(planet);
	}

	public static void CreateEntityComponents(PlanetFactory factory, int entityId, PrefabDesc desc, int prebuildId)
	{
		for (int i = 1; i < extensions.Count; i++)
		{
			if (extensions[i].GetExtension(factory) is IComponentStateListener componentStateListener)
			{
				componentStateListener.OnLogicComponentsAdd(entityId, desc, prebuildId);
			}
		}
		for (int j = 1; j < extensions.Count; j++)
		{
			if (extensions[j].GetExtension(factory) is IComponentStateListener componentStateListener2)
			{
				componentStateListener2.OnPostlogicComponentsAdd(entityId, desc, prebuildId);
			}
		}
	}

	public static void RemoveEntityComponents(PlanetFactory factory, int entityId)
	{
		for (int i = 1; i < extensions.Count; i++)
		{
			if (extensions[i].GetExtension(factory) is IComponentStateListener componentStateListener)
			{
				componentStateListener.OnLogicComponentsRemove(entityId);
			}
		}
	}

	public static void DrawUpdate(PlanetFactory factory)
	{
		if (factory != null)
		{
			for (int i = 1; i < extensions.Count; i++)
			{
				extensions[i].DrawUpdate(factory);
			}
		}
	}

	public static void PowerUpdate(PlanetFactory factory)
	{
		if (factory != null)
		{
			for (int i = 1; i < extensions.Count; i++)
			{
				extensions[i].PowerUpdate(factory);
			}
		}
	}

	public static void PreUpdate(PlanetFactory factory)
	{
		if (factory != null)
		{
			for (int i = 1; i < extensions.Count; i++)
			{
				extensions[i].PreUpdate(factory);
			}
		}
	}

	public static void Update(PlanetFactory factory)
	{
		if (factory != null)
		{
			for (int i = 1; i < extensions.Count; i++)
			{
				extensions[i].Update(factory);
			}
		}
	}

	public static void PostUpdate(PlanetFactory factory)
	{
		if (factory != null)
		{
			for (int i = 1; i < extensions.Count; i++)
			{
				extensions[i].PostUpdate(factory);
			}
		}
	}

	public static void PowerUpdateOnlySinglethread(GameData data)
	{
		for (int i = 0; i < data.factoryCount; i++)
		{
			PlanetFactory planetFactory = data.factories[i];
			if (planetFactory == null)
			{
				continue;
			}
			for (int j = 1; j < extensions.Count; j++)
			{
				PlanetExtensionStorage planetExtensionStorage = extensions[j];
				if (planetExtensionStorage != null && !(planetExtensionStorage.GetExtension(planetFactory) is IPowerUpdateMultithread))
				{
					planetExtensionStorage.PowerUpdate(planetFactory);
				}
			}
		}
	}

	public static void PreUpdateOnlySinglethread(GameData data)
	{
		for (int i = 0; i < data.factoryCount; i++)
		{
			PlanetFactory planetFactory = data.factories[i];
			if (planetFactory == null)
			{
				continue;
			}
			for (int j = 1; j < extensions.Count; j++)
			{
				PlanetExtensionStorage planetExtensionStorage = extensions[j];
				if (planetExtensionStorage != null && !(planetExtensionStorage.GetExtension(planetFactory) is IPreUpdateMultithread))
				{
					planetExtensionStorage.PreUpdate(planetFactory);
				}
			}
		}
	}

	public static void UpdateOnlySinglethread(GameData data)
	{
		for (int i = 0; i < data.factoryCount; i++)
		{
			PlanetFactory planetFactory = data.factories[i];
			if (planetFactory == null)
			{
				continue;
			}
			for (int j = 1; j < extensions.Count; j++)
			{
				PlanetExtensionStorage planetExtensionStorage = extensions[j];
				if (planetExtensionStorage != null && !(planetExtensionStorage.GetExtension(planetFactory) is IUpdateMultithread))
				{
					planetExtensionStorage.Update(planetFactory);
				}
			}
		}
	}

	public static void PostUpdateOnlySinglethread(GameData data)
	{
		for (int i = 0; i < data.factoryCount; i++)
		{
			PlanetFactory planetFactory = data.factories[i];
			if (planetFactory == null)
			{
				continue;
			}
			for (int j = 1; j < extensions.Count; j++)
			{
				PlanetExtensionStorage planetExtensionStorage = extensions[j];
				if (planetExtensionStorage != null && !(planetExtensionStorage.GetExtension(planetFactory) is IPostUpdateMultithread))
				{
					planetExtensionStorage.PostUpdate(planetFactory);
				}
			}
		}
	}

	public static void PowerUpdateMultithread(PlanetFactory factory, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		for (int i = 1; i < extensions.Count; i++)
		{
			extensions[i].PowerUpdateMultithread(factory, usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public static void PreUpdateMultithread(PlanetFactory factory, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		for (int i = 1; i < extensions.Count; i++)
		{
			extensions[i].PreUpdateMultithread(factory, usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public static void UpdateMultithread(PlanetFactory factory, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		for (int i = 1; i < extensions.Count; i++)
		{
			extensions[i].UpdateMultithread(factory, usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public static void PostUpdateMultithread(PlanetFactory factory, int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		for (int i = 1; i < extensions.Count; i++)
		{
			extensions[i].PostUpdateMultithread(factory, usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public static void Import(BinaryReader r)
	{
		r.ReadInt32();
		if (r.ReadBoolean())
		{
			registry.ImportAndMigrate(extensions, r);
		}
	}

	public static void Export(BinaryWriter w)
	{
		bool loaded = Instance.Loaded;
		w.Write(0);
		w.Write(loaded);
		if (loaded)
		{
			registry.ExportContainer(extensions, w);
		}
	}
}
