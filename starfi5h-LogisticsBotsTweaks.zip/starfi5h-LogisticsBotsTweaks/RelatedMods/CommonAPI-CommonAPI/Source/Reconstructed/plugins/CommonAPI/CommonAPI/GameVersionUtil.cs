namespace CommonAPI;

public static class GameVersionUtil
{
	public static Version GetVersion(int major, int minor, int release, int build)
	{
		Version result = new Version(major, minor, release);
		result.Build = build;
		return result;
	}

	public static bool CompatibleWith(this Version first, Version other)
	{
		if (first.Major == other.Major && first.Minor == other.Minor)
		{
			return first.Release == other.Release;
		}
		return false;
	}
}
