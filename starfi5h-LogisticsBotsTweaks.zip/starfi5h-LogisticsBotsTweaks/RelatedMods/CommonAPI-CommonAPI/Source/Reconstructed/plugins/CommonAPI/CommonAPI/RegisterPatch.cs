using System;

namespace CommonAPI;

[AttributeUsage(AttributeTargets.Class)]
public class RegisterPatch : Attribute
{
	public string typeKey;

	public RegisterPatch(string typeKey)
	{
		this.typeKey = typeKey;
	}
}
