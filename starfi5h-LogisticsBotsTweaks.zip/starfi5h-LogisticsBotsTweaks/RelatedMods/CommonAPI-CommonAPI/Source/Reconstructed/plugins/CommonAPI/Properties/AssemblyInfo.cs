using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyFileVersion("1.6.8.0")]
[assembly: AssemblyInformationalVersion("1.6.8-compat+87e5135e5325fc0d02b98ceb91347e406022618b")]
[assembly: AssemblyVersion("1.6.7.0")]
[module: RefSafetyRules(11)]
