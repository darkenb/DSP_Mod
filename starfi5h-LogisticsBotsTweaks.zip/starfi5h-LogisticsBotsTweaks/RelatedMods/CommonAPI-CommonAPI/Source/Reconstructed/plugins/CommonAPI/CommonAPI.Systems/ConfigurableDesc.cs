using System;
using System.Reflection;
using BepInEx.Configuration;

namespace CommonAPI.Systems;

public abstract class ConfigurableDesc : CustomDesc
{
	public int tier;

	internal static MethodInfo bindMethod;

	public abstract string configCategory { get; }

	public abstract ConfigFile modConfig { get; }

	static ConfigurableDesc()
	{
		MethodInfo[] methods = typeof(ConfigFile).GetMethods(BindingFlags.Instance | BindingFlags.Public);
		foreach (MethodInfo methodInfo in methods)
		{
			ParameterInfo[] parameters = methodInfo.GetParameters();
			if (!(methodInfo.Name != "Bind") && parameters.Length == 4 && parameters[0].ParameterType == typeof(string) && parameters[1].ParameterType == typeof(string) && parameters[3].ParameterType == typeof(string))
			{
				bindMethod = methodInfo;
				return;
			}
		}
		CommonAPIPlugin.logger.LogDebug("Failed to find MethodInfo for ConfigFile.Bind!");
	}

	public override void ApplyProperties(PrefabDesc desc)
	{
		FieldInfo[] fields = GetType().GetFields(BindingFlags.Instance | BindingFlags.Public);
		foreach (FieldInfo fieldInfo in fields)
		{
			if (Attribute.IsDefined(fieldInfo, typeof(UseConfigFile)))
			{
				UseConfigFile[] array = (UseConfigFile[])fieldInfo.GetCustomAttributes<UseConfigFile>(inherit: false);
				if (array.Length != 0)
				{
					object obj = bindMethod.MakeGenericMethod(fieldInfo.FieldType).Invoke(modConfig, new object[4]
					{
						configCategory,
						$"Tier-{tier}_{fieldInfo.Name}",
						fieldInfo.GetValue(this),
						array[0].description
					});
					object value = typeof(ConfigEntry<>).MakeGenericType(fieldInfo.FieldType).GetProperty("BoxedValue").GetValue(obj);
					fieldInfo.SetValue(this, value);
				}
			}
		}
	}
}
