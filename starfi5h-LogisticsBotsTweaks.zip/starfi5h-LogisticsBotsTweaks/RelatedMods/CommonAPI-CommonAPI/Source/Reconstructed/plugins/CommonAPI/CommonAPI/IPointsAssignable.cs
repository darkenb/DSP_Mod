using UnityEngine;

namespace CommonAPI;

public interface IPointsAssignable
{
	void SetPoints(Vector3[] points);
}
