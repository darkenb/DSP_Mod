using System;

namespace CommonAPI;

internal static class ExtensionTickDispatch
{
	internal static void Synchronize(GameLogic logic, int ordinal, int threads, Action callback)
	{
		if (threads <= 1)
		{
			if (ordinal == -1)
			{
				callback();
			}
			return;
		}
		HybridBarrier phaseBarrier = logic.threadController.threadManager.phaseBarrier;
		int participant_index = ordinal + 1;
		phaseBarrier.SignalAndWait(participant_index);
		try
		{
			callback();
		}
		finally
		{
			phaseBarrier.SignalAndWait(participant_index);
		}
	}

	internal static void Run(object extension, int stage, int ordinal, int threads, int minimum)
	{
		if (extension == null || threads < 0 || ordinal < -1)
		{
			return;
		}
		if (threads == 0)
		{
			threads = 1;
		}
		if (ordinal >= threads)
		{
			return;
		}
		bool flag = threads > 1;
		bool flag2 = ordinal == -1;
		switch (stage)
		{
		case 0:
			if (flag && extension is IPowerUpdateMultithread powerUpdateMultithread)
			{
				if (!flag2)
				{
					powerUpdateMultithread.PowerUpdateMultithread(threads, ordinal, minimum);
				}
			}
			else if (flag2 && extension is IPowerUpdate powerUpdate)
			{
				powerUpdate.PowerUpdate();
			}
			break;
		case 1:
			if (flag && extension is IPreUpdateMultithread preUpdateMultithread)
			{
				if (!flag2)
				{
					preUpdateMultithread.PreUpdateMultithread(threads, ordinal, minimum);
				}
			}
			else if (flag2 && extension is IPreUpdate preUpdate)
			{
				preUpdate.PreUpdate();
			}
			break;
		case 2:
			if (flag && extension is IUpdateMultithread updateMultithread)
			{
				if (!flag2)
				{
					updateMultithread.UpdateMultithread(threads, ordinal, minimum);
				}
			}
			else if (flag2 && extension is IUpdate update)
			{
				update.Update();
			}
			break;
		case 3:
			if (flag && extension is IPostUpdateMultithread postUpdateMultithread)
			{
				if (!flag2)
				{
					postUpdateMultithread.PostUpdateMultithread(threads, ordinal, minimum);
				}
			}
			else if (flag2 && extension is IPostUpdate postUpdate)
			{
				postUpdate.PostUpdate();
			}
			break;
		}
	}
}
