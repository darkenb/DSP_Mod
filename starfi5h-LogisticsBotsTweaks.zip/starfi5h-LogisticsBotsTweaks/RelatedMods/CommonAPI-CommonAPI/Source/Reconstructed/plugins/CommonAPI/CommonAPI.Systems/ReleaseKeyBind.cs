namespace CommonAPI.Systems;

public class ReleaseKeyBind : PressKeyBind
{
	protected override bool ReadKey(CombineKey key)
	{
		return key.GetKeyUp();
	}
}
