namespace CommonAPI;

public interface IPreUpdate
{
	void PreUpdate();
}
