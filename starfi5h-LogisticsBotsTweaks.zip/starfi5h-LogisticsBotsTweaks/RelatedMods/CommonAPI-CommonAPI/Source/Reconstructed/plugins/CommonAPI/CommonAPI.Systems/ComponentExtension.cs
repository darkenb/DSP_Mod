using System.Collections.Generic;
using System.IO;

namespace CommonAPI.Systems;

public class ComponentExtension : IPlanetExtension, ISerializeState, IUpdateMultithread, IUpdate, IPowerUpdateMultithread, IPowerUpdate, IComponentStateListener
{
	public static readonly string systemID = "CommonAPI:ComponentSystem";

	private static int _cachedId;

	public static TypeRegistry<FactoryComponent, ComponentTypePool> componentRegistry = new TypeRegistry<FactoryComponent, ComponentTypePool>();

	private PlanetFactory factory;

	public List<ComponentTypePool> pools = new List<ComponentTypePool>();

	public static int cachedId
	{
		get
		{
			if (_cachedId == 0)
			{
				_cachedId = PlanetExtensionSystem.registry.GetUniqueId(systemID);
			}
			return _cachedId;
		}
	}

	public void Init(PlanetFactory factory)
	{
		this.factory = factory;
		pools.Capacity = componentRegistry.data.Count + 1;
		pools.Add(null);
		for (int i = 1; i < componentRegistry.data.Count; i++)
		{
			ComponentTypePool componentTypePool = new ComponentTypePool(factory, i);
			pools.Add(componentTypePool);
			componentTypePool.Init(256);
		}
	}

	public void OnLogicComponentsAdd(int entityId, PrefabDesc desc, int prebuildId)
	{
		int property = desc.GetProperty<int>("CommonAPI:componentId");
		if (property != 0)
		{
			PrebuildData data = default(PrebuildData);
			if (prebuildId > 0 && factory.prebuildPool[prebuildId].id == prebuildId)
			{
				data = factory.prebuildPool[prebuildId];
			}
			GetPool(property).AddComponent(entityId, data);
		}
	}

	public void OnPostlogicComponentsAdd(int entityId, PrefabDesc desc, int prebuildId)
	{
		int property = desc.GetProperty<int>("CommonAPI:componentId");
		if (property != 0)
		{
			GetPool(property).OnPostComponentAdded();
		}
	}

	public void OnLogicComponentsRemove(int id)
	{
		if (id != 0 && factory.entityPool[id].id != 0)
		{
			int customType = factory.entityPool[id].customType;
			int customId = factory.entityPool[id].customId;
			if (customId != 0)
			{
				GetPool(customType).RemovePoolItem(customId);
			}
		}
	}

	public static FactoryComponent GetComponent(PlanetFactory factory, int typeId, int customId)
	{
		if (customId == 0 || typeId == 0)
		{
			return null;
		}
		return factory.GetSystem<ComponentExtension>(cachedId).GetPool(typeId).pool[customId];
	}

	public void Import(BinaryReader r)
	{
		r.ReadInt32();
		CommonAPIPlugin.logger.LogInfo("Start Component System Import");
		componentRegistry.ImportAndMigrate(pools, r);
		for (int i = 1; i < factory.entityCursor; i++)
		{
			if (r.ReadBoolean())
			{
				factory.entityPool[i].customId = r.ReadInt32();
				int key = r.ReadInt32();
				if (componentRegistry.migrationMap.ContainsKey(key))
				{
					int customType = componentRegistry.migrationMap[key];
					factory.entityPool[i].customType = customType;
				}
				else
				{
					factory.entityPool[i].customId = 0;
				}
			}
			EntityDataExtensions.ImportData(ref factory.entityPool[i], r);
		}
	}

	public void Free()
	{
		for (int i = 1; i < componentRegistry.data.Count; i++)
		{
			pools[i].Free();
		}
		pools.Clear();
	}

	public void Export(BinaryWriter w)
	{
		w.Write(0);
		CommonAPIPlugin.logger.LogInfo("Start Component System Export");
		componentRegistry.ExportContainer(pools, w);
		for (int i = 1; i < factory.entityCursor; i++)
		{
			int customId = factory.entityPool[i].customId;
			w.Write(customId != 0);
			if (customId != 0)
			{
				w.Write(customId);
				w.Write(factory.entityPool[i].customType);
			}
			EntityDataExtensions.ExportData(ref factory.entityPool[i], w);
		}
	}

	public ComponentTypePool GetPool(int typeId)
	{
		if (typeId > 0 && typeId < pools.Count)
		{
			return pools[typeId];
		}
		return null;
	}

	public void Update()
	{
		for (int i = 1; i < componentRegistry.data.Count; i++)
		{
			pools[i].UpdatePool();
		}
	}

	public void UpdateMultithread(int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		for (int i = 1; i < componentRegistry.data.Count; i++)
		{
			pools[i].UpdatePoolMultithread(usedThreadCount, currentThreadIdx, minimumCount);
		}
	}

	public void PowerUpdate()
	{
		for (int i = 1; i < componentRegistry.data.Count; i++)
		{
			ComponentTypePool componentTypePool = pools[i];
			componentTypePool.UpdatePool(componentTypePool.InitPowerUpdate());
		}
	}

	public void PowerUpdateMultithread(int usedThreadCount, int currentThreadIdx, int minimumCount)
	{
		for (int i = 1; i < componentRegistry.data.Count; i++)
		{
			ComponentTypePool componentTypePool = pools[i];
			componentTypePool.UpdatePoolMultithread(usedThreadCount, currentThreadIdx, minimumCount, componentTypePool.InitPowerUpdate());
		}
	}
}
