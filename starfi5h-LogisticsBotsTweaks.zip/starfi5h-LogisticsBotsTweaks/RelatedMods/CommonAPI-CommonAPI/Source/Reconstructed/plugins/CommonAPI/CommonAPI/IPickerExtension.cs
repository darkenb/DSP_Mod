namespace CommonAPI;

public interface IPickerExtension<in T>
{
	void Open(T picker);

	void Close(T picker);

	void OnPopup(T picker);

	void PostPopup(T picker);
}
