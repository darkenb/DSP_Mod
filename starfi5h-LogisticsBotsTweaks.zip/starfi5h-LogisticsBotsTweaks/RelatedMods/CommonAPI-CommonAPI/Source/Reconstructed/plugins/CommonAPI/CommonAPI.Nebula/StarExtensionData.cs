namespace CommonAPI.Nebula;

public class StarExtensionData
{
	public int starIndex { get; set; }

	public byte[] binaryData { get; set; }

	public StarExtensionData()
	{
	}

	public StarExtensionData(int starIndex, byte[] data)
	{
		this.starIndex = starIndex;
		binaryData = data;
	}
}
