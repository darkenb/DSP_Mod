namespace CommonAPI;

public enum PointsType
{
	Land,
	Water,
	Insert,
	Belt,
	Custom
}
