using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using HarmonyLib;

namespace CommonAPI.Systems.ModLocalization.Patch;

public static class Localization_Patch
{
	[HarmonyPatch(typeof(Localization), "LoadSettings")]
	[HarmonyPostfix]
	public static void OnLoadSettings()
	{
		CommonAPIPlugin.logger.LogInfo("Editing localizations!");
		AddModLanguages();
		AddModKeys();
	}

	[HarmonyPatch(typeof(Localization), "LoadLanguage")]
	[HarmonyPostfix]
	public static void OnLoadLanguage(int index)
	{
		int num = Localization.Languages.Length;
		if ((ulong)index < (ulong)num)
		{
			Localization.Language language = Localization.Languages[index];
			AddModTranslations(index, language);
			EditTranslations(index, language);
		}
	}

	[HarmonyPatch(typeof(Localization), "LoadLanguage")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(true, new CodeMatch((CodeInstruction i) => i.IsLdloc()), new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(StringBuilder), "Clear")), new CodeMatch(OpCodes.Pop), new CodeMatch((CodeInstruction i) => i.IsLdloc()), new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(StringBuilder), "Clear")), new CodeMatch(OpCodes.Pop));
		codeMatcher.Advance(1);
		codeMatcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0)).InsertAndAdvance(Transpilers.EmitDelegate<Action<int>>(delegate(int index)
		{
			Localization.Language language = Localization.Languages[index];
			if (language.lcId >= 50000 && language.fallback != 0)
			{
				LoadFallbackInfo(index, language);
			}
		}));
		return codeMatcher.InstructionEnumeration();
	}

	private static void LoadFallbackInfo(int index, Localization.Language language)
	{
		if (language.fallback == language.lcId)
		{
			return;
		}
		CommonAPIPlugin.logger.LogInfo("Loading fallback info for " + language.abbr);
		int num = Array.FindIndex(Localization.Languages, (Localization.Language other) => other.lcId == language.fallback);
		if (num < 0)
		{
			return;
		}
		if (!Localization.LanguageLoaded(num))
		{
			CommonAPIPlugin.logger.LogDebug("Fallback language isn't loaded, loading it now");
			if (!Localization.LoadLanguage(num))
			{
				return;
			}
		}
		string[] array = Localization.strings[index];
		string[] array2 = Localization.strings[num];
		for (int num2 = 0; num2 < array.Length; num2++)
		{
			if (string.IsNullOrEmpty(array[num2]) && !string.IsNullOrEmpty(array2[num2]))
			{
				array[num2] = array2[num2];
			}
		}
	}

	private static void AddModTranslations(int index, Localization.Language language)
	{
		if (!LocalizationModule.extraDataEntires.ContainsKey(language.lcId))
		{
			return;
		}
		CommonAPIPlugin.logger.LogDebug("Applying translations for " + language.abbr);
		string[] array = Localization.strings[index];
		foreach (KeyValuePair<string, string> modString in LocalizationModule.extraDataEntires[language.lcId].modStrings)
		{
			if (Localization.namesIndexer.ContainsKey(modString.Key))
			{
				int num = Localization.namesIndexer[modString.Key];
				array[num] = modString.Value;
			}
		}
	}

	private static void EditTranslations(int index, Localization.Language language)
	{
		if (!LocalizationModule.extraDataEntires.ContainsKey(language.lcId))
		{
			return;
		}
		CommonAPIPlugin.logger.LogDebug("Editing translations for " + language.abbr);
		string[] array = Localization.strings[index];
		foreach (KeyValuePair<string, string> item in LocalizationModule.extraDataEntires[language.lcId].stringsToEdit)
		{
			if (!Localization.namesIndexer.ContainsKey(item.Key))
			{
				CommonAPIPlugin.logger.LogWarning("Tried to edit key '" + item.Key + "', which does not exist!");
				continue;
			}
			int num = Localization.namesIndexer[item.Key];
			array[num] = item.Value;
		}
	}

	private static void AddModLanguages()
	{
		List<Localization.Language> list = Localization.Languages.ToList();
		foreach (KeyValuePair<int, Localization.Language> pair in LocalizationModule.modLanguages)
		{
			if (list.FirstOrDefault((Localization.Language language) => pair.Value.lcId == language.lcId || pair.Value.abbr == language.abbr) != null)
			{
				CommonAPIPlugin.logger.LogWarning("Ignoring mod language '" + pair.Value.abbr + "', because it already exists!");
			}
			else
			{
				list.Add(pair.Value);
			}
		}
		Localization.Languages = list.ToArray();
		int num = Localization.Languages.Length;
		Localization.strings = new string[num][];
		Localization.floats = new float[num][];
	}

	private static void AddModKeys()
	{
		foreach (string item in LocalizationModule.extraDataEntires.SelectMany((KeyValuePair<int, ExtraLanguageData> pair) => pair.Value.modStrings.Keys).Distinct().ToList())
		{
			if (!Localization.namesIndexer.ContainsKey(item))
			{
				Localization.namesIndexer.Add(item, Localization.namesIndexer.Count);
			}
		}
	}
}
