using UnityEngine;

namespace CommonAPI.Systems.UI;

public class UIShowSignalTipExtension : IUpdatePickerExtension<UISignalPicker>, IPickerExtension<UISignalPicker>
{
	private float mouseInTime;

	private UISignalTip screenSignalTip;

	public void OnUpdate(UISignalPicker picker)
	{
		int num = -1;
		int num2 = -1;
		int num3 = 0;
		if (picker.hoveredIndex >= 0)
		{
			num3 = picker.signalArray[picker.hoveredIndex];
			num = picker.hoveredIndex % 14;
			num2 = picker.hoveredIndex / 14;
		}
		if (num3 != 0 && num3 < 1000)
		{
			mouseInTime += Time.deltaTime;
			if (mouseInTime > picker.showItemTipsDelay)
			{
				if (screenSignalTip == null)
				{
					screenSignalTip = UISignalTip.Create(num3, picker.itemTipAnchor, new Vector2(num * 46 + 15, (0f - (float)num2) * 46f - 50f), picker.iconImage.transform);
				}
				if (!screenSignalTip.gameObject.activeSelf)
				{
					screenSignalTip.gameObject.SetActive(value: true);
					screenSignalTip.SetTip(num3, picker.itemTipAnchor, new Vector2(num * 46 + 15, (0f - (float)num2) * 46f - 50f), picker.iconImage.transform);
				}
				else if (screenSignalTip.showingSignalId != num3)
				{
					screenSignalTip.SetTip(num3, picker.itemTipAnchor, new Vector2(num * 46 + 15, (0f - (float)num2) * 46f - 50f), picker.iconImage.transform);
				}
			}
		}
		else
		{
			CloseTip();
		}
	}

	public void Open(UISignalPicker picker)
	{
		CloseTip();
	}

	public void Close(UISignalPicker picker)
	{
		CloseTip();
	}

	private void CloseTip()
	{
		if (mouseInTime > 0f)
		{
			mouseInTime = 0f;
		}
		if (screenSignalTip != null)
		{
			screenSignalTip.showingSignalId = 0;
			screenSignalTip.gameObject.SetActive(value: false);
		}
	}

	public void OnPopup(UISignalPicker picker)
	{
	}

	public void PostPopup(UISignalPicker picker)
	{
	}
}
