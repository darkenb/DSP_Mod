internal static class ThisAssembly
{
	public const string AssemblyVersion = "1.6.8.0";
}
