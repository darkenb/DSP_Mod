using System;
using UnityEngine;

namespace CommonAPI.Systems;

public class UIRecipePickerExtension
{
	public static Func<RecipeProto, bool> currentFilter;

	public static bool showLocked;

	public static IPickerExtension<UIRecipePicker> currentExtension;

	public static UIRecipePicker PreparePicker()
	{
		PickerExtensionsSystem.Instance.ThrowIfNotLoaded();
		if (UIRoot.instance == null)
		{
			throw new PickerNotReadyException();
		}
		UIRecipePicker recipePicker = UIRoot.instance.uiGame.recipePicker;
		if (!recipePicker.inited || recipePicker.active)
		{
			throw new PickerNotReadyException();
		}
		return recipePicker;
	}

	public static void Popup(Vector2 pos, Action<RecipeProto> _onReturn, bool showLockedRecipes, Func<RecipeProto, bool> filter)
	{
		PickerExtensionsSystem.Instance.ThrowIfNotLoaded();
		try
		{
			showLocked = showLockedRecipes;
			currentExtension = null;
			UIRecipePicker uIRecipePicker = PreparePicker();
			if (uIRecipePicker == null)
			{
				_onReturn?.Invoke(null);
			}
			currentFilter = filter;
			uIRecipePicker.filter = ERecipeType.None;
			uIRecipePicker.onReturn = _onReturn;
			uIRecipePicker._Open();
			uIRecipePicker.pickerTrans.anchoredPosition = pos;
		}
		catch (PickerNotReadyException)
		{
			_onReturn?.Invoke(null);
		}
	}

	public static void Popup(Vector2 pos, Action<RecipeProto> _onReturn, Func<RecipeProto, bool> filter)
	{
		Popup(pos, _onReturn, showLockedRecipes: false, filter);
	}

	public static void Popup(Vector2 pos, IPickerExtension<UIRecipePicker> extension)
	{
		PickerExtensionsSystem.Instance.ThrowIfNotLoaded();
		try
		{
			showLocked = extension is ShowLocked;
			currentExtension = extension;
			UIRecipePicker uIRecipePicker = PreparePicker();
			extension.OnPopup(uIRecipePicker);
			uIRecipePicker._Open();
			uIRecipePicker.pickerTrans.anchoredPosition = pos;
			extension.PostPopup(uIRecipePicker);
		}
		catch (PickerNotReadyException)
		{
		}
	}
}
