using System;
using System.IO;

namespace CommonAPI;

public class Pool<T> : ISerializeState where T : IPoolable, new()
{
	public T[] pool;

	public int poolCursor = 1;

	protected int poolCapacity;

	protected int[] poolRecycle;

	protected int recycleCursor;

	private Action<T> _cachedInitUpdate = delegate
	{
	};

	public T this[int index] => pool[index];

	protected virtual T GetNewInstance()
	{
		return new T();
	}

	protected virtual void InitPoolItem(T item, object[] data)
	{
	}

	protected virtual void RemovePoolItem(T item)
	{
		item.Free();
	}

	public virtual void Free()
	{
		T[] array = pool;
		for (int i = 0; i < array.Length; i++)
		{
			T val = array[i];
			if (val != null && val.GetId() != 0)
			{
				val.Free();
			}
		}
		pool = null;
		poolCursor = 1;
		poolCapacity = 0;
		poolRecycle = null;
		recycleCursor = 0;
	}

	public virtual void Import(BinaryReader r)
	{
		r.ReadInt32();
		int newSize = r.ReadInt32();
		Init(newSize);
		poolCursor = r.ReadInt32();
		recycleCursor = r.ReadInt32();
		for (int i = 1; i < poolCursor; i++)
		{
			if (r.ReadByte() == 1)
			{
				pool[i] = GetNewInstance();
				pool[i].Import(r);
			}
		}
		for (int j = 0; j < recycleCursor; j++)
		{
			poolRecycle[j] = r.ReadInt32();
		}
	}

	public virtual void Export(BinaryWriter w)
	{
		w.Write(0);
		w.Write(poolCapacity);
		w.Write(poolCursor);
		w.Write(recycleCursor);
		for (int i = 1; i < poolCursor; i++)
		{
			if (pool[i] != null && pool[i].GetId() != 0)
			{
				w.Write((byte)1);
				pool[i].Export(w);
			}
			else
			{
				w.Write((byte)0);
			}
		}
		for (int j = 0; j < recycleCursor; j++)
		{
			w.Write(poolRecycle[j]);
		}
	}

	public void Init(int newSize)
	{
		T[] array = pool;
		pool = new T[newSize];
		poolRecycle = new int[newSize];
		if (array != null)
		{
			Array.Copy(array, pool, (newSize <= poolCapacity) ? newSize : poolCapacity);
		}
		poolCapacity = newSize;
	}

	public int AddPoolItem(object[] data)
	{
		return AddPoolItem(default(T), data);
	}

	public int AddPoolItem(T item, object[] data)
	{
		int num;
		if (recycleCursor > 0)
		{
			num = poolRecycle[--recycleCursor];
		}
		else
		{
			num = poolCursor++;
			if (num == poolCapacity)
			{
				Init(poolCapacity * 2);
			}
		}
		if (item != null)
		{
			pool[num] = item;
		}
		else if (pool[num] == null)
		{
			pool[num] = GetNewInstance();
		}
		pool[num].SetId(num);
		InitPoolItem(pool[num], data);
		return num;
	}

	public void RemovePoolItem(int id)
	{
		ref readonly T reference = ref pool[id];
		T val = default(T);
		if (val == null)
		{
			val = reference;
			reference = ref val;
			if (val == null)
			{
				goto IL_0042;
			}
		}
		if (reference.GetId() == 0)
		{
			return;
		}
		goto IL_0042;
		IL_0042:
		RemovePoolItem(pool[id]);
		poolRecycle[recycleCursor++] = id;
	}

	protected virtual Action<T> InitUpdate()
	{
		return _cachedInitUpdate;
	}

	public void UpdatePool(Action<T> initFunc = null)
	{
		Action<T> action = initFunc ?? InitUpdate();
		for (int i = 1; i < poolCursor; i++)
		{
			ref readonly T reference = ref pool[i];
			T val = default(T);
			if (val == null)
			{
				val = reference;
				reference = ref val;
				if (val == null)
				{
					continue;
				}
			}
			if (reference.GetId() == i)
			{
				action(pool[i]);
			}
		}
	}

	public void UpdatePoolMultithread(int usedThreadCount, int currentThreadIdx, int minimumCount, Action<T> initFunc = null)
	{
	}
}
