using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using BepInEx;
using BepInEx.Bootstrap;
using Mono.Cecil;

namespace CommonAPI;

internal class PluginScanner
{
	internal abstract class ScanRequest
	{
		internal readonly string SearchedTypeFullName;

		internal readonly Action WhenRequestIsDone;

		internal readonly bool OneMatchPerAssembly;

		internal readonly HashSet<AssemblyDefinition> AlreadyFound;

		internal ScanRequest(string searchedTypeFullName, Action whenRequestIsDone, bool oneMatchPerAssembly)
		{
			SearchedTypeFullName = searchedTypeFullName;
			WhenRequestIsDone = whenRequestIsDone;
			OneMatchPerAssembly = oneMatchPerAssembly;
			AlreadyFound = new HashSet<AssemblyDefinition>();
		}

		internal abstract bool IsCoherent();
	}

	public delegate void AttributeFoundOnAssemblyTypesDelegate(TypeDefinition scannedType, IList<CustomAttributeArgument> attributeArguments);

	public delegate void AttributeFoundOnAssemblyAttributesDelegate(AssemblyDefinition scannedAssembly, IList<CustomAttributeArgument> attributeArguments);

	internal class AttributeScanRequest : ScanRequest
	{
		private readonly AttributeTargets _attributeTargets;

		internal readonly AttributeFoundOnAssemblyAttributesDelegate FoundOnAssemblyAttributes;

		internal readonly AttributeFoundOnAssemblyTypesDelegate FoundOnAssemblyTypes;

		internal readonly string AttributeMustBeOnTypeFullName;

		internal AttributeScanRequest(string attributeTypeFullName, AttributeTargets attributeTargets, Action whenRequestIsDone, bool oneMatchPerAssembly, AttributeFoundOnAssemblyAttributesDelegate foundOnAssemblyAttributes, AttributeFoundOnAssemblyTypesDelegate foundOnAssemblyTypes = null, string attributeMustBeOnTypeFullName = null)
			: base(attributeTypeFullName, whenRequestIsDone, oneMatchPerAssembly)
		{
			_attributeTargets = attributeTargets;
			FoundOnAssemblyAttributes = foundOnAssemblyAttributes;
			FoundOnAssemblyTypes = foundOnAssemblyTypes;
			AttributeMustBeOnTypeFullName = attributeMustBeOnTypeFullName;
		}

		internal override bool IsCoherent()
		{
			bool result = true;
			if (_attributeTargets.HasFlag(AttributeTargets.Assembly) && FoundOnAssemblyAttributes == null)
			{
				CommonAPIPlugin.logger.LogError("[ScanRequest] Given attribute " + SearchedTypeFullName + " will be checked against assemblies attributes but no corresponding callback was given");
				result = false;
			}
			if (_attributeTargets.HasFlag(AttributeTargets.Class) && FoundOnAssemblyTypes == null)
			{
				CommonAPIPlugin.logger.LogError("[ScanRequest] Given attribute " + SearchedTypeFullName + " will be checked against assemblies class types but no corresponding callback was given");
				result = false;
			}
			return result;
		}
	}

	public delegate void ClassFoundOnAssemblyTypesDelegate(TypeDefinition scannedType, IList<CustomAttribute> classAttributes);

	internal class ClassScanRequest : ScanRequest
	{
		internal readonly ClassFoundOnAssemblyTypesDelegate FoundOnAssemblyTypes;

		internal readonly bool MatchSubType;

		internal ClassScanRequest(string searchedTypeFullName, Action whenRequestIsDone, bool oneMatchPerAssembly, ClassFoundOnAssemblyTypesDelegate foundOnAssemblyTypes, bool matchSubType = true)
			: base(searchedTypeFullName, whenRequestIsDone, oneMatchPerAssembly)
		{
			FoundOnAssemblyTypes = foundOnAssemblyTypes;
			MatchSubType = matchSubType;
		}

		internal override bool IsCoherent()
		{
			bool result = true;
			if (FoundOnAssemblyTypes == null)
			{
				CommonAPIPlugin.logger.LogError("[ScanRequest] Given attribute " + SearchedTypeFullName + " will be checked against assemblies class types but no corresponding callback was given");
				result = false;
			}
			return result;
		}
	}

	private List<AssemblyDefinition> _pluginsAssemblyDefinitions;

	private readonly List<ScanRequest> _scanRequests = new List<ScanRequest>();

	private List<AssemblyDefinition> PluginsAssemblyDefinitions
	{
		get
		{
			if (_pluginsAssemblyDefinitions == null)
			{
				List<AssemblyDefinition> assemblies = new List<AssemblyDefinition>();
				string[] files = Directory.GetFiles(Paths.PluginPath, "*.dll", SearchOption.AllDirectories);
				foreach (string text in files)
				{
					string fileName = Path.GetFileName(text);
					if (!fileName.ToLower().Contains("commonapi") && !fileName.ToLower().Contains("mmhook"))
					{
						try
						{
							assemblies.Add(AssemblyDefinition.ReadAssembly(text, TypeLoader.ReaderParameters));
						}
						catch (Exception)
						{
							CommonAPIPlugin.logger.LogDebug("Cecil ReadAssembly couldn't read " + text);
						}
					}
				}
				DetectAndRemoveDuplicateAssemblies(ref assemblies);
				_pluginsAssemblyDefinitions = assemblies;
			}
			return _pluginsAssemblyDefinitions;
		}
	}

	private static void DetectAndRemoveDuplicateAssemblies(ref List<AssemblyDefinition> assemblies)
	{
		HashSet<AssemblyDefinition> hashSet = new HashSet<AssemblyDefinition>();
		foreach (AssemblyDefinition assembly in assemblies)
		{
			if (hashSet.Contains(assembly))
			{
				continue;
			}
			List<CustomAttribute> list = (from attribute in assembly.MainModule.Types.SelectMany((TypeDefinition typeDef) => typeDef.CustomAttributes)
				where attribute.AttributeType.FullName == typeof(BepInPlugin).FullName
				select attribute).ToList();
			foreach (AssemblyDefinition assembly2 in assemblies)
			{
				if (hashSet.Contains(assembly2) || assembly == assembly2)
				{
					continue;
				}
				List<CustomAttribute> list2 = (from attribute in assembly2.MainModule.Types.SelectMany((TypeDefinition typeDef) => typeDef.CustomAttributes)
					where attribute.AttributeType.FullName == typeof(BepInPlugin).FullName
					select attribute).ToList();
				AssemblyDefinition assemblyDefinition = null;
				string text = null;
				AssemblyDefinition assemblyDefinition2 = null;
				string text2 = null;
				foreach (CustomAttribute item in list)
				{
					var (text3, text4) = GetBepinPluginInfo(item.ConstructorArguments);
					if (text3 == null)
					{
						break;
					}
					foreach (CustomAttribute item2 in list2)
					{
						var (text5, text6) = GetBepinPluginInfo(item2.ConstructorArguments);
						if (text3 == text5)
						{
							if (string.Compare(text4, text6, StringComparison.Ordinal) >= 0)
							{
								assemblyDefinition = item.AttributeType.Module.Assembly;
								text = text4;
								assemblyDefinition2 = item2.AttributeType.Module.Assembly;
								text2 = text6;
							}
							continue;
						}
						assemblyDefinition2 = null;
						break;
					}
				}
				if (assemblyDefinition2 != null)
				{
					CommonAPIPlugin.logger.LogDebug("Removing " + assemblyDefinition2.MainModule.FileName + " (ModVer : " + text2 + ") from the list because it's a duplicate of " + assemblyDefinition.MainModule.FileName + " (ModVer : " + text + ").");
					hashSet.Add(assemblyDefinition2);
				}
			}
		}
		assemblies = assemblies.Except(hashSet).ToList();
	}

	internal void AddScanRequest(ScanRequest request)
	{
		if (request.IsCoherent())
		{
			_scanRequests.Add(request);
		}
	}

	internal void ScanPlugins()
	{
		foreach (AssemblyDefinition pluginsAssemblyDefinition in PluginsAssemblyDefinitions)
		{
			if (pluginsAssemblyDefinition.HasCustomAttributes)
			{
				ScanAssemblyAttributes(pluginsAssemblyDefinition);
			}
			ScanAssemblyTypes(pluginsAssemblyDefinition.Modules.SelectMany((ModuleDefinition module) => module.Types));
		}
		foreach (ScanRequest scanRequest in _scanRequests)
		{
			scanRequest.WhenRequestIsDone?.Invoke();
		}
	}

	private void ScanAssemblyAttributes(AssemblyDefinition assembly)
	{
		foreach (CustomAttribute customAttribute in assembly.CustomAttributes)
		{
			foreach (ScanRequest scanRequest in _scanRequests)
			{
				if (!scanRequest.AlreadyFound.Contains(assembly) && scanRequest is AttributeScanRequest { FoundOnAssemblyAttributes: not null } attributeScanRequest && customAttribute.AttributeType.FullName == scanRequest.SearchedTypeFullName)
				{
					attributeScanRequest.FoundOnAssemblyAttributes(assembly, customAttribute.ConstructorArguments);
					if (attributeScanRequest.OneMatchPerAssembly)
					{
						attributeScanRequest.AlreadyFound.Add(assembly);
					}
				}
			}
		}
	}

	private void ScanAssemblyTypes(IEnumerable<TypeDefinition> types)
	{
		foreach (TypeDefinition type in types)
		{
			foreach (ScanRequest scanRequest in _scanRequests)
			{
				if (scanRequest.AlreadyFound.Contains(type.Module.Assembly))
				{
					continue;
				}
				if (scanRequest is AttributeScanRequest { FoundOnAssemblyTypes: not null } attributeScanRequest && type.HasCustomAttributes)
				{
					try
					{
						foreach (CustomAttribute customAttribute in type.CustomAttributes)
						{
							if (!(customAttribute.AttributeType.FullName == attributeScanRequest.SearchedTypeFullName))
							{
								continue;
							}
							bool flag = !string.IsNullOrEmpty(attributeScanRequest.AttributeMustBeOnTypeFullName);
							if ((flag && type.IsSubTypeOf(attributeScanRequest.AttributeMustBeOnTypeFullName)) || !flag)
							{
								attributeScanRequest.FoundOnAssemblyTypes(type, customAttribute.ConstructorArguments);
								if (attributeScanRequest.OneMatchPerAssembly)
								{
									attributeScanRequest.AlreadyFound.Add(type.Module.Assembly);
								}
							}
						}
					}
					catch (Exception ex)
					{
						if (!(ex is AssemblyResolutionException))
						{
							CommonAPIPlugin.logger.LogDebug($"Catched ex when handling attribute scan request : {ex}\n" + "We were looking for " + attributeScanRequest.SearchedTypeFullName + " in the assembly called " + type.Module.FileName);
						}
					}
				}
				if (!(scanRequest is ClassScanRequest { FoundOnAssemblyTypes: not null } classScanRequest))
				{
					continue;
				}
				try
				{
					if (classScanRequest.SearchedTypeFullName == type.FullName || (classScanRequest.MatchSubType && type.IsSubTypeOf(classScanRequest.SearchedTypeFullName)))
					{
						classScanRequest.FoundOnAssemblyTypes(type, type.CustomAttributes);
						if (classScanRequest.OneMatchPerAssembly)
						{
							classScanRequest.AlreadyFound.Add(type.Module.Assembly);
						}
					}
				}
				catch (Exception ex2)
				{
					if (!(ex2 is AssemblyResolutionException))
					{
						CommonAPIPlugin.logger.LogDebug($"Catched ex when handling class scan request : {ex2}\n" + "We were looking for " + classScanRequest.SearchedTypeFullName + " in the assembly called " + type.Module.FileName);
					}
				}
			}
		}
	}

	internal static (string modGuid, string modVersion) GetBepinPluginInfo(IList<CustomAttributeArgument> attributeArguments)
	{
		if (attributeArguments == null)
		{
			return (modGuid: null, modVersion: null);
		}
		string item = (string)attributeArguments[0].Value;
		string item2 = (string)attributeArguments[2].Value;
		return (modGuid: item, modVersion: item2);
	}
}
