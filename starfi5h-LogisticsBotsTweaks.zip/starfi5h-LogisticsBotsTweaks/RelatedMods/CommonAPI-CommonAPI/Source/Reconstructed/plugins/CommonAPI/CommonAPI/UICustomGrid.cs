using System;
using System.Text;
using CommonAPI.Systems;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace CommonAPI;

public class UICustomGrid : ManualBehaviour
{
	public int colCount = 10;

	public int rowCount = 5;

	public RectTransform rectTrans;

	public RectTransform contentRect;

	public Image bgImage;

	public RawImage iconImage;

	public Text prefabNumText;

	private Material iconImageMat;

	private Material bgImageMat;

	private uint[] iconIndexArray;

	private uint[] stateArray;

	private ComputeBuffer iconIndexBuffer;

	private ComputeBuffer stateBuffer;

	private Text[] numTexts;

	private int[] itemCounts;

	protected IStorage storage;

	private StringBuilder strb = new StringBuilder("      ", 6);

	private static readonly int buffer = Shader.PropertyToID("_StateBuffer");

	private static readonly int indexBuffer = Shader.PropertyToID("_IndexBuffer");

	private static readonly int bans = Shader.PropertyToID("_Bans");

	private static readonly int gridProp = Shader.PropertyToID("_Grid");

	private static readonly int rect = Shader.PropertyToID("_Rect");

	public override void _OnCreate()
	{
		numTexts = new Text[400];
		itemCounts = new int[400];
		iconIndexArray = new uint[1024];
		iconIndexBuffer = new ComputeBuffer(iconIndexArray.Length, 4);
		stateArray = new uint[1024];
		stateBuffer = new ComputeBuffer(stateArray.Length, 4);
		if (bgImage != null)
		{
			bgImageMat = ProtoRegistry.CreateMaterial("UI Ex/Storage Bg", "storage-bg", "#FFFFFFFF", null, new string[0]);
			bgImageMat.SetBuffer(buffer, stateBuffer);
			bgImage.material = bgImageMat;
		}
		if (iconImage != null)
		{
			iconImageMat = ProtoRegistry.CreateMaterial("UI Ex/Storage Icons", "storage-icons", "#FFFFFFFF", null, new string[0]);
			iconImageMat.SetBuffer(indexBuffer, iconIndexBuffer);
			iconImage.material = iconImageMat;
		}
	}

	public override void _OnDestroy()
	{
		if (bgImage != null)
		{
			UnityEngine.Object.Destroy(bgImageMat);
		}
		if (iconImage != null)
		{
			UnityEngine.Object.Destroy(iconImageMat);
		}
		iconIndexBuffer.Release();
		stateBuffer.Release();
		numTexts = null;
		itemCounts = null;
		bgImageMat = null;
		iconImageMat = null;
		iconIndexArray = null;
		iconIndexBuffer = null;
		stateArray = null;
		stateBuffer = null;
	}

	public override bool _OnInit()
	{
		if (iconImage != null)
		{
			iconImage.texture = GameMain.iconSet.texture;
		}
		return true;
	}

	public override void _OnFree()
	{
		SetStorage(null);
	}

	public override void _OnClose()
	{
		OnContentMouseExit(null);
		SetStorage(null);
	}

	public override void _OnUpdate()
	{
		if (storage != null && storage.changed)
		{
			OnStorageContentChanged();
			storage.changed = false;
		}
	}

	protected int GetItemId(int gridX, int gridY)
	{
		int result = 0;
		if (gridX >= 0 && gridY >= 0)
		{
			int index = gridX + gridY * colCount;
			result = storage.GetAt(index).GetItemId();
		}
		return result;
	}

	private void OnApplicationFocus(bool focus)
	{
		if (!focus)
		{
			OnContentMouseExit(null);
		}
	}

	public void SetStorage(IStorage _storage)
	{
		if (_storage != storage)
		{
			storage = _storage;
			OnStorageDataChanged();
		}
	}

	protected void SetRectSize()
	{
		if (!(rectTrans == null))
		{
			rectTrans.sizeDelta = new Vector2(colCount * 50 + 4, rowCount * 50 + 4);
			Vector4 value = new Vector4(colCount, rowCount, 0.04f, 0.04f);
			if (bgImageMat != null)
			{
				bgImageMat.SetVector(gridProp, value);
			}
			if (iconImageMat != null)
			{
				iconImageMat.SetVector(gridProp, value);
				Vector4 value2 = new Vector4(0.1f, 0.1f, 1.25f, 1.25f);
				iconImageMat.SetVector(rect, value2);
			}
		}
	}

	protected void CreateGridGraphic(int index)
	{
		if (numTexts[index] == null)
		{
			numTexts[index] = UnityEngine.Object.Instantiate(prefabNumText, rectTrans);
		}
		RepositionGridGraphic(index);
	}

	protected void SetGridGraphic(int index, bool newState)
	{
		if (numTexts[index].gameObject.activeSelf != newState)
		{
			numTexts[index].gameObject.SetActive(newState);
		}
		if (!newState)
		{
			numTexts[index].text = "";
			itemCounts[index] = 0;
			stateArray[index] = 0u;
			iconIndexArray[index] = 0u;
		}
	}

	protected void DeactiveAllGridGraphics()
	{
		for (int i = 0; i < 400; i++)
		{
			if (numTexts[i] != null && numTexts[i].gameObject.activeSelf)
			{
				numTexts[i].text = "";
				numTexts[i].gameObject.SetActive(value: false);
			}
		}
		Array.Clear(itemCounts, 0, 400);
		Array.Clear(stateArray, 0, stateArray.Length);
		Array.Clear(iconIndexArray, 0, iconIndexArray.Length);
	}

	protected void RepositionGridGraphic(int index)
	{
		int num = index % colCount;
		int num2 = index / colCount;
		numTexts[index].rectTransform.anchoredPosition = new Vector2(num * 50, num2 * -50 - 34);
	}

	public void OnStorageDataChanged()
	{
		if (bgImageMat != null)
		{
			Array.Clear(stateArray, 0, stateArray.Length);
			stateBuffer.SetData(stateArray);
			bgImageMat.SetBuffer(buffer, stateBuffer);
		}
		if (iconImageMat != null)
		{
			Array.Clear(iconIndexArray, 0, iconIndexArray.Length);
			iconIndexBuffer.SetData(iconIndexArray);
			iconImageMat.SetBuffer(indexBuffer, iconIndexBuffer);
		}
		OnStorageSizeChanged();
	}

	public void OnStorageSizeChanged()
	{
		if (storage == null)
		{
			rowCount = 1;
		}
		else
		{
			rowCount = (storage.size - 1) / colCount + 1;
		}
		SetRectSize();
		DeactiveAllGridGraphics();
		for (int i = 0; i < colCount * rowCount; i++)
		{
			CreateGridGraphic(i);
		}
		OnStorageContentChanged();
	}

	public void OnStorageContentChanged()
	{
		if (storage == null)
		{
			return;
		}
		if ((storage.size - 1) / colCount + 1 != rowCount)
		{
			OnStorageSizeChanged();
		}
		for (int i = 0; i < storage.size; i++)
		{
			IItem at = storage.GetAt(i);
			if (at.GetItemId() > 0)
			{
				SetGridGraphic(i, newState: true);
				iconIndexArray[i] = GameMain.iconSet.itemIconIndex[at.GetItemId()];
				stateArray[i] = 1u;
				bool num = itemCounts[i] != at.GetCount();
				itemCounts[i] = at.GetCount();
				if (num)
				{
					if (at.GetMaxStackSize() > 1)
					{
						StringBuilderUtility.WriteKMG(strb, 5, at.GetCount());
						numTexts[i].text = strb.ToString();
					}
					else
					{
						numTexts[i].text = "";
					}
				}
			}
			else
			{
				iconIndexArray[i] = 0u;
				stateArray[i] = 0u;
				SetGridGraphic(i, newState: false);
			}
		}
		iconIndexBuffer.SetData(iconIndexArray);
		stateBuffer.SetData(stateArray);
	}

	public virtual void OnContentMouseEnter(BaseEventData eventData)
	{
	}

	public virtual void OnContentMouseExit(BaseEventData eventData)
	{
	}

	public void OnContentMouseDown(BaseEventData eventData)
	{
		CommonAPIPlugin.logger.LogInfo("Mouse down");
		if (GameMain.mainPlayer != null && GetGridPos(out var gridX, out var gridY))
		{
			CommonAPIPlugin.logger.LogInfo($"pos: {gridX} {gridY}");
			int grid = gridX + gridY * colCount;
			if (eventData is PointerEventData pointerEventData)
			{
				OnGridMouseDown(grid, (int)pointerEventData.button, VFInput.shift, VFInput.control, GameMain.mainPlayer);
			}
		}
	}

	protected bool GetGridPos(out int gridX, out int gridY, bool filterEdges = false)
	{
		gridX = -1;
		gridY = -1;
		if (!UIRoot.ScreenPointIntoRect(Input.mousePosition, contentRect, out var rectPoint))
		{
			return false;
		}
		gridX = Mathf.FloorToInt(rectPoint.x / 50f);
		gridY = Mathf.FloorToInt((0f - rectPoint.y) / 50f);
		if (gridX < 0 || gridX >= colCount)
		{
			gridX = -1;
			gridY = -1;
			return false;
		}
		if (gridY < 0 || gridY >= rowCount)
		{
			gridX = -1;
			gridY = -1;
			return false;
		}
		int num = (int)(rectPoint.x - (float)(gridX * 50));
		int num2 = (int)(0f - rectPoint.y - (float)(gridY * 50));
		if (num <= 3 || num2 <= 3 || num >= 47 || num2 >= 47)
		{
			gridX = -1;
			gridY = -1;
			return false;
		}
		return true;
	}

	public void OnContentMouseUp(BaseEventData eventData)
	{
		if (GameMain.mainPlayer != null)
		{
			PointerEventData pointerEventData = eventData as PointerEventData;
			if (pointerEventData.button == PointerEventData.InputButton.Right)
			{
				OnGridRightMouseUp(GameMain.mainPlayer);
			}
			if (GetGridPos(out var gridX, out var gridY))
			{
				int grid = gridX + gridY * colCount;
				OnGridMouseUp(grid, (int)pointerEventData.button, VFInput.shift, VFInput.control, GameMain.mainPlayer);
			}
		}
	}

	public virtual void OnSort()
	{
	}

	protected virtual void OnGridMouseDown(int grid, int button, bool shift, bool control, Player player)
	{
	}

	protected virtual void OnGridMouseUp(int grid, int button, bool shift, bool control, Player player)
	{
	}

	protected virtual void OnGridRightMouseUp(Player player)
	{
	}

	protected virtual int HandTake(Player player, int grid, int count = 0)
	{
		return 0;
	}

	protected virtual void HandPut(Player player, int grid, int count = 0)
	{
	}
}
