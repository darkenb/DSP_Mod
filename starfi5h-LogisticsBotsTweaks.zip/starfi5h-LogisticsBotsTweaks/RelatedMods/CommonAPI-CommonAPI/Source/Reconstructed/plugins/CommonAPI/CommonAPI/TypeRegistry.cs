using System;
using System.Collections.Generic;
using System.IO;

namespace CommonAPI;

public class TypeRegistry<TItem, TCont> : InstanceRegistry<Type> where TCont : ISerializeState
{
	public override int Register(string key, Type item)
	{
		if (typeof(TItem).IsAssignableFrom(item))
		{
			return base.Register(key, item);
		}
		throw new ArgumentException("Trying to register type " + item.FullName + ", which does not implement " + typeof(TItem).FullName + "!");
	}

	public TItem GetNew(int typeId)
	{
		if (typeId > 0 && typeId < data.Count)
		{
			return (TItem)Activator.CreateInstance(data[typeId]);
		}
		throw new ArgumentException($"Item with id {typeId} is not registered!");
	}

	public void ImportAndMigrate(IList<TCont> list, BinaryReader r)
	{
		while (true)
		{
			int num = r.ReadInt32();
			switch (num)
			{
			case -1:
				continue;
			case 0:
				return;
			}
			int num2 = MigrateId(num);
			if (num2 != 0)
			{
				TCont val = list[num2];
				long num3 = r.ReadInt64();
				long position = r.BaseStream.Position;
				try
				{
					val.Import(r);
				}
				catch (Exception ex)
				{
					CommonLogger.logger.LogWarning("Error importing container for type " + typeof(TItem).FullName + ", message: " + ex.Message + ", Stacktrace:\n" + ex.StackTrace);
					r.BaseStream.Position = position + num3;
				}
			}
			else
			{
				long num4 = r.ReadInt64();
				r.ReadBytes((int)num4);
			}
		}
	}

	public void ExportContainer(IList<TCont> list, BinaryWriter w)
	{
		for (int i = 1; i < list.Count; i++)
		{
			MemoryStream memoryStream = new MemoryStream();
			BinaryWriter w2 = new BinaryWriter(memoryStream);
			TCont val = list[i];
			try
			{
				val.Export(w2);
			}
			catch (Exception ex)
			{
				w.Write(-1);
				CommonLogger.logger.LogWarning("Error exporting container for type " + typeof(TItem).FullName + ", message: " + ex.Message + ", Stacktrace:\n" + ex.StackTrace);
				continue;
			}
			w.Write(i);
			w.Write(memoryStream.Length);
			w.Write(memoryStream.ToArray());
		}
		w.Write(0);
	}
}
