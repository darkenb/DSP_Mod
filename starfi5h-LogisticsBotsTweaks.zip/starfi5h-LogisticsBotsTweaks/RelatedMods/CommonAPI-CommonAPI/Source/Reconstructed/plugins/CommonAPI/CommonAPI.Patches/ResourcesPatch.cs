using System;
using CommonAPI.Systems;
using HarmonyLib;
using UnityEngine;

namespace CommonAPI.Patches;

[HarmonyPatch]
internal static class ResourcesPatch
{
	[HarmonyPatch(typeof(Resources), "Load", new Type[]
	{
		typeof(string),
		typeof(Type)
	})]
	[HarmonyPrefix]
	public static bool Prefix(ref string path, Type systemTypeInstance, ref UnityEngine.Object __result)
	{
		foreach (ResourceData modResource in ProtoRegistry.modResources)
		{
			if (!path.Contains(modResource.keyWord) || !modResource.HasAssetBundle())
			{
				continue;
			}
			if (modResource.bundle.Contains(path + ".prefab") && systemTypeInstance == typeof(GameObject))
			{
				UnityEngine.Object obj = modResource.bundle.LoadAsset(path + ".prefab");
				CommonAPIPlugin.logger.LogDebug("Loading registered asset " + path + ": " + ((obj != null) ? "Success" : "Failure"));
				if (!ProtoRegistry.modelMats.ContainsKey(path))
				{
					__result = obj;
					return false;
				}
				LodMaterials lodMaterials = ProtoRegistry.modelMats[path];
				if (obj != null && lodMaterials.HasLod(0))
				{
					MeshRenderer[] componentsInChildren = ((GameObject)obj).GetComponentsInChildren<MeshRenderer>();
					foreach (MeshRenderer meshRenderer in componentsInChildren)
					{
						Material[] array = new Material[meshRenderer.sharedMaterials.Length];
						for (int j = 0; j < array.Length; j++)
						{
							array[j] = lodMaterials[0][j];
						}
						meshRenderer.sharedMaterials = array;
					}
				}
				__result = obj;
				return false;
			}
			string[] spriteFileExtensions = ProtoRegistry.spriteFileExtensions;
			foreach (string text in spriteFileExtensions)
			{
				if (modResource.bundle.Contains(path + text))
				{
					UnityEngine.Object obj2 = modResource.bundle.LoadAsset(path + text, systemTypeInstance);
					CommonAPIPlugin.logger.LogDebug("Loading registered asset " + path + ": " + ((obj2 != null) ? "Success" : "Failure"));
					__result = obj2;
					return false;
				}
			}
			spriteFileExtensions = ProtoRegistry.audioClipFileExtensions;
			foreach (string text2 in spriteFileExtensions)
			{
				if (modResource.bundle.Contains(path + text2))
				{
					UnityEngine.Object obj3 = modResource.bundle.LoadAsset(path + text2, systemTypeInstance);
					CommonAPIPlugin.logger.LogDebug("Loading registered asset " + path + ": " + ((obj3 != null) ? "Success" : "Failure"));
					__result = obj3;
					return false;
				}
			}
		}
		return true;
	}
}
