using System;
using System.IO;

namespace CommonAPI;

public class IntArrayPropertySerializer : IPropertySerializer
{
	public static readonly IntArrayPropertySerializer instance = new IntArrayPropertySerializer();

	public void Export(object obj, BinaryWriter w)
	{
		int[] array = (int[])obj;
		w.Write(array.Length);
		int[] array2 = array;
		foreach (int value in array2)
		{
			w.Write(value);
		}
	}

	public object Import(BinaryReader r)
	{
		int num = r.ReadInt32();
		int[] array = new int[num];
		for (int i = 0; i < num; i++)
		{
			array[i] = r.ReadInt32();
		}
		return array;
	}

	public Type GetTargetType()
	{
		return typeof(int[]);
	}
}
