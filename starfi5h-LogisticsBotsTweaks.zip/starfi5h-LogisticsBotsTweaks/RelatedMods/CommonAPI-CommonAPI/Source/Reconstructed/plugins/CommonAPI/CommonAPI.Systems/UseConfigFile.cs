using System;

namespace CommonAPI.Systems;

[AttributeUsage(AttributeTargets.Field)]
public class UseConfigFile : Attribute
{
	public string description;

	public UseConfigFile()
	{
	}

	public UseConfigFile(string description)
	{
		this.description = description;
	}
}
