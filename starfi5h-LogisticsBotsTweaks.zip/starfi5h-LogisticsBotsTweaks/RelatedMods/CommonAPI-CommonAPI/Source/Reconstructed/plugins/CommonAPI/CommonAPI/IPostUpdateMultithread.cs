namespace CommonAPI;

public interface IPostUpdateMultithread : IPostUpdate
{
	void PostUpdateMultithread(int usedThreadCount, int currentThreadIdx, int minimumCount);
}
