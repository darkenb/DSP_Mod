namespace CommonAPI.Systems;

public interface IComponentStateListener
{
	void OnLogicComponentsAdd(int entityId, PrefabDesc desc, int prebuildId);

	void OnPostlogicComponentsAdd(int entityId, PrefabDesc desc, int prebuildId);

	void OnLogicComponentsRemove(int entityId);
}
