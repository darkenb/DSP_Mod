using System.Collections.Generic;
using System.Reflection;
using CommonAPI.Systems;
using HarmonyLib;
using UnityEngine;

namespace CommonAPI.Patches;

[HarmonyPatch]
public static class IconSetPatch
{
	[HarmonyPatch(typeof(IconSet), "Create")]
	[HarmonyPostfix]
	public static void AddIconDescs(IconSet __instance)
	{
		foreach (KeyValuePair<int, IconToolNew.IconDesc> itemIconDesc in ProtoRegistry.itemIconDescs)
		{
			if (itemIconDesc.Key <= 0 || itemIconDesc.Key >= 12000)
			{
				continue;
			}
			uint num = __instance.itemIconIndex[itemIconDesc.Key];
			if (num == 0)
			{
				continue;
			}
			IconToolNew.IconDesc value = itemIconDesc.Value;
			FieldInfo[] fields = typeof(IconToolNew.IconDesc).GetFields(BindingFlags.Instance | BindingFlags.Public);
			uint num2 = 0u;
			FieldInfo[] array = fields;
			foreach (FieldInfo fieldInfo in array)
			{
				if (fieldInfo.FieldType == typeof(float))
				{
					__instance.itemDescArr[num * 40 + num2++] = (float)fieldInfo.GetValue(value);
				}
				else if (fieldInfo.FieldType == typeof(Color))
				{
					Color color = (Color)fieldInfo.GetValue(value);
					__instance.itemDescArr[num * 40 + num2++] = color.r;
					__instance.itemDescArr[num * 40 + num2++] = color.g;
					__instance.itemDescArr[num * 40 + num2++] = color.b;
					__instance.itemDescArr[num * 40 + num2++] = color.a;
				}
			}
		}
		__instance.itemIconDescBuffer.SetData(__instance.itemDescArr);
	}
}
