using System;
using System.Collections.Generic;
using CommonAPI.Systems;
using HarmonyLib;
using UnityEngine;

namespace CommonAPI.Patches;

[HarmonyPatch]
public class UIRecipePickerPatch
{
	private static List<UITabButton> tabs;

	[HarmonyPatch(typeof(UIRecipePicker), "_OnCreate")]
	[HarmonyPostfix]
	public static void Create(UIRecipePicker __instance)
	{
		TabData[] allTabs = TabSystem.GetAllTabs();
		tabs = new List<UITabButton>(allTabs.Length - 3);
		TabData[] array = allTabs;
		foreach (TabData tabData in array)
		{
			if (tabData != null)
			{
				GameObject gameObject = UnityEngine.Object.Instantiate(TabSystem.GetTabPrefab(), __instance.pickerTrans, worldPositionStays: false);
				((RectTransform)gameObject.transform).anchoredPosition = new Vector2(70 * tabData.tabIndex - 54, -75f);
				UITabButton component = gameObject.GetComponent<UITabButton>();
				Sprite newIcon = Resources.Load<Sprite>(tabData.tabIconPath);
				component.Init(newIcon, tabData.tabName, tabData.tabIndex, (Action<int>)__instance.OnTypeButtonClick);
				tabs.Add(component);
			}
		}
	}

	[HarmonyPatch(typeof(UIRecipePicker), "OnTypeButtonClick")]
	[HarmonyPostfix]
	public static void OnTypeClicked(int type)
	{
		foreach (UITabButton tab in tabs)
		{
			tab.TabSelected(type);
		}
	}
}
