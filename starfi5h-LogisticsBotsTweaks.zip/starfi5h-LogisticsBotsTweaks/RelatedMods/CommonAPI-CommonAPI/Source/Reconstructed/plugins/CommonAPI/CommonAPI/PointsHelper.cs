using System.Linq;
using UnityEngine;

namespace CommonAPI;

public class PointsHelper : MonoBehaviour
{
	public Component target;

	public Transform searchPoint;

	public PointsType pointsType;

	public void Assign()
	{
		if (searchPoint == null)
		{
			searchPoint = base.gameObject.transform;
		}
		Transform[] array = searchPoint.Cast<Transform>().ToArray();
		Vector3[] array2 = array.Select((Transform trs) => trs.position).ToArray();
		if (target == null)
		{
			target = GetComponent<BuildConditionConfig>();
		}
		else if (pointsType == PointsType.Land || pointsType == PointsType.Water)
		{
			target = target.gameObject.GetComponent<BuildConditionConfig>();
		}
		else if (pointsType == PointsType.Insert || pointsType == PointsType.Belt)
		{
			target = target.gameObject.GetComponent<SlotConfig>();
		}
		if (target == null)
		{
			return;
		}
		if (target is IPointsAssignable pointsAssignable && pointsType == PointsType.Custom)
		{
			pointsAssignable.SetPoints(array2);
			return;
		}
		if (target is BuildConditionConfig buildConditionConfig)
		{
			if (pointsType == PointsType.Land)
			{
				buildConditionConfig.landPoints = array2;
			}
			else
			{
				buildConditionConfig.waterPoints = array2;
			}
		}
		if (target is SlotConfig slotConfig)
		{
			if (pointsType == PointsType.Insert)
			{
				slotConfig.insertPoses = array;
			}
			else
			{
				slotConfig.slotPoses = array;
			}
		}
	}
}
