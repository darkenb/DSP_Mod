using System.Globalization;
using CommonAPI.ShotScene.Patches;
using UnityEngine;
using UnityEngine.PostProcessing;
using UnityEngine.UI;

namespace CommonAPI.ShotScene;

public class GeneratorSceneController : MonoBehaviour
{
	public static GeneratorSceneController shotGenerator;

	public static PostEffectController postEffectController;

	public static Vector3 oldCameraPos;

	public static Quaternion oldCameraRot;

	public static bool isShotSceneLoaded;

	public static bool patchLoaded;

	public static bool pointerInside;

	public bool l_pointerInside;

	public TPCameraController cameraController;

	public TPCameraController lightController;

	public Light light;

	public InputField lightColorField;

	public Slider lightColorSlider;

	public bool ignoreLightEvents;

	public InputField cameraFovField;

	public Slider cameraFovSlider;

	public bool ignoreCameraEvents;

	public RuntimeIconGenerator generator;

	public Transform center;

	public Canvas canvas;

	public void OnCameraToggleChanged(bool value)
	{
		if (cameraController != null)
		{
			cameraController.enabled = value;
		}
	}

	public void OnLightToggleChanged(bool value)
	{
		if (lightController != null)
		{
			lightController.enabled = value;
		}
	}

	public void OnCameraYSliderChanged(float value)
	{
		if (cameraController != null)
		{
			cameraController.cameraOffset.y = 0f - value + 2f;
			cameraController.RecalculatePosition();
		}
	}

	public void OnCamersFOVSliderChanged(float value)
	{
		if (!ignoreCameraEvents && cameraController != null)
		{
			cameraController.camera.fieldOfView = value;
			ignoreCameraEvents = true;
			cameraFovField.text = value.ToString(CultureInfo.InvariantCulture);
			ignoreCameraEvents = false;
		}
	}

	public void OnCameraFOVFieldValueEntered(string value)
	{
		if (!ignoreCameraEvents && cameraController != null)
		{
			float num = float.Parse(value);
			cameraController.camera.fieldOfView = num;
			ignoreCameraEvents = true;
			cameraFovSlider.value = num;
			ignoreCameraEvents = false;
		}
	}

	public void PointerIn()
	{
		pointerInside = true;
		l_pointerInside = true;
	}

	public void PointerOut()
	{
		pointerInside = false;
		l_pointerInside = false;
	}

	public void OnLightColorSliderChanged(float value)
	{
		if (light != null && !ignoreLightEvents)
		{
			int num = Mathf.RoundToInt(value);
			light.color = Mathf.CorrelatedColorTemperatureToRGB(num);
			ignoreLightEvents = true;
			lightColorField.text = num.ToString();
			ignoreLightEvents = false;
		}
	}

	public void OnLightColorEntered(string input)
	{
		if (light != null && !ignoreLightEvents)
		{
			int num = int.Parse(input);
			if (num < 1000)
			{
				num = 1000;
			}
			else if (num > 15000)
			{
				num = 15000;
			}
			light.color = Mathf.CorrelatedColorTemperatureToRGB(num);
			ignoreLightEvents = true;
			lightColorField.text = num.ToString();
			lightColorSlider.value = num;
			ignoreLightEvents = false;
		}
	}

	public void SetLightIntensity(float value)
	{
		if (light != null)
		{
			light.intensity = value;
		}
	}

	public static void LoadIconGeneratorScene()
	{
		if (!isShotSceneLoaded)
		{
			isShotSceneLoaded = true;
			DSPGame.EndGame();
			if (!patchLoaded)
			{
				CommonAPIPlugin.harmony.PatchAll(typeof(PostProcessingMaterialFactoryPatch));
				patchLoaded = true;
			}
			UIRoot.instance.overlayCanvas.enabled = false;
			oldCameraPos = GameCamera.main.transform.position;
			oldCameraRot = GameCamera.main.transform.rotation;
			GameCamera.instance.enabled = false;
			GameCamera.instance.gameObject.SetActive(value: false);
			GameCamera.main.backgroundColor = Color.clear;
			GameCamera.main.fieldOfView = 15f;
			shotGenerator = Object.Instantiate(CommonAPIPlugin.resource.bundle.LoadAsset<GameObject>("Assets/CommonAPI/IconShotPrefab.prefab")).GetComponent<GeneratorSceneController>();
			shotGenerator.lightController.enabled = false;
			shotGenerator.cameraController = GameCamera.main.gameObject.AddComponent<TPCameraController>();
			shotGenerator.cameraController.lookAt = shotGenerator.center;
			shotGenerator.generator.Load(GameCamera.main);
			shotGenerator.canvas.worldCamera = UIRoot.instance.overlayCanvas.worldCamera;
			shotGenerator.canvas.planeDistance = 20f;
			postEffectController = shotGenerator.cameraController.GetComponent<PostEffectController>();
			postEffectController.enabled = false;
			postEffectController.postScript.profile = postEffectController.inst;
			BloomModel.Settings settings = postEffectController.menuProfile.bloom.settings;
			settings.lensDirt.intensity = 0f;
			postEffectController.menuProfile.bloom.settings = settings;
			postEffectController.menuProfile.antialiasing.enabled = false;
		}
	}

	public static void UnloadIconGeneratorScene()
	{
		if (isShotSceneLoaded)
		{
			isShotSceneLoaded = false;
			BloomModel.Settings settings = postEffectController.menuProfile.bloom.settings;
			settings.lensDirt.intensity = 5f;
			settings.bloom.intensity = 0.3f;
			settings.bloom.radius = 4f;
			postEffectController.menuProfile.bloom.settings = settings;
			postEffectController.menuProfile.antialiasing.enabled = true;
			postEffectController.enabled = true;
			Object.Destroy(shotGenerator.cameraController);
			Object.Destroy(shotGenerator.gameObject);
			shotGenerator = null;
			GameCamera.main.backgroundColor = Color.black;
			GameCamera.main.targetTexture = null;
			GameCamera.main.fieldOfView = 60f;
			GameCamera.main.transform.position = oldCameraPos;
			GameCamera.main.transform.rotation = oldCameraRot;
			GameCamera.instance.enabled = true;
			GameCamera.instance.gameObject.SetActive(value: true);
			UIRoot.instance.overlayCanvas.enabled = true;
			DSPGame.StartDemoGame(Random.Range(-2, 0));
		}
	}
}
