using System.IO;
using System.Reflection;
using JetBrains.Annotations;
using UnityEngine;

namespace CommonAPI.Systems;

[UsedImplicitly]
public class ResourceData
{
	public string modId;

	public string modPath;

	public string keyWord;

	public AssetBundle bundle;

	public string vertaFolder;

	public ResourceData(string modId, string keyWord, string modPath)
	{
		this.modId = modId;
		this.modPath = modPath;
		this.keyWord = keyWord;
	}

	public ResourceData(string modId, string keyWord)
	{
		this.modId = modId;
		modPath = Path.GetDirectoryName(Assembly.GetCallingAssembly().Location);
		this.keyWord = keyWord;
	}

	public bool HasVertaFolder()
	{
		return !vertaFolder.Equals("");
	}

	public bool HasAssetBundle()
	{
		return bundle != null;
	}

	public void LoadAssetBundle(string bundleName)
	{
		bundle = AssetBundle.LoadFromFile(modPath + "/" + bundleName);
		if (bundle == null)
		{
			throw new LoadException("Failed to load asset bundle at " + modPath + "/" + bundleName);
		}
	}

	public void ResolveVertaFolder()
	{
		FileInfo fileInfo = new FileInfo(modPath + "/Verta/");
		FileInfo fileInfo2 = new FileInfo(modPath + "/plugins/");
		if (Directory.Exists(fileInfo.Directory?.FullName))
		{
			vertaFolder = modPath;
			return;
		}
		if (Directory.Exists(fileInfo2.Directory?.FullName))
		{
			vertaFolder = modPath + "/plugins";
			return;
		}
		vertaFolder = "";
		throw new LoadException("Failed to resolve verta folder at " + modPath);
	}
}
