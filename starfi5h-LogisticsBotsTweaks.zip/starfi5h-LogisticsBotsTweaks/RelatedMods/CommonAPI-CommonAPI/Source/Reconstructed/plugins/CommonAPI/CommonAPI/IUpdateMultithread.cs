namespace CommonAPI;

public interface IUpdateMultithread : IUpdate
{
	void UpdateMultithread(int usedThreadCount, int currentThreadIdx, int minimumCount);
}
