using System;
using BepInEx.Bootstrap;

namespace CommonAPI;

public static class GeneralExtensions
{
	public static string[] units = new string[5] { "", "k", "M", "G", "T" };

	public static string FormatNumber(this int number)
	{
		if (number == 0)
		{
			return "0";
		}
		bool flag = false;
		if (number <= 0)
		{
			number = Math.Abs(number);
			flag = true;
		}
		int num = (int)(Math.Log10(number) / Math.Log10(1000.0));
		return string.Format("{0}{1:0.#}", flag ? "-" : "", (double)number / Math.Pow(1000.0, num)) + units[num];
	}

	public static bool IsModInstalled(this string modGUID)
	{
		if (Chainloader.PluginInfos == null)
		{
			return false;
		}
		return Chainloader.PluginInfos.ContainsKey(modGUID);
	}
}
