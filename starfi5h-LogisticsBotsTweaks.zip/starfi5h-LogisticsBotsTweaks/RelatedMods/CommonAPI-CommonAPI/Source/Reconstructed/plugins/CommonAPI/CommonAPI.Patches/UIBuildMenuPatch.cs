using System.Collections.Generic;
using CommonAPI.Systems;
using HarmonyLib;

namespace CommonAPI.Patches;

[HarmonyPatch]
internal static class UIBuildMenuPatch
{
	[HarmonyPatch(typeof(UIBuildMenu), "StaticLoad")]
	[HarmonyPostfix]
	public static void Postfix(ItemProto[,] ___protos)
	{
		foreach (KeyValuePair<int, ItemProto> item in ProtoRegistry.items)
		{
			int buildIndex = item.Value.BuildIndex;
			if (buildIndex > 0)
			{
				int num = buildIndex / 100;
				int num2 = buildIndex % 100;
				if (num <= 12 && num2 <= 12)
				{
					___protos[num, num2] = item.Value;
				}
			}
		}
	}
}
