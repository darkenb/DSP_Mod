using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using CommonAPI.Systems.ModLocalization.Patch;
using UnityEngine;
using UnityEngine.UI;

namespace CommonAPI.Systems.ModLocalization;

public class LocalizationModule : BaseSubmodule
{
	private static string[] separators = new string[3] { "\r\n", "\r", "\n" };

	internal const int FIRST_MOD_LANGUAGE_ID = 50000;

	internal static Registry languageRegistry = new Registry(50000, throwErrorOnConflict: true);

	internal static Dictionary<int, Localization.Language> modLanguages = new Dictionary<int, Localization.Language>();

	internal static Dictionary<int, ExtraLanguageData> extraDataEntires = new Dictionary<int, ExtraLanguageData>();

	private static readonly Dictionary<Text, TextDefaultFont> _textReferences = new Dictionary<Text, TextDefaultFont>();

	private static readonly Dictionary<string, int> fileOrder = new Dictionary<string, int>();

	private static readonly StringBuilder tempBuffer1 = new StringBuilder();

	private static readonly StringBuilder tempBuffer2 = new StringBuilder();

	internal static LocalizationModule Instance => CommonAPIPlugin.GetModuleInstance<LocalizationModule>();

	public static int AddLanguage(Localization.Language language)
	{
		Instance.ThrowIfNotLoaded();
		language.published = true;
		int num = (language.lcId = languageRegistry.Register(language.abbr));
		modLanguages[num] = language;
		return num;
	}

	public static void RegisterFontForLanguage(int languageId, string systemFontName)
	{
		Font customFont = Font.CreateDynamicFontFromOSFont(systemFontName, 12);
		GetOrCreateExtraData(languageId).customFont = customFont;
	}

	public static void RegisterFontForLanguageFromBundle(int languageId, string assetBundlePath)
	{
		AssetBundle assetBundle = AssetBundle.LoadFromFile(assetBundlePath);
		if (assetBundle == null)
		{
			CommonAPIPlugin.logger.LogWarning("Failed to load asset bundle from path: " + assetBundlePath);
			return;
		}
		Font[] array = assetBundle.LoadAllAssets<Font>();
		if (array == null || array.Length == 0)
		{
			CommonAPIPlugin.logger.LogWarning("Asset bundle at path " + assetBundlePath + " does not contain any fonts!");
		}
		else
		{
			GetOrCreateExtraData(languageId).customFont = array[0];
		}
	}

	public static int GetLanguageId(string abbreviation)
	{
		if (int.TryParse(abbreviation, out var result))
		{
			return result;
		}
		return abbreviation switch
		{
			"enUS" => 1033, 
			"zhCN" => 2052, 
			"frFR" => 1036, 
			_ => modLanguages.Values.FirstOrDefault((Localization.Language language) => language.abbr.Equals(abbreviation))?.lcId ?? 0, 
		};
	}

	public static void LoadTranslationsFromFolder(string path)
	{
		Instance.ThrowIfNotLoaded();
		if (!Directory.Exists(path))
		{
			CommonAPIPlugin.logger.LogError("Failed to load translations: " + path + " is not a valid directory!");
			return;
		}
		IEnumerable<string> enumerable = Directory.EnumerateDirectories(path);
		int num = 0;
		int num2 = 0;
		foreach (string item in enumerable)
		{
			string fileName = Path.GetFileName(item);
			int languageId = GetLanguageId(fileName);
			if (languageId == 0)
			{
				CommonAPIPlugin.logger.LogWarning("Failed to load translations from folder: " + fileName + ": not a valid language");
				continue;
			}
			List<string> list = Directory.EnumerateFiles(item).ToList();
			list.Sort(delegate(string path2, string path3)
			{
				string fileNameWithoutExtension = Path.GetFileNameWithoutExtension(path2);
				string fileNameWithoutExtension2 = Path.GetFileNameWithoutExtension(path3);
				int order = GetOrder(fileNameWithoutExtension);
				int order2 = GetOrder(fileNameWithoutExtension2);
				return order.CompareTo(order2);
			});
			foreach (string item2 in list)
			{
				if (!File.Exists(item2))
				{
					continue;
				}
				try
				{
					StreamReader streamReader = new StreamReader(item2, detectEncodingFromByteOrderMarks: true);
					while (true)
					{
						string text = streamReader.ReadLine();
						if (text != null)
						{
							if (!text.Equals(string.Empty) && !LoadTranslationFromLine(text, languageId, allowOverride: true))
							{
								num2++;
							}
							continue;
						}
						break;
					}
				}
				catch (Exception ex)
				{
					CommonAPIPlugin.logger.LogError("Failed to load translations from file: " + item2 + ": " + ex.Message + "\n" + ex.StackTrace);
				}
			}
			num++;
		}
		if (num == 0)
		{
			CommonAPIPlugin.logger.LogWarning("Failed to load translations from '" + path + "': found no language subdirectories!");
		}
		else if (num2 == 0)
		{
			CommonAPIPlugin.logger.LogInfo("Successfully loaded translations from '" + path + "'");
		}
		else
		{
			CommonAPIPlugin.logger.LogWarning($"{num2} errors occured while loading translations from '{path}'!");
		}
	}

	public static void LoadTranslationsFromString(string data, string languageAbbr)
	{
		Instance.ThrowIfNotLoaded();
		int languageId = GetLanguageId(languageAbbr);
		if (languageId == 0)
		{
			CommonAPIPlugin.logger.LogWarning("Failed to interpret '" + languageAbbr + "' as a language!");
		}
		else
		{
			LoadTranslationsFromString(data, languageId);
		}
	}

	public static void LoadTranslationsFromString(string data, int languageId)
	{
		Instance.ThrowIfNotLoaded();
		string[] array = data.Split(separators, StringSplitOptions.None);
		int num = 0;
		string[] array2 = array;
		for (int i = 0; i < array2.Length; i++)
		{
			if (!LoadTranslationFromLine(array2[i], languageId, allowOverride: false))
			{
				num++;
			}
		}
		if (num == 0)
		{
			CommonAPIPlugin.logger.LogInfo("Successfully loaded translations from string data");
		}
		else
		{
			CommonAPIPlugin.logger.LogWarning($"{num} errors occured while loading translations from string data for language {languageId}!");
		}
	}

	public static void RegisterTranslation(string key, string enTrans)
	{
		Instance.ThrowIfNotLoaded();
		ExtraLanguageData orCreateExtraData = GetOrCreateExtraData(1033);
		if (!orCreateExtraData.modStrings.ContainsKey(key))
		{
			orCreateExtraData.modStrings[key] = enTrans;
		}
		else
		{
			CommonAPIPlugin.logger.LogWarning("Trying to override translations via RegisterTranslation, this is not supported. Use EditTranslation");
		}
	}

	public static void RegisterTranslation(string key, string enTrans, string cnTrans, string frTrans)
	{
		Instance.ThrowIfNotLoaded();
		ExtraLanguageData orCreateExtraData = GetOrCreateExtraData(1033);
		if (!orCreateExtraData.modStrings.ContainsKey(key))
		{
			orCreateExtraData.modStrings[key] = enTrans;
		}
		else
		{
			CommonAPIPlugin.logger.LogWarning("Trying to override translation '" + key + "' via RegisterTranslation, this is not supported. Use EditTranslation");
		}
		if (!string.IsNullOrEmpty(cnTrans))
		{
			ExtraLanguageData orCreateExtraData2 = GetOrCreateExtraData(2052);
			if (!orCreateExtraData2.modStrings.ContainsKey(key))
			{
				orCreateExtraData2.modStrings[key] = cnTrans;
			}
			else
			{
				CommonAPIPlugin.logger.LogWarning("Trying to override translation '" + key + "' via RegisterTranslation, this is not supported. Use EditTranslation");
			}
		}
		if (!string.IsNullOrEmpty(frTrans))
		{
			ExtraLanguageData orCreateExtraData3 = GetOrCreateExtraData(1036);
			if (!orCreateExtraData3.modStrings.ContainsKey(key))
			{
				orCreateExtraData3.modStrings[key] = frTrans;
			}
			else
			{
				CommonAPIPlugin.logger.LogWarning("Trying to override translation '" + key + "' via RegisterTranslation, this is not supported. Use EditTranslation");
			}
		}
	}

	public static void RegisterTranslation(string key, Dictionary<string, string> translations)
	{
		Instance.ThrowIfNotLoaded();
		foreach (KeyValuePair<string, string> translation in translations)
		{
			int languageId = GetLanguageId(translation.Key);
			if (languageId == 0)
			{
				CommonAPIPlugin.logger.LogWarning("Failed to interpret '" + translation.Key + "' as a language!");
				continue;
			}
			ExtraLanguageData orCreateExtraData = GetOrCreateExtraData(languageId);
			if (!orCreateExtraData.modStrings.ContainsKey(key))
			{
				orCreateExtraData.modStrings[key] = translation.Value;
			}
			else
			{
				CommonAPIPlugin.logger.LogWarning("Trying to override translation '" + key + "' via RegisterTranslation, this is not supported. Use EditTranslation");
			}
		}
	}

	public static void EditTranslation(string key, string enTrans)
	{
		EditTranslation(key, enTrans, "", "");
	}

	public static void EditTranslation(string key, string enTrans, string cnTrans, string frTrans)
	{
		Instance.ThrowIfNotLoaded();
		GetOrCreateExtraData(1033).stringsToEdit[key] = enTrans;
		if (!string.IsNullOrEmpty(cnTrans))
		{
			GetOrCreateExtraData(2052).stringsToEdit[key] = cnTrans;
		}
		if (!string.IsNullOrEmpty(frTrans))
		{
			GetOrCreateExtraData(1036).stringsToEdit[key] = frTrans;
		}
	}

	public static void EditTranslation(string key, Dictionary<string, string> translations)
	{
		Instance.ThrowIfNotLoaded();
		foreach (KeyValuePair<string, string> translation in translations)
		{
			int languageId = GetLanguageId(translation.Key);
			if (languageId == 0)
			{
				CommonAPIPlugin.logger.LogWarning("Failed to interpret '" + translation.Key + "' as a language!");
			}
			else
			{
				GetOrCreateExtraData(languageId).modStrings[key] = translation.Value;
			}
		}
	}

	internal override void SetHooks()
	{
		CommonAPIPlugin.harmony.PatchAll(typeof(Localization_Patch));
		CommonAPIPlugin.harmony.PatchAll(typeof(Text_Patch));
		CommonAPIPlugin.harmony.PatchAll(typeof(UIBehaviour_Patch));
	}

	internal override void Load()
	{
		Localization.OnLanguageChange += RefreshAllTextElements;
		fileOrder["base"] = 0;
		fileOrder["combat"] = 0;
		fileOrder["prototype"] = -1;
		fileOrder["dictionary"] = 3;
	}

	private static int GetOrder(string fileName)
	{
		if (fileOrder.TryGetValue(fileName, out var value))
		{
			return value;
		}
		return -9;
	}

	private static ExtraLanguageData GetOrCreateExtraData(int languageId)
	{
		if (extraDataEntires.ContainsKey(languageId))
		{
			return extraDataEntires[languageId];
		}
		ExtraLanguageData extraLanguageData = new ExtraLanguageData();
		extraDataEntires[languageId] = extraLanguageData;
		return extraLanguageData;
	}

	private static bool LoadTranslationFromLine(string line, int languageId, bool allowOverride)
	{
		if (string.IsNullOrEmpty(line))
		{
			return false;
		}
		if (languageId == 0)
		{
			return false;
		}
		string[] array = line.Split(new char[1] { '\t' });
		if (array.Length != 4)
		{
			CommonAPIPlugin.logger.LogWarning("Translation line '" + line + "' is invalid: wrong tab count!");
			return false;
		}
		tempBuffer1.Clear();
		tempBuffer1.Append(array[0]);
		string text = Localization.UnescapeString(tempBuffer1, tempBuffer2).ToString();
		if (string.IsNullOrEmpty(text))
		{
			CommonAPIPlugin.logger.LogWarning("Translation line '" + line + "' is invalid: key is empty!");
			return false;
		}
		tempBuffer1.Clear();
		tempBuffer1.Append(array[3]);
		string value = Localization.UnescapeString(tempBuffer1, tempBuffer2).ToString();
		if (string.IsNullOrEmpty(value))
		{
			CommonAPIPlugin.logger.LogWarning("Translation line '" + line + "' is invalid: translation is empty!");
			return false;
		}
		ExtraLanguageData orCreateExtraData = GetOrCreateExtraData(languageId);
		if (!orCreateExtraData.modStrings.ContainsKey(text))
		{
			orCreateExtraData.modStrings[text] = value;
		}
		else
		{
			if (!allowOverride)
			{
				CommonAPIPlugin.logger.LogWarning("Trying to override translation '" + text + "' via local files, this is not supported. Use EditTranslation");
				return false;
			}
			orCreateExtraData.modStrings[text] = value;
		}
		return true;
	}

	internal static TextDefaultFont Get(Text text)
	{
		_textReferences.TryGetValue(text, out var value);
		return value;
	}

	internal static void Add(Text text)
	{
		if (Get(text) == null)
		{
			_textReferences.Add(text, new TextDefaultFont(text));
		}
	}

	internal static void Remove(Text text)
	{
		if (Get(text) != null)
		{
			_textReferences.Remove(text);
		}
	}

	public static void RefreshAllTextElements()
	{
		int currentLanguageLCID = Localization.CurrentLanguageLCID;
		if (!extraDataEntires.ContainsKey(currentLanguageLCID))
		{
			return;
		}
		ExtraLanguageData extraLanguageData = extraDataEntires[currentLanguageLCID];
		foreach (KeyValuePair<Text, TextDefaultFont> textReference in _textReferences)
		{
			TextDefaultFont value = textReference.Value;
			Font fontToUse = ((extraLanguageData.customFont != null) ? extraLanguageData.customFont : value.DefaultFont);
			value.UseCustomFontImmediate(fontToUse);
		}
	}
}
