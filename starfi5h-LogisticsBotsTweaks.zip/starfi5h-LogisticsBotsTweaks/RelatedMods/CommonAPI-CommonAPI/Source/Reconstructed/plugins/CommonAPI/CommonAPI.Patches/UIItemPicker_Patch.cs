using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using CommonAPI.Systems;
using HarmonyLib;
using UnityEngine;

namespace CommonAPI.Patches;

[HarmonyPatch]
public class UIItemPicker_Patch
{
	[HarmonyPatch(typeof(UIItemPicker), "RefreshIcons")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> AddItemFilter(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(true, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(ItemProto), "GridIndex")), new CodeMatch(OpCodes.Ldc_I4)).Advance(1);
		Label label = (Label)codeMatcher.Instruction.operand;
		codeMatcher.Advance(-2).InsertAndAdvance(Transpilers.EmitDelegate<Func<ItemProto, bool>>((ItemProto proto) => UIItemPickerExtension.currentFilter == null || UIItemPickerExtension.currentFilter(proto))).InsertAndAdvance(new CodeInstruction(OpCodes.Brfalse, label))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_1))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_3))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Ldelem_Ref));
		codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(Proto), "ID")), new CodeMatch(OpCodes.Callvirt)).SetInstruction(Transpilers.EmitDelegate<Func<GameHistoryData, int, bool>>(CheckItem));
		return codeMatcher.InstructionEnumeration();
	}

	public static bool CheckItem(GameHistoryData history, int itemId)
	{
		if (UIItemPickerExtension.showLocked)
		{
			return true;
		}
		return history.ItemUnlocked(itemId);
	}

	[HarmonyPatch(typeof(UIItemPicker), "Popup", new Type[]
	{
		typeof(Vector2),
		typeof(Action<ItemProto>)
	})]
	[HarmonyPrefix]
	public static void IgnoreFilter(UIItemPicker __instance)
	{
		UIItemPickerExtension.currentFilter = null;
		UIItemPickerExtension.currentExtension = null;
		UIItemPickerExtension.showLocked = false;
	}

	[HarmonyPatch(typeof(UIItemPicker), "OnBoxMouseDown")]
	[HarmonyPrefix]
	public static bool OnBoxMouseDown(UIItemPicker __instance)
	{
		if (UIItemPickerExtension.currentExtension == null)
		{
			return true;
		}
		if (UIItemPickerExtension.currentExtension is IMouseHandlerExtension<UIItemPicker> mouseHandlerExtension)
		{
			return mouseHandlerExtension.OnBoxMouseDown(__instance);
		}
		return true;
	}

	[HarmonyPatch(typeof(UIItemPicker), "TestMouseIndex")]
	[HarmonyPostfix]
	public static void TestMouseIndex(UIItemPicker __instance)
	{
		if (UIItemPickerExtension.currentExtension != null && UIItemPickerExtension.currentExtension is IMouseHandlerExtension<UIItemPicker> mouseHandlerExtension)
		{
			mouseHandlerExtension.TestMouseIndex(__instance);
		}
	}

	[HarmonyPatch(typeof(UIItemPicker), "_OnOpen")]
	[HarmonyPostfix]
	public static void Open(UIItemPicker __instance)
	{
		if (UIItemPickerExtension.currentExtension != null)
		{
			UIItemPickerExtension.currentExtension.Open(__instance);
		}
	}

	[HarmonyPatch(typeof(UIItemPicker), "_OnClose")]
	[HarmonyPostfix]
	public static void Close(UIItemPicker __instance)
	{
		if (UIItemPickerExtension.currentExtension != null)
		{
			UIItemPickerExtension.currentExtension.Close(__instance);
		}
	}

	[HarmonyPatch(typeof(UIItemPicker), "_OnUpdate")]
	[HarmonyPostfix]
	public static void Update(UIItemPicker __instance)
	{
		if (UIItemPickerExtension.currentExtension != null && UIItemPickerExtension.currentExtension is IUpdatePickerExtension<UIItemPicker> updatePickerExtension)
		{
			updatePickerExtension.OnUpdate(__instance);
		}
	}
}
