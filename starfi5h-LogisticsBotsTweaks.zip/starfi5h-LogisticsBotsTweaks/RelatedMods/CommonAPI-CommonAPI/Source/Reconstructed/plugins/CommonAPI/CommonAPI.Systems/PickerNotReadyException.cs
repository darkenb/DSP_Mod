using System;

namespace CommonAPI.Systems;

public class PickerNotReadyException : Exception
{
	public PickerNotReadyException()
		: base("UIItemPicker is not ready!")
	{
	}
}
