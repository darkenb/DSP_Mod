using System;
using CommonAPI.Systems;
using NebulaAPI;
using NebulaAPI.Interfaces;
using NebulaAPI.Networking;
using NebulaAPI.Packets;

namespace CommonAPI.Nebula;

[RegisterPacketProcessor]
public class StarExtensionLoadRequestProcessor : BasePacketProcessor<StarExtensionLoadRequest>
{
	public override void ProcessPacket(StarExtensionLoadRequest packet, INebulaConnection conn)
	{
		if (base.IsClient)
		{
			return;
		}
		StarData star = GameMain.galaxy.StarById(packet.starIndex + 1);
		StarExtensionSystem.InitNewStar(star);
		IWriterProvider binaryWriter = NebulaModAPI.GetBinaryWriter();
		try
		{
			for (int i = 1; i < StarExtensionSystem.registry.data.Count; i++)
			{
				StarExtensionSystem.extensions[i].GetSystem(star).Export(binaryWriter.BinaryWriter);
			}
			conn.SendPacket<StarExtensionData>(new StarExtensionData(packet.starIndex, binaryWriter.CloseAndGetBytes()));
		}
		finally
		{
			((IDisposable)binaryWriter)?.Dispose();
		}
	}
}
