namespace CommonAPI.Systems;

public interface IStarExtension : ISerializeState
{
	void Init(StarData star);
}
