using System;

namespace CommonAPI.Systems;

public class LoadException : Exception
{
	public LoadException(string message)
		: base(message)
	{
	}
}
