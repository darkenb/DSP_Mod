using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using BepInEx.Logging;
using HarmonyLib;
using Mono.Cecil;

namespace CommonAPI;

internal class SubmoduleHandler
{
	private readonly Version currentBuild;

	private readonly ManualLogSource logger;

	internal readonly Dictionary<Type, BaseSubmodule> allModules;

	private readonly HashSet<string> loadedModules;

	internal SubmoduleHandler(Version currentBuild, ManualLogSource logger)
	{
		this.currentBuild = currentBuild;
		this.logger = logger;
		loadedModules = new HashSet<string>();
		allModules = GetSubmodules();
	}

	internal T? GetModuleInstance<T>() where T : BaseSubmodule
	{
		if (allModules.TryGetValue(typeof(T), out BaseSubmodule value))
		{
			return (T)value;
		}
		return null;
	}

	public bool IsLoaded(string submodule)
	{
		return loadedModules.Contains(submodule);
	}

	public bool RequestModuleLoad(Type moduleType)
	{
		return RequestModuleLoad(moduleType, ignoreDependencies: false);
	}

	private bool RequestModuleLoad(Type moduleType, bool ignoreDependencies)
	{
		if (moduleType == null)
		{
			throw new ArgumentNullException("moduleType");
		}
		if (!allModules.ContainsKey(moduleType))
		{
			throw new InvalidOperationException("Tried to load unknown submodule: '" + moduleType.FullName + "'!");
		}
		string name = moduleType.Name;
		if (IsLoaded(name))
		{
			return true;
		}
		CommonAPIPlugin.logger.LogInfo("Enabling CommonAPI Submodule: " + name);
		try
		{
			if (!ignoreDependencies)
			{
				foreach (Type moduleDependency in GetModuleDependencies(moduleType))
				{
					if (!(moduleDependency == moduleType) && !RequestModuleLoad(moduleDependency, ignoreDependencies: true))
					{
						logger.LogError(name + " could not be initialized because one of it's dependencies failed to load.");
					}
				}
			}
			BaseSubmodule baseSubmodule = allModules[moduleType];
			if (!baseSubmodule.Build.Equals(default(Version)) && !baseSubmodule.Build.CompatibleWith(currentBuild))
			{
				logger.LogWarning($"Submodule {name} was built for {baseSubmodule.Build}, but current build is {currentBuild}.");
			}
			baseSubmodule.SetHooks();
			baseSubmodule.Load();
			baseSubmodule.Loaded = true;
			loadedModules.Add(name);
			baseSubmodule.PostLoad();
			return true;
		}
		catch (Exception arg)
		{
			logger.LogError($"{name} could not be initialized and has been disabled:\n{arg}");
		}
		return false;
	}

	private IEnumerable<Type> GetModuleDependencies(Type moduleType)
	{
		return moduleType.GetDependants(delegate(Type type)
		{
			BaseSubmodule baseSubmodule = allModules[type];
			return baseSubmodule.Dependencies.AddRangeToArray(baseSubmodule.GetOptionalDependencies());
		}, delegate(Type start, Type end)
		{
			logger.LogWarning("Found Submodule circular dependency! Submodule " + start.FullName + " depends on " + end.FullName + ", which depends on " + start.FullName + "! Submodule " + start.FullName + " and all of its dependencies will not be loaded.");
		});
	}

	internal HashSet<string> LoadRequested(PluginScanner pluginScanner)
	{
		List<Type> modulesToLoad = new List<Type>();
		PluginScanner.AttributeScanRequest request = new PluginScanner.AttributeScanRequest(typeof(CommonAPISubmoduleDependency).FullName, AttributeTargets.Assembly | AttributeTargets.Class, CallWhenAssembliesAreScanned, oneMatchPerAssembly: false, delegate(AssemblyDefinition assembly, IList<CustomAttributeArgument> arguments)
		{
			AddModuleToSet(arguments);
		}, delegate(TypeDefinition type, IList<CustomAttributeArgument> arguments)
		{
			AddModuleToSet(arguments);
		});
		pluginScanner.AddScanRequest(request);
		return loadedModules;
		void AddModuleToSet(IEnumerable<CustomAttributeArgument> arguments)
		{
			foreach (CustomAttributeArgument argument in arguments)
			{
				CustomAttributeArgument[] array = (CustomAttributeArgument[])argument.Value;
				foreach (CustomAttributeArgument customAttributeArgument in array)
				{
					string moduleName = (string)customAttributeArgument.Value;
					foreach (Type dependant in allModules.First<KeyValuePair<Type, BaseSubmodule>>((KeyValuePair<Type, BaseSubmodule> pair) => pair.Key.Name.Equals(moduleName)).Key.GetDependants(delegate(Type type)
					{
						BaseSubmodule baseSubmodule = allModules[type];
						return baseSubmodule.Dependencies.AddRangeToArray(baseSubmodule.GetOptionalDependencies());
					}, delegate(Type start, Type end)
					{
						CommonAPIPlugin.logger.LogWarning("Found Submodule circular dependency! Submodule " + start.FullName + " depends on " + end.FullName + ", which depends on " + start.FullName + "! Submodule " + start.FullName + " and all of its dependencies will not be loaded.");
					}))
					{
						modulesToLoad.Add(dependant);
					}
				}
			}
		}
		void CallWhenAssembliesAreScanned()
		{
			foreach (Type item in modulesToLoad)
			{
				RequestModuleLoad(item, ignoreDependencies: true);
			}
		}
	}

	private Dictionary<Type, BaseSubmodule> GetSubmodules()
	{
		Type[] types;
		try
		{
			types = Assembly.GetExecutingAssembly().GetTypes();
		}
		catch (ReflectionTypeLoadException ex)
		{
			types = ex.Types;
		}
		Dictionary<Type, BaseSubmodule> dictionary = new Dictionary<Type, BaseSubmodule>();
		foreach (Type item in types.Where(IsSubmodule))
		{
			dictionary.Add(item, (BaseSubmodule)Activator.CreateInstance(item));
		}
		return dictionary;
	}

	private static bool IsSubmodule(Type type)
	{
		if (typeof(BaseSubmodule).IsAssignableFrom(type))
		{
			return type != typeof(BaseSubmodule);
		}
		return false;
	}
}
