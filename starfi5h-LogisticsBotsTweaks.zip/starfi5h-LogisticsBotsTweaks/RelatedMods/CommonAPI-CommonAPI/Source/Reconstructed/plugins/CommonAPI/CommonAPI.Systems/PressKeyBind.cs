namespace CommonAPI.Systems;

public class PressKeyBind
{
	public BuiltinKey defaultBind;

	public bool keyValue
	{
		get
		{
			if (!VFInput.override_keys[defaultBind.id].IsNull())
			{
				return ReadKey(VFInput.override_keys[defaultBind.id]);
			}
			return ReadDefaultKey();
		}
	}

	public void Init(BuiltinKey defaultBind)
	{
		this.defaultBind = defaultBind;
	}

	protected virtual bool ReadDefaultKey()
	{
		return ReadKey(defaultBind.key);
	}

	protected virtual bool ReadKey(CombineKey key)
	{
		return key.GetKeyDown();
	}
}
