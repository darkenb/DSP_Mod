namespace CommonAPI;

public interface IItem
{
	int GetItemId();

	int GetCount();

	int GetMaxStackSize();
}
