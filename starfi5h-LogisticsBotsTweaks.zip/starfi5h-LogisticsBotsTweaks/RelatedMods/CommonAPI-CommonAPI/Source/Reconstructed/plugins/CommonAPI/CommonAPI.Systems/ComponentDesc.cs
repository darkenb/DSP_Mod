namespace CommonAPI.Systems;

public class ComponentDesc : CustomDesc
{
	public const string FIELD_NAME = "CommonAPI:componentId";

	public string componentId;

	public override void ApplyProperties(PrefabDesc desc)
	{
		int uniqueId = ComponentExtension.componentRegistry.GetUniqueId(componentId);
		desc.SetProperty("CommonAPI:componentId", uniqueId);
	}
}
