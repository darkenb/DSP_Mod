using System;
using CommonAPI.Systems;
using NebulaAPI;
using NebulaAPI.Interfaces;
using NebulaAPI.Networking;
using NebulaAPI.Packets;

namespace CommonAPI.Nebula;

[RegisterPacketProcessor]
public class PlanetSystemLoadRequestProcessor : BasePacketProcessor<PlanetSystemLoadRequest>
{
	public override void ProcessPacket(PlanetSystemLoadRequest packet, INebulaConnection conn)
	{
		if (base.IsClient)
		{
			return;
		}
		PlanetData planet = GameMain.galaxy.PlanetById(packet.planetID);
		PlanetFactory orCreateFactory = GameMain.data.GetOrCreateFactory(planet);
		IWriterProvider binaryWriter = NebulaModAPI.GetBinaryWriter();
		try
		{
			for (int i = 1; i < PlanetExtensionSystem.registry.data.Count; i++)
			{
				PlanetExtensionSystem.extensions[i].GetExtension(orCreateFactory).Export(binaryWriter.BinaryWriter);
			}
			conn.SendPacket<PlanetExtensionData>(new PlanetExtensionData(packet.planetID, binaryWriter.CloseAndGetBytes()));
		}
		finally
		{
			((IDisposable)binaryWriter)?.Dispose();
		}
	}
}
