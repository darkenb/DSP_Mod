using UnityEngine;

namespace CommonAPI.Systems;

public class ExtendedAssemberDesc : CustomDesc
{
	public const string RECIPE_TYPE_NAME = "CommonAPI:recipeType";

	public string recipeType;

	public float speed = 1f;

	public override void ApplyProperties(PrefabDesc desc)
	{
		AssemblerRecipeSystem.Instance.ThrowIfNotLoaded();
		desc.assemblerSpeed = Mathf.RoundToInt(speed * 10000f);
		desc.assemblerRecipeType = (ERecipeType)20;
		desc.SetProperty("CommonAPI:recipeType", AssemblerRecipeSystem.recipeTypes.GetUniqueId(recipeType));
		desc.isAssembler = (int)desc.assemblerRecipeType > 0;
	}
}
