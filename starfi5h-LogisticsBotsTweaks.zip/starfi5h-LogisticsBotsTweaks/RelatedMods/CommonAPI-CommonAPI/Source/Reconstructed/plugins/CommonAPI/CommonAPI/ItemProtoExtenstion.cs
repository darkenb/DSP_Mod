using UnityEngine;

namespace CommonAPI;

public static class ItemProtoExtenstion
{
	public static void SetIcon(this ItemProto proto, string path, bool propageToRecipe = true)
	{
		if (!string.IsNullOrEmpty(path))
		{
			Sprite iconSprite = Resources.Load<Sprite>(path);
			proto.IconPath = path;
			proto._iconSprite = iconSprite;
			if (propageToRecipe && proto.maincraft != null)
			{
				RecipeProto recipeProto = LDB.recipes.Select(proto.maincraft.ID);
				CommonAPIPlugin.logger.LogInfo($"Changing recipe icon: {recipeProto != null}");
				recipeProto.IconPath = "";
				recipeProto._iconSprite = iconSprite;
			}
		}
	}
}
