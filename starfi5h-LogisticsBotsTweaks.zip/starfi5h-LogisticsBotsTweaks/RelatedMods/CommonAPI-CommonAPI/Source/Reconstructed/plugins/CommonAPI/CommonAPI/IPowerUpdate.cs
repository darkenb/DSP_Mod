namespace CommonAPI;

public interface IPowerUpdate
{
	void PowerUpdate();
}
