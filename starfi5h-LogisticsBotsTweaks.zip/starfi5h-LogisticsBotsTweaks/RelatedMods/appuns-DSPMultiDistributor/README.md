# appuns-DSPMultiDistributor

Deduplicate distributor pairs and refresh the panel-owned transport; preserve native order cancellation.

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.

[Review map](REVIEW_GUIDE.md) · [Receiving package relationship index](../../RELATED_MODS.md) · [Detailed changes](CHANGELOG.md) · [Build/review notes](BUILD.md) · [Assembly metadata](metadata.json)

Prepared for maintainer review on 15 October 2026. This is a local modified build, not an official upstream release, published package or pull request.

Installed plugin version(s): **0.0.4**. Existing package manifest version: **0.0.3**. Manifest, plugin and assembly versions are separate; the original manifest is retained.

## Package layout

- `InstalledPackage/`: actual installed mod files and companion preloader when present.
- `Source/Reconstructed/`: full projects reconstructed from the exact installed assemblies.
- `Source/EarlierWorkingSource/`, `PortedWorkingSource/`, `UpstreamSnapshot/`: source snapshots when available; provenance is recorded separately.
- `Evidence/`: development helpers, focused check sources and structured validation/installation records.
- `Diffs/`: source-port patches and normalized structural IL comparison.
- `Baselines/`: previous binary and its provenance for review, not an automatic rollback.

## Plugin identifiers and declared dependencies

- `Appun.DSP.plugin.MultiDistributor` — DSPMultiDistributor 0.0.4; dependencies: none declared on this plugin.

## Installed assembly hashes

| Recorded path | SHA-256 |
|---|---|
| `plugins/appuns-DSPMultiDistributor/DSPMultiDistributor.dll` | `cc02bcb7071ef02578df55fccf4df93562bb60d563d96f1f7ce62f9bc3edd1ba` |

## Scope and limitations

Not every source project has been rebuilt. Historical compile/test evidence is limited to its recorded hashes. Headless/embedded-Mono checks do not establish real Unity UI, the user's world, all-mod startup, multiplayer or sustained-memory acceptance.
