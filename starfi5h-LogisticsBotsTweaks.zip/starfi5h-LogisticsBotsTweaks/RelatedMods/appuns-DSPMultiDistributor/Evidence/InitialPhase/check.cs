using System;
using System.Runtime.Serialization;
using HarmonyLib;
using DSPMultiDistributor;

static class Check
{
    static T Empty<T>() => (T)FormatterServices.GetUninitializedObject(typeof(T));
    static int Main()
    {
        AccessTools.Field(typeof(StorageComponent), "staticLoaded").SetValue(null, true);
        StorageComponent.itemStackCount = new int[12000];
        var storage = new StorageComponent(3);
        storage.grids[0].filter = 5001; storage.grids[1].filter = 5001; storage.grids[2].filter = 5002;
        var delivery = new DeliveryPackage(); delivery.Init();
        GameMain.data = Empty<GameData>(); GameMain.data.history = new GameHistoryData {logisticCourierCarries = 5};
        GameMain.data.factories = new PlanetFactory[0];
        var transport = Empty<PlanetTransport>(); transport.gameData = GameMain.data;
        transport.playerDeliveryPackage = delivery;
        transport.dispenserCursor = 4;
        transport.dispenserPool = new[] {null,
            new DispenserComponent {id = 1, filter = 0, storage = storage, storageMode = EStorageDeliveryMode.Supply, deliveryPackage = delivery},
            new DispenserComponent {id = 2, filter = 5001, storageMode = EStorageDeliveryMode.Demand, deliveryPackage = delivery},
            new DispenserComponent {id = 3, filter = 5002, storageMode = EStorageDeliveryMode.Demand, deliveryPackage = delivery}};
        var harmony = new Harmony("phase27.check");
        try
        {
            harmony.Patch(AccessTools.Method(typeof(PlanetTransport), "RefreshDispenserTraffic"), postfix: new HarmonyMethod(typeof(Main), "PlanetTransport_RefreshDispenserTraffic_Postfix"));
            for (int i = 0; i < 2; i++)
            {
                transport.RefreshDispenserTraffic();
                if (transport.dispenserPool[1].pairCount != 2 || transport.dispenserPool[2].pairCount != 1 || transport.dispenserPool[3].pairCount != 1)
                    throw new Exception("Duplicate filters created duplicate traffic pairs");
            }
            Console.WriteLine("PASS real native refresh + Harmony postfix creates unique multi-item pairs and remains stable on refresh");
            harmony.Patch(AccessTools.Method(typeof(DispenserComponent), "OnRematchPairs"), transpiler: new HarmonyMethod(AccessTools.Method(typeof(Main), "RematchTranspiler")));
            var multi = transport.dispenserPool[1]; multi.storageMode = EStorageDeliveryMode.Demand;
            var fixedDispenser = transport.dispenserPool[2]; fixedDispenser.storageMode = EStorageDeliveryMode.Supply;
            fixedDispenser.workCourierCount = 1;
            fixedDispenser.workCourierDatas = new[] {new CourierData {direction = 1f, itemCount = 5, itemId = 5001, endId = 1}};
            fixedDispenser.orders = new[] {new DeliveryLogisticOrder {itemId = 5001, otherId = 1, thisOrdered = -5, otherOrdered = 5}};
            fixedDispenser.storageOrdered = -5; multi.storageOrdered = 5;
            fixedDispenser.OnRematchPairs(null, transport.dispenserPool, 1, 5);
            if (fixedDispenser.orders[0].thisOrdered != -5 || multi.storageOrdered != 5 || fixedDispenser.workCourierDatas[0].direction != 1f)
                throw new Exception("Valid in-flight multi-item order canceled by native rematch");
            storage.grids[0].filter = 5002; storage.grids[1].filter = 5002;
            fixedDispenser.OnRematchPairs(null, transport.dispenserPool, 1, 5);
            if (fixedDispenser.orders[0].thisOrdered != 0 || multi.storageOrdered != 0 || fixedDispenser.workCourierDatas[0].direction != -1f)
                throw new Exception("Removed multi-item filter did not cancel obsolete order");
            Console.WriteLine("PASS actual native rematch preserves valid in-flight multi-item order and cancels removed filter");
            storage.grids[0].filter = 5001;
            multi.storageMode = EStorageDeliveryMode.Supply;
            fixedDispenser.storageMode = EStorageDeliveryMode.Demand;
            foreach (int key in new[] {1, 2})
            {
                fixedDispenser.workCourierDatas[0] = new CourierData {direction = 1f, itemCount = 0, itemId = 5001, endId = 1};
                fixedDispenser.orders[0] = new DeliveryLogisticOrder {itemId = 5001, otherId = 1, thisOrdered = 5, otherOrdered = -5};
                fixedDispenser.storageOrdered = 5; multi.storageOrdered = -5;
                fixedDispenser.OnRematchPairs(null, transport.dispenserPool, key, 5);
                if (fixedDispenser.orders[0].thisOrdered != 5 || fixedDispenser.workCourierDatas[0].direction != 1f)
                    throw new Exception("Demand pickup canceled: " + key);
            }
            Console.WriteLine("PASS native demand pickup on both changed-dispenser rematch branches");
        }
        finally { harmony.UnpatchSelf(); GameMain.data = null; }
        return 0;
    }
}
