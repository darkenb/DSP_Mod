using System;
using System.Collections.Generic;
using System.Reflection;
using System.Reflection.Emit;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;

namespace DSPMultiDistributor;

[BepInPlugin("Appun.DSP.plugin.MultiDistributor", "DSPMultiDistributor", "0.0.4")]
[HarmonyPatch]
public class Main : BaseUnityPlugin
{
	public class LogManager
	{
		public static ManualLogSource Logger;
	}

	private static bool FiltersMatch(DispenserComponent left, DispenserComponent right)
	{
		if (left.filter > 0 && left.filter == right.filter)
		{
			return true;
		}
		DispenserComponent dispenserComponent = ((left.filter == 0) ? left : ((right.filter == 0) ? right : null));
		int num = ((left.filter > 0) ? left.filter : right.filter);
		if (dispenserComponent?.storage == null || num <= 0 || num == 1099)
		{
			return false;
		}
		for (int i = 0; i < dispenserComponent.storage.size; i++)
		{
			if (dispenserComponent.storage.grids[i].filter == num)
			{
				return true;
			}
		}
		return false;
	}

	[HarmonyTranspiler]
	[HarmonyPatch(typeof(DispenserComponent), "OnRematchPairs")]
	private static IEnumerable<CodeInstruction> RematchTranspiler(IEnumerable<CodeInstruction> instructions)
	{
		List<CodeInstruction> list = new List<CodeInstruction>(instructions);
		FieldInfo field = AccessTools.Field(typeof(DispenserComponent), "storageMode");
		FieldInfo field2 = AccessTools.Field(typeof(DispenserComponent), "filter");
		int num = 0;
		for (int i = 0; i + 16 < list.Count; i++)
		{
			if (!(list[i].opcode != OpCodes.Ldarg_0) && list[i + 1].LoadsField(field) && list[i + 5].LoadsField(field) && list[i + 9].LoadsField(field2) && list[i + 13].LoadsField(field2) && list[i + 15].LoadsField(field2) && !(list[i + 16].opcode != OpCodes.Beq))
			{
				list[i + 9].opcode = list[i + 4].opcode;
				list[i + 9].operand = list[i + 4].operand;
				list[i + 10].opcode = OpCodes.Call;
				list[i + 10].operand = AccessTools.Method(typeof(Main), "FiltersMatch");
				list[i + 11].opcode = OpCodes.Brtrue;
				list[i + 11].operand = list[i + 16].operand;
				for (int j = 12; j <= 16; j++)
				{
					list[i + j].opcode = OpCodes.Nop;
					list[i + j].operand = null;
				}
				num++;
			}
		}
		if (num != 3)
		{
			throw new InvalidOperationException("Native dispenser rematch filter checks changed: " + num);
		}
		return list;
	}

	private static void AddPairIfMissing(DispenserComponent dispenser, int supply, int supplyIndex, int demand, int demandIndex)
	{
		for (int i = 0; i < dispenser.pairCount; i++)
		{
			SupplyDemandPair supplyDemandPair = dispenser.pairs[i];
			if (supplyDemandPair.supplyId == supply && supplyDemandPair.supplyIndex == supplyIndex && supplyDemandPair.demandId == demand && supplyDemandPair.demandIndex == demandIndex)
			{
				return;
			}
		}
		dispenser.AddPair(supply, supplyIndex, demand, demandIndex);
	}

	public void Awake()
	{
		LogManager.Logger = base.Logger;
		Harmony.CreateAndPatchAll(Assembly.GetExecutingAssembly());
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIDispenserWindow), "_OnClose")]
	public static void UIDispenserWindow_OnClose_Prefix2(UIDispenserWindow __instance)
	{
		AccessTools.FieldRefAccess<UIDispenserWindow, PlanetTransport>(__instance, "transport")?.RefreshDispenserTraffic();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetTransport), "RefreshDispenserTraffic")]
	public static void PlanetTransport_RefreshDispenserTraffic_Postfix(PlanetTransport __instance, int keyId)
	{
		if (GameMain.history == null || __instance.dispenserPool == null)
		{
			return;
		}
		for (int i = 1; i < __instance.dispenserCursor; i++)
		{
			DispenserComponent dispenserComponent = __instance.dispenserPool[i];
			if (dispenserComponent == null || dispenserComponent.storage == null || dispenserComponent.id != i || dispenserComponent.filter != 0)
			{
				continue;
			}
			if (dispenserComponent.storageMode == EStorageDeliveryMode.Supply)
			{
				for (int j = 0; j < dispenserComponent.storage.size; j++)
				{
					int filter = dispenserComponent.storage.grids[j].filter;
					if (filter <= 0 || filter == 1099)
					{
						continue;
					}
					for (int k = 1; k < __instance.dispenserCursor; k++)
					{
						DispenserComponent dispenserComponent2 = __instance.dispenserPool[k];
						if (dispenserComponent2 != null && dispenserComponent2.id == k && dispenserComponent2.storageMode == EStorageDeliveryMode.Demand && dispenserComponent2.filter == filter)
						{
							AddPairIfMissing(dispenserComponent, i, 0, k, 0);
							AddPairIfMissing(dispenserComponent2, i, 0, k, 0);
						}
					}
				}
			}
			else if (dispenserComponent.storageMode == EStorageDeliveryMode.Demand)
			{
				for (int l = 0; l < dispenserComponent.storage.size; l++)
				{
					int filter2 = dispenserComponent.storage.grids[l].filter;
					if (filter2 <= 0 || filter2 == 1099)
					{
						continue;
					}
					for (int m = 1; m < __instance.dispenserCursor; m++)
					{
						DispenserComponent dispenserComponent3 = __instance.dispenserPool[m];
						if (dispenserComponent3 != null && dispenserComponent3.id == m && dispenserComponent3.storageMode == EStorageDeliveryMode.Supply && dispenserComponent3.filter == filter2)
						{
							AddPairIfMissing(dispenserComponent, m, 0, i, 0);
							AddPairIfMissing(dispenserComponent3, m, 0, i, 0);
						}
					}
				}
			}
			int logisticCourierCarries = GameMain.history.logisticCourierCarries;
			dispenserComponent.OnRematchPairs(__instance.factory, __instance.dispenserPool, keyId, logisticCourierCarries);
		}
	}
}
