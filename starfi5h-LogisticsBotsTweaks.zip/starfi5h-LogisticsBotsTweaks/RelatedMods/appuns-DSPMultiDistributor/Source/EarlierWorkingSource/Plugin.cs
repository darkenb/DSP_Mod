using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;
using BepInEx;
using BepInEx.Logging;
using HarmonyLib;



[assembly: Debuggable(DebuggableAttribute.DebuggingModes.Default | DebuggableAttribute.DebuggingModes.DisableOptimizations | DebuggableAttribute.DebuggingModes.IgnoreSymbolStoreSequencePoints | DebuggableAttribute.DebuggingModes.EnableEditAndContinue)]
[assembly: AssemblyTitle("DspFontPatcher")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("DspFontPatcher")]
[assembly: AssemblyCopyright("Copyright ©  2021")]
[assembly: AssemblyTrademark("")]
[assembly: ComVisible(false)]
[assembly: Guid("81DF3045-8007-4F6A-AAF6-903139D85B6C")]
[assembly: AssemblyFileVersion("0.1.0.0")]
[assembly: TargetFramework(".NETFramework,Version=v4.7.2", FrameworkDisplayName = ".NET Framework 4.7.2")]
[assembly: SecurityPermission(SecurityAction.RequestMinimum, SkipVerification = true)]
[assembly: AssemblyVersion("0.1.0.0")]
[module: UnverifiableCode]
namespace DSPMultiDistributor;

[BepInPlugin("Appun.DSP.plugin.MultiDistributor", "DSPMultiDistributor", "0.0.4")]
[HarmonyPatch]
public class Main : BaseUnityPlugin
{
	private static bool FiltersMatch(DispenserComponent left, DispenserComponent right)
	{
		if (left.filter > 0 && left.filter == right.filter) return true;
		var multi = left.filter == 0 ? left : right.filter == 0 ? right : null;
		int item = left.filter > 0 ? left.filter : right.filter;
		if (multi?.storage == null || item <= 0 || item == 1099) return false;
		for (int i = 0; i < multi.storage.size; i++) if (multi.storage.grids[i].filter == item) return true;
		return false;
	}

	[HarmonyTranspiler, HarmonyPatch(typeof(DispenserComponent), "OnRematchPairs")]
	private static System.Collections.Generic.IEnumerable<CodeInstruction> RematchTranspiler(System.Collections.Generic.IEnumerable<CodeInstruction> instructions)
	{
		var codes = new System.Collections.Generic.List<CodeInstruction>(instructions);
		var mode = AccessTools.Field(typeof(DispenserComponent), "storageMode");
		var filter = AccessTools.Field(typeof(DispenserComponent), "filter");
		int matched = 0;
		for (int i = 0; i + 16 < codes.Count; i++)
		{
			if (codes[i].opcode != System.Reflection.Emit.OpCodes.Ldarg_0 || !codes[i+1].LoadsField(mode) ||
				!codes[i+5].LoadsField(mode) || !codes[i+9].LoadsField(filter) || !codes[i+13].LoadsField(filter) ||
				!codes[i+15].LoadsField(filter) || codes[i+16].opcode != System.Reflection.Emit.OpCodes.Beq) continue;
			codes[i+9].opcode = codes[i+4].opcode; codes[i+9].operand = codes[i+4].operand;
			codes[i+10].opcode = System.Reflection.Emit.OpCodes.Call; codes[i+10].operand = AccessTools.Method(typeof(Main), "FiltersMatch");
			codes[i+11].opcode = System.Reflection.Emit.OpCodes.Brtrue; codes[i+11].operand = codes[i+16].operand;
			for (int j = 12; j <= 16; j++) { codes[i+j].opcode = System.Reflection.Emit.OpCodes.Nop; codes[i+j].operand = null; }
			matched++;
		}
		if (matched != 3) throw new System.InvalidOperationException("Native dispenser rematch filter checks changed: " + matched);
		return codes;
	}
	private static void AddPairIfMissing(DispenserComponent dispenser, int supply, int supplyIndex, int demand, int demandIndex)
	{
		for (int i = 0; i < dispenser.pairCount; i++)
		{
			var pair = dispenser.pairs[i];
			if (pair.supplyId == supply && pair.supplyIndex == supplyIndex && pair.demandId == demand && pair.demandIndex == demandIndex) return;
		}
		dispenser.AddPair(supply, supplyIndex, demand, demandIndex);
	}
	public class LogManager
	{
		public static ManualLogSource Logger;
	}

	public void Awake()
	{
		LogManager.Logger = Logger;
		Harmony.CreateAndPatchAll(Assembly.GetExecutingAssembly(), (string)null);
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIDispenserWindow), "_OnClose")]
	public static void UIDispenserWindow_OnClose_Prefix2(UIDispenserWindow __instance)
	{
		AccessTools.FieldRefAccess<UIDispenserWindow, PlanetTransport>(__instance, "transport")?.RefreshDispenserTraffic();
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetTransport), "RefreshDispenserTraffic")]
	public static void PlanetTransport_RefreshDispenserTraffic_Postfix(PlanetTransport __instance, int keyId)
	{
		if (GameMain.history == null || __instance.dispenserPool == null) return;
		for (int i = 1; i < __instance.dispenserCursor; i++)
		{
			DispenserComponent dispenserComponent = __instance.dispenserPool[i];
			if (dispenserComponent == null || dispenserComponent.storage == null || dispenserComponent.id != i || dispenserComponent.filter != 0)
			{
				continue;
			}
			if (dispenserComponent.storageMode == EStorageDeliveryMode.Supply)
			{
				for (int j = 0; j < dispenserComponent.storage.size; j++)
				{
					int filter = dispenserComponent.storage.grids[j].filter;
					if (filter <= 0 || filter == 1099)
					{
						continue;
					}
					for (int k = 1; k < __instance.dispenserCursor; k++)
					{
						DispenserComponent dispenserComponent2 = __instance.dispenserPool[k];
						if (dispenserComponent2 != null && dispenserComponent2.id == k && dispenserComponent2.storageMode == EStorageDeliveryMode.Demand && dispenserComponent2.filter == filter)
						{
							AddPairIfMissing(dispenserComponent, i, 0, k, 0);
							AddPairIfMissing(dispenserComponent2, i, 0, k, 0);
						}
					}
				}
			}
			else if (dispenserComponent.storageMode == EStorageDeliveryMode.Demand)
			{
				for (int l = 0; l < dispenserComponent.storage.size; l++)
				{
					int filter2 = dispenserComponent.storage.grids[l].filter;
					if (filter2 <= 0 || filter2 == 1099)
					{
						continue;
					}
					for (int m = 1; m < __instance.dispenserCursor; m++)
					{
						DispenserComponent dispenserComponent3 = __instance.dispenserPool[m];
						if (dispenserComponent3 != null && dispenserComponent3.id == m && dispenserComponent3.storageMode == EStorageDeliveryMode.Supply && dispenserComponent3.filter == filter2)
						{
							AddPairIfMissing(dispenserComponent, m, 0, i, 0);
							AddPairIfMissing(dispenserComponent3, m, 0, i, 0);
						}
					}
				}
			}
			int logisticCourierCarries = GameMain.history.logisticCourierCarries;
			dispenserComponent.OnRematchPairs(__instance.factory, __instance.dispenserPool, keyId, logisticCourierCarries);
		}
	}
}
