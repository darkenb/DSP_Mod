# appuns-DSPMultiDistributor — detailed change report

Installed plugin version(s): **0.0.4**. Deduplicate distributor pairs and refresh the panel-owned transport; preserve native order cancellation.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Pair matching and panel ownership — 0.0.4

Use the installed 0.0.3 behavior as the baseline. Duplicate slot filters no longer add the same dispenser pair repeatedly. On close, refresh the panel's own transport instead of the global `localLoadedPlanetFactory`. Exclude filter 1099, which native delivery does not transport.

Preserve native `RefreshDispenserTraffic`, active delivery-grid geometry and courier research. All three filter-equality checks in native rematching recognize the actual storage filters of a `filter=0` distributor. Keep native storageMode and cancellation rules: a valid multi-item order survives, and removing its matching filter cancels it normally.

Checks run actual native refresh plus Harmony postfix and native rematch plus transpiler for repeated filters/refresh, full delivery and both empty-pickup branches. Actual courier flight/delivery and visual acceptance remain untested.

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
