using System;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Reflection.Emit;
using System.Collections.Generic;
using System.Runtime.Serialization;
using BepInEx.Configuration;
using HarmonyLib;
using UXAssist.Patches.Logistics;
static class Check
{
    static T Empty<T>() => (T)FormatterServices.GetUninitializedObject(typeof(T));
    static void Set(object target, string name, object value) =>
        (AccessTools.Field(target.GetType(), name) ?? AccessTools.Field(target.GetType(), "<" + name + ">k__BackingField")).SetValue(target, value);
    static void Call(string name, params object[] args) => AccessTools.Method(typeof(LogisticsPatch), name).Invoke(null,args);
    static void Assert(bool value, string name) { if (!value) throw new Exception(name); Console.WriteLine("PASS " + name); }
    static int Main()
    {
        var original = Assembly.LoadFile(Path.GetFullPath("soarqin-UXAssist/UXAssist.dll"));
        var built = typeof(LogisticsPatch).Assembly;
        var aux = Assembly.LoadFile(Path.GetFullPath("blacksnipebiu-Auxilaryfunction/Auxilaryfunction.dll"));
        var configType = aux.GetType("Auxilaryfunction.AuxConfig", true);
        Assert(configType.GetField("ShowStationInfo").FieldType == typeof(ConfigEntry<bool>),
            "current Auxilaryfunction station-overlay config is located in AuxConfig");
        var loadTop = AccessTools.Method(typeof(MilkyWayCache), "LoadTopTenPlayerData");
        var cachePatch = AccessTools.Method(built.GetType("UXAssist.Patches.PersistPatch", true), "MilkyWayCache_LoadTopTenPlayerData_Transpiler");
        var cacheGenerator = new DynamicMethod("cache", typeof(void), Type.EmptyTypes).GetILGenerator();
        var cacheNative = PatchProcessor.GetOriginalInstructions(loadTop, cacheGenerator);
        var cacheOutput = ((IEnumerable<CodeInstruction>)cachePatch.Invoke(null, new object[] { cacheNative, cacheGenerator })).ToList();
        var countCallback = AccessTools.Method(built.GetType("UXAssist.Functions.UIFunctions", true), "SetTopPlayerCount");
        Assert(cacheOutput.Any(i=>i.Calls(countCallback)),
            "current MilkyWay cache patch binds real BinaryReader.ReadInt32 and inserts player count callback");
        Assert(original.GetManifestResourceNames().OrderBy(s=>s).SequenceEqual(built.GetManifestResourceNames().OrderBy(s=>s)), "all original embedded resource names preserved");
        foreach (string name in original.GetManifestResourceNames()) {
            using(var old = original.GetManifestResourceStream(name)) using(var now = built.GetManifestResourceStream(name)) {
                var a = new MemoryStream(); var b = new MemoryStream(); old.CopyTo(a); now.CopyTo(b);
                Assert(a.ToArray().SequenceEqual(b.ToArray()), "resource bytes " + name);
            }
        }
        var cfg = new ConfigFile(Path.Combine(Path.GetTempPath(),"dsp-phase16-test.cfg"),false); cfg.SaveOnConfigSet=false;
        LogisticsPatch.AutoConfigPLSDroneCount=cfg.Bind("Test","Drones",int.MaxValue);
        LogisticsPatch.AutoConfigILSShipCount=cfg.Bind("Test","Ships",int.MaxValue);
        LogisticsPatch.AutoConfigDispenserCourierCount=cfg.Bind("Test","Bots",int.MaxValue);
        AccessTools.Field(typeof(StorageComponent),"staticLoaded").SetValue(null,true);
        StorageComponent.itemStackCount=new int[12000];
        foreach(int id in new[]{5001,5002,5003}) StorageComponent.itemStackCount[id]=100;
        var player=new Player(); var package=new StorageComponent(4); Set(player,"package",package);
        for(int i=0;i<3;i++) package.grids[i]=new StorageComponent.GRID {itemId=5001+i,count=50,inc=100,stackSize=100};
        var data=Empty<GameData>();Set(data,"mainPlayer",player);GameMain.data=data;
        var factory=Empty<PlanetFactory>(); var planet=Empty<PlanetData>(); planet.factory=factory;
        Set(planet,"factoryLoaded",true);Set(player,"planetData",planet);
        var station=new StationComponent {idleDroneCount=3,workDroneCount=2,workDroneDatas=new DroneData[10],
            idleShipCount=2,workShipCount=1,workShipDatas=new ShipData[6],droneAutoReplenish=true,shipAutoReplenish=true};
        var bot=new DispenserComponent {idleCourierCount=3,workCourierCount=2,workCourierDatas=new CourierData[20],courierAutoReplenish=true};
        Call("StationFillDrones",factory,station);Call("StationFillShips",factory,station);Call("DispenserFillCouriers",factory,bot);
        Assert(station.idleDroneCount==8 && station.idleShipCount==5 && bot.idleCourierCount==18 && package.grids[2].count==35,
               "native inventory fill respects station arrays and LogisticsBotsTweaks expanded capacity");
        Call("StationFillDrones",factory,station);Call("DispenserFillCouriers",factory,bot);
        Assert(package.grids[0].count==45 && package.grids[2].count==35 && package.grids[2].inc==70,
               "repeat fill is idempotent and preserves remaining native inc");
        station.idleDroneCount=0;Call("StationFillDrones",Empty<PlanetFactory>(),station);
        Assert(package.grids[0].count==45 && station.idleDroneCount==0, "foreign factory event cannot consume local player's drones");
        Assert(station.droneAutoReplenish && station.shipAutoReplenish && bot.courierAutoReplenish, "new native auto replenishment flags preserved");
        return 0;
    }
}
