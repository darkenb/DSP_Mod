# NebulaMultiplayerModApi — unchanged reference copy

Included only as a related API dependency. Package 2.1.0, plugin 2.1.0.7 and assembly 2.1.0.0 are preserved byte-for-byte; no full Nebula multiplayer implementation is installed in this profile. Source/Reconstructed contains the exact installed API reconstruction. This copy does not claim network/host-client acceptance or a local gameplay modification.

The analysis and proposed fixes in this handoff were developed with assistance from the GPT 6.1 Sol model. English documentation accompanies the code to explain what changed, why it changed, and the available validation results.
