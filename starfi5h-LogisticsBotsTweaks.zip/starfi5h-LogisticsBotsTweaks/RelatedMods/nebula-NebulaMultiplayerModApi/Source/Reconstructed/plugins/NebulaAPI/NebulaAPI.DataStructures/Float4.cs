using NebulaAPI.Interfaces;
using NebulaAPI.Packets;
using UnityEngine;

namespace NebulaAPI.DataStructures;

[RegisterNestedType]
public struct Float4 : INetSerializable
{
	public float x;

	public float y;

	public float z;

	public float w;

	public Float4(float x, float y, float z, float w)
	{
		this.x = x;
		this.y = y;
		this.z = z;
		this.w = w;
	}

	public Float4(Quaternion value)
	{
		x = value.x;
		y = value.y;
		z = value.z;
		w = value.w;
	}

	public Color ToColor()
	{
		return new Color(x, y, z, w);
	}

	public Color32 ToColor32()
	{
		return new Color32((byte)x, (byte)y, (byte)z, (byte)w);
	}

	public static Color32[] ToColor32(Float4[] float4s)
	{
		Color32[] array = new Color32[float4s.Length];
		for (int i = 0; i < float4s.Length; i++)
		{
			array[i] = float4s[i].ToColor32();
		}
		return array;
	}

	public static Float4 ToFloat4(Color32 color32)
	{
		return new Float4((int)color32.r, (int)color32.g, (int)color32.b, (int)color32.a);
	}

	public static Float4[] ToFloat4(Color32[] color32s)
	{
		Float4[] array = new Float4[color32s.Length];
		for (int i = 0; i < color32s.Length; i++)
		{
			array[i] = new Float4((int)color32s[i].r, (int)color32s[i].g, (int)color32s[i].b, (int)color32s[i].a);
		}
		return array;
	}

	public void Serialize(INetDataWriter writer)
	{
		writer.Put(x);
		writer.Put(y);
		writer.Put(z);
		writer.Put(w);
	}

	public void Deserialize(INetDataReader reader)
	{
		x = reader.GetFloat();
		y = reader.GetFloat();
		z = reader.GetFloat();
		w = reader.GetFloat();
	}

	public override string ToString()
	{
		return $"x: {x}, y: {y}, z: {z}, w: {w}";
	}
}
