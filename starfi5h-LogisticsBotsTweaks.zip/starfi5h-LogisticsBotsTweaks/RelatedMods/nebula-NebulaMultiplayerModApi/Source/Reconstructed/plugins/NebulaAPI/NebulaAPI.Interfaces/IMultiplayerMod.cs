namespace NebulaAPI.Interfaces;

public interface IMultiplayerMod
{
	string Version { get; }

	bool CheckVersion(string hostVersion, string clientVersion);
}
