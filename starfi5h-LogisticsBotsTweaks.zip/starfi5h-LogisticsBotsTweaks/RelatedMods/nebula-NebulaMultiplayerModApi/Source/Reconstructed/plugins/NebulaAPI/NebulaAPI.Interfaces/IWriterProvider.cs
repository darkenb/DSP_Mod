using System;
using System.IO;

namespace NebulaAPI.Interfaces;

public interface IWriterProvider : IDisposable
{
	BinaryWriter BinaryWriter { get; }

	byte[] CloseAndGetBytes();
}
