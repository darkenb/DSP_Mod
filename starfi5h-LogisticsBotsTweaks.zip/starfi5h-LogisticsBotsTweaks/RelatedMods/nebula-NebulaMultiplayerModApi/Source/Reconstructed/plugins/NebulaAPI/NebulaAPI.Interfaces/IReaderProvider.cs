using System;
using System.IO;

namespace NebulaAPI.Interfaces;

public interface IReaderProvider : IDisposable
{
	BinaryReader BinaryReader { get; }
}
