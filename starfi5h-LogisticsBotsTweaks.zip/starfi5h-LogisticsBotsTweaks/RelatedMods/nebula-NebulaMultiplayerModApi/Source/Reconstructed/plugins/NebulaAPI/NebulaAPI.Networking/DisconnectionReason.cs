namespace NebulaAPI.Networking;

public enum DisconnectionReason
{
	Normal = 1000,
	ProtocolError = 1002,
	InvalidData = 1007,
	HostStillLoading = 2000,
	ClientRequestedDisconnect = 2001,
	ModVersionMismatch = 2002,
	GameVersionMismatch = 2003,
	ModIsMissing = 2500,
	ModIsMissingOnServer = 2501
}
