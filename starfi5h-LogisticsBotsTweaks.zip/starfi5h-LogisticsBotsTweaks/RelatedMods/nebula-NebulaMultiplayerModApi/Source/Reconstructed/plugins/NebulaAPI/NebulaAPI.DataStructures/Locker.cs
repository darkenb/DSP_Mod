using System;
using System.Threading;

namespace NebulaAPI.DataStructures;

public readonly struct Locker : IDisposable
{
	private readonly object lockObject;

	public Locker(object lockObject)
	{
		this.lockObject = lockObject;
		Monitor.Enter(lockObject);
	}

	public void Dispose()
	{
		Monitor.Exit(lockObject);
	}
}
