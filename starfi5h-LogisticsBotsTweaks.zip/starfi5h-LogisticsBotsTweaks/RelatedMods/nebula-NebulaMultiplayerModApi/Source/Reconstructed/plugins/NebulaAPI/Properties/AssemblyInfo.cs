using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.Versioning;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyFileVersion("2.1.0.7")]
[assembly: AssemblyInformationalVersion("2.1.0.7+924606f")]
[assembly: AssemblyCompany("Nebula Mod Team")]
[assembly: AssemblyConfiguration("Release")]
[assembly: AssemblyDescription("API for other mods to work with the Nebula Multiplayer Mod for Dyson Sphere Program.")]
[assembly: AssemblyProduct("NebulaAPI")]
[assembly: AssemblyTitle("NebulaAPI")]
[assembly: AssemblyVersion("2.1.0.0")]
[module: RefSafetyRules(11)]
