using System;

namespace NebulaAPI.Packets;

[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct)]
public class HidePacketInDebugLogsAttribute : Attribute
{
}
