namespace NebulaAPI.Networking;

public enum EConnectionStatus
{
	Undefined,
	Pending,
	Syncing,
	Connected
}
