using System;

namespace NebulaAPI.GameState;

public interface ILocalPlayer : IDisposable
{
	bool IsInitialDataReceived { get; set; }

	bool IsHost { get; set; }

	bool IsClient { get; }

	bool IsNewPlayer { get; set; }

	ushort Id { get; }

	IPlayerData Data { get; set; }
}
