using System.IO;

namespace NebulaAPI.Interfaces;

public interface IMultiplayerModWithSettings : IMultiplayerMod
{
	void Export(BinaryWriter w);

	void Import(BinaryReader r);
}
