using System;

namespace NebulaAPI.Networking;

public interface INebulaConnection : IEquatable<INebulaConnection>
{
	bool IsAlive { get; }

	int Id { get; }

	EConnectionStatus ConnectionStatus { get; set; }

	void SendPacket<T>(T packet) where T : class, new();

	void SendRawPacket(byte[] rawData);
}
