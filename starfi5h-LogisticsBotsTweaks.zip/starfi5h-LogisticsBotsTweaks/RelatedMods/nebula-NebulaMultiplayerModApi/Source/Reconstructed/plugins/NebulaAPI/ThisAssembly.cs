using System;
using System.CodeDom.Compiler;
using System.Diagnostics.CodeAnalysis;

[GeneratedCode("Nerdbank.GitVersioning.Tasks", "3.8.118.27059")]
[ExcludeFromCodeCoverage]
internal static class ThisAssembly
{
	internal const string AssemblyConfiguration = "Release";

	internal const string AssemblyFileVersion = "2.1.0.7";

	internal const string AssemblyInformationalVersion = "2.1.0.7+924606f";

	internal const string AssemblyName = "NebulaAPI";

	internal const string AssemblyTitle = "NebulaAPI";

	internal const string AssemblyVersion = "2.1.0.0";

	internal static readonly DateTime GitCommitAuthorDate = new DateTime(638969190330000000L, DateTimeKind.Utc);

	internal static readonly DateTime GitCommitDate = new DateTime(638969190330000000L, DateTimeKind.Utc);

	internal const string GitCommitId = "924606f63bc4be9ac347c1c455bf77b6f60fd620";

	internal const bool IsPrerelease = false;

	internal const bool IsPublicRelease = true;

	internal const string RootNamespace = "NebulaAPI";
}
