using System;

namespace NebulaAPI.Packets;

[AttributeUsage(AttributeTargets.Class)]
public class RegisterPacketProcessorAttribute : Attribute
{
}
