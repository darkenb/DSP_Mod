using System.IO;

namespace crecheng.DSPModSave;

public interface IModCanSave
{
	void Export(BinaryWriter w);

	void Import(BinaryReader r);

	void IntoOtherSave();
}
