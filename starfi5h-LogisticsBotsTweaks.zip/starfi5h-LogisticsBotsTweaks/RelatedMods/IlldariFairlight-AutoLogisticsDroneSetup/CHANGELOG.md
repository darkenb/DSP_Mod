# IlldariFairlight-AutoLogisticsDroneSetup — detailed change report

Installed plugin version(s): **1.8.2**. Refill only missing workers using runtime capacity and existing idle/working counts; do not consume local stock for foreign factories.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Capacity-aware initial refill — 1.8.2

The source matched installed 1.8.1. Initial refill now takes only `target - existing idle/working total` and adds the quantity actually obtained to the idle count. Repeated callbacks consume nothing extra, and workers already supplied by another mod are not overwritten.

Read capacity from the runtime worker arrays, including arrays expanded by other mods. Preserve the native 64-bit vessel-ID mask limit, storage/station source priority, delivery-first `PlayerPackageUtility` transfers and inc separation. Skip reserved source index 0. Creation events for a remote/foreign factory cannot consume the local player's inventory.

Retain native drone/ship/courier auto-replenishment settings; initial fill coexists with ongoing native replenishment and accounts for prior fills by other mods.

Checks covered 36 game references, 4 Harmony targets, assembly/public contracts and GUID. Actual StorageComponent/DeliveryPackage/PlayerPackageUtility tests covered delivery priority, remaining package count/inc, existing idle/working workers, repeated fill, limited stock, enlarged courier arrays, large totals/overflow and foreign-factory events. The fixture verifies the replenishment flags are preserved, not the complete ongoing native tick. UXAssist/Auxilaryfunction/LogisticsBotsTweaks interaction, real UI and sustained replenishment remain live acceptance work.

## Recorded source commits

- `c273cb0c9307bed136b451fcac0b08ad603e6876`

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
