using System;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization;
using BepInEx.Configuration;
using BepInEx.Logging;
using DSP_Mods;

static class Check
{
    static T Empty<T>() => (T)FormatterServices.GetUninitializedObject(typeof(T));
    static void Set(object target, string name, object value)
    {
        var field = target.GetType().GetField(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);
        if (field == null) field = target.GetType().GetField("<" + name + ">k__BackingField", BindingFlags.Instance | BindingFlags.NonPublic);
        if (field != null) field.SetValue(target, value);
        else target.GetType().GetProperty(name, BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic).SetValue(target, value, null);
    }
    static void Assert(bool value, string name) { if (!value) throw new Exception(name); Console.WriteLine("PASS " + name); }
    static void Fill(string name, object target, PrefabDesc desc, object util, int desired)
        => typeof(AutoLogisticsDroneSetup).GetMethod(name, BindingFlags.NonPublic | BindingFlags.Static).Invoke(null, new[] {target, desc, util, desired});
    static int Main()
    {
        typeof(StorageComponent).GetField("staticLoaded", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic).SetValue(null, true);
        StorageComponent.itemStackCount = new int[12000];
        StorageComponent.itemStackCount[5001] = StorageComponent.itemStackCount[5002] = StorageComponent.itemStackCount[5003] = 100;
        var config = new ConfigFile(Path.Combine(Path.GetTempPath(), "dsp-phase10-test.cfg"), false); config.SaveOnConfigSet = false;
        ModConfig.InitConfig(config); DSP_Mods.Logger.Init(new ManualLogSource("AutoFillTest"));
        var data = Empty<GameData>(); var player = new Player(); Set(data, "mainPlayer", player); GameMain.data = data;
        var planet = Empty<PlanetData>(); var factory = Empty<PlanetFactory>(); planet.factory = factory;
        Set(planet, "factoryLoaded", true); Set(player, "planetData", planet);
        var package = new StorageComponent(4); Set(player, "package", package);
        var delivery = new DeliveryPackage(); delivery.Init(); delivery.unlocked = true; Set(player, "deliveryPackage", delivery);
        factory.factoryStorage = Empty<FactoryStorage>(); factory.factoryStorage.storagePool = new StorageComponent[1]; factory.factoryStorage.storageCursor = 1;
        factory.transport = Empty<PlanetTransport>(); factory.transport.stationPool = new StationComponent[1]; factory.transport.stationCursor = 1;
        package.grids[0] = new StorageComponent.GRID {itemId = 5001, count = 7, inc = 14, stackSize = 100};
        package.grids[1] = new StorageComponent.GRID {itemId = 5002, count = 4, inc = 0, stackSize = 100};
        package.grids[2] = new StorageComponent.GRID {itemId = 5003, count = 10, inc = 10, stackSize = 100};
        delivery.grids[0] = new DeliveryPackage.GRID {itemId = 5001, count = 3, inc = 3, stackSize = 100, stackSizeMultiplier = 1};
        var util = Activator.CreateInstance(typeof(AutoLogisticsDroneSetup).Assembly.GetType("DSP_Mods.StorageUtility"), true);
        var desc = new PrefabDesc {stationMaxDroneCount = 10, stationMaxShipCount = 10, dispenserMaxCourierCount = 10};
        var station = new StationComponent {idleDroneCount = 3, workDroneCount = 2, workDroneDatas = new DroneData[10],
            idleShipCount = 2, workShipCount = 1, workShipDatas = new ShipData[10], droneAutoReplenish = true, shipAutoReplenish = true};
        Fill("AddDrones", station, desc, util, 8);
        Assert(station.idleDroneCount == 6 && station.workDroneCount == 2 && package.grids[0].count == 7 && package.grids[0].inc == 14 && delivery.grids[0].count == 0,
            "additive drone fill consumes only missing count from native delivery priority");
        Fill("AddDrones", station, desc, util, 8);
        Assert(package.grids[0].count == 7 && station.idleDroneCount == 6, "repeated fill does not consume inventory twice");
        Fill("AddShips", station, desc, util, -1);
        Assert(station.idleShipCount == 6 && station.workShipCount == 1 && package.grids[1].count == 0, "short inventory adds only actual ships and preserves working ships");
        var bots = new DispenserComponent {idleCourierCount = 3, workCourierCount = 2, workCourierDatas = new CourierData[20], courierAutoReplenish = true};
        Fill("AddBots", bots, desc, util, -1);
        Assert(bots.idleCourierCount == 13 && bots.workCourierCount == 2 && package.grids[2].count == 0,
            "runtime extended bot capacity used without overwriting existing bots");
        Assert(station.droneAutoReplenish && station.shipAutoReplenish && bots.courierAutoReplenish, "native auto replenish settings preserved");
        var remoteTransport = Empty<PlanetTransport>(); remoteTransport.factory = Empty<PlanetFactory>();
        AutoLogisticsDroneSetup.NewStationComponent_PostFix(remoteTransport, 1, 1, desc);
        Assert(package.grids[0].count == 7, "foreign factory event cannot consume local inventory");
        var needed = typeof(AutoLogisticsDroneSetup).Assembly.GetType("DSP_Mods.FillQuantity").GetMethod("Needed");
        Assert((int)needed.Invoke(null, new object[] {100, int.MaxValue, int.MaxValue, -1}) == 0, "large existing totals cannot overflow into extra withdrawal");
        Assert((int)needed.Invoke(null, new object[] {10, 3, 7, -1}) == 0
            && (int)needed.Invoke(null, new object[] {10, 3, 2, 0}) == 0
            && (int)needed.Invoke(null, new object[] {10, 3, 2, 100}) == 5, "working count, disabled target and capacity clamping respected");
        return 0;
    }
}
