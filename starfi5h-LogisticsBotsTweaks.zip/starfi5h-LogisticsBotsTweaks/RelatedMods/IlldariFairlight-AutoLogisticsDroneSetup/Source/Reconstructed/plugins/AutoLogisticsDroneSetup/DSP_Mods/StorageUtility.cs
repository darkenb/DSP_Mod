using System.Collections.Generic;
using System.Linq;

namespace DSP_Mods;

internal class StorageUtility
{
	public enum Source
	{
		Inventory,
		Storage,
		Stations
	}

	private struct StorageSource
	{
		public Source Source { get; set; }

		public int Priority { get; set; }
	}

	private PlayerPackageUtility PlayerPackageUtility;

	private IEnumerable<StorageSource> GetStorageSources()
	{
		List<StorageSource> list = new List<StorageSource>();
		AddSource(list, Source.Inventory, ModConfig.InventoryPriority.Value);
		AddSource(list, Source.Storage, ModConfig.StoragePriority.Value);
		AddSource(list, Source.Stations, ModConfig.StationsPriority.Value);
		return list.OrderBy((StorageSource s) => s.Priority).ToList();
	}

	private void AddSource(List<StorageSource> sources, Source source, int priority)
	{
		if (priority >= 0)
		{
			sources.Add(new StorageSource
			{
				Source = source,
				Priority = priority
			});
		}
	}

	public int RemoveItems(Item item, int desiredAmount)
	{
		Player mainPlayer = GameMain.mainPlayer;
		PlanetFactory planetFactory = mainPlayer?.factory;
		if (mainPlayer == null || planetFactory == null)
		{
			return 0;
		}
		if (desiredAmount <= 0)
		{
			return 0;
		}
		int num = 0;
		foreach (StorageSource storageSource in GetStorageSources())
		{
			int num2 = 0;
			switch (storageSource.Source)
			{
			case Source.Inventory:
				num2 = RemoveFromPlayer(mainPlayer, item, desiredAmount);
				break;
			case Source.Storage:
				num2 = RemoveFromStorage(planetFactory, item, desiredAmount);
				break;
			case Source.Stations:
				num2 = RemoveFromStations(planetFactory, item, desiredAmount);
				break;
			}
			num += num2;
			desiredAmount -= num2;
			if (desiredAmount <= 0)
			{
				break;
			}
		}
		return num;
	}

	private int RemoveFromPlayer(Player player, Item item, int desiredAmount)
	{
		if (player == null || player.package == null)
		{
			return 0;
		}
		if (PlayerPackageUtility == null || PlayerPackageUtility.player != player)
		{
			PlayerPackageUtility = new PlayerPackageUtility(player);
		}
		int itemId = item.Id;
		int inc = 0;
		int count = desiredAmount;
		PlayerPackageUtility.TryTakeItemFromAllPackages(ref itemId, ref count, out inc, deliveryFirst: true);
		if (count > 0)
		{
			Logger.Instance.LogInfo(string.Format("Removed {0} {1}{2} from player", count, item.Name, (count == 1) ? "" : "s"));
		}
		return count;
	}

	private int RemoveFromStorage(PlanetFactory factory, Item item, int desiredAmount)
	{
		int num = 0;
		for (int i = 1; i < factory.factoryStorage.storageCursor; i++)
		{
			if (num >= desiredAmount)
			{
				break;
			}
			StorageComponent storageComponent = factory.factoryStorage.storagePool[i];
			if (storageComponent != null && storageComponent.id == i)
			{
				int itemId = item.Id;
				int inc = 0;
				int count = desiredAmount - num;
				storageComponent.TakeTailItems(ref itemId, ref count, out inc);
				num += count;
				if (count > 0)
				{
					Logger.Instance.LogInfo(string.Format("Removed {0} {1}{2} from storage", count, item.Name, (count == 1) ? "" : "s"));
				}
			}
		}
		return num;
	}

	private int RemoveFromStations(PlanetFactory factory, Item item, int desiredAmount)
	{
		int num = 0;
		for (int i = 1; i < factory.transport.stationCursor; i++)
		{
			if (num >= desiredAmount)
			{
				break;
			}
			StationComponent stationComponent = factory.transport.stationPool[i];
			if (stationComponent != null && stationComponent.id == i)
			{
				int itemId = item.Id;
				int count = desiredAmount - num;
				int inc = 0;
				stationComponent.TakeItem(ref itemId, ref count, out inc);
				num += count;
				if (count > 0)
				{
					Logger.Instance.LogInfo(string.Format("Removed {0} {1}{2} from station", count, item.Name, (count == 1) ? "" : "s"));
				}
			}
		}
		return num;
	}
}
