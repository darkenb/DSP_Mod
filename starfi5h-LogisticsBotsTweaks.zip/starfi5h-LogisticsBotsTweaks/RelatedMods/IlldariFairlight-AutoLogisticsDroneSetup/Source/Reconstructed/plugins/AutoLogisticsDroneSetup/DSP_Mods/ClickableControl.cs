using System;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

namespace DSP_Mods;

internal class ClickableControl : MonoBehaviour, IPointerEnterHandler, IEventSystemHandler, IPointerExitHandler, IPointerClickHandler
{
	private GameObject hoverTextObj;

	public string HoverText = "";

	public Text TextObject;

	public event Action<PointerEventData> OnClick;

	public void Start()
	{
		if (TextObject != null)
		{
			hoverTextObj = TextObject.gameObject;
			hoverTextObj.SetActive(value: false);
			TextObject.text = HoverText;
		}
	}

	public void OnPointerEnter(PointerEventData eventData)
	{
		if (hoverTextObj == null)
		{
			Start();
		}
		else
		{
			hoverTextObj.SetActive(value: true);
		}
	}

	public void OnPointerExit(PointerEventData eventData)
	{
		if (hoverTextObj == null)
		{
			Start();
		}
		else
		{
			hoverTextObj.SetActive(value: false);
		}
	}

	public void OnPointerClick(PointerEventData eventData)
	{
		this.OnClick?.Invoke(eventData);
	}
}
