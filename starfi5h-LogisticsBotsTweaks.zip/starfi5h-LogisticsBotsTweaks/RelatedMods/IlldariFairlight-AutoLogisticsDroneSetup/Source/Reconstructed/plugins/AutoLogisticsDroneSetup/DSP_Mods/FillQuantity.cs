using System;

namespace DSP_Mods;

internal static class FillQuantity
{
	public static int Needed(int capacity, int idle, int working, int desired)
	{
		if (capacity <= 0 || idle < 0 || working < 0)
		{
			return 0;
		}
		long num = ((desired < 0) ? capacity : Math.Min(desired, capacity));
		return (int)Math.Max(0L, num - idle - working);
	}
}
