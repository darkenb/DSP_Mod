using BepInEx.Configuration;
using HarmonyLib;
using UnityEngine;

namespace DSP_Mods;

public class ModConfigWindow
{
	private static Rect WindowRect = new Rect(Screen.width / 3 * 2, 100f, 500f, 420f);

	public static bool Visible { get; set; }

	public static void Open()
	{
		Visible = true;
	}

	public static void Close()
	{
		Visible = false;
	}

	public static void OnGUI()
	{
		if (Input.GetKeyDown(KeyCode.Escape))
		{
			Visible = false;
		}
		else
		{
			WindowRect = GUILayout.Window(1786512, WindowRect, WindowFunction, "AutoLogisticsDroneSetup config");
		}
	}

	private static void WindowFunction(int id)
	{
		GUILayout.BeginArea(new Rect(WindowRect.width - 25f, 0f, 25f, 25f));
		if (GUILayout.Button("X"))
		{
			Close();
			return;
		}
		GUILayout.EndArea();
		GUILayout.BeginVertical(GUI.skin.box);
		DrawResetButton();
		string text = "";
		foreach (ConfigDefinition key in ModConfig.ConfigFile.Keys)
		{
			if (text != key.Section)
			{
				DrawSectionLabel(key.Section);
			}
			DrawOption(ModConfig.ConfigFile[key]);
			text = key.Section;
		}
		GUILayout.EndVertical();
		GUI.DragWindow();
	}

	private static void DrawResetButton()
	{
		GUILayout.BeginHorizontal();
		GUILayout.FlexibleSpace();
		if (GUILayout.Button("Restore Defaults", GUILayout.Width(125f)))
		{
			ModConfig.ResetAllToDefault();
		}
		GUILayout.EndVertical();
	}

	private static void DrawSectionLabel(string text)
	{
		GUILayout.BeginHorizontal();
		GUILayout.FlexibleSpace();
		GUILayout.Label(text);
		GUILayout.FlexibleSpace();
		GUILayout.EndHorizontal();
	}

	private static void DrawOption(ConfigEntryBase configEntry)
	{
		GUILayout.BeginHorizontal();
		GUILayout.Label(new GUIContent(configEntry.Definition.Key, configEntry.Description.Description));
		GUILayout.FlexibleSpace();
		if (configEntry.SettingType == typeof(bool))
		{
			DrawBoolValue(configEntry, 75f);
		}
		else if (configEntry.SettingType == typeof(int))
		{
			DrawIntValue(configEntry, 75f);
		}
		else
		{
			Logger.Instance.LogInfo($"Attempted to draw invalid option type for setting {configEntry.Definition.Key}. Setting is of type {configEntry.SettingType}");
		}
		GUILayout.EndHorizontal();
	}

	private static void DrawBoolValue(ConfigEntryBase configEntry, float width)
	{
		if (configEntry.SettingType != typeof(bool))
		{
			Logger.Instance.LogInfo($"Attempted to draw invalid ccnfig type. Expected bool but got {configEntry.SettingType}");
			return;
		}
		bool flag = (bool)configEntry.BoxedValue;
		GUILayout.BeginHorizontal(GUILayout.Width(width));
		bool flag2 = GUILayout.Toggle(flag, flag ? "Enabled" : "Disabled");
		if (flag2 != flag)
		{
			configEntry.BoxedValue = flag2;
		}
		GUILayout.EndHorizontal();
	}

	private static void DrawIntValue(ConfigEntryBase configEntry, float width)
	{
		if (configEntry.SettingType != typeof(int))
		{
			Logger.Instance.LogInfo($"Attempted to draw invalid ccnfig type. Expected int but got {configEntry.SettingType}");
			return;
		}
		int num = (int)configEntry.BoxedValue;
		GUILayout.BeginHorizontal(GUILayout.Width(width));
		if (int.TryParse(GUILayout.TextField(num.ToString()), out var result) && result != num)
		{
			configEntry.BoxedValue = result;
		}
		GUILayout.EndHorizontal();
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIGame), "On_E_Switch")]
	public static bool On_E_Switch_Prefix()
	{
		if (Visible)
		{
			Visible = false;
		}
		return true;
	}
}
