# Related mods and code references — starfi5h-LogisticsBotsTweaks

All listed copies are inside this mod folder. They are one-level reference copies with their own Source, InstalledPackage, metadata and English change notes. Required installed dependencies of those copies are flattened into the same RelatedMods directory; copies never recursively contain another RelatedMods directory.

Dependency declarations (including optional compatibility plugins), compiled member calls and native integration/test context are distinguished below. A shared native API touchpoint is not presented as a direct foreign-method call. Original game/BepInEx SDK files and uninstalled optional mods are not fabricated or downloaded. 

## CommonAPI-CommonAPI

Copy: `RelatedMods/CommonAPI-CommonAPI/`.

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder. Via: `soarqin-UXAssist`.

### Dependency references inside the copied mods

`RelatedMods/soarqin-UXAssist/Source/Reconstructed/plugins/UXAssist/UXAssist/UXAssist.cs:23`

```csharp
namespace UXAssist;

[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "CustomKeyBindSystem" })]
```

`RelatedMods/soarqin-UXAssist/Source/Reconstructed/plugins/UXAssist/UXAssist.ModsCompat/CommonAPIWrapper.cs:11`

```csharp
	public static void Run(Harmony harmony)
	{
		if (ModCompatHelper.TryGetLoadedPluginInfo("dsp.common-api.CommonAPI", out var pluginInfo) && !(pluginInfo.Metadata.Version > new System.Version(1, 6, 7, 0)))
		{
			harmony.Patch(AccessTools.Method(typeof(GameOption), "InitKeys"), new HarmonyMethod(AccessTools.Method(typeof(CommonAPIWrapper), "PatchInitKeys"), 800));
```

`RelatedMods/soarqin-UXAssist/Source/EarlierWorkingSource/Common/ModFeatures/IModFeature.cs:15`

```csharp
/// <item><see cref="Init"/> runs <strong>eagerly</strong> at registration time — synchronously inside
/// <see cref="ModFeatureRegistry.Register{T}"/>, normally during the registering mod's BepInEx
/// <c>Awake</c> phase. It is the phase for early setup such as keybind registration via CommonAPI's
/// <c>CustomKeyBindSystem</c>, whose registered bindings are copied by the game's
/// <c>UIOptionWindow._OnCreate</c> only after all plugins finish loading. A late-discovered feature may
```

### Code in the related copy

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/BaseSubmodule.cs:18`

```csharp
		{
			string name = GetType().Name;
			throw new InvalidOperationException(name + " is not loaded. Please use [CommonAPISubmoduleDependency(nameof(" + name + ")]");
		}
	}
```

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs:16`

```csharp
namespace CommonAPI;

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
```

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPISubmoduleDependency.cs:6`

```csharp

[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
public class CommonAPISubmoduleDependency : Attribute
{
	public string?[]? SubmoduleNames { get; }
```

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ConfigFileExtension.cs:33`

```csharp
				entry.SetSerializedValue(item.Value);
				list.Add(item.Key);
				CommonAPIPlugin.logger.LogInfo("Migrating config from " + oldSection + ":" + key + " to " + newSection + ":" + key);
			}
		}
```

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/HarmonyRegisterExtension.cs:31`

```csharp
			else
			{
				CommonAPIPlugin.logger.LogInfo("Failed to patch: " + item.FullName + ".");
			}
		}
```

## CommonAPI-DSPModSave

Copy: `RelatedMods/CommonAPI-DSPModSave/`.

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder. Via: `CommonAPI-CommonAPI`, `soarqin-UXAssist`.

### Dependency references inside the copied mods

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs:18`

```csharp
[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
{
```

`RelatedMods/CommonAPI-CommonAPI/Source/EarlierWorkingSource/CommonAPIPlugin.cs:31`

```csharp
    [BepInPlugin(GUID, DISPNAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
    {
```

`RelatedMods/soarqin-UXAssist/Source/Reconstructed/plugins/UXAssist/UXAssist/UXAssist.cs:24`

```csharp

[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "CustomKeyBindSystem" })]
[BepInPlugin("org.soardev.uxassist", "UXAssist", "1.6.3")]
```

`RelatedMods/soarqin-UXAssist/Source/EarlierWorkingSource/UXAssist.cs:26`

```csharp

[BepInDependency(CommonAPIPlugin.GUID)]
[BepInDependency(DSPModSavePlugin.MODGUID)]
[CommonAPISubmoduleDependency(nameof(CustomKeyBindSystem))]
[BepInPlugin(PluginInfo.PLUGIN_GUID, PluginInfo.PLUGIN_NAME, PluginInfo.PLUGIN_VERSION)]
```

### Code in the related copy

`RelatedMods/CommonAPI-DSPModSave/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs:15`

```csharp
namespace crecheng.DSPModSave;

[BepInPlugin("crecheng.DSPModSave", "DSP Mod Save", "1.2.3")]
public class DSPModSavePlugin : BaseUnityPlugin
{
```

`RelatedMods/CommonAPI-DSPModSave/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs:12`

```csharp
	private static void EnterGame()
	{
		DSPModSavePlugin.logger.LogInfo("Enter New Game");
		foreach (ModSaveSettings value in DSPModSavePlugin.allModData.Values)
		{
```

`RelatedMods/CommonAPI-DSPModSave/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs:13`

```csharp
		if (__result)
		{
			DSPModSavePlugin.OnSave(saveName);
		}
	}
```

`RelatedMods/CommonAPI-DSPModSave/Evidence/InitialPhase/check.cs:19`

```csharp
static class Check
{
    static void Call(string method, params object[] args) {AccessTools.Method(typeof(DSPModSavePlugin), method).Invoke(null, args);}
    static int Main()
    {
```

`RelatedMods/CommonAPI-DSPModSave/Source/EarlierWorkingSource/DSPModSavePlugin.cs:20`

```csharp
{
    [BepInPlugin(MODGUID, MODNAME, VERSION)]
    public class DSPModSavePlugin : BaseUnityPlugin
    {
        public const string MODGUID = "crecheng.DSPModSave";
```

## IlldariFairlight-AutoLogisticsDroneSetup

Copy: `RelatedMods/IlldariFairlight-AutoLogisticsDroneSetup/`.

- **fix_integration_context**: Initial refill reads expanded runtime courier capacity and preserves working/idle data.

### Code in this mod

`Source/Reconstructed/plugins/LogisticsBotsTweaks/LogisticsBotsTweaks/Patch_Distributor.cs:33`

```csharp
	{
		int val = dispenserMaxCourierCount;
		CourierData[] workCourierDatas = component.workCourierDatas;
		int num = Math.Max(val, (workCourierDatas != null) ? workCourierDatas.Length : 0);
		int val2 = num;
```

`Evidence/InitialPhase/check.cs:36`

```csharp
        Assert(Math.Abs(history.logisticCourierSpeedModified - 68) < 0.001, "repeated load/unlock adjustment does not compound speed");
        distributor.GetField("dispenserMaxCourierCount").SetValue(null, 20);
        var component = new DispenserComponent {workCourierDatas = new CourierData[10], orders = new DeliveryLogisticOrder[10], holdupPackage = new DispenserStore[20], idleCourierCount = 3, workCourierCount = 2};
        component.workCourierDatas[1].itemId = 1001; component.holdupPackage[1].itemId = 1002; component.holdupPackage[1].count = 7;
        Call(distributor, "Expand", component);
```

`Source/EarlierWorkingSource/LogisticsBotsTweaks.cs:86`

```csharp
        public static void Expand(DispenserComponent component)
        {
            int count = Math.Max(dispenserMaxCourierCount, component.workCourierDatas?.Length ?? 0);
            count = Math.Max(count, component.orders?.Length ?? 0);
            count = Math.Max(count, (component.holdupPackage?.Length ?? 0) / 2);
```

`Source/Reconstructed/plugins/LogisticsBotsTweaks/LogisticsBotsTweaks/Patch_LogisticsBot.cs:17`

```csharp
	[HarmonyPatch(typeof(GameHistoryData), "SetForNewGame")]
	[HarmonyPatch(typeof(GameHistoryData), "UnlockTechFunction")]
	public static void LogisticCourierSpeedModified(GameHistoryData __instance)
	{
		if (logisticsBotSpeedScale != 1f)
```

`Source/Reconstructed/plugins/LogisticsBotsTweaks/LogisticsBotsTweaks/Plugin.cs:26`

```csharp
		Patch_LogisticsBot.logisticsBotCapacity = base.Config.Bind("Bot", "Capacity", 0, "If > 0, Overwirte carrying capacity of logistics bots. 覆写配送运输机运载量").Value;
		Patch_LogisticsBot.dispenserDeliveryMaxAngle = base.Config.Bind("Bot", "DeliveryMaxAngle", 0f, new ConfigDescription("If > 0, Overwirte distribution range of logistics bots. 覆写配送范围(度)", new AcceptableValueRange<float>(0f, 180f))).Value;
		Patch_Distributor.dispenserMaxCourierCount = base.Config.Bind("Distributor", "MaxBotCount", 10, "Max logistics bots count. 物流配送器的最大运输机数量").Value;
		Patch_Distributor.maxChargePowerScale = base.Config.Bind("Distributor", "MaxChargePowerScale", 1f, "Scale of max charge power. 物流配送器的最大充电功率倍率").Value;
		Log = base.Logger;
```

### Code in the related copy

`RelatedMods/IlldariFairlight-AutoLogisticsDroneSetup/Source/Reconstructed/plugins/AutoLogisticsDroneSetup/DSP_Mods/AutoLogisticsDroneSetup.cs:144`

```csharp
		if (dispenser != null && desc != null && util != null)
		{
			int num = FillQuantity.Needed((dispenser.workCourierDatas != null) ? dispenser.workCourierDatas.Length : desc.dispenserMaxCourierCount, dispenser.idleCourierCount, dispenser.workCourierCount, desiredAmount);
			if (num > 0)
			{
```

`RelatedMods/IlldariFairlight-AutoLogisticsDroneSetup/Evidence/InitialPhase/check.cs:51`

```csharp
        Fill("AddShips", station, desc, util, -1);
        Assert(station.idleShipCount == 6 && station.workShipCount == 1 && package.grids[1].count == 0, "short inventory adds only actual ships and preserves working ships");
        var bots = new DispenserComponent {idleCourierCount = 3, workCourierCount = 2, workCourierDatas = new CourierData[20], courierAutoReplenish = true};
        Fill("AddBots", bots, desc, util, -1);
        Assert(bots.idleCourierCount == 13 && bots.workCourierCount == 2 && package.grids[2].count == 0,
```

`RelatedMods/IlldariFairlight-AutoLogisticsDroneSetup/Source/EarlierWorkingSource/AutoLogisticsDroneSetup.cs:129`

```csharp
        {
            if (dispenser == null || desc == null || util == null) return;
            int capacity = dispenser.workCourierDatas != null ? dispenser.workCourierDatas.Length : desc.dispenserMaxCourierCount;
            int need = FillQuantity.Needed(capacity, dispenser.idleCourierCount, dispenser.workCourierCount, desiredAmount);
            if (need > 0) dispenser.idleCourierCount += util.RemoveItems(Bot, need);
```

## appuns-DSPMultiDistributor

Copy: `RelatedMods/appuns-DSPMultiDistributor/`.

- **fix_integration_context**: Distributor pairing and courier dispatch share the expanded native courier capacity and order arrays.

### Code in this mod

`Source/Reconstructed/plugins/LogisticsBotsTweaks/LogisticsBotsTweaks/Patch_Distributor.cs:17`

```csharp

	[HarmonyPostfix]
	[HarmonyPatch(typeof(DispenserComponent), "Init")]
	public static void Init(DispenserComponent __instance, PrefabDesc _desc)
	{
```

`Evidence/InitialPhase/check.cs:36`

```csharp
        Assert(Math.Abs(history.logisticCourierSpeedModified - 68) < 0.001, "repeated load/unlock adjustment does not compound speed");
        distributor.GetField("dispenserMaxCourierCount").SetValue(null, 20);
        var component = new DispenserComponent {workCourierDatas = new CourierData[10], orders = new DeliveryLogisticOrder[10], holdupPackage = new DispenserStore[20], idleCourierCount = 3, workCourierCount = 2};
        component.workCourierDatas[1].itemId = 1001; component.holdupPackage[1].itemId = 1002; component.holdupPackage[1].count = 7;
        Call(distributor, "Expand", component);
```

`Source/EarlierWorkingSource/LogisticsBotsTweaks.cs:80`

```csharp
		public static float maxChargePowerScale = 1.0f;

        [HarmonyPostfix, HarmonyPatch(typeof(DispenserComponent), nameof(DispenserComponent.Init))]
        public static void Init(DispenserComponent __instance, PrefabDesc _desc) => Expand(__instance);
        [HarmonyPostfix, HarmonyPatch(typeof(DispenserComponent), nameof(DispenserComponent.Import))]
```

`Source/Reconstructed/plugins/LogisticsBotsTweaks/LogisticsBotsTweaks/Patch_LogisticsBot.cs:17`

```csharp
	[HarmonyPatch(typeof(GameHistoryData), "SetForNewGame")]
	[HarmonyPatch(typeof(GameHistoryData), "UnlockTechFunction")]
	public static void LogisticCourierSpeedModified(GameHistoryData __instance)
	{
		if (logisticsBotSpeedScale != 1f)
```

`Source/Reconstructed/plugins/LogisticsBotsTweaks/LogisticsBotsTweaks/Plugin.cs:26`

```csharp
		Patch_LogisticsBot.logisticsBotCapacity = base.Config.Bind("Bot", "Capacity", 0, "If > 0, Overwirte carrying capacity of logistics bots. 覆写配送运输机运载量").Value;
		Patch_LogisticsBot.dispenserDeliveryMaxAngle = base.Config.Bind("Bot", "DeliveryMaxAngle", 0f, new ConfigDescription("If > 0, Overwirte distribution range of logistics bots. 覆写配送范围(度)", new AcceptableValueRange<float>(0f, 180f))).Value;
		Patch_Distributor.dispenserMaxCourierCount = base.Config.Bind("Distributor", "MaxBotCount", 10, "Max logistics bots count. 物流配送器的最大运输机数量").Value;
		Patch_Distributor.maxChargePowerScale = base.Config.Bind("Distributor", "MaxChargePowerScale", 1f, "Scale of max charge power. 物流配送器的最大充电功率倍率").Value;
		Log = base.Logger;
```

### Code in the related copy

`RelatedMods/appuns-DSPMultiDistributor/Source/Reconstructed/plugins/DSPMultiDistributor/DSPMultiDistributor/Main.cs:20`

```csharp
	}

	private static bool FiltersMatch(DispenserComponent left, DispenserComponent right)
	{
		if (left.filter > 0 && left.filter == right.filter)
```

`RelatedMods/appuns-DSPMultiDistributor/Evidence/InitialPhase/check.cs:22`

```csharp
        transport.dispenserCursor = 4;
        transport.dispenserPool = new[] {null,
            new DispenserComponent {id = 1, filter = 0, storage = storage, storageMode = EStorageDeliveryMode.Supply, deliveryPackage = delivery},
            new DispenserComponent {id = 2, filter = 5001, storageMode = EStorageDeliveryMode.Demand, deliveryPackage = delivery},
            new DispenserComponent {id = 3, filter = 5002, storageMode = EStorageDeliveryMode.Demand, deliveryPackage = delivery}};
```

`RelatedMods/appuns-DSPMultiDistributor/Source/EarlierWorkingSource/Plugin.cs:35`

```csharp
public class Main : BaseUnityPlugin
{
	private static bool FiltersMatch(DispenserComponent left, DispenserComponent right)
	{
		if (left.filter > 0 && left.filter == right.filter) return true;
```

## nebula-NebulaMultiplayerModApi

Copy: `RelatedMods/nebula-NebulaMultiplayerModApi/`.

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder. Via: `CommonAPI-CommonAPI`.

### Dependency references inside the copied mods

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs:13`

```csharp

[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
```

### Code in the related copy

`RelatedMods/nebula-NebulaMultiplayerModApi/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs:15`

```csharp
[BepInPlugin("dsp.nebula-multiplayer-api", "NebulaMultiplayerModApi", "2.1.0.7")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class NebulaModAPI : BaseUnityPlugin
{
	public const string NEBULA_MODID = "dsp.nebula-multiplayer";
```

`RelatedMods/nebula-NebulaMultiplayerModApi/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs:5`

```csharp
namespace NebulaAPI.DataStructures;

public static class CollectionExtensions
{
	public static Locker Lock(this ICollection collection)
```

## soarqin-UXAssist

Copy: `RelatedMods/soarqin-UXAssist/`.

- **fix_integration_context**: Refill must use expanded runtime courier arrays without replacing research or replenishment flags.

### Code in this mod

`Source/Reconstructed/plugins/LogisticsBotsTweaks/LogisticsBotsTweaks/Patch_Distributor.cs:33`

```csharp
	{
		int val = dispenserMaxCourierCount;
		CourierData[] workCourierDatas = component.workCourierDatas;
		int num = Math.Max(val, (workCourierDatas != null) ? workCourierDatas.Length : 0);
		int val2 = num;
```

`Evidence/InitialPhase/check.cs:36`

```csharp
        Assert(Math.Abs(history.logisticCourierSpeedModified - 68) < 0.001, "repeated load/unlock adjustment does not compound speed");
        distributor.GetField("dispenserMaxCourierCount").SetValue(null, 20);
        var component = new DispenserComponent {workCourierDatas = new CourierData[10], orders = new DeliveryLogisticOrder[10], holdupPackage = new DispenserStore[20], idleCourierCount = 3, workCourierCount = 2};
        component.workCourierDatas[1].itemId = 1001; component.holdupPackage[1].itemId = 1002; component.holdupPackage[1].count = 7;
        Call(distributor, "Expand", component);
```

`Source/EarlierWorkingSource/LogisticsBotsTweaks.cs:86`

```csharp
        public static void Expand(DispenserComponent component)
        {
            int count = Math.Max(dispenserMaxCourierCount, component.workCourierDatas?.Length ?? 0);
            count = Math.Max(count, component.orders?.Length ?? 0);
            count = Math.Max(count, (component.holdupPackage?.Length ?? 0) / 2);
```

### Code in the related copy

`RelatedMods/soarqin-UXAssist/Source/Reconstructed/plugins/UXAssist/UXAssist.Patches.Logistics/AutoConfigLogistics.cs:20`

```csharp
		{
			CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
			codeMatcher.Start().MatchForward(false, new CodeMatch((CodeInstruction ci) => ci.IsLdloc()), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(DispenserComponent), "workCourierDatas")), new CodeMatch(OpCodes.Ldlen), new CodeMatch(OpCodes.Conv_I4));
			codeMatcher.Repeat(delegate(CodeMatcher m)
			{
```

`RelatedMods/soarqin-UXAssist/Source/Reconstructed/plugins/UXAssist/UXAssist.Patches.Logistics/LogisticsPatch.cs:255`

```csharp
	internal static void DispenserFillCouriers(PlanetFactory factory, DispenserComponent dispenser)
	{
		if (factory != null && GameMain.mainPlayer != null && GameMain.mainPlayer.factory == factory && dispenser?.workCourierDatas != null)
		{
			int num = MissingWorkers(AutoConfigDispenserCourierCount.Value, dispenser.workCourierDatas.Length, dispenser.idleCourierCount, dispenser.workCourierCount);
```

`RelatedMods/soarqin-UXAssist/Evidence/InitialPhase/check.cs:55`

```csharp
        var station=new StationComponent {idleDroneCount=3,workDroneCount=2,workDroneDatas=new DroneData[10],
            idleShipCount=2,workShipCount=1,workShipDatas=new ShipData[6],droneAutoReplenish=true,shipAutoReplenish=true};
        var bot=new DispenserComponent {idleCourierCount=3,workCourierCount=2,workCourierDatas=new CourierData[20],courierAutoReplenish=true};
        Call("StationFillDrones",factory,station);Call("StationFillShips",factory,station);Call("DispenserFillCouriers",factory,bot);
        Assert(station.idleDroneCount==8 && station.idleShipCount==5 && bot.idleCourierCount==18 && package.grids[2].count==35,
```

`RelatedMods/soarqin-UXAssist/Source/EarlierWorkingSource/Patches/Logistics/AutoConfigPatch.cs:43`

```csharp
            matcher.Start().MatchForward(false,
                new CodeMatch(ci => ci.IsLdloc()),
                new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(DispenserComponent), nameof(DispenserComponent.workCourierDatas))),
                new CodeMatch(OpCodes.Ldlen),
                new CodeMatch(OpCodes.Conv_I4)
```

`RelatedMods/soarqin-UXAssist/Source/EarlierWorkingSource/Patches/Logistics/LogisticsPatch.cs:195`

```csharp
    internal static void DispenserFillCouriers(PlanetFactory factory, DispenserComponent dispenser)
    {
        if (factory == null || GameMain.mainPlayer == null || GameMain.mainPlayer.factory != factory || dispenser?.workCourierDatas == null) return;
        var toFill = MissingWorkers(AutoConfigDispenserCourierCount.Value, dispenser.workCourierDatas.Length, dispenser.idleCourierCount, dispenser.workCourierCount);
        if (toFill > 0) dispenser.idleCourierCount += GameMain.data.mainPlayer.package.TakeItem((int)KnownItemId.Bot, toFill, out _);
```

## xiaoye97-LDBTool

Copy: `RelatedMods/xiaoye97-LDBTool/`.

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder. Via: `CommonAPI-CommonAPI`.

### Dependency references inside the copied mods

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs:17`

```csharp

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
```

`RelatedMods/CommonAPI-CommonAPI/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/ProtoRegistry.cs:81`

```csharp
		spriteFileExtensions = new string[3] { ".jpg", ".png", ".tif" };
		audioClipFileExtensions = new string[4] { ".mp3", ".ogg", ".waw", ".aif" };
		LDBTool.PostAddDataAction = (Action)Delegate.Combine(LDBTool.PostAddDataAction, new Action(OnPostAdd));
		LDBTool.EditDataAction = (Action<Proto>)Delegate.Combine(LDBTool.EditDataAction, new Action<Proto>(EditProto));
	}
```

`RelatedMods/CommonAPI-CommonAPI/Source/EarlierWorkingSource/CommonAPIPlugin.cs:30`

```csharp
    /// </summary>
    [BepInPlugin(GUID, DISPNAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
```

### Code in the related copy

`RelatedMods/xiaoye97-LDBTool/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs:11`

```csharp
namespace xiaoye97;

public static class LDBTool
{
	public static Action PreAddDataAction;
```

`RelatedMods/xiaoye97-LDBTool/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs:11`

```csharp
namespace xiaoye97;

[BepInPlugin("me.xiaoye97.plugin.Dyson.LDBTool", "LDBTool", "3.0.4")]
public class LDBToolPlugin : BaseUnityPlugin
{
```

`RelatedMods/xiaoye97-LDBTool/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs:16`

```csharp
	internal static void InitIndex()
	{
		LDBToolPlugin.logger.LogDebug("Generating Proto type list:");
		protoTypes = (from domainAssembly in AppDomain.CurrentDomain.GetAssemblies()
			from assemblyType in GetTypesSafe(domainAssembly)
```

`RelatedMods/xiaoye97-LDBTool/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs:19`

```csharp
		if (__instance.recipeExecuteData == null)
		{
			LDBToolPlugin.logger.LogWarning($"Importing assembler {__instance.recipeType}: Can't find recipeId {__instance.recipeId}");
			__instance.recipeId = 0;
			__instance.recipeType = ERecipeType.None;
```

`RelatedMods/xiaoye97-LDBTool/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs:12`

```csharp
	private static void HistoryPatch(GameHistoryData __instance)
	{
		foreach (Proto item in LDBTool.TotalDict[ProtoIndex.GetIndex(typeof(RecipeProto))])
		{
			RecipeProto recipeProto = item as RecipeProto;
```
