# starfi5h-LogisticsBotsTweaks — detailed change report

Installed plugin version(s): **1.1.1**. Grow courier/order/holdup arrays together while preserving data, research speed and the intended charge slider target.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Data-preserving courier capacity — 1.1.1

The earlier concern that the mod loses research speed was not confirmed in current native code: `UnlockTechFunction(34)` increases `logisticCourierSpeedScale`, while `logisticCourierSpeedModified` multiplies separate base and research fields. The mod writes its configured base once and does not replace research state. Existing intentional speed/capacity/range policies remain.

- Do not let a fixed UI config value reduce a larger native runtime capacity; inspect the actual component array.
- Grow courier/order/holdup arrays together, copying their existing data during Init/Import. Do not shrink them destructively.
- Target the charge-power slider's own field rather than an unrelated new slider's first `maxValue` call.

The phase checked 12 API references, 7 Harmony targets and assembly/public/GUID contracts. Native research/getter tests verified research contributions and no compounding on repeated configuration. Actual DispenserComponent Export/Import plus patches preserved active couriers, holdup data and `courierAutoReplenish`, growing arrays from 20 to 30 together. AutoLogisticsDroneSetup uses the same runtime capacity and working total.

Only the `Configs.get_freeMode` Unity-object-equality boundary was simplified in the desktop test reference; 26,419 other top-level native method bodies, including history/import/export/logistics, remained unchanged. Two UI transpilers matched their intended native IL targets, which is not UI JIT/render acceptance. Actual flight, ongoing replenishment, UI and MultiDistributor/DeliverySlots integration need game testing.

## Recorded source commits

- `0890ba1bdaa11856f3a4ba4211122c398d7a0111`

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
