using System.Diagnostics;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Security;
using System.Security.Permissions;

[assembly: AssemblyTitle("MassRecipePaste")]
[assembly: AssemblyVersion("1.1.3.0")]
[module: RefSafetyRules(11)]
