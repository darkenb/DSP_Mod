using System.Collections.Generic;

namespace MassRecipePaste;

internal static class StationParameters
{
	private static bool hasCopy;

	private static string name;

	private static long remoteGroupMask;

	private static ERemoteRoutePriority routePriority;

	private static readonly List<int> addGids = new List<int>();

	public static void Clear()
	{
		hasCopy = false;
		name = null;
		addGids.Clear();
	}

	public static void Copy(PlanetFactory factory, StationComponent station)
	{
		if (station == null || !station.isStellar)
		{
			return;
		}
		hasCopy = true;
		remoteGroupMask = station.remoteGroupMask;
		routePriority = station.routePriority;
		if (Plugin.CopyStationName.Value)
		{
			name = factory.ReadExtraInfoOnEntity(station.entityId);
		}
		if (!Plugin.CopyStationP2P.Value)
		{
			return;
		}
		addGids.Clear();
		GalacticTransport galacticTransport = GameMain.data.galacticTransport;
		for (int i = 1; i < galacticTransport.stationCursor; i++)
		{
			if (galacticTransport.stationPool[i] != null && galacticTransport.stationPool[i].id > 0 && galacticTransport.stationPool[i].gid == i)
			{
				long item = galacticTransport.CalculateStation2StationKey(station.gid, i);
				if (galacticTransport.station2stationRoutes.Contains(item))
				{
					addGids.Add(i);
				}
			}
		}
	}

	public static void Paste(PlanetFactory factory, StationComponent station)
	{
		if (!hasCopy || station == null || !station.isStellar)
		{
			return;
		}
		if (Plugin.CopyStationGroup.Value)
		{
			station.remoteGroupMask = remoteGroupMask;
		}
		if (Plugin.CopyStationPriorityBehavior.Value)
		{
			station.routePriority = routePriority;
		}
		if (Plugin.CopyStationName.Value)
		{
			factory.WriteExtraInfoOnEntity(station.entityId, name);
		}
		if (!Plugin.CopyStationP2P.Value)
		{
			return;
		}
		GameMain.data.galacticTransport.RemoveStation2StationRoute(station.gid);
		foreach (int addGid in addGids)
		{
			GameMain.data.galacticTransport.AddStation2StationRoute(station.gid, addGid);
		}
	}
}
