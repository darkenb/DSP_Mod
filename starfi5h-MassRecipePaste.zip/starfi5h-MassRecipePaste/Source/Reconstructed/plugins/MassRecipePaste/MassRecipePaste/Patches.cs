using System;
using HarmonyLib;
using UnityEngine;

namespace MassRecipePaste;

public class Patches
{
	public static bool isCustomHotkey;

	public static DragPasteTool tool;

	[HarmonyPostfix]
	[HarmonyAfter(new string[] { "org.kremnev8.plugin.BlueprintTweaks" })]
	[HarmonyPatch(typeof(PlayerAction_Build), "Init")]
	public static void InitTool(PlayerAction_Build __instance)
	{
		BuildTool[] tools = __instance.tools;
		if (tools != null)
		{
			BuildTool[] array = new BuildTool[tools.Length + 1];
			tools.CopyTo(array, 0);
			tool = new DragPasteTool();
			array[^1] = tool;
			__instance.tools = array;
			Plugin.Log.LogDebug("Add DragPasteTool. Total tools count: " + array.Length);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlayerAction_Build), "DetermineActive")]
	public static void UpdateCommandState(PlayerAction_Build __instance, ref bool __result)
	{
		if (tool != null)
		{
			if (tool.isEnable && __instance.activeTool == tool)
			{
				__result = true;
			}
			else if (VFInput.readyToBuild && VFInput.inScreen && IsHotKey() && __instance.blueprintMode == EBlueprintMode.None)
			{
				Plugin.Log.LogDebug("Enter PasteMode: " + BuildingParameters.clipboard.type.ToString() + " - " + BuildingParameters.clipboard.recipeType);
				__instance.player.controller.cmd.SetNoneCommand();
				tool.isEnable = true;
				__result = true;
			}
		}
	}

	private static bool IsHotKey()
	{
		if (PluginCAPIcompat.IsRegisiter)
		{
			return PluginCAPIcompat.IsPressed();
		}
		if (isCustomHotkey)
		{
			return Plugin.MassPasteKey.Value.IsPressed();
		}
		if (!VFInput.override_keys[31].IsNull())
		{
			if (VFInput.control)
			{
				return VFInput._InputValueNoCombatOrFullscreenOrScreenshot(VFInput.axis_combine_key, 31).onDown;
			}
			return false;
		}
		if (VFInput.control)
		{
			return VFInput._InputValueNoCombatOrFullscreenOrScreenshot(VFInput.axis_button, 33).onDown;
		}
		return false;
	}

	[HarmonyPrefix]
	[HarmonyPatch(typeof(UIRealtimeTip), "Popup", new Type[]
	{
		typeof(string),
		typeof(bool),
		typeof(int)
	})]
	public static bool Blocker()
	{
		DragPasteTool dragPasteTool = tool;
		if (dragPasteTool != null && dragPasteTool.isPasting)
		{
			return false;
		}
		return true;
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
	private static void CountSuccessfulPaste(bool __result)
	{
		if (__result)
		{
			DragPasteTool dragPasteTool = tool;
			if (dragPasteTool != null && dragPasteTool.isPasting)
			{
				tool.pastedCount++;
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPriority(0)]
	[HarmonyPatch(typeof(UIBuildingGrid), "Update")]
	public static void UpdateGrid(UIBuildingGrid __instance)
	{
		Player mainPlayer = GameMain.mainPlayer;
		if (GameMain.localPlanet?.factory == null || GameMain.localPlanet.type == EPlanetType.Gas || tool == null || !tool.active)
		{
			return;
		}
		PlayerAction_Build playerAction_Build = mainPlayer?.controller?.actionBuild;
		if (playerAction_Build == null || playerAction_Build.blueprintMode != EBlueprintMode.None)
		{
			return;
		}
		PlanetGrid planetGrid = null;
		if (GameMain.localPlanet != null && GameMain.localPlanet.aux != null && GameMain.localPlanet.aux.activeGridIndex < GameMain.localPlanet.aux.customGrids.Count)
		{
			planetGrid = GameMain.localPlanet.aux.customGrids[GameMain.localPlanet.aux.activeGridIndex];
		}
		if (planetGrid != null)
		{
			Vector4 value = Vector4.zero;
			if (tool.isSelecting)
			{
				__instance.gridRnd.enabled = playerAction_Build.blueprintMode == EBlueprintMode.None;
				__instance.gridRnd.transform.localScale = new Vector3(__instance.displayScale, __instance.displayScale, __instance.displayScale);
				__instance.gridRnd.transform.rotation = planetGrid.rotation;
				__instance.material.SetColor("_TintColor", new Color(0.4f, 0.5f, 0f));
				__instance.material.SetFloat("_ReformMode", 0f);
				__instance.material.SetFloat("_ZMin", -0.5f);
				value = (Vector4)tool.selectGratBox;
			}
			__instance.material.SetVector("_CursorGratBox", value);
		}
	}
}
