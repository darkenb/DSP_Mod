using BepInEx;
using BepInEx.Configuration;
using BepInEx.Logging;
using HarmonyLib;
using UnityEngine;

namespace MassRecipePaste;

[BepInPlugin("starfi5h.plugin.MassRecipePaste", "MassRecipePaste", "1.1.5")]
public class Plugin : BaseUnityPlugin
{
	public const string GUID = "starfi5h.plugin.MassRecipePaste";

	public const string NAME = "MassRecipePaste";

	public const string VERSION = "1.1.5";

	public static ManualLogSource Log;

	public static Plugin instance;

	private static Harmony harmony;

	public static ConfigEntry<KeyboardShortcut> MassPasteKey;

	public static ConfigEntry<bool> CopyStationName;

	public static ConfigEntry<bool> CopyStationPriorityBehavior;

	public static ConfigEntry<bool> CopyStationGroup;

	public static ConfigEntry<bool> CopyStationP2P;

	public void Awake()
	{
		Log = base.Logger;
		instance = this;
		harmony = new Harmony("starfi5h.plugin.MassRecipePaste");
		harmony.PatchAll(typeof(Patches));
		harmony.PatchAll(typeof(ExtraCopy));
		LoadConfigs();
		Log.LogDebug("1.1.5");
	}

	public void LoadConfigs()
	{
		MassPasteKey = base.Config.Bind("KeyBinds", "MassPasteKey", new KeyboardShortcut(KeyCode.Period, KeyCode.LeftControl), "Custom keybind. Default is ctrl + >(paste recipe)\n没有设置时, 默认为Ctrl + >(配方黏贴键)");
		if (!MassPasteKey.Value.Equals(default(KeyboardShortcut)) && !MassPasteKey.Value.Equals(new KeyboardShortcut(KeyCode.Period, KeyCode.LeftControl)))
		{
			Patches.isCustomHotkey = true;
			base.Logger.LogDebug("MassPasteKey: " + MassPasteKey.Value.ToString());
		}
		CopyStationName = base.Config.Bind("ExtraCopy", "CopyStationName", defaultValue: false, "复制物流站名称");
		CopyStationPriorityBehavior = base.Config.Bind("ExtraCopy", "CopyStationPriorityBehavior", defaultValue: true, "复制物流站优先行为");
		CopyStationGroup = base.Config.Bind("ExtraCopy", "CopyStationGroup", defaultValue: true, "复制物流站分组设置");
		CopyStationP2P = base.Config.Bind("ExtraCopy", "CopyStationP2P", defaultValue: true, "复制物流站点对点设置");
	}

	public void OnDestroy()
	{
		harmony.UnpatchSelf();
		harmony = null;
	}
}
