using System;
using System.Collections.Generic;
using UnityEngine;

namespace MassRecipePaste;

public class DragPasteTool : BuildTool
{
	public bool isEnable;

	public bool isSelecting;

	public bool isPasting;

	public int pastedCount;

	private bool castTerrain;

	private bool castGround;

	private Vector3 castGroundPos = Vector3.zero;

	private Vector3 castGroundPosSnapped = Vector3.zero;

	private int castObjectId;

	private Vector3 castObjectPos;

	private bool cursorValid;

	private Vector3 cursorTarget;

	private Vector3 startGroundPosSnapped = Vector3.zero;

	private Vector3 lastGroundPosSnapped = Vector3.zero;

	public BPGratBox selectGratBox = BPGratBox.zero;

	private BPGratBox lastSelectGratBox = BPGratBox.zero;

	private BPGratBox selectArcBox = BPGratBox.zero;

	private HashSet<int> selectObjIds;

	private BuildPreview[] bpPool;

	private AnimData[] animPool;

	private ComputeBuffer animBuffer;

	private int bpCursor = 1;

	private int bpPoolCapacity;

	private int[] bpRecycle;

	private int bpRecycleCursor;

	public override void _OnInit()
	{
		selectObjIds = new HashSet<int>();
		SetDisplayPreviewCapacity(256);
	}

	public override void _OnFree()
	{
		selectObjIds = null;
		FreeBuildPreviews();
		isEnable = false;
		isSelecting = false;
		isPasting = false;
	}

	public override void _OnOpen()
	{
		ClearSelection();
		ResetBuildPreviews();
		castTerrain = false;
		castGround = false;
		castGroundPos = Vector3.zero;
		startGroundPosSnapped = (lastGroundPosSnapped = (castGroundPosSnapped = Vector3.zero));
		lastSelectGratBox = (selectGratBox = (selectArcBox = BPGratBox.zero));
		castObjectId = 0;
		castObjectPos = Vector3.zero;
		cursorValid = false;
		cursorTarget = Vector3.zero;
		isSelecting = false;
	}

	public override void _OnClose()
	{
		ClearSelection();
		ResetBuildPreviews();
		startGroundPosSnapped = (lastGroundPosSnapped = (castGroundPosSnapped = Vector3.zero));
		lastSelectGratBox = (selectGratBox = (selectArcBox = BPGratBox.zero));
		castObjectId = 0;
		castObjectPos = Vector3.zero;
		cursorValid = false;
		cursorTarget = Vector3.zero;
		isEnable = false;
		isSelecting = false;
		isPasting = false;
	}

	public override void _OnTick(long time)
	{
		UpdateRaycast();
		Operating();
		if (base.active)
		{
			UpdatePreviewModels(base.actionBuild.model);
		}
	}

	public override bool DetermineActive()
	{
		if (isEnable && base.actionBuild.blueprintMode == EBlueprintMode.None)
		{
			return base.controller.cmd.mode == 0;
		}
		return false;
	}

	public override void EscLogic()
	{
		bool flag = !VFInput.onGUI && VFInput.inScreen && !VFInput.inputing;
		bool flag2 = VFInput.escKey.onDown || VFInput.escape;
		bool num = !VFInput._godModeMechaMove && VFInput.rtsCancel.onDown && flag;
		if (num || flag2)
		{
			base.player.SetHandItems(0, 0);
			_Close();
			base.actionBuild.Close();
		}
		if (flag2)
		{
			VFInput.UseEscape();
		}
		if (num)
		{
			VFInput.UseMouseRight();
		}
	}

	public override void UpdatePreviewModels(BuildModel model)
	{
		for (int i = 1; i < bpCursor; i++)
		{
			BuildPreview buildPreview = bpPool[i];
			if (buildPreview == null || buildPreview.bpgpuiModelId <= 0 || !buildPreview.isConnNode)
			{
				continue;
			}
			if (buildPreview.objId > 0)
			{
				factory.cargoTraffic.SetBeltSelected(factory.entityPool[buildPreview.objId].beltId);
				continue;
			}
			uint beltSpeed = (uint)buildPreview.desc.beltSpeed;
			if (buildPreview.outputObjId == 0 || buildPreview.inputObjId == 0 || buildPreview.coverbp != null)
			{
				model.connRenderer.AddBlueprintBeltMajorPoint(buildPreview.lpos, buildPreview.lrot, beltSpeed);
			}
			else
			{
				model.connRenderer.AddBlueprintBeltPoint(buildPreview.lpos, buildPreview.lrot, beltSpeed);
			}
		}
	}

	public void UpdateRaycast()
	{
		castTerrain = false;
		castGround = false;
		castGroundPos = Vector3.zero;
		castGroundPosSnapped = Vector3.zero;
		castObjectId = 0;
		castObjectPos = Vector3.zero;
		cursorValid = false;
		cursorTarget = Vector3.zero;
		if (!VFInput.onGUI && VFInput.inScreen)
		{
			castGround = Physics.Raycast(mouseRay, out var hitInfo, 800f, 8720, QueryTriggerInteraction.Collide);
			if (castGround)
			{
				Layer layer = (Layer)hitInfo.collider.gameObject.layer;
				castTerrain = layer == Layer.Terrain || layer == Layer.Water;
				castGroundPos = (base.controller.cmd.test = (base.controller.cmd.target = hitInfo.point));
				castGroundPosSnapped = base.actionBuild.planetAux.Snap(castGroundPos, castTerrain);
				castGroundPosSnapped = castGroundPosSnapped.normalized * (planet.realRadius + 0.2f);
				base.controller.cmd.test = castGroundPosSnapped;
				Vector3 normalized = castGroundPosSnapped.normalized;
				if (Physics.Raycast(new Ray(castGroundPosSnapped + normalized * 10f, -normalized), out hitInfo, 20f, 8720, QueryTriggerInteraction.Collide))
				{
					base.controller.cmd.test = hitInfo.point;
				}
				cursorTarget = castGroundPosSnapped;
				cursorValid = true;
			}
			int castAllCount = base.controller.cmd.raycast.castAllCount;
			RaycastData[] castAll = base.controller.cmd.raycast.castAll;
			int num = 0;
			for (int i = 0; i < castAllCount; i++)
			{
				if (castAll[i].objType == EObjectType.None || castAll[i].objType == EObjectType.Prebuild)
				{
					num = ((castAll[i].objType == EObjectType.None) ? castAll[i].objId : (-castAll[i].objId));
					break;
				}
			}
			if (num != 0)
			{
				castObjectId = num;
				castObjectPos = GetObjectPose(num).position;
				cursorTarget = castObjectPos;
				base.controller.cmd.test = castObjectPos;
				castGroundPosSnapped = (castGroundPos = castObjectPos);
				castGroundPosSnapped = castGroundPosSnapped.normalized * (planet.realRadius + 0.2f);
				base.controller.cmd.test = castGroundPosSnapped;
				Vector3 normalized2 = castGroundPosSnapped.normalized;
				if (Physics.Raycast(new Ray(castGroundPosSnapped + normalized2 * 10f, -normalized2), out hitInfo, 20f, 8720, QueryTriggerInteraction.Collide))
				{
					base.controller.cmd.test = hitInfo.point;
				}
				cursorTarget = castGroundPosSnapped;
				cursorValid = true;
			}
		}
		base.controller.cmd.state = (cursorValid ? 1 : 0);
		base.controller.cmd.target = (cursorValid ? cursorTarget : Vector3.zero);
	}

	public void Operating()
	{
		if (!isSelecting && VFInput.blueprintCopyOperate0.onDown && cursorValid)
		{
			isSelecting = true;
			startGroundPosSnapped = castGroundPosSnapped;
			lastGroundPosSnapped = startGroundPosSnapped;
			InitSelectGratBox();
			VFInput.UseMouseLeft();
		}
		bool num = (castGroundPosSnapped - startGroundPosSnapped).sqrMagnitude > 0.01f;
		bool flag = VFInput.blueprintCopyOperate0.onDown || VFInput.blueprintCopyOperate1.onDown;
		if (isSelecting && flag && cursorValid)
		{
			PasteAction();
			ResetBuildPreviews();
			isSelecting = false;
			VFInput.UseMouseLeft();
			VFInput.UseEnterConfirm();
			_Close();
		}
		else if (isSelecting && VFInput.rtsCancel.onUp)
		{
			isSelecting = false;
			startGroundPosSnapped = castGroundPosSnapped;
			lastGroundPosSnapped = startGroundPosSnapped;
			ClearSelection();
			ResetBuildPreviews();
		}
		if (isSelecting)
		{
			UICursor.SetCursor(ECursor.TargetIn);
			DetermineSelectGratBox();
			if (lastSelectGratBox != selectGratBox)
			{
				DetermineAddSelection();
				lastSelectGratBox = selectGratBox;
			}
		}
		else
		{
			startGroundPosSnapped = castGroundPosSnapped;
			ReDeterminePreviews();
		}
		if (num)
		{
			ReDeterminePreviews();
		}
		if ((BuildingParameters.clipboard.type == BuildingType.Assembler || BuildingParameters.clipboard.type == BuildingType.Lab) && BuildingParameters.clipboard.recipeId != 0)
		{
			base.actionBuild.model.cursorText = "MassRecipePaste\r\n" + BuildingParameters.clipboard.recipeType.ToString() + " (" + LDB.RecipeName(BuildingParameters.clipboard.recipeId) + ") : " + selectObjIds.Count;
		}
		else
		{
			base.actionBuild.model.cursorText = "MassRecipePaste\r\n" + BuildingParameters.clipboard.type.ToString() + " : " + selectObjIds.Count;
		}
	}

	public void PasteAction()
	{
		Plugin.Log.LogInfo("PasteAction " + BuildingParameters.clipboard.type.ToString() + " - " + BuildingParameters.clipboard.recipeType);
		isPasting = true;
		pastedCount = 0;
		try
		{
			foreach (int selectObjId in selectObjIds)
			{
				if (ShouldAddObject(selectObjId))
				{
					factory.PasteBuildingSetting(selectObjId);
				}
			}
		}
		finally
		{
			isPasting = false;
			isSelecting = false;
			ClearSelection();
		}
		if (pastedCount > 0)
		{
			string text = BuildingParameters.clipboard.PastedTipText() + " (" + pastedCount + ")";
			UIRealtimeTip.Popup(text, sound: false);
			Plugin.Log.LogDebug(text);
		}
	}

	private void InitSelectGratBox()
	{
		BlueprintUtils.GetMinimumGratBox(startGroundPosSnapped.normalized, ref selectGratBox);
		selectArcBox = selectGratBox;
		if (selectArcBox.y >= 1.5707864f)
		{
			selectArcBox.y = (selectArcBox.w = MathF.PI / 2f);
			selectArcBox.z = selectArcBox.x + MathF.PI * 200f;
		}
		else if (selectArcBox.y <= -1.5707864f)
		{
			selectArcBox.y = (selectArcBox.w = -MathF.PI / 2f);
			selectArcBox.z = selectArcBox.x + MathF.PI * 200f;
		}
		lastSelectGratBox = selectGratBox;
	}

	public void DetermineSelectGratBox()
	{
		if (!cursorValid)
		{
			return;
		}
		float longitudeRad = BlueprintUtils.GetLongitudeRad(castGroundPosSnapped.normalized);
		float longitudeRad2 = BlueprintUtils.GetLongitudeRad(lastGroundPosSnapped.normalized);
		float latitudeRad = BlueprintUtils.GetLatitudeRad(castGroundPosSnapped.normalized);
		int num;
		float num2;
		if (!(latitudeRad >= 1.5707864f))
		{
			num = ((latitudeRad <= -1.5707864f) ? 1 : 0);
			if (num == 0)
			{
				num2 = longitudeRad - longitudeRad2;
				goto IL_0061;
			}
		}
		else
		{
			num = 1;
		}
		num2 = 0f;
		goto IL_0061;
		IL_0061:
		float num3 = num2;
		num3 = Mathf.Repeat(num3 + MathF.PI, MathF.PI * 2f) - MathF.PI;
		selectArcBox.endLongitudeRad += num3;
		selectArcBox.endLatitudeRad = latitudeRad;
		selectGratBox = selectArcBox;
		selectGratBox.x = ((selectArcBox.x < selectArcBox.z) ? selectArcBox.x : selectArcBox.z);
		selectGratBox.z = ((selectArcBox.x > selectArcBox.z) ? selectArcBox.x : selectArcBox.z);
		if (selectArcBox.x < selectArcBox.z)
		{
			if (selectGratBox.z > selectGratBox.x + MathF.PI * 2f - 1E-05f - 4E-06f)
			{
				selectGratBox.z = selectGratBox.x + MathF.PI * 2f - 1E-05f - 4E-06f;
			}
			selectGratBox.z = Mathf.Repeat(selectGratBox.z + MathF.PI, MathF.PI * 2f) - MathF.PI;
		}
		else
		{
			if (selectGratBox.x < selectGratBox.z - MathF.PI * 2f + 1E-05f + 4E-06f)
			{
				selectGratBox.x = selectGratBox.z - MathF.PI * 2f + 1E-05f + 4E-06f;
			}
			selectGratBox.x = Mathf.Repeat(selectGratBox.x + MathF.PI, MathF.PI * 2f) - MathF.PI;
		}
		selectGratBox.y = ((selectArcBox.y < selectArcBox.w) ? selectArcBox.y : selectArcBox.w);
		selectGratBox.w = ((selectArcBox.y > selectArcBox.w) ? selectArcBox.y : selectArcBox.w);
		float longitude = BlueprintUtils.GetLongitudeRadPerGrid((Mathf.Abs(castGroundPosSnapped.y) < Mathf.Abs(startGroundPosSnapped.y)) ? castGroundPosSnapped.normalized : startGroundPosSnapped.normalized) * 0.33f;
		selectGratBox.Extend(longitude, 0.002f);
		if (num == 0)
		{
			lastGroundPosSnapped = castGroundPosSnapped;
		}
	}

	public void DetermineAddSelection()
	{
		selectObjIds.Clear();
		if (Mathf.Abs(selectArcBox.x - selectArcBox.z) < 0.01f && Mathf.Abs(selectArcBox.y - selectArcBox.w) < 0.01f && castObjectId != 0)
		{
			if (ShouldAddObject(castObjectId))
			{
				selectObjIds.Add(castObjectId);
			}
		}
		else
		{
			EntityData[] entityPool = factory.entityPool;
			int entityCursor = factory.entityCursor;
			for (int i = 1; i < entityCursor; i++)
			{
				int num = i;
				if (entityPool[i].id == i && selectGratBox.InGratBox(entityPool[i].pos) && ShouldAddObject(num))
				{
					selectObjIds.Add(num);
				}
			}
			PrebuildData[] prebuildPool = factory.prebuildPool;
			int prebuildCursor = factory.prebuildCursor;
			for (int j = 1; j < prebuildCursor; j++)
			{
				int num2 = -j;
				if (prebuildPool[j].id == j && selectGratBox.InGratBox(prebuildPool[j].pos) && ShouldAddObject(num2))
				{
					selectObjIds.Add(num2);
				}
			}
		}
		DeterminePreviews();
	}

	public bool ShouldAddObject(int objId)
	{
		if (factory == null || objId == 0 || objId == int.MinValue)
		{
			return false;
		}
		if (objId > 0 && (factory.entityPool == null || objId >= factory.entityPool.Length || factory.entityPool[objId].id != objId))
		{
			return false;
		}
		if (objId < 0 && (factory.prebuildPool == null || -objId >= factory.prebuildPool.Length || factory.prebuildPool[-objId].id != -objId))
		{
			return false;
		}
		bool flag = BuildingParameters.clipboard.CanPasteToFactoryObject(objId, factory);
		if (!flag && objId > 0 && (BuildingParameters.clipboard.type == BuildingType.Assembler || BuildingParameters.clipboard.type == BuildingType.Lab))
		{
			int recipeId = BuildingParameters.clipboard.recipeId;
			EntityData[] entityPool = factory.entityPool;
			FactorySystem factorySystem = factory.factorySystem;
			switch (BuildingParameters.clipboard.type)
			{
			case BuildingType.Assembler:
			{
				int assemblerId = entityPool[objId].assemblerId;
				if (assemblerId > 0 && assemblerId < factorySystem.assemblerPool.Length && factorySystem.assemblerPool[assemblerId].id == assemblerId && recipeId != 0 && factorySystem.assemblerPool[assemblerId].recipeId == recipeId && BuildingParameters.clipboard.parameters != null && BuildingParameters.clipboard.parameters.Length >= 1)
				{
					bool flag3 = BuildingParameters.clipboard.parameters[0] > 0;
					flag |= factorySystem.assemblerPool[assemblerId].forceAccMode != flag3;
				}
				break;
			}
			case BuildingType.Lab:
			{
				int labId = entityPool[objId].labId;
				if (labId > 0 && labId < factorySystem.labPool.Length && factorySystem.labPool[labId].id == labId && recipeId != 0 && factorySystem.labPool[labId].recipeId == recipeId)
				{
					bool flag2 = BuildingParameters.clipboard.mode1 == 1;
					flag |= factorySystem.labPool[labId].forceAccMode != flag2;
				}
				break;
			}
			}
		}
		return flag;
	}

	public void ClearSelection()
	{
		selectObjIds.Clear();
		lastSelectGratBox = (selectGratBox = (selectArcBox = BPGratBox.zero));
	}

	public void ReDeterminePreviews()
	{
		ResetBuildPreviews();
		foreach (int selectObjId in selectObjIds)
		{
			BuildPreview buildPreview = GetBuildPreview(selectObjId);
			AddBPGPUIModel(buildPreview);
		}
		SyncAnimBuffer();
		planet.factoryModel.bpgpuiManager.animBuffer = animBuffer;
		planet.factoryModel.bpgpuiManager.SyncAllGPUBuffer();
	}

	public void DeterminePreviews()
	{
		HashSet<int> hashSet = new HashSet<int>(selectObjIds);
		for (int i = 1; i < bpCursor; i++)
		{
			BuildPreview buildPreview = bpPool[i];
			if (buildPreview == null || buildPreview.bpgpuiModelId <= 0)
			{
				continue;
			}
			if (!selectObjIds.Contains(buildPreview.objId))
			{
				if (buildPreview.bpgpuiModelInstIndex >= 0)
				{
					planet.factoryModel.bpgpuiManager.RemoveBuildPreviewModel(buildPreview.desc.modelIndex, buildPreview.bpgpuiModelInstIndex, setBuffer: false);
				}
				RemoveBuildPreview(i);
			}
			else
			{
				hashSet.Remove(buildPreview.objId);
			}
		}
		foreach (int item in hashSet)
		{
			BuildPreview buildPreview2 = GetBuildPreview(item);
			AddBPGPUIModel(buildPreview2);
		}
		if (castObjectId != 0)
		{
			BuildPreview buildPreview3 = GetBuildPreview(castObjectId);
			AddBPGPUIModel(buildPreview3);
		}
		SyncAnimBuffer();
		planet.factoryModel.bpgpuiManager.animBuffer = animBuffer;
		planet.factoryModel.bpgpuiManager.SyncAllGPUBuffer();
	}

	public void AddBPGPUIModel(BuildPreview preview)
	{
		if (preview == null || preview.bpgpuiModelId <= 0 || !preview.needModel)
		{
			return;
		}
		ModelProto modelProto = LDB.models.Select(preview.desc.modelIndex);
		Color32 color = new Color32(44, 123, 250, byte.MaxValue);
		if (modelProto.RendererType == 2)
		{
			GetInserterT1T2(preview.objId, out var t, out var t2);
			if (preview.objId > 0)
			{
				animPool[preview.bpgpuiModelId] = factory.entityAnimPool[preview.objId];
			}
			animPool[preview.bpgpuiModelId].state = (uint)((color.r << 24) + (color.g << 16) + (color.b << 8) + color.a);
			planet.factoryModel.bpgpuiManager.AddBuildPreviewModel(preview.desc.modelIndex, out preview.bpgpuiModelInstIndex, preview.bpgpuiModelId, preview.lpos, preview.lrot, preview.lpos2, preview.lrot2, t ? 1 : 0, t2 ? 1 : 0, setBuffer: false);
			return;
		}
		if (modelProto.RendererType == 3)
		{
			factory.ReadObjectConn(preview.objId, 14, out var _, out var otherObjId, out var _);
			if (preview.objId > 0)
			{
				animPool[preview.bpgpuiModelId] = factory.entityAnimPool[preview.objId];
			}
			animPool[preview.bpgpuiModelId].state = (uint)((color.r << 24) + (color.g << 16) + (color.b << 8) + color.a);
			planet.factoryModel.bpgpuiManager.AddBuildPreviewModel(preview.desc.modelIndex, out preview.bpgpuiModelInstIndex, preview.bpgpuiModelId, preview.lpos, preview.lrot, (otherObjId != 0) ? 1u : 0u, setBuffer: false);
			return;
		}
		if (preview.objId > 0)
		{
			animPool[preview.bpgpuiModelId] = factory.entityAnimPool[preview.objId];
		}
		animPool[preview.bpgpuiModelId].state = (uint)((color.r << 24) + (color.g << 16) + (color.b << 8) + color.a);
		if (preview.objId > 0 && preview.desc.isEjector)
		{
			animPool[preview.bpgpuiModelId].power = factory.factorySystem.ejectorPool[factory.entityPool[preview.objId].ejectorId].localDir.z;
		}
		planet.factoryModel.bpgpuiManager.AddBuildPreviewModel(preview.desc.modelIndex, out preview.bpgpuiModelInstIndex, preview.bpgpuiModelId, preview.lpos, preview.lrot, setBuffer: false);
	}

	public void GeneratePreviewByObjId(BuildPreview preview, int objId)
	{
		ItemProto itemProto = GetItemProto(objId);
		PrefabDesc prefabDesc = GetPrefabDesc(objId);
		if (prefabDesc == null || itemProto == null)
		{
			preview.ResetAll();
			return;
		}
		Pose objectPose = GetObjectPose(objId);
		Pose pose = (prefabDesc.isInserter ? GetObjectPose2(objId) : objectPose);
		preview.item = itemProto;
		preview.desc = prefabDesc;
		preview.lpos = objectPose.position;
		preview.lrot = objectPose.rotation;
		preview.lpos2 = objectPose.position;
		preview.lrot2 = objectPose.rotation;
		preview.objId = objId;
		preview.genNearColliderArea2 = 0f;
		if (preview.desc.lodCount > 0 && preview.desc.lodMeshes != null && preview.desc.lodMeshes[0] != null)
		{
			preview.needModel = true;
		}
		else
		{
			preview.needModel = false;
		}
		preview.isConnNode = prefabDesc.isBelt;
		if (prefabDesc.isBelt)
		{
			for (int i = 0; i < 4; i++)
			{
				factory.ReadObjectConn(objId, i, out var isOutput, out var otherObjId, out var _);
				if (otherObjId != 0)
				{
					if (isOutput)
					{
						preview.outputObjId = otherObjId;
					}
					else if (preview.inputObjId == 0)
					{
						preview.inputObjId = otherObjId;
					}
					else
					{
						preview.coverbp = preview;
					}
				}
			}
		}
		if (prefabDesc.isInserter)
		{
			preview.lpos2 = pose.position;
			preview.lrot2 = pose.rotation;
		}
	}

	public void ResetBuildPreviews()
	{
		if (planet != null && planet.factoryModel != null && planet.factoryModel.bpgpuiManager != null)
		{
			planet.factoryModel.bpgpuiManager.Reset();
		}
		for (int i = 0; i < bpPool.Length; i++)
		{
			if (bpPool[i] != null)
			{
				bpPool[i].ResetAll();
			}
		}
		Array.Clear(animPool, 0, bpPoolCapacity);
		Array.Clear(bpRecycle, 0, bpPoolCapacity);
		bpCursor = 1;
		bpRecycleCursor = 0;
		animBuffer.SetData(animPool);
	}

	public void FreeBuildPreviews()
	{
		if (planet != null && planet.factoryModel != null && planet.factoryModel.bpgpuiManager != null)
		{
			planet.factoryModel.bpgpuiManager.Reset();
		}
		for (int i = 0; i < bpPool.Length; i++)
		{
			if (bpPool[i] != null)
			{
				bpPool[i].Free();
				bpPool[i] = null;
			}
		}
		animPool = null;
		bpPool = null;
		bpCursor = 1;
		bpPoolCapacity = 0;
		bpRecycle = null;
		bpRecycleCursor = 0;
		if (animBuffer != null)
		{
			animBuffer.Release();
			animBuffer = null;
		}
	}

	private void SetDisplayPreviewCapacity(int newCapacity)
	{
		BuildPreview[] array = bpPool;
		AnimData[] sourceArray = animPool;
		bpPool = new BuildPreview[newCapacity];
		animPool = new AnimData[newCapacity];
		bpRecycle = new int[newCapacity];
		if (array != null)
		{
			Array.Copy(array, bpPool, (newCapacity > bpPoolCapacity) ? bpPoolCapacity : newCapacity);
			Array.Copy(sourceArray, animPool, (newCapacity > bpPoolCapacity) ? bpPoolCapacity : newCapacity);
		}
		bpPoolCapacity = newCapacity;
		animBuffer?.Release();
		animBuffer = new ComputeBuffer(newCapacity, 20, ComputeBufferType.Default);
	}

	public void RemoveBuildPreview(int id)
	{
		if (bpPool[id] != null && bpPool[id].bpgpuiModelInstIndex >= 0)
		{
			animPool[id].time = 0f;
			animPool[id].prepare_length = 0f;
			animPool[id].working_length = 0f;
			animPool[id].state = 0u;
			animPool[id].power = 0f;
			bpPool[id].ResetAll();
			bpRecycle[bpRecycleCursor++] = id;
		}
	}

	public BuildPreview GetBuildPreview(int objId)
	{
		if (bpRecycleCursor > 0)
		{
			int num = bpRecycle[--bpRecycleCursor];
			BuildPreview buildPreview = bpPool[num];
			if (buildPreview == null)
			{
				buildPreview = new BuildPreview();
				bpPool[num] = buildPreview;
			}
			GeneratePreviewByObjId(buildPreview, objId);
			animPool[num] = default(AnimData);
			buildPreview.previewIndex = num;
			buildPreview.bpgpuiModelId = num;
			return buildPreview;
		}
		int num2 = bpCursor++;
		if (num2 == bpPoolCapacity)
		{
			SetDisplayPreviewCapacity(bpPoolCapacity * 2);
		}
		BuildPreview buildPreview2 = bpPool[num2];
		if (buildPreview2 == null)
		{
			buildPreview2 = new BuildPreview();
			bpPool[num2] = buildPreview2;
		}
		GeneratePreviewByObjId(buildPreview2, objId);
		animPool[num2] = default(AnimData);
		buildPreview2.previewIndex = num2;
		buildPreview2.bpgpuiModelId = num2;
		return buildPreview2;
	}

	public void SyncAnimBuffer()
	{
		animBuffer?.SetData(animPool);
	}
}
