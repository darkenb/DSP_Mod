using System;
using HarmonyLib;

namespace MassRecipePaste;

public class ExtraCopy
{
	[HarmonyPostfix]
	[HarmonyPatch(typeof(UIOptionWindow), "OnApplyClick")]
	internal static void OnApplyClick()
	{
		try
		{
			Plugin.instance.Config.Reload();
			Plugin.instance.LoadConfigs();
		}
		catch (Exception data)
		{
			Plugin.Log.LogWarning(data);
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetFactory), "CopyBuildingSetting")]
	public static void CopyExtraClipborad(PlanetFactory __instance, int objectId)
	{
		StationParameters.Clear();
		if (objectId > 0 && objectId < __instance.entityPool.Length && __instance.entityPool[objectId].id == objectId)
		{
			int stationId = __instance.entityPool[objectId].stationId;
			if (stationId != 0)
			{
				StationComponent station = __instance.transport.stationPool[stationId];
				StationParameters.Copy(__instance, station);
			}
		}
	}

	[HarmonyPostfix]
	[HarmonyPatch(typeof(PlanetFactory), "PasteBuildingSetting")]
	public static void PasteExtraClipborad(PlanetFactory __instance, int objectId)
	{
		if (objectId <= 0 || objectId >= __instance.entityPool.Length)
		{
			return;
		}
		DragPasteTool tool = Patches.tool;
		if (tool != null && tool.isPasting && __instance.entityPool[objectId].id == objectId)
		{
			int stationId = __instance.entityPool[objectId].stationId;
			if (stationId != 0)
			{
				StationComponent station = __instance.transport.stationPool[stationId];
				StationParameters.Paste(__instance, station);
			}
		}
	}
}
