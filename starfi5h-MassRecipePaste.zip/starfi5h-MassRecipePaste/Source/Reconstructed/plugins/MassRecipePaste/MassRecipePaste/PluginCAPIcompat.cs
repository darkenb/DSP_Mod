using BepInEx;
using CommonAPI;
using CommonAPI.Systems;
using CommonAPI.Systems.ModLocalization;

namespace MassRecipePaste;

[BepInPlugin("starfi5h.plugin.MassRecipePaste.CAPIcompat", "MassRecipePasteCAPIcompat", "1.0.0")]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "LocalizationModule", "CustomKeyBindSystem" })]
public class PluginCAPIcompat : BaseUnityPlugin
{
	public const string GUID = "starfi5h.plugin.MassRecipePaste.CAPIcompat";

	public const string NAME = "MassRecipePasteCAPIcompat";

	public const string VERSION = "1.0.0";

	public static bool IsRegisiter;

	public void Awake()
	{
		CustomKeyBindSystem.RegisterKeyBind<PressKeyBind>(new BuiltinKey
		{
			key = new CombineKey(46, 2, ECombineKeyAction.OnceClick, _noneKey: false),
			conflictGroup = 2048,
			name = "MassRecipePaste",
			canOverride = true
		});
		LocalizationModule.RegisterTranslation("KEYMassRecipePaste", "(Mod) Mass Recipe Paste", "(Mod) 范围配方黏贴", "Mass Recipe Paste");
		IsRegisiter = true;
	}

	public static bool IsPressed()
	{
		return CustomKeyBindSystem.GetKeyBind("MassRecipePaste").keyValue;
	}
}
