using System;
using System.Collections.Generic;
using System.Linq;
using CommonAPI.Patches;
using CommonAPI.Systems.ModLocalization;
using HarmonyLib;
using UnityEngine;
using xiaoye97;

namespace CommonAPI.Systems;

public class ProtoRegistry : BaseSubmodule
{
	public const string UNKNOWN_MOD = "Unknown";

	internal static string currentMod = "";

	internal static Dictionary<int, ItemProto> items = new Dictionary<int, ItemProto>();

	internal static Dictionary<int, IconToolNew.IconDesc> itemIconDescs = new Dictionary<int, IconToolNew.IconDesc>();

	internal static Dictionary<int, int> itemUpgradeList = new Dictionary<int, int>();

	internal static Dictionary<int, RecipeProto> recipes = new Dictionary<int, RecipeProto>();

	internal static Dictionary<int, RecipeProto> recipeReplace = new Dictionary<int, RecipeProto>();

	internal static Dictionary<int, TechProto> techs = new Dictionary<int, TechProto>();

	internal static Dictionary<int, List<TechProto>> techUpdateList = new Dictionary<int, List<TechProto>>();

	internal static Dictionary<int, ModelProto> models = new Dictionary<int, ModelProto>();

	internal static Dictionary<string, LodMaterials> modelMats = new Dictionary<string, LodMaterials>();

	internal static Dictionary<int, AudioProto> audios = new Dictionary<int, AudioProto>();

	internal static Dictionary<int, MIDIProto> midiProtos = new Dictionary<int, MIDIProto>();

	internal static Dictionary<int, SignalProto> signals = new Dictionary<int, SignalProto>();

	internal static List<ResourceData> modResources = new List<ResourceData>();

	internal static int[] textureNames;

	internal static string[] spriteFileExtensions;

	internal static string[] audioClipFileExtensions;

	internal static ProtoRegistry Instance => CommonAPIPlugin.GetModuleInstance<ProtoRegistry>();

	internal override Type[] Dependencies => new Type[2]
	{
		typeof(PickerExtensionsSystem),
		typeof(LocalizationModule)
	};

	public static event Action onLoadingFinished;

	internal override void SetHooks()
	{
		CommonAPIPlugin.harmony.PatchAll(typeof(ResourcesPatch));
		CommonAPIPlugin.harmony.PatchAll(typeof(StorageComponentPatch));
		CommonAPIPlugin.harmony.PatchAll(typeof(UIBuildMenuPatch));
		CommonAPIPlugin.harmony.PatchAll(typeof(VertaBufferPatch));
		CommonAPIPlugin.harmony.PatchAll(typeof(IconSetPatch));
		CommonAPIPlugin.harmony.PatchAll(typeof(GameMain_Patch));
		CommonAPIPlugin.harmony.PatchAll(typeof(ProtoSet_Patch));
	}

	internal override void Load()
	{
		int num = Shader.PropertyToID("_MainTex");
		int num2 = Shader.PropertyToID("_NormalTex");
		int num3 = Shader.PropertyToID("_MS_Tex");
		int num4 = Shader.PropertyToID("_EmissionTex");
		int num5 = Shader.PropertyToID("_EmissionJitterTex");
		textureNames = new int[5] { num, num2, num3, num4, num5 };
		spriteFileExtensions = new string[3] { ".jpg", ".png", ".tif" };
		audioClipFileExtensions = new string[4] { ".mp3", ".ogg", ".waw", ".aif" };
		LDBTool.PostAddDataAction = (Action)Delegate.Combine(LDBTool.PostAddDataAction, new Action(OnPostAdd));
		LDBTool.EditDataAction = (Action<Proto>)Delegate.Combine(LDBTool.EditDataAction, new Action<Proto>(EditProto));
	}

	internal override void PostLoad()
	{
		LocalizationModule.RegisterTranslation("ModItemMissingWarnTitle", "Missing mod machines");
		LocalizationModule.RegisterTranslation("ModItemMissingWarnDesc", "Following mods had missing machines that were removed from your save:");
	}

	public static void AddResource(ResourceData resource)
	{
		Instance.ThrowIfNotLoaded();
		modResources.Add(resource);
	}

	public static IDisposable StartModLoad(string modGUID)
	{
		Instance.ThrowIfNotLoaded();
		if (currentMod.Equals(""))
		{
			currentMod = modGUID;
			return new ModLoadState(modGUID);
		}
		throw new ArgumentException("Invalid request! Mod " + modGUID + " is trying to start it's loading phase, while " + currentMod + " is still loading. Please report this to " + modGUID + " author!");
	}

	private static void OnPostAdd()
	{
		try
		{
			foreach (KeyValuePair<int, ModelProto> model in models)
			{
				model.Value.Preload();
				PrefabDesc prefabDesc = model.Value.prefabDesc;
				EnsureModelCapacity(ref LDB.models.modelArray, model.Value.ID);
				if (!modelMats.ContainsKey(model.Value.PrefabPath))
				{
					LDB.models.modelArray[model.Value.ID] = model.Value;
					continue;
				}
				LodMaterials lodMaterials = modelMats[model.Value.PrefabPath];
				for (int i = 0; i < prefabDesc.lodCount; i++)
				{
					for (int j = 0; j < prefabDesc.lodMaterials[i].Length; j++)
					{
						if (lodMaterials.HasLod(i))
						{
							prefabDesc.lodMaterials[i][j] = lodMaterials[i][j];
						}
					}
				}
				LDB.models.modelArray[model.Value.ID] = model.Value;
			}
			foreach (KeyValuePair<int, ItemProto> item in items)
			{
				item.Value.Preload(item.Value.index);
			}
			foreach (KeyValuePair<int, RecipeProto> recipe in recipes)
			{
				recipe.Value.Preload(recipe.Value.index);
			}
			foreach (KeyValuePair<int, TechProto> tech in techs)
			{
				tech.Value.Preload();
				tech.Value.Preload2();
			}
			foreach (KeyValuePair<int, List<TechProto>> techUpdate in techUpdateList)
			{
				TechProto techProto = LDB.techs.Select(techUpdate.Key);
				techProto.postTechArray = techProto.postTechArray.AddRangeToArray(techUpdate.Value.ToArray());
			}
			foreach (KeyValuePair<int, AudioProto> audio in audios)
			{
				audio.Value.Preload();
				int value = ((ProtoSet<AudioProto>)LDB.audios).dataIndices[audio.Value.ID];
				LDB.audios.nameIndices.Add(audio.Value.Name, value);
			}
			foreach (KeyValuePair<int, MIDIProto> midiProto in midiProtos)
			{
				midiProto.Value.Preload();
			}
			foreach (KeyValuePair<int, SignalProto> signal in signals)
			{
				signal.Value.Preload();
				signal.Value.description = signal.Value.description.Translate();
			}
			CommonAPIPlugin.logger.LogInfo("Reinit cached data!");
			ItemProto.InitFuelNeeds();
			ItemProto.InitFluids();
			ItemProto.InitItemIds();
			ItemProto.InitItemIndices();
			SpaceSector.PrefabDescByModelIndex = null;
			SpaceSector.InitPrefabDescArray();
			PlanetFactory.PrefabDescByModelIndex = null;
			PlanetFactory.InitPrefabDescArray();
			ProtoRegistry.onLoadingFinished?.Invoke();
			CommonAPIPlugin.logger.LogInfo("Post loading is complete!");
		}
		catch (Exception ex)
		{
			CommonAPIPlugin.logger.LogError("Error initializing proto data!\n" + ex.Message + ", stacktrace:\n" + ex.StackTrace);
		}
	}

	internal static void EnsureModelCapacity(ref ModelProto[] modelArray, int id)
	{
		if (id >= modelArray.Length)
		{
			Array.Resize(ref modelArray, checked(id + 64));
		}
	}

	private static void EditProto(Proto proto)
	{
		if (proto is ItemProto itemProto)
		{
			if (itemUpgradeList.ContainsKey(itemProto.ID))
			{
				itemProto.Grade = itemUpgradeList[itemProto.ID];
				CommonAPIPlugin.logger.LogDebug($"Changing grade of {itemProto.name} to {itemProto.Grade}");
			}
			if (itemProto.Grade == 0 || items.ContainsKey(itemProto.ID))
			{
				return;
			}
			{
				foreach (KeyValuePair<int, ItemProto> item in items)
				{
					if (item.Value.Grade != 0 && item.Value.Upgrades != null && itemProto.Grade <= item.Value.Upgrades.Length && item.Value.Upgrades[itemProto.Grade - 1] == itemProto.ID)
					{
						itemProto.Upgrades = item.Value.Upgrades;
						CommonAPIPlugin.logger.LogDebug("Updating upgrade list of " + itemProto.name + " to " + itemProto.Upgrades.Join());
					}
				}
				return;
			}
		}
		RecipeProto destination = proto as RecipeProto;
		if (destination != null && recipeReplace.ContainsKey(destination.ID))
		{
			recipeReplace[destination.ID].CopyPropsTo(ref destination);
			destination.Preload(destination.index);
		}
	}

	public static Material CreateMaterial(string shaderName, string materialName, string color, string[] textures, string[] keywords)
	{
		return CreateMaterial(shaderName, materialName, color, textures, keywords, null);
	}

	public static Material CreateMaterial(string shaderName, string materialName, string color, string[] textures)
	{
		return CreateMaterial(shaderName, materialName, color, textures, null, null);
	}

	public static Material CreateMaterial(string shaderName, string materialName, string color)
	{
		return CreateMaterial(shaderName, materialName, color, null, null, null);
	}

	public static Material CreateMaterial(string shaderName, string materialName, string color, string[] textures, string[] keywords, int[] textureIDs)
	{
		ColorUtility.TryParseHtmlString(color, out var color2);
		return CreateMaterial(shaderName, materialName, color2, textures, keywords, textureIDs);
	}

	public static Material CreateMaterial(string shaderName, string materialName, Color color, string[] textures, string[] keywords)
	{
		return CreateMaterial(shaderName, materialName, color, textures, keywords, null);
	}

	public static Material CreateMaterial(string shaderName, string materialName, Color color, string[] textures)
	{
		return CreateMaterial(shaderName, materialName, color, textures, null, null);
	}

	public static Material CreateMaterial(string shaderName, string materialName, Color color)
	{
		return CreateMaterial(shaderName, materialName, color, null, null, null);
	}

	public static Material CreateMaterial(string shaderName, string materialName, Color color, string[] textures, string[] keywords, int[] textureIDs)
	{
		Instance.ThrowIfNotLoaded();
		Material material = new Material(Shader.Find(shaderName));
		material.shaderKeywords = keywords ?? new string[1] { "_ENABLE_VFINST" };
		material.color = color;
		material.name = materialName;
		Material material2 = material;
		if (textures == null)
		{
			return material2;
		}
		int[] array = textureIDs ?? textureNames;
		for (int i = 0; i < textures.Length; i++)
		{
			if (i < array.Length && !textures[i].Equals(""))
			{
				Texture2D value = Resources.Load<Texture2D>(textures[i]);
				material2.SetTexture(array[i], value);
			}
		}
		return material2;
	}

	public static int GetGridIndex(int tab, int x, int y)
	{
		return tab * 1000 + y * 100 + x;
	}

	public static ModelProto RegisterModel(int id, string prefabPath, Material[] mats = null, int rendererType = 0)
	{
		Instance.ThrowIfNotLoaded();
		ModelProto modelProto = new ModelProto
		{
			Name = id.ToString(),
			PrefabPath = prefabPath,
			ID = id,
			RendererType = rendererType
		};
		LDBTool.PreAddProto((Proto)modelProto);
		models.Add(modelProto.ID, modelProto);
		if (mats != null)
		{
			modelMats.Add(prefabPath, new LodMaterials(mats));
		}
		return modelProto;
	}

	public static ModelProto RegisterModel(int id, ItemProto proto, string prefabPath, Material[] mats, int[] descFields, int buildIndex)
	{
		return RegisterModel(id, proto, prefabPath, mats, descFields, buildIndex, 0, new int[0], 0);
	}

	public static ModelProto RegisterModel(int id, ItemProto proto, string prefabPath, Material[] mats, int[] descFields, int buildIndex, int grade, int[] upgradesIDs)
	{
		return RegisterModel(id, proto, prefabPath, mats, descFields, buildIndex, grade, upgradesIDs, 0);
	}

	public static ModelProto RegisterModel(int id, ItemProto proto, string prefabPath, Material[] mats, int[] descFields, int buildIndex, int grade, int[] upgradesIDs, int rendererType)
	{
		Instance.ThrowIfNotLoaded();
		ModelProto modelProto = new ModelProto
		{
			Name = id.ToString(),
			PrefabPath = prefabPath,
			ID = id,
			RendererType = rendererType
		};
		AddModelToItemProto(modelProto, proto, descFields, buildIndex, grade, upgradesIDs);
		LDBTool.PreAddProto((Proto)modelProto);
		models.Add(modelProto.ID, modelProto);
		if (mats != null)
		{
			modelMats.Add(prefabPath, new LodMaterials(mats));
		}
		return modelProto;
	}

	public static void AddLodMaterials(string prefabPath, int lod, Material[] mats)
	{
		Instance.ThrowIfNotLoaded();
		if (modelMats.ContainsKey(prefabPath))
		{
			modelMats[prefabPath].AddLod(lod, mats);
		}
		else
		{
			modelMats.Add(prefabPath, new LodMaterials(lod, mats));
		}
	}

	public static void AddModelToItemProto(ModelProto model, ItemProto item, int[] descFields, int buildIndex)
	{
		AddModelToItemProto(model, item, descFields, buildIndex, 0, new int[0]);
	}

	public static void AddModelToItemProto(ModelProto model, ItemProto item, int[] descFields, int buildIndex, int grade, int[] upgradesIDs)
	{
		Instance.ThrowIfNotLoaded();
		item.Type = EItemType.Production;
		item.ModelIndex = model.ID;
		item.ModelCount = 1;
		item.BuildIndex = buildIndex;
		item.BuildMode = 1;
		item.IsEntity = true;
		item.CanBuild = true;
		item.DescFields = descFields;
		if (grade != 0 && upgradesIDs != null)
		{
			item.Grade = grade;
			for (int i = 0; i < upgradesIDs.Length; i++)
			{
				int num = upgradesIDs[i];
				if (num != 0 && !itemUpgradeList.ContainsKey(num))
				{
					itemUpgradeList.Add(num, i + 1);
				}
			}
			upgradesIDs[grade - 1] = item.ID;
			item.Upgrades = upgradesIDs;
		}
		else
		{
			item.Upgrades = new int[0];
		}
		if (currentMod.Equals(""))
		{
			ModProtoHistory.AddModMachine("Unknown", item.ID);
		}
		else
		{
			ModProtoHistory.AddModMachine(currentMod, item.ID);
		}
	}

	public static ItemProto RegisterItem(int id, string name, string description, string iconPath, int gridIndex, int stackSize, EItemType type)
	{
		return RegisterItem(id, name, description, iconPath, gridIndex, stackSize, type, null);
	}

	public static ItemProto RegisterItem(int id, string name, string description, string iconPath, int gridIndex, int stackSize)
	{
		return RegisterItem(id, name, description, iconPath, gridIndex, stackSize, EItemType.Material, null);
	}

	public static ItemProto RegisterItem(int id, string name, string description, string iconPath, int gridIndex)
	{
		return RegisterItem(id, name, description, iconPath, gridIndex, 50, EItemType.Material, null);
	}

	public static ItemProto RegisterItem(int id, string name, string description, string iconPath, int gridIndex, int stackSize, EItemType type, IconToolNew.IconDesc beltItemDesc)
	{
		Instance.ThrowIfNotLoaded();
		if (beltItemDesc == null)
		{
			beltItemDesc = GetDefaultIconDesc(Color.gray, Color.gray);
		}
		ItemProto itemProto = new ItemProto();
		itemProto.Type = type;
		itemProto.StackSize = stackSize;
		itemProto.FuelType = 0;
		itemProto.IconPath = iconPath;
		itemProto.Name = name;
		itemProto.Description = description;
		itemProto.GridIndex = gridIndex;
		itemProto.DescFields = new int[1] { 1 };
		itemProto.ID = id;
		ItemProto itemProto2 = itemProto;
		LDBTool.PreAddProto((Proto)itemProto2);
		items.Add(itemProto2.ID, itemProto2);
		itemIconDescs.Add(itemProto2.ID, beltItemDesc);
		return itemProto2;
	}

	public static IconToolNew.IconDesc GetDefaultIconDesc(Color faceColor, Color sideColor)
	{
		return new IconToolNew.IconDesc
		{
			faceColor = faceColor,
			sideColor = sideColor,
			faceEmission = Color.black,
			sideEmission = Color.black,
			iconEmission = new Color(0.2f, 0.2f, 0.2f, 1f),
			metallic = 0.8f,
			smoothness = 0.5f,
			solidAlpha = 1f,
			iconAlpha = 1f
		};
	}

	public static IconToolNew.IconDesc GetDefaultIconDesc(Color faceColor, Color sideColor, Color faceEmission, Color sideEmission)
	{
		IconToolNew.IconDesc defaultIconDesc = GetDefaultIconDesc(faceColor, sideColor);
		defaultIconDesc.faceEmission = faceEmission;
		defaultIconDesc.sideEmission = sideEmission;
		return defaultIconDesc;
	}

	public static RecipeProto RegisterRecipe(int id, int type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description, int techID)
	{
		return RegisterRecipe(id, type, time, input, inCounts, output, outCounts, description, techID, 0);
	}

	public static RecipeProto RegisterRecipe(int id, int type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description)
	{
		return RegisterRecipe(id, type, time, input, inCounts, output, outCounts, description, 0, 0);
	}

	public static RecipeProto RegisterRecipe(int id, int type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description, int techID, int gridIndex)
	{
		Instance.ThrowIfNotLoaded();
		return RegisterRecipe(id, type, time, input, inCounts, output, outCounts, description, techID, gridIndex, "", "");
	}

	public static RecipeProto RegisterRecipe(int id, int type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description, int techID, int gridIndex, string iconPath)
	{
		Instance.ThrowIfNotLoaded();
		return RegisterRecipe(id, type, time, input, inCounts, output, outCounts, description, techID, gridIndex, "", iconPath);
	}

	public static RecipeProto RegisterRecipe(int id, int type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description, int techID, int gridIndex, string name, string iconPath)
	{
		Instance.ThrowIfNotLoaded();
		if (AssemblerRecipeSystem.IsRecipeTypeRegistered(type))
		{
			RecipeProto recipeProto = RegisterRecipe(id, (ERecipeType)20, time, input, inCounts, output, outCounts, description, techID, gridIndex, name, iconPath);
			AssemblerRecipeSystem.BindRecipeToType(recipeProto, type);
			return recipeProto;
		}
		throw new ArgumentException($"Recipe Type: {type} is not registered!");
	}

	public static RecipeProto RegisterRecipe(int id, ERecipeType type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description, int techID)
	{
		return RegisterRecipe(id, type, time, input, inCounts, output, outCounts, description, techID, 0);
	}

	public static RecipeProto RegisterRecipe(int id, ERecipeType type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description)
	{
		return RegisterRecipe(id, type, time, input, inCounts, output, outCounts, description, 0, 0);
	}

	public static RecipeProto RegisterRecipe(int id, ERecipeType type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description, int techID, int gridIndex)
	{
		Instance.ThrowIfNotLoaded();
		RecipeProto recipeProto = NewRecipeProto(id, type, time, input, inCounts, output, outCounts, description, techID, gridIndex, "", "");
		LDBTool.PreAddProto((Proto)recipeProto);
		recipes.Add(id, recipeProto);
		return recipeProto;
	}

	public static RecipeProto RegisterRecipe(int id, ERecipeType type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description, int techID, int gridIndex, string iconPath)
	{
		Instance.ThrowIfNotLoaded();
		RecipeProto recipeProto = NewRecipeProto(id, type, time, input, inCounts, output, outCounts, description, techID, gridIndex, "", iconPath);
		LDBTool.PreAddProto((Proto)recipeProto);
		recipes.Add(id, recipeProto);
		return recipeProto;
	}

	public static RecipeProto RegisterRecipe(int id, ERecipeType type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description, int techID, int gridIndex, string name, string iconPath)
	{
		Instance.ThrowIfNotLoaded();
		RecipeProto recipeProto = NewRecipeProto(id, type, time, input, inCounts, output, outCounts, description, techID, gridIndex, name, iconPath);
		LDBTool.PreAddProto((Proto)recipeProto);
		recipes.Add(id, recipeProto);
		return recipeProto;
	}

	private static RecipeProto NewRecipeProto(int id, ERecipeType type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description, int techID, int gridIndex, string name, string iconPath)
	{
		Instance.ThrowIfNotLoaded();
		if (output.Length != 0)
		{
			ItemProto itemProto = null;
			if (name.Equals("") || iconPath.Equals(""))
			{
				itemProto = (items.ContainsKey(output[0]) ? items[output[0]] : LDB.items.Select(output[0]));
			}
			TechProto preTech = null;
			if (techID != 0 && LDB.techs.Exist(techID))
			{
				preTech = LDB.techs.Select(techID);
			}
			return new RecipeProto
			{
				Type = type,
				Handcraft = true,
				TimeSpend = time,
				Items = input,
				ItemCounts = inCounts,
				Results = output,
				ResultCounts = outCounts,
				Description = description,
				GridIndex = ((gridIndex == 0) ? itemProto.GridIndex : gridIndex),
				IconPath = (iconPath.Equals("") ? itemProto.IconPath : iconPath),
				Name = (name.Equals("") ? (itemProto.Name + "Recipe") : name),
				preTech = preTech,
				ID = id
			};
		}
		throw new ArgumentException("Output array must not be empty");
	}

	public static void EditRecipe(int id, ERecipeType type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description, int techID)
	{
		EditRecipe(id, type, time, input, inCounts, output, outCounts, description, techID, 0);
	}

	public static void EditRecipe(int id, ERecipeType type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description)
	{
		EditRecipe(id, type, time, input, inCounts, output, outCounts, description, 0, 0);
	}

	public static void EditRecipe(int id, ERecipeType type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description, int techID, int gridIndex)
	{
		EditRecipe(id, type, time, input, inCounts, output, outCounts, description, techID, gridIndex, "");
	}

	public static void EditRecipe(int id, ERecipeType type, int time, int[] input, int[] inCounts, int[] output, int[] outCounts, string description, int techID, int gridIndex, string iconPath)
	{
		Instance.ThrowIfNotLoaded();
		RecipeProto recipeProto = NewRecipeProto(id, type, time, input, inCounts, output, outCounts, description, techID, gridIndex, "", iconPath);
		recipeReplace.Add(recipeProto.ID, recipeProto);
	}

	public static TechProto RegisterTech(int id, string name, string description, string conclusion, string iconPath, int[] preTechs, int[] jellos, int[] jelloRate, long hashNeeded, int[] unlockRecipes, Vector2 position)
	{
		Instance.ThrowIfNotLoaded();
		bool isLabTech = jellos.Any((int itemId) => LabComponent.matrixIds.Contains(itemId));
		TechProto techProto = new TechProto
		{
			ID = id,
			Name = name,
			Desc = description,
			Published = true,
			Conclusion = conclusion,
			IconPath = iconPath,
			IsLabTech = isLabTech,
			PreTechs = preTechs,
			Items = jellos,
			ItemPoints = jelloRate,
			HashNeeded = hashNeeded,
			UnlockRecipes = unlockRecipes,
			AddItems = Array.Empty<int>(),
			AddItemCounts = Array.Empty<int>(),
			Position = position,
			PreItem = Array.Empty<int>(),
			PreTechsImplicit = Array.Empty<int>(),
			UnlockFunctions = Array.Empty<int>(),
			UnlockValues = Array.Empty<double>(),
			PropertyOverrideItems = Array.Empty<int>(),
			PropertyItemCounts = Array.Empty<int>(),
			PropertyOverrideItemArray = Array.Empty<IDCNT>()
		};
		foreach (int key in preTechs)
		{
			if (techUpdateList.ContainsKey(key))
			{
				techUpdateList[key].Add(techProto);
				continue;
			}
			techUpdateList.Add(key, new List<TechProto>(new TechProto[1] { techProto }));
		}
		LDBTool.PreAddProto((Proto)techProto);
		techs.Add(id, techProto);
		return techProto;
	}

	[Obsolete("Use LocalizationModule.EditTranslation() instead!")]
	public static void EditString(string key, string enTrans)
	{
		EditString(key, enTrans, "", "");
	}

	[Obsolete("Use LocalizationModule.EditTranslation() instead!")]
	public static void EditString(string key, string enTrans, string cnTrans)
	{
		EditString(key, enTrans, cnTrans, "");
	}

	[Obsolete("Use LocalizationModule.EditTranslation() instead!")]
	public static void EditString(string key, string enTrans, string cnTrans, string frTrans)
	{
		Instance.ThrowIfNotLoaded();
		LocalizationModule.EditTranslation(key, enTrans, cnTrans, frTrans);
	}

	[Obsolete("Use LocalizationModule.RegisterTranslation() instead!")]
	public static void RegisterString(string key, string enTrans, string cnTrans)
	{
		RegisterString(key, enTrans, cnTrans, "");
	}

	[Obsolete("Use LocalizationModule.RegisterTranslation() instead!")]
	public static void RegisterString(string key, string enTrans)
	{
		RegisterString(key, enTrans, "", "");
	}

	[Obsolete("Use LocalizationModule.RegisterTranslation() instead!")]
	public static void RegisterString(string key, string enTrans, string cnTrans, string frTrans)
	{
		Instance.ThrowIfNotLoaded();
		LocalizationModule.RegisterTranslation(key, enTrans, cnTrans, frTrans);
	}

	public static AudioProto RegisterInstrument(int id, string audioClipPath, int volume, float length, float fadeIn, float fadeOut)
	{
		AudioProto audioProto = RegisterAudio(id, audioClipPath, 32, 1f, 1f, 0f, 1f, loop: false, localized: false, bypassEffect: false);
		AddMIDIInstrument(id, audioProto, volume, length, fadeIn, fadeOut);
		return audioProto;
	}

	public static AudioProto RegisterLocalizedAudio(int id, string audioClipPath, float volume)
	{
		return RegisterAudio(id, audioClipPath, 1, volume, 1f, 0f, 0f, loop: false, localized: true, bypassEffect: true);
	}

	public static AudioProto RegisterAudio(int id, string audioClipPath, float volume, float spatialBlend, bool loop)
	{
		return RegisterAudio(id, audioClipPath, 1, volume, 1f, 0f, spatialBlend, loop, localized: false, bypassEffect: false);
	}

	public static AudioProto RegisterAudio(int id, string audioClipPath, int clipCount, float volume, float pitch, float pitchRandomness, float spatialBlend, bool loop, bool localized, bool bypassEffect)
	{
		Instance.ThrowIfNotLoaded();
		string name = audioClipPath.Split('/', '\\').Last();
		AudioProto audioProto = new AudioProto
		{
			ID = id,
			Name = name,
			ClipPath = audioClipPath,
			ClipCount = clipCount,
			Pitch = pitch,
			Volume = volume,
			PitchRandomness = pitchRandomness,
			SpatialBlend = spatialBlend,
			Loop = loop,
			Localized = localized,
			BypassEffect = bypassEffect
		};
		LDBTool.PreAddProto((Proto)audioProto);
		audios.Add(id, audioProto);
		return audioProto;
	}

	public static void EditAudio(int id, string newAudioClipPath, float volume, float pitch, float pitchRandomness, float spatialBlend)
	{
		Instance.ThrowIfNotLoaded();
		AudioProto audioProto = LDB.audios.Select(id);
		audioProto.ClipPath = newAudioClipPath;
		audioProto.Volume = volume;
		audioProto.Pitch = pitch;
		audioProto.PitchRandomness = pitchRandomness;
		audioProto.SpatialBlend = spatialBlend;
	}

	internal static void AddMIDIInstrument(int id, AudioProto audio, int volume, float length, float fadeIn, float fadeOut)
	{
		List<int> list = new List<int>();
		List<Vector2> list2 = new List<Vector2>();
		for (int i = 7; i <= 100; i += 3)
		{
			list.Add(i);
			list2.Add(new Vector2(i - 1, i + 1));
		}
		MIDIProto mIDIProto = new MIDIProto();
		mIDIProto.ID = id;
		mIDIProto.Instrument = true;
		mIDIProto.StandardKey = 58;
		mIDIProto.PitchRange = new int[2] { 6, 101 };
		mIDIProto.Key = list.ToArray();
		mIDIProto.KeyRange = list2.ToArray();
		mIDIProto.Volume = volume;
		mIDIProto.Length = length;
		mIDIProto.FadeInDuration = fadeIn;
		mIDIProto.FadeOutDuration = fadeOut;
		mIDIProto.Name = audio.Name;
		MIDIProto mIDIProto2 = mIDIProto;
		LDBTool.PreAddProto((Proto)mIDIProto2);
		midiProtos.Add(mIDIProto2.ID, mIDIProto2);
	}

	public static SignalProto RegisterSignal(int id, string iconPath, int gridIndex, string name, string desc)
	{
		Instance.ThrowIfNotLoaded();
		SignalProto signalProto = new SignalProto
		{
			ID = id,
			IconPath = iconPath,
			Name = name,
			GridIndex = gridIndex,
			description = desc
		};
		LDBTool.PreAddProto((Proto)signalProto);
		signals.Add(signalProto.ID, signalProto);
		return signalProto;
	}

	public static void EditSignal(int id, string iconPath, int gridIndex, string name)
	{
		Instance.ThrowIfNotLoaded();
		SignalProto signalProto = LDB.signals.Select(id);
		if (!iconPath.Equals(""))
		{
			signalProto.IconPath = iconPath;
		}
		signalProto.GridIndex = gridIndex;
		signalProto.Name = name;
	}
}
