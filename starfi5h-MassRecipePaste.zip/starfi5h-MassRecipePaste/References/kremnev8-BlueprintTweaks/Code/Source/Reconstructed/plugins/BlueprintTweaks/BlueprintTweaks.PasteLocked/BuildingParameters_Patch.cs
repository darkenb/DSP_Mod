using System.Collections.Generic;
using System.Reflection.Emit;
using CommonAPI;
using HarmonyLib;

namespace BlueprintTweaks.PasteLocked;

[RegisterPatch("PasteLocked")]
public static class BuildingParameters_Patch
{
	[HarmonyPatch(typeof(BuildingParameters), "CanPasteToFactoryObject")]
	[HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> AllowPastingLockedRecipes(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(false, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld), new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(GameHistoryData), "RecipeUnlocked"))).Repeat(delegate(CodeMatcher codeMatcher2)
		{
			codeMatcher2.Advance(-1).SetOpcodeAndAdvance(OpCodes.Nop).SetOpcodeAndAdvance(OpCodes.Nop)
				.SetInstructionAndAdvance(new CodeInstruction(OpCodes.Nop))
				.SetInstructionAndAdvance(new CodeInstruction(OpCodes.Ldc_I4_1));
		});
		codeMatcher.Start().MatchForward(false, new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Ldfld), new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(GameHistoryData), "ItemUnlocked"))).Repeat(delegate(CodeMatcher codeMatcher2)
		{
			codeMatcher2.Advance(-1).SetOpcodeAndAdvance(OpCodes.Nop).SetOpcodeAndAdvance(OpCodes.Nop)
				.SetInstructionAndAdvance(new CodeInstruction(OpCodes.Nop))
				.SetInstructionAndAdvance(new CodeInstruction(OpCodes.Ldc_I4_1));
		});
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(BuildingParameters), "ApplyPrebuildParametersToEntity")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> AllowBuildingWithLockedRecipes(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions).MatchForward(false, new CodeMatch(OpCodes.Ldarg_1), new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(GameHistoryData), "RecipeUnlocked"))).Repeat(delegate(CodeMatcher codeMatcher2)
		{
			codeMatcher2.Advance(-1).SetOpcodeAndAdvance(OpCodes.Nop).SetOpcodeAndAdvance(OpCodes.Nop)
				.SetInstructionAndAdvance(new CodeInstruction(OpCodes.Ldc_I4_1));
		});
		codeMatcher.Start().MatchForward(false, new CodeMatch(OpCodes.Ldarg_3), new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch(OpCodes.Ldelem_I4), new CodeMatch(OpCodes.Callvirt, AccessTools.Method(typeof(GameHistoryData), "ItemUnlocked"))).Advance(-1)
			.SetOpcodeAndAdvance(OpCodes.Nop)
			.SetOpcodeAndAdvance(OpCodes.Nop)
			.SetOpcodeAndAdvance(OpCodes.Nop)
			.SetOpcodeAndAdvance(OpCodes.Nop)
			.SetInstructionAndAdvance(new CodeInstruction(OpCodes.Ldc_I4_1));
		return codeMatcher.InstructionEnumeration();
	}
}
