using HarmonyLib;

namespace BlueprintTweaks.InstallCheck;

public static class UIMainMenuPatch
{
	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	[HarmonyPostfix]
	public static void OnMainMenuOpen()
	{
		if (!InstallationChecker.installationIsValid)
		{
			string text = "Mod installation is incorrect because:\n";
			if (!InstallationChecker.preloaderInstalled)
			{
				text += "  - Preloader patch has not been detected\n";
			}
			if (!InstallationChecker.assetBundleFound)
			{
				text += "  - Asset Bundle in installation folder is missing!\n";
			}
			if (!InstallationChecker.ldbToolInstalled)
			{
				text += "  - Plugin \"LDB Tool\" is missing\n";
			}
			if (!InstallationChecker.nebulaAPIInstalled)
			{
				text += "  - Plugin \"Nebula Multiplayer Mod API\" is missing\n";
			}
			text += "Please check your installation, make sure you followed installation instructions correctly.\nIf you are using a mod manager make sure that all dependencies have been downloaded!\nIf nothing helps you can message me via Discord: Kremnev8#3756";
			UIMessageBox.Show("BlueprintTweaks mod installation is incorrect!", text, "Ok", 3);
		}
	}
}
