using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BlueprintTweaks.FactoryUndo;

public class UndoBuild : UndoAction
{
	protected static int[] tmpIds = new int[20];

	public static BuildingParameters undoClipboard = BuildingParameters.zero;

	protected List<int> objectIds;

	protected List<BuildPreview> previews;

	protected static Dictionary<int, BuildPreview> tmpPreviews = new Dictionary<int, BuildPreview>();

	public UndoBuild(PlayerUndo undoData, int objectId)
		: base(undoData)
	{
		objectIds = new List<int> { objectId };
	}

	public UndoBuild(PlayerUndo undoData, IEnumerable<int> objectIds)
		: base(undoData)
	{
		this.objectIds = new List<int>(objectIds);
	}

	public override void NotifyBuild(int preObjId, int postObjId)
	{
		int num = objectIds.FindIndex((int i) => preObjId == i);
		if (num >= 0)
		{
			objectIds[num] = postObjId;
		}
	}

	public override void NotifyDismantled(int objId)
	{
		objectIds.Remove(objId);
	}

	public override bool HasAnyPrebuilds()
	{
		return objectIds.Any((int i) => i < 0);
	}

	public override bool IsEmpty()
	{
		if (objectIds != null)
		{
			return objectIds.Count == 0;
		}
		return true;
	}

	public override bool Undo(PlanetFactory factory, PlayerAction_Build actionBuild)
	{
		bool result = SaveBuildData(factory, actionBuild);
		using (UndoManager.IgnoreAllEvents.On())
		{
			foreach (int objectId in objectIds)
			{
				if (objectId != 0)
				{
					PrefabDesc prefabDesc = actionBuild.noneTool.GetPrefabDesc(objectId);
					if (prefabDesc == null || !prefabDesc.isStation || !BlueprintTweaksPlugin.undoExcludeStations.Value)
					{
						actionBuild.DoDismantleObject(objectId);
					}
				}
			}
		}
		undoData.notifyBuildListeners.Remove(this);
		undoData.notifyDismantleListeners.Remove(this);
		return result;
	}

	protected bool SaveBuildData(PlanetFactory factory, PlayerAction_Build actionBuild)
	{
		bool result = false;
		previews = new List<BuildPreview>(objectIds.Count);
		tmpPreviews.Clear();
		foreach (int objectId in objectIds)
		{
			if (objectId > 0)
			{
				ref EntityData reference = ref factory.entityPool[objectId];
				if (reference.id == objectId)
				{
					BuildPreview item = InitPreviewFromObject(factory, actionBuild, reference.id);
					previews.Add(item);
					result = true;
				}
			}
			else if (objectId < 0)
			{
				ref PrebuildData reference2 = ref factory.prebuildPool[-objectId];
				if (reference2.id == -objectId)
				{
					BuildPreview item2 = InitPreviewFromObject(factory, actionBuild, -reference2.id);
					previews.Add(item2);
					result = true;
				}
			}
		}
		tmpPreviews.Clear();
		return result;
	}

	private static BuildPreview InitPreviewFromObject(PlanetFactory factory, PlayerAction_Build actionBuild, int objectId, bool checkConn = true)
	{
		BuildPreview buildPreview;
		if (tmpPreviews.ContainsKey(objectId))
		{
			buildPreview = tmpPreviews[objectId];
		}
		else
		{
			buildPreview = new BuildPreview();
			buildPreview.ResetAll();
			tmpPreviews.Add(objectId, buildPreview);
		}
		buildPreview.item = actionBuild.noneTool.GetItemProto(objectId);
		buildPreview.desc = actionBuild.noneTool.GetPrefabDesc(objectId);
		Pose objectPose = actionBuild.noneTool.GetObjectPose(objectId);
		Pose objectPose2 = actionBuild.noneTool.GetObjectPose2(objectId);
		buildPreview.lpos = objectPose.position;
		buildPreview.lrot = objectPose.rotation;
		buildPreview.lpos2 = objectPose2.position;
		buildPreview.lrot2 = objectPose2.rotation;
		undoClipboard.CopyFromFactoryObject(objectId, factory);
		buildPreview.recipeId = undoClipboard.recipeId;
		buildPreview.filterId = undoClipboard.filterId;
		buildPreview.parameters = ((undoClipboard.parameters == null) ? null : ((int[])undoClipboard.parameters.Clone()));
		if (undoClipboard.parameters != null)
		{
			buildPreview.paramCount = undoClipboard.parameters.Length;
		}
		if (!checkConn)
		{
			return buildPreview;
		}
		factory.ReadObjectConn(objectId, 0, out var _, out var otherObjId, out var _);
		if (otherObjId != 0)
		{
			if (tmpPreviews.ContainsKey(otherObjId))
			{
				buildPreview.output = tmpPreviews[otherObjId];
				buildPreview.outputFromSlot = 0;
				buildPreview.outputToSlot = 1;
			}
			else
			{
				BuildPreview value = (buildPreview.output = new BuildPreview());
				buildPreview.outputFromSlot = 0;
				buildPreview.outputToSlot = 1;
				buildPreview.objId = otherObjId;
				tmpPreviews.Add(otherObjId, value);
			}
		}
		return buildPreview;
	}

	public override bool Redo(PlanetFactory factory, PlayerAction_Build actionBuild)
	{
		if (previews == null)
		{
			return false;
		}
		BuildTool_Click clickTool = actionBuild.clickTool;
		clickTool.InitTool();
		if (previews.Count == 1)
		{
			BuildPreview buildPreview = previews[0];
			if (buildPreview.desc.multiLevel)
			{
				Vector3 vector = buildPreview.lpos - buildPreview.lrot * buildPreview.desc.lapJoint;
				int buildingsInAreaNonAlloc = factory.planet.physics.nearColliderLogic.GetBuildingsInAreaNonAlloc(vector, 0.25f, ref tmpIds, ignoreAltitude: false);
				if (buildingsInAreaNonAlloc > 0)
				{
					for (int i = 0; i < buildingsInAreaNonAlloc; i++)
					{
						int num = tmpIds[i];
						Pose objectPose = actionBuild.noneTool.GetObjectPose(num);
						PrefabDesc prefabDesc = actionBuild.noneTool.GetPrefabDesc(num);
						if (prefabDesc != null && buildPreview.desc.modelIndex == prefabDesc.modelIndex && (objectPose.position - vector).magnitude < 0.1f)
						{
							buildPreview.inputObjId = num;
							buildPreview.inputFromSlot = 15;
							buildPreview.inputToSlot = 14;
							break;
						}
					}
				}
			}
		}
		clickTool.buildPreviews.Clear();
		clickTool.buildPreviews.AddRange(previews.Where((BuildPreview preview) => !preview.desc.isStation || !BlueprintTweaksPlugin.undoExcludeStations.Value));
		bool flag;
		using (UndoManager.IgnoreAllEvents.On())
		{
			clickTool.CheckInserters();
			flag = clickTool.CheckBuildConditions();
			if (flag)
			{
				clickTool.CreatePrebuilds();
			}
			objectIds.Clear();
			foreach (BuildPreview buildPreview2 in clickTool.buildPreviews)
			{
				objectIds.Add(buildPreview2.objId);
			}
			if (objectIds.Count > 0)
			{
				if (!undoData.notifyBuildListeners.Contains(this))
				{
					undoData.notifyBuildListeners.Add(this);
				}
				if (!undoData.notifyDismantleListeners.Contains(this))
				{
					undoData.notifyDismantleListeners.Add(this);
				}
			}
		}
		previews.Clear();
		previews = null;
		return flag;
	}
}
