using System.Collections.Generic;
using UnityEngine;

namespace BlueprintTweaks;

public class UIRecipesPanel : UIBlueprintPanel
{
	public List<UIBlueprintRecipeItem> recipeItems = new List<UIBlueprintRecipeItem>();

	public List<int> tmpRecipeList = new List<int>();

	public int recipeCount;

	public UIBlueprintRecipeItem prefab;

	public static Sprite noRecipeIcon;

	public override int verticalSize
	{
		get
		{
			if (recipeCount == 0)
			{
				return 22;
			}
			return 22 + ((recipeCount - 1) / 8 + 1) * 46;
		}
	}

	private void Awake()
	{
		noRecipeIcon = Resources.Load<Sprite>("ui/textures/sprites/icons/select-recipe");
	}

	public override void OnUpdate()
	{
		tmpRecipeList.Clear();
		BlueprintBuilding[] buildings = inspector.blueprint.buildings;
		foreach (BlueprintBuilding blueprintBuilding in buildings)
		{
			int num = blueprintBuilding.recipeId;
			if (num == 0)
			{
				ItemProto itemProto = LDB.items.Select(blueprintBuilding.itemId);
				if (itemProto.prefabDesc != null)
				{
					num = 0 - itemProto.prefabDesc.assemblerRecipeType;
					if (itemProto.prefabDesc.isLab && blueprintBuilding.parameters.Length != 0 && blueprintBuilding.parameters[0] != 2)
					{
						num = -15;
					}
				}
			}
			if (num != 0 && !tmpRecipeList.Contains(num))
			{
				tmpRecipeList.Add(num);
			}
		}
		int num2 = 0;
		foreach (int tmpRecipe in tmpRecipeList)
		{
			SetItem(num2, tmpRecipe);
			num2++;
		}
		ClearComponentItems(num2);
	}

	public void SetItem(int index, int recipeId)
	{
		if (index >= 0 && index <= 256)
		{
			while (index >= recipeItems.Count)
			{
				UIBlueprintRecipeItem uIBlueprintRecipeItem = Object.Instantiate(prefab, prefab.transform.parent);
				uIBlueprintRecipeItem.Create(this);
				recipeItems.Add(uIBlueprintRecipeItem);
			}
			recipeItems[index].SetDisplay(index, recipeId);
			recipeItems[index].Open();
		}
	}

	public void ClearComponentItems(int activeCount = 0)
	{
		for (int i = activeCount; i < recipeItems.Count; i++)
		{
			recipeItems[i].Close();
		}
		recipeCount = activeCount;
	}

	public void ChangeRecipe(int oldRecipe, RecipeProto newRecipe)
	{
		BlueprintBuilding[] buildings = inspector.blueprint.buildings;
		if (oldRecipe < 0)
		{
			ERecipeType eRecipeType = (ERecipeType)(-oldRecipe);
			BlueprintBuilding[] array = buildings;
			foreach (BlueprintBuilding blueprintBuilding in array)
			{
				if (blueprintBuilding.recipeId != 0)
				{
					continue;
				}
				ItemProto itemProto = LDB.items.Select(blueprintBuilding.itemId);
				if (itemProto.prefabDesc != null)
				{
					if (itemProto.prefabDesc.assemblerRecipeType == eRecipeType)
					{
						blueprintBuilding.recipeId = newRecipe.ID;
					}
					else if (itemProto.prefabDesc.isLab && eRecipeType == ERecipeType.Research && blueprintBuilding.parameters.Length != 0 && blueprintBuilding.parameters[0] != 2)
					{
						blueprintBuilding.recipeId = newRecipe.ID;
						blueprintBuilding.parameters[0] = 1;
					}
				}
			}
		}
		else
		{
			BlueprintBuilding[] array = buildings;
			foreach (BlueprintBuilding blueprintBuilding2 in array)
			{
				if (blueprintBuilding2.recipeId == oldRecipe)
				{
					blueprintBuilding2.recipeId = newRecipe.ID;
				}
			}
		}
		if (inspector.usage == UIBlueprintInspector.EUsage.Paste)
		{
			inspector.pasteBuildTool.ResetStates();
		}
		inspector.Refresh(forModify: true, refreshComponent: true, refreshCode: true);
	}
}
