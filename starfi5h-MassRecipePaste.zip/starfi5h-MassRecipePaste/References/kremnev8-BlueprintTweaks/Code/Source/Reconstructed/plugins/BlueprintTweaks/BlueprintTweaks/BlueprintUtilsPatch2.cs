using System;
using System.Collections.Generic;
using System.Reflection.Emit;
using HarmonyLib;
using UnityEngine;

namespace BlueprintTweaks;

[HarmonyPatch]
public static class BlueprintUtilsPatch2
{
	public delegate float RefAction(ref Vector4 area, ref float latValueOut, bool longAxis, bool latAxis, float yaw);

	public delegate void RectRefAction(ref float xPos, ref float yPos, int yawCount);

	public delegate float MirrorFunc(ref Vector4 area, bool longAxis, int yawCount);

	public delegate float ApplyFunc(float value, int yawCount);

	public static bool mirrorLat;

	public static bool mirrorLong;

	public static Dictionary<int, MajorAxis> buildingsAxis = new Dictionary<int, MajorAxis>();

	public static Dictionary<int, Vector2> buildingsOffsets = new Dictionary<int, Vector2>();

	public static void Init()
	{
		buildingsAxis.Add(52, MajorAxis.XAXIS);
		buildingsAxis.Add(121, MajorAxis.XAXIS);
		buildingsAxis.Add(64, MajorAxis.XAXIS);
		buildingsOffsets.Add(64, new Vector2(0f, -1f));
		buildingsAxis.Add(376, MajorAxis.XAXIS);
		buildingsOffsets.Add(376, new Vector2(0f, -1f));
		buildingsAxis.Add(69, MajorAxis.XAXIS);
		buildingsOffsets.Add(54, new Vector2(-1f, 0f));
		buildingsOffsets.Add(118, new Vector2(-1f, 0f));
	}

	public static void UpdateBlueprintDisplay()
	{
		if (!(GameMain.mainPlayer?.controller == null) && GameMain.mainPlayer.controller.actionBuild.blueprintMode == EBlueprintMode.Paste)
		{
			GameMain.mainPlayer.controller.actionBuild.blueprintPasteTool.ForceDetermineBP();
		}
	}

	[HarmonyPatch(typeof(BuildTool_BlueprintPaste), "_OnClose")]
	[HarmonyPrefix]
	public static void Close()
	{
		if (BlueprintTweaksPlugin.resetFunctionsOnMenuExit.Value)
		{
			mirrorLat = false;
			mirrorLong = false;
		}
	}

	[HarmonyPatch(typeof(BlueprintUtils), "TransitionWidthAndHeight")]
	[HarmonyPrefix]
	public static void MirrorObjects(float _yaw, ref float _width, ref float _height)
	{
		if (mirrorLat)
		{
			_width *= -1f;
		}
		if (mirrorLong)
		{
			_height *= -1f;
		}
	}

	public static void MirrorReformRect(ref float xPos, ref float yPos, int yawCount)
	{
		if (mirrorLat)
		{
			if (yawCount == 1 || yawCount == 3)
			{
				yPos *= -1f;
			}
			else
			{
				xPos *= -1f;
			}
		}
		if (mirrorLong)
		{
			if (yawCount == 1 || yawCount == 3)
			{
				xPos *= -1f;
			}
			else
			{
				yPos *= -1f;
			}
		}
	}

	public static float ApplyMirrorLat(float latValue, int yawCount)
	{
		if (!mirrorLong && !mirrorLat)
		{
			return latValue;
		}
		if (mirrorLong && mirrorLat)
		{
			return latValue * -1f;
		}
		if (yawCount == 1 || yawCount == 3)
		{
			if (!mirrorLong)
			{
				return latValue * -1f;
			}
			return latValue;
		}
		if (!mirrorLong)
		{
			return latValue;
		}
		return latValue * -1f;
	}

	public static float ApplyMirrorLong(float longValue, int yawCount)
	{
		if (!mirrorLong && !mirrorLat)
		{
			return longValue;
		}
		if (mirrorLong && mirrorLat)
		{
			return longValue * -1f;
		}
		if (yawCount == 1 || yawCount == 3)
		{
			if (!mirrorLat)
			{
				return longValue * -1f;
			}
			return longValue;
		}
		if (!mirrorLat)
		{
			return longValue;
		}
		return longValue * -1f;
	}

	public static float MirrorRotation(float yaw)
	{
		if (mirrorLat && mirrorLong)
		{
			return yaw + 180f;
		}
		if (mirrorLat)
		{
			return 0f - yaw;
		}
		if (mirrorLong)
		{
			return 0f - yaw + 180f;
		}
		return yaw;
	}

	public static float MirrorAreaLong(ref Vector4 area, bool longAxis, int yawCount)
	{
		if (mirrorLat && yawCount != 1 && yawCount != 3)
		{
			longAxis = !longAxis;
		}
		if (mirrorLong && (yawCount == 1 || yawCount == 3))
		{
			longAxis = !longAxis;
		}
		if (!longAxis)
		{
			return area.x;
		}
		return area.z;
	}

	public static float MirrorAreaLat(ref Vector4 area, bool latAxis, int yawCount)
	{
		if (mirrorLat && (yawCount == 1 || yawCount == 3))
		{
			latAxis = !latAxis;
		}
		if (mirrorLong && yawCount != 1 && yawCount != 3)
		{
			latAxis = !latAxis;
		}
		if (!latAxis)
		{
			return area.y;
		}
		return area.w;
	}

	public static float MirrorArea(ref Vector4 area, ref float latValueOut, bool longAxis, bool latAxis, float yaw)
	{
		int num = Mathf.FloorToInt(yaw / 90f);
		if (mirrorLat)
		{
			if (num == 1 || num == 3)
			{
				latAxis = !latAxis;
			}
			else
			{
				longAxis = !longAxis;
			}
		}
		if (mirrorLong)
		{
			if (num == 1 || num == 3)
			{
				longAxis = !longAxis;
			}
			else
			{
				latAxis = !latAxis;
			}
		}
		float result = (longAxis ? area.z : area.x);
		latValueOut = (latAxis ? area.w : area.y);
		return result;
	}

	[HarmonyPatch(typeof(BlueprintUtils), "RefreshBuildPreview")]
	[HarmonyTranspiler]
	private static IEnumerable<CodeInstruction> RefreshPreviews(IEnumerable<CodeInstruction> instructions, ILGenerator generator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, generator);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(Mathf), "FloorToInt"))).Advance(1);
		object operand = codeMatcher.Operand;
		RefreshPreviewsPatchStepReformMirror(codeMatcher, operand);
		RefreshPreviewsPatchStep1(codeMatcher, operand);
		RefreshPreviewsPatchStep2(codeMatcher);
		RefreshPreviewsPatchStep3(codeMatcher);
		RefreshPreviewsPatchStep4(codeMatcher);
		RefreshPreviewsPatchStep3b(codeMatcher);
		RefreshPreviewsPatchStep4b(codeMatcher);
		RefreshPreviewsPatchStep5(codeMatcher);
		return codeMatcher.InstructionEnumeration();
	}

	private static void RefreshPreviewsPatchStepReformMirror(CodeMatcher matcher, object yawCountVar)
	{
		matcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(BPReformRect), "y")));
		while (matcher.Opcode != OpCodes.Stloc_S)
		{
			matcher.Advance(1);
		}
		object operand = matcher.Operand;
		matcher.Advance(1);
		while (matcher.Opcode != OpCodes.Stloc_S)
		{
			matcher.Advance(1);
		}
		object operand2 = matcher.Operand;
		matcher.MatchForward(true, new CodeMatch(OpCodes.Ldelema, typeof(Vector4)), new CodeMatch(OpCodes.Stloc_S), new CodeMatch(OpCodes.Ldloc_S));
		matcher.Advance(-1);
		object operand3 = matcher.Operand;
		matcher.Advance(1);
		object operand4 = matcher.Operand;
		for (int i = 0; i < 2; i++)
		{
			while (matcher.Opcode != OpCodes.Ldfld)
			{
				matcher.RemoveInstruction();
			}
			matcher.RemoveInstruction();
		}
		matcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand3)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand4)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, yawCountVar))
			.InsertAndAdvance(Transpilers.EmitDelegate<MirrorFunc>(MirrorAreaLat));
		matcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloca_S, operand)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloca_S, operand2)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, yawCountVar))
			.InsertAndAdvance(Transpilers.EmitDelegate<RectRefAction>(MirrorReformRect));
		matcher.MatchForward(true, new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch(OpCodes.Stloc_S));
		object operand5 = matcher.Operand;
		matcher.MatchForward(false, new CodeMatch(OpCodes.Ldloc_S, operand5));
		matcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, yawCountVar)).InsertAndAdvance(Transpilers.EmitDelegate<ApplyFunc>(ApplyMirrorLat));
		matcher.MatchForward(false, new CodeMatch(OpCodes.Ldloc_S, operand3)).Advance(-2);
		object operand6 = matcher.Operand;
		for (int j = 0; j < 2; j++)
		{
			while (matcher.Opcode != OpCodes.Ldfld)
			{
				matcher.RemoveInstruction();
			}
			matcher.RemoveInstruction();
		}
		matcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand3)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand6)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, yawCountVar))
			.InsertAndAdvance(Transpilers.EmitDelegate<MirrorFunc>(MirrorAreaLong));
		matcher.MatchForward(true, new CodeMatch(OpCodes.Ldc_I4_0), new CodeMatch(OpCodes.Stloc_S));
		object operand7 = matcher.Operand;
		matcher.MatchForward(false, new CodeMatch(OpCodes.Ldloc_S, operand7));
		matcher.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, yawCountVar)).InsertAndAdvance(Transpilers.EmitDelegate<ApplyFunc>(ApplyMirrorLong));
	}

	private static void RefreshPreviewsPatchStep1(CodeMatcher matcher, object yawCountVar)
	{
		matcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(BuildPreview), "bpgpuiModelId")));
		matcher.MatchForward(true, new CodeMatch(OpCodes.Ldelema, typeof(Vector4)), new CodeMatch(OpCodes.Stloc_S), new CodeMatch(OpCodes.Ldloc_S));
		matcher.Advance(-1);
		object operand = matcher.Operand;
		matcher.Advance(1);
		object operand2 = matcher.Operand;
		for (int i = 0; i < 2; i++)
		{
			while (matcher.Opcode != OpCodes.Ldfld)
			{
				matcher.RemoveInstruction();
			}
			matcher.RemoveInstruction();
		}
		object operand3 = matcher.Operand;
		while (matcher.Opcode != OpCodes.Stloc_S)
		{
			matcher.RemoveInstruction();
		}
		object operand4 = matcher.Operand;
		matcher.RemoveInstruction().InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand2))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, yawCountVar))
			.InsertAndAdvance(Transpilers.EmitDelegate<MirrorFunc>(MirrorAreaLong))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand3))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, yawCountVar))
			.InsertAndAdvance(Transpilers.EmitDelegate<MirrorFunc>(MirrorAreaLat))
			.InsertAndAdvance(new CodeInstruction(OpCodes.Stloc_S, operand4));
	}

	private static void RefreshPreviewsPatchStep2(CodeMatcher matcher)
	{
		matcher.MatchForward(false, new CodeMatch(OpCodes.Call, AccessTools.Method(typeof(BlueprintUtils), "TransitionWidthAndHeight"))).Advance(-3).RemoveInstruction()
			.RemoveInstruction()
			.RemoveInstruction()
			.SetInstruction(Transpilers.EmitDelegate<Func<float, BlueprintBuilding, Vector2>>(delegate(float yaw, BlueprintBuilding building)
			{
				float num = building.localOffset_x;
				float num2 = building.localOffset_y;
				if (((mirrorLat && !mirrorLong) || (!mirrorLat && mirrorLong)) && buildingsOffsets.ContainsKey(building.modelIndex))
				{
					Vector2 v = buildingsOffsets[building.modelIndex];
					float num3 = MirrorBuildingRotation(building.yaw, building);
					v = v.Rotate(num3 + (float)(mirrorLong ? 180 : 0));
					num += v.x;
					num2 += v.y;
				}
				return BlueprintUtils.TransitionWidthAndHeight(yaw, num, num2);
			}));
	}

	private static void RefreshPreviewsPatchStep3(CodeMatcher matcher)
	{
		matcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(BlueprintBuilding), "yaw"))).Advance(-1);
		object operand = matcher.Operand;
		matcher.Advance(2).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand)).InsertAndAdvance(Transpilers.EmitDelegate<Func<float, BlueprintBuilding, float>>(MirrorBuildingRotation))
			.Advance(2);
	}

	private static void RefreshPreviewsPatchStep4(CodeMatcher matcher)
	{
		matcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(BlueprintBuilding), "yaw2"))).Advance(-1);
		object operand = matcher.Operand;
		matcher.Advance(2).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand)).InsertAndAdvance(Transpilers.EmitDelegate<Func<float, BlueprintBuilding, float>>(MirrorBuildingRotation));
	}

	private static void RefreshPreviewsPatchStep3b(CodeMatcher matcher)
	{
		matcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(BlueprintBuilding), "yaw"))).Advance(-1);
		object operand = matcher.Operand;
		matcher.Advance(2).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand)).InsertAndAdvance(Transpilers.EmitDelegate<Func<float, BlueprintBuilding, float>>(MirrorBuildingRotation))
			.Advance(2);
	}

	private static void RefreshPreviewsPatchStep4b(CodeMatcher matcher)
	{
		matcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(BlueprintBuilding), "yaw2"))).Advance(-1);
		object operand = matcher.Operand;
		matcher.Advance(2).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand)).InsertAndAdvance(Transpilers.EmitDelegate<Func<float, BlueprintBuilding, float>>(MirrorBuildingRotation));
	}

	private static void RefreshPreviewsPatchStep5(CodeMatcher matcher)
	{
		matcher.MatchForward(false, new CodeMatch(OpCodes.Ldloc_S), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(BlueprintBuilding), "index")));
		object operand = matcher.Operand;
		matcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(BuildPreview), "desc")), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(PrefabDesc), "isInserter"))).Advance(-1);
		object operand2 = matcher.Operand;
		matcher.Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand2)).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_S, operand))
			.InsertAndAdvance(Transpilers.EmitDelegate<Action<BuildPreview, BlueprintBuilding>>(delegate(BuildPreview preview, BlueprintBuilding building)
			{
				if (mirrorLat || mirrorLong)
				{
					if (preview.desc.isInserter)
					{
						EntityInputsAndOutputs(preview, useSlots: true);
					}
					if (preview.desc.isBelt)
					{
						EntityInputsAndOutputs(preview, useSlots: false);
					}
					if (preview.desc.isStation)
					{
						MirrorStationData(preview, building);
					}
					if (preview.desc.isSplitter)
					{
						MirrorSplitterData(preview, building);
					}
				}
			}));
	}

	public static float MirrorBuildingRotation(float yaw, BlueprintBuilding building)
	{
		if (buildingsAxis.ContainsKey(building.modelIndex) && buildingsAxis[building.modelIndex] == MajorAxis.XAXIS)
		{
			return MirrorRotation(yaw + 90f) - 90f;
		}
		return MirrorRotation(yaw);
	}

	private static Pose[] GetSlotsOrPorts(this PrefabDesc desc, bool useSlots)
	{
		if (!useSlots)
		{
			return desc.portPoses;
		}
		return desc.slotPoses;
	}

	private static void EntityInputsAndOutputs(BuildPreview preview, bool useSlots)
	{
		if (preview.input != null && !preview.input.desc.isBelt && !preview.input.desc.isInserter && preview.inputFromSlot < preview.input.desc.GetSlotsOrPorts(useSlots).Length)
		{
			Quaternion quaternion = Quaternion.Inverse(preview.input.lrot);
			Vector3 vector = preview.lpos - preview.input.lpos;
			vector = quaternion * vector;
			Quaternion value = quaternion * preview.lrot;
			Pose[] slotsOrPorts = preview.input.desc.GetSlotsOrPorts(useSlots);
			for (int i = 0; i < slotsOrPorts.Length; i++)
			{
				Pose pose = slotsOrPorts[i];
				if ((pose.position - vector).sqrMagnitude < 0.1f && pose.rotation.Approximately(value))
				{
					if (preview.inputFromSlot != i)
					{
						preview.inputFromSlot = i;
					}
					break;
				}
			}
		}
		if (preview.output == null || preview.output.desc.isBelt || preview.output.desc.isInserter || preview.outputToSlot >= preview.output.desc.GetSlotsOrPorts(useSlots).Length)
		{
			return;
		}
		Quaternion quaternion2 = Quaternion.Inverse(preview.output.lrot);
		Vector3 vector2 = preview.lpos2 - preview.output.lpos;
		vector2 = quaternion2 * vector2;
		Quaternion value2 = quaternion2 * (preview.lrot2 * Quaternion.Euler(0f, -180f, 0f));
		Pose[] slotsOrPorts2 = preview.output.desc.GetSlotsOrPorts(useSlots);
		for (int j = 0; j < slotsOrPorts2.Length; j++)
		{
			Pose pose2 = slotsOrPorts2[j];
			if ((pose2.position - vector2).sqrMagnitude < 0.1f && pose2.rotation.Approximately(value2))
			{
				if (preview.outputToSlot != j)
				{
					preview.outputToSlot = j;
				}
				break;
			}
		}
	}

	public static Vector2 RotateXZ(Vector3 inVec, float angleRad)
	{
		float x = inVec.x * Mathf.Cos(angleRad) - inVec.z * Mathf.Sin(angleRad);
		float y = inVec.x * Mathf.Sin(angleRad) + inVec.z * Mathf.Cos(angleRad);
		return new Vector2(x, y);
	}

	private static void MirrorStationData(BuildPreview preview, BlueprintBuilding building)
	{
		if (preview.desc.isCollectStation || building.parameters == null || building.parameters.Length == 0 || preview.desc.portPoses == null || building.parameters.Length < 192 + preview.desc.portPoses.Length * 4)
		{
			return;
		}
		if (preview.parameters == null || preview.parameters.Length < building.parameters.Length || preview.parameters == building.parameters)
		{
			preview.parameters = (int[])building.parameters.Clone();
			preview.paramCount = building.parameters.Length;
		}
		if (!mirrorLat && !mirrorLong)
		{
			for (int i = 0; i < preview.desc.portPoses.Length; i++)
			{
				int num = 192 + i * 4;
				preview.parameters[num] = building.parameters[num];
				preview.parameters[num + 1] = building.parameters[num + 1];
			}
			return;
		}
		float target = MirrorBuildingRotation(building.yaw, building);
		float angleRad = building.yaw * (MathF.PI / 180f);
		bool flag = mirrorLat;
		bool flag2 = mirrorLong;
		if (Mathf.Abs(Mathf.DeltaAngle(building.yaw, target)) == 180f)
		{
			flag = !mirrorLat;
			flag2 = !mirrorLong;
		}
		for (int j = 0; j < preview.desc.portPoses.Length; j++)
		{
			Vector2 vector = RotateXZ(preview.desc.portPoses[j].position, angleRad);
			int num2 = 192 + j * 4;
			Vector2 vector2 = new Vector2(flag ? (0f - vector.x) : vector.x, flag2 ? (0f - vector.y) : vector.y);
			for (int k = 0; k < preview.desc.portPoses.Length; k++)
			{
				Vector2 vector3 = RotateXZ(preview.desc.portPoses[k].position, angleRad);
				if ((vector2 - vector3).sqrMagnitude < 0.1f)
				{
					int num3 = 192 + k * 4;
					preview.parameters[num2] = building.parameters[num3];
					preview.parameters[num2 + 1] = building.parameters[num3 + 1];
					break;
				}
			}
		}
	}

	private static void MirrorSplitterData(BuildPreview preview, BlueprintBuilding building)
	{
		if (building.parameters == null || building.parameters.Length == 0 || preview.desc.portPoses == null || building.parameters.Length < preview.desc.portPoses.Length)
		{
			return;
		}
		if (preview.parameters == null || preview.parameters.Length < building.parameters.Length || preview.parameters == building.parameters)
		{
			preview.parameters = (int[])building.parameters.Clone();
			preview.paramCount = building.parameters.Length;
		}
		float target = MirrorBuildingRotation(building.yaw, building);
		float angleRad = building.yaw * (MathF.PI / 180f);
		bool flag = mirrorLat;
		bool flag2 = mirrorLong;
		if (Mathf.Abs(Mathf.DeltaAngle(building.yaw, target)) == 180f)
		{
			flag = !mirrorLat;
			flag2 = !mirrorLong;
		}
		for (int i = 0; i < preview.desc.portPoses.Length; i++)
		{
			Vector2 vector = RotateXZ(preview.desc.portPoses[i].position, angleRad);
			Vector2 vector2 = new Vector2(flag ? (0f - vector.x) : vector.x, flag2 ? (0f - vector.y) : vector.y);
			for (int j = 0; j < preview.desc.portPoses.Length; j++)
			{
				Vector2 vector3 = RotateXZ(preview.desc.portPoses[j].position, angleRad);
				if ((vector2 - vector3).sqrMagnitude < 0.1f)
				{
					preview.parameters[i] = building.parameters[j];
					break;
				}
			}
		}
	}
}
