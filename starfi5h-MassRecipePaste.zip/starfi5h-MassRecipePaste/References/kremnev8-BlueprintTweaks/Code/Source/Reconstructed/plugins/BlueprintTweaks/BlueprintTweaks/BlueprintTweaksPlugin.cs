using System.Collections.Generic;
using System.IO;
using System.Reflection;
using BepInEx;
using BepInEx.Bootstrap;
using BepInEx.Configuration;
using BepInEx.Logging;
using BlueprintTweaks.BlueprintBrowserUIChanges;
using BlueprintTweaks.BlueprintDataSaveEdit;
using BlueprintTweaks.BrowserRememberFolder;
using BlueprintTweaks.DragToMoveBlueprints;
using BlueprintTweaks.FactoryUndo;
using BlueprintTweaks.GlobalPatch;
using BlueprintTweaks.KeepBPName;
using BlueprintTweaks.Patches;
using CommonAPI;
using CommonAPI.Systems;
using CommonAPI.Systems.ModLocalization;
using HarmonyLib;
using NebulaAPI;
using NebulaAPI.Interfaces;

namespace BlueprintTweaks;

[BepInPlugin("org.kremnev8.plugin.BlueprintTweaks", "Blueprint Tweaks", "1.6.14")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "CustomKeyBindSystem", "PickerExtensionsSystem", "LocalizationModule" })]
public class BlueprintTweaksPlugin : BaseUnityPlugin, IMultiplayerMod
{
	public const string MODNAME = "BlueprintTweaks";

	public const string MODGUID = "org.kremnev8.plugin.BlueprintTweaks";

	public const string MOD_DISP_NAME = "Blueprint Tweaks";

	public const string VERSION = "1.6.14";

	public const string GENESIS_BOOK_MODGUID = "org.LoShin.GenesisBook";

	public const string DRAG_REMOVE = "DragRemove";

	public const string PASTE_LOCKED = "PasteLocked";

	public const string FACTORY_UNDO = "FactoryUndo";

	public static ManualLogSource logger;

	public static ResourceData resource;

	internal static ConfigFile configFile;

	private static Harmony harmony;

	public static DragRemoveBuildTool tool;

	public static bool gotPluginInfo;

	public static bool genesisBookIsInstalled;

	public static ConfigEntry<bool> cameraToggleEnabled;

	public static ConfigEntry<bool> addPasteButtonEnabled;

	public static ConfigEntry<bool> recipeChangeEnabled;

	public static ConfigEntry<bool> changeTierEnabled;

	public static ConfigEntry<bool> logisticCargoChangeEnabled;

	public static ConfigEntry<bool> beltHintsChangeEnable;

	public static ConfigEntry<bool> keepBlueprintDesc;

	public static ConfigEntry<bool> keepBrowserPath;

	public static ConfigEntry<bool> forcePasteEnabled;

	public static ConfigEntry<bool> axisLockEnabled;

	public static ConfigEntry<bool> gridControlFeature;

	public static ConfigEntry<bool> blueprintMirroring;

	public static ConfigEntry<bool> dragRemove;

	public static ConfigEntry<bool> pasteLocked;

	public static ConfigEntry<bool> moveWithDragNDrop;

	public static ConfigEntry<bool> factoryUndo;

	public static ConfigEntry<bool> resetFunctionsOnMenuExit;

	public static ConfigEntry<bool> canBlueprintOnGasGiants;

	public static ConfigEntry<bool> excludeStations;

	public static ConfigEntry<bool> undoExcludeStations;

	public static ConfigEntry<int> undoMaxHistory;

	public static ConfigEntry<bool> showUndoClearedMessage;

	private static bool appliedBlueprintDataPatch = false;

	internal static List<PressKeyBind> modKeybinds = new List<PressKeyBind>();

	public string Version => "1.6.14";

	private void Awake()
	{
		//IL_0042: Unknown result type (might be due to invalid IL or missing references)
		//IL_004c: Expected O, but got Unknown
		logger = base.Logger;
		configFile = base.Config;
		LoadConfigs();
		base.Config.Save();
		string directoryName = Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location);
		resource = new ResourceData("BlueprintTweaks", "blueprinttweaks", directoryName);
		resource.LoadAssetBundle("blueprinttweaks");
		ProtoRegistry.AddResource(resource);
		LocalizationModule.LoadTranslationsFromFolder(Path.Combine(directoryName, "Locale"));
		harmony = new Harmony("org.kremnev8.plugin.BlueprintTweaks");
		if (factoryUndo.Value)
		{
			UndoManager.Init();
		}
		UIBlueprintInspectorPatch.Init();
		BlueprintUtilsPatch2.Init();
		RegisterKeyBinds();
		NebulaModAPI.RegisterPackets(Assembly.GetExecutingAssembly());
		if (factoryUndo.Value)
		{
			HarmonyRegisterExtension.PatchAll(harmony, "FactoryUndo");
		}
		if (keepBrowserPath.Value)
		{
			harmony.PatchAll(typeof(BlueprintTweaks.BrowserRememberFolder.UIBlueprintBrowser_Patch));
		}
		if (moveWithDragNDrop.Value)
		{
			harmony.PatchAll(typeof(BuildTool_Copy_Patch));
			harmony.PatchAll(typeof(BlueprintTweaks.DragToMoveBlueprints.UIBlueprintBrowser_Patch));
		}
		if (keepBlueprintDesc.Value)
		{
			harmony.PatchAll(typeof(BlueprintTweaks.KeepBPName.UIBlueprintInspectorPatch));
		}
		if (pasteLocked.Value)
		{
			HarmonyRegisterExtension.PatchAll(harmony, "PasteLocked");
		}
		if (addPasteButtonEnabled.Value)
		{
			harmony.PatchAll(typeof(UIBlueprintBrowserPatch));
		}
		if (blueprintMirroring.Value)
		{
			harmony.PatchAll(typeof(BlueprintUtilsPatch2));
		}
		if (dragRemove.Value)
		{
			HarmonyRegisterExtension.PatchAll(harmony, "DragRemove");
		}
		if (changeTierEnabled.Value)
		{
			harmony.PatchAll(typeof(UIBlueprintComponentItemPatch));
		}
		if (canBlueprintOnGasGiants.Value)
		{
			harmony.PatchAll(typeof(PlayerControllerPatch));
			harmony.PatchAll(typeof(BuildTool_BlueprintPastePatch));
		}
		if (axisLockEnabled.Value || gridControlFeature.Value)
		{
			harmony.PatchAll(typeof(GridSnappingPatches));
			harmony.PatchAll(typeof(BuildTool_BlueprintPaste_Patch));
			ApplyBlueprintDataPatch();
		}
		if (cameraToggleEnabled.Value)
		{
			harmony.PatchAll(typeof(CameraFixPatch));
		}
		if (recipeChangeEnabled.Value || gridControlFeature.Value)
		{
			harmony.PatchAll(typeof(UIBlueprintInspectorPatch));
		}
		_ = forcePasteEnabled.Value;
		harmony.PatchAll(typeof(BuildTool_BlueprintPaste_Patch_3));
		logger.LogInfo("Blueprint tweaks mod is initialized!");
	}

	private void LoadConfigs()
	{
		cameraToggleEnabled = base.Config.Bind("Interface", "cameraToggle", defaultValue: true, "Allows toggling camera between 3rd person and god view\nAll values are applied on restart");
		addPasteButtonEnabled = base.Config.Bind("Interface", "addBluprintPasteButton", defaultValue: true, "If enabled new button will be added to Blueprint Browser. Pressing it will paste curretly selected blueprint\nAll values are applied on restart");
		recipeChangeEnabled = base.Config.Bind("Interface", "recipeChange", defaultValue: true, "Add recipe change panel to blueprint inspectors\nAll values are applied on restart");
		logisticCargoChangeEnabled = base.Config.Bind("Interface", "changeLogisticCargo", defaultValue: true, "Allows changing cargo requested/provided by logistic stations");
		changeTierEnabled = base.Config.Bind("Interface", "changeTier", defaultValue: true, "Allows using change tier functionality\nAll values are applied on restart");
		beltHintsChangeEnable = base.Config.Bind("Interface", "beltHintChange", defaultValue: true, "Add belt hint change panel to blueprint inspectors\nAll values are applied on restart");
		keepBlueprintDesc = base.Config.Bind("Interface", "keepBlueprintDescription", defaultValue: true, "When pasting blueprint string into existing blueprint you can hold shift to keep description and icons");
		keepBrowserPath = base.Config.Bind("Interface", "keepBroserPath", defaultValue: true, "Preserve last open Blueprint Browser directory. Also when creating new blueprints, they will be saved in the last open directory");
		forcePasteEnabled = base.Config.Bind("Features", "forcePaste", defaultValue: true, "Allow to force paste using Shift+Click");
		axisLockEnabled = base.Config.Bind("Features", "axisLock", defaultValue: true, "Allows using Latitude/Longtitude axis locks\nAll values are applied on restart");
		gridControlFeature = base.Config.Bind("Features", "gridControl", defaultValue: true, "Allows changing grid size and its offset\nAll values are applied on restart");
		blueprintMirroring = base.Config.Bind("Features", "blueprintMirroring", defaultValue: true, "Allows mirroring Blueprints\nAll values are applied on restart");
		dragRemove = base.Config.Bind("Features", "dragRemove", defaultValue: true, "Allows using drag remove function\nAll values are applied on restart");
		pasteLocked = base.Config.Bind("Features", "PasteLockedRecipes", defaultValue: true, "Allow pasting assemblers with recipes which have not been unlocked yet. Assemblers with recipes that are not unlocked will not work.");
		moveWithDragNDrop = base.Config.Bind("Features", "moveBPWithDragNDrop", defaultValue: true, "Allow moving blueprints using drag and drop");
		factoryUndo = base.Config.Bind("Features", "factoryUndo", defaultValue: true, "Enable Factory Undo feature. Allows to undo/redo most building actions. Will force dragRemove to true");
		resetFunctionsOnMenuExit = base.Config.Bind("Misc", "resetOnExit", defaultValue: true, "If enabled when you exit build mode, some functions (Axis/Grid lock, Mirror) will reset their state");
		canBlueprintOnGasGiants = base.Config.Bind("Misc", "bpOnGasGiants", defaultValue: true, "Allow using Blueprints on Gas Giants\nAll values are applied on restart");
		excludeStations = base.Config.Bind("Misc", "excludeStations", defaultValue: true, "When using drag remove tool, logistic stations (and miners Mk.II) will not get removed. This is a safeguard against errors which occur most of the time when you try to mass dismantle logistic stations.");
		undoMaxHistory = base.Config.Bind("Misc", "undoMaxHistory", 50, "Defines undo history size. When history reaches it's capacity, old entries will get removed. When using Nebula host controls the used value");
		undoExcludeStations = base.Config.Bind("Misc", "undoExcludeStations", defaultValue: true, "When enabled factory undo will not undo/redo actions with logistic stations.");
		showUndoClearedMessage = base.Config.Bind("Misc", "showUndoClearedMessage", defaultValue: true, "Should a message informing you that undo history has been cleared be shown whenever you leave a planet?");
		ConfigFileExtension.MigrateConfig<bool>(base.Config, "General", "Interface", new string[4] { "cameraToggle", "recipeChange", "changeLogisticCargo", "changeTier" });
		ConfigFileExtension.MigrateConfig<bool>(base.Config, "General", "Features", new string[5] { "forcePaste", "axisLock", "gridControl", "gridControl", "blueprintFoundations" });
		ConfigFileExtension.MigrateConfig<bool>(base.Config, "General", "Misc", new string[1] { "bpOnGasGiants" });
		if (factoryUndo.Value)
		{
			dragRemove.Value = true;
		}
	}

	private static void RegisterKeyBinds()
	{
		if (cameraToggleEnabled.Value)
		{
			modKeybinds.Add(CustomKeyBindSystem.RegisterKeyBindWithReturn<PressKeyBind>(new BuiltinKey
			{
				key = new CombineKey(106, 0, ECombineKeyAction.OnceClick, _noneKey: false),
				conflictGroup = 3071,
				name = "ToggleBPGodModeDesc",
				canOverride = true
			}));
		}
		if (forcePasteEnabled.Value)
		{
			modKeybinds.Add((PressKeyBind)(object)CustomKeyBindSystem.RegisterKeyBindWithReturn<HoldKeyBind>(new BuiltinKey
			{
				key = new CombineKey(0, 1, ECombineKeyAction.OnceClick, _noneKey: false),
				conflictGroup = 2052,
				name = "ForceBPPlace",
				canOverride = true
			}));
		}
		if (axisLockEnabled.Value)
		{
			modKeybinds.Add(CustomKeyBindSystem.RegisterKeyBindWithReturn<PressKeyBind>(new BuiltinKey
			{
				key = new CombineKey(103, 2, ECombineKeyAction.OnceClick, _noneKey: false),
				conflictGroup = 2052,
				name = "LockLongAxis",
				canOverride = true
			}));
			modKeybinds.Add(CustomKeyBindSystem.RegisterKeyBindWithReturn<PressKeyBind>(new BuiltinKey
			{
				key = new CombineKey(116, 2, ECombineKeyAction.OnceClick, _noneKey: false),
				conflictGroup = 2052,
				name = "LockLatAxis",
				canOverride = true
			}));
		}
		if (gridControlFeature.Value)
		{
			modKeybinds.Add(CustomKeyBindSystem.RegisterKeyBindWithReturn<PressKeyBind>(new BuiltinKey
			{
				key = new CombineKey(98, 2, ECombineKeyAction.OnceClick, _noneKey: false),
				conflictGroup = 2052,
				name = "SetLocalOffset",
				canOverride = true
			}));
		}
		if (blueprintMirroring.Value)
		{
			modKeybinds.Add(CustomKeyBindSystem.RegisterKeyBindWithReturn<PressKeyBind>(new BuiltinKey
			{
				key = new CombineKey(103, 1, ECombineKeyAction.OnceClick, _noneKey: false),
				conflictGroup = 2052,
				name = "MirrorLongAxis",
				canOverride = true
			}));
			modKeybinds.Add(CustomKeyBindSystem.RegisterKeyBindWithReturn<PressKeyBind>(new BuiltinKey
			{
				key = new CombineKey(116, 1, ECombineKeyAction.OnceClick, _noneKey: false),
				conflictGroup = 2052,
				name = "MirrorLatAxis",
				canOverride = true
			}));
		}
		if (factoryUndo.Value)
		{
			CustomKeyBindSystem.RegisterKeyBind<PressKeyBind>(new BuiltinKey
			{
				key = new CombineKey(122, 2, ECombineKeyAction.OnceClick, _noneKey: false),
				conflictGroup = 2052,
				name = "FactoryUndo",
				canOverride = true
			});
			CustomKeyBindSystem.RegisterKeyBind<PressKeyBind>(new BuiltinKey
			{
				key = new CombineKey(122, 1, ECombineKeyAction.OnceClick, _noneKey: false),
				conflictGroup = 2052,
				name = "FactoryRedo",
				canOverride = true
			});
		}
	}

	private void Update()
	{
		if (!gotPluginInfo)
		{
			if (Chainloader.PluginInfos.ContainsKey("org.LoShin.GenesisBook"))
			{
				genesisBookIsInstalled = true;
			}
			gotPluginInfo = true;
		}
		if (!GameMain.isRunning || GameMain.localPlanet == null)
		{
			return;
		}
		if (factoryUndo.Value)
		{
			if (CustomKeyBindSystem.GetKeyBind("FactoryUndo").keyValue)
			{
				UndoManager.TryUndo();
			}
			if (CustomKeyBindSystem.GetKeyBind("FactoryRedo").keyValue)
			{
				UndoManager.TryRedo();
			}
		}
		if (cameraToggleEnabled.Value && CustomKeyBindSystem.GetKeyBind("ToggleBPGodModeDesc").keyValue)
		{
			CameraFixPatch.mode = !CameraFixPatch.mode;
		}
		if (axisLockEnabled.Value && CustomKeyBindSystem.GetKeyBind("LockLongAxis").keyValue)
		{
			GridSnappingPatches.LockLongitude();
		}
		if (axisLockEnabled.Value && CustomKeyBindSystem.GetKeyBind("LockLatAxis").keyValue)
		{
			GridSnappingPatches.LockLatitude();
		}
		if (gridControlFeature.Value && CustomKeyBindSystem.GetKeyBind("SetLocalOffset").keyValue)
		{
			GridSnappingPatches.SetOffset();
		}
		_ = forcePasteEnabled.Value;
		if (blueprintMirroring.Value && CustomKeyBindSystem.GetKeyBind("MirrorLongAxis").keyValue)
		{
			BlueprintUtilsPatch2.mirrorLong = !BlueprintUtilsPatch2.mirrorLong;
			BlueprintUtilsPatch2.UpdateBlueprintDisplay();
		}
		if (blueprintMirroring.Value && CustomKeyBindSystem.GetKeyBind("MirrorLatAxis").keyValue)
		{
			BlueprintUtilsPatch2.mirrorLat = !BlueprintUtilsPatch2.mirrorLat;
			BlueprintUtilsPatch2.UpdateBlueprintDisplay();
		}
	}

	public static void RegisterCustomBlueprintDataSerializer<T>(string key) where T : ICustomBlueprintDataSerializer, new()
	{
		ApplyBlueprintDataPatch();
		if (BlueprintData_Patch_2.customSerializers.ContainsKey(key))
		{
			logger.LogError("Failed to register custom blueprint data serializer with key '" + key + "' and type " + typeof(T).FullName + ", because the key has been already taken!");
		}
		else
		{
			T val = new T();
			BlueprintData_Patch_2.customSerializers.Add(key, val);
			logger.LogInfo("Registered custom blueprint data serializer with key '" + key + "'");
		}
	}

	private static void ApplyBlueprintDataPatch()
	{
		if (!appliedBlueprintDataPatch)
		{
			harmony.PatchAll(typeof(BlueprintData_Patch_2));
			appliedBlueprintDataPatch = true;
		}
	}

	public bool CheckVersion(string hostVersion, string clientVersion)
	{
		return hostVersion.Equals(clientVersion);
	}
}
