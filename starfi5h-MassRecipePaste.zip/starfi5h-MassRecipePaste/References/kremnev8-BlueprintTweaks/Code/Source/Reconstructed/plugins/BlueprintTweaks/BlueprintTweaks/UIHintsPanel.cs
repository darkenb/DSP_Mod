using System.Collections.Generic;
using System.Linq;
using UnityEngine;

namespace BlueprintTweaks;

public class UIHintsPanel : UIBlueprintPanel
{
	public List<UIHintItem> hintsItems = new List<UIHintItem>();

	public List<HintData> tmpHintList = new List<HintData>();

	public int hintsCount;

	public UIHintItem prefab;

	public override int verticalSize
	{
		get
		{
			if (hintsCount == 0)
			{
				return 22;
			}
			return 22 + ((hintsCount - 1) / 8 + 1) * 46;
		}
	}

	public override void OnUpdate()
	{
		tmpHintList.Clear();
		BlueprintBuilding[] buildings = inspector.blueprint.buildings;
		foreach (BlueprintBuilding blueprintBuilding in buildings)
		{
			int itemId = blueprintBuilding.itemId;
			ItemProto itemProto = LDB.items.Select(itemId);
			if (itemProto == null || !itemProto.prefabDesc.isBelt || blueprintBuilding.parameters == null || blueprintBuilding.parameters.Length < 1)
			{
				continue;
			}
			int signalId = blueprintBuilding.parameters[0];
			if (signalId != 0)
			{
				int count = 0;
				if (blueprintBuilding.parameters.Length >= 2)
				{
					count = blueprintBuilding.parameters[1];
				}
				if (!tmpHintList.Any((HintData data) => data.signalId == signalId && data.value == count))
				{
					tmpHintList.Add(new HintData(signalId, count));
				}
			}
		}
		int num = 0;
		foreach (HintData tmpHint in tmpHintList)
		{
			SetItem(num, tmpHint);
			num++;
		}
		ClearComponentItems(num);
	}

	public void SetItem(int index, HintData itemId)
	{
		if (index >= 0 && index <= 256)
		{
			while (index >= hintsItems.Count)
			{
				UIHintItem uIHintItem = Object.Instantiate(prefab, prefab.transform.parent);
				uIHintItem.Create(this);
				hintsItems.Add(uIHintItem);
			}
			hintsItems[index].SetDisplay(index, itemId);
			hintsItems[index].Open();
		}
	}

	public void ClearComponentItems(int activeCount = 0)
	{
		for (int i = activeCount; i < hintsItems.Count; i++)
		{
			hintsItems[i].Close();
		}
		hintsCount = activeCount;
	}

	public void ChangeHint(int oldSignalId, HintData newSignal)
	{
		BlueprintBuilding[] buildings = inspector.blueprint.buildings;
		foreach (BlueprintBuilding blueprintBuilding in buildings)
		{
			int itemId = blueprintBuilding.itemId;
			if (LDB.items.Select(itemId).prefabDesc.isBelt && blueprintBuilding.parameters != null && blueprintBuilding.parameters.Length >= 1 && blueprintBuilding.parameters[0] == oldSignalId)
			{
				blueprintBuilding.parameters[0] = newSignal.signalId;
				if (blueprintBuilding.parameters.Length >= 2)
				{
					blueprintBuilding.parameters[1] = newSignal.value;
				}
				else if (newSignal.value != 0)
				{
					blueprintBuilding.parameters = new int[2] { newSignal.signalId, newSignal.value };
				}
			}
		}
		if (inspector.usage == UIBlueprintInspector.EUsage.Paste)
		{
			inspector.pasteBuildTool.ResetStates();
		}
		inspector.Refresh(forModify: true, refreshComponent: true, refreshCode: true);
	}
}
