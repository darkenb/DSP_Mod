using System.IO;
using System.Reflection;
using BepInEx;
using BepInEx.Bootstrap;
using HarmonyLib;

namespace BlueprintTweaks.InstallCheck;

[BepInPlugin("org.kremnev8.plugin.BlueprintTweaksInstallCheck", "Blueprint Tweaks Installation Checker", "1.6.14")]
public class InstallationChecker : BaseUnityPlugin
{
	public const string MODNAME = "Blueprint Tweaks Installation Checker";

	public const string MODGUID = "org.kremnev8.plugin.BlueprintTweaksInstallCheck";

	public const string LDBTOOLGUID = "me.xiaoye97.plugin.Dyson.LDBTool";

	public static bool preloaderInstalled;

	public static bool ldbToolInstalled;

	public static bool nebulaAPIInstalled;

	public static bool assetBundleFound;

	public static bool installationIsValid;

	private void Awake()
	{
		preloaderInstalled = AccessTools.TypeByName("BlueprintData").GetField("anchorType") != null;
		if (Chainloader.PluginInfos.ContainsKey("me.xiaoye97.plugin.Dyson.LDBTool"))
		{
			ldbToolInstalled = true;
		}
		if (Chainloader.PluginInfos.ContainsKey("dsp.nebula-multiplayer-api"))
		{
			nebulaAPIInstalled = true;
		}
		assetBundleFound = File.Exists(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location) + "/blueprinttweaks");
		installationIsValid = preloaderInstalled && ldbToolInstalled && nebulaAPIInstalled && assetBundleFound;
		Harmony.CreateAndPatchAll(typeof(UIMainMenuPatch));
		if (installationIsValid)
		{
			base.Logger.LogInfo("Check successful. Installation is correct!");
		}
		else
		{
			base.Logger.LogInfo("Check failed. Mod is installed incorrectly!");
		}
	}
}
