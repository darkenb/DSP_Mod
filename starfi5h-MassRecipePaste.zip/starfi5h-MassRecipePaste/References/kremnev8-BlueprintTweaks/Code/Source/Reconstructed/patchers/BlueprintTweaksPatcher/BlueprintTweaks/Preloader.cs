using System;
using System.Collections.Generic;
using System.Linq;
using BepInEx.Logging;
using Mono.Cecil;

namespace BlueprintTweaks;

public static class Preloader
{
	public static ManualLogSource logSource;

	public static IEnumerable<string> TargetDLLs { get; } = new string[1] { "Assembly-CSharp.dll" };

	public static void Initialize()
	{
		logSource = Logger.CreateLogSource("BlueprintTweaks Preloader");
	}

	public static MethodReference DefaultCtorFor(TypeReference type)
	{
		TypeDefinition typeDefinition = type.Resolve();
		if (typeDefinition == null)
		{
			return null;
		}
		MethodDefinition methodDefinition = typeDefinition.Methods.SingleOrDefault((MethodDefinition m) => m.IsConstructor && m.Parameters.Count == 0 && !m.IsStatic);
		if (methodDefinition == null)
		{
			return DefaultCtorFor(typeDefinition.BaseType);
		}
		return new MethodReference(".ctor", type.Module.TypeSystem.Void, type)
		{
			HasThis = true
		};
	}

	public static void Patch(AssemblyDefinition assembly)
	{
		try
		{
			ModuleDefinition mainModule = assembly.MainModule;
			TypeDefinition typeDefinition = mainModule.Types.First((TypeDefinition t) => t.FullName == "BlueprintData");
			TypeDefinition typeDefinition2 = mainModule.Types.First((TypeDefinition t) => t.FullName == "AssemblerComponent");
			TypeDefinition typeDefinition3 = mainModule.Types.First((TypeDefinition t) => t.FullName == "LabComponent");
			typeDefinition.Fields.Add(new FieldDefinition("anchorType", FieldAttributes.Public, mainModule.ImportReference(typeof(int))));
			typeDefinition.Fields.Add(new FieldDefinition("autoReformMode", FieldAttributes.Public, mainModule.ImportReference(typeof(int))));
			typeDefinition2.Fields.Add(new FieldDefinition("recipeIsLocked", FieldAttributes.Public, mainModule.ImportReference(typeof(bool))));
			typeDefinition3.Fields.Add(new FieldDefinition("recipeIsLocked", FieldAttributes.Public, mainModule.ImportReference(typeof(bool))));
			logSource.LogInfo("Preloader patching is successful!");
		}
		catch (Exception)
		{
			logSource.LogError("Preloader patching failed!");
			throw;
		}
	}
}
