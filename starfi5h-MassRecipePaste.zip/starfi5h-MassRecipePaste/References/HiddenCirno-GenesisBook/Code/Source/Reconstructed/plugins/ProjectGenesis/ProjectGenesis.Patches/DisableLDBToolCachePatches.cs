using System.IO;
using BepInEx;
using HarmonyLib;
using xiaoye97;

namespace ProjectGenesis.Patches;

public static class DisableLDBToolCachePatches
{
	private static bool _finished;

	[HarmonyPatch(typeof(LDBTool), "Bind")]
	[HarmonyPriority(700)]
	[HarmonyPrefix]
	public static bool LDBTool_Bind()
	{
		return ProjectGenesis.LDBToolCacheEntry.Value;
	}

	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	[HarmonyAfter(new string[] { "me.xiaoye97.plugin.Dyson.LDBTool" })]
	[HarmonyPostfix]
	public static void DeleteFiles()
	{
		if (_finished || !ProjectGenesis.LDBToolCacheEntry.Value)
		{
			return;
		}
		try
		{
			string path = Path.Combine(Paths.ConfigPath, "LDBTool");
			if (Directory.Exists(path))
			{
				Directory.Delete(path, recursive: true);
			}
		}
		catch
		{
		}
		_finished = true;
	}
}
