using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.IO;
using System.Reflection.Emit;
using System.Threading;
using HarmonyLib;
using ProjectGenesis.Utils;
using UnityEngine;
using UnityEngine.UI;

namespace ProjectGenesis.Patches;

public static class QuantumStoragePatches
{
	private const int QuantumStorageSize = 80;

	private static StorageComponent[] _components;

	private static readonly ConcurrentDictionary<int, List<QuantumStorageData>> QuantumStorageIds;

	private static readonly Mutex QuantumStorageMutex;

	private static UIOrbitPicker orbitPicker;

	[HarmonyPatch(typeof(BuildingParameters), "ApplyPrebuildParametersToEntity")]
	[HarmonyPrefix]
	public static bool BuildingParameters_ApplyPrebuildParametersToEntity_Prefix(int entityId, int[] parameters, PlanetFactory factory)
	{
		if (entityId <= 0 || factory.entityPool[entityId].id != entityId)
		{
			return false;
		}
		int storageId = factory.entityPool[entityId].storageId;
		if (storageId == 0)
		{
			return true;
		}
		if (parameters == null || parameters.Length <= 2)
		{
			return false;
		}
		if (factory.factoryStorage.storagePool[storageId].size == 80)
		{
			QuantumStorageOrbitChange(factory.planetId, storageId, parameters[2]);
		}
		return true;
	}

	[HarmonyPatch(typeof(BuildingParameters), "FromParamsArray")]
	[HarmonyPostfix]
	public static void BuildingParameters_FromParamsArray(ref BuildingParameters __instance, int[] _parameters)
	{
		if (__instance.type == BuildingType.Storage && _parameters != null)
		{
			__instance.mode2 = _parameters[2];
		}
	}

	[HarmonyPatch(typeof(BuildingParameters), "ToParamsArray")]
	[HarmonyPostfix]
	public static void BuildingParameters_ToParamsArray(ref BuildingParameters __instance, ref int[] _parameters, ref int _paramCount)
	{
		if (__instance.type == BuildingType.Storage && _parameters != null)
		{
			_parameters[2] = __instance.mode2;
		}
	}

	[HarmonyPatch(typeof(BuildingParameters), "CopyFromFactoryObject")]
	[HarmonyPostfix]
	public static void BuildingParameters_CopyFromFactoryObject_Postfix(ref BuildingParameters __instance, int objectId, PlanetFactory factory)
	{
		if (__instance.type == BuildingType.Storage && objectId > 0 && factory.entityPool[objectId].id == objectId)
		{
			int storageId = factory.entityPool[objectId].storageId;
			if (storageId != 0 && factory.factoryStorage.storagePool[storageId].size == 80)
			{
				__instance.mode2 = QueryOrbitId(factory.planetId, storageId);
			}
		}
	}

	[HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
	[HarmonyPrefix]
	public static bool BuildingParameters_PasteToFactoryObject_Prefix(ref BuildingParameters __instance, int objectId, PlanetFactory factory)
	{
		if (__instance.type != BuildingType.Storage)
		{
			return true;
		}
		if (objectId <= 0 || factory.entityPool[objectId].id != objectId)
		{
			return false;
		}
		int storageId = factory.entityPool[objectId].storageId;
		if (storageId == 0)
		{
			return true;
		}
		if (factory.factoryStorage.storagePool[storageId].size == 80)
		{
			QuantumStorageOrbitChange(factory.planetId, storageId, __instance.mode2);
		}
		return true;
	}

	static QuantumStoragePatches()
	{
		QuantumStorageMutex = new Mutex(-1);
		QuantumStorageIds = new ConcurrentDictionary<int, List<QuantumStorageData>>();
		_components = new StorageComponent[10];
		for (int i = 0; i < _components.Length; i++)
		{
			ref StorageComponent reference = ref _components[i];
			reference = new StorageComponent(80);
			reference.CutNext();
		}
	}

	private static void QuantumStorageOrbitChange(int planetId, int storageId, int orbitId)
	{
		if (QuantumStorageIds.TryGetValue(planetId, out var value))
		{
			int num = value.FindIndex((QuantumStorageData i) => i.StorageId == storageId);
			if (num >= 0)
			{
				value[num] = new QuantumStorageData(storageId, orbitId);
				PlanetData planet = GameMain.galaxy.PlanetById(planetId);
				GameMain.data.GetOrCreateFactory(planet).factoryStorage.storagePool[storageId] = _components[orbitId - 1];
			}
		}
	}

	internal static void SyncNewQuantumStorage(int planetId, int storageId, int orbitId)
	{
		QuantumStorageIds.TryAddOrInsert(planetId, new QuantumStorageData(storageId, orbitId));
		PlanetData planet = GameMain.galaxy.PlanetById(planetId);
		GameMain.data.GetOrCreateFactory(planet).factoryStorage.storagePool[storageId] = _components[orbitId - 1];
	}

	internal static void SyncRemoveQuantumStorage(int planetId, int storageId, int orbitId)
	{
		QuantumStorageIds.TryRemove(planetId, new QuantumStorageData(storageId, orbitId));
	}

	internal static void SyncQuantumStorageOrbitChange(int planetId, int storageId, int orbitId)
	{
		QuantumStorageOrbitChange(planetId, storageId, orbitId);
	}

	internal static void ExportPlanetQuantumStorage(int planetId, BinaryWriter w)
	{
		if (!QuantumStorageIds.ContainsKey(planetId))
		{
			QuantumStorageIds[planetId] = new List<QuantumStorageData>();
		}
		List<QuantumStorageData> list = QuantumStorageIds[planetId];
		w.Write(list.Count);
		w.Write(planetId);
		foreach (QuantumStorageData item in list)
		{
			w.Write(item.StorageId);
			w.Write(item.OrbitId);
		}
	}

	internal static void ImportPlanetQuantumStorage(BinaryReader r)
	{
		int num = r.ReadInt32();
		int key = r.ReadInt32();
		QuantumStorageData[] array = new QuantumStorageData[num];
		for (int i = 0; i < num; i++)
		{
			array[i] = new QuantumStorageData(r.ReadInt32(), r.ReadInt32());
		}
		QuantumStorageIds[key] = new List<QuantumStorageData>(array);
	}

	private static int QueryOrbitId(int planetId, int storageId)
	{
		if (!QuantumStorageIds.TryGetValue(planetId, out var value))
		{
			return -1;
		}
		int num = value.FindIndex((QuantumStorageData i) => i.StorageId == storageId);
		if (num < 0)
		{
			return -1;
		}
		return value[num].OrbitId;
	}

	internal static void Export(BinaryWriter w)
	{
		lock (QuantumStorageIds)
		{
			w.Write(QuantumStorageIds.Count);
			foreach (KeyValuePair<int, List<QuantumStorageData>> quantumStorageId in QuantumStorageIds)
			{
				w.Write(quantumStorageId.Key);
				w.Write(quantumStorageId.Value.Count);
				foreach (QuantumStorageData item in quantumStorageId.Value)
				{
					w.Write(item.StorageId);
					w.Write(item.OrbitId);
				}
			}
		}
		lock (_components)
		{
			StorageComponent[] components = _components;
			for (int i = 0; i < components.Length; i++)
			{
				components[i].Export(w);
			}
		}
	}

	internal static void Import(BinaryReader r)
	{
		ReInitAll();
		try
		{
			int num = r.ReadInt32();
			for (int i = 0; i < num; i++)
			{
				int key = r.ReadInt32();
				int num2 = r.ReadInt32();
				List<QuantumStorageData> list = new List<QuantumStorageData>();
				for (int j = 0; j < num2; j++)
				{
					list.Add(new QuantumStorageData(r.ReadInt32(), r.ReadInt32()));
				}
				QuantumStorageIds.TryAdd(key, list);
			}
			StorageComponent[] components = _components;
			for (int k = 0; k < components.Length; k++)
			{
				components[k].Import(r);
			}
		}
		catch (EndOfStreamException)
		{
		}
	}

	internal static void IntoOtherSave()
	{
		ReInitAll();
	}

	private static void ReInitAll()
	{
		QuantumStorageIds.Clear();
		_components = new StorageComponent[10];
		for (int i = 0; i < _components.Length; i++)
		{
			ref StorageComponent reference = ref _components[i];
			reference = new StorageComponent(80);
			reference.CutNext();
		}
	}

	[HarmonyPatch(typeof(StorageComponent), "TakeTailItems", new Type[]
	{
		typeof(int),
		typeof(int),
		typeof(int),
		typeof(bool)
	}, new ArgumentType[]
	{
		ArgumentType.Ref,
		ArgumentType.Ref,
		ArgumentType.Out,
		ArgumentType.Normal
	})]
	[HarmonyPatch(typeof(StorageComponent), "TakeTailItems", new Type[]
	{
		typeof(int),
		typeof(int),
		typeof(int[]),
		typeof(int),
		typeof(bool)
	}, new ArgumentType[]
	{
		ArgumentType.Ref,
		ArgumentType.Ref,
		ArgumentType.Normal,
		ArgumentType.Out,
		ArgumentType.Normal
	})]
	[HarmonyPatch(typeof(StorageComponent), "TakeTailItemsFiltered")]
	[HarmonyPriority(700)]
	[HarmonyPrefix]
	public static void StorageComponent_TakeTailItems_Prefix(StorageComponent __instance)
	{
		if (__instance.size == 80)
		{
			Monitor.Enter(QuantumStorageMutex);
		}
	}

	[HarmonyPatch(typeof(StorageComponent), "TakeTailItems", new Type[]
	{
		typeof(int),
		typeof(int),
		typeof(int),
		typeof(bool)
	}, new ArgumentType[]
	{
		ArgumentType.Ref,
		ArgumentType.Ref,
		ArgumentType.Out,
		ArgumentType.Normal
	})]
	[HarmonyPatch(typeof(StorageComponent), "TakeTailItems", new Type[]
	{
		typeof(int),
		typeof(int),
		typeof(int[]),
		typeof(int),
		typeof(bool)
	}, new ArgumentType[]
	{
		ArgumentType.Ref,
		ArgumentType.Ref,
		ArgumentType.Normal,
		ArgumentType.Out,
		ArgumentType.Normal
	})]
	[HarmonyPatch(typeof(StorageComponent), "TakeTailItemsFiltered")]
	[HarmonyPostfix]
	public static void StorageComponent_TakeTailItems_Postfix(StorageComponent __instance)
	{
		if (__instance.size == 80)
		{
			Monitor.Exit(QuantumStorageMutex);
		}
	}

	[HarmonyPatch(typeof(FactoryStorage), "GameTickStorage")]
	[HarmonyPatch(typeof(FactoryStorage), "GetStorageComponent")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> FactoryStorage_GameTick_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(StorageComponent), "id")));
		CodeInstruction instruction = codeMatcher.InstructionAt(-1);
		codeMatcher.Advance(2).InsertAndAdvance(new CodeInstruction(instruction), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(QuantumStoragePatches), "FactoryStorage_GameTick_PatchMethod")));
		codeMatcher.SetOpcodeAndAdvance(OpCodes.Brfalse);
		return codeMatcher.InstructionEnumeration();
	}

	public static bool FactoryStorage_GameTick_PatchMethod(int id, int index, StorageComponent component)
	{
		if (id != index)
		{
			return component.size == 80;
		}
		return true;
	}

	[HarmonyPatch(typeof(StorageComponent), "SetEmpty")]
	[HarmonyPriority(700)]
	[HarmonyPrefix]
	public static bool StorageComponent_SetEmpty(StorageComponent __instance)
	{
		return __instance.size != 80;
	}

	[HarmonyPatch(typeof(FactoryStorage), "NewStorageComponent")]
	[HarmonyPostfix]
	public static void FactoryStorage_NewStorageComponent(FactoryStorage __instance, int entityId, int size, ref StorageComponent __result)
	{
		if (size == 80)
		{
			int id = __result.id;
			int num = 1;
			StorageComponent storageComponent = _components[num - 1];
			__instance.storagePool[id] = storageComponent;
			__result = storageComponent;
			QuantumStorageIds.TryAddOrInsert(__instance.planet.id, new QuantumStorageData(id, num));
			SyncNewQuantumStorageData.Sync(__instance.planet.id, id, num);
		}
	}

	[HarmonyPatch(typeof(FactoryStorage), "RemoveStorageComponent")]
	[HarmonyPriority(700)]
	[HarmonyPrefix]
	public static bool FactoryStorage_RemoveStorageComponent(FactoryStorage __instance, int id)
	{
		StorageComponent storageComponent = __instance.storagePool[id];
		if (storageComponent == null)
		{
			return false;
		}
		if (storageComponent.size != 80)
		{
			return true;
		}
		int orbitId = QueryOrbitId(__instance.planet.id, id);
		QuantumStorageIds.TryRemove(__instance.planet.id, new QuantumStorageData(id, orbitId));
		__instance.storagePool[id] = new StorageComponent(30);
		__instance.storagePool[id].SetEmpty();
		__instance.storageRecycle[__instance.storageRecycleCursor++] = id;
		SyncRemoveQuantumStorageData.Sync(__instance.planet.id, id, orbitId);
		return false;
	}

	[HarmonyPatch(typeof(FactoryStorage), "TryTakeBackItems_Storage")]
	[HarmonyPostfix]
	public static void FactoryStorage_TryTakeBackItems_Storage(FactoryStorage __instance, int storageId, ref bool __result)
	{
		StorageComponent storageComponent = __instance.GetStorageComponent(storageId);
		if (storageComponent == null || storageComponent.size == 80)
		{
			__result = true;
		}
	}

	[HarmonyPatch(typeof(PlanetFactory), "InsertInto", new Type[]
	{
		typeof(int),
		typeof(int),
		typeof(int),
		typeof(byte),
		typeof(byte),
		typeof(byte)
	}, new ArgumentType[]
	{
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Out
	})]
	[HarmonyPatch(typeof(PlanetFactory), "InsertInto", new Type[]
	{
		typeof(uint),
		typeof(int),
		typeof(int),
		typeof(byte),
		typeof(byte),
		typeof(byte)
	}, new ArgumentType[]
	{
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Out
	})]
	[HarmonyPatch(typeof(PlanetFactory), "InsertIntoStorage")]
	[HarmonyPatch(typeof(PlanetFactory), "InsertCargoIntoStorage")]
	[HarmonyPatch(typeof(PlanetFactory), "PickFrom", new Type[]
	{
		typeof(int),
		typeof(int),
		typeof(int),
		typeof(int[]),
		typeof(byte),
		typeof(byte)
	}, new ArgumentType[]
	{
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Out,
		ArgumentType.Out
	})]
	[HarmonyPatch(typeof(PlanetFactory), "PickFrom", new Type[]
	{
		typeof(uint),
		typeof(int),
		typeof(int),
		typeof(int[]),
		typeof(byte),
		typeof(byte)
	}, new ArgumentType[]
	{
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Normal,
		ArgumentType.Out,
		ArgumentType.Out
	})]
	[HarmonyPatch(typeof(PlanetFactory), "PickFromStorage")]
	[HarmonyPatch(typeof(PlanetFactory), "PickFromStorageFiltered")]
	[HarmonyPatch(typeof(PlanetFactory), "PickFuelForPowerGenFrom")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> PlanetFactory_Mutexs_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(PlanetFactory), "entityMutexs")), new CodeMatch((CodeInstruction inst) => inst.IsLdloc()), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(StorageComponent), "entityId")), new CodeMatch(OpCodes.Ldelem_Ref));
		CodeInstruction instruction = codeMatcher.InstructionAt(-2);
		codeMatcher.Advance(1).InsertAndAdvance(new CodeInstruction(instruction), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(QuantumStoragePatches), "PlanetFactory_Mutexs_PatchMethod")));
		return codeMatcher.InstructionEnumeration();
	}

	public static Mutex PlanetFactory_Mutexs_PatchMethod(Mutex mutex, StorageComponent component)
	{
		if (component.size == 80)
		{
			return QuantumStorageMutex;
		}
		return mutex;
	}

	[HarmonyPatch(typeof(UIStorageWindow), "_OnUpdate")]
	[HarmonyPatch(typeof(UIStorageWindow), "OnStorageIdChange")]
	[HarmonyPatch(typeof(UIStorageWindow), "OnSortClick")]
	[HarmonyPatch(typeof(UIStorageWindow), "OnBansSliderValueChange")]
	[HarmonyPatch(typeof(UIStorageWindow), "OnFilterItemPickerReturn")]
	[HarmonyPatch(typeof(UIStorageWindow), "OnFilterButton2Click")]
	[HarmonyPatch(typeof(UIStorageWindow), "OnFilterButton3Click")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> UIStorageWindow_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(true, new CodeMatch(OpCodes.Ldloc_0), new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(StorageComponent), "id")), new CodeMatch(OpCodes.Ldarg_0), new CodeMatch(OpCodes.Call, AccessTools.PropertyGetter(typeof(UIStorageWindow), "storageId")));
		object operand = codeMatcher.Advance(1).Operand;
		codeMatcher.Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Ldloc_0), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(QuantumStoragePatches), "PatchMethod")), new CodeInstruction(OpCodes.Brtrue_S, operand));
		return codeMatcher.InstructionEnumeration();
	}

	public static bool PatchMethod(StorageComponent component)
	{
		return component.size == 80;
	}

	[HarmonyPatch(typeof(UIStorageWindow), "OnStorageIdChange")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> UIStorageWindow_OnStorageIdChange_Transpiler(IEnumerable<CodeInstruction> instructions, ILGenerator ilGenerator)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions, ilGenerator);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Ldfld, AccessTools.Field(typeof(EntityData), "protoId")));
		codeMatcher.CreateLabelAt(codeMatcher.Pos + 1, out var label);
		codeMatcher.Advance(-6).InsertAndAdvance(new CodeInstruction(OpCodes.Ldc_I4, 6231), new CodeInstruction(OpCodes.Ldloc_0), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(QuantumStoragePatches), "PatchMethod")), new CodeInstruction(OpCodes.Brtrue_S, label), new CodeInstruction(OpCodes.Pop));
		return codeMatcher.InstructionEnumeration();
	}

	[HarmonyPatch(typeof(FactoryStorage), "Import")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> FactoryStorage_Import_Transpiler(IEnumerable<CodeInstruction> instructions)
	{
		CodeMatcher codeMatcher = new CodeMatcher(instructions);
		codeMatcher.MatchForward(false, new CodeMatch(OpCodes.Stloc_2), new CodeMatch(OpCodes.Ldloc_2));
		object operand = codeMatcher.InstructionAt(2).operand;
		codeMatcher.Advance(1).InsertAndAdvance(new CodeInstruction(OpCodes.Ldarg_0), new CodeInstruction(OpCodes.Ldloc_1), new CodeInstruction(OpCodes.Call, AccessTools.Method(typeof(QuantumStoragePatches), "Import_PatchMethod")), new CodeInstruction(OpCodes.Brtrue, operand));
		return codeMatcher.InstructionEnumeration();
	}

	public static bool Import_PatchMethod(FactoryStorage storage, int storageId)
	{
		int num = QueryOrbitId(storage.planet.id, storageId);
		if (num < 0)
		{
			return false;
		}
		storage.storagePool[storageId] = _components[num - 1];
		return true;
	}

	[HarmonyPatch(typeof(UIGame), "_OnInit")]
	[HarmonyPostfix]
	public static void Init()
	{
		if ((bool)orbitPicker)
		{
			return;
		}
		orbitPicker = UnityEngine.Object.Instantiate(UIRoot.instance.uiGame.ejectorWindow.orbitPicker, UIRoot.instance.uiGame.storageWindow.transform);
		Transform transform = orbitPicker.transform;
		((RectTransform)transform).localPosition = new Vector3(90f, -410f, 0f);
		Transform transform2 = transform.GetChild(0).transform;
		((RectTransform)transform2).localPosition = new Vector3(-120f, -65f, 0f);
		UnityEngine.Object.DestroyImmediate(transform2.GetComponent<Localizer>());
		Text component = transform2.GetComponent<Text>();
		component.fontSize = 16;
		component.text = "选择量子频道".TranslateFromJson();
		transform.GetChild(1).gameObject.SetActive(value: false);
		transform.GetChild(2).gameObject.SetActive(value: false);
		transform.GetChild(3).gameObject.SetActive(value: false);
		Transform child = transform.GetChild(4);
		for (int i = 0; i < child.childCount; i++)
		{
			Transform child2 = child.GetChild(i);
			bool flag = i >= 2 && i <= 11;
			if (flag)
			{
				child2.GetChild(1).gameObject.SetActive(value: false);
			}
			child2.gameObject.SetActive(flag);
		}
		Array.Resize(ref orbitPicker.orbitButtons, 11);
		orbitPicker.UnregInnerEvents();
		orbitPicker.RegInnerEvents();
		orbitPicker.onOrbitButtonClick += OnOrbitPickerButtonClick;
	}

	private static void OnOrbitPickerButtonClick(int orbitId)
	{
		UIStorageWindow storageWindow = UIRoot.instance.uiGame.storageWindow;
		if (storageWindow.active && storageWindow.factory != null)
		{
			QuantumStorageOrbitChange(storageWindow.factory.planetId, storageWindow.storageId, orbitId);
			storageWindow.OnStorageIdChange();
		}
	}

	[HarmonyPatch(typeof(UIStorageWindow), "OnStorageIdChange")]
	[HarmonyPostfix]
	public static void UIStorageWindow_OnStorageIdChange_Postfix(UIStorageWindow __instance)
	{
		if (__instance.active && __instance.factory != null)
		{
			bool flag = __instance.factoryStorage.storagePool[__instance.storageId].size == 80;
			__instance.bansSlider.transform.parent.gameObject.SetActive(!flag);
			orbitPicker.gameObject.SetActive(flag);
			if (flag)
			{
				orbitPicker.SetOrbitId(QueryOrbitId(__instance.factory.planetId, __instance.storageId));
			}
		}
	}
}
