# starfi5h-MassRecipePaste — detailed change report

Installed plugin version(s): **1.1.5, 1.0.0**. Revalidate the target at paste time and preserve lab recipe compatibility and research restrictions.

This report covers the final local build and its development history. Historical tests apply to their recorded source/game hashes; later ports supersede earlier version contracts. `metadata.json` and `InstalledPackage/` identify the actual handoff binary.

## Paste-time validation and clipboard cleanup — 1.1.4/1.1.5

Use source matching installed 1.1.3, retaining both plugin GUIDs and assembly identity.

- Revalidate the selected building at paste time. Deleted/out-of-pool entities or prebuilds, zero and `int.MinValue` IDs never reach native setters.
- Limit the extra lab proliferator-mode selection path to the same current recipe; do not force an incompatible or research-locked different recipe.
- Count successful native `PasteToFactoryObject` results rather than popup calls. Replenishment or unrelated notifications must not increment the paste count.
- Clear `isPasting` and selection in `finally`, preserving the original exception and later normal notifications.
- Reset the extra ILS clipboard on a new copy. Copying another building or PLS cannot accidentally paste a previous ILS group/route.
- Retain native recipe locks, buffer refunds and BuildingParameters paths; new lens modes/storage filters use current setters, without a special-recipe ID list.

Version 1.1.5 adds `/unsafe+` metadata verified in native Mono. Independent checks cover invalid selection, success counting, popups without a tool and clipboard reset. Complete buffer/inc refunds, Genesis quantum behavior, rendered selection and Undo integration remain game acceptance work.

## Recorded source commits

- `3d77a1ebff3ed4d0b7c29aba4e1b9a6b61f7bea1`

## Evidence locations

Structured build/API/contract/installation results and test/patch sources are under `Evidence/`. Source-port diffs and structural baseline comparisons are under `Diffs/`. `Baselines/` identifies previous DLLs and comparison scope. A structural IL difference can include compiler or upstream changes and does not prove every changed instruction is a local semantic fix.
