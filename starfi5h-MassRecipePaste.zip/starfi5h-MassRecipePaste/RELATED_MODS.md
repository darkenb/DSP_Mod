# Related mod references - starfi5h-MassRecipePaste

Full related-mod packages are intentionally omitted. Project URLs, versions, exact local assembly hashes and targeted source files are supplied under `References/`. Upstream HEAD may differ from the locally modified snapshot. Build/runtime dependencies remain external prerequisites.

The source links below point to files actually present in this ZIP. Original line numbers and short excerpts are retained. A shared native integration point does not imply a direct DLL dependency.

## CommonAPI-CommonAPI

[Project identity and versions](References/CommonAPI-CommonAPI/reference.json) | [Reference notes](References/CommonAPI-CommonAPI/README.md)

Upstream: https://github.com/kremnev8/CommonAPI

- **declared_hard_dependency**: Plugin-level dependency declaration; this may belong to an optional compatibility plugin.
- **compiled_assembly_reference**: Actual assembly reference; inspect concrete members separately from data-only/native integration.

### Code in this mod

[Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/PluginCAPIcompat.cs](Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/PluginCAPIcompat.cs) - original line 9

```csharp

[BepInPlugin("starfi5h.plugin.MassRecipePaste.CAPIcompat", "MassRecipePasteCAPIcompat", "1.0.0")]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "LocalizationModule", "CustomKeyBindSystem" })]
public class PluginCAPIcompat : BaseUnityPlugin
```

[Source/EarlierWorkingSource/PluginCAPIcompat.cs](Source/EarlierWorkingSource/PluginCAPIcompat.cs) - original line 11

```csharp
{
    [BepInPlugin(GUID, NAME, VERSION)]
    [BepInDependency(CommonAPIPlugin.GUID)]
    [CommonAPISubmoduleDependency(nameof(LocalizationModule), nameof(CustomKeyBindSystem))]
    public class PluginCAPIcompat : BaseUnityPlugin
```

### Code in the related reference

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 16

```csharp
namespace CommonAPI;

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs) - original line 14

```csharp
[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
{
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/PowerNetworkHandler.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/PowerNetworkHandler.cs) - original line 58

```csharp
	public override string GetComponentType()
	{
		return "dsp.common-api.CommonAPI:PowerNetworkHandler";
	}

```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 35

```csharp
    {
        public const string ID = "CommonAPI";
        public const string GUID = "dsp.common-api.CommonAPI";
        public const string DISPNAME = "DSP Common API";

```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/BaseSubmodule.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/BaseSubmodule.cs) - original line 18

```csharp
		{
			string name = GetType().Name;
			throw new InvalidOperationException(name + " is not loaded. Please use [CommonAPISubmoduleDependency(nameof(" + name + ")]");
		}
	}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPISubmoduleDependency.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPISubmoduleDependency.cs) - original line 6

```csharp

[AttributeUsage(AttributeTargets.All, AllowMultiple = true)]
public class CommonAPISubmoduleDependency : Attribute
{
	public string?[]? SubmoduleNames { get; }
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ConfigFileExtension.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/ConfigFileExtension.cs) - original line 33

```csharp
				entry.SetSerializedValue(item.Value);
				list.Add(item.Key);
				CommonAPIPlugin.logger.LogInfo("Migrating config from " + oldSection + ":" + key + " to " + newSection + ":" + key);
			}
		}
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/HarmonyRegisterExtension.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/HarmonyRegisterExtension.cs) - original line 31

```csharp
			else
			{
				CommonAPIPlugin.logger.LogInfo("Failed to patch: " + item.FullName + ".");
			}
		}
```

## CommonAPI-DSPModSave

[Project identity and versions](References/CommonAPI-DSPModSave/reference.json) | [Reference notes](References/CommonAPI-DSPModSave/README.md)

Upstream: https://github.com/kremnev8/DSP-Mods/tree/master/Mods/DSPModSave

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave/DSPModSavePlugin.cs) - original line 15

```csharp
namespace crecheng.DSPModSave;

[BepInPlugin("crecheng.DSPModSave", "DSP Mod Save", "1.2.3")]
public class DSPModSavePlugin : BaseUnityPlugin
{
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameData_Patch.cs) - original line 12

```csharp
	private static void EnterGame()
	{
		DSPModSavePlugin.logger.LogInfo("Enter New Game");
		foreach (ModSaveSettings value in DSPModSavePlugin.allModData.Values)
		{
```

[References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/Reconstructed/plugins/DSPModSave/crecheng.DSPModSave.Patches/GameSave_Patch.cs) - original line 13

```csharp
		if (__result)
		{
			DSPModSavePlugin.OnSave(saveName);
		}
	}
```

[References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs](References/CommonAPI-DSPModSave/Code/Evidence/InitialPhase/check.cs) - original line 19

```csharp
static class Check
{
    static void Call(string method, params object[] args) {AccessTools.Method(typeof(DSPModSavePlugin), method).Invoke(null, args);}
    static int Main()
    {
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/DSPModSavePlugin.cs) - original line 20

```csharp
{
    [BepInPlugin(MODGUID, MODNAME, VERSION)]
    public class DSPModSavePlugin : BaseUnityPlugin
    {
        public const string MODGUID = "crecheng.DSPModSave";
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameData_Patch.cs) - original line 12

```csharp
        static void EnterGame()
        {
            DSPModSavePlugin.logger.LogInfo("Enter New Game");
            foreach (var d in DSPModSavePlugin.allModData.Values)
            {
```

[References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs](References/CommonAPI-DSPModSave/Code/Source/EarlierWorkingSource/Patches/GameSave_Patch.cs) - original line 14

```csharp
            if (!__result) return;

            DSPModSavePlugin.OnSave(saveName);
        }

```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 18

```csharp
[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
{
```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 31

```csharp
    [BepInPlugin(GUID, DISPNAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
    {
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 23

```csharp

[BepInPlugin("org.LoShin.GenesisBook", "GenesisBook", "3.2.6")]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/ProjectGenesis.cs) - original line 40

```csharp
{
    [BepInPlugin(MODGUID, MODNAME, VERSION)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    [BepInDependency(CommonAPIPlugin.GUID)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
```

## Galactic_Scale-GalacticScale

[Project identity and versions](References/Galactic_Scale-GalacticScale/reference.json) | [Reference notes](References/Galactic_Scale-GalacticScale/README.md)

Upstream: https://github.com/Touhma/DSP_Plugins

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/NebulaCompatibility.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/NebulaCompatibility.cs) - original line 20

```csharp
        {
            NebulaModAPI.RegisterPackets(Assembly.GetExecutingAssembly());
            GalacticScale.BCE.Console.Init();
            if (NebulaModAPI.NebulaIsInstalled)
            {
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/PluginInfo.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/PluginInfo.cs) - original line 6

```csharp
    {
        public const string PLUGIN_GUID = "dsp.galactic-scale.2";
        public const string PLUGIN_NAME = "GalacticScale";
        public const string PLUGIN_VERSION = "2.80.9";
    }
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Generators/Sol/Sol.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Generators/Sol/Sol.cs) - original line 276

```csharp
            stars.Clear();
            // GS2.Error("Test");
            //string path = Path.Combine(Path.Combine(Path.Combine(Path.Combine(Paths.BepInExRootPath, "plugins"), "GalacticScale"), "data"), "galaxy.json");
            var serializer = new fsSerializer();
            //string json = File.ReadAllText(path);
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Init.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Init.cs) - original line 16

```csharp
        private static readonly string AssemblyPath = Path.GetDirectoryName(Assembly.GetAssembly(typeof(GS2)).Location);
        private static readonly string OldDataDir = Path.Combine(AssemblyPath, "config");
        public static readonly string DataDir = Path.Combine(Paths.ConfigPath, "GalacticScale2");
        public static bool Failed = false;
        public static string updateMessage = "";
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/IO/Plugins.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/IO/Plugins.cs) - original line 44

```csharp
            foreach (var g in Generators)
            {
                Log("GalacticScale2|LoadPlugins|Loading Generator:" + g.Name);
                g.Init();
            }
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/IO/Save_Load.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/IO/Save_Load.cs) - original line 33

```csharp
            // var isVanilla = true;
            fsData data2 = null;
            var parseResult = fsResult.Fail("DSV contains no legacy GalacticScale settings.");
            try
            {
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Localization/GSLocalization.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Localization/GSLocalization.cs) - original line 46

```csharp
        {
            var entries = new Dictionary<string, string>(StringComparer.Ordinal);
            var name = $"GalacticScale.Translations.{language}.tsv";
            using (var stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(name))
            {
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/CosmicMessageManager/LateUpdate.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Scripts/Patches/CosmicMessageManager/LateUpdate.cs) - original line 21

```csharp
//  * 
//  * The original method assumes arrays are initialized and messageData is set,
//  * which may not be true during GalacticScale's extended initialization.
//  * 
//  * Changes from original:
```

### Dependency reference code

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GalacticScale.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/GalacticScale.cs) - original line 17

```csharp
internal static class GalacticScale
{
	internal const string GUID = "dsp.galactic-scale.2";

	private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility.dsp.galactic-scale.2");
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/InstallationCheckPlugin.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/InstallationCheckPlugin.cs) - original line 15

```csharp
[BepInDependency("org.kremnev8.plugin.BlueprintTweaks", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("Gnimaerd.DSP.plugin.MoreMegaStructure", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.galactic-scale.2", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("930f5bae-66d2-4917-988b-162fe2456643", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("testpostpleaseignore.dsp.planet_vein_utilization", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Compatibility/GalacticScale.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Compatibility/GalacticScale.cs) - original line 21

```csharp
    internal static class GalacticScale
    {
        internal const string GUID = "dsp.galactic-scale.2";

        private static readonly Harmony HarmonyPatch = new Harmony("ProjectGenesis.Compatibility." + GUID);
```

## HiddenCirno-GenesisBook

[Project identity and versions](References/HiddenCirno-GenesisBook/reference.json) | [Reference notes](References/HiddenCirno-GenesisBook/README.md)

Upstream: https://github.com/Awbugl/ProjectGenesis

- **fix_integration_context**: Paste validation preserves custom recipes and native parameter payloads used by Genesis buildings.

### Code in this mod

[Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/DragPasteTool.cs](Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/DragPasteTool.cs) - original line 447

```csharp
			return false;
		}
		bool flag = BuildingParameters.clipboard.CanPasteToFactoryObject(objId, factory);
		if (!flag && objId > 0 && (BuildingParameters.clipboard.type == BuildingType.Assembler || BuildingParameters.clipboard.type == BuildingType.Lab))
		{
```

[Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/Patches.cs](Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/Patches.cs) - original line 93

```csharp

	[HarmonyPostfix]
	[HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
	private static void CountSuccessfulPaste(bool __result)
	{
```

[Source/EarlierWorkingSource/DragPasteTool.cs](Source/EarlierWorkingSource/DragPasteTool.cs) - original line 437

```csharp
            if (objId > 0 && (factory.entityPool == null || objId >= factory.entityPool.Length || factory.entityPool[objId].id != objId)) return false;
            if (objId < 0 && (factory.prebuildPool == null || -objId >= factory.prebuildPool.Length || factory.prebuildPool[-objId].id != -objId)) return false;
            bool result = BuildingParameters.clipboard.CanPasteToFactoryObject(objId, factory);
            // CanPasteToFactoryObject大多數情況都是簡單判斷建築種類是否相同
            // 對於Assembler和Lab會額外判斷配方建築類型是否吻合和配方是否相同
```

[Source/EarlierWorkingSource/Patches.cs](Source/EarlierWorkingSource/Patches.cs) - original line 83

```csharp
        }

        [HarmonyPostfix, HarmonyPatch(typeof(BuildingParameters), nameof(BuildingParameters.PasteToFactoryObject))]
        private static void CountSuccessfulPaste(bool __result)
        {
```

[Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/ExtraCopy.cs](Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/ExtraCopy.cs) - original line 27

```csharp
	public static void CopyExtraClipborad(PlanetFactory __instance, int objectId)
	{
		StationParameters.Clear();
		if (objectId > 0 && objectId < __instance.entityPool.Length && __instance.entityPool[objectId].id == objectId)
		{
```

[Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/StationParameters.cs](Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/StationParameters.cs) - original line 5

```csharp
namespace MassRecipePaste;

internal static class StationParameters
{
	private static bool hasCopy;
```

[Evidence/InitialPhase/check.cs](Evidence/InitialPhase/check.cs) - original line 12

```csharp
    {
        var tool = (DragPasteTool)FormatterServices.GetUninitializedObject(typeof(DragPasteTool));
        BuildingParameters.clipboard.type = BuildingType.Assembler;
        foreach (int id in new[] {0, 1, -1, int.MinValue, int.MaxValue})
            if (tool.ShouldAddObject(id)) throw new Exception("Invalid native object accepted");
```

[Source/EarlierWorkingSource/ExtraCopy.cs](Source/EarlierWorkingSource/ExtraCopy.cs) - original line 27

```csharp
        public static void CopyExtraClipborad(PlanetFactory __instance, int objectId)
        {
            StationParameters.Clear();
            if (objectId <= 0 || objectId >= __instance.entityPool.Length) return;
            if (__instance.entityPool[objectId].id != objectId) return;
```

### Code in the related reference

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/MegaAssemblerPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/MegaAssemblerPatches.cs) - original line 173

```csharp
	}

	[HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
	[HarmonyTranspiler]
	public static IEnumerable<CodeInstruction> BuildingParameters_PasteToFactoryObject_Transpiler(IEnumerable<CodeInstruction> instructions)
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/QuantumStoragePatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/QuantumStoragePatches.cs) - original line 84

```csharp
	}

	[HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
	[HarmonyPrefix]
	public static bool BuildingParameters_PasteToFactoryObject_Prefix(ref BuildingParameters __instance, int objectId, PlanetFactory factory)
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Patches/Hooks/MegaAssembler/BuildingParametersPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Patches/Hooks/MegaAssembler/BuildingParametersPatches.cs) - original line 152

```csharp
        }

        [HarmonyPatch(typeof(BuildingParameters), nameof(BuildingParameters.PasteToFactoryObject))]
        [HarmonyTranspiler]
        public static IEnumerable<CodeInstruction> BuildingParameters_PasteToFactoryObject_Transpiler(
```

[References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Patches/Hooks/QuantumStorage/BuildingParametersPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/EarlierWorkingSource/Patches/Hooks/QuantumStorage/BuildingParametersPatches.cs) - original line 67

```csharp
        }

        [HarmonyPatch(typeof(BuildingParameters), nameof(BuildingParameters.PasteToFactoryObject))]
        [HarmonyPrefix]
        public static bool BuildingParameters_PasteToFactoryObject_Prefix(ref BuildingParameters __instance, int objectId,
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/ChemicalRecipeFcolPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/ChemicalRecipeFcolPatches.cs) - original line 14

```csharp
public static class ChemicalRecipeFcolPatches
{
	private static readonly Dictionary<int, int> RecipeIdPos = new Dictionary<int, int>
	{
		{ 506, 431 },
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/InitialTechPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/InitialTechPatches.cs) - original line 61

```csharp
				for (i = 0; i < unlockRecipes.Length; i++)
				{
					int recipeId = unlockRecipes[i];
					__instance.history.UnlockRecipe(recipeId);
				}
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/MultiProductionPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/MultiProductionPatches.cs) - original line 97

```csharp
		}
		AssemblerComponent assemblerComponent = __instance.factorySystem.assemblerPool[__instance.assemblerId];
		if (assemblerComponent.id != __instance.assemblerId || assemblerComponent.recipeId == 0)
		{
			return;
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/ProductOverflowPatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/ProductOverflowPatches.cs) - original line 46

```csharp
			break;
		}
		EOverflowFlag eOverflowFlag = (EOverflowFlag)(LDB.recipes.Select(component.recipeId)?.Overflow ?? 0);
		if ((ProjectGenesis.ProductOverflowEntry.Value == 0 && eOverflowFlag != EOverflowFlag.None) || ProjectGenesis.ProductOverflowEntry.Value == 1)
		{
```

## kremnev8-BlueprintTweaks

[Project identity and versions](References/kremnev8-BlueprintTweaks/reference.json) | [Reference notes](References/kremnev8-BlueprintTweaks/README.md)

Upstream: https://github.com/kremnev8/DSP-Mods/tree/master/Mods/BlueprintTweaks

- **fix_integration_context**: Paste validation and clipboard reset retain native parameter/Undo paths used by the blueprint mod.

### Code in this mod

[Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/DragPasteTool.cs](Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/DragPasteTool.cs) - original line 447

```csharp
			return false;
		}
		bool flag = BuildingParameters.clipboard.CanPasteToFactoryObject(objId, factory);
		if (!flag && objId > 0 && (BuildingParameters.clipboard.type == BuildingType.Assembler || BuildingParameters.clipboard.type == BuildingType.Lab))
		{
```

[Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/Patches.cs](Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/Patches.cs) - original line 93

```csharp

	[HarmonyPostfix]
	[HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
	private static void CountSuccessfulPaste(bool __result)
	{
```

[Source/EarlierWorkingSource/DragPasteTool.cs](Source/EarlierWorkingSource/DragPasteTool.cs) - original line 437

```csharp
            if (objId > 0 && (factory.entityPool == null || objId >= factory.entityPool.Length || factory.entityPool[objId].id != objId)) return false;
            if (objId < 0 && (factory.prebuildPool == null || -objId >= factory.prebuildPool.Length || factory.prebuildPool[-objId].id != -objId)) return false;
            bool result = BuildingParameters.clipboard.CanPasteToFactoryObject(objId, factory);
            // CanPasteToFactoryObject大多數情況都是簡單判斷建築種類是否相同
            // 對於Assembler和Lab會額外判斷配方建築類型是否吻合和配方是否相同
```

[Source/EarlierWorkingSource/Patches.cs](Source/EarlierWorkingSource/Patches.cs) - original line 83

```csharp
        }

        [HarmonyPostfix, HarmonyPatch(typeof(BuildingParameters), nameof(BuildingParameters.PasteToFactoryObject))]
        private static void CountSuccessfulPaste(bool __result)
        {
```

[Evidence/InitialPhase/check.cs](Evidence/InitialPhase/check.cs) - original line 12

```csharp
    {
        var tool = (DragPasteTool)FormatterServices.GetUninitializedObject(typeof(DragPasteTool));
        BuildingParameters.clipboard.type = BuildingType.Assembler;
        foreach (int id in new[] {0, 1, -1, int.MinValue, int.MaxValue})
            if (tool.ShouldAddObject(id)) throw new Exception("Invalid native object accepted");
```

[Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/ExtraCopy.cs](Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/ExtraCopy.cs) - original line 27

```csharp
	public static void CopyExtraClipborad(PlanetFactory __instance, int objectId)
	{
		StationParameters.Clear();
		if (objectId > 0 && objectId < __instance.entityPool.Length && __instance.entityPool[objectId].id == objectId)
		{
```

[Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/StationParameters.cs](Source/Reconstructed/plugins/MassRecipePaste/MassRecipePaste/StationParameters.cs) - original line 5

```csharp
namespace MassRecipePaste;

internal static class StationParameters
{
	private static bool hasCopy;
```

[Source/EarlierWorkingSource/ExtraCopy.cs](Source/EarlierWorkingSource/ExtraCopy.cs) - original line 27

```csharp
        public static void CopyExtraClipborad(PlanetFactory __instance, int objectId)
        {
            StationParameters.Clear();
            if (objectId <= 0 || objectId >= __instance.entityPool.Length) return;
            if (__instance.entityPool[objectId].id != objectId) return;
```

### Code in the related reference

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.PasteLocked/BuildingParameters_Patch.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.PasteLocked/BuildingParameters_Patch.cs) - original line 11

```csharp
public static class BuildingParameters_Patch
{
	[HarmonyPatch(typeof(BuildingParameters), "CanPasteToFactoryObject")]
	[HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
	[HarmonyTranspiler]
```

[References/kremnev8-BlueprintTweaks/Code/Source/EarlierWorkingSource/PasteLocked/BuildingParameters_Patch.cs](References/kremnev8-BlueprintTweaks/Code/Source/EarlierWorkingSource/PasteLocked/BuildingParameters_Patch.cs) - original line 13

```csharp
    public static class BuildingParameters_Patch
    {
        [HarmonyPatch(typeof(BuildingParameters), "CanPasteToFactoryObject")]
        [HarmonyPatch(typeof(BuildingParameters), "PasteToFactoryObject")]
        [HarmonyTranspiler]
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.FactoryUndo/UndoBuild.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.FactoryUndo/UndoBuild.cs) - original line 11

```csharp
	protected static int[] tmpIds = new int[20];

	public static BuildingParameters undoClipboard = BuildingParameters.zero;

	protected List<int> objectIds;
```

[References/kremnev8-BlueprintTweaks/Code/Source/EarlierWorkingSource/FactoryUndo/UndoActions/UndoBuild.cs](References/kremnev8-BlueprintTweaks/Code/Source/EarlierWorkingSource/FactoryUndo/UndoActions/UndoBuild.cs) - original line 12

```csharp
    {
        protected static int[] tmpIds = new int[20];
        public static BuildingParameters undoClipboard = BuildingParameters.zero;
        
        public UndoBuild(PlayerUndo undoData, int objectId) : base(undoData)
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/patchers/BlueprintTweaksPatcher/BlueprintTweaks/Preloader.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/patchers/BlueprintTweaksPatcher/BlueprintTweaks/Preloader.cs) - original line 27

```csharp
			return null;
		}
		MethodDefinition methodDefinition = typeDefinition.Methods.SingleOrDefault((MethodDefinition m) => m.IsConstructor && m.Parameters.Count == 0 && !m.IsStatic);
		if (methodDefinition == null)
		{
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/BlueprintUtilsPatch2.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/BlueprintUtilsPatch2.cs) - original line 488

```csharp
	private static void MirrorStationData(BuildPreview preview, BlueprintBuilding building)
	{
		if (preview.desc.isCollectStation || building.parameters == null || building.parameters.Length == 0 || preview.desc.portPoses == null || building.parameters.Length < 192 + preview.desc.portPoses.Length * 4)
		{
			return;
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/UIHintsPanel.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/UIHintsPanel.cs) - original line 37

```csharp
			int itemId = blueprintBuilding.itemId;
			ItemProto itemProto = LDB.items.Select(itemId);
			if (itemProto == null || !itemProto.prefabDesc.isBelt || blueprintBuilding.parameters == null || blueprintBuilding.parameters.Length < 1)
			{
				continue;
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/UIRecipesPanel.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/UIRecipesPanel.cs) - original line 48

```csharp
				{
					num = 0 - itemProto.prefabDesc.assemblerRecipeType;
					if (itemProto.prefabDesc.isLab && blueprintBuilding.parameters.Length != 0 && blueprintBuilding.parameters[0] != 2)
					{
						num = -15;
```

## nebula-NebulaMultiplayerModApi

[Project identity and versions](References/nebula-NebulaMultiplayerModApi/reference.json) | [Reference notes](References/nebula-NebulaMultiplayerModApi/README.md)

Upstream: https://github.com/NebulaModTeam/nebula

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI/NebulaModAPI.cs) - original line 15

```csharp
[BepInPlugin("dsp.nebula-multiplayer-api", "NebulaMultiplayerModApi", "2.1.0.7")]
[BepInDependency("dsp.nebula-multiplayer", BepInDependency.DependencyFlags.SoftDependency)]
public class NebulaModAPI : BaseUnityPlugin
{
	public const string NEBULA_MODID = "dsp.nebula-multiplayer";
```

[References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs](References/nebula-NebulaMultiplayerModApi/Code/Source/Reconstructed/plugins/NebulaAPI/NebulaAPI.DataStructures/CollectionExtensions.cs) - original line 5

```csharp
namespace NebulaAPI.DataStructures;

public static class CollectionExtensions
{
	public static Locker Lock(this ICollection collection)
```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/NebulaCompatPlugin.cs) - original line 13

```csharp

[BepInPlugin("dsp.common-tools.common-api-nebula-compat", "Common API Nebula Compatibility", "1.6.8.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
public class NebulaCompatPlugin : BaseUnityPlugin, IMultiplayerMod
```

[References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Bootstrap.cs](References/Galactic_Scale-GalacticScale/Code/Source/PortedWorkingSource/Bootstrap.cs) - original line 20

```csharp
    [BepInPlugin("dsp.galactic-scale.2", "Galactic Scale 2 Plug-In", "2.80.9")]
    [BepInDependency("space.customizing.console", BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("lltcggie.DSP.plugin.PlanetwidePlanetaryShieldGenerator", BepInDependency.DependencyFlags.SoftDependency)]
    [BepInDependency("un1eagle.planetwideshield", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/GalacticScale/Bootstrap.cs](References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/GalacticScale/Bootstrap.cs) - original line 14

```csharp
[BepInPlugin("dsp.galactic-scale.2", "Galactic Scale 2 Plug-In", "2.80.9")]
[BepInDependency("space.customizing.console", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("lltcggie.DSP.plugin.PlanetwidePlanetaryShieldGenerator", BepInDependency.DependencyFlags.SoftDependency)]
[BepInDependency("un1eagle.planetwideshield", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/NebulaCompatibility/Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod.cs](References/Galactic_Scale-GalacticScale/Code/Source/Reconstructed/plugins/GalacticScale/NebulaCompatibility/Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod.cs) - original line 13

```csharp

[BepInPlugin("dsp.galactic-scale.2.nebula", "Galactic Scale 2 Nebula Compatibility Plug-In", "1.0.0.0")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
public class Ignore_This_Warning_If_Not_Using_Nebula_Multiplayer_Mod : BaseUnityPlugin, IMultiplayerModWithSettings, IMultiplayerMod
{
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 26

```csharp
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.LoShin.GenesisBook.InstallationCheck", BepInDependency.DependencyFlags.SoftDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "TabSystem", "LocalizationModule" })]
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/BlueprintTweaksPlugin.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks/BlueprintTweaksPlugin.cs) - original line 26

```csharp

[BepInPlugin("org.kremnev8.plugin.BlueprintTweaks", "Blueprint Tweaks", "1.6.14")]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[CommonAPISubmoduleDependency(new string[] { "ProtoRegistry", "CustomKeyBindSystem", "PickerExtensionsSystem", "LocalizationModule" })]
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.InstallCheck/InstallationChecker.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.InstallCheck/InstallationChecker.cs) - original line 35

```csharp
			ldbToolInstalled = true;
		}
		if (Chainloader.PluginInfos.ContainsKey("dsp.nebula-multiplayer-api"))
		{
			nebulaAPIInstalled = true;
```

[References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.InstallCheck/UIMainMenuPatch.cs](References/kremnev8-BlueprintTweaks/Code/Source/Reconstructed/plugins/BlueprintTweaks/BlueprintTweaks.InstallCheck/UIMainMenuPatch.cs) - original line 26

```csharp
				text += "  - Plugin \"LDB Tool\" is missing\n";
			}
			if (!InstallationChecker.nebulaAPIInstalled)
			{
				text += "  - Plugin \"Nebula Multiplayer Mod API\" is missing\n";
```

## xiaoye97-LDBTool

[Project identity and versions](References/xiaoye97-LDBTool/reference.json) | [Reference notes](References/xiaoye97-LDBTool/README.md)

Upstream: https://github.com/xiaoye97/DSP_LDBTool

- **required_reference_dependency**: Required by a copied related mod so its dependency code is available without a different maintainer folder.

### Code in the related reference

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBTool.cs) - original line 11

```csharp
namespace xiaoye97;

public static class LDBTool
{
	public static Action PreAddDataAction;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/LDBToolPlugin.cs) - original line 11

```csharp
namespace xiaoye97;

[BepInPlugin("me.xiaoye97.plugin.Dyson.LDBTool", "LDBTool", "3.0.4")]
public class LDBToolPlugin : BaseUnityPlugin
{
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97/ProtoIndex.cs) - original line 16

```csharp
	internal static void InitIndex()
	{
		LDBToolPlugin.logger.LogDebug("Generating Proto type list:");
		protoTypes = (from domainAssembly in AppDomain.CurrentDomain.GetAssemblies()
			from assemblyType in GetTypesSafe(domainAssembly)
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/AssemblerComponent_Patch.cs) - original line 19

```csharp
		if (__instance.recipeExecuteData == null)
		{
			LDBToolPlugin.logger.LogWarning($"Importing assembler {__instance.recipeType}: Can't find recipeId {__instance.recipeId}");
			__instance.recipeId = 0;
			__instance.recipeType = ERecipeType.None;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/GameHistoryData_Patch.cs) - original line 12

```csharp
	private static void HistoryPatch(GameHistoryData __instance)
	{
		foreach (Proto item in LDBTool.TotalDict[ProtoIndex.GetIndex(typeof(RecipeProto))])
		{
			RecipeProto recipeProto = item as RecipeProto;
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/UITip_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/UITip_Patch.cs) - original line 12

```csharp
	private static void ItemTipPatch(UIItemTip __instance, int itemId)
	{
		if (LDBToolPlugin.ShowProto.Value)
		{
			__instance.nameText.text += $" {itemId}";
```

[References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/VFPreload_Patch.cs](References/xiaoye97-LDBTool/Code/Source/Reconstructed/plugins/LDBTool/xiaoye97.Patches/VFPreload_Patch.cs) - original line 15

```csharp
	private static void VFPreloadPrePatch()
	{
		if (!LDBTool.Finshed)
		{
			LDBToolPlugin.logger.LogInfo("Pre Loading...");
```

[References/xiaoye97-LDBTool/Code/Evidence/InitialPhase/check.cs](References/xiaoye97-LDBTool/Code/Evidence/InitialPhase/check.cs) - original line 53

```csharp
            return null;
        };
        try { plugin = Assembly.LoadFrom(Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "LDBTool.dll")); Run(); }
        catch (Exception error) { Console.Error.WriteLine(error); Environment.ExitCode = 1; }
    }
```

### Dependency reference code

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI/CommonAPIPlugin.cs) - original line 17

```csharp

[BepInPlugin("dsp.common-api.CommonAPI", "DSP Common API", "1.6.8.0")]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
```

[References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/ProtoRegistry.cs](References/CommonAPI-CommonAPI/Code/Source/Reconstructed/plugins/CommonAPI/CommonAPI.Systems/ProtoRegistry.cs) - original line 81

```csharp
		spriteFileExtensions = new string[3] { ".jpg", ".png", ".tif" };
		audioClipFileExtensions = new string[4] { ".mp3", ".ogg", ".waw", ".aif" };
		LDBTool.PostAddDataAction = (Action)Delegate.Combine(LDBTool.PostAddDataAction, new Action(OnPostAdd));
		LDBTool.EditDataAction = (Action<Proto>)Delegate.Combine(LDBTool.EditDataAction, new Action<Proto>(EditProto));
	}
```

[References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs](References/CommonAPI-CommonAPI/Code/Source/EarlierWorkingSource/CommonAPIPlugin.cs) - original line 30

```csharp
    /// </summary>
    [BepInPlugin(GUID, DISPNAME, VERSION)]
    [BepInDependency(LDBToolPlugin.MODGUID)]
    [BepInDependency(DSPModSavePlugin.MODGUID)]
    public class CommonAPIPlugin : BaseUnityPlugin, IModCanSave
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis/ProjectGenesis.cs) - original line 25

```csharp
[BepInDependency("crecheng.DSPModSave", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.common-api.CommonAPI", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("me.xiaoye97.plugin.Dyson.LDBTool", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("dsp.nebula-multiplayer-api", BepInDependency.DependencyFlags.HardDependency)]
[BepInDependency("org.LoShin.GenesisBook.InstallationCheck", BepInDependency.DependencyFlags.SoftDependency)]
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/MoreMegaStructure.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Compatibility/MoreMegaStructure.cs) - original line 37

```csharp
			HarmonyPatch.Patch(AccessTools.Method(typeof(VFPreload), "InvokeOnLoadWorkEnded"), null, new HarmonyMethod(typeof(MoreMegaStructure), "LDBToolOnPostAddDataAction")
			{
				after = new string[1] { "me.xiaoye97.plugin.Dyson.LDBTool" }
			});
		}
```

[References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/DisableLDBToolCachePatches.cs](References/HiddenCirno-GenesisBook/Code/Source/Reconstructed/plugins/ProjectGenesis/ProjectGenesis.Patches/DisableLDBToolCachePatches.cs) - original line 21

```csharp

	[HarmonyPatch(typeof(VFPreload), "InvokeOnLoadWorkEnded")]
	[HarmonyAfter(new string[] { "me.xiaoye97.plugin.Dyson.LDBTool" })]
	[HarmonyPostfix]
	public static void DeleteFiles()
```
