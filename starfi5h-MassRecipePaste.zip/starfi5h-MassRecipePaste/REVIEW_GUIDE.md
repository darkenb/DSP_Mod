# Review map for starfi5h-MassRecipePaste

Start with [CHANGELOG.md](CHANGELOG.md) for the concrete changes and historical validation limits, then [RELATED_MODS.md](RELATED_MODS.md) for relationships and included code references.

- `Source/Reconstructed/`: primary installed-assembly code exported by ILSpy; not original-author source or a clean rebuild guarantee.
- Earlier working, ported and upstream snapshots are distinguished in `Source/PROVENANCE.json`.
- `Evidence/`: original focused checks, installation records and any later overlays.
- `Diffs/` and `Baselines/`: prior comparisons and baselines, subject to the explicit size exclusions.
- `References/`: targeted related-mod source files and exact identity/version/hash records. Full related-mod packages are not included.
- [PACKAGING.md](PACKAGING.md): size policy, omissions and build/runtime requirements.
- [STANDALONE_VERIFICATION.json](STANDALONE_VERIFICATION.json): current package checks.

The primary development code and validation records were preserved byte-for-byte. Historical scripts may need their original game/SDK, resources and machine-path adaptations. Real Unity UI, complete saves, all-mod startup and sustained-memory acceptance remain separate.
