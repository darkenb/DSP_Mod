using System;
using System.Runtime.Serialization;
using HarmonyLib;
using MassRecipePaste;
using Patches = MassRecipePaste.Patches;

static class Check
{
    static int Main()
    {
        var tool = (DragPasteTool)FormatterServices.GetUninitializedObject(typeof(DragPasteTool));
        BuildingParameters.clipboard.type = BuildingType.Assembler;
        foreach (int id in new[] {0, 1, -1, int.MinValue, int.MaxValue})
            if (tool.ShouldAddObject(id)) throw new Exception("Invalid native object accepted");
        Patches.tool = null;
        if (!Patches.Blocker()) throw new Exception("Popup suppressed without tool");
        Patches.tool = tool; tool.isPasting = true;
        var count = AccessTools.Method(typeof(Patches), "CountSuccessfulPaste");
        count.Invoke(null, new object[] {false});
        if (tool.pastedCount != 0) throw new Exception("Failed native paste counted");
        count.Invoke(null, new object[] {true});
        if (tool.pastedCount != 1 || Patches.Blocker() || tool.pastedCount != 1) throw new Exception("Popup or success count incorrect");
        var clipboard = typeof(Plugin).Assembly.GetType("MassRecipePaste.StationParameters");
        AccessTools.Field(clipboard, "hasCopy").SetValue(null, true);
        AccessTools.Method(clipboard, "Clear").Invoke(null, null);
        if ((bool)AccessTools.Field(clipboard, "hasCopy").GetValue(null)) throw new Exception("Previous station clipboard retained");
        Console.WriteLine("PASS invalid object rejection, native success count independent of popups, missing tool guard and station clipboard reset");
        return 0;
    }
}
